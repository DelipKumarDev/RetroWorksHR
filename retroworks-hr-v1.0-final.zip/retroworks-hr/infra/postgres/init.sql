-- RetroWorks HR — PostgreSQL Init Script
-- Runs once on first database initialization

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";       -- UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";        -- Cryptographic functions
CREATE EXTENSION IF NOT EXISTS "pg_trgm";         -- Trigram similarity (fuzzy search)
CREATE EXTENSION IF NOT EXISTS "btree_gin";       -- GIN index support
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements"; -- Query performance tracking

-- pgvector — AI embeddings (1536 dims for OpenAI, 1024 for Anthropic)
-- Note: pgvector/pgvector:pg16 image includes this by default
CREATE EXTENSION IF NOT EXISTS "vector";

-- Create schema for AI knowledge base chunks
-- (Prisma handles all other tables via migrations)
CREATE TABLE IF NOT EXISTS kb_chunks (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   TEXT NOT NULL,
  document_id TEXT NOT NULL,
  content     TEXT NOT NULL,
  embedding   vector(1536),    -- OpenAI text-embedding-3-small dimensions
  chunk_index INTEGER DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- HNSW index for fast approximate nearest neighbor search
-- (IVFFlat is faster to build, HNSW is faster to query)
CREATE INDEX IF NOT EXISTS kb_chunks_embedding_idx
  ON kb_chunks USING hnsw (embedding vector_cosine_ops)
  WITH (m = 16, ef_construction = 64);

-- Tenant isolation index
CREATE INDEX IF NOT EXISTS kb_chunks_tenant_idx ON kb_chunks (tenant_id);
CREATE INDEX IF NOT EXISTS kb_chunks_document_idx ON kb_chunks (document_id);

-- Performance configuration
ALTER SYSTEM SET work_mem = '32MB';
ALTER SYSTEM SET maintenance_work_mem = '128MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET random_page_cost = 1.1;  -- SSD-optimized
ALTER SYSTEM SET pg_trgm.similarity_threshold = 0.3;

-- Grant permissions to app user
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO retroworks;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO retroworks;
GRANT ALL PRIVILEGES ON TABLE kb_chunks TO retroworks;

\echo 'RetroWorks HR database initialized successfully'
\echo 'Extensions: uuid-ossp, pgcrypto, pg_trgm, btree_gin, pg_stat_statements, vector'
