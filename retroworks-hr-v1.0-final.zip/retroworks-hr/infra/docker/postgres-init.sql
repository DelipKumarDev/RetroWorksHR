-- RetroWorks HR — PostgreSQL Initialization
-- Runs on first container start

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "vector";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- for fuzzy text search

-- Set default timezone
SET timezone = 'UTC';

-- Log configuration
ALTER SYSTEM SET log_timezone = 'UTC';
ALTER SYSTEM SET log_min_duration_statement = '1000ms';

-- Performance tuning for t2.micro (1GB RAM)
ALTER SYSTEM SET shared_buffers = '128MB';
ALTER SYSTEM SET work_mem = '4MB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
ALTER SYSTEM SET effective_cache_size = '512MB';
ALTER SYSTEM SET max_connections = 80;

SELECT pg_reload_conf();
