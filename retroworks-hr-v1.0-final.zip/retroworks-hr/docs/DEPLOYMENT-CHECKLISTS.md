# RetroWorks HR — Deployment Checklists

---

## 📦 STAGING DEPLOYMENT CHECKLIST

Run this before every staging push.

### Pre-Deploy
- [ ] All tests passing: `pnpm test` → 0 failures (Part 2: 94/94, Part 3: 97/97, Part 4: 148/148)
- [ ] No console.log in production paths: `grep -r "console.log" apps/api/src --include="*.ts" | grep -v __tests__`
- [ ] `.env.staging` has no CHANGE-ME values
- [ ] `JWT_SECRET` and `JWT_REFRESH_SECRET` are ≥64 chars and differ from each other
- [ ] `ALLOWED_ORIGINS` does not contain wildcard `*`
- [ ] `DATABASE_URL` points to staging DB (not prod)

### Build
- [ ] `pnpm build` exits 0
- [ ] `apps/api/dist/main.js` exists
- [ ] `apps/web/.next/BUILD_ID` exists

### Database
- [ ] `prisma migrate deploy` exits 0
- [ ] Performance index migration applied: `master-audit-indexes-v4.0.0.sql`
- [ ] Leave year-end ledger migration applied: `leave-year-end-ledger-v4.1.0.sql`

### Deploy
- [ ] `docker compose -f docker-compose.prod.yml up -d` exits 0
- [ ] All containers show `healthy` within 2 minutes
- [ ] `GET /health` returns `{"status":"ok",...}`
- [ ] Swagger disabled (`/api/docs` returns 404 in prod)

---

## 🚀 PRODUCTION DEPLOYMENT CHECKLIST

All staging checks plus:

### Security Pre-Flight
- [ ] JWT secrets rotated from staging values
- [ ] `USE_KMS=true` — encryption keys in AWS KMS
- [ ] `REDIS_URL` uses `rediss://` (TLS) for ElastiCache
- [ ] `AWS_S3_ENDPOINT` removed (no MinIO in prod)
- [ ] CloudFront distribution active, HTTPS enforced
- [ ] `ALLOWED_ORIGINS=https://hr.yourcompany.com` (no localhost)
- [ ] Rate limiting configured for login endpoint

### Database Pre-Flight
- [ ] RDS automated backups enabled (7-day retention minimum)
- [ ] RDS Multi-AZ enabled (for HA)
- [ ] DB parameter group: `shared_preload_libraries=pg_stat_statements`
- [ ] pgvector extension installed: `CREATE EXTENSION IF NOT EXISTS vector`
- [ ] All migrations applied and verified

### Deployment
- [ ] Previous version image tagged and retained for rollback
- [ ] Deploy to 1 instance first, verify health, then scale
- [ ] Monitor CloudWatch for error rate spike
- [ ] Verify `POST /api/v1/auth/login` works end-to-end

### Post-Deployment
- [ ] 24-hour observation period with alert coverage
- [ ] Smoke test suite passes (see below)
- [ ] Update deployment record in ops runbook

---

## 🧪 POST-DEPLOYMENT SMOKE TEST CHECKLIST

Run these manually after every production deployment.

### Auth
- [ ] `POST /api/v1/auth/login` with valid credentials → 200 + access_token
- [ ] `POST /api/v1/auth/login` with bad password → 401 (not 500)
- [ ] `POST /api/v1/auth/login` 6× wrong password → 429 (account lockout)
- [ ] `GET /api/v1/auth/me` with expired token → 401
- [ ] `POST /api/v1/auth/refresh` with valid cookie → 200 + new access_token
- [ ] `POST /api/v1/auth/logout` → 204 + cookie cleared

### Tenant Isolation
- [ ] Login as Tenant A, attempt to read Tenant B employee list → 403 or empty
- [ ] Login as Tenant B, attempt to access Tenant A payroll → 403

### Payroll
- [ ] Create payroll run (hr-admin role) → 201
- [ ] Approve payroll (finance role) → 200
- [ ] Employee role: attempt to approve payroll → 403

### Leave
- [ ] Submit leave request → 201
- [ ] Manager approves leave → 200
- [ ] Check leave balance decremented → correct

### Education Mode (if applicable)
- [ ] Login as education tenant user → terminology shows "Staff" not "Employee"
- [ ] Attempt to access recruitment module → 403

### Health & Observability
- [ ] `GET /health` → `{"status":"ok","db":"connected","redis":"connected"}`
- [ ] `GET /metrics` → Prometheus metrics (with auth token)
- [ ] Grafana dashboard shows API request rate

---

## 🗂️ FOLDER TREE & ZIP INSTRUCTIONS

### Final Monorepo Structure
```
retroworks-hr/
├── apps/
│   ├── api/                      NestJS backend
│   │   ├── src/
│   │   │   ├── modules/
│   │   │   │   ├── leave/year-end/leave-year-end.engine.ts  [NEW Part 3]
│   │   │   │   ├── security/role-permission.engine.ts
│   │   │   │   ├── settings/education-mode.engine.ts
│   │   │   │   ├── auth/auth-secure.controller.ts            [H-09 fix]
│   │   │   │   ├── payroll/                                  [Part 1-2]
│   │   │   │   └── ...
│   │   │   ├── common/
│   │   │   │   ├── security/env-validator.ts                 [C-01]
│   │   │   │   └── ...
│   │   │   └── main.ts
│   │   ├── prisma/
│   │   │   └── schema.prisma                                 [1376 lines]
│   │   ├── migrations/
│   │   │   ├── security-sprint-v2.0.0.sql
│   │   │   ├── tds-engine-v3.0.0.sql
│   │   │   ├── form16-engine-v3.1.0.sql
│   │   │   ├── pf-esi-pt-v3.3.0.sql
│   │   │   ├── master-audit-indexes-v4.0.0.sql
│   │   │   └── leave-year-end-ledger-v4.1.0.sql              [NEW Part 4]
│   │   └── Dockerfile
│   └── web/                      Next.js frontend
│       └── ...
├── infra/
│   ├── docker/
│   │   ├── Dockerfile.api
│   │   └── Dockerfile.web
│   └── postgres/
│       └── init.sql
├── packages/
│   ├── types/
│   ├── ui/
│   └── config/
├── docs/
│   ├── adr.md
│   ├── PRODUCTION-DEPLOYMENT.md                              [NEW Part 4]
│   ├── DEPLOYMENT-CHECKLISTS.md                              [NEW Part 4]
│   └── ROLES-GUIDE.md                                        [NEW Part 4]
├── docker-compose.yml
├── docker-compose.prod.yml
├── .env.example
├── package.json
├── pnpm-workspace.yaml
├── turbo.json
└── tsconfig.base.json
```

### Create Production ZIP

```bash
cd /opt

# 1. Build
cd retroworks-hr && pnpm build

# 2. Remove dev artifacts
rm -rf node_modules apps/api/node_modules apps/web/node_modules
rm -rf apps/api/dist apps/web/.next  # Will be rebuilt in Docker

# 3. Create ZIP (excludes .git, node_modules, .env files)
zip -r retroworks-hr-prod.zip retroworks-hr/ \
  --exclude "*.git*" \
  --exclude "*node_modules*" \
  --exclude "*.env.local" \
  --exclude "*.env.production" \
  --exclude "*/.next/*" \
  --exclude "*/dist/*"

# 4. Verify
unzip -l retroworks-hr-prod.zip | grep -c "\.ts$"
# Should show ~200+ TypeScript files
```

