# RetroWorks HR — Production Deployment Guide

## Overview

This guide covers full production deployment to AWS EC2 (t2.micro) with RDS PostgreSQL, ElastiCache Redis, S3, SES, and CloudFront.

---

## Prerequisites

- AWS account with appropriate IAM permissions
- EC2 t2.micro instance (Ubuntu 22.04 LTS)
- RDS PostgreSQL 16 instance
- ElastiCache Redis cluster
- S3 bucket for file storage
- SES verified sending domain
- Domain name with SSL certificate (ACM or Let's Encrypt)

---

## EC2 Instance Setup

```bash
# 1. SSH into instance
ssh -i your-key.pem ubuntu@<EC2_PUBLIC_IP>

# 2. Install Docker + Docker Compose
curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh
sudo apt-get install -y docker-compose-plugin
sudo usermod -aG docker ubuntu
newgrp docker

# 3. Install pnpm + Node 20
curl -fsSL https://fnm.vercel.app/install | bash
source ~/.bashrc && fnm use --install-if-missing 20
npm install -g pnpm@9

# 4. Clone repository
git clone https://github.com/your-org/retroworks-hr.git
cd retroworks-hr
```

---

## Environment Configuration

```bash
# 1. Copy and edit environment file
cp .env.example .env.production

# 2. REQUIRED — generate secrets
openssl rand -hex 32  # → JWT_SECRET (must be ≥64 hex chars → use 64)
openssl rand -hex 32  # → JWT_REFRESH_SECRET
openssl rand -hex 32  # → ENCRYPTION_KEY
openssl rand -hex 32  # → MAGIC_LINK_SECRET
openssl rand -hex 32  # → NEXTAUTH_SECRET

# 3. Edit .env.production with your values:
nano .env.production
```

**Required values in `.env.production`:**

| Variable | Description |
|---|---|
| `NODE_ENV` | Must be `production` |
| `DATABASE_URL` | `postgresql://user:pass@rds-endpoint:5432/retroworks` |
| `REDIS_URL` | `rediss://clustercfg.endpoint.cache.amazonaws.com:6379` |
| `JWT_SECRET` | ≥64 char random hex (openssl rand -hex 32) |
| `JWT_REFRESH_SECRET` | ≥64 char random hex, different from JWT_SECRET |
| `ENCRYPTION_KEY` | 64 char hex (AES-256) |
| `ALLOWED_ORIGINS` | `https://app.yourcompany.com` (no wildcards) |
| `AWS_S3_BUCKET` | Your S3 bucket name |
| `AWS_REGION` | e.g. `ap-south-1` |
| `MAGIC_LINK_SECRET` | ≥32 char random hex |
| `AWS_SES_FROM_EMAIL` | Verified SES email address |
| `NEXTAUTH_URL` | `https://app.yourcompany.com` |

---

## Production Build

```bash
# 1. Install dependencies
pnpm install --frozen-lockfile

# 2. Build all packages
pnpm build

# 3. Run database migrations
cd apps/api
DATABASE_URL=$DATABASE_URL npx prisma migrate deploy

# 4. Apply performance indexes
psql $DATABASE_URL -f migrations/master-audit-indexes-v4.0.0.sql
psql $DATABASE_URL -f migrations/leave-year-end-ledger-v4.1.0.sql
```

---

## Docker Deployment

```bash
# Production stack startup
docker compose -f docker-compose.prod.yml --env-file .env.production up -d

# Verify all services healthy
docker compose -f docker-compose.prod.yml ps

# Check API logs
docker compose -f docker-compose.prod.yml logs -f api

# Health check
curl https://app.yourcompany.com/health
```

---

## SSL / NGINX

The `docker-compose.prod.yml` includes an NGINX reverse proxy. Configure SSL:

```bash
# Install Certbot on host
sudo apt install certbot

# Obtain certificate
sudo certbot certonly --standalone -d app.yourcompany.com

# Copy to nginx certs volume
sudo cp /etc/letsencrypt/live/app.yourcompany.com/fullchain.pem infra/nginx/certs/
sudo cp /etc/letsencrypt/live/app.yourcompany.com/privkey.pem infra/nginx/certs/
```

---

## Post-Deployment Verification

```bash
# API health
curl https://app.yourcompany.com/health

# Auth check
curl -X POST https://app.yourcompany.com/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@company.com","password":"..."}'

# Prometheus metrics (internal only)
curl http://localhost:3001/metrics | head -20
```

---

## Backup & Restore

```bash
# Database backup
pg_dump $DATABASE_URL -Fc -f retroworks_$(date +%Y%m%d).dump

# Upload to S3
aws s3 cp retroworks_$(date +%Y%m%d).dump s3://$BACKUP_S3_BUCKET/db/

# Restore
pg_restore -d $DATABASE_URL retroworks_20250101.dump
```

---

## Incident Response

| Scenario | Action |
|---|---|
| API down | `docker compose restart api` → check logs |
| DB connection failure | Verify RDS security group, DATABASE_URL, RDS status |
| JWT auth failures | Check JWT_SECRET in env, clear Redis sessions |
| High memory | `docker stats` → scale or reduce connection pool |
| Payroll locked | Check `payroll_runs` table status; `redis-cli DEL lock:payroll:*` |
| Cross-tenant incident | Immediately rotate ENCRYPTION_KEY, audit `audit_logs` table |

---

## Monitoring

- **Prometheus**: `http://localhost:9090` (internal)
- **Grafana**: `http://localhost:3002` (internal)
- **PgAdmin**: Disabled in production (remove from compose if needed)

---

## Scaling

For > 500 employees, consider:
- RDS: upgrade to `db.t3.medium`
- Redis: ElastiCache `cache.t3.small`  
- EC2: `t2.small` or add load balancer + second instance
- Enable PgBouncer connection pooling
