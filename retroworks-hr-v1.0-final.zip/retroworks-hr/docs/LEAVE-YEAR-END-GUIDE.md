# RetroWorks HR — Leave Year-End Processing Guide

> Engine: `src/modules/leave/year-end/leave-year-end.engine.ts`

---

## Year Types

| Type | Period | Used By |
|------|--------|---------|
| `financial` | Apr → Mar | Most corporate tenants (India) |
| `calendar` | Jan → Dec | Some corporates, global entities |
| `academic` | Jun → May | Education mode tenants |

## Processing Steps

1. **Configure** year-end config (`LeaveYearConfig`)
2. **Simulate** first (`isSimulation=true`) — no changes, diff report only
3. **Review** simulation output, check encashment amounts
4. **Process** real run (`isSimulation=false`) — ledger locked
5. **Verify** ledger consistency (`verifyLedgerConsistency`)
6. **Lock** balances for new year

## Key Invariant

For every `(employee, leaveType)` record:
```
carryForwardDays + lapsedDays + encashedDays = closingAvailable
```
Any violation surfaces in `verifyLedgerConsistency().violations[]`.

## Idempotency

The guard prevents double-processing:
```typescript
const guard = guardIdempotency(ledger, tenantId, 2024);
// guard.safe = false → already processed, block re-run
```

## Freeze Window

During freeze (default 3 days before year-end):
- `canSubmitLeaveRequest()` returns `{ allowed: false }`
- New leave submissions are blocked
- In-progress requests must be resolved before processing

## Education Mode

Education tenants use `yearType: 'academic'` (Jun–May).  
Leave types unique to education:
- `VL` (Vacation Leave): 50 days, no carry-forward (summer/winter break)
- `EL` (Earned Leave): 30 days, carry-forward 15 days

