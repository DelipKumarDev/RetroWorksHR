# Environment Variables Guide

All required variables are enforced at boot by `env-validator.ts`. Missing or placeholder values cause immediate crash with a descriptive error.

## Required Variables (App will not start without these)

| Variable | Minimum | Validation | Example |
|---|---|---|---|
| `JWT_SECRET` | 64 chars | Not CHANGE-ME, not placeholder | `openssl rand -hex 32` |
| `JWT_REFRESH_SECRET` | 64 chars | Different from JWT_SECRET | `openssl rand -hex 32` |
| `ENCRYPTION_KEY` | 32 chars | Not CHANGE-ME | `openssl rand -hex 16` |
| `MAGIC_LINK_SECRET` | 32 chars | Not CHANGE-ME | `openssl rand -hex 16` |
| `DATABASE_URL` | — | Must start `postgresql://` | `postgresql://user:pass@host:5432/db` |
| `REDIS_URL` | — | Must start `redis://` or `rediss://` | `rediss://cluster.cache.amazonaws.com:6379` |
| `ALLOWED_ORIGINS` | — | No wildcard `*` | `https://app.yourcompany.com` |

## Warnings Only (App starts but logs warning)

| Variable | When Warned |
|---|---|
| `FRONTEND_URL` | Not using HTTPS in production |
| `DATABASE_URL` | Points to localhost (reminder) |
| `AWS_S3_BUCKET` | Not set (file uploads will fail) |
| `BACKUP_ENCRYPTION_KEY` | Not set (backups unencrypted) |

## Application Settings

```env
NODE_ENV=production         # Disables Swagger, enables JSON logging
APP_NAME=RetroWorks HR
PORT=3001
LOG_LEVEL=info              # debug | info | warn | error
LOG_FORMAT=json             # json (production) | pretty (development)
```

## JWT Settings

```env
JWT_SECRET=<64-char-hex>
JWT_EXPIRES_IN=15m          # Access token TTL
JWT_REFRESH_SECRET=<64-char-hex>
JWT_REFRESH_EXPIRES_IN=7d   # Refresh token TTL
```

## Database

```env
DATABASE_URL=postgresql://retroworks:pass@rds-endpoint:5432/retroworks_prod
```

## Redis

```env
REDIS_URL=rediss://clustercfg.xxxx.cache.amazonaws.com:6379
REDIS_TLS=true              # Set true for ElastiCache TLS
```

## AWS Services

```env
AWS_REGION=ap-south-1
AWS_ACCESS_KEY_ID=<iam-key>
AWS_SECRET_ACCESS_KEY=<iam-secret>
AWS_S3_BUCKET=retroworks-hr-prod
AWS_KMS_KEY_ID=<kms-key-id>        # Required for encrypted PII
AWS_SES_FROM_EMAIL=noreply@company.com
AWS_CLOUDFRONT_URL=https://dxxxx.cloudfront.net
```

## Security

```env
ALLOWED_ORIGINS=https://app.company.com,https://admin.company.com
WEBHOOK_SECRET=<32-char-hex>
ENCRYPTION_KEY=<64-char-hex>        # AES-256 for PII fields
USE_KMS=true                        # Use AWS KMS instead of local key
MAGIC_LINK_SECRET=<32-char-hex>
MAGIC_LINK_EXPIRES_MINUTES=15
```

## Frontend (Next.js)

```env
NEXT_PUBLIC_API_URL=https://api.company.com
NEXT_PUBLIC_WS_URL=wss://api.company.com
NEXTAUTH_URL=https://app.company.com
NEXTAUTH_SECRET=<32-char-hex>
```

## SMTP / Email

```env
SMTP_HOST=email-smtp.ap-south-1.amazonaws.com
SMTP_PORT=587
SMTP_USER=<ses-smtp-user>
SMTP_PASS=<ses-smtp-password>
SMTP_FROM=RetroWorks HR <noreply@company.com>
```

## Generating Secrets

```bash
# 64-char JWT secret
openssl rand -hex 32

# 32-char encryption key  
openssl rand -hex 16

# Any arbitrary secret
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```
