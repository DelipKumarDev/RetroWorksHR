# RetroWorks HR — Education Mode Setup Guide

> Engine: `src/modules/settings/education-mode.engine.ts`

---

## Enabling Education Mode

```typescript
const result = toggleEducationMode(tenantId, currentConfig, true, hasPayrollData);
// result.success: true
// result.newMode: 'education'
// result.requiredActions: [...steps to complete]
```

## Post-Enable Required Actions

1. Configure academic year start/end months (default: Jun–May)
2. Set board affiliation (CBSE / ICSE / State Board)
3. Configure pay commission (7th / 8th Pay Commission)
4. Create teacher leave entitlements (EL 30d, CL 8d, ML 10d, VL 50d)
5. Assign education roles to staff (teacher, HOD, principal, bursar)
6. Verify disabled modules: recruitment, expense, analytics

## Terminology Changes

| Corporate | Education |
|-----------|-----------|
| Employee | Staff |
| Manager | HOD |
| Financial Year | Academic Year |
| Department | Faculty / Department |

## Disabled Modules in Education Mode

- `recruitment` — blocked (`isModuleAllowedInEducationMode` returns false)
- `expense` — blocked
- `analytics` — blocked

## Principal Approval Workflow

The Principal (or Director) must approve the annual leave close.  
Multi-step workflow with mandatory sign-off at each stage:

```typescript
let wf = initializeLeaveCloseWorkflow(config, '2024-25');
// Steps: department-review → bursar-verify → principal-approve → final-lock
for (const step of wf.steps) {
  wf = advanceWorkflowStep(wf, step.stepId, userId, 'approved');
}
// wf.status === 'approved' → safe to lock ledger
```

## 7th Pay Commission

Education tenants default to 7th Pay Commission grade structure.  
April payroll validation automatically warns about DA arrears.

