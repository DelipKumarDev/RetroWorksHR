# RetroWorks HR — Incident Response Guide

---

## P1 — Production Outage

**Signs**: API returns 5xx, health check fails, users cannot log in

### Immediate (0-5 min)
```bash
# Check container status
docker compose -f docker-compose.prod.yml ps
docker compose -f docker-compose.prod.yml logs api --tail=100

# Check DB connection
docker exec retroworks_postgres pg_isready -U retroworks

# Restart API if crash loop
docker compose -f docker-compose.prod.yml restart api
```

### Escalation
- If DB down → check RDS console, restore from snapshot if needed
- If Redis down → `docker compose restart redis`, payroll locks fall back to DB unique constraint
- If total failure → rollback to previous image tag

---

## P2 — Tenant Data Leakage

**Signs**: User sees another tenant's data, cross-tenant 403 not firing

### Immediate
1. Disable affected tenant's access (set `isActive=false` in tenants table)
2. Pull audit logs: `SELECT * FROM audit_logs WHERE tenantId = '<id>' ORDER BY timestamp DESC LIMIT 200`
3. Identify which query bypassed `PrismaTenantService`

### Fix
- All DB queries must go through `PrismaTenantService.forTenant(tenantId)`
- Never use `this.prisma.model.findMany()` without `where: { tenantId }` scoping
- Audit trail: `AuditLog` table records every data access

---

## P3 — Payroll Double-Run

**Signs**: Two PayrollRun records for same tenant + period

### Immediate
1. `SELECT * FROM payroll_runs WHERE "tenantId" = '<id>' AND period = '2025-03'`
2. Identify duplicate, mark one as `status='reversed'`
3. Check `leave_year_end_ledgers` for matching idempotency violation

### Prevention
- DB unique constraint: `@@unique([tenantId, payrollGroupId, period])`
- Redis distributed lock: `redis-lock.service.ts`
- Both must be healthy for payroll runs

---

## P4 — JWT Secret Compromise

**Signs**: Forged tokens accepted, unauthorized access

### Immediate
1. Rotate `JWT_SECRET` and `JWT_REFRESH_SECRET` immediately
2. Restart all API containers (invalidates all existing tokens)
3. Clear all sessions: `DELETE FROM sessions WHERE createdAt < NOW()`
4. Notify affected users to re-authenticate

### Recovery
```bash
# Generate new secrets
openssl rand -hex 32  # → new JWT_SECRET
openssl rand -hex 32  # → new JWT_REFRESH_SECRET

# Update .env.production, restart
docker compose -f docker-compose.prod.yml restart api
```

---

## P5 — Leave Year-End Failure

**Signs**: Year-end process fails mid-run, partial records written

### Check
```sql
SELECT * FROM leave_year_end_ledgers
WHERE "tenantId" = '<id>' ORDER BY "createdAt" DESC LIMIT 1;

SELECT COUNT(*) FROM leave_year_end_entries WHERE "ledgerId" = '<ledger_id>';
```

### Recovery
1. If `isLocked=false` → safe to re-run (idempotency guard checks this)
2. If `isLocked=true` but inconsistent → delete ledger + entries, re-run
3. Run `verifyLedgerConsistency()` after recovery to confirm clean state

