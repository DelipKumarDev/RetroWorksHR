# RetroWorks HR — Role & Permission Engine Guide

> System roles, custom roles, field masking, temporary elevation, education roles

---

## System Roles

| Role | Access Level | Key Permissions |
|------|-------------|-----------------|
| `hr-admin` | HR administration | All leave, employee CRUD, year-end, statutory |
| `finance` | Payroll & statutory | Payroll run, TDS, PF/ESI, Form 16, all pay data |
| `manager` | Team management | Team attendance, leave approval, performance |
| `employee` | Self-service only | Own payslip, own leave, own attendance |

## Custom Roles

```typescript
const custom = createCustomRole(tenantId, {
  name: 'payroll-auditor',
  displayName: 'Payroll Auditor',
  allowedModules: ['payroll', 'payroll-tds'],
  permissions: [{ resource: 'payroll:run', module: 'payroll', actions: ['read', 'export'] }],
  menuVisibility: { 'nav-payroll': true },
  globalMaskedFields: ['bankAccountNumber'],
}, createdBy);
```

## Field Masking

Fields masked per role:
- **HR Admin / Finance**: No masking (full visibility)
- **Manager**: `salary`, `ctc`, `bankAccountNumber`, `panNumber` masked
- **HOD (Education)**: Same as Manager
- **Employee**: Self-record only, salary visible in own payslip

## Temporary Elevation

```typescript
const elevation = grantTemporaryElevation({
  userId, tenantId,
  targetRoleId: financeRole.id, targetRoleName: 'finance',
  reason: 'Q4 payroll coverage',
  grantedBy: 'hr-admin-001',
  durationHours: 8,  // Max: 72h
});
// isRevoked: false → active; expiresAt enforced
```

## Education Roles

| Role | Module Access | Notes |
|------|--------------|-------|
| `principal` | All (inc. payroll) | Approves year-end, runs Form 16 |
| `hod` | Leave, attendance, performance | Dept-scoped |
| `teacher` | Self-service + leave | Own records only |
| `bursar` | Payroll, TDS, PF/ESI, Form 16 | Finance equivalent |

