# Role & Permission Engine Guide

## Overview

The Role & Permission Engine provides RBAC (Role-Based Access Control) with ABAC (Attribute-Based Access Control) extensions, field-level masking, temporary elevation, and full audit logging.

## System Roles

| Role | Module Access | Field Masking |
|---|---|---|
| `hr-admin` | All HR modules | None (full access) |
| `finance` | payroll, tds, pf-esi, form16, reports | None |
| `manager` | core-hr, leave, attendance, performance | salary, ctc, bank fields |
| `employee` | Self-service only (own records) | All sensitive fields |

## Checking Access

```typescript
const result = canAccess(ctx, 'leave', 'leave:request', 'approve');
// result.allowed: true/false
// result.reason: explanation
// result.matchedRole: which role granted/denied
```

## Enforcing Access (With Audit Log)

```typescript
const log: PermissionAuditEvent[] = [];
const result = enforceAccess(ctx, 'payroll', 'payroll:run', 'approve', log);

if (!result.allowed) {
  // log[0].action === 'access_denied' — automatically logged
  throw new ForbiddenException(result.reason);
}
```

## Field Masking

```typescript
// Get list of fields to mask for this context
const maskedFields = getMaskedFields(ctx, 'employee');

// Apply masking to a record
const safeRecord = maskRecord(record, ctx, 'employee');
// { name: 'Arjun', salary: '****', ctc: '****', department: 'Eng' }
```

Sensitive fields: `salary`, `ctc`, `bankAccountNumber`, `ifscCode`, `panNumber`, `aadhaarNumber`, `passportNumber`, `mfaSecret`, `passwordHash`, `netPay`, `basicPay`.

## Temporary Elevation

```typescript
// Grant 4-hour finance access to a manager
const elevation = grantTemporaryElevation({
  userId: 'mgr-001',
  tenantId: 'tenant-acme',
  targetRoleId: financeRole.id,
  targetRoleName: 'finance',
  reason: 'Q4 payroll coverage — Priya on leave',
  grantedBy: 'hr-admin-001',
  durationHours: 4,   // Max: 72 hours
});

// Check if still active
if (isElevationActive(elevation)) {
  // elevated access granted
}

// Revoke early
const revoked = revokeElevation(elevation, 'hr-admin-001');
```

**Constraints:**
- Maximum duration: 72 hours (configurable)
- Revocation is permanent — once revoked, cannot be re-activated
- All grants and revocations are audit-logged

## Custom Roles

```typescript
const auditorRole = createCustomRole(
  tenantId,
  {
    name: 'payroll-auditor',
    displayName: 'Payroll Auditor',
    description: 'Read-only payroll + TDS access for Q4 audit',
    allowedModules: ['payroll', 'payroll-tds'],
    permissions: [
      { resource: 'payroll:run', module: 'payroll', actions: ['read', 'export'] },
      { resource: 'payroll:tds', module: 'payroll-tds', actions: ['read', 'export'] },
    ],
    menuVisibility: { 'nav-payroll': true, 'nav-payroll-tds': true },
    globalMaskedFields: ['bankAccountNumber'],
  },
  'admin-001',  // createdBy
);
```

## Role Simulation (Dry-Run)

Test what a role can do before assigning it to a user:

```typescript
const sim = simulateRole(
  roleDefinition,
  { targetRoleId: role.id, resource: 'payroll:run', module: 'payroll', action: 'approve' },
  fullMenuTree,
);
// sim.allowed: true/false
// sim.visibleModules: list
// sim.maskedFields: list
```

## Audit Events

All permission operations generate audit events:

```typescript
// Access denied
const event = auditAccessDenied(ctx, 'payroll', 'payroll:run', 'approve', 'No matching permission');
// event.action: 'access_denied'

// Role created
const event = auditRoleCreated(role, 'admin-001');
// event.action: 'role_created'

// Elevation granted
const event = auditElevationGranted(elevation);
// event.action: 'elevation_granted'
// event.metadata.auditToken: tamper-proof token
```
