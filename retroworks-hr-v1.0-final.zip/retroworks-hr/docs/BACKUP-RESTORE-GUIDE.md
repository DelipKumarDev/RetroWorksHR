# Backup & Restore Guide

## Automated Backups

RetroWorks HR includes a built-in backup module (`/modules/backup/`) that runs scheduled backups via cron.

### Configuration

```env
BACKUP_DIR=/var/retroworks/backups
BACKUP_ENCRYPTION_KEY=<32-char-hex>
BACKUP_S3_BUCKET=retroworks-hr-backups
BACKUP_RETAIN_DAILY=7       # Keep 7 daily backups
BACKUP_RETAIN_WEEKLY=4      # Keep 4 weekly backups
```

## Manual Database Backup

```bash
# Full database backup (compressed)
pg_dump $DATABASE_URL \
  -Fc \
  --no-acl \
  --no-owner \
  -f retroworks_$(date +%Y%m%d_%H%M%S).dump

# Upload to S3
aws s3 cp retroworks_$(date +%Y%m%d_%H%M%S).dump \
  s3://$BACKUP_S3_BUCKET/manual/

# Verify backup integrity
pg_restore --list retroworks_<timestamp>.dump | head -20
```

## Restore Procedure

```bash
# 1. Download backup from S3
aws s3 cp s3://$BACKUP_S3_BUCKET/retroworks_20250101.dump .

# 2. Create fresh database
createdb retroworks_restore

# 3. Restore
pg_restore \
  -d $RESTORE_DATABASE_URL \
  --no-owner \
  --no-acl \
  retroworks_20250101.dump

# 4. Re-apply any migrations that postdate the backup
DATABASE_URL=$RESTORE_DATABASE_URL npx prisma migrate deploy

# 5. Verify row counts
psql $RESTORE_DATABASE_URL -c "
  SELECT 'tenants' as t, COUNT(*) FROM tenants UNION ALL
  SELECT 'employees', COUNT(*) FROM employees UNION ALL
  SELECT 'payroll_runs', COUNT(*) FROM payroll_runs;
"
```

## S3 File Storage Backup

```bash
# Sync S3 bucket to backup bucket
aws s3 sync s3://$AWS_S3_BUCKET s3://$BACKUP_S3_BUCKET/files/
```

## Point-in-Time Recovery (RDS)

For RDS, enable automated backups with 7-day retention:
```bash
aws rds modify-db-instance \
  --db-instance-identifier retroworks-prod \
  --backup-retention-period 7 \
  --preferred-backup-window "03:00-04:00"
```

Restore to point in time via AWS Console: RDS → Instance → Restore to point in time.

## Disaster Recovery Checklist

1. Identify backup to restore from (daily, weekly, or point-in-time)
2. Provision new RDS instance from snapshot or restore
3. Re-apply post-backup migrations
4. Update `DATABASE_URL` in `.env.production`
5. Restart API service
6. Run smoke tests (`/health` + auth + one payroll query)
7. Notify affected tenants of any data gap
