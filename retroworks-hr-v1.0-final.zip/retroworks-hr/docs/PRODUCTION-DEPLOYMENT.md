# RetroWorks HR — Production Deployment Guide

> EC2 t2.micro / RDS / ElastiCache / S3 / CloudFront / SES  
> Stack: NestJS + Next.js + PostgreSQL + Redis  
> Last updated: Part 4 Final Consolidation

---

## Prerequisites

| Tool | Version |
|------|---------|
| Docker | ≥ 24 |
| Docker Compose | ≥ 2.20 |
| pnpm | ≥ 9.1 |
| Node.js | ≥ 20 LTS |
| PostgreSQL | 16 (pgvector extension) |
| Redis | 7 |
| AWS CLI | ≥ 2 |

---

## Architecture Overview

```
CloudFront (CDN/TLS)
    │
    ├── /          → EC2: Next.js (port 3000)
    └── /api/*     → EC2: NestJS API (port 3001)
                        │
                        ├── RDS PostgreSQL 16 + pgvector
                        ├── ElastiCache Redis 7
                        ├── S3 (file uploads, Form 16 PDFs)
                        └── SES (email notifications)
```

---

## Step 1 — EC2 Instance Setup

```bash
# Launch: t2.micro, Ubuntu 22.04 LTS, 20GB EBS gp3
# Open ports: 22 (SSH), 80, 443, 3000, 3001

# Connect
ssh -i ~/.ssh/retroworks.pem ubuntu@<INSTANCE_IP>

# Install Docker
curl -fsSL https://get.docker.com -o install-docker.sh
sudo sh install-docker.sh
sudo usermod -aG docker ubuntu

# Install Docker Compose plugin
sudo apt-get install docker-compose-plugin -y

# Install pnpm (for build only)
curl -fsSL https://get.pnpm.io/install.sh | sh -
```

---

## Step 2 — Clone and Configure

```bash
# Clone repository
git clone https://github.com/retroworks/retroworks-hr.git /opt/retroworks-hr
cd /opt/retroworks-hr

# Create production environment file
cp .env.example .env.production
nano .env.production
```

### Required Environment Variables

```bash
# ─── CRITICAL: Generate BEFORE going live ────────────────────────────────────
# JWT_SECRET (64+ chars, cryptographically random)
openssl rand -hex 32    # → 64 hex chars

# JWT_REFRESH_SECRET (must differ from JWT_SECRET)
openssl rand -hex 32

# ENCRYPTION_KEY (AES-256-GCM)
openssl rand -hex 32

# MAGIC_LINK_SECRET
openssl rand -hex 16

# ─── Fill in .env.production ─────────────────────────────────────────────────
NODE_ENV=production
JWT_SECRET=<64-char-random>
JWT_REFRESH_SECRET=<64-char-random-different>
ENCRYPTION_KEY=<32-byte-hex>
DATABASE_URL=postgresql://retroworks:<PASSWORD>@<RDS_ENDPOINT>:5432/retroworks_hr
REDIS_URL=rediss://<ELASTICACHE_ENDPOINT>:6380
ALLOWED_ORIGINS=https://hr.yourcompany.com
AWS_REGION=ap-south-1
AWS_S3_BUCKET=retroworks-hr-prod
AWS_SES_FROM_EMAIL=noreply@yourcompany.com
```

> **Security Rule**: `.env.production` must NEVER be committed to git.  
> Verify: `git check-ignore -v .env.production`

---

## Step 3 — Build

```bash
cd /opt/retroworks-hr

# Install dependencies
pnpm install --frozen-lockfile

# Build all packages
pnpm build

# Verify build artifacts
ls apps/api/dist/main.js
ls apps/web/.next/BUILD_ID
```

---

## Step 4 — Database Setup

```bash
# Run migrations (auto-runs on container start via Dockerfile CMD)
# But can also be run manually:
npx prisma migrate deploy --schema=apps/api/prisma/schema.prisma

# Apply performance indexes
psql $DATABASE_URL -f apps/api/migrations/master-audit-indexes-v4.0.0.sql
psql $DATABASE_URL -f apps/api/migrations/leave-year-end-ledger-v4.1.0.sql

# Seed tax slabs (FY2024-25, FY2025-26)
cd apps/api && npx ts-node prisma/seed.ts
```

---

## Step 5 — Deploy with Docker Compose

```bash
cd /opt/retroworks-hr

# Validate compose file
docker compose -f docker-compose.prod.yml config

# Pull / build images
docker compose -f docker-compose.prod.yml build

# Start all services
docker compose -f docker-compose.prod.yml up -d

# Check health
docker compose -f docker-compose.prod.yml ps
docker compose -f docker-compose.prod.yml logs api --tail=50
```

---

## Step 6 — Verify Deployment

```bash
# API health check
curl https://hr.yourcompany.com/api/v1/health

# Expected response:
# {"status":"ok","timestamp":"...","version":"1.1.0","db":"connected","redis":"connected"}

# Check audit log (should have bootstrap event)
curl -H "Authorization: Bearer <ADMIN_TOKEN>" \
  https://hr.yourcompany.com/api/v1/audit-logs?limit=5
```

---

## Rollback Procedure

```bash
# Quick rollback to previous image
docker compose -f docker-compose.prod.yml down
docker compose -f docker-compose.prod.yml pull
git checkout <PREVIOUS_TAG>
docker compose -f docker-compose.prod.yml up -d

# Database rollback (if migration applied)
psql $DATABASE_URL -c "-- Run rollback SQL specific to the migration"
```

---

## SSL/TLS via CloudFront

1. Request ACM certificate in `us-east-1` for `hr.yourcompany.com`
2. Create CloudFront distribution pointing to EC2 (custom origin, HTTPS to origin)
3. Set `ALLOWED_ORIGINS=https://hr.yourcompany.com` in production env

---

## Backup & Restore

```bash
# Daily backup (add to cron: 0 2 * * *)
pg_dump $DATABASE_URL | gzip | \
  aws s3 cp - s3://retroworks-hr-backups/$(date +%Y-%m-%d).sql.gz \
  --sse aws:kms

# Restore
aws s3 cp s3://retroworks-hr-backups/2025-01-01.sql.gz - | \
  gunzip | psql $DATABASE_URL
```

---

## Monitoring

- **Health endpoint**: `GET /health` — DB + Redis status
- **Metrics**: `GET /metrics` — Prometheus format (guarded by `METRICS_AUTH_TOKEN`)
- **Grafana**: `http://localhost:3100` on prod stack (add to Nginx with auth)
- **Logs**: `docker compose logs api -f` — JSON structured logs

