# ADR-001: Modular Monolith Architecture

**Status:** Accepted  
**Date:** 2024-01-01  
**Deciders:** RetroWorks HR Architecture Team  

---

## Context

We need to build a production-grade HRMS/HRIS covering HIRE→RETIRE with India payroll compliance, AI HR Copilot, and multi-tenant support. The team is small, budget is constrained (AWS Free Tier), and we need to ship fast while remaining scalable.

## Decision

Start as a **modular monolith** with clear module boundaries, then extract microservices as needed.

### Structure
- Single NestJS application with clearly separated modules
- Each HR module (Leave, Payroll, ATS, etc.) is a self-contained NestJS module
- Shared kernel: Auth, Tenant, Database, Audit, Events
- Event-driven internal communication (NestJS EventEmitter)
- Contracts defined via shared TypeScript types

### Future Microservice Extraction Path
When traffic or team size demands it, extract in this order:
1. AI/RAG service (most compute-intensive)
2. Payroll engine (compliance isolation)
3. Notifications service (scale independently)

## Consequences

### Positive
- Faster development and deployment
- Simpler local dev setup
- Lower infrastructure cost (single EC2 t2.micro)
- Easier debugging and tracing
- Shared database transactions (critical for payroll integrity)

### Negative
- Cannot scale individual modules independently (until extracted)
- Single point of failure (mitigated by health checks + auto-restart)
- All modules share one deploy lifecycle

## Compliance with Decision

All NestJS modules MUST:
1. Never import from another module's internal files
2. Only use the public module interface (exported providers)
3. Communicate cross-module via EventEmitter for async operations
4. Define clear DTOs for cross-module data
5. Use the shared `PrismaClient` with tenant filtering middleware

---

# ADR-002: Row-Level Tenancy Strategy

**Status:** Accepted

## Decision

Every database table includes `tenantId`. Prisma middleware enforces tenant filtering on all queries. JWT tokens contain `tid` (tenant ID) which is validated on every request.

**NO** schema-per-tenant (too complex for free tier RDS).
**NO** database-per-tenant (too expensive).

Row-level isolation with middleware enforcement + comprehensive audit logging.

---

# ADR-003: PII Encryption Strategy

**Status:** Accepted

## Decision

Sensitive PII (PAN, Aadhaar, bank details, UAN) is encrypted using AES-256-GCM before storage.

- **Development:** Symmetric key in env var
- **Production:** AWS KMS envelope encryption
- Field-level masking for display (last 4 chars visible)
- DSR export/delete workflow with 2-person approval
- Legal hold prevents deletion

---

# ADR-004: pgvector for RAG over FAISS

**Status:** Accepted

## Decision

Use **pgvector** (PostgreSQL extension) as the primary vector store over FAISS.

### Rationale
- Same database, no additional infra cost
- Tenant filtering via SQL WHERE clause (native)
- Hybrid search: vector similarity + full-text (pg_trgm)
- ACID transactions for document ingestion
- Simpler operational model on t2.micro

### FAISS Fallback
FAISS adapter available if pgvector performance is insufficient.

---

# ADR-005: Upstash Redis (Serverless) over Self-Hosted

**Status:** Accepted

## Decision

Use **Upstash Redis** (free tier: 10k commands/day) for BullMQ queues and caching.

Fallback: in-process queue with PostgreSQL persistence for dev environments without Redis.
