# Incident Response Guide

## Severity Levels

| Level | Description | Response Time |
|---|---|---|
| P0 | Complete outage or data breach | Immediate |
| P1 | Partial outage, payroll blocked | < 1 hour |
| P2 | Feature degraded, workaround available | < 4 hours |
| P3 | Minor issue, no business impact | Next business day |

---

## P0 — Security Incident (Suspected Data Breach)

```bash
# IMMEDIATE: Revoke all active sessions
redis-cli FLUSHDB                          # Kills all sessions

# Rotate secrets (new values via AWS Secrets Manager)
# Update .env.production, restart all containers
docker compose -f docker-compose.prod.yml restart

# Audit cross-tenant access
psql $DATABASE_URL -c "
  SELECT tenantId, userId, action, resource, ip, timestamp
  FROM audit_logs
  WHERE timestamp > NOW() - INTERVAL '24 hours'
    AND action IN ('EXPORT', 'DELETE', 'BULK_UPDATE')
  ORDER BY timestamp DESC;
"
```

**Notify:** Engineering lead, CISO, affected tenants (if confirmed breach)

---

## P0 — Payroll Lock Stuck

Symptom: Payroll run cannot start — "already in progress" error.

```bash
# Check Redis lock
redis-cli KEYS "lock:payroll:*"

# Verify no active payroll run in DB
psql $DATABASE_URL -c "
  SELECT id, tenantId, status, createdAt 
  FROM payroll_runs 
  WHERE status = 'processing';
"

# If process is orphaned (> 30 min, no worker activity):
redis-cli DEL lock:payroll:<tenantId>:<year>:<month>

# Update orphaned run to 'failed'
psql $DATABASE_URL -c "
  UPDATE payroll_runs 
  SET status = 'failed', updatedAt = NOW()
  WHERE status = 'processing' 
    AND updatedAt < NOW() - INTERVAL '30 minutes';
"
```

---

## P1 — API Down

```bash
# Check container status
docker compose -f docker-compose.prod.yml ps

# Check logs
docker compose -f docker-compose.prod.yml logs --tail=100 api

# Common causes:
# 1. Database connection: check DATABASE_URL, RDS security group
# 2. Missing env var: app crashes at boot with descriptive error
# 3. Memory: `docker stats` → check heap

# Restart
docker compose -f docker-compose.prod.yml restart api
```

---

## P1 — Database Connection Failure

```bash
# Test connection directly
psql $DATABASE_URL -c "SELECT 1;"

# Check RDS security group allows EC2 IP on port 5432
# AWS Console → RDS → Security Groups

# Check connection pool exhaustion
psql $DATABASE_URL -c "SELECT COUNT(*) FROM pg_stat_activity;"
# If > 180/200 connections: restart API to reset pool
```

---

## P2 — Tenant Data Corruption

```bash
# Identify affected tenant
psql $DATABASE_URL -c "
  SELECT * FROM audit_logs 
  WHERE tenantId = '<tenant-id>' 
    AND timestamp > NOW() - INTERVAL '1 hour'
  ORDER BY timestamp DESC LIMIT 50;
"

# Restore from point-in-time backup (see BACKUP-RESTORE-GUIDE.md)
# Or revert specific records using audit_logs.oldData
```

---

## P2 — JWT Auth Failures

```bash
# Verify JWT_SECRET hasn't changed
# If changed: all existing tokens are invalid — users must re-login
# This is expected behavior, not a bug

# Clear Redis token blocklist (if tokens are being incorrectly blocked)
redis-cli KEYS "revoked:*" | xargs redis-cli DEL

# Check env validator output at next boot
docker compose logs api | grep -i "jwt\|secret\|env"
```

---

## P3 — Slow Queries

```bash
# Find slow queries
psql $DATABASE_URL -c "
  SELECT query, mean_exec_time, calls
  FROM pg_stat_statements
  ORDER BY mean_exec_time DESC
  LIMIT 10;
"

# Run ANALYZE to refresh query planner statistics
psql $DATABASE_URL -c "ANALYZE employees; ANALYZE payroll_runs;"

# Check for missing indexes — run the performance migration
psql $DATABASE_URL -f migrations/master-audit-indexes-v4.0.0.sql
```

---

## Communication Templates

**Internal (Slack #incidents):**
> [P1] RetroWorks HR API down since HH:MM. Root cause: [X]. ETA: [Y]. @oncall investigating.

**Tenant email (P0/P1):**
> Dear [Tenant], we experienced a service disruption from HH:MM to HH:MM IST. All data is safe. [Brief cause]. We have resolved the issue and taken steps to prevent recurrence. Please contact support if you notice any data discrepancies.
