import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main(): Promise<void> {
  console.log('🌱 Seeding RetroWorks HR — India Demo Company...');

  // ─────────────────────────────────────────────
  // TENANT
  // ─────────────────────────────────────────────
  const tenant = await prisma.tenant.upsert({
    where: { slug: 'acme-india' },
    update: {},
    create: {
      name: 'Acme Technologies Pvt. Ltd.',
      slug: 'acme-india',
      region: 'IN',
      currency: 'INR',
      timezone: 'Asia/Kolkata',
      locale: 'en-IN',
      enabledModules: [
        'ats', 'onboarding', 'core-hr', 'attendance', 'leave',
        'payroll', 'benefits', 'performance', 'lnd', 'expenses',
        'assets', 'helpdesk', 'surveys',
      ],
      subscriptionTier: 'growth',
      settings: {
        theme: { mode: 'dark', enableCrtEffect: true, enableScanlines: true, pixelFont: true },
        payroll: { pfEnabled: true, esiEnabled: true, ptEnabled: true, ptState: 'KA', tdsRegime: 'new', lwfEnabled: false, gratuityEnabled: true },
        attendance: { mode: 'manual', gracePeriodMinutes: 15, halfDayHours: 4, fullDayHours: 8, overTimeEnabled: true, compOffEnabled: true },
        leave: { approvalRequired: true, maxApprovers: 2, allowBackdatedLeave: true, backdatedDays: 3, leaveCalendar: 'working-days' },
        security: { mfaRequired: false, sessionTimeoutMinutes: 480, ssoEnabled: false, biometricEnabled: false, passwordPolicy: { minLength: 8, requireUppercase: true, requireNumbers: true, requireSymbols: false } },
      },
    },
  });
  console.log(`✅ Tenant: ${tenant.name}`);

  const SYSTEM_ID = 'system';

  // ─────────────────────────────────────────────
  // ROLES
  // ─────────────────────────────────────────────
  const adminRole = await prisma.role.upsert({
    where: { tenantId_name: { tenantId: tenant.id, name: 'hr-admin' } },
    update: {},
    create: {
      tenantId: tenant.id,
      name: 'hr-admin',
      description: 'Full HR administrative access',
      isSystem: true,
      permissions: [
        { resource: 'employee', action: 'create' }, { resource: 'employee', action: 'read' },
        { resource: 'employee', action: 'update' }, { resource: 'employee', action: 'delete' },
        { resource: 'leave', action: 'approve' }, { resource: 'payroll', action: 'create' },
        { resource: 'admin', action: 'configure' },
      ],
    },
  });

  const managerRole = await prisma.role.upsert({
    where: { tenantId_name: { tenantId: tenant.id, name: 'manager' } },
    update: {},
    create: {
      tenantId: tenant.id,
      name: 'manager',
      description: 'Team manager — can approve leaves and view team data',
      isSystem: true,
      permissions: [
        { resource: 'employee', action: 'read' }, { resource: 'leave', action: 'approve' },
        { resource: 'attendance', action: 'read' }, { resource: 'performance', action: 'create' },
      ],
    },
  });

  const employeeRole = await prisma.role.upsert({
    where: { tenantId_name: { tenantId: tenant.id, name: 'employee' } },
    update: {},
    create: {
      tenantId: tenant.id,
      name: 'employee',
      description: 'Standard employee access',
      isSystem: true,
      permissions: [
        { resource: 'leave', action: 'create' }, { resource: 'attendance', action: 'create' },
        { resource: 'expense', action: 'create' }, { resource: 'helpdesk', action: 'create' },
      ],
    },
  });
  console.log('✅ Roles created');

  // ─────────────────────────────────────────────
  // LOCATIONS
  // ─────────────────────────────────────────────
  const bangaloreHQ = await prisma.location.upsert({
    where: { tenantId_name: { tenantId: tenant.id, name: 'Bangalore HQ' } },
    update: {},
    create: {
      tenantId: tenant.id,
      name: 'Bangalore HQ',
      address: '100, MG Road, Ashok Nagar',
      city: 'Bengaluru',
      state: 'KA',
      country: 'IN',
      pincode: '560001',
    },
  });

  const mumbaiOffice = await prisma.location.upsert({
    where: { tenantId_name: { tenantId: tenant.id, name: 'Mumbai Office' } },
    update: {},
    create: {
      tenantId: tenant.id,
      name: 'Mumbai Office',
      address: 'BKC, Bandra Kurla Complex',
      city: 'Mumbai',
      state: 'MH',
      country: 'IN',
      pincode: '400051',
    },
  });
  console.log('✅ Locations created');

  // ─────────────────────────────────────────────
  // DEPARTMENTS
  // ─────────────────────────────────────────────
  const departments = await Promise.all([
    prisma.department.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'ENG' } }, update: {}, create: { tenantId: tenant.id, name: 'Engineering', code: 'ENG', createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
    prisma.department.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'HR' } }, update: {}, create: { tenantId: tenant.id, name: 'Human Resources', code: 'HR', createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
    prisma.department.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'FIN' } }, update: {}, create: { tenantId: tenant.id, name: 'Finance', code: 'FIN', createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
    prisma.department.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'MKT' } }, update: {}, create: { tenantId: tenant.id, name: 'Marketing', code: 'MKT', createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
    prisma.department.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'OPS' } }, update: {}, create: { tenantId: tenant.id, name: 'Operations', code: 'OPS', createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
  ]);
  console.log('✅ Departments created');

  // ─────────────────────────────────────────────
  // GRADES
  // ─────────────────────────────────────────────
  const grades = await Promise.all([
    prisma.grade.upsert({ where: { tenantId_name: { tenantId: tenant.id, name: 'L1' } }, update: {}, create: { tenantId: tenant.id, name: 'L1', level: 1, minSalary: 300000, maxSalary: 600000 } }),
    prisma.grade.upsert({ where: { tenantId_name: { tenantId: tenant.id, name: 'L2' } }, update: {}, create: { tenantId: tenant.id, name: 'L2', level: 2, minSalary: 600000, maxSalary: 1200000 } }),
    prisma.grade.upsert({ where: { tenantId_name: { tenantId: tenant.id, name: 'L3' } }, update: {}, create: { tenantId: tenant.id, name: 'L3', level: 3, minSalary: 1200000, maxSalary: 2500000 } }),
    prisma.grade.upsert({ where: { tenantId_name: { tenantId: tenant.id, name: 'L4' } }, update: {}, create: { tenantId: tenant.id, name: 'L4', level: 4, minSalary: 2500000, maxSalary: 5000000 } }),
  ]);

  // ─────────────────────────────────────────────
  // DESIGNATIONS
  // ─────────────────────────────────────────────
  const designations = await Promise.all([
    prisma.designation.upsert({ where: { tenantId_name: { tenantId: tenant.id, name: 'Software Engineer' } }, update: {}, create: { tenantId: tenant.id, name: 'Software Engineer', code: 'SWE', gradeId: grades[1]!.id } }),
    prisma.designation.upsert({ where: { tenantId_name: { tenantId: tenant.id, name: 'Senior Software Engineer' } }, update: {}, create: { tenantId: tenant.id, name: 'Senior Software Engineer', code: 'SSE', gradeId: grades[2]!.id } }),
    prisma.designation.upsert({ where: { tenantId_name: { tenantId: tenant.id, name: 'Engineering Manager' } }, update: {}, create: { tenantId: tenant.id, name: 'Engineering Manager', code: 'EM', gradeId: grades[3]!.id } }),
    prisma.designation.upsert({ where: { tenantId_name: { tenantId: tenant.id, name: 'HR Manager' } }, update: {}, create: { tenantId: tenant.id, name: 'HR Manager', code: 'HRM', gradeId: grades[2]!.id } }),
    prisma.designation.upsert({ where: { tenantId_name: { tenantId: tenant.id, name: 'Product Manager' } }, update: {}, create: { tenantId: tenant.id, name: 'Product Manager', code: 'PM', gradeId: grades[3]!.id } }),
  ]);
  console.log('✅ Grades & Designations created');

  // ─────────────────────────────────────────────
  // ADMIN USER
  // ─────────────────────────────────────────────
  const adminUser = await prisma.user.upsert({
    where: { tenantId_email: { tenantId: tenant.id, email: 'admin@acme.retroworks.local' } },
    update: {},
    create: {
      tenantId: tenant.id,
      email: 'admin@acme.retroworks.local',
      emailVerified: true,
      name: 'HR Admin',
      passwordHash: await bcrypt.hash('Admin@123!', 12),
      isActive: true,
    },
  });
  await prisma.userRole.upsert({
    where: { userId_roleId: { userId: adminUser.id, roleId: adminRole.id } },
    update: {},
    create: { userId: adminUser.id, roleId: adminRole.id },
  });
  console.log('✅ Admin user: admin@acme.retroworks.local / Admin@123!');

  // ─────────────────────────────────────────────
  // LEAVE TYPES (India standard)
  // ─────────────────────────────────────────────
  const leaveTypes = await Promise.all([
    prisma.leaveType.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'CL' } }, update: {}, create: { tenantId: tenant.id, name: 'Casual Leave', code: 'CL', unit: 'days', maxDaysPerYear: 12, carryForwardDays: 0, paidLeave: true, createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
    prisma.leaveType.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'SL' } }, update: {}, create: { tenantId: tenant.id, name: 'Sick Leave', code: 'SL', unit: 'days', maxDaysPerYear: 12, carryForwardDays: 0, paidLeave: true, requiresDocument: true, createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
    prisma.leaveType.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'PL' } }, update: {}, create: { tenantId: tenant.id, name: 'Privilege Leave', code: 'PL', unit: 'days', maxDaysPerYear: 15, carryForwardDays: 15, paidLeave: true, encashable: true, noticeDaysRequired: 2, createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
    prisma.leaveType.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'ML' } }, update: {}, create: { tenantId: tenant.id, name: 'Maternity Leave', code: 'ML', unit: 'days', maxDaysPerYear: 182, paidLeave: true, requiresDocument: true, applicableGenders: ['female'], createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
    prisma.leaveType.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'PaL' } }, update: {}, create: { tenantId: tenant.id, name: 'Paternity Leave', code: 'PaL', unit: 'days', maxDaysPerYear: 15, paidLeave: true, applicableGenders: ['male', 'non-binary'], createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
    prisma.leaveType.upsert({ where: { tenantId_code: { tenantId: tenant.id, code: 'LOP' } }, update: {}, create: { tenantId: tenant.id, name: 'Loss of Pay', code: 'LOP', unit: 'days', maxDaysPerYear: 365, paidLeave: false, createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID } }),
  ]);
  console.log('✅ Leave types created');

  // ─────────────────────────────────────────────
  // PAYROLL GROUP
  // ─────────────────────────────────────────────
  await prisma.payrollGroup.upsert({
    where: { id: `${tenant.id}-monthly-default` },
    update: {},
    create: {
      id: `${tenant.id}-monthly-default`,
      tenantId: tenant.id,
      name: 'Monthly - All Employees',
      payPeriod: 'monthly',
      payDay: 28,
      currency: 'INR',
      components: [
        { id: 'basic', name: 'Basic Salary', code: 'BASIC', type: 'earning', taxable: true, percentOf: 'ctc', percentValue: 40, order: 1 },
        { id: 'hra', name: 'HRA', code: 'HRA', type: 'earning', taxable: false, percentOf: 'basic', percentValue: 50, order: 2 },
        { id: 'conveyance', name: 'Conveyance', code: 'CONV', type: 'earning', taxable: false, fixedAmount: 1600, order: 3 },
        { id: 'medical', name: 'Medical Allowance', code: 'MED', type: 'earning', taxable: false, fixedAmount: 1250, order: 4 },
        { id: 'special', name: 'Special Allowance', code: 'SPEC', type: 'earning', taxable: true, formula: 'CTC - BASIC - HRA - CONV - MED', order: 5 },
        { id: 'pf_emp', name: 'PF (Employee)', code: 'PF_EMP', type: 'deduction', taxable: false, percentOf: 'basic', percentValue: 12, order: 10 },
        { id: 'esi_emp', name: 'ESI (Employee)', code: 'ESI_EMP', type: 'deduction', taxable: false, percentOf: 'gross', percentValue: 0.75, order: 11 },
        { id: 'pt', name: 'Professional Tax', code: 'PT', type: 'deduction', taxable: false, formula: 'PT_SLAB', order: 12 },
        { id: 'tds', name: 'TDS', code: 'TDS', type: 'deduction', taxable: false, formula: 'TDS_COMPUTED', order: 13 },
      ],
      statutoryConfig: {
        pf: { enabled: true, employeeRate: 0.12, employerRate: 0.12, ceilingAmount: 15000, voluntaryPF: false },
        esi: { enabled: true, employeeRate: 0.0075, employerRate: 0.0325, wageLimit: 21000 },
        pt: { enabled: true, state: 'KA', slabs: [{ from: 0, to: 14999, monthlyPt: 0 }, { from: 15000, monthlyPt: 200 }] },
        tds: { enabled: true, regime: 'new' },
        lwf: { enabled: false, state: 'KA' },
        gratuity: { enabled: true, eligibilityYears: 5 },
      },
      createdBy: SYSTEM_ID,
      updatedBy: SYSTEM_ID,
    },
  });
  console.log('✅ Payroll group created');

  // ─────────────────────────────────────────────
  // DEMO EMPLOYEES (10)
  // ─────────────────────────────────────────────
  const demoEmployees = [
    { code: 'EMP001', first: 'Arjun', last: 'Sharma', dept: departments[0]!, desig: designations[0]!, loc: bangaloreHQ },
    { code: 'EMP002', first: 'Priya', last: 'Patel', dept: departments[0]!, desig: designations[1]!, loc: bangaloreHQ },
    { code: 'EMP003', first: 'Rahul', last: 'Nair', dept: departments[0]!, desig: designations[2]!, loc: bangaloreHQ },
    { code: 'EMP004', first: 'Sneha', last: 'Iyer', dept: departments[1]!, desig: designations[3]!, loc: bangaloreHQ },
    { code: 'EMP005', first: 'Vikram', last: 'Reddy', dept: departments[2]!, desig: designations[0]!, loc: mumbaiOffice },
    { code: 'EMP006', first: 'Divya', last: 'Krishnan', dept: departments[3]!, desig: designations[4]!, loc: bangaloreHQ },
    { code: 'EMP007', first: 'Karthik', last: 'Menon', dept: departments[0]!, desig: designations[1]!, loc: mumbaiOffice },
    { code: 'EMP008', first: 'Ananya', last: 'Singh', dept: departments[4]!, desig: designations[0]!, loc: bangaloreHQ },
    { code: 'EMP009', first: 'Rohan', last: 'Gupta', dept: departments[2]!, desig: designations[1]!, loc: bangaloreHQ },
    { code: 'EMP010', first: 'Meera', last: 'Joshi', dept: departments[1]!, desig: designations[3]!, loc: mumbaiOffice },
  ];

  for (const emp of demoEmployees) {
    const workEmail = `${emp.first.toLowerCase()}.${emp.last.toLowerCase()}@acme.retroworks.local`;
    await prisma.employee.upsert({
      where: { tenantId_employeeCode: { tenantId: tenant.id, employeeCode: emp.code } },
      update: {},
      create: {
        tenantId: tenant.id,
        employeeCode: emp.code,
        firstName: emp.first,
        lastName: emp.last,
        email: workEmail,
        workEmail,
        gender: emp.first === 'Priya' || emp.first === 'Sneha' || emp.first === 'Divya' || emp.first === 'Ananya' || emp.first === 'Meera' ? 'female' : 'male',
        dateOfJoining: new Date('2023-01-01'),
        employmentType: 'full-time',
        status: 'active',
        departmentId: emp.dept.id,
        designationId: emp.desig.id,
        locationId: emp.loc.id,
        noticePeriodDays: 60,
        createdBy: SYSTEM_ID,
        updatedBy: SYSTEM_ID,
      },
    });
  }
  console.log(`✅ ${demoEmployees.length} demo employees created`);

  // ─────────────────────────────────────────────
  // NOTIFICATION TEMPLATES
  // ─────────────────────────────────────────────
  const notificationTemplates = [
    {
      name: 'Leave Request Submitted',
      eventKey: 'leave.submitted',
      channels: ['email', 'in-app'],
      subject: 'Leave Request from {{employee.name}} — {{leave.type}}',
      bodyHtml: '<p>{{employee.name}} has submitted a leave request for {{leave.startDate}} to {{leave.endDate}} ({{leave.days}} days).</p><p><a href="{{action.url}}">Review Request →</a></p>',
      tokens: ['{{employee.name}}', '{{leave.type}}', '{{leave.startDate}}', '{{leave.endDate}}', '{{leave.days}}', '{{action.url}}'],
    },
    {
      name: 'Leave Approved',
      eventKey: 'leave.approved',
      channels: ['email', 'in-app'],
      subject: 'Your leave has been approved',
      bodyHtml: '<p>Hi {{employee.name}}, your leave request for {{leave.startDate}} to {{leave.endDate}} has been approved by {{approver.name}}.</p>',
      tokens: ['{{employee.name}}', '{{leave.startDate}}', '{{leave.endDate}}', '{{approver.name}}'],
    },
    {
      name: 'Payslip Published',
      eventKey: 'payslip.published',
      channels: ['email', 'in-app'],
      subject: 'Your payslip for {{period}} is ready',
      bodyHtml: '<p>Hi {{employee.name}}, your payslip for {{period}} is available. Net pay: {{payslip.netPay}}.</p><p><a href="{{action.url}}">View Payslip →</a></p>',
      tokens: ['{{employee.name}}', '{{period}}', '{{payslip.netPay}}', '{{action.url}}'],
    },
    {
      name: 'Magic Link',
      eventKey: 'auth.magic-link',
      channels: ['email'],
      subject: 'Your login link for RetroWorks HR',
      bodyHtml: '<p>Click the button below to sign in to RetroWorks HR. This link expires in 15 minutes.</p><p><a href="{{magic.url}}" style="background:#16a34a;color:#fff;padding:12px 24px;text-decoration:none;font-family:monospace;">[ LOGIN → ]</a></p><p>If you did not request this link, ignore this email.</p>',
      tokens: ['{{magic.url}}'],
    },
  ];

  for (const template of notificationTemplates) {
    await prisma.notificationTemplate.upsert({
      where: { tenantId_eventKey: { tenantId: tenant.id, eventKey: template.eventKey } },
      update: {},
      create: { tenantId: tenant.id, ...template, createdBy: SYSTEM_ID, updatedBy: SYSTEM_ID },
    });
  }
  console.log('✅ Notification templates created');

  // ─────────────────────────────────────────────
  // RAG SEED DOCUMENTS
  // ─────────────────────────────────────────────
  await prisma.ragDocument.upsert({
    where: { id: `${tenant.id}-leave-policy` },
    update: {},
    create: {
      id: `${tenant.id}-leave-policy`,
      tenantId: tenant.id,
      title: 'Leave Policy 2024',
      sourceType: 'policy',
      content: `# Acme Technologies — Leave Policy 2024

## Leave Types
- Casual Leave (CL): 12 days per year, non-carry-forward
- Sick Leave (SL): 12 days per year, medical certificate required for more than 3 consecutive days
- Privilege Leave (PL): 15 days per year, carry-forward up to 15 days, encashable
- Maternity Leave: 182 days (6 months), paid, for female employees
- Paternity Leave: 15 days, paid

## Leave Application Process
1. Apply in the HR portal at least 2 days in advance for PL
2. Your reporting manager receives a notification
3. Manager approves or rejects within 2 working days
4. You receive email and in-app notification

## Public Holidays
Employees are entitled to 14 public holidays per year (8 national + 6 optional).

## Leave Balance
Check your leave balance in the HR portal under Leave → My Balance.`,
      metadata: { version: '2024.1', author: 'HR Team' },
      tags: ['leave', 'policy', 'hr'],
      visibleForRoles: ['employee', 'manager', 'hr-admin'],
      confidential: false,
      createdBy: SYSTEM_ID,
      updatedBy: SYSTEM_ID,
    },
  });
  console.log('✅ RAG seed documents created');

  console.log('\n🎉 Seed complete!');
  console.log('\n📋 Login credentials:');
  console.log('   Email:    admin@acme.retroworks.local');
  console.log('   Password: Admin@123!');
  console.log('   Tenant:   acme-india');
}

main()
  .then(async () => { await prisma.$disconnect(); })
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
