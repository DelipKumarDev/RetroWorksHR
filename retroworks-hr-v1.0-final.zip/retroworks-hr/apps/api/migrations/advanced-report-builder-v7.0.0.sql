-- ─────────────────────────────────────────────────────────────────────────────
-- MIGRATION: advanced-report-builder-v7.0.0.sql
-- Advanced Report Builder — enterprise schema upgrade
-- ─────────────────────────────────────────────────────────────────────────────
-- Upgrades existing saved_reports table.
-- Adds report_versions for version history.
-- Adds covering indexes for all report queries.
-- All tables are tenant-isolated.
-- ─────────────────────────────────────────────────────────────────────────────

-- ── 1. Upgrade saved_reports (add missing enterprise columns) ─────────────

ALTER TABLE saved_reports
  ADD COLUMN IF NOT EXISTS "joinId"           TEXT,
  ADD COLUMN IF NOT EXISTS "filterGroup"      JSONB,
  ADD COLUMN IF NOT EXISTS "groupBy"          TEXT[]   DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS "aggregations"     JSONB    DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS "calculatedFields" JSONB    DEFAULT '[]',
  ADD COLUMN IF NOT EXISTS "sortBy"           TEXT,
  ADD COLUMN IF NOT EXISTS "sortOrder"        TEXT     DEFAULT 'asc',
  ADD COLUMN IF NOT EXISTS "limit"            INTEGER  DEFAULT 500,
  ADD COLUMN IF NOT EXISTS "visibility"       TEXT     DEFAULT 'PRIVATE'
                                              CHECK ("visibility" IN ('PRIVATE', 'SHARED', 'ENTITY')),
  ADD COLUMN IF NOT EXISTS "entityId"         TEXT,
  ADD COLUMN IF NOT EXISTS "allowedRoles"     TEXT[]   DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS "tags"             TEXT[]   DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS "configHash"       TEXT,
  ADD COLUMN IF NOT EXISTS "version"          INTEGER  DEFAULT 1,
  ADD COLUMN IF NOT EXISTS "updatedBy"        TEXT;

-- Migrate old isShared column to new visibility
UPDATE saved_reports
  SET visibility = CASE WHEN "isShared" THEN 'SHARED' ELSE 'PRIVATE' END
  WHERE visibility IS NULL OR visibility = '';

-- ── 2. Report version history ────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS report_versions (
  id            TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  "reportId"    TEXT NOT NULL REFERENCES saved_reports(id) ON DELETE CASCADE,
  "tenantId"    TEXT NOT NULL,
  version       INTEGER NOT NULL,
  config        TEXT NOT NULL,   -- JSON snapshot of full report config
  "configHash"  TEXT NOT NULL,
  "createdBy"   TEXT NOT NULL,
  note          TEXT,
  "createdAt"   TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_report_version UNIQUE ("reportId", version)
);

CREATE INDEX IF NOT EXISTS idx_report_version_tenant
  ON report_versions ("tenantId", "reportId", version DESC);

-- ── 3. Performance indexes ───────────────────────────────────────────────────

-- Report list queries
CREATE INDEX IF NOT EXISTS idx_saved_report_tenant_user
  ON saved_reports ("tenantId", "createdBy", "deletedAt", visibility);

CREATE INDEX IF NOT EXISTS idx_saved_report_tenant_shared
  ON saved_reports ("tenantId", visibility, "deletedAt");

-- GIN index for JSONB scheduled delivery filter
CREATE INDEX IF NOT EXISTS idx_saved_report_scheduled
  ON saved_reports USING GIN ("scheduledDelivery")
  WHERE "deletedAt" IS NULL;

-- ── 4. Report run audit index ────────────────────────────────────────────────
-- (audit_logs table already exists — add partial index for reports)

CREATE INDEX IF NOT EXISTS idx_audit_log_report_action
  ON audit_logs ("tenantId", "resourceType", "resourceId", timestamp DESC)
  WHERE "resourceType" = 'report';

-- ── 5. Comments ──────────────────────────────────────────────────────────────

COMMENT ON TABLE report_versions IS 'Version snapshots of saved report configs — supports rollback';
COMMENT ON COLUMN saved_reports.visibility IS 'PRIVATE=owner only, SHARED=all tenant users, ENTITY=entity-scoped';
COMMENT ON COLUMN saved_reports."configHash" IS 'SHA-256 prefix of report config for change detection';
COMMENT ON COLUMN saved_reports."joinId" IS 'Pre-defined safe join identifier — no raw SQL allowed';
