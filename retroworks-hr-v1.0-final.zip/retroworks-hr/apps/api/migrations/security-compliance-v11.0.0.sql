-- ─────────────────────────────────────────────────────────────────────────────
-- Security & Compliance Pack — Migration v11.0.0
-- RetroWorks HR v1.0
-- ─────────────────────────────────────────────────────────────────────────────
-- New tables:
--   tenant_security_settings   — MFA policy, session timeout per tenant
--   ip_allowlist_rules         — CIDR rules with optional expiry
--   login_history              — immutable login audit log
--   dpdpa_requests             — DPDPA 2023 data request workflow
--   consent_records            — per-employee consent with versioning
--   feature_flags              — global flag definitions
--   tenant_feature_overrides   — per-tenant flag overrides with expiry
--   cron_execution_log         — cron job run history
--   ai_usage_log               — AI token/cost tracking per tenant
--   backup_log                 — DB/storage backup history
-- ─────────────────────────────────────────────────────────────────────────────

BEGIN;

-- ─── Tenant Security Settings ─────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS tenant_security_settings (
  tenant_id                 TEXT PRIMARY KEY REFERENCES tenants(id) ON DELETE CASCADE,
  mfa_enforce_for_roles     TEXT[]  NOT NULL DEFAULT ARRAY['payroll-admin','super-admin'],
  mfa_grace_period_hours    INTEGER NOT NULL DEFAULT 24 CHECK (mfa_grace_period_hours >= 0),
  session_timeout_minutes   INTEGER NOT NULL DEFAULT 480,        -- 8 hours
  max_sessions_per_user     INTEGER NOT NULL DEFAULT 5,
  ip_allowlist_enabled      BOOLEAN NOT NULL DEFAULT FALSE,
  password_policy           JSONB   NOT NULL DEFAULT '{
    "minLength": 10,
    "requireUppercase": true,
    "requireNumber": true,
    "requireSymbol": true,
    "historyCount": 5,
    "maxAgeDays": 90
  }',
  updated_by                TEXT    NOT NULL DEFAULT 'system',
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE tenant_security_settings IS 'Per-tenant security configuration: MFA policy, session limits, password rules';

-- Seed defaults for existing tenants
INSERT INTO tenant_security_settings (tenant_id, updated_by)
SELECT id, 'system' FROM tenants WHERE is_active = TRUE
ON CONFLICT DO NOTHING;

-- ─── IP Allowlist Rules ───────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS ip_allowlist_rules (
  id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  cidr        TEXT NOT NULL,           -- e.g. "203.0.113.0/24"
  label       TEXT NOT NULL,
  added_by    TEXT NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at  TIMESTAMPTZ,             -- NULL = never expires
  deleted_at  TIMESTAMPTZ,             -- soft delete

  CONSTRAINT ip_allowlist_valid_cidr CHECK (
    cidr ~ '^[\d.]+(/\d+)?$' OR cidr ~ '^[\da-fA-F:]+(/\d+)?$'
  )
);

CREATE INDEX IF NOT EXISTS idx_ip_allowlist_tenant_active
  ON ip_allowlist_rules (tenant_id, created_at)
  WHERE deleted_at IS NULL;

-- ─── Login History ────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS login_history (
  id              TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id       TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  user_id         TEXT,                -- NULL for failed attempts with unknown user
  ip              TEXT NOT NULL,
  user_agent      TEXT,
  device_name     TEXT,
  success         BOOLEAN NOT NULL,
  failure_reason  TEXT,                -- 'invalid_password' | 'account_locked' | 'mfa_failed' | 'ip_blocked'
  mfa_used        BOOLEAN NOT NULL DEFAULT FALSE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Partition-friendly: most queries are recent events
CREATE INDEX IF NOT EXISTS idx_login_history_user_recent
  ON login_history (tenant_id, user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_login_history_failed
  ON login_history (tenant_id, created_at DESC)
  WHERE success = FALSE;

-- Retain login history for 1 year (enforced by app-layer cron)
COMMENT ON TABLE login_history IS 'Immutable login audit log. Retained 365 days. Never updated.';

-- Extend sessions table with revocation tracking
DO $$
BEGIN
  ALTER TABLE sessions ADD COLUMN IF NOT EXISTS last_active_at TIMESTAMPTZ;
  ALTER TABLE sessions ADD COLUMN IF NOT EXISTS revoked_at TIMESTAMPTZ;
  ALTER TABLE sessions ADD COLUMN IF NOT EXISTS revoked_by TEXT;
  ALTER TABLE sessions ADD COLUMN IF NOT EXISTS device_fingerprint TEXT;
EXCEPTION WHEN OTHERS THEN NULL;
END $$;

-- ─── DPDPA Requests ───────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS dpdpa_requests (
  id                  TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id           TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  requester_id        TEXT NOT NULL REFERENCES employees(id),
  request_type        TEXT NOT NULL CHECK (request_type IN ('export','deletion','correction')),
  status              TEXT NOT NULL DEFAULT 'pending'
                      CHECK (status IN ('pending','under_review','approved','rejected','completed','expired')),
  reason              TEXT,
  admin_notes         TEXT,
  reviewed_by         TEXT,
  reviewed_at         TIMESTAMPTZ,
  -- Secure download
  download_token      TEXT UNIQUE,         -- 48-char secure random token
  download_expires_at TIMESTAMPTZ,
  download_count      INTEGER NOT NULL DEFAULT 0,
  max_downloads       INTEGER NOT NULL DEFAULT 3,
  -- Legal hold
  is_legal_hold       BOOLEAN NOT NULL DEFAULT FALSE,
  legal_hold_reason   TEXT,
  legal_hold_by       TEXT,
  legal_hold_at       TIMESTAMPTZ,
  -- SLA
  sla_deadline        TIMESTAMPTZ NOT NULL,  -- created_at + 30 days (DPDPA 2023)
  -- Meta
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at        TIMESTAMPTZ,

  CONSTRAINT dpdpa_requests_no_legal_hold_approval
    CHECK (NOT (is_legal_hold = TRUE AND status = 'approved'))
);

COMMENT ON TABLE dpdpa_requests IS 'DPDPA 2023 data request workflow. 30-day SLA enforced by cron. Legal hold blocks processing.';
COMMENT ON COLUMN dpdpa_requests.download_token IS '48-char alphanumeric token. Single-use links with 48h expiry and max 3 downloads.';

CREATE INDEX IF NOT EXISTS idx_dpdpa_tenant_status
  ON dpdpa_requests (tenant_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_dpdpa_sla_breach
  ON dpdpa_requests (sla_deadline)
  WHERE status IN ('pending','under_review');

CREATE INDEX IF NOT EXISTS idx_dpdpa_download_token
  ON dpdpa_requests (download_token)
  WHERE download_token IS NOT NULL;

-- Prevent multiple pending requests of same type per employee
CREATE UNIQUE INDEX IF NOT EXISTS idx_dpdpa_one_pending_per_type
  ON dpdpa_requests (requester_id, request_type)
  WHERE status IN ('pending','under_review');

-- ─── Consent Records ──────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS consent_records (
  id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id        TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id      TEXT NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  consent_type     TEXT NOT NULL,       -- 'payroll_processing' | 'data_sharing' | 'background_check'
  consent_version  TEXT NOT NULL,       -- e.g. "v2.1"
  given_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ip_address       TEXT,
  withdrawn_at     TIMESTAMPTZ,
  withdrawn_reason TEXT,
  is_active        BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE INDEX IF NOT EXISTS idx_consent_employee_type
  ON consent_records (tenant_id, employee_id, consent_type, is_active);

-- ─── Feature Flags ────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS feature_flags (
  id                       TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  key                      TEXT UNIQUE NOT NULL,
  name                     TEXT NOT NULL,
  description              TEXT,
  category                 TEXT NOT NULL DEFAULT 'beta'
                           CHECK (category IN ('beta','experimental','ga','deprecated')),
  default_value            JSONB NOT NULL DEFAULT 'false',
  global_enabled           BOOLEAN NOT NULL DEFAULT TRUE,
  global_value             JSONB,
  rollout_strategy         TEXT NOT NULL DEFAULT 'all'
                           CHECK (rollout_strategy IN ('all','none','percentage','allowlist','denylist')),
  rollout_percentage       INTEGER CHECK (rollout_percentage BETWEEN 0 AND 100),
  allowlist_tenant_ids     TEXT[] DEFAULT '{}',
  denylist_tenant_ids      TEXT[] DEFAULT '{}',
  version                  TEXT,
  deprecated_in_version    TEXT,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE feature_flags IS 'Global feature flag definitions. Evaluated per-tenant using rollout strategy.';

-- ─── Tenant Feature Overrides ─────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS tenant_feature_overrides (
  tenant_id   TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  flag_key    TEXT NOT NULL REFERENCES feature_flags(key) ON DELETE CASCADE,
  enabled     BOOLEAN NOT NULL,
  value       JSONB,
  reason      TEXT NOT NULL,
  set_by      TEXT NOT NULL,
  set_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at  TIMESTAMPTZ,             -- auto-revert after this date

  PRIMARY KEY (tenant_id, flag_key)
);

CREATE INDEX IF NOT EXISTS idx_tenant_overrides_expiry
  ON tenant_feature_overrides (expires_at)
  WHERE expires_at IS NOT NULL;

-- ─── Seed: Built-in feature flags ─────────────────────────────────────────────

INSERT INTO feature_flags (key, name, description, category, global_enabled, rollout_strategy, rollout_percentage, version) VALUES
  ('ai_assistant',            'AI Assistant',             'AI-powered HR assistant for employees',               'beta',         TRUE,  'allowlist',  NULL, '1.1'),
  ('analytics_lab',           'Analytics Lab',            'Advanced analytics workbench for power users',        'beta',         TRUE,  'percentage', 20,   '1.1'),
  ('expression_engine_v2',    'Expression Engine v2',     'Next-generation formula engine with enhanced DSL',    'experimental', FALSE, 'none',       NULL, '1.2'),
  ('multi_entity_payroll',    'Multi-Entity Payroll',     'Run payroll simultaneously across legal entities',    'ga',           TRUE,  'all',        NULL, '1.0'),
  ('pulse_survey',            'Pulse Survey',             '5-question anonymous employee engagement surveys',    'ga',           TRUE,  'all',        NULL, '1.0'),
  ('performance_9box',        'Performance 9-Box Matrix', 'Visual 9-box calibration for talent management',     'ga',           TRUE,  'all',        NULL, '1.0'),
  ('dpdpa_workflow',          'DPDPA Workflow',           'Data subject request management for DPDPA 2023',     'ga',           TRUE,  'all',        NULL, '1.0'),
  ('ip_allowlisting',         'IP Allowlisting',          'Restrict tenant login to specific IP/CIDR ranges',   'ga',           TRUE,  'all',        NULL, '1.0'),
  ('advanced_report_builder', 'Advanced Report Builder',  'Drag-and-drop cross-module report builder',          'beta',         TRUE,  'percentage', 50,   '1.0'),
  ('ai_payslip_insights',     'AI Payslip Insights',      'AI-generated payslip explanations for employees',    'experimental', FALSE, 'allowlist',  NULL, '1.2')
ON CONFLICT (key) DO NOTHING;

-- ─── Monitoring Tables ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS cron_execution_log (
  job_name          TEXT PRIMARY KEY,
  last_run          TIMESTAMPTZ,
  last_status       TEXT NOT NULL DEFAULT 'never'
                    CHECK (last_status IN ('success','failure','running','never')),
  last_duration_ms  INTEGER,
  next_run          TIMESTAMPTZ,
  error_message     TEXT,
  run_count_24h     INTEGER NOT NULL DEFAULT 0,
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Seed known cron jobs
INSERT INTO cron_execution_log (job_name) VALUES
  ('grace-period-enforcement'),
  ('monthly-invoicing'),
  ('seat-count-sync'),
  ('tds-monthly-compute'),
  ('leave-accrual'),
  ('dpdpa-sla-check'),
  ('login-history-cleanup'),
  ('feature-flag-expiry-check'),
  ('backup-verification')
ON CONFLICT (job_name) DO NOTHING;

CREATE TABLE IF NOT EXISTS ai_usage_log (
  id          TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id   TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  feature     TEXT NOT NULL,           -- 'ai_assistant' | 'payslip_insights' | 'report_builder'
  model       TEXT NOT NULL DEFAULT 'claude-sonnet-4-20250514',
  tokens_in   INTEGER NOT NULL DEFAULT 0,
  tokens_out  INTEGER NOT NULL DEFAULT 0,
  latency_ms  INTEGER,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ai_usage_tenant_month
  ON ai_usage_log (tenant_id, date_trunc('month', created_at));

CREATE TABLE IF NOT EXISTS backup_log (
  id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  backup_type      TEXT NOT NULL DEFAULT 'full' CHECK (backup_type IN ('full','incremental','wal')),
  status           TEXT NOT NULL CHECK (status IN ('running','success','failure')),
  started_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at     TIMESTAMPTZ,
  size_bytes       BIGINT,
  storage_location TEXT,               -- 's3' | 'gcs' | 'local'
  storage_path     TEXT,
  error_message    TEXT
);

-- ─── Views ────────────────────────────────────────────────────────────────────

-- DPDPA SLA dashboard
CREATE OR REPLACE VIEW v_dpdpa_sla AS
SELECT
  r.*,
  e.first_name || ' ' || e.last_name AS requester_name,
  e.employee_code,
  CEIL(EXTRACT(EPOCH FROM (r.sla_deadline - NOW())) / 86400)::INT AS days_until_sla,
  r.sla_deadline < NOW() AND r.status IN ('pending','under_review') AS is_overdue
FROM dpdpa_requests r
JOIN employees e ON e.id = r.requester_id
ORDER BY r.sla_deadline ASC;

-- Active sessions per tenant
CREATE OR REPLACE VIEW v_active_sessions AS
SELECT
  u.tenant_id,
  COUNT(*) AS active_session_count,
  COUNT(*) FILTER (WHERE s.created_at > NOW() - INTERVAL '1 hour') AS sessions_last_hour
FROM sessions s
JOIN users u ON u.id = s.user_id
WHERE s.revoked_at IS NULL AND s.expires_at > NOW()
GROUP BY u.tenant_id;

-- ─── Triggers ─────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['feature_flags','cron_execution_log','tenant_security_settings']
  LOOP
    IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = t || '_updated_at') THEN
      EXECUTE format(
        'CREATE TRIGGER %I BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION set_updated_at()',
        t || '_updated_at', t
      );
    END IF;
  END LOOP;
END $$;

-- ─── Row-Level Security: login_history is insert-only ────────────────────────

-- Login history should never be UPDATE'd or DELETE'd (audit integrity)
CREATE OR REPLACE RULE login_history_no_update AS ON UPDATE TO login_history DO INSTEAD NOTHING;
CREATE OR REPLACE RULE login_history_no_delete AS ON DELETE TO login_history DO INSTEAD NOTHING;

COMMIT;
