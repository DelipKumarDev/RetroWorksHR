-- ═══════════════════════════════════════════════════════════════════════════
-- RetroWorks HR — Security Sprint Migration
-- Version: 20240201_security_sprint
-- Applies: C-04 (payroll unique constraint) + H-07 (SLA indexes) +
--          H-10 (N+1 optimization indexes) + M-05 (audit log protection)
-- Run: psql $DATABASE_URL -f migrations/20240201_security_sprint.sql
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─── Metadata ────────────────────────────────────────────────────────────────
DO $$ BEGIN
  RAISE NOTICE 'Starting Security Sprint migration...';
END $$;

-- ═══════════════════════════════════════════════════════════════════════════
-- C-04: Prevent duplicate payroll runs at DB level
-- This is the safety net if Redis lock is unavailable
-- ═══════════════════════════════════════════════════════════════════════════

-- Only one non-cancelled payroll run per tenant/month/year
-- Using a partial unique index — allows multiple cancelled runs (for retry tracking)
CREATE UNIQUE INDEX IF NOT EXISTS
  uidx_payroll_run_tenant_month_year_active
  ON "PayrollRun" ("tenantId", "month", "year")
  WHERE status NOT IN ('cancelled', 'failed');

DO $$ BEGIN
  RAISE NOTICE 'C-04: Payroll run unique constraint added';
END $$;

-- ═══════════════════════════════════════════════════════════════════════════
-- H-07: SLA cron optimization — composite indexes for batch queries
-- ═══════════════════════════════════════════════════════════════════════════

-- Primary SLA monitoring index (status + slaBreached + slaResolutionDue)
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_ticket_sla_monitor
  ON "Ticket" ("status", "slaBreached", "slaResolutionDue")
  WHERE "deletedAt" IS NULL AND "status" NOT IN ('resolved', 'closed');

-- Tenant-scoped ticket queries
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_ticket_tenant_status
  ON "Ticket" ("tenantId", "status", "createdAt" DESC)
  WHERE "deletedAt" IS NULL;

-- SLA due dates — used by cron every 5 minutes
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_ticket_sla_response_due
  ON "Ticket" ("slaResponseDue", "firstResponseAt")
  WHERE "deletedAt" IS NULL AND "firstResponseAt" IS NULL AND "slaBreached" = false;

CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_ticket_sla_resolution_due
  ON "Ticket" ("slaResolutionDue")
  WHERE "deletedAt" IS NULL AND "slaBreached" = false;

DO $$ BEGIN
  RAISE NOTICE 'H-07: SLA cron indexes created';
END $$;

-- ═══════════════════════════════════════════════════════════════════════════
-- H-10: N+1 fix indexes — employee, payslip, leave queries
-- ═══════════════════════════════════════════════════════════════════════════

-- Payslip queries (payroll engine, insights)
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_payslip_tenant_year_month
  ON "Payslip" ("tenantId", "year", "month")
  WHERE "status" != 'cancelled';

CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_payslip_employee_year_month
  ON "Payslip" ("employeeId", "year", "month")
  WHERE "status" != 'cancelled';

-- Employee active roster queries
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_employee_tenant_status_active
  ON "Employee" ("tenantId", "status")
  WHERE "deletedAt" IS NULL AND "status" = 'active';

-- Leave requests — used heavily by insights
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_leave_tenant_status_dates
  ON "LeaveRequest" ("tenantId", "status", "startDate", "endDate")
  WHERE "deletedAt" IS NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_leave_employee_year
  ON "LeaveRequest" ("employeeId", "startDate")
  WHERE "status" IN ('approved', 'auto-approved');

-- Attendance records
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_attendance_tenant_date
  ON "AttendanceRecord" ("tenantId", "date" DESC)
  WHERE "deletedAt" IS NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_attendance_employee_date
  ON "AttendanceRecord" ("employeeId", "date" DESC);

-- Performance reviews
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_perf_review_employee_created
  ON "PerformanceReview" ("employeeId", "createdAt" DESC);

DO $$ BEGIN
  RAISE NOTICE 'H-10: N+1 optimization indexes created';
END $$;

-- ═══════════════════════════════════════════════════════════════════════════
-- C-02: Tenant isolation — ensure all tables have tenantId indexed
-- ═══════════════════════════════════════════════════════════════════════════

-- Notification queries
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_notification_tenant_user_read
  ON "Notification" ("tenantId", "userId", "isRead")
  WHERE "deletedAt" IS NULL;

-- Audit log — append-optimized
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_audit_tenant_created
  ON "AuditLog" ("tenantId", "createdAt" DESC);

CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_audit_resource
  ON "AuditLog" ("tenantId", "resource", "resourceId");

-- Sessions — for refresh token validation
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_session_refresh_token
  ON "Session" ("refreshToken")
  WHERE "expiresAt" > NOW();

CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_session_user_active
  ON "Session" ("userId", "expiresAt");

-- SLA Events (case engine)
CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_sla_event_tenant_type
  ON "SLAEvent" ("tenantId", "eventType", "triggeredAt" DESC);

DO $$ BEGIN
  RAISE NOTICE 'C-02: Tenant isolation indexes created';
END $$;

-- ═══════════════════════════════════════════════════════════════════════════
-- M-05: Audit Log Immutability (DB-level trigger)
-- Prevents UPDATE/DELETE on audit log entries
-- ═══════════════════════════════════════════════════════════════════════════

-- Function to block modifications
CREATE OR REPLACE FUNCTION prevent_audit_log_modification()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Audit log entries are immutable. Modification of audit records is prohibited. '
    'TenantId: %, ResourceId: %', OLD."tenantId", OLD."resourceId";
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger on UPDATE
DROP TRIGGER IF EXISTS trg_audit_no_update ON "AuditLog";
CREATE TRIGGER trg_audit_no_update
  BEFORE UPDATE ON "AuditLog"
  FOR EACH ROW EXECUTE FUNCTION prevent_audit_log_modification();

-- Trigger on DELETE  
DROP TRIGGER IF EXISTS trg_audit_no_delete ON "AuditLog";
CREATE TRIGGER trg_audit_no_delete
  BEFORE DELETE ON "AuditLog"
  FOR EACH ROW EXECUTE FUNCTION prevent_audit_log_modification();

DO $$ BEGIN
  RAISE NOTICE 'M-05: Audit log immutability triggers created';
END $$;

-- ═══════════════════════════════════════════════════════════════════════════
-- Additional: PayrollAdjustment index for monthly queries
-- ═══════════════════════════════════════════════════════════════════════════

CREATE INDEX CONCURRENTLY IF NOT EXISTS
  idx_payroll_adjustment_tenant_employee_month
  ON "PayrollAdjustment" ("tenantId", "employeeId", "month", "year")
  WHERE "applied" = false;

-- ─── Migration record ────────────────────────────────────────────────────────
DO $$ BEGIN
  INSERT INTO "MigrationLog" ("version", "name", "appliedAt", "appliedBy")
  VALUES (
    '20240201_security_sprint',
    'Security Fix Sprint — C-04 payroll lock, H-07 SLA indexes, H-10 N+1 indexes, M-05 audit immutability',
    NOW(),
    'migration-script'
  )
  ON CONFLICT ("version") DO NOTHING;
EXCEPTION WHEN undefined_table THEN
  -- MigrationLog table may not exist in all environments
  RAISE NOTICE 'MigrationLog table not found — skipping migration record';
END $$;

COMMIT;

DO $$ BEGIN
  RAISE NOTICE '✅ Security Sprint migration completed successfully';
  RAISE NOTICE 'Indexes created (non-blocking CONCURRENTLY):';
  RAISE NOTICE '  - uidx_payroll_run_tenant_month_year_active (C-04)';
  RAISE NOTICE '  - idx_ticket_sla_monitor (H-07)';
  RAISE NOTICE '  - idx_ticket_tenant_status (C-02)';
  RAISE NOTICE '  - idx_payslip_tenant_year_month (H-10)';
  RAISE NOTICE '  - idx_employee_tenant_status_active (H-10)';
  RAISE NOTICE '  - idx_leave_tenant_status_dates (H-10)';
  RAISE NOTICE '  - trg_audit_no_update, trg_audit_no_delete (M-05)';
END $$;
