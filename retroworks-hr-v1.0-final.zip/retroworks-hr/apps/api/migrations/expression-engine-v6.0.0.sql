-- ─────────────────────────────────────────────────────────────────────────────
-- MIGRATION: expression-engine-v6.0.0.sql
-- Phase 2B: Payroll Expression Engine
-- ─────────────────────────────────────────────────────────────────────────────
-- Creates pay_components and pay_component_versions tables.
-- Adds formulaGraphHash to payroll_runs for audit trail.
-- Tenant-isolated: all tables include tenantId.
-- ─────────────────────────────────────────────────────────────────────────────

-- ── Pay Component definitions ──────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS pay_components (
  id                  TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  "tenantId"          TEXT NOT NULL,
  code                TEXT NOT NULL,
  name                TEXT NOT NULL,
  type                TEXT NOT NULL CHECK (type IN ('FIXED', 'FORMULA', 'STATUTORY')),
  formula             TEXT,
  version             INTEGER NOT NULL DEFAULT 1,
  "isActive"          BOOLEAN NOT NULL DEFAULT TRUE,
  "isTaxable"         BOOLEAN NOT NULL DEFAULT TRUE,
  "isDeduction"       BOOLEAN NOT NULL DEFAULT FALSE,
  "roundingRule"      TEXT NOT NULL DEFAULT 'ROUND' CHECK ("roundingRule" IN ('NONE', 'ROUND', 'FLOOR', 'CEIL')),
  "canOverrideBasic"  BOOLEAN NOT NULL DEFAULT FALSE,
  "maxValue"          NUMERIC(12,2),
  "minValue"          NUMERIC(12,2),
  description         TEXT,
  "isLocked"          BOOLEAN NOT NULL DEFAULT FALSE,  -- locked after payroll run
  "createdAt"         TIMESTAMPTZ NOT NULL DEFAULT now(),
  "updatedAt"         TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_pay_component_tenant_code UNIQUE ("tenantId", code)
);

CREATE INDEX IF NOT EXISTS idx_pay_component_tenant
  ON pay_components ("tenantId", "isActive");

-- ── Pay Component version snapshots ───────────────────────────────────────

CREATE TABLE IF NOT EXISTS pay_component_versions (
  id              TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  "componentId"   TEXT NOT NULL REFERENCES pay_components(id) ON DELETE CASCADE,
  "tenantId"      TEXT NOT NULL,  -- denormalized for tenant-scoped queries
  formula         TEXT NOT NULL,
  version         INTEGER NOT NULL,
  "changedBy"     TEXT NOT NULL,
  "changeNote"    TEXT,
  "formulaHash"   TEXT NOT NULL,
  "createdAt"     TIMESTAMPTZ NOT NULL DEFAULT now(),

  CONSTRAINT uq_pay_component_version UNIQUE ("componentId", version)
);

CREATE INDEX IF NOT EXISTS idx_pay_component_version_tenant
  ON pay_component_versions ("tenantId", "componentId", version DESC);

-- ── Add formulaGraphHash to payroll_runs ──────────────────────────────────

ALTER TABLE payroll_runs
  ADD COLUMN IF NOT EXISTS "formulaGraphHash" TEXT;

ALTER TABLE payroll_runs
  ADD COLUMN IF NOT EXISTS "componentVersionSnapshot" JSONB;

-- ── Seed standard components for every new tenant ─────────────────────────
-- (Production seed handled by prisma/seed.ts — this migration adds the schema only)

-- ── Verify ────────────────────────────────────────────────────────────────
-- SELECT count(*) FROM pay_components;
-- SELECT count(*) FROM pay_component_versions;
-- SELECT column_name FROM information_schema.columns WHERE table_name = 'payroll_runs' AND column_name = 'formulaGraphHash';
