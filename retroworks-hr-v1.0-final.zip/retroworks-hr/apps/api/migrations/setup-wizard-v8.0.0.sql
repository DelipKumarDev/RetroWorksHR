-- ─────────────────────────────────────────────────────────────────────────────
-- Smart Onboarding Wizard + Config Validator — Migration v8.0.0
-- ─────────────────────────────────────────────────────────────────────────────
-- New tables:
--   legal_entities           — multi-entity with statutory registrations
--   worker_categories        — PF/ESI applicability per category
--   wizard_sessions          — step-by-step wizard state per tenant
--   tenant_health_snapshots  — time-series health score history
--   migration_jobs           — CSV import job tracking with rollback
--   config_issues            — persisted validator findings
--
-- Indexes optimised for:
--   - Nightly health scan (tenantId + computedAt)
--   - Fix-now dashboard (tenantId + severity + resolvedAt)
--   - Migration job status polling (tenantId + status)
-- ─────────────────────────────────────────────────────────────────────────────

BEGIN;

-- ─── Legal Entities ──────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS legal_entities (
  id                      TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id               TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name                    TEXT NOT NULL,
  cin                     TEXT,                          -- Corporate Identification Number
  pan                     TEXT NOT NULL,                 -- Mandatory for all entities
  tan                     TEXT,                          -- Required for TDS filing
  gst_number              TEXT,
  pf_registration_number  TEXT,
  esi_registration_number TEXT,
  pt_registration_number  TEXT,
  state_code              TEXT NOT NULL DEFAULT 'Maharashtra',
  bank_account_number     TEXT,
  bank_ifsc               TEXT,
  bank_name               TEXT,
  is_headquarters         BOOLEAN NOT NULL DEFAULT FALSE,
  is_active               BOOLEAN NOT NULL DEFAULT TRUE,
  created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  deleted_at              TIMESTAMPTZ,

  CONSTRAINT legal_entities_tenant_name_key UNIQUE (tenant_id, name),
  CONSTRAINT legal_entities_pan_format CHECK (pan ~ '^[A-Z]{5}[0-9]{4}[A-Z]$'),
  CONSTRAINT legal_entities_tan_format CHECK (tan IS NULL OR tan ~ '^[A-Z]{4}[0-9]{5}[A-Z]$'),
  CONSTRAINT legal_entities_ifsc_format CHECK (bank_ifsc IS NULL OR bank_ifsc ~ '^[A-Z]{4}0[A-Z0-9]{6}$')
);

COMMENT ON TABLE legal_entities IS 'Company legal entities with statutory registration numbers per tenant';

-- ─── Worker Categories ───────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS worker_categories (
  id                   TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id            TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  code                 TEXT NOT NULL,
  name                 TEXT NOT NULL,
  apply_pf             BOOLEAN NOT NULL DEFAULT TRUE,
  apply_esi            BOOLEAN NOT NULL DEFAULT FALSE,
  is_contract_worker   BOOLEAN NOT NULL DEFAULT FALSE,
  description          TEXT,
  is_active            BOOLEAN NOT NULL DEFAULT TRUE,
  created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT worker_categories_tenant_code_key UNIQUE (tenant_id, code)
);

COMMENT ON TABLE worker_categories IS 'Worker categories controlling PF/ESI applicability per employee type';

-- Link employees to worker categories (nullable until configured)
ALTER TABLE employees
  ADD COLUMN IF NOT EXISTS worker_category_id TEXT REFERENCES worker_categories(id) ON DELETE SET NULL;

-- ─── Wizard Sessions ─────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS wizard_sessions (
  id                TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id         TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  current_step      TEXT NOT NULL DEFAULT 'company_profile',
  completed_steps   TEXT[] NOT NULL DEFAULT '{}',
  industry_preset   TEXT,                                -- it_services | manufacturing | school | startup | consulting
  state_json        JSONB NOT NULL DEFAULT '{}',         -- Full serialised WizardState
  is_complete       BOOLEAN NOT NULL DEFAULT FALSE,
  started_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  completed_at      TIMESTAMPTZ,
  started_by        TEXT,                                -- userId
  last_updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT wizard_sessions_tenant_key UNIQUE (tenant_id)   -- One active session per tenant
);

COMMENT ON TABLE wizard_sessions IS 'Persisted setup wizard state — one row per tenant, upserted on each step save';

-- ─── Tenant Health Snapshots ─────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS tenant_health_snapshots (
  id              TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id       TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  overall_score   SMALLINT NOT NULL CHECK (overall_score BETWEEN 0 AND 100),
  status          TEXT NOT NULL CHECK (status IN ('HEALTHY', 'ATTENTION', 'ACTION_REQUIRED')),
  dimensions      JSONB NOT NULL DEFAULT '{}',
  checks_run      SMALLINT NOT NULL DEFAULT 0,
  critical_count  SMALLINT NOT NULL DEFAULT 0,
  high_count      SMALLINT NOT NULL DEFAULT 0,
  medium_count    SMALLINT NOT NULL DEFAULT 0,
  low_count       SMALLINT NOT NULL DEFAULT 0,
  computed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  triggered_by    TEXT NOT NULL DEFAULT 'cron'       -- 'cron' | 'manual' | 'wizard_complete'
);

COMMENT ON TABLE tenant_health_snapshots IS 'Time-series health score history for trend analysis';

-- ─── Config Issues ────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS config_issues (
  id               TEXT NOT NULL,                    -- Deterministic check ID e.g. STAT_001_PF_REG
  tenant_id        TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  severity         TEXT NOT NULL CHECK (severity IN ('CRITICAL','HIGH','MEDIUM','LOW','INFO')),
  category         TEXT NOT NULL,
  title            TEXT NOT NULL,
  description      TEXT NOT NULL,
  recommendation   TEXT NOT NULL,
  affected_module  TEXT NOT NULL,
  can_auto_fix     BOOLEAN NOT NULL DEFAULT FALSE,
  fix_route        TEXT,
  detected_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at      TIMESTAMPTZ,
  suppressed_until TIMESTAMPTZ,                      -- For snoozing low-priority issues
  suppressed_by    TEXT,

  PRIMARY KEY (tenant_id, id),
  CONSTRAINT config_issues_severity_check CHECK (severity IN ('CRITICAL','HIGH','MEDIUM','LOW','INFO'))
);

COMMENT ON TABLE config_issues IS 'Persisted config validator findings — upserted on each scan, resolved_at set when fixed';

-- ─── Migration Jobs ───────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS migration_jobs (
  id               TEXT PRIMARY KEY,
  tenant_id        TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  entity           TEXT NOT NULL CHECK (entity IN ('employees','departments','designations','leaves','salary_structures')),
  status           TEXT NOT NULL DEFAULT 'PENDING'
                   CHECK (status IN ('PENDING','VALIDATING','DRY_RUN','RUNNING','COMPLETE','FAILED','ROLLED_BACK')),
  total_rows       INTEGER NOT NULL DEFAULT 0,
  processed_rows   INTEGER NOT NULL DEFAULT 0,
  success_rows     INTEGER NOT NULL DEFAULT 0,
  failed_rows      INTEGER NOT NULL DEFAULT 0,
  column_mappings  JSONB NOT NULL DEFAULT '[]',
  errors_json      JSONB NOT NULL DEFAULT '[]',      -- Array of {row, error}
  rollback_data    TEXT,                             -- JSON snapshot for undo (compressed)
  dry_run_result   JSONB,                            -- Summary from dry-run phase
  started_at       TIMESTAMPTZ,
  completed_at     TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_by       TEXT NOT NULL,
  notes            TEXT
);

COMMENT ON TABLE migration_jobs IS 'CSV import job lifecycle tracking with rollback support';

-- ─── Indexes ──────────────────────────────────────────────────────────────────

-- Legal entities
CREATE INDEX IF NOT EXISTS idx_legal_entities_tenant
  ON legal_entities (tenant_id, is_active)
  WHERE deleted_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_legal_entities_pan
  ON legal_entities (pan)
  WHERE deleted_at IS NULL;

-- Worker categories
CREATE INDEX IF NOT EXISTS idx_worker_categories_tenant
  ON worker_categories (tenant_id, is_active);

-- Employees → worker category join
CREATE INDEX IF NOT EXISTS idx_employees_worker_category
  ON employees (tenant_id, worker_category_id)
  WHERE deleted_at IS NULL;

-- Wizard sessions
CREATE INDEX IF NOT EXISTS idx_wizard_sessions_tenant
  ON wizard_sessions (tenant_id, is_complete);

-- Health snapshots — for trend queries (last 90 days)
CREATE INDEX IF NOT EXISTS idx_health_snapshots_tenant_time
  ON tenant_health_snapshots (tenant_id, computed_at DESC);

CREATE INDEX IF NOT EXISTS idx_health_snapshots_status
  ON tenant_health_snapshots (tenant_id, status, computed_at DESC);

-- Config issues — Fix-Now dashboard query
CREATE INDEX IF NOT EXISTS idx_config_issues_active
  ON config_issues (tenant_id, severity, detected_at DESC)
  WHERE resolved_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_config_issues_category
  ON config_issues (tenant_id, category)
  WHERE resolved_at IS NULL;

-- Migration jobs — status polling
CREATE INDEX IF NOT EXISTS idx_migration_jobs_tenant_status
  ON migration_jobs (tenant_id, status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_migration_jobs_entity
  ON migration_jobs (tenant_id, entity, created_at DESC);

-- ─── Views ────────────────────────────────────────────────────────────────────

-- Latest health score per tenant (used by dashboard widget)
CREATE OR REPLACE VIEW v_tenant_health_latest AS
SELECT DISTINCT ON (tenant_id)
  tenant_id,
  overall_score,
  status,
  dimensions,
  critical_count,
  high_count,
  medium_count,
  computed_at
FROM tenant_health_snapshots
ORDER BY tenant_id, computed_at DESC;

COMMENT ON VIEW v_tenant_health_latest IS 'Latest health snapshot per tenant — used by dashboard health widget';

-- Active config issues summary (for Fix-Now panel)
CREATE OR REPLACE VIEW v_config_issues_active AS
SELECT
  tenant_id,
  severity,
  COUNT(*)                                              AS issue_count,
  ARRAY_AGG(id ORDER BY detected_at DESC)               AS issue_ids,
  MIN(detected_at)                                      AS oldest_issue,
  MAX(detected_at)                                      AS newest_issue
FROM config_issues
WHERE resolved_at IS NULL
  AND (suppressed_until IS NULL OR suppressed_until < NOW())
GROUP BY tenant_id, severity;

COMMENT ON VIEW v_config_issues_active IS 'Active unresolved config issues grouped by severity — for Fix-Now panel';

-- ─── Update trigger for updated_at ───────────────────────────────────────────

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'legal_entities_updated_at') THEN
    CREATE TRIGGER legal_entities_updated_at
      BEFORE UPDATE ON legal_entities
      FOR EACH ROW EXECUTE FUNCTION set_updated_at();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'worker_categories_updated_at') THEN
    CREATE TRIGGER worker_categories_updated_at
      BEFORE UPDATE ON worker_categories
      FOR EACH ROW EXECUTE FUNCTION set_updated_at();
  END IF;
END $$;

-- ─── Seed: default worker categories for existing tenants ────────────────────

-- Only inserts if tenant has employees but no worker categories yet
INSERT INTO worker_categories (tenant_id, code, name, apply_pf, apply_esi, is_contract_worker)
SELECT DISTINCT
  e.tenant_id,
  'regular',
  'Regular Employee',
  TRUE,
  FALSE,
  FALSE
FROM employees e
LEFT JOIN worker_categories wc ON wc.tenant_id = e.tenant_id AND wc.code = 'regular'
WHERE wc.id IS NULL
ON CONFLICT (tenant_id, code) DO NOTHING;

COMMIT;

-- ─── Rollback script (save for emergencies) ───────────────────────────────────
-- BEGIN;
-- ALTER TABLE employees DROP COLUMN IF EXISTS worker_category_id;
-- DROP TABLE IF EXISTS migration_jobs CASCADE;
-- DROP TABLE IF EXISTS config_issues CASCADE;
-- DROP TABLE IF EXISTS tenant_health_snapshots CASCADE;
-- DROP TABLE IF EXISTS wizard_sessions CASCADE;
-- DROP TABLE IF EXISTS worker_categories CASCADE;
-- DROP TABLE IF EXISTS legal_entities CASCADE;
-- DROP VIEW IF EXISTS v_config_issues_active;
-- DROP VIEW IF EXISTS v_tenant_health_latest;
-- COMMIT;
