-- ─────────────────────────────────────────────────────────────────────────────
-- MIGRATION: analytics-indexes-v5.0.0.sql
-- Phase 2: CFO Dashboard + Payroll Audit covering indexes
-- ─────────────────────────────────────────────────────────────────────────────
-- These indexes make aggregate queries on payslips fast at scale.
-- No schema changes — indexes only.
-- Safe to run on live database (CONCURRENTLY where supported).
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Payslip aggregate queries: tenantId + month + year + status
-- Powers: cost summary, department breakdown, audit scan
CREATE INDEX IF NOT EXISTS idx_payslip_tenant_period_status
  ON payslips ("tenantId", year, month, status)
  INCLUDE ("grossPay", "netPay", "tdsDeducted", "pfEmployee", "pfEmployer",
           "pfEps", "pfEpf", "esiEmployee", "esiEmployer", "professionalTax");

-- 2. Payslip groupBy departmentId — CFO department breakdown
CREATE INDEX IF NOT EXISTS idx_payslip_dept_period
  ON payslips ("tenantId", "departmentId", year, month)
  INCLUDE ("grossPay", "netPay", "pfEmployer", "esiEmployer");

-- 3. Employee join date — headcount trend (joiners per month)
CREATE INDEX IF NOT EXISTS idx_employee_join_date_tenant
  ON employees ("tenantId", "joinDate", status)
  WHERE "deletedAt" IS NULL;

-- 4. Leave balance — liability projection (tenantId + year)
CREATE INDEX IF NOT EXISTS idx_leave_balance_tenant_year_encashable
  ON leave_balances ("tenantId", year, "leaveTypeId")
  INCLUDE ("employeeId", allocated, "usedDays", "pendingDays", "carryForward", "encashedDays");

-- 5. Salary structure — revision simulator (tenantId + employeeId)
CREATE INDEX IF NOT EXISTS idx_salary_structure_tenant_employee
  ON salary_structures ("tenantId", "employeeId")
  INCLUDE ("basicSalary", hra, "specialAllowance", lta, "medicalAllowance", "otherAllowances");

-- 6. Payroll run — duplicate detection (tenantId + payrollGroupId + period)
-- Note: unique constraint already exists on these columns (from Part 2 migration)
-- This partial index speeds up the EXISTS check in audit
CREATE INDEX IF NOT EXISTS idx_payroll_run_period_status
  ON payroll_runs ("tenantId", "payrollGroupId", period, status)
  WHERE status != 'REVERSED';

-- 7. TDS projection — statutory forecast
CREATE INDEX IF NOT EXISTS idx_tds_projection_tenant_fy
  ON tds_projections ("tenantId", "financialYear", "employeeId")
  INCLUDE ("projectedAnnualTax", "totalDeductions");

-- 8. Audit log — CFO report history lookup
CREATE INDEX IF NOT EXISTS idx_audit_log_action_tenant
  ON audit_logs ("tenantId", action, timestamp DESC)
  WHERE action = 'payroll_audit_report_generated';

-- ─────────────────────────────────────────────────────────────────────────────
-- VERIFY: run EXPLAIN ANALYZE on the main aggregate queries to confirm index usage
-- Example:
--   EXPLAIN ANALYZE
--   SELECT SUM("grossPay"), SUM("pfEmployer"), COUNT(*)
--   FROM payslips
--   WHERE "tenantId" = 'tenant-x' AND year = 2024 AND month = 12 AND status != 'REVERSED';
-- ─────────────────────────────────────────────────────────────────────────────
