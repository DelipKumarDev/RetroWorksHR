-- ═══════════════════════════════════════════════════════════════════════════
-- RetroWorks HR — Salary Revision, Arrears & Section 89 Migration
-- Version: 3.4.0-arrears-section89
-- Legal basis:
--   Section 89(1), Income Tax Act 1961
--   Rule 21A, Income Tax Rules 1962
--   Form 10E — CBDT Circular No. 13/2017
--
-- Apply:  psql $DATABASE_URL -f migrations/arrears-section89-v3.4.0.sql
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─── 1. Salary Revision Records ──────────────────────────────────────────────
-- Master record for each salary revision event.
-- Status flow: pending → processed → arrear_payslip_generated → disbursed

CREATE TABLE IF NOT EXISTS "salary_revisions" (
  "id"                          TEXT           NOT NULL,
  "tenantId"                    TEXT           NOT NULL,
  "employeeId"                  TEXT           NOT NULL,
  "effectiveFrom"               DATE           NOT NULL,
  "revisionAnnouncedDate"       DATE           NOT NULL,
  "financialYear"               TEXT           NOT NULL,
  "reason"                      TEXT           NOT NULL DEFAULT '',
  "approvedBy"                  TEXT           NOT NULL DEFAULT '',

  -- Old salary structure
  "oldMonthlyBasic"             DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "oldMonthlyHRA"               DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "oldMonthlySpecialAllowance"  DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "oldMonthlyOtherAllowances"   DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "oldMonthlyGross"             DECIMAL(12,2)  NOT NULL DEFAULT 0,

  -- New salary structure
  "newMonthlyBasic"             DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "newMonthlyHRA"               DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "newMonthlySpecialAllowance"  DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "newMonthlyOtherAllowances"   DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "newMonthlyGross"             DECIMAL(12,2)  NOT NULL DEFAULT 0,

  -- Computed outputs (set after processing)
  "totalArrearAmount"           DECIMAL(14,2),
  "section89ReliefAmount"       DECIMAL(12,2),
  "revisedMonthlyTds"           DECIMAL(10,2),
  "arrearData"                  JSONB,           -- Full ArrearsComputationResult
  "form10EData"                 JSONB,           -- Form10EComputation
  "revisedTdsSchedule"          JSONB,           -- RevisedTdsSchedule

  -- Lifecycle
  "status"                      TEXT           NOT NULL DEFAULT 'pending',
  "createdBy"                   TEXT           NOT NULL,
  "processedBy"                 TEXT,
  "processedAt"                 TIMESTAMPTZ,
  "disbursedAt"                 TIMESTAMPTZ,
  "createdAt"                   TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  "updatedAt"                   TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

  CONSTRAINT "salary_revision_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "salary_revision_emp_date_key"
    UNIQUE ("tenantId", "employeeId", "effectiveFrom"),
  CONSTRAINT "salary_revision_status_check"
    CHECK ("status" IN (
      'pending', 'processed', 'arrear_payslip_generated',
      'disbursed', 'cancelled'
    )),
  CONSTRAINT "salary_revision_dates_check"
    CHECK ("effectiveFrom" <= "revisionAnnouncedDate"),
  CONSTRAINT "salary_revision_gross_check"
    CHECK ("newMonthlyGross" >= 0 AND "oldMonthlyGross" >= 0)
);

-- Prevent modification of disbursed revisions
CREATE OR REPLACE FUNCTION fn_salary_revision_immutability()
RETURNS trigger AS $$
BEGIN
  IF OLD.status = 'disbursed' THEN
    RAISE EXCEPTION
      'Salary revision for employee % effective % is disbursed and immutable.',
      OLD."employeeId", OLD."effectiveFrom";
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS tg_salary_revision_immutability ON "salary_revisions";
CREATE TRIGGER tg_salary_revision_immutability
  BEFORE UPDATE ON "salary_revisions"
  FOR EACH ROW EXECUTE FUNCTION fn_salary_revision_immutability();

CREATE INDEX IF NOT EXISTS idx_salary_revision_tenant_fy
  ON "salary_revisions" ("tenantId", "financialYear");
CREATE INDEX IF NOT EXISTS idx_salary_revision_employee
  ON "salary_revisions" ("tenantId", "employeeId");
CREATE INDEX IF NOT EXISTS idx_salary_revision_status
  ON "salary_revisions" ("tenantId", "status");

-- ─── 2. Arrear Entries ────────────────────────────────────────────────────────
-- Month-by-month arrear breakdown per revision.
-- Immutable after revision is disbursed.

CREATE TABLE IF NOT EXISTS "arrear_entries" (
  "id"            TEXT           NOT NULL,
  "revisionId"    TEXT           NOT NULL,
  "tenantId"      TEXT           NOT NULL,
  "employeeId"    TEXT           NOT NULL,
  "month"         INTEGER        NOT NULL,
  "year"          INTEGER        NOT NULL,
  "financialYear" TEXT           NOT NULL,
  "arrearAmount"  DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "basicArrear"   DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "hraArrear"     DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "specialArrear" DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "otherArrear"   DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "createdAt"     TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

  CONSTRAINT "arrear_entry_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "arrear_entry_revision_fk"
    FOREIGN KEY ("revisionId") REFERENCES "salary_revisions"("id") ON DELETE CASCADE,
  CONSTRAINT "arrear_entry_month_check"
    CHECK ("month" BETWEEN 1 AND 12),
  CONSTRAINT "arrear_entry_year_check"
    CHECK ("year" BETWEEN 2000 AND 2099)
);

CREATE INDEX IF NOT EXISTS idx_arrear_entry_revision
  ON "arrear_entries" ("revisionId");
CREATE INDEX IF NOT EXISTS idx_arrear_entry_employee_fy
  ON "arrear_entries" ("tenantId", "employeeId", "financialYear");

-- ─── 3. Section 89 Audit Log ──────────────────────────────────────────────────
-- Append-only log of all Section 89 computations (for audit + ITD queries).

CREATE TABLE IF NOT EXISTS "section89_audit_logs" (
  "id"                    TEXT        NOT NULL,
  "tenantId"              TEXT        NOT NULL,
  "employeeId"            TEXT        NOT NULL,
  "revisionId"            TEXT        NOT NULL,
  "financialYear"         TEXT        NOT NULL,
  "pan"                   TEXT        NOT NULL,
  "totalArrearAmount"     DECIMAL(14,2),
  "extraTaxCurrentYear"   DECIMAL(12,2),
  "excessTaxPriorYears"   DECIMAL(12,2),
  "reliefAmount"          DECIMAL(12,2),
  "isReliefAvailable"     BOOLEAN,
  "form10ERequired"       BOOLEAN,
  "computedAt"            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "computedBy"            TEXT        NOT NULL,
  "computationSnapshot"   JSONB,       -- Full Section89Relief snapshot

  CONSTRAINT "s89_audit_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "s89_audit_revision_fk"
    FOREIGN KEY ("revisionId") REFERENCES "salary_revisions"("id") ON DELETE CASCADE
);

-- Append-only trigger
CREATE OR REPLACE FUNCTION fn_s89_audit_append_only()
RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'Section 89 audit log is append-only. Modification is not permitted (Row: %).', OLD.id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS tg_s89_audit_immutability ON "section89_audit_logs";
CREATE TRIGGER tg_s89_audit_immutability
  BEFORE UPDATE OR DELETE ON "section89_audit_logs"
  FOR EACH ROW EXECUTE FUNCTION fn_s89_audit_append_only();

CREATE INDEX IF NOT EXISTS idx_s89_audit_employee
  ON "section89_audit_logs" ("tenantId", "employeeId", "financialYear");

-- ─── 4. Columns added to existing tables ─────────────────────────────────────

-- TDS projections: add Section 89 relief and arrear income columns
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'TDSProjection' AND column_name = 'section89Relief') THEN
    ALTER TABLE "TDSProjection"
      ADD COLUMN "section89Relief"  DECIMAL(12,2) NOT NULL DEFAULT 0,
      ADD COLUMN "arrearIncome"     DECIMAL(14,2) NOT NULL DEFAULT 0,
      ADD COLUMN "revisionId"       TEXT;

    COMMENT ON COLUMN "TDSProjection"."section89Relief" IS
      'Section 89(1) relief computed from salary revision. Reduces net TDS liability.';
    COMMENT ON COLUMN "TDSProjection"."arrearIncome" IS
      'Total arrear amount included in current FY income.';
  END IF;
END $$;

-- Payslip: add arrear payslip support
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'payslips' AND column_name = 'payslipType') THEN
    ALTER TABLE "payslips"
      ADD COLUMN "payslipType"  TEXT NOT NULL DEFAULT 'regular',
      ADD COLUMN "revisionId"   TEXT,
      ADD COLUMN "notes"        TEXT;

    COMMENT ON COLUMN "payslips"."payslipType" IS
      'regular | arrear | supplementary';
  END IF;
END $$;

-- ─── 5. Dashboard View ────────────────────────────────────────────────────────

CREATE OR REPLACE VIEW vw_arrear_fy_summary AS
SELECT
  r."tenantId",
  r."financialYear",
  COUNT(*)                                                 AS total_revisions,
  COUNT(*) FILTER (WHERE r.status = 'pending')             AS pending,
  COUNT(*) FILTER (WHERE r.status = 'processed')          AS processed,
  COUNT(*) FILTER (WHERE r.status = 'arrear_payslip_generated') AS payslip_generated,
  COUNT(*) FILTER (WHERE r.status = 'disbursed')          AS disbursed,
  SUM(r."totalArrearAmount")                              AS total_arrear_amount,
  SUM(r."section89ReliefAmount")                          AS total_section89_relief,
  AVG(r."totalArrearAmount")                              AS avg_arrear_per_employee,
  COUNT(*) FILTER (WHERE r."section89ReliefAmount" > 0)   AS employees_with_relief
FROM "salary_revisions" r
GROUP BY r."tenantId", r."financialYear";

COMMENT ON VIEW vw_arrear_fy_summary IS
  'Per-FY arrear and Section 89 relief rollup: counts by status, totals.';

-- ─── 6. Arrear Register View (for payroll audit) ──────────────────────────────

CREATE OR REPLACE VIEW vw_arrear_register AS
SELECT
  r."tenantId",
  r."employeeId",
  r."financialYear",
  r."effectiveFrom",
  r."revisionAnnouncedDate",
  r."oldMonthlyGross",
  r."newMonthlyGross",
  r."newMonthlyGross" - r."oldMonthlyGross"   AS monthly_increment,
  r."totalArrearAmount",
  r."section89ReliefAmount",
  r."revisedMonthlyTds",
  r.status,
  r."reason",
  r."processedAt",
  s."reliefAmount"                             AS s89_relief_verified,
  s."form10ERequired"
FROM "salary_revisions"     r
LEFT JOIN "section89_audit_logs" s
  ON s."revisionId" = r.id
ORDER BY r."tenantId", r."financialYear" DESC, r."totalArrearAmount" DESC;

-- ─── 7. Verification ─────────────────────────────────────────────────────────

DO $$
BEGIN
  RAISE NOTICE '✅ Arrears & Section 89 migration complete (v3.4.0):';
  RAISE NOTICE '   Tables: salary_revisions, arrear_entries, section89_audit_logs';
  RAISE NOTICE '   Columns added: TDSProjection.section89Relief, payslips.payslipType';
  RAISE NOTICE '   Triggers: revision immutability (post-disbursal), audit append-only';
  RAISE NOTICE '   Views: vw_arrear_fy_summary, vw_arrear_register';
  RAISE NOTICE '';
  RAISE NOTICE '📋 SECTION 89 STATUTORY REMINDER:';
  RAISE NOTICE '   Employee MUST file Form 10E on incometax.gov.in BEFORE filing ITR.';
  RAISE NOTICE '   CBDT Circular 13/2017: non-filers will have relief denied by ITD.';
  RAISE NOTICE '   Employer: provide Form 10E data via GET /arrears/revisions/:id/form10e';
  RAISE NOTICE '';
  RAISE NOTICE '⚠️  NEXT STEPS:';
  RAISE NOTICE '   1. Create revision: POST /api/v1/arrears/revisions';
  RAISE NOTICE '   2. Process arrears: POST /api/v1/arrears/revisions/:id/process';
  RAISE NOTICE '   3. Review Section 89 + Form 10E data';
  RAISE NOTICE '   4. Generate arrear payslip: POST /api/v1/arrears/revisions/:id/arrear-payslip';
  RAISE NOTICE '   5. Inform employee to file Form 10E before ITR';
END $$;

COMMIT;
