-- ═══════════════════════════════════════════════════════════════════════════
-- RetroWorks HR — 24Q TDS Returns + TRACES Integration Migration
-- Version: 3.2.0-24q-traces
-- Legal basis: Section 200 r/w Rule 31A, Income Tax Act 1961
--              NSDL e-TDS/TCS RPU Format Specification v2.7
--
-- Apply:  psql $DATABASE_URL -f migrations/24q-traces-v3.2.0.sql
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─── 1. TDS Challan ──────────────────────────────────────────────────────────
-- Proof of tax deposit under Section 200(1).
-- CIN = BSR Code + Challan Date (DDMMYYYY) + Challan Serial (5 digits)

CREATE TABLE IF NOT EXISTS "tds_challans" (
  "id"                    TEXT           NOT NULL,
  "tenantId"              TEXT           NOT NULL,
  "financialYear"         TEXT           NOT NULL,
  "quarter"               TEXT           NOT NULL,
  "bsrCode"               TEXT           NOT NULL,
  "challanSerialNumber"   TEXT           NOT NULL,
  "challanDate"           TEXT           NOT NULL,
  "cin"                   TEXT           GENERATED ALWAYS AS (
                            "bsrCode" || "challanDate" || LPAD("challanSerialNumber", 5, '0')
                          ) STORED,
  "totalAmountDeposited"  DECIMAL(14,2)  NOT NULL,
  "tdsAmount"             DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "surchargeAmount"       DECIMAL(10,2)  NOT NULL DEFAULT 0,
  "educationCessAmount"   DECIMAL(10,2)  NOT NULL DEFAULT 0,
  "interestAmount"        DECIMAL(10,2)  NOT NULL DEFAULT 0,
  "penaltyAmount"         DECIMAL(10,2)  NOT NULL DEFAULT 0,
  "bankName"              TEXT           NOT NULL DEFAULT '',
  "isLinkedToReturn"      BOOLEAN        NOT NULL DEFAULT FALSE,
  "tracesVerified"        BOOLEAN        NOT NULL DEFAULT FALSE,
  "tracesDepositedAmount" DECIMAL(12,2),
  "createdBy"             TEXT           NOT NULL,
  "updatedBy"             TEXT,
  "createdAt"             TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  "updatedAt"             TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

  CONSTRAINT "tds_challans_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "tds_challans_quarter_check"
    CHECK ("quarter" IN ('Q1','Q2','Q3','Q4')),
  CONSTRAINT "tds_challans_amount_check"
    CHECK ("totalAmountDeposited" >= 0),
  -- Prevent duplicate CIN per tenant
  CONSTRAINT "tds_challans_cin_tenant_key"
    UNIQUE ("tenantId", "bsrCode", "challanSerialNumber", "challanDate")
);

CREATE INDEX IF NOT EXISTS idx_challans_tenant_fy
  ON "tds_challans" ("tenantId", "financialYear");
CREATE INDEX IF NOT EXISTS idx_challans_tenant_fy_quarter
  ON "tds_challans" ("tenantId", "financialYear", "quarter");
CREATE INDEX IF NOT EXISTS idx_challans_cin
  ON "tds_challans" ("cin");

-- ─── 2. TDS Return ───────────────────────────────────────────────────────────
-- One record per tenant per FY per quarter.
-- Immutable once status = 'filed' or 'reconciled'.

CREATE TABLE IF NOT EXISTS "tds_returns" (
  "id"                    TEXT        NOT NULL,
  "tenantId"              TEXT        NOT NULL,
  "financialYear"         TEXT        NOT NULL,
  "quarter"               TEXT        NOT NULL,
  "assessmentYear"        TEXT        NOT NULL,
  "totalTaxDeducted"      DECIMAL(14,2) NOT NULL DEFAULT 0,
  "totalTaxDeposited"     DECIMAL(14,2) NOT NULL DEFAULT 0,
  "totalEmployees"        INTEGER     NOT NULL DEFAULT 0,
  "challanLinked"         BOOLEAN     NOT NULL DEFAULT FALSE,
  "status"                TEXT        NOT NULL DEFAULT 'draft',
  "checksumHash"          TEXT        NOT NULL DEFAULT '',
  "templateVersion"       TEXT        NOT NULL DEFAULT '24Q-2024-v1',
  "returnData"            JSONB       NOT NULL DEFAULT '{}',
  "tracesReconciled"      BOOLEAN     NOT NULL DEFAULT FALSE,
  "reconciledAt"          TIMESTAMPTZ,
  "filedAt"               TIMESTAMPTZ,
  "filedBy"               TEXT,
  "acknowledgementNumber" TEXT,
  "generatedBy"           TEXT        NOT NULL,
  "generatedAt"           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "createdAt"             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  "updatedAt"             TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT "tds_returns_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "tds_returns_tenant_fy_quarter_key"
    UNIQUE ("tenantId", "financialYear", "quarter"),
  CONSTRAINT "tds_returns_status_check"
    CHECK ("status" IN ('draft','validated','filed','reconciled')),
  CONSTRAINT "tds_returns_quarter_check"
    CHECK ("quarter" IN ('Q1','Q2','Q3','Q4'))
);

CREATE INDEX IF NOT EXISTS idx_returns_tenant_fy
  ON "tds_returns" ("tenantId", "financialYear");
CREATE INDEX IF NOT EXISTS idx_returns_status
  ON "tds_returns" ("tenantId", "status");

-- Prevent UPDATE of filed/reconciled returns (enforce immutability at DB level)
CREATE OR REPLACE FUNCTION fn_tds_return_immutability()
RETURNS trigger AS $$
BEGIN
  IF OLD.status IN ('filed', 'reconciled') AND NEW.status NOT IN ('filed', 'reconciled') THEN
    RAISE EXCEPTION
      'TDS return for % % % is % and cannot be modified. Statutory records are immutable.',
      OLD."tenantId", OLD."financialYear", OLD."quarter", OLD.status;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS tg_tds_return_immutability ON "tds_returns";
CREATE TRIGGER tg_tds_return_immutability
  BEFORE UPDATE ON "tds_returns"
  FOR EACH ROW EXECUTE FUNCTION fn_tds_return_immutability();

-- ─── 3. TDS Return Employee Entry ────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "tds_return_employee_entries" (
  "id"                TEXT           NOT NULL,
  "returnId"          TEXT           NOT NULL,
  "employeeId"        TEXT           NOT NULL,
  "pan"               TEXT           NOT NULL DEFAULT 'APPLIED',
  "totalSalaryPaid"   DECIMAL(14,2)  NOT NULL DEFAULT 0,
  "totalTdsDeducted"  DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "sectionCode"       TEXT           NOT NULL DEFAULT '192',
  "createdAt"         TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

  CONSTRAINT "tds_emp_entries_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "tds_emp_entries_return_fk"
    FOREIGN KEY ("returnId") REFERENCES "tds_returns"("id") ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_return_entries_return
  ON "tds_return_employee_entries" ("returnId");
CREATE INDEX IF NOT EXISTS idx_return_entries_employee
  ON "tds_return_employee_entries" ("employeeId");
CREATE INDEX IF NOT EXISTS idx_return_entries_pan
  ON "tds_return_employee_entries" ("pan");

-- ─── 4. TRACES Import Log ────────────────────────────────────────────────────
-- Immutable import history. Each TRACES upload logged forever.

CREATE TABLE IF NOT EXISTS "traces_import_logs" (
  "id"                TEXT           NOT NULL,
  "tenantId"          TEXT           NOT NULL,
  "financialYear"     TEXT           NOT NULL,
  "quarter"           TEXT           NOT NULL,
  "importedBy"        TEXT           NOT NULL,
  "importedAt"        TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  "recordCount"       INTEGER        NOT NULL DEFAULT 0,
  "mismatchCount"     INTEGER        NOT NULL DEFAULT 0,
  "parseErrors"       INTEGER        NOT NULL DEFAULT 0,
  "status"            TEXT           NOT NULL DEFAULT 'pending',
  "totalTracesTds"    DECIMAL(14,2)  NOT NULL DEFAULT 0,
  "totalInternalTds"  DECIMAL(14,2)  NOT NULL DEFAULT 0,
  "variance"          DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "contentHash"       TEXT           NOT NULL DEFAULT '',
  "mismatchDetail"    JSONB          NOT NULL DEFAULT '{}',

  CONSTRAINT "traces_logs_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "traces_logs_status_check"
    CHECK ("status" IN ('reconciled','mismatch','error','pending')),
  CONSTRAINT "traces_logs_quarter_check"
    CHECK ("quarter" IN ('Q1','Q2','Q3','Q4'))
);

-- Immutability trigger for TRACES logs
CREATE OR REPLACE FUNCTION fn_traces_log_immutable()
RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'traces_import_logs is immutable — % is not permitted.', TG_OP;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS tg_traces_log_immutable ON "traces_import_logs";
CREATE TRIGGER tg_traces_log_immutable
  BEFORE UPDATE OR DELETE ON "traces_import_logs"
  FOR EACH ROW EXECUTE FUNCTION fn_traces_log_immutable();

CREATE INDEX IF NOT EXISTS idx_traces_logs_tenant_fy
  ON "traces_import_logs" ("tenantId", "financialYear");
CREATE INDEX IF NOT EXISTS idx_traces_logs_tenant_quarter
  ON "traces_import_logs" ("tenantId", "financialYear", "quarter");
CREATE INDEX IF NOT EXISTS idx_traces_logs_status
  ON "traces_import_logs" ("tenantId", "status");

-- ─── 5. TDS Return Audit Log (immutable) ─────────────────────────────────────

CREATE TABLE IF NOT EXISTS "tds_return_audit_logs" (
  "id"            TEXT        NOT NULL,
  "tenantId"      TEXT        NOT NULL,
  "financialYear" TEXT        NOT NULL,
  "quarter"       TEXT        NOT NULL,
  "action"        TEXT        NOT NULL,
  "performedBy"   TEXT        NOT NULL,
  "notes"         TEXT,
  "createdAt"     TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT "tds_audit_logs_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "tds_audit_action_check"
    CHECK ("action" IN ('GENERATED','VALIDATED','FILED','FVU_EXPORTED','TRACES_IMPORTED','RECONCILED'))
);

DROP TRIGGER IF EXISTS tg_tds_audit_immutable ON "tds_return_audit_logs";
CREATE TRIGGER tg_tds_audit_immutable
  BEFORE UPDATE OR DELETE ON "tds_return_audit_logs"
  FOR EACH ROW EXECUTE FUNCTION fn_traces_log_immutable(); -- Reuse same fn

CREATE INDEX IF NOT EXISTS idx_tds_audit_tenant_fy
  ON "tds_return_audit_logs" ("tenantId", "financialYear");

-- ─── 6. Dashboard Views ───────────────────────────────────────────────────────

CREATE OR REPLACE VIEW vw_24q_quarterly_status AS
SELECT
  r."tenantId",
  r."financialYear",
  r."quarter",
  r."status",
  r."totalTaxDeducted",
  r."totalTaxDeposited",
  r."totalEmployees",
  r."challanLinked",
  r."tracesReconciled",
  r."filedAt",
  r."acknowledgementNumber",
  COALESCE(SUM(c."totalAmountDeposited"), 0) AS total_challan_deposited,
  COUNT(c.id) AS challan_count,
  ABS(r."totalTaxDeducted" - COALESCE(SUM(c."totalAmountDeposited"), 0)) AS tds_challan_variance
FROM "tds_returns" r
LEFT JOIN "tds_challans" c
  ON c."tenantId" = r."tenantId"
  AND c."financialYear" = r."financialYear"
  AND c."quarter" = r."quarter"
GROUP BY r.id, r."tenantId", r."financialYear", r."quarter", r."status",
  r."totalTaxDeducted", r."totalTaxDeposited", r."totalEmployees",
  r."challanLinked", r."tracesReconciled", r."filedAt", r."acknowledgementNumber";

CREATE OR REPLACE VIEW vw_fy_tds_compliance AS
SELECT
  r."tenantId",
  r."financialYear",
  COUNT(DISTINCT r."quarter")                                    AS quarters_with_returns,
  COUNT(DISTINCT r."quarter") FILTER (WHERE r."status" = 'filed'
    OR r."status" = 'reconciled')                               AS quarters_filed,
  COUNT(DISTINCT r."quarter") FILTER (WHERE r."tracesReconciled") AS quarters_reconciled,
  SUM(r."totalTaxDeducted")                                      AS total_tds_deducted_fy,
  SUM(r."totalTaxDeposited")                                     AS total_tds_deposited_fy,
  (COUNT(DISTINCT r."quarter") FILTER (WHERE r."tracesReconciled") = 4) AS all_quarters_reconciled,
  MAX(t."mismatchCount")                                         AS max_traces_mismatches
FROM "tds_returns" r
LEFT JOIN "traces_import_logs" t
  ON t."tenantId" = r."tenantId"
  AND t."financialYear" = r."financialYear"
  AND t."quarter" = r."quarter"
  AND t."status" = 'reconciled'
GROUP BY r."tenantId", r."financialYear";

COMMENT ON VIEW vw_24q_quarterly_status IS
  'Per-quarter 24Q status dashboard: TDS deducted vs deposited, filing status, TRACES reconciliation.';
COMMENT ON VIEW vw_fy_tds_compliance IS
  'Full-year compliance roll-up: quarters filed, TRACES reconciled, Form 16 readiness.';

-- ─── 7. Verification ─────────────────────────────────────────────────────────

DO $$
BEGIN
  RAISE NOTICE '✅ 24Q + TRACES migration complete:';
  RAISE NOTICE '   Tables: tds_challans, tds_returns, tds_return_employee_entries, traces_import_logs, tds_return_audit_logs';
  RAISE NOTICE '   Triggers: return immutability, audit log immutability, traces log immutability';
  RAISE NOTICE '   Views: vw_24q_quarterly_status, vw_fy_tds_compliance';
  RAISE NOTICE '   Indexes: 12 covering all query paths';
  RAISE NOTICE '';
  RAISE NOTICE '⚠️  NEXT STEPS:';
  RAISE NOTICE '   1. Configure tenant TAN, PAN, responsible person PAN in tenant settings';
  RAISE NOTICE '   2. Add challans for each quarter before generating returns';
  RAISE NOTICE '   3. Generate 24Q returns: POST /api/v1/tds-returns/generate/:quarter';
  RAISE NOTICE '   4. Export FVU: GET /api/v1/tds-returns/:quarter/export-fvu';
  RAISE NOTICE '   5. Upload FVU to NSDL utility and file — RetroWorks does NOT file directly';
  RAISE NOTICE '   6. Import TRACES Part A statement for reconciliation';
  RAISE NOTICE '   7. After all 4 quarters reconciled, populate Form 16 Part A';
  RAISE NOTICE '';
  RAISE NOTICE '⚖️  STATUTORY REMINDER:';
  RAISE NOTICE '   24Q must be filed by: Q1=31 Jul, Q2=31 Oct, Q3=31 Jan, Q4=31 May';
  RAISE NOTICE '   Late filing attracts penalty under Section 234E: ₹200/day';
END $$;

COMMIT;
