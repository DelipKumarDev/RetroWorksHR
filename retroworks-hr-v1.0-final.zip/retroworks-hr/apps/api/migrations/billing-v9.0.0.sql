-- ─────────────────────────────────────────────────────────────────────────────
-- Billing Engine — Migration v9.0.0
-- ─────────────────────────────────────────────────────────────────────────────

BEGIN;

-- ─── Subscriptions ────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS subscriptions (
  id                        TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id                 TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  plan_id                   TEXT NOT NULL DEFAULT 'starter'
                            CHECK (plan_id IN ('starter','growth','pro','enterprise')),
  status                    TEXT NOT NULL DEFAULT 'trialing'
                            CHECK (status IN ('trialing','active','past_due','grace_period',
                                              'suspended','cancelled','expired')),
  cycle                     TEXT NOT NULL DEFAULT 'monthly'
                            CHECK (cycle IN ('monthly','annual')),
  payroll_seats             INTEGER NOT NULL DEFAULT 0,
  current_period_start      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  current_period_end        TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '30 days',
  trial_start               TIMESTAMPTZ,
  trial_end                 TIMESTAMPTZ,
  grace_period_end          TIMESTAMPTZ,
  cancelled_at              TIMESTAMPTZ,
  cancel_at_period_end      BOOLEAN NOT NULL DEFAULT FALSE,
  gateway                   TEXT NOT NULL DEFAULT 'manual'
                            CHECK (gateway IN ('razorpay','stripe','manual')),
  gateway_subscription_id   TEXT,
  gateway_customer_id       TEXT,
  custom_price_per_seat     NUMERIC(10,2),
  notes                     TEXT,
  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT subscriptions_tenant_key UNIQUE (tenant_id)
);

-- ─── Invoices ─────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS invoices (
  id                    TEXT PRIMARY KEY,
  invoice_number        TEXT NOT NULL UNIQUE,
  tenant_id             TEXT NOT NULL REFERENCES tenants(id) ON DELETE RESTRICT,
  subscription_id       TEXT REFERENCES subscriptions(id) ON DELETE SET NULL,
  status                TEXT NOT NULL DEFAULT 'open'
                        CHECK (status IN ('draft','open','paid','void','uncollectible')),
  period_start          TIMESTAMPTZ NOT NULL,
  period_end            TIMESTAMPTZ NOT NULL,
  subtotal              NUMERIC(12,2) NOT NULL DEFAULT 0,
  discount_amount       NUMERIC(12,2) NOT NULL DEFAULT 0,
  taxable_amount        NUMERIC(12,2) NOT NULL DEFAULT 0,
  cgst_rate             NUMERIC(5,2) NOT NULL DEFAULT 0,
  sgst_rate             NUMERIC(5,2) NOT NULL DEFAULT 0,
  igst_rate             NUMERIC(5,2) NOT NULL DEFAULT 0,
  cgst_amount           NUMERIC(12,2) NOT NULL DEFAULT 0,
  sgst_amount           NUMERIC(12,2) NOT NULL DEFAULT 0,
  igst_amount           NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_tax             NUMERIC(12,2) NOT NULL DEFAULT 0,
  total_amount          NUMERIC(12,2) NOT NULL DEFAULT 0,
  amount_due            NUMERIC(12,2) NOT NULL DEFAULT 0,
  amount_paid           NUMERIC(12,2) NOT NULL DEFAULT 0,
  supplier_gstin        TEXT,
  customer_gstin        TEXT,
  place_of_supply       TEXT NOT NULL DEFAULT 'MH',
  is_inter_state        BOOLEAN NOT NULL DEFAULT FALSE,
  line_items            JSONB NOT NULL DEFAULT '[]',
  due_date              TIMESTAMPTZ NOT NULL,
  paid_at               TIMESTAMPTZ,
  gateway_payment_id    TEXT,
  notes                 TEXT,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Payment Events ───────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS payment_events (
  id                  TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id           TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  subscription_id     TEXT REFERENCES subscriptions(id) ON DELETE SET NULL,
  event_type          TEXT NOT NULL,
  gateway             TEXT NOT NULL DEFAULT 'manual',
  gateway_event_id    TEXT,
  amount              NUMERIC(12,2),
  currency            TEXT DEFAULT 'INR',
  metadata            JSONB DEFAULT '{}',
  processed_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Feature Gate Logs ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS feature_gate_logs (
  id          BIGSERIAL PRIMARY KEY,
  tenant_id   TEXT NOT NULL,
  user_id     TEXT,
  feature     TEXT NOT NULL,
  plan_id     TEXT NOT NULL,
  allowed     BOOLEAN NOT NULL,
  reason      TEXT,
  endpoint    TEXT,
  logged_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Plan Change History ──────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS plan_change_history (
  id              TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id       TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  from_plan       TEXT NOT NULL,
  to_plan         TEXT NOT NULL,
  from_cycle      TEXT NOT NULL,
  to_cycle        TEXT NOT NULL,
  changed_by      TEXT,
  prorated_credit NUMERIC(12,2) DEFAULT 0,
  effective_date  TIMESTAMPTZ NOT NULL,
  reason          TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Indexes ──────────────────────────────────────────────────────────────────

CREATE INDEX IF NOT EXISTS idx_subscriptions_tenant ON subscriptions (tenant_id, status);
CREATE INDEX IF NOT EXISTS idx_subscriptions_grace ON subscriptions (status, grace_period_end) WHERE status = 'grace_period';
CREATE INDEX IF NOT EXISTS idx_subscriptions_gateway ON subscriptions (gateway_subscription_id) WHERE gateway_subscription_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_subscriptions_renewal ON subscriptions (current_period_end, status) WHERE status IN ('active','trialing') AND cancel_at_period_end = FALSE;

CREATE INDEX IF NOT EXISTS idx_invoices_tenant ON invoices (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_invoices_open ON invoices (tenant_id, status) WHERE status IN ('open','past_due');
CREATE INDEX IF NOT EXISTS idx_invoices_overdue ON invoices (due_date, status) WHERE status = 'open';

CREATE INDEX IF NOT EXISTS idx_payment_events_tenant ON payment_events (tenant_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_feature_gate_denied ON feature_gate_logs (tenant_id, feature, logged_at DESC) WHERE allowed = FALSE;
CREATE INDEX IF NOT EXISTS idx_plan_change_tenant ON plan_change_history (tenant_id, created_at DESC);

-- ─── Views ────────────────────────────────────────────────────────────────────

CREATE OR REPLACE VIEW v_tenant_subscriptions AS
SELECT
  t.id                                                    AS tenant_id,
  t.name                                                  AS tenant_name,
  t.is_active,
  COALESCE(s.plan_id, t.subscription_tier, 'starter')    AS plan_id,
  COALESCE(s.status, 'active')                            AS status,
  COALESCE(s.cycle, 'monthly')                            AS cycle,
  COALESCE(s.payroll_seats, 0)                            AS payroll_seats,
  s.trial_end,
  s.grace_period_end,
  s.current_period_end                                    AS next_billing_date,
  s.gateway_subscription_id
FROM tenants t
LEFT JOIN subscriptions s ON s.tenant_id = t.id
WHERE t.is_active = TRUE;

-- Overdue invoices for collections
CREATE OR REPLACE VIEW v_overdue_invoices AS
SELECT
  i.*,
  t.name AS tenant_name,
  EXTRACT(DAYS FROM NOW() - i.due_date)::INTEGER AS days_overdue
FROM invoices i
JOIN tenants t ON t.id = i.tenant_id
WHERE i.status = 'open'
  AND i.due_date < NOW()
ORDER BY days_overdue DESC;

-- Feature denial heatmap (for upsell analytics)
CREATE OR REPLACE VIEW v_feature_denials_7d AS
SELECT
  tenant_id,
  feature,
  plan_id,
  COUNT(*) AS denial_count,
  MAX(logged_at) AS last_denied
FROM feature_gate_logs
WHERE allowed = FALSE
  AND logged_at > NOW() - INTERVAL '7 days'
GROUP BY tenant_id, feature, plan_id
ORDER BY denial_count DESC;

-- ─── Seed: start trials for existing active tenants ──────────────────────────

INSERT INTO subscriptions (tenant_id, plan_id, status, cycle, payroll_seats, trial_start, trial_end, current_period_end, gateway)
SELECT
  id,
  COALESCE(subscription_tier, 'starter'),
  CASE WHEN subscription_tier IS NOT NULL AND subscription_tier != 'free' THEN 'active' ELSE 'trialing' END,
  'monthly',
  0,
  NOW(),
  NOW() + INTERVAL '14 days',
  NOW() + INTERVAL '14 days',
  'manual'
FROM tenants
WHERE is_active = TRUE
ON CONFLICT (tenant_id) DO NOTHING;

-- ─── Trigger: auto-update updated_at ─────────────────────────────────────────

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'subscriptions_updated_at') THEN
    CREATE TRIGGER subscriptions_updated_at
      BEFORE UPDATE ON subscriptions
      FOR EACH ROW EXECUTE FUNCTION set_updated_at();
  END IF;
END $$;

COMMIT;
