-- ═══════════════════════════════════════════════════════════════════════════
-- RetroWorks HR — Security Sprint Database Migration
-- Version: 2.0.0-security
-- Date: 2026-02-23
-- Author: Security Sprint — Production Hardening
--
-- APPLY IN ORDER:
--   1. Backup your database FIRST
--   2. Run this in a transaction
--   3. Verify indexes with: \d "Employee"
--   4. Verify constraint with: \d "PayrollRun"
--
-- ROLLBACK SCRIPT: security-sprint-rollback.sql
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─── C-04: Payroll Double-Run Prevention ─────────────────────────────────────
-- Unique constraint prevents duplicate payroll runs at DB level.
-- This is the safety net when Redis is unavailable.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'uq_payroll_run_tenant_month_year_active'
  ) THEN
    -- Partial unique index: only one non-cancelled run per tenant+month+year
    -- Cancelled runs are excluded so reruns after cancellation are allowed
    CREATE UNIQUE INDEX CONCURRENTLY uq_payroll_run_tenant_month_year_active
      ON "PayrollRun" ("tenantId", "month", "year")
      WHERE "status" NOT IN ('cancelled', 'failed');
    RAISE NOTICE 'Created payroll run uniqueness constraint';
  ELSE
    RAISE NOTICE 'Payroll run uniqueness constraint already exists — skipping';
  END IF;
END $$;


-- ─── H-07 + H-10: Performance Indexes ────────────────────────────────────────
-- Critical composite indexes to prevent full table scans in production.
-- Each CONCURRENTLY to avoid table locks.

-- Ticket: SLA monitoring cron (H-07 fix)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_ticket_tenant_status_sla_due
  ON "Ticket" ("tenantId", "status", "slaResolutionDue")
  WHERE "deletedAt" IS NULL;

CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_ticket_sla_response_due
  ON "Ticket" ("tenantId", "slaResponseDue", "slaBreached")
  WHERE "deletedAt" IS NULL AND "firstResponseAt" IS NULL;

-- Ticket: List queries with pagination
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_ticket_tenant_created_desc
  ON "Ticket" ("tenantId", "createdAt" DESC)
  WHERE "deletedAt" IS NULL;

-- Ticket: Assignee workload view
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_ticket_tenant_assignee_status
  ON "Ticket" ("tenantId", "assigneeId", "status")
  WHERE "deletedAt" IS NULL;

-- Employee: Tenant-scoped active employee queries (H-10 fix for N+1)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_employee_tenant_status_active
  ON "Employee" ("tenantId", "status")
  WHERE "deletedAt" IS NULL;

-- Employee: Department groupBy (attrition, insights)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_employee_tenant_dept
  ON "Employee" ("tenantId", "departmentId", "status")
  WHERE "deletedAt" IS NULL;

-- Payslip: Month/year queries for TDS projection, analytics
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_payslip_tenant_year_month
  ON "Payslip" ("tenantId", "year", "month")
  WHERE "status" != 'cancelled';

-- Payslip: Employee history for TDS annual projection
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_payslip_tenant_emp_year
  ON "Payslip" ("tenantId", "employeeId", "year", "month")
  WHERE "status" != 'cancelled';

-- Leave: Date range queries for attendance and leave analysis
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leave_tenant_dates
  ON "LeaveRequest" ("tenantId", "startDate", "endDate")
  WHERE "deletedAt" IS NULL;

-- Leave: Status filter for pending approval dashboard
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leave_tenant_status
  ON "LeaveRequest" ("tenantId", "status", "createdAt" DESC)
  WHERE "deletedAt" IS NULL;

-- Attendance: Daily queries for LOP calculation
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_attendance_tenant_emp_date
  ON "Attendance" ("tenantId", "employeeId", "date" DESC);

-- Audit Log: Tenant audit trail queries (immutability — read-heavy)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_audit_tenant_resource_created
  ON "AuditLog" ("tenantId", "resource", "createdAt" DESC);

-- SLA Event: Analytics queries
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_sla_event_tenant_created
  ON "SLAEvent" ("tenantId", "createdAt" DESC, "eventType");


-- ─── M-05: Audit Log Immutability ────────────────────────────────────────────
-- Prevents UPDATE and DELETE on AuditLog table.
-- Audit entries can only be inserted, never modified.

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_proc p
    JOIN pg_trigger t ON t.tgfoid = p.oid
    WHERE t.tgname = 'tg_audit_log_immutable'
  ) THEN

    -- Create trigger function to block mutations
    CREATE OR REPLACE FUNCTION fn_audit_log_immutable()
    RETURNS trigger AS $func$
    BEGIN
      IF TG_OP = 'UPDATE' THEN
        RAISE EXCEPTION 'AuditLog records are immutable — UPDATE is not allowed (TG_OP=%)'. TG_OP;
      END IF;
      IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'AuditLog records cannot be deleted (TG_OP=%)', TG_OP;
      END IF;
      RETURN NULL;
    END;
    $func$ LANGUAGE plpgsql SECURITY DEFINER;

    -- Apply trigger to AuditLog table
    CREATE TRIGGER tg_audit_log_immutable
      BEFORE UPDATE OR DELETE ON "AuditLog"
      FOR EACH ROW
      EXECUTE FUNCTION fn_audit_log_immutable();

    RAISE NOTICE 'AuditLog immutability trigger created';
  ELSE
    RAISE NOTICE 'AuditLog immutability trigger already exists';
  END IF;
END $$;


-- ─── C-02: Tenant Isolation Verification Query ───────────────────────────────
-- Run this after deployment to verify no cross-tenant data exists.
-- Should return 0 rows. If any rows returned — data integrity issue.

-- Uncomment to verify:
-- SELECT e.id, e."tenantId" as emp_tenant, u."tenantId" as user_tenant
-- FROM "Employee" e
-- JOIN "User" u ON u."employeeId" = e.id
-- WHERE e."tenantId" != u."tenantId";


-- ─── Security Housekeeping ────────────────────────────────────────────────────
-- Revoke public schema access — only the app user should have access
-- Uncomment and replace 'retroworks_app' with your actual DB user:
-- REVOKE ALL ON SCHEMA public FROM PUBLIC;
-- GRANT USAGE ON SCHEMA public TO retroworks_app;
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO retroworks_app;
-- GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO retroworks_app;


-- ─── Verify migration ────────────────────────────────────────────────────────
DO $$
DECLARE
  idx_count integer;
  constraint_count integer;
BEGIN
  SELECT COUNT(*) INTO idx_count
  FROM pg_indexes
  WHERE indexname LIKE 'idx_%'
    AND tablename IN ('Ticket', 'Employee', 'Payslip', 'LeaveRequest', 'Attendance', 'AuditLog', 'SLAEvent');

  SELECT COUNT(*) INTO constraint_count
  FROM pg_indexes
  WHERE indexname = 'uq_payroll_run_tenant_month_year_active';

  RAISE NOTICE '✅ Migration complete: % new indexes created', idx_count;
  RAISE NOTICE '✅ Payroll run uniqueness constraint: % (1=present)', constraint_count;

  IF constraint_count = 0 THEN
    RAISE WARNING '⚠️ Payroll uniqueness constraint NOT created — check for errors above';
  END IF;
END $$;

COMMIT;
