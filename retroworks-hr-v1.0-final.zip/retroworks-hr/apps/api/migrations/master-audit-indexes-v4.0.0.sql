-- ═══════════════════════════════════════════════════════════════════════════
-- RetroWorks HR — Performance Indexes & Query Optimization
-- Migration: master-audit-indexes-v4.0.0.sql
-- AUDIT-08: Added missing covering indexes for core hot queries
--
-- Targets identified from audit:
--   1. 500-employee payroll read (N+1 query risk on salary structure join)
--   2. 1,000-employee list view (no composite index on tenantId+status+dept)
--   3. 50-concurrent login attempts (no index on email+tenantId for auth lookup)
--   4. TDS projection FY lookup (missing FY filter index)
--   5. Permission cache sentinel (Redis — no DB index needed)
--   6. Audit log retrieval (range queries by date)
--   7. Session lookup (JWT validation = per-request)
--
-- All indexes use CONCURRENTLY to avoid table locks in production.
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─── 1. Authentication (50 concurrent logins — high frequency) ───────────────

-- Login: email + tenantId lookup (most frequent auth query)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_user_email_tenant_active
  ON "users" ("email", "tenantId", "isActive")
  WHERE "deletedAt" IS NULL AND "isActive" = TRUE;

-- Session validation: per JWT validate call (every authenticated request)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_session_user_active
  ON "sessions" ("userId", "expiresAt", "revokedAt")
  WHERE "revokedAt" IS NULL;

-- Account lockout check (failedLoginCount > 0)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_user_locked
  ON "users" ("lockedUntil")
  WHERE "lockedUntil" IS NOT NULL;

-- ─── 2. Employee List (1,000+ employees with dept/manager joins) ─────────────

-- Main list query: filter by tenant + status + dept, sort by name
-- This is the single most important index for employee list performance
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_employee_list_core
  ON "employees" ("tenantId", "status", "departmentId", "lastName", "firstName")
  WHERE "deletedAt" IS NULL;

-- Manager hierarchy (reporting chain lookups)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_employee_manager
  ON "employees" ("tenantId", "managerId")
  WHERE "managerId" IS NOT NULL AND "deletedAt" IS NULL;

-- Employee code lookup (unique within tenant)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_employee_code_tenant
  ON "employees" ("tenantId", "employeeCode")
  WHERE "deletedAt" IS NULL;

-- Location filter (multi-location tenants)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_employee_location
  ON "employees" ("tenantId", "locationId", "status")
  WHERE "deletedAt" IS NULL;

-- Designation filter (job title-based queries)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_employee_designation
  ON "employees" ("tenantId", "designationId", "status");

-- ─── 3. Payroll Run (500-employee payroll — salary structure join) ────────────

-- Salary structure: one row per (employee, effectiveFrom)
-- Hot query: load all active structures for a tenant's payroll run
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_salary_structure_payroll_run
  ON "salary_structures" ("tenantId", "employeeId", "effectiveFrom" DESC)
  WHERE "isActive" = TRUE;

-- Payroll run lookup by month/year (the most common filter)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_payroll_run_month_year
  ON "payroll_runs" ("tenantId", "year", "month", "status");

-- Payslip bulk read for payroll run (one-to-many join)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_payslip_run_employee
  ON "payslips" ("payrollRunId", "employeeId");

-- Payslip employee self-service (my payslips query)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_payslip_employee_year_desc
  ON "payslips" ("tenantId", "employeeId", "year" DESC, "month" DESC)
  WHERE "payslipType" = 'regular';

-- Payroll adjustments lookup during run
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_payroll_adj_month
  ON "payroll_adjustments" ("tenantId", "employeeId", "year", "month")
  WHERE "status" = 'pending';

-- ─── 4. TDS / Statutory (FY-scoped queries) ──────────────────────────────────

-- TDS projection: FY + employee (loaded on every TDS recalculation)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tds_projection_fy_emp
  ON "TDSProjection" ("tenantId", "financialYear", "employeeId");

-- TDS challan: FY + quarter filter
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_tds_challan_fy_quarter
  ON "tds_challans" ("tenantId", "financialYear", "quarter");

-- PF ECR records by period
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_pf_ecr_period
  ON "pf_ecr_records" ("tenantId", "year", "month");

-- ESI contribution by period
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_esi_contribution_period
  ON "esi_contribution_records" ("tenantId", "year", "month");

-- Salary revisions by FY (arrears processing)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_salary_revision_status
  ON "salary_revisions" ("tenantId", "financialYear", "status");

-- ─── 5. Audit Log (compliance queries — date range scans) ────────────────────

-- Audit log by resource + date (GDPR/SOC2 audit queries)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_audit_log_resource_date
  ON "audit_logs" ("tenantId", "resource", "resourceId", "timestamp" DESC);

-- Audit log by user (who changed what)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_audit_log_user_date
  ON "audit_logs" ("tenantId", "userId", "timestamp" DESC)
  WHERE "userId" IS NOT NULL;

-- ─── 6. Leave Management ─────────────────────────────────────────────────────

-- Leave calendar: date range overlap check (when approving)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leave_date_range
  ON "leave_requests" ("tenantId", "employeeId", "startDate", "endDate")
  WHERE "status" IN ('pending', 'approved');

-- Leave balance lookup (frequently read per employee)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leave_balance_employee_type
  ON "leave_balances" ("tenantId", "employeeId", "leaveTypeId", "year");

-- ─── 7. ATS (recruitment pipeline) ──────────────────────────────────────────

-- Job applications pipeline view
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_ats_application_job_stage
  ON "ats_applications" ("tenantId", "jobId", "stage", "createdAt" DESC);

-- ─── 8. Performance partial indexes (frequently filtered) ────────────────────

-- Performance reviews: active cycle filter
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_perf_review_cycle_status
  ON "performance_reviews" ("tenantId", "cycleId", "status", "revieweeId");

-- ─── Verification ────────────────────────────────────────────────────────────

DO $$
DECLARE
  idx_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO idx_count
  FROM pg_indexes
  WHERE schemaname = 'public'
    AND indexname LIKE 'idx_%';

  RAISE NOTICE '✅ AUDIT-08 Performance indexes applied.';
  RAISE NOTICE '   Total indexes in schema: %', idx_count;
  RAISE NOTICE '';
  RAISE NOTICE 'Key hot queries now covered:';
  RAISE NOTICE '   Login (email+tenant): idx_user_email_tenant_active';
  RAISE NOTICE '   JWT validation (session): idx_session_user_active';
  RAISE NOTICE '   Employee list (1000+): idx_employee_list_core';
  RAISE NOTICE '   Payroll run (500 emp): idx_salary_structure_payroll_run';
  RAISE NOTICE '   TDS FY lookup: idx_tds_projection_fy_emp';
  RAISE NOTICE '   Audit compliance: idx_audit_log_resource_date';
END $$;

-- ─── ANALYZE to update planner statistics ────────────────────────────────────
-- Run after index creation in production to update query planner
ANALYZE "users";
ANALYZE "sessions";
ANALYZE "employees";
ANALYZE "salary_structures";
ANALYZE "payroll_runs";
ANALYZE "payslips";

COMMIT;
