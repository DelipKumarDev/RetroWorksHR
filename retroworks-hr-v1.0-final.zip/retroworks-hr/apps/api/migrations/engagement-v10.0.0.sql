-- ─────────────────────────────────────────────────────────────────────────────
-- Engagement + Performance + Experience — Migration v10.0.0
-- ─────────────────────────────────────────────────────────────────────────────
-- New tables:
--   pulse_surveys          — survey definitions (max 5 questions, anonymous flag)
--   survey_responses       — per-respondent answers (nullable respondent = anon)
--   performance_cycles     — H1/H2 review cycle configuration
--   performance_goals      — employee goals with weight + ratings
--   performance_reviews    — self + manager + calibration ratings, 9-box axes
-- ─────────────────────────────────────────────────────────────────────────────

BEGIN;

-- ─── Pulse Surveys ───────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS pulse_surveys (
  id               TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id        TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  title            TEXT NOT NULL,
  description      TEXT,
  questions        JSONB NOT NULL DEFAULT '[]',
  is_anonymous     BOOLEAN NOT NULL DEFAULT FALSE,
  target_audience  TEXT NOT NULL DEFAULT 'all'
                   CHECK (target_audience IN ('all','department','entity')),
  target_ids       TEXT[]  NOT NULL DEFAULT '{}',
  status           TEXT NOT NULL DEFAULT 'draft'
                   CHECK (status IN ('draft','active','closed')),
  opens_at         TIMESTAMPTZ,
  closes_at        TIMESTAMPTZ,
  created_by       TEXT NOT NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON COLUMN pulse_surveys.questions IS
  'JSONB array of {id,text,type,required,options?} — max 5 items enforced in service';
COMMENT ON COLUMN pulse_surveys.is_anonymous IS
  'When true, survey_responses.respondent_id is always NULL';

-- ─── Survey Responses ─────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS survey_responses (
  id            TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  survey_id     TEXT NOT NULL REFERENCES pulse_surveys(id) ON DELETE CASCADE,
  tenant_id     TEXT NOT NULL,
  respondent_id TEXT,           -- NULL for anonymous surveys
  answers       JSONB NOT NULL DEFAULT '[]',
  submitted_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON COLUMN survey_responses.respondent_id IS
  'NULL when survey is anonymous — no PII linkage possible';

-- ─── Performance Cycles ───────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS performance_cycles (
  id                       TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id                TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  name                     TEXT NOT NULL,
  period                   TEXT NOT NULL,   -- e.g. "H1 2024", "FY 2024-25"
  status                   TEXT NOT NULL DEFAULT 'planning'
                           CHECK (status IN (
                             'planning','goal_setting','self_review',
                             'manager_review','calibration','complete'
                           )),
  goal_setting_deadline    TIMESTAMPTZ NOT NULL,
  self_review_deadline     TIMESTAMPTZ NOT NULL,
  manager_review_deadline  TIMESTAMPTZ NOT NULL,
  calibration_date         TIMESTAMPTZ,
  created_by               TEXT,
  created_at               TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Performance Goals ────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS performance_goals (
  id             TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id      TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id    TEXT NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  cycle_id       TEXT NOT NULL REFERENCES performance_cycles(id) ON DELETE CASCADE,
  title          TEXT NOT NULL,
  description    TEXT,
  metric         TEXT,          -- Success metric e.g. "Ship 3 features"
  weight         INTEGER NOT NULL DEFAULT 20 CHECK (weight >= 0 AND weight <= 100),
  status         TEXT NOT NULL DEFAULT 'active'
                 CHECK (status IN ('draft','active','completed','cancelled')),
  progress       INTEGER NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  self_rating    INTEGER CHECK (self_rating >= 1 AND self_rating <= 5),
  manager_rating INTEGER CHECK (manager_rating >= 1 AND manager_rating <= 5),
  due_date       TIMESTAMPTZ,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Ensure total weight per employee per cycle ≤ 100
-- (enforced in service layer with BadRequestException)

-- ─── Performance Reviews ──────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS performance_reviews (
  id                        TEXT PRIMARY KEY DEFAULT gen_random_uuid()::TEXT,
  tenant_id                 TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  employee_id               TEXT NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  cycle_id                  TEXT NOT NULL REFERENCES performance_cycles(id) ON DELETE CASCADE,
  review_status             TEXT NOT NULL DEFAULT 'pending'
                            CHECK (review_status IN (
                              'pending','self_review','manager_review',
                              'calibration','complete'
                            )),

  -- Self review
  self_overall_rating       INTEGER CHECK (self_overall_rating >= 1 AND self_overall_rating <= 5),
  self_strengths            TEXT,
  self_improvements         TEXT,
  self_submitted_at         TIMESTAMPTZ,

  -- Manager review
  manager_overall_rating    INTEGER CHECK (manager_overall_rating >= 1 AND manager_overall_rating <= 5),
  manager_strengths         TEXT,
  manager_development       TEXT,
  promotion_recommendation  TEXT
                            CHECK (promotion_recommendation IN (
                              'ready_now','ready_in_6m','ready_in_12m','not_ready'
                            )),
  manager_submitted_at      TIMESTAMPTZ,

  -- 9-box placement
  performance_axis          SMALLINT CHECK (performance_axis IN (1,2,3)),
  potential_axis            SMALLINT CHECK (potential_axis IN (1,2,3)),
  nine_box_label            TEXT,

  -- Calibration
  calibrated_rating         INTEGER CHECK (calibrated_rating >= 1 AND calibrated_rating <= 5),
  calibration_notes         TEXT,
  calibrated_at             TIMESTAMPTZ,
  calibrated_by             TEXT,

  created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),

  CONSTRAINT perf_review_unique UNIQUE (employee_id, cycle_id)
);

COMMENT ON COLUMN performance_reviews.nine_box_label IS
  'Computed from performance_axis × potential_axis — e.g. Star Performer, Key Player';
COMMENT ON COLUMN performance_reviews.promotion_recommendation IS
  'Manager recommendation: ready_now | ready_in_6m | ready_in_12m | not_ready';

-- ─── Indexes ──────────────────────────────────────────────────────────────────

-- Pulse surveys
CREATE INDEX IF NOT EXISTS idx_pulse_surveys_tenant_status
  ON pulse_surveys (tenant_id, status);

CREATE INDEX IF NOT EXISTS idx_pulse_surveys_active
  ON pulse_surveys (tenant_id)
  WHERE status = 'active';

-- Survey responses
CREATE INDEX IF NOT EXISTS idx_survey_responses_survey
  ON survey_responses (survey_id);

CREATE INDEX IF NOT EXISTS idx_survey_responses_respondent
  ON survey_responses (respondent_id)
  WHERE respondent_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_survey_responses_tenant_date
  ON survey_responses (tenant_id, submitted_at DESC);

-- Performance cycles
CREATE INDEX IF NOT EXISTS idx_perf_cycles_tenant_status
  ON performance_cycles (tenant_id, status);

-- Performance goals
CREATE INDEX IF NOT EXISTS idx_perf_goals_employee_cycle
  ON performance_goals (employee_id, cycle_id);

CREATE INDEX IF NOT EXISTS idx_perf_goals_cycle
  ON performance_goals (cycle_id, status);

-- Performance reviews
CREATE INDEX IF NOT EXISTS idx_perf_reviews_tenant_cycle
  ON performance_reviews (tenant_id, cycle_id, review_status);

CREATE INDEX IF NOT EXISTS idx_perf_reviews_employee
  ON performance_reviews (employee_id, cycle_id);

CREATE INDEX IF NOT EXISTS idx_perf_reviews_9box
  ON performance_reviews (tenant_id, cycle_id, performance_axis, potential_axis)
  WHERE performance_axis IS NOT NULL AND potential_axis IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_perf_reviews_promotion
  ON performance_reviews (tenant_id, cycle_id, promotion_recommendation)
  WHERE promotion_recommendation = 'ready_now';

-- ─── Views ────────────────────────────────────────────────────────────────────

-- 9-box population per cycle (for calibration dashboard)
CREATE OR REPLACE VIEW v_nine_box_population AS
SELECT
  pr.tenant_id,
  pr.cycle_id,
  pr.performance_axis,
  pr.potential_axis,
  pr.nine_box_label,
  COUNT(*) AS employee_count,
  ROUND(AVG(COALESCE(pr.calibrated_rating, pr.manager_overall_rating))::NUMERIC, 1)
    AS avg_rating
FROM performance_reviews pr
WHERE pr.performance_axis IS NOT NULL
  AND pr.potential_axis IS NOT NULL
GROUP BY pr.tenant_id, pr.cycle_id, pr.performance_axis, pr.potential_axis, pr.nine_box_label;

-- eNPS per closed survey
CREATE OR REPLACE VIEW v_enps_by_survey AS
SELECT
  ps.id AS survey_id,
  ps.tenant_id,
  ps.title,
  ps.closes_at,
  COUNT(sr.id)                                                          AS total_responses,
  COUNT(CASE WHEN (ans->>'value')::INT >= 9  THEN 1 END)               AS promoters,
  COUNT(CASE WHEN (ans->>'value')::INT IN (7,8) THEN 1 END)            AS passives,
  COUNT(CASE WHEN (ans->>'value')::INT <= 6  THEN 1 END)               AS detractors,
  ROUND(
    ((COUNT(CASE WHEN (ans->>'value')::INT >= 9  THEN 1 END)::FLOAT
     - COUNT(CASE WHEN (ans->>'value')::INT <= 6 THEN 1 END)::FLOAT)
    / NULLIF(COUNT(sr.id), 0) * 100)::NUMERIC, 0
  )                                                                      AS enps_score
FROM pulse_surveys ps
JOIN survey_responses sr ON sr.survey_id = ps.id
CROSS JOIN LATERAL jsonb_array_elements(sr.answers) AS ans
JOIN LATERAL (
  SELECT elem->>'type' AS qtype, elem->>'id' AS qid
  FROM jsonb_array_elements(ps.questions) AS elem
) AS q ON q.qid = ans->>'questionId' AND q.qtype = 'nps'
WHERE ps.status = 'closed'
GROUP BY ps.id, ps.tenant_id, ps.title, ps.closes_at;

-- Promotion pipeline (ready_now employees)
CREATE OR REPLACE VIEW v_promotion_pipeline AS
SELECT
  pr.tenant_id,
  pr.cycle_id,
  pc.period,
  e.id AS employee_id,
  e.employee_code,
  e.first_name || ' ' || e.last_name AS full_name,
  d.name  AS department,
  des.name AS designation,
  pr.manager_overall_rating,
  pr.calibrated_rating,
  pr.nine_box_label,
  pr.promotion_recommendation,
  pr.manager_submitted_at
FROM performance_reviews pr
JOIN performance_cycles pc ON pc.id = pr.cycle_id
JOIN employees e ON e.id = pr.employee_id
LEFT JOIN departments d ON d.id = e.department_id
LEFT JOIN designations des ON des.id = e.designation_id
WHERE pr.promotion_recommendation = 'ready_now'
  AND e.deleted_at IS NULL
ORDER BY pr.calibrated_rating DESC NULLS LAST;

-- ─── Auto-update triggers ─────────────────────────────────────────────────────

DO $$
DECLARE
  tbl TEXT;
BEGIN
  FOREACH tbl IN ARRAY ARRAY['pulse_surveys','performance_cycles','performance_goals','performance_reviews']
  LOOP
    EXECUTE format(
      'CREATE TRIGGER %I_updated_at
         BEFORE UPDATE ON %I
         FOR EACH ROW EXECUTE FUNCTION set_updated_at()',
      tbl || '_trig', tbl
    );
  END LOOP;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

COMMIT;
