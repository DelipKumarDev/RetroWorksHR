-- ═══════════════════════════════════════════════════════════════════════════
-- RetroWorks HR — TDS Engine Migration
-- Version: 3.0.0-tds-engine
-- Reference: Income Tax Act 1961, Finance Act 2024 (AY 2025-26 / FY 2024-25)
--
-- ⚠️  DISCLAIMER: Tax slabs seeded below are based on Finance Act 2024.
--     These MUST be reviewed and validated by a Chartered Accountant
--     before processing actual employee payroll.
--
-- Apply:  psql $DATABASE_URL -f migrations/tds-engine-v3.0.0.sql
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─── 1. FY Tax Config ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "fy_tax_configs" (
  "id"                          TEXT          NOT NULL,
  "financialYear"               TEXT          NOT NULL,
  "standardDeductionNew"        DECIMAL(12,2) NOT NULL DEFAULT 75000,
  "standardDeductionOld"        DECIMAL(12,2) NOT NULL DEFAULT 50000,
  "maxSection80C"               DECIMAL(12,2) NOT NULL DEFAULT 150000,
  "maxSection80D_self"          DECIMAL(12,2) NOT NULL DEFAULT 25000,
  "maxSection80D_parents"       DECIMAL(12,2) NOT NULL DEFAULT 25000,
  "maxSection80D_parentsSenior" DECIMAL(12,2) NOT NULL DEFAULT 50000,
  "maxSection80CCD1B"           DECIMAL(12,2) NOT NULL DEFAULT 50000,
  "max87ARebate_new"            DECIMAL(12,2) NOT NULL DEFAULT 25000,
  "max87AThreshold_new"         DECIMAL(12,2) NOT NULL DEFAULT 700000,
  "max87ARebate_old"            DECIMAL(12,2) NOT NULL DEFAULT 12500,
  "max87AThreshold_old"         DECIMAL(12,2) NOT NULL DEFAULT 500000,
  "cessRate"                    DECIMAL(6,4)  NOT NULL DEFAULT 0.04,
  "notes"                       TEXT,
  "createdBy"                   TEXT          NOT NULL DEFAULT 'system',
  "createdAt"                   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  "updatedAt"                   TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  CONSTRAINT "fy_tax_configs_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "fy_tax_configs_fy_key" UNIQUE ("financialYear")
);

-- ─── 2. Tax Slabs ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "tax_slabs" (
  "id"            TEXT          NOT NULL,
  "financialYear" TEXT          NOT NULL,
  "regimeType"    TEXT          NOT NULL,
  "slabFrom"      DECIMAL(12,2) NOT NULL,
  "slabTo"        DECIMAL(12,2) NOT NULL,
  "taxRate"       DECIMAL(6,4)  NOT NULL,
  "description"   TEXT,
  "createdBy"     TEXT          NOT NULL DEFAULT 'system',
  "createdAt"     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  CONSTRAINT "tax_slabs_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "tax_slabs_fy_regime_from_key" UNIQUE ("financialYear", "regimeType", "slabFrom"),
  CONSTRAINT "tax_slabs_rate_range" CHECK ("taxRate" >= 0 AND "taxRate" <= 1),
  CONSTRAINT "tax_slabs_slab_valid" CHECK ("slabFrom" >= 0 AND "slabTo" > "slabFrom")
);
CREATE INDEX IF NOT EXISTS idx_tax_slabs_fy_regime ON "tax_slabs" ("financialYear", "regimeType");

-- ─── 3. Employee Tax Declarations ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "employee_tax_declarations" (
  "id"                      TEXT          NOT NULL,
  "tenantId"                TEXT          NOT NULL,
  "employeeId"              TEXT          NOT NULL,
  "financialYear"           TEXT          NOT NULL,
  "regimeType"              TEXT          NOT NULL DEFAULT 'new',
  "section80C"              DECIMAL(12,2) NOT NULL DEFAULT 0,
  "section80D_self"         DECIMAL(12,2) NOT NULL DEFAULT 0,
  "section80D_parents"      DECIMAL(12,2) NOT NULL DEFAULT 0,
  "section80D_parentsIsSenior" BOOLEAN    NOT NULL DEFAULT FALSE,
  "section80CCD1B"          DECIMAL(12,2) NOT NULL DEFAULT 0,
  "homeLoanInterest"        DECIMAL(12,2) NOT NULL DEFAULT 0,
  "otherDeductions"         DECIMAL(12,2) NOT NULL DEFAULT 0,
  "hraRentPaid"             DECIMAL(12,2) NOT NULL DEFAULT 0,
  "hraCityType"             TEXT          NOT NULL DEFAULT 'non-metro',
  "ltaAmountClaimed"        DECIMAL(12,2) NOT NULL DEFAULT 0,
  "prevEmployerIncome"      DECIMAL(12,2) NOT NULL DEFAULT 0,
  "prevEmployerTds"         DECIMAL(12,2) NOT NULL DEFAULT 0,
  "prevEmployerPfContrib"   DECIMAL(12,2) NOT NULL DEFAULT 0,
  "projectedBonusForFy"     DECIMAL(12,2) NOT NULL DEFAULT 0,
  "isLocked"                BOOLEAN       NOT NULL DEFAULT FALSE,
  "lockedAt"                TIMESTAMPTZ,
  "lockedBy"                TEXT,
  "createdBy"               TEXT          NOT NULL,
  "updatedBy"               TEXT,
  "createdAt"               TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  "updatedAt"               TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  CONSTRAINT "employee_tax_declarations_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "emp_tax_decl_tenant_emp_fy_key" UNIQUE ("tenantId", "employeeId", "financialYear"),
  CONSTRAINT "emp_tax_decl_regime_check" CHECK ("regimeType" IN ('old', 'new')),
  CONSTRAINT "emp_tax_decl_city_check" CHECK ("hraCityType" IN ('metro', 'non-metro'))
);
CREATE INDEX IF NOT EXISTS idx_emp_tax_decl_tenant_fy ON "employee_tax_declarations" ("tenantId", "financialYear");
CREATE INDEX IF NOT EXISTS idx_emp_tax_decl_employee  ON "employee_tax_declarations" ("tenantId", "employeeId");

-- ─── 4. TDS Projections ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS "tds_projections" (
  "id"                    TEXT          NOT NULL,
  "tenantId"              TEXT          NOT NULL,
  "employeeId"            TEXT          NOT NULL,
  "financialYear"         TEXT          NOT NULL,
  "regimeType"            TEXT          NOT NULL,
  "projectedAnnualIncome" DECIMAL(14,2) NOT NULL,
  "totalTaxLiability"     DECIMAL(12,2) NOT NULL,
  "totalCess"             DECIMAL(10,2) NOT NULL,
  "totalTDS"              DECIMAL(12,2) NOT NULL,
  "monthlyTDS"            DECIMAL(10,2) NOT NULL,
  "triggeredBy"           TEXT          NOT NULL,
  "calculationInput"      JSONB         NOT NULL DEFAULT '{}',
  "calculationBreakdown"  JSONB         NOT NULL DEFAULT '{}',
  "recalculatedAt"        TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  "createdBy"             TEXT          NOT NULL DEFAULT 'system',
  "updatedBy"             TEXT,
  "createdAt"             TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  "updatedAt"             TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  CONSTRAINT "tds_projections_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "tds_proj_tenant_emp_fy_key" UNIQUE ("tenantId", "employeeId", "financialYear"),
  CONSTRAINT "tds_proj_monthly_non_negative" CHECK ("monthlyTDS" >= 0)
);
CREATE INDEX IF NOT EXISTS idx_tds_proj_tenant_fy   ON "tds_projections" ("tenantId", "financialYear");
CREATE INDEX IF NOT EXISTS idx_tds_proj_employee    ON "tds_projections" ("tenantId", "employeeId");
CREATE INDEX IF NOT EXISTS idx_tds_proj_monthly_desc ON "tds_projections" ("tenantId", "financialYear", "monthlyTDS" DESC);

-- ─── 5. TDS Recalculation Log (append-only) ──────────────────────────────────
CREATE TABLE IF NOT EXISTS "tds_recalculation_logs" (
  "id"                  TEXT          NOT NULL,
  "tenantId"            TEXT          NOT NULL,
  "employeeId"          TEXT          NOT NULL,
  "financialYear"       TEXT          NOT NULL,
  "calendarMonth"       INTEGER       NOT NULL,
  "year"                INTEGER       NOT NULL,
  "regimeType"          TEXT          NOT NULL,
  "previousMonthlyTds"  DECIMAL(10,2) NOT NULL,
  "newMonthlyTds"       DECIMAL(10,2) NOT NULL,
  "trigger"             TEXT          NOT NULL,
  "snapshot"            JSONB         NOT NULL,
  "createdAt"           TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
  CONSTRAINT "tds_recalc_logs_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "tds_recalc_month_range" CHECK ("calendarMonth" BETWEEN 1 AND 12)
);

CREATE OR REPLACE FUNCTION fn_tds_log_immutable()
RETURNS trigger AS $$ BEGIN
  RAISE EXCEPTION 'TDS recalculation log is immutable — % not allowed', TG_OP;
  RETURN NULL;
END; $$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS tg_tds_log_immutable ON "tds_recalculation_logs";
CREATE TRIGGER tg_tds_log_immutable
  BEFORE UPDATE OR DELETE ON "tds_recalculation_logs"
  FOR EACH ROW EXECUTE FUNCTION fn_tds_log_immutable();

CREATE INDEX IF NOT EXISTS idx_tds_log_tenant_emp_fy ON "tds_recalculation_logs" ("tenantId", "employeeId", "financialYear");
CREATE INDEX IF NOT EXISTS idx_tds_log_tenant_fy_month ON "tds_recalculation_logs" ("tenantId", "financialYear", "calendarMonth");

-- ─── 6. Remove old flat-rate TDS column from payslips (if exists) ─────────────
-- The new engine writes TDS as a component in the JSONB 'components' field.
-- No schema change needed for payslips — components[] carries TDS line item.

-- ═══════════════════════════════════════════════════════════════════════════
-- SEED: FY 2024-25 — Finance Act 2024
-- ⚠️  SUBJECT TO CA REVIEW AND VALIDATION BEFORE PRODUCTION USE
-- ═══════════════════════════════════════════════════════════════════════════

INSERT INTO "fy_tax_configs" (
  "id","financialYear","standardDeductionNew","standardDeductionOld",
  "maxSection80C","maxSection80D_self","maxSection80D_parents","maxSection80D_parentsSenior",
  "maxSection80CCD1B","max87ARebate_new","max87AThreshold_new","max87ARebate_old","max87AThreshold_old",
  "cessRate","notes","createdBy"
) VALUES
  ('fyc-2024-25','2024-25',75000,50000,150000,25000,25000,50000,50000,25000,700000,12500,500000,0.04,
   'Finance Act 2024. New regime std deduction ₹75K (increased from ₹50K). 87A rebate ₹25K. MUST BE CA-VALIDATED.','system'),
  ('fyc-2025-26','2025-26',75000,50000,150000,25000,25000,50000,50000,25000,700000,12500,500000,0.04,
   'PLACEHOLDER — UPDATE AFTER UNION BUDGET 2025. Do not process payroll until CA-validated.','system')
ON CONFLICT ("financialYear") DO NOTHING;

-- New Regime Slabs FY 2024-25
INSERT INTO "tax_slabs" ("id","financialYear","regimeType","slabFrom","slabTo","taxRate","description","createdBy") VALUES
  ('snew-24-1','2024-25','new',0,300000,0.00,'Nil — ₹0 to ₹3,00,000','system'),
  ('snew-24-2','2024-25','new',300001,600000,0.05,'5% — ₹3,00,001 to ₹6,00,000','system'),
  ('snew-24-3','2024-25','new',600001,900000,0.10,'10% — ₹6,00,001 to ₹9,00,000','system'),
  ('snew-24-4','2024-25','new',900001,1200000,0.15,'15% — ₹9,00,001 to ₹12,00,000','system'),
  ('snew-24-5','2024-25','new',1200001,1500000,0.20,'20% — ₹12,00,001 to ₹15,00,000','system'),
  ('snew-24-6','2024-25','new',1500001,999999999,0.30,'30% — above ₹15,00,000','system')
ON CONFLICT ("financialYear","regimeType","slabFrom") DO NOTHING;

-- Old Regime Slabs FY 2024-25 (below 60 years)
INSERT INTO "tax_slabs" ("id","financialYear","regimeType","slabFrom","slabTo","taxRate","description","createdBy") VALUES
  ('sold-24-1','2024-25','old',0,250000,0.00,'Nil — ₹0 to ₹2,50,000','system'),
  ('sold-24-2','2024-25','old',250001,500000,0.05,'5% — ₹2,50,001 to ₹5,00,000','system'),
  ('sold-24-3','2024-25','old',500001,1000000,0.20,'20% — ₹5,00,001 to ₹10,00,000','system'),
  ('sold-24-4','2024-25','old',1000001,999999999,0.30,'30% — above ₹10,00,000','system')
ON CONFLICT ("financialYear","regimeType","slabFrom") DO NOTHING;

-- Verify
DO $$ DECLARE n INT; o INT;
BEGIN
  SELECT COUNT(*) INTO n FROM "tax_slabs" WHERE "financialYear"='2024-25' AND "regimeType"='new';
  SELECT COUNT(*) INTO o FROM "tax_slabs" WHERE "financialYear"='2024-25' AND "regimeType"='old';
  RAISE NOTICE '✅ TDS Engine migration complete: new regime slabs=%, old regime slabs=%',n,o;
  RAISE NOTICE '⚠️  SLABS MUST BE CA-REVIEWED BEFORE PRODUCTION PAYROLL';
END $$;

COMMIT;
