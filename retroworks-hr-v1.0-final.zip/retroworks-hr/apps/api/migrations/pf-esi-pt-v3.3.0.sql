-- ═══════════════════════════════════════════════════════════════════════════
-- RetroWorks HR — PF / ESI / Professional Tax Migration
-- Version: 3.3.0-pf-esi-pt
-- Legal basis:
--   EPF & MP Act 1952 | EPF Scheme 1952 | EPS 1995 | EDLI 1976
--   ESI Act 1948 | State Professional Tax Acts
--
-- Apply:  psql $DATABASE_URL -f migrations/pf-esi-pt-v3.3.0.sql
-- ═══════════════════════════════════════════════════════════════════════════

BEGIN;

-- ─── 1. PF ECR Records ───────────────────────────────────────────────────────
-- One ECR per establishment per wage month.
-- Immutable once status = 'submitted' or 'paid'.

CREATE TABLE IF NOT EXISTS "pf_ecr_records" (
  "id"                      TEXT           NOT NULL,
  "tenantId"                TEXT           NOT NULL,
  "wageYear"                INTEGER        NOT NULL,
  "wageMonth"               INTEGER        NOT NULL,
  "financialYear"           TEXT           NOT NULL,
  "pfRegistrationNumber"    TEXT           NOT NULL DEFAULT '',
  "trrnNumber"              TEXT,
  "totalMembers"            INTEGER        NOT NULL DEFAULT 0,
  "totalEpfEmployee"        DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "totalEpfEmployer"        DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "totalEps"                DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "totalEdli"               DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "totalAdminCharge"        DECIMAL(10,2)  NOT NULL DEFAULT 0,
  "totalVpf"                DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "grandTotalPayable"       DECIMAL(14,2)  NOT NULL DEFAULT 0,
  "ecrData"                 JSONB          NOT NULL DEFAULT '{}',
  "checksumHash"            TEXT           NOT NULL DEFAULT '',
  "status"                  TEXT           NOT NULL DEFAULT 'draft',
  "generatedBy"             TEXT           NOT NULL,
  "generatedAt"             TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  "submittedAt"             TIMESTAMPTZ,
  "paidAt"                  TIMESTAMPTZ,
  "createdAt"               TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  "updatedAt"               TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

  CONSTRAINT "pf_ecr_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "pf_ecr_tenant_ym_key"
    UNIQUE ("tenantId", "wageYear", "wageMonth"),
  CONSTRAINT "pf_ecr_status_check"
    CHECK ("status" IN ('draft','submitted','paid')),
  CONSTRAINT "pf_ecr_month_check"
    CHECK ("wageMonth" BETWEEN 1 AND 12)
);

-- Immutability: prevent downgrade from submitted/paid
CREATE OR REPLACE FUNCTION fn_pf_ecr_immutability()
RETURNS trigger AS $$
BEGIN
  IF OLD.status IN ('submitted', 'paid') AND NEW.status NOT IN ('submitted', 'paid') THEN
    RAISE EXCEPTION
      'ECR for %/% is % and cannot be downgraded. Statutory record is immutable.',
      OLD."wageMonth", OLD."wageYear", OLD.status;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS tg_pf_ecr_immutability ON "pf_ecr_records";
CREATE TRIGGER tg_pf_ecr_immutability
  BEFORE UPDATE ON "pf_ecr_records"
  FOR EACH ROW EXECUTE FUNCTION fn_pf_ecr_immutability();

CREATE INDEX IF NOT EXISTS idx_pf_ecr_tenant_fy
  ON "pf_ecr_records" ("tenantId", "financialYear");
CREATE INDEX IF NOT EXISTS idx_pf_ecr_status
  ON "pf_ecr_records" ("tenantId", "status");

-- ─── 2. ESI Contribution Records ─────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS "esi_contribution_records" (
  "id"                    TEXT           NOT NULL,
  "tenantId"              TEXT           NOT NULL,
  "wageYear"              INTEGER        NOT NULL,
  "wageMonth"             INTEGER        NOT NULL,
  "contributionPeriod"    TEXT           NOT NULL,
  "totalMembers"          INTEGER        NOT NULL DEFAULT 0,
  "totalEsiEmployee"      DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "totalEsiEmployer"      DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "totalEsiPayable"       DECIMAL(12,2)  NOT NULL DEFAULT 0,
  "esiData"               JSONB          NOT NULL DEFAULT '{}',
  "checksumHash"          TEXT           NOT NULL DEFAULT '',
  "status"                TEXT           NOT NULL DEFAULT 'draft',
  "generatedBy"           TEXT           NOT NULL,
  "generatedAt"           TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  "submittedAt"           TIMESTAMPTZ,
  "paidAt"                TIMESTAMPTZ,
  "createdAt"             TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  "updatedAt"             TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

  CONSTRAINT "esi_contrib_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "esi_contrib_tenant_ym_key"
    UNIQUE ("tenantId", "wageYear", "wageMonth"),
  CONSTRAINT "esi_contrib_status_check"
    CHECK ("status" IN ('draft','submitted','paid'))
);

CREATE INDEX IF NOT EXISTS idx_esi_tenant_period
  ON "esi_contribution_records" ("tenantId", "wageYear", "wageMonth");

-- ─── 3. Professional Tax Return Records ──────────────────────────────────────

CREATE TABLE IF NOT EXISTS "pt_return_records" (
  "id"              TEXT           NOT NULL,
  "tenantId"        TEXT           NOT NULL,
  "wageYear"        INTEGER        NOT NULL,
  "wageMonth"       INTEGER        NOT NULL,
  "financialYear"   TEXT           NOT NULL,
  "stateCode"       TEXT           NOT NULL,
  "totalEmployees"  INTEGER        NOT NULL DEFAULT 0,
  "totalPtPayable"  DECIMAL(10,2)  NOT NULL DEFAULT 0,
  "ptData"          JSONB          NOT NULL DEFAULT '{}',
  "dueDate"         TEXT           NOT NULL DEFAULT '',
  "status"          TEXT           NOT NULL DEFAULT 'draft',
  "generatedBy"     TEXT           NOT NULL,
  "generatedAt"     TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  "submittedAt"     TIMESTAMPTZ,
  "paidAt"          TIMESTAMPTZ,
  "createdAt"       TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
  "updatedAt"       TIMESTAMPTZ    NOT NULL DEFAULT NOW(),

  CONSTRAINT "pt_return_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "pt_return_tenant_ym_key"
    UNIQUE ("tenantId", "wageYear", "wageMonth"),
  CONSTRAINT "pt_return_status_check"
    CHECK ("status" IN ('draft','submitted','paid'))
);

CREATE INDEX IF NOT EXISTS idx_pt_tenant_fy
  ON "pt_return_records" ("tenantId", "financialYear");

-- ─── 4. UAN / IP Number on Employee ──────────────────────────────────────────
-- Add PF/ESI statutory columns to employees table if not present.

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'employees' AND column_name = 'uan') THEN
    ALTER TABLE "employees"
      ADD COLUMN "uan"            TEXT,         -- 12-digit Universal Account Number
      ADD COLUMN "pfMemberId"     TEXT,         -- Establishment-specific PF member ID
      ADD COLUMN "esiIpNumber"    TEXT,         -- ESI Insurance (IP) Number
      ADD COLUMN "esiEligible"    BOOLEAN NOT NULL DEFAULT TRUE,
      ADD COLUMN "pfExempt"       BOOLEAN NOT NULL DEFAULT FALSE;

    COMMENT ON COLUMN "employees"."uan" IS
      'EPFO Universal Account Number (12 digits). Mandatory for PF filing.';
    COMMENT ON COLUMN "employees"."esiIpNumber" IS
      'ESIC Insurance Person number. Required for ESI portal filing.';
  END IF;
END $$;

-- ─── 5. Dashboard View ────────────────────────────────────────────────────────

CREATE OR REPLACE VIEW vw_monthly_statutory_compliance AS
SELECT
  COALESCE(p."tenantId", e."tenantId", t."tenantId")   AS "tenantId",
  COALESCE(p."wageYear", e."wageYear", t."wageYear")   AS "wageYear",
  COALESCE(p."wageMonth", e."wageMonth", t."wageMonth") AS "wageMonth",
  COALESCE(p."financialYear", t."financialYear")        AS "financialYear",
  p."grandTotalPayable"                                 AS pf_payable,
  p."status"                                            AS pf_status,
  p."trrnNumber"                                        AS pf_trrn,
  e."totalEsiPayable"                                   AS esi_payable,
  e."status"                                            AS esi_status,
  t."totalPtPayable"                                    AS pt_payable,
  t."status"                                            AS pt_status,
  COALESCE(p."grandTotalPayable", 0) +
  COALESCE(e."totalEsiPayable", 0) +
  COALESCE(t."totalPtPayable", 0)                       AS total_statutory_payable
FROM      "pf_ecr_records"           p
FULL JOIN "esi_contribution_records" e
  ON  e."tenantId" = p."tenantId"
  AND e."wageYear" = p."wageYear"
  AND e."wageMonth" = p."wageMonth"
FULL JOIN "pt_return_records"        t
  ON  t."tenantId" = COALESCE(p."tenantId", e."tenantId")
  AND t."wageYear" = COALESCE(p."wageYear", e."wageYear")
  AND t."wageMonth" = COALESCE(p."wageMonth", e."wageMonth");

COMMENT ON VIEW vw_monthly_statutory_compliance IS
  'Per-month PF + ESI + PT roll-up: amounts, payment status, and total statutory payable.';

-- ─── 6. Annual PF Summary View ────────────────────────────────────────────────

CREATE OR REPLACE VIEW vw_annual_pf_summary AS
SELECT
  "tenantId",
  "financialYear",
  COUNT(DISTINCT "wageMonth")                    AS months_filed,
  SUM("totalMembers")                            AS total_member_months,
  SUM("totalEpfEmployee")                        AS annual_epf_employee,
  SUM("totalEpfEmployer")                        AS annual_epf_employer,
  SUM("totalEps")                                AS annual_eps,
  SUM("totalEdli")                               AS annual_edli,
  SUM("totalAdminCharge")                        AS annual_admin_charge,
  SUM("grandTotalPayable")                       AS annual_total_payable,
  COUNT(*) FILTER (WHERE "status" = 'paid')      AS months_paid,
  COUNT(*) FILTER (WHERE "status" = 'draft')     AS months_unpaid,
  MAX("updatedAt")                               AS last_updated
FROM "pf_ecr_records"
GROUP BY "tenantId", "financialYear";

-- ─── 7. Seed: PF config on tenants ───────────────────────────────────────────

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tenants' AND column_name = 'pf_config') THEN
    ALTER TABLE "tenants"
      ADD COLUMN "pf_config" JSONB NOT NULL DEFAULT '{}';
    COMMENT ON COLUMN "tenants"."pf_config" IS
      'PF/ESI/PT config: {pfRegistrationNumber, esiRegistrationNumber, state, adminContactName}. Configure before generating ECR.';
  END IF;
END $$;

-- ─── 8. Verification ─────────────────────────────────────────────────────────

DO $$
BEGIN
  RAISE NOTICE '✅ PF/ESI/PT migration complete:';
  RAISE NOTICE '   Tables: pf_ecr_records, esi_contribution_records, pt_return_records';
  RAISE NOTICE '   Employee columns: uan, pfMemberId, esiIpNumber, esiEligible, pfExempt';
  RAISE NOTICE '   Triggers: ECR immutability (submitted/paid cannot be downgraded)';
  RAISE NOTICE '   Views: vw_monthly_statutory_compliance, vw_annual_pf_summary';
  RAISE NOTICE '';
  RAISE NOTICE '⚠️  NEXT STEPS:';
  RAISE NOTICE '   1. Configure pf_config on tenant: {pfRegistrationNumber, esiRegistrationNumber, state}';
  RAISE NOTICE '   2. Import UANs: POST /api/v1/pf-esi/uan/bulk-import';
  RAISE NOTICE '   3. Generate ECR monthly: POST /api/v1/pf-esi/ecr/generate';
  RAISE NOTICE '   4. Export and upload to EPFO Unified Portal by 15th of each month';
  RAISE NOTICE '   5. Mark as paid after challan: POST /api/v1/pf-esi/ecr/status/:year/:month';
  RAISE NOTICE '';
  RAISE NOTICE '⚖️  STATUTORY PENALTIES:';
  RAISE NOTICE '   PF delay: 12% p.a. interest (Sec 7Q) + 5-25% damages (Sec 14B)';
  RAISE NOTICE '   ESI delay: 12% p.a. simple interest (Reg 31C)';
END $$;

COMMIT;
