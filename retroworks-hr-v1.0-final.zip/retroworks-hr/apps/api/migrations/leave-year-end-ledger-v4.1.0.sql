-- ═══════════════════════════════════════════════════════════════════════
-- RetroWorks HR — Leave Year-End Ledger Table
-- Migration: leave-year-end-ledger-v4.1.0.sql
-- Provides: idempotency guard, audit trail for year-end processing
-- ═══════════════════════════════════════════════════════════════════════

BEGIN;

-- Leave year-end processed ledger (idempotency + audit)
CREATE TABLE IF NOT EXISTS "leave_year_end_ledgers" (
  "id"           TEXT NOT NULL DEFAULT gen_random_uuid()::text,
  "tenantId"     TEXT NOT NULL,
  "yearType"     TEXT NOT NULL,  -- 'calendar' | 'financial' | 'academic'
  "closingYear"  INTEGER NOT NULL,
  "processedAt"  TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "processedBy"  TEXT NOT NULL,
  "isSimulation" BOOLEAN NOT NULL DEFAULT FALSE,
  "totalEmployees" INTEGER NOT NULL DEFAULT 0,
  "totalRecords"   INTEGER NOT NULL DEFAULT 0,
  "totalCarryForward" DECIMAL(10,2) NOT NULL DEFAULT 0,
  "totalLapsed"       DECIMAL(10,2) NOT NULL DEFAULT 0,
  "totalEncashmentAmount" DECIMAL(15,2) NOT NULL DEFAULT 0,
  "ledgerHash"   TEXT NOT NULL,  -- content hash for tamper detection
  "isLocked"     BOOLEAN NOT NULL DEFAULT FALSE,
  "createdAt"    TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "leave_year_end_ledgers_pkey" PRIMARY KEY ("id")
);

-- Unique constraint: one REAL (non-simulation) run per tenant+year+type
CREATE UNIQUE INDEX IF NOT EXISTS "leave_year_end_unique_real_run"
  ON "leave_year_end_ledgers" ("tenantId", "yearType", "closingYear")
  WHERE "isSimulation" = FALSE;

-- Tenant + year lookup for idempotency guard
CREATE INDEX IF NOT EXISTS "idx_leave_year_end_tenant_year"
  ON "leave_year_end_ledgers" ("tenantId", "closingYear", "yearType");

-- Audit queries by date
CREATE INDEX IF NOT EXISTS "idx_leave_year_end_processed_at"
  ON "leave_year_end_ledgers" ("tenantId", "processedAt" DESC);

-- Line-item details per employee per leave type
CREATE TABLE IF NOT EXISTS "leave_year_end_entries" (
  "id"              TEXT NOT NULL DEFAULT gen_random_uuid()::text,
  "ledgerId"        TEXT NOT NULL,
  "tenantId"        TEXT NOT NULL,
  "employeeId"      TEXT NOT NULL,
  "leaveTypeId"     TEXT NOT NULL,
  "leaveTypeCode"   TEXT NOT NULL,
  "year"            INTEGER NOT NULL,
  "allocated"       DECIMAL(8,2) NOT NULL,
  "used"            DECIMAL(8,2) NOT NULL,
  "pending"         DECIMAL(8,2) NOT NULL,
  "closingAvailable" DECIMAL(8,2) NOT NULL,
  "carryForwardDays" DECIMAL(8,2) NOT NULL,
  "lapsedDays"       DECIMAL(8,2) NOT NULL,
  "encashedDays"     DECIMAL(8,2) NOT NULL,
  "encashmentAmount" DECIMAL(12,2) NOT NULL,
  "newYearAllocated" DECIMAL(8,2) NOT NULL,
  "processedAt"     TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

  CONSTRAINT "leave_year_end_entries_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "leave_year_end_entries_ledger_fk" FOREIGN KEY ("ledgerId")
    REFERENCES "leave_year_end_ledgers"("id") ON DELETE CASCADE
);

-- One entry per employee+leaveType per ledger
CREATE UNIQUE INDEX IF NOT EXISTS "leave_year_end_entries_unique"
  ON "leave_year_end_entries" ("ledgerId", "employeeId", "leaveTypeId");

-- Bulk read by ledger (all employees in a run)
CREATE INDEX IF NOT EXISTS "idx_leave_year_end_entries_ledger"
  ON "leave_year_end_entries" ("ledgerId", "employeeId");

COMMIT;
