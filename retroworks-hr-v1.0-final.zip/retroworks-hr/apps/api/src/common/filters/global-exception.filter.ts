import {
  ExceptionFilter, Catch, ArgumentsHost, HttpException,
  HttpStatus, Logger,
} from '@nestjs/common';
import type { Request, Response } from 'express';
import { Prisma } from '@prisma/client';

/**
 * Global exception filter — catches ALL unhandled errors.
 * Returns consistent structured JSON error responses.
 */
@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(GlobalExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const request = ctx.getRequest<Request>();
    const response = ctx.getResponse<Response>();

    let statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Internal server error';
    let code = 'INTERNAL_ERROR';
    let details: unknown = undefined;

    // ── NestJS HTTP exceptions ──────────────────────────────
    if (exception instanceof HttpException) {
      statusCode = exception.getStatus();
      const exceptionResponse = exception.getResponse();

      if (typeof exceptionResponse === 'string') {
        message = exceptionResponse;
      } else if (typeof exceptionResponse === 'object') {
        const res = exceptionResponse as Record<string, unknown>;
        message = (res['message'] as string) ?? message;
        details = res['errors'];
      }

      code = this.getCodeFromStatus(statusCode);
    }

    // ── Prisma errors ───────────────────────────────────────
    else if (exception instanceof Prisma.PrismaClientKnownRequestError) {
      switch (exception.code) {
        case 'P2002': // Unique constraint
          statusCode = HttpStatus.CONFLICT;
          code = 'DUPLICATE_ENTRY';
          message = `A record with this ${(exception.meta?.target as string[])?.join(', ')} already exists`;
          break;
        case 'P2025': // Record not found
          statusCode = HttpStatus.NOT_FOUND;
          code = 'NOT_FOUND';
          message = 'Record not found';
          break;
        case 'P2003': // Foreign key constraint
          statusCode = HttpStatus.BAD_REQUEST;
          code = 'INVALID_REFERENCE';
          message = 'Referenced record does not exist';
          break;
        case 'P2014': // Required relation
          statusCode = HttpStatus.BAD_REQUEST;
          code = 'INVALID_RELATION';
          message = 'Invalid relation constraint';
          break;
        default:
          statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
          code = `PRISMA_${exception.code}`;
          message = 'Database operation failed';
      }
    }

    // ── Prisma validation errors ──────────────────────────
    else if (exception instanceof Prisma.PrismaClientValidationError) {
      statusCode = HttpStatus.BAD_REQUEST;
      code = 'VALIDATION_ERROR';
      message = 'Invalid data provided';
    }

    // ── Unhandled errors ────────────────────────────────────
    else if (exception instanceof Error) {
      if (process.env['NODE_ENV'] !== 'production') {
        message = exception.message;
        details = exception.stack;
      }
      this.logger.error(
        `Unhandled exception: ${exception.message}`,
        exception.stack,
        `${request.method} ${request.url}`,
      );
    }

    // Log non-500 errors at debug level, 500s at error level
    if (statusCode >= 500) {
      this.logger.error(
        `${request.method} ${request.url} → ${statusCode}: ${message}`,
        exception instanceof Error ? exception.stack : undefined,
      );
    } else {
      this.logger.debug(`${request.method} ${request.url} → ${statusCode}: ${message}`);
    }

    const errorResponse = {
      success: false,
      statusCode,
      code,
      message,
      ...(details !== undefined && process.env['NODE_ENV'] !== 'production' && { details }),
      timestamp: new Date().toISOString(),
      path: request.url,
    };

    response.status(statusCode).json(errorResponse);
  }

  private getCodeFromStatus(status: number): string {
    const codes: Record<number, string> = {
      400: 'BAD_REQUEST',
      401: 'UNAUTHORIZED',
      403: 'FORBIDDEN',
      404: 'NOT_FOUND',
      405: 'METHOD_NOT_ALLOWED',
      408: 'REQUEST_TIMEOUT',
      409: 'CONFLICT',
      410: 'GONE',
      413: 'PAYLOAD_TOO_LARGE',
      415: 'UNSUPPORTED_MEDIA_TYPE',
      422: 'UNPROCESSABLE_ENTITY',
      429: 'TOO_MANY_REQUESTS',
      500: 'INTERNAL_ERROR',
      502: 'BAD_GATEWAY',
      503: 'SERVICE_UNAVAILABLE',
    };
    return codes[status] ?? 'UNKNOWN_ERROR';
  }
}
