import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { v4 as uuid } from 'uuid';

@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();
    const traceId = uuid();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let code = 'INTERNAL_ERROR';
    let message = 'An unexpected error occurred';
    let details: Record<string, string[]> | undefined;

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      const exResponse = exception.getResponse();

      if (typeof exResponse === 'string') {
        message = exResponse;
      } else if (typeof exResponse === 'object' && exResponse !== null) {
        const res = exResponse as Record<string, unknown>;
        message = (res['message'] as string) || message;
        code = (res['error'] as string)?.toUpperCase().replace(/\s+/g, '_') || `HTTP_${status}`;

        // Validation errors
        if (Array.isArray(res['message'])) {
          message = 'Validation failed';
          details = { validation: res['message'] as string[] };
        }
      }
    }

    // Log errors (not 4xx client errors in development)
    if (status >= 500) {
      this.logger.error(
        `${request.method} ${request.url} — ${status}`,
        exception instanceof Error ? exception.stack : String(exception),
        { traceId, body: request.body },
      );
    } else if (status >= 400) {
      this.logger.warn(`${request.method} ${request.url} — ${status} ${message}`, { traceId });
    }

    response.status(status).json({
      success: false,
      error: { code, message, details, traceId },
      meta: {
        requestId: traceId,
        timestamp: new Date().toISOString(),
        version: '1.0',
        path: request.url,
      },
    });
  }
}
