import { SetMetadata } from '@nestjs/common';
import type { ResourceType, ActionType } from '@retroworks/types';

export interface RequiredPermission {
  resource: ResourceType;
  action: ActionType;
}

export const PERMISSIONS_KEY = 'permissions';
export const RequirePermission = (...permissions: RequiredPermission[]) =>
  SetMetadata(PERMISSIONS_KEY, permissions);

export const ROLES_KEY = 'roles';
export const Roles = (...roles: string[]) => SetMetadata(ROLES_KEY, roles);
