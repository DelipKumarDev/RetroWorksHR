import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { PrismaClient } from '@prisma/client';

interface AuditEvent {
  tenantId: string;
  userId?: string;
  action: string;
  resource: string;
  resourceId?: string;
  oldData?: Record<string, unknown>;
  newData?: Record<string, unknown>;
  ip?: string;
  userAgent?: string;
  sessionId?: string;
}

@Injectable()
export class AuditService {
  private readonly logger = new Logger(AuditService.name);

  constructor(private readonly prisma: PrismaClient) {}

  @OnEvent('audit.created', { async: true })
  async handleAuditEvent(event: AuditEvent): Promise<void> {
    try {
      await this.prisma.auditLog.create({
        data: {
          tenantId: event.tenantId,
          userId: event.userId,
          action: event.action,
          resource: event.resource,
          resourceId: event.resourceId,
          oldData: event.oldData as object | undefined,
          newData: event.newData as object | undefined,
          ip: event.ip,
          userAgent: event.userAgent,
          sessionId: event.sessionId,
          timestamp: new Date(),
        },
      });
    } catch (e) {
      // Audit failures must never break the main flow
      this.logger.error('Failed to write audit log', e);
    }
  }

  async getAuditLogs(
    tenantId: string,
    filters: {
      resource?: string;
      resourceId?: string;
      userId?: string;
      action?: string;
      from?: Date;
      to?: Date;
      limit?: number;
      cursor?: string;
    },
  ) {
    const where = {
      tenantId,
      ...(filters.resource && { resource: filters.resource }),
      ...(filters.resourceId && { resourceId: filters.resourceId }),
      ...(filters.userId && { userId: filters.userId }),
      ...(filters.action && { action: filters.action }),
      ...(filters.from || filters.to ? {
        timestamp: {
          ...(filters.from && { gte: filters.from }),
          ...(filters.to && { lte: filters.to }),
        },
      } : {}),
    };

    const limit = Math.min(filters.limit ?? 50, 200);
    const logs = await this.prisma.auditLog.findMany({
      where,
      orderBy: { timestamp: 'desc' },
      take: limit + 1,
      ...(filters.cursor && { cursor: { id: filters.cursor }, skip: 1 }),
      include: {
        user: { select: { name: true, email: true } },
      },
    });

    const hasMore = logs.length > limit;
    return {
      data: logs.slice(0, limit),
      hasMore,
      nextCursor: hasMore ? logs[limit - 1]?.id : undefined,
    };
  }
}
