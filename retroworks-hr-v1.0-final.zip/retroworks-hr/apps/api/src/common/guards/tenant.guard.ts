import {
  Injectable,
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Request } from 'express';

export const SKIP_TENANT_CHECK = 'skipTenantCheck';
export const SkipTenantCheck = () =>
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (target: any, key?: string, descriptor?: PropertyDescriptor) => {
    if (descriptor) {
      Reflect.defineMetadata(SKIP_TENANT_CHECK, true, descriptor.value as object);
      return descriptor;
    }
    Reflect.defineMetadata(SKIP_TENANT_CHECK, true, target);
    return target;
  };

interface AuthRequest extends Request {
  user?: {
    sub: string;
    tid: string;
    email: string;
    roles: string[];
    sessionId: string;
  };
}

@Injectable()
export class TenantGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const skipTenantCheck = this.reflector.getAllAndOverride<boolean>(
      SKIP_TENANT_CHECK,
      [context.getHandler(), context.getClass()],
    );

    if (skipTenantCheck) return true;

    const request = context.switchToHttp().getRequest<AuthRequest>();

    if (!request.user) {
      throw new UnauthorizedException('Authentication required');
    }

    const tokenTenantId = request.user.tid;
    const headerTenantId = request.headers['x-tenant-id'];
    const paramTenantId = (request.params as Record<string, string>)['tenantId'];

    // Validate tenant consistency
    if (headerTenantId && headerTenantId !== tokenTenantId) {
      throw new ForbiddenException('Tenant mismatch');
    }

    if (paramTenantId && paramTenantId !== tokenTenantId && !request.user.roles.includes('super-admin')) {
      throw new ForbiddenException('Cross-tenant access denied');
    }

    return true;
  }
}
