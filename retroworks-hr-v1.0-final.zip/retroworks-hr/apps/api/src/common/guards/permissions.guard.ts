/**
 * Permissions Guard — RBAC + ABAC with Redis Permission Cache
 * ═══════════════════════════════════════════════════════════════════════════
 * AUDIT-07: Integrated PermissionCacheService — cache-first lookup, DB fallback.
 *           Role changes now immediately invalidate cache via tenant sentinel.
 *
 * Flow:
 *   1. Check cache (rw:perm:<tid>:<uid>) — verify against tenant sentinel
 *   2. On miss/stale: load from DB, write to cache (TTL 5min)
 *   3. Evaluate required permissions + ABAC conditions
 */

import {
  Injectable, CanActivate, ExecutionContext,
  ForbiddenException, Logger,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PrismaClient } from '@prisma/client';
import type { JwtPayload, Permission, PolicyCondition } from '@retroworks/types';
import { PERMISSIONS_KEY, ROLES_KEY, type RequiredPermission } from '../decorators/permissions.decorator';
import { PermissionCacheService, type CachedPermissions } from '../security/permission-cache.service';

interface AuthRequest {
  user: JwtPayload;
  params: Record<string, string>;
  body: Record<string, unknown>;
  query: Record<string, string>;
}

@Injectable()
export class PermissionsGuard implements CanActivate {
  private readonly logger = new Logger(PermissionsGuard.name);

  constructor(
    private readonly reflector: Reflector,
    private readonly prisma: PrismaClient,
    private readonly permCache: PermissionCacheService, // AUDIT-07: injected
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredPermissions = this.reflector.getAllAndOverride<RequiredPermission[]>(
      PERMISSIONS_KEY, [context.getHandler(), context.getClass()],
    );
    const requiredRoles = this.reflector.getAllAndOverride<string[]>(
      ROLES_KEY, [context.getHandler(), context.getClass()],
    );

    if (!requiredPermissions?.length && !requiredRoles?.length) return true;

    const request = context.switchToHttp().getRequest<AuthRequest>();
    const user = request.user;
    if (!user) throw new ForbiddenException('User context missing');

    // Super-admin bypass
    if (user.roles.includes('super-admin')) return true;

    // Role check (from JWT — fast, no DB)
    if (requiredRoles?.length) {
      const hasRole = requiredRoles.some(r => user.roles.includes(r));
      if (hasRole) return true;
    }

    // Permission check — cache-first
    if (requiredPermissions?.length) {
      const cachedPerms = await this.loadPermissions(user);
      const hasPermission = await this.evaluatePermissions(cachedPerms, requiredPermissions, user, request);
      if (!hasPermission) throw new ForbiddenException('Insufficient permissions');
    }

    return true;
  }

  /** AUDIT-07: Cache-first permission loading with sentinel validation */
  private async loadPermissions(user: JwtPayload): Promise<CachedPermissions> {
    // 1. Try cache
    const cached = await this.permCache.getPermissions(user.tid, user.sub);
    if (cached) {
      const valid = await this.permCache.isCacheValid(cached);
      if (valid) return cached;
      this.logger.debug(`Cache stale (sentinel bumped) for user=${user.sub} — reloading from DB`);
    }

    // 2. Cache miss or stale — load from DB
    const userRoles = await this.prisma.role.findMany({
      where: {
        tenantId: user.tid,
        users: { some: { userId: user.sub } },
      },
      select: { name: true, permissions: true },
    });

    const allPermissions = userRoles.flatMap(r => r.permissions as Permission[]);
    const roleNames = userRoles.map(r => r.name);

    const fresh: CachedPermissions = {
      userId: user.sub,
      tenantId: user.tid,
      roles: roleNames,
      permissions: allPermissions.map(p => ({
        resource: p.resource,
        action: p.action,
        conditions: p.conditions,
      })),
      cachedAt: Date.now(),
    };

    // 3. Write back to cache
    await this.permCache.setPermissions(fresh);
    return fresh;
  }

  private async evaluatePermissions(
    cached: CachedPermissions,
    required: RequiredPermission[],
    user: JwtPayload,
    request: AuthRequest,
  ): Promise<boolean> {
    for (const req of required) {
      const match = cached.permissions.find(
        p => p.resource === req.resource && p.action === req.action,
      );

      if (!match) {
        this.logger.warn(`User ${user.sub} missing permission ${req.resource}:${req.action}`);
        return false;
      }

      if (match.conditions?.length) {
        const met = this.evaluateConditions(match.conditions as PolicyCondition[], user, request);
        if (!met) return false;
      }
    }
    return true;
  }

  private evaluateConditions(
    conditions: PolicyCondition[],
    user: JwtPayload,
    request: AuthRequest,
  ): boolean {
    for (const c of conditions) {
      const value = this.resolveValue(c.field, user, request);
      switch (c.operator) {
        case 'eq':  if (value !== c.value) return false; break;
        case 'neq': if (value === c.value) return false; break;
        case 'in':  if (!Array.isArray(c.value) || !c.value.includes(value)) return false; break;
        case 'not-in': if (Array.isArray(c.value) && c.value.includes(value)) return false; break;
      }
    }
    return true;
  }

  private resolveValue(field: string, user: JwtPayload, request: AuthRequest): unknown {
    const [scope, key] = field.split('.') as [string, string];
    switch (scope) {
      case 'user':   return (user as Record<string, unknown>)[key];
      case 'params': return request.params[key];
      case 'body':   return request.body[key];
      case 'query':  return request.query[key];
      default:       return undefined;
    }
  }
}
