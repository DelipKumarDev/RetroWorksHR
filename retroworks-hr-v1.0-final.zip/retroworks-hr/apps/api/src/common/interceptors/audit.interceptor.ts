import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
  Logger,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Request } from 'express';

interface AuthRequest extends Request {
  user?: {
    sub: string;
    tid: string;
    email: string;
    sessionId: string;
  };
  requestId?: string;
}

@Injectable()
export class AuditInterceptor implements NestInterceptor {
  private readonly logger = new Logger('Audit');

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const request = context.switchToHttp().getRequest<AuthRequest>();
    const { method, url, user, ip } = request;

    // Only audit mutating requests
    if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) {
      return next.handle();
    }

    const startTime = Date.now();

    return next.handle().pipe(
      tap({
        next: () => {
          this.logger.log({
            type: 'AUDIT',
            method,
            url,
            userId: user?.sub,
            tenantId: user?.tid,
            sessionId: user?.sessionId,
            ip,
            duration: Date.now() - startTime,
            requestId: request.requestId,
            status: 'success',
          });
        },
        error: (error: unknown) => {
          this.logger.warn({
            type: 'AUDIT',
            method,
            url,
            userId: user?.sub,
            tenantId: user?.tid,
            ip,
            duration: Date.now() - startTime,
            status: 'error',
            error: error instanceof Error ? error.message : String(error),
          });
        },
      }),
    );
  }
}
