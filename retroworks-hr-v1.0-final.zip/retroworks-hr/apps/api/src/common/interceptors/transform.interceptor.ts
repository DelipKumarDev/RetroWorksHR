import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { v4 as uuid } from 'uuid';

@Injectable()
export class TransformInterceptor implements NestInterceptor {
  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const requestId = uuid();
    const request = context.switchToHttp().getRequest<{ requestId?: string }>();
    request.requestId = requestId;

    return next.handle().pipe(
      map((data: unknown) => ({
        success: true,
        data,
        meta: {
          requestId,
          timestamp: new Date().toISOString(),
          version: '1.0',
        },
      })),
    );
  }
}
