import {
  Injectable, NestInterceptor, ExecutionContext, CallHandler, Logger,
} from '@nestjs/common';
import { Observable, throwError } from 'rxjs';
import { map, catchError, tap } from 'rxjs/operators';
import type { Request, Response } from 'express';

/**
 * Response Transform Interceptor
 * Wraps all successful responses in a standard envelope:
 * { success: true, data: ..., meta?: ..., timestamp: ... }
 */
@Injectable()
export class ResponseTransformInterceptor<T> implements NestInterceptor<T, unknown> {
  intercept(context: ExecutionContext, next: CallHandler<T>): Observable<unknown> {
    const ctx = context.switchToHttp();
    const response = ctx.getResponse<Response>();

    return next.handle().pipe(
      map(data => {
        // Don't wrap if already wrapped or null/undefined
        if (data === null || data === undefined) return data;
        if (typeof data === 'object' && data !== null && 'success' in data) return data;

        // Extract pagination meta if present
        let payload = data;
        let meta: Record<string, unknown> | undefined;

        if (typeof data === 'object' && data !== null && 'data' in data && 'meta' in data) {
          payload = (data as any).data;
          meta = (data as any).meta;
        }

        return {
          success: true,
          data: payload,
          ...(meta && { meta }),
          timestamp: new Date().toISOString(),
        };
      }),
    );
  }
}

/**
 * Request Logging Interceptor
 * Logs all requests with method, path, status code, and duration.
 */
@Injectable()
export class RequestLoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger('HTTP');

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const ctx = context.switchToHttp();
    const request = ctx.getRequest<Request>();
    const response = ctx.getResponse<Response>();
    const { method, url } = request;
    const startTime = Date.now();

    return next.handle().pipe(
      tap(() => {
        const duration = Date.now() - startTime;
        const statusCode = response.statusCode;

        const logMsg = `${method} ${url} ${statusCode} +${duration}ms`;

        if (statusCode >= 500) this.logger.error(logMsg);
        else if (statusCode >= 400) this.logger.warn(logMsg);
        else if (duration > 2000) this.logger.warn(`SLOW: ${logMsg}`);
        else this.logger.log(logMsg);
      }),
      catchError(err => {
        const duration = Date.now() - startTime;
        this.logger.error(`${method} ${url} ERR +${duration}ms — ${err?.message}`);
        return throwError(() => err);
      }),
    );
  }
}

/**
 * Performance Monitoring Interceptor
 * Tracks slow queries and logs P95 response times
 */
@Injectable()
export class PerformanceInterceptor implements NestInterceptor {
  private readonly logger = new Logger('Performance');
  private readonly SLOW_THRESHOLD_MS = 3000;

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const start = Date.now();
    const ctx = context.switchToHttp();
    const request = ctx.getRequest<Request>();

    return next.handle().pipe(
      tap(() => {
        const duration = Date.now() - start;
        if (duration > this.SLOW_THRESHOLD_MS) {
          this.logger.warn(
            `SLOW ENDPOINT: ${request.method} ${request.url} took ${duration}ms`,
            { body: request.body, query: request.query },
          );
        }
      }),
    );
  }
}
