/**
 * Security Module — Global security services
 * AUDIT-06: FileValidationService added
 * AUDIT-07: PermissionCacheService added (used by PermissionsGuard)
 */
import { Global, Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaTenantService } from './prisma-tenant.service';
import { FieldEncryptionService } from './field-encryption.service';
import { RedisLockService } from './redis-lock.service';
import { FileValidationService } from './file-validation.service';
import { PermissionCacheService } from './permission-cache.service';
import { PrismaClient } from '@prisma/client';

@Global()
@Module({
  imports: [ConfigModule],
  providers: [
    PrismaClient,
    PrismaTenantService,
    FieldEncryptionService,
    RedisLockService,
    FileValidationService,
    PermissionCacheService,
  ],
  exports: [
    PrismaTenantService,
    FieldEncryptionService,
    RedisLockService,
    FileValidationService,
    PermissionCacheService,
  ],
})
export class SecurityModule {}
