/**
 * SECURITY FIX C-01 — Environment Startup Validator
 * ─────────────────────────────────────────────────────
 * Enforces all required environment variables at boot.
 * Application will CRASH with a clear error if any are missing.
 *
 * Usage: call validateEnvironment() as the FIRST statement in main.ts
 * before NestFactory.create()
 */

import { Logger } from '@nestjs/common';
import * as crypto from 'crypto';

const logger = new Logger('EnvValidator');

interface EnvRule {
  key: string;
  description: string;
  required: boolean;
  minLength?: number;
  validator?: (value: string) => boolean;
  validatorMessage?: string;
}

const REQUIRED_ENV_RULES: EnvRule[] = [
  // ── Authentication ────────────────────────────────────────────
  {
    key: 'JWT_SECRET',
    description: 'JWT signing secret (min 64 chars, cryptographically random)',
    required: true,
    minLength: 64,
    validator: (v) => !/CHANGE-ME|retroworks-secret|development|test|placeholder/i.test(v),
    validatorMessage: 'JWT_SECRET must not contain placeholder values',
  },
  {
    key: 'JWT_REFRESH_SECRET',
    description: 'JWT refresh token signing secret (min 64 chars)',
    required: true,
    minLength: 64,
    validator: (v) => !/CHANGE-ME|retroworks-secret|development|test|placeholder/i.test(v),
    validatorMessage: 'JWT_REFRESH_SECRET must not contain placeholder values',
  },
  // ── Database ──────────────────────────────────────────────────
  {
    key: 'DATABASE_URL',
    description: 'PostgreSQL connection string',
    required: true,
    validator: (v) => v.startsWith('postgresql://') || v.startsWith('postgres://'),
    validatorMessage: 'DATABASE_URL must be a valid PostgreSQL connection string',
  },
  // ── Encryption ────────────────────────────────────────────────
  {
    key: 'ENCRYPTION_KEY',
    description: 'AES-256 field encryption key (64-char hex = 32 bytes)',
    required: true,
    minLength: 64,
    validator: (v) => /^[0-9a-fA-F]{64}$/.test(v),
    validatorMessage: 'ENCRYPTION_KEY must be exactly 64 hex characters (32 bytes)',
  },
  // ── Redis ─────────────────────────────────────────────────────
  {
    key: 'REDIS_URL',
    description: 'Redis connection URL',
    required: true,
    validator: (v) => v.startsWith('redis://') || v.startsWith('rediss://'),
    validatorMessage: 'REDIS_URL must start with redis:// or rediss://',
  },
  // ── Frontend CORS ─────────────────────────────────────────────
  {
    key: 'ALLOWED_ORIGINS',
    description: 'Comma-separated list of allowed CORS origins',
    required: true,
    validator: (v) => !v.includes('*'),
    validatorMessage: 'ALLOWED_ORIGINS must not contain wildcard (*) in production',
  },
  // ── Magic link ────────────────────────────────────────────────
  {
    key: 'MAGIC_LINK_SECRET',
    description: 'Magic link signing secret (min 32 chars)',
    required: true,
    minLength: 32,
    validator: (v) => !/CHANGE-ME|placeholder/i.test(v),
    validatorMessage: 'MAGIC_LINK_SECRET must not be a placeholder',
  },
];

const WARN_ENV_RULES: EnvRule[] = [
  {
    key: 'AWS_S3_BUCKET',
    description: 'S3 bucket for file storage',
    required: false,
  },
  {
    key: 'BACKUP_ENCRYPTION_KEY',
    description: 'Key for encrypting database backups',
    required: false,
    minLength: 32,
  },
  {
    key: 'FRONTEND_URL',
    description: 'Frontend application URL',
    required: false,
    validator: (v) => v.startsWith('https://') || v === 'http://localhost:3000',
    validatorMessage: 'FRONTEND_URL should use HTTPS in production',
  },
];

export function validateEnvironment(): void {
  const errors: string[] = [];
  const warnings: string[] = [];
  const nodeEnv = process.env['NODE_ENV'] ?? 'development';
  const isProduction = nodeEnv === 'production';

  logger.log(`🔐 Validating environment [NODE_ENV=${nodeEnv}]...`);

  for (const rule of REQUIRED_ENV_RULES) {
    const value = process.env[rule.key];

    if (!value || value.trim() === '') {
      errors.push(
        `[MISSING] ${rule.key}: ${rule.description}\n` +
        `  → Generate: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"`,
      );
      continue;
    }

    if (rule.minLength && value.length < rule.minLength) {
      errors.push(
        `[TOO SHORT] ${rule.key}: Must be at least ${rule.minLength} characters (got ${value.length})\n` +
        `  → Generate: node -e "console.log(require('crypto').randomBytes(${Math.ceil(rule.minLength / 2)}).toString('hex'))"`,
      );
      continue;
    }

    if (rule.validator && !rule.validator(value)) {
      errors.push(`[INVALID] ${rule.key}: ${rule.validatorMessage ?? 'Validation failed'}`);
      continue;
    }
  }

  // In production, additional strict checks
  if (isProduction) {
    if ((process.env['NODE_ENV'] === 'production') && !process.env['ALLOWED_ORIGINS']?.includes('https://')) {
      warnings.push('[WARN] ALLOWED_ORIGINS should use HTTPS origins in production');
    }

    const dbUrl = process.env['DATABASE_URL'] ?? '';
    if (dbUrl.includes('localhost') || dbUrl.includes('127.0.0.1')) {
      warnings.push('[WARN] DATABASE_URL points to localhost — ensure this is intentional in production');
    }
  }

  // Optional warns
  for (const rule of WARN_ENV_RULES) {
    const value = process.env[rule.key];
    if (!value && isProduction) {
      warnings.push(`[OPTIONAL] ${rule.key} not set: ${rule.description}`);
    } else if (value && rule.validator && !rule.validator(value) && isProduction) {
      warnings.push(`[WARN] ${rule.key}: ${rule.validatorMessage}`);
    }
  }

  // Print warnings
  if (warnings.length > 0) {
    logger.warn('⚠️  Environment warnings:');
    for (const w of warnings) logger.warn(`  ${w}`);
  }

  // Fatal errors
  if (errors.length > 0) {
    logger.error('╔══════════════════════════════════════════════════════════════╗');
    logger.error('║       FATAL: Environment validation failed                   ║');
    logger.error('║  Application cannot start until all issues are resolved.     ║');
    logger.error('╚══════════════════════════════════════════════════════════════╝');
    logger.error('');
    for (const err of errors) {
      logger.error(`  ✗ ${err}`);
      logger.error('');
    }
    logger.error('Run: node scripts/generate-secrets.js  to create a secure .env file');
    process.exit(1);
  }

  logger.log(`✅ Environment validated — ${REQUIRED_ENV_RULES.length} required variables OK`);
}

/**
 * Generate a cryptographically secure random hex string
 * Utility for secret rotation scripts
 */
export function generateSecret(bytes = 64): string {
  return crypto.randomBytes(bytes).toString('hex');
}

/**
 * Verify a JWT secret meets minimum security requirements
 * Used in tests and key rotation validation
 */
export function isSecureSecret(value: string): boolean {
  if (!value || value.length < 64) return false;
  if (/CHANGE-ME|retroworks-secret|development|test|placeholder/i.test(value)) return false;
  return true;
}
