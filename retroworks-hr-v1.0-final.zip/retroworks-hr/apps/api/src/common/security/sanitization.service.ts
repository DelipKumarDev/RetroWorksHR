/**
 * SECURITY FIX H-04 — Message Sanitization Service
 * ──────────────────────────────────────────────────
 * Prevents stored XSS in ticket messages, announcements, KB articles.
 * Uses an allowlist approach — only safe HTML tags/attributes pass through.
 *
 * SECURITY FIX H-05 — Strict Employee & Settings DTOs
 * Prevents mass assignment via whitelisted class-validator DTOs.
 */

// ─────────────────────────────────────────────────────────────────────────────
// H-04: HTML Sanitization (server-side)
// ─────────────────────────────────────────────────────────────────────────────

import { Injectable, Logger } from '@nestjs/common';
import { IsEmail, IsString, IsOptional, IsBoolean, IsNumber,
  MinLength, MaxLength, IsEnum, IsArray, Min, Max,
  IsNotEmpty, IsIn } from 'class-validator';
import { Transform, Expose } from 'class-transformer';

// Pure server-side HTML sanitizer (no DOM required)
// Allowlist: only these tags and attributes are preserved
const ALLOWED_TAGS = new Set(['b', 'i', 'strong', 'em', 'u', 's', 'br', 'p',
  'ul', 'ol', 'li', 'blockquote', 'code', 'pre', 'h1', 'h2', 'h3', 'h4']);
const ALLOWED_ATTRS = new Set(['class', 'id']);

/**
 * Sanitizes HTML content server-side.
 * Strips all tags not in the allowlist, removes all event handlers,
 * and neutralizes javascript: URLs.
 */
export function sanitizeHtml(input: string, maxLength = 50000): string {
  if (!input || typeof input !== 'string') return '';

  // Length cap first
  let text = input.slice(0, maxLength);

  // Remove script and style blocks entirely
  text = text.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, '');
  text = text.replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, '');
  text = text.replace(/<link[^>]*>/gi, '');

  // Remove all event handlers (onclick, onmouseover, etc.)
  text = text.replace(/\s+on\w+\s*=\s*["'][^"']*["']/gi, '');
  text = text.replace(/\s+on\w+\s*=\s*[^\s>]*/gi, '');

  // Neutralize javascript: URLs
  text = text.replace(/javascript\s*:/gi, 'blocked:');
  text = text.replace(/data\s*:/gi, 'blocked:');
  text = text.replace(/vbscript\s*:/gi, 'blocked:');

  // Strip disallowed HTML tags while keeping their text content
  text = text.replace(/<\/?([a-zA-Z][a-zA-Z0-9]*)[^>]*>/g, (match, tag) => {
    const tagLower = (tag as string).toLowerCase();
    if (ALLOWED_TAGS.has(tagLower)) {
      // Keep the tag but strip all non-whitelisted attributes
      return match.replace(/\s+([a-zA-Z-]+)\s*=\s*["'][^"']*["']/g, (attrMatch, attrName) => {
        return ALLOWED_ATTRS.has((attrName as string).toLowerCase()) ? attrMatch : '';
      });
    }
    return ''; // Remove the tag entirely
  });

  // Encode remaining angle brackets that aren't part of allowed tags
  // (catches any edge cases)
  text = text.replace(/&(?!#?[a-zA-Z0-9]+;)/g, '&amp;');

  return text.trim();
}

/**
 * Sanitize plain text — strips all HTML, returns plain text only.
 * Use for fields that should never contain HTML (names, titles, etc.)
 */
export function sanitizePlainText(input: string, maxLength = 500): string {
  if (!input || typeof input !== 'string') return '';
  return input
    .replace(/<[^>]*>/g, '') // Strip all HTML
    .replace(/[<>&"']/g, (c) => ({ '<':'&lt;', '>':'&gt;', '&':'&amp;', '"':'&quot;', "'":"&#39;" }[c] ?? c))
    .trim()
    .slice(0, maxLength);
}

@Injectable()
export class ContentSanitizer {
  private readonly logger = new Logger(ContentSanitizer.name);

  sanitizeTicketMessage(body: string, isInternal: boolean): string {
    if (!body?.trim()) return '';
    const sanitized = sanitizeHtml(body, 100_000); // 100k chars max for ticket body
    if (sanitized !== body) {
      this.logger.warn('[SECURITY] XSS attempt sanitized in ticket message');
    }
    return sanitized;
  }

  sanitizeAnnouncementContent(html: string): string {
    return sanitizeHtml(html, 50_000);
  }

  sanitizeKbArticleContent(markdown: string): string {
    // KB uses Markdown — strip any injected HTML
    return sanitizeHtml(markdown, 200_000);
  }

  sanitizeSubject(subject: string): string {
    return sanitizePlainText(subject, 255);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// H-05: Strict Employee Update DTO
// ─────────────────────────────────────────────────────────────────────────────

export class UpdateEmployeeDto {
  @IsOptional() @IsString() @MaxLength(100)
  firstName?: string;

  @IsOptional() @IsString() @MaxLength(100)
  lastName?: string;

  @IsOptional() @IsEmail()
  personalEmail?: string;

  @IsOptional() @IsString() @MaxLength(20)
  phone?: string;

  @IsOptional() @IsString() @MaxLength(255)
  address?: string;

  @IsOptional() @IsString() @MaxLength(100)
  city?: string;

  @IsOptional() @IsString() @MaxLength(10)
  pincode?: string;

  @IsOptional() @IsString() @MaxLength(500)
  emergencyContactName?: string;

  @IsOptional() @IsString() @MaxLength(20)
  emergencyContactPhone?: string;

  @IsOptional() @IsString() @MaxLength(100)
  designation?: string;

  @IsOptional() @IsString()
  departmentId?: string;

  @IsOptional() @IsString()
  managerId?: string;

  @IsOptional() @IsString()
  locationId?: string;

  @IsOptional() @IsIn(['active', 'inactive', 'on-leave', 'notice-period', 'terminated'])
  status?: string;

  @IsOptional() @IsString()
  dateOfBirth?: string;

  @IsOptional() @IsString()
  dateOfJoining?: string;

  @IsOptional() @IsString()
  dateOfExit?: string;

  // Fields that CANNOT be updated through this DTO:
  // tenantId — protected (cannot change tenant)
  // role — managed through RBAC endpoints only
  // isAdmin — managed through RBAC endpoints only
  // id — never updatable
  // passwordHash — changed through /auth/change-password only
}

export class CreateEmployeeDto {
  @IsString() @IsNotEmpty() @MaxLength(100)
  firstName!: string;

  @IsString() @IsNotEmpty() @MaxLength(100)
  lastName!: string;

  @IsEmail()
  email!: string;

  @IsString() @IsNotEmpty() @MaxLength(50)
  employeeCode!: string;

  @IsString()
  departmentId!: string;

  @IsOptional() @IsString()
  designationId?: string;

  @IsOptional() @IsString()
  managerId?: string;

  @IsOptional() @IsString()
  locationId?: string;

  @IsString()
  dateOfJoining!: string;

  @IsOptional() @IsIn(['full-time', 'part-time', 'contract', 'intern'])
  employmentType?: string;

  // PROTECTED — these fields cannot be set by clients
  // tenantId: injected from JWT
  // createdBy: injected from JWT
  // passwordHash: set during onboarding/magic-link flow
}

// ─────────────────────────────────────────────────────────────────────────────
// H-05: Strict Settings Update DTOs
// ─────────────────────────────────────────────────────────────────────────────

export class UpdateTenantSettingsDto {
  @IsOptional() @IsString() @MaxLength(100)
  companyName?: string;

  @IsOptional() @IsString() @MaxLength(500)
  companyAddress?: string;

  @IsOptional() @IsEmail()
  contactEmail?: string;

  @IsOptional() @IsString() @MaxLength(15)
  contactPhone?: string;

  @IsOptional() @IsString() @MaxLength(50)
  timezone?: string;

  @IsOptional() @IsIn(['INR', 'USD', 'GBP', 'EUR', 'AED', 'SGD'])
  currency?: string;

  @IsOptional() @IsString() @MaxLength(500)
  logoUrl?: string;

  @IsOptional() @IsBoolean()
  mfaRequired?: boolean;

  @IsOptional() @IsNumber() @Min(1) @Max(365)
  sessionTimeoutDays?: number;

  @IsOptional() @IsBoolean()
  allowMagicLink?: boolean;

  @IsOptional() @IsBoolean()
  auditLogEnabled?: boolean;

  // PROTECTED — cannot be set via settings API:
  // tenantId, isActive, plan, trialEndsAt, subscriptionId
}

export class UpdateLeaveSettingsDto {
  @IsOptional() @IsNumber() @Min(0) @Max(365)
  annualLeaveQuota?: number;

  @IsOptional() @IsNumber() @Min(0) @Max(365)
  sickLeaveQuota?: number;

  @IsOptional() @IsBoolean()
  allowLeaveEncashment?: boolean;

  @IsOptional() @IsBoolean()
  requireManagerApproval?: boolean;

  @IsOptional() @IsNumber() @Min(1) @Max(365)
  advanceNoticeDays?: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// H-05: Login DTO (stricter)
// ─────────────────────────────────────────────────────────────────────────────

export class StrictLoginDto {
  @IsEmail() @Transform(({ value }) => (value as string).toLowerCase().trim())
  email!: string;

  @IsString() @MinLength(8) @MaxLength(128)
  password!: string;

  @IsOptional() @IsString() @MaxLength(100)
  tenantSlug?: string;

  @IsOptional() @IsString() @MaxLength(6) // TOTP code
  totpCode?: string;

  // PROTECTED — these fields are NEVER accepted from client:
  // role, tenantId, isAdmin, permissions — all come from DB/JWT
}
