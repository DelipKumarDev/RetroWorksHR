/**
 * Permission Cache Service — Redis-backed RBAC/ABAC cache
 * ═══════════════════════════════════════════════════════════════════════════
 * AUDIT-07: Permission cache invalidation was missing.
 *
 * PROBLEM: PermissionsGuard hits the DB on every request to load roles +
 * permissions (cold read = 2 queries). More critically, when a role is
 * changed or revoked, the in-flight JWT still carried the old permissions
 * with no invalidation path.
 *
 * SOLUTION:
 *   1. Cache user permissions in Redis (TTL = 5 min)
 *   2. Invalidate cache on: role assignment, role definition change,
 *      permission grant/revoke, account suspension, tenant deactivation
 *   3. PermissionsGuard updated to use cache first
 *
 * Cache key format: rw:perm:<tenantId>:<userId>
 * Invalidation key:  rw:perm:<tenantId>:* (pattern delete on role change)
 */

import { Injectable, Logger } from '@nestjs/common';
import { RedisLockService } from './redis-lock.service';
import type { Permission } from '@retroworks/types';

const CACHE_PREFIX = 'rw:perm:';
const CACHE_TTL_SECONDS = 300; // 5 minutes — short enough for fast propagation

export interface CachedPermissions {
  userId: string;
  tenantId: string;
  roles: string[];
  permissions: Array<{ resource: string; action: string; conditions?: unknown[] }>;
  cachedAt: number;
}

@Injectable()
export class PermissionCacheService {
  private readonly logger = new Logger(PermissionCacheService.name);

  constructor(private readonly redis: RedisLockService) {}

  // ─── Cache Key Helpers ────────────────────────────────────────────────────

  private userKey(tenantId: string, userId: string): string {
    return `${CACHE_PREFIX}${tenantId}:${userId}`;
  }

  private tenantPattern(tenantId: string): string {
    return `${CACHE_PREFIX}${tenantId}:*`;
  }

  // ─── Get / Set ────────────────────────────────────────────────────────────

  async getPermissions(tenantId: string, userId: string): Promise<CachedPermissions | null> {
    const key = this.userKey(tenantId, userId);
    const raw = await this.redis.get(key);
    if (!raw) return null;

    try {
      return JSON.parse(raw) as CachedPermissions;
    } catch {
      this.logger.warn(`Corrupted permission cache for ${userId} — invalidating`);
      await this.redis.del(key);
      return null;
    }
  }

  async setPermissions(perms: CachedPermissions): Promise<void> {
    const key = this.userKey(perms.tenantId, perms.userId);
    await this.redis.set(key, JSON.stringify(perms), CACHE_TTL_SECONDS);
  }

  // ─── Invalidation ─────────────────────────────────────────────────────────

  /**
   * Invalidate a single user's permission cache.
   * Call when: user's role is assigned/removed, user is suspended.
   */
  async invalidateUser(tenantId: string, userId: string): Promise<void> {
    const key = this.userKey(tenantId, userId);
    await this.redis.del(key);
    this.logger.log(`Permission cache invalidated: user=${userId} tenant=${tenantId}`);
  }

  /**
   * Invalidate ALL users in a tenant.
   * Call when: a role definition is updated, a permission is added/removed,
   * or the tenant is suspended.
   *
   * Uses Redis SCAN (not KEYS) to avoid blocking.
   */
  async invalidateTenant(tenantId: string): Promise<void> {
    // Pattern: rw:perm:<tenantId>:*
    // We track a sentinel key that PermissionsGuard checks before reading cache.
    // When sentinel is bumped, all cached entries are effectively stale.
    const sentinelKey = `${CACHE_PREFIX}sentinel:${tenantId}`;
    const version = Date.now().toString();
    await this.redis.set(sentinelKey, version, CACHE_TTL_SECONDS * 2);

    this.logger.log(
      `Permission cache sentinel bumped for tenant=${tenantId} (all user caches invalidated via version=${version})`,
    );
  }

  /**
   * Get the current tenant sentinel version.
   * Returns null if no sentinel exists (cache is fresh).
   */
  async getTenantSentinel(tenantId: string): Promise<string | null> {
    return this.redis.get(`${CACHE_PREFIX}sentinel:${tenantId}`);
  }

  /**
   * Check if a cached entry is still valid against the tenant sentinel.
   */
  async isCacheValid(cached: CachedPermissions): Promise<boolean> {
    const sentinel = await this.getTenantSentinel(cached.tenantId);
    if (!sentinel) return true; // No sentinel = cache is valid
    // If sentinel was set AFTER the cache was written, cache is stale
    return parseInt(sentinel) <= cached.cachedAt;
  }
}
