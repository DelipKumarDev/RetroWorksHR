/**
 * SECURITY FIX C-04 + H-01 — Redis Distributed Lock & Rate Limiter
 * ──────────────────────────────────────────────────────────────────
 * Provides:
 *   1. Distributed lock for payroll runs (C-04 — double-run prevention)
 *   2. Login rate limiter with account lockout (H-01 — brute force protection)
 *   3. Generic cron job idempotency lock (M-06)
 *
 * Uses Redis SET NX EX pattern — safe for single-instance and clustered Redis.
 */

import { Injectable, Logger, ConflictException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { createClient, type RedisClientType } from 'redis';

const LOCK_PREFIX = 'rw:lock:';
const LOGIN_ATTEMPTS_PREFIX = 'rw:login:attempts:';
const LOGIN_LOCKOUT_PREFIX = 'rw:login:lockout:';
const CRON_LOCK_PREFIX = 'rw:cron:';

@Injectable()
export class RedisLockService {
  private readonly logger = new Logger(RedisLockService.name);
  private client: RedisClientType;
  private connected = false;

  private readonly maxLoginAttempts: number;
  private readonly loginWindowSeconds: number;
  private readonly lockoutSeconds: number;

  constructor(private readonly config: ConfigService) {
    this.maxLoginAttempts = config.get<number>('app.rateLimit.loginMaxAttempts') ?? 5;
    this.loginWindowSeconds = Math.floor((config.get<number>('app.rateLimit.loginWindowMs') ?? 900000) / 1000);
    this.lockoutSeconds = this.loginWindowSeconds; // Same window = 15 min lockout

    const redisUrl = config.get<string>('app.redis.url') ?? 'redis://localhost:6379';
    const useTls = config.get<boolean>('app.redis.tls') ?? false;

    this.client = createClient({
      url: redisUrl,
      socket: { tls: useTls, rejectUnauthorized: useTls },
    }) as RedisClientType;

    this.client.on('error', (err) => {
      this.logger.error('Redis connection error:', err.message);
      this.connected = false;
    });
    this.client.on('connect', () => {
      this.connected = true;
      this.logger.log('Redis connected');
    });

    void this.client.connect();
  }

  // ─── Distributed Payroll Lock ─────────────────────────────────────────────

  /**
   * Acquire a distributed lock for a payroll run.
   * Returns a release function — MUST be called in finally block.
   *
   * @throws ConflictException if lock is already held (another run in progress)
   */
  async acquirePayrollLock(
    tenantId: string,
    month: number,
    year: number,
    ttlSeconds?: number,
  ): Promise<() => Promise<void>> {
    const key = `${LOCK_PREFIX}payroll:${tenantId}:${year}:${month}`;
    const lockToken = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const ttl = ttlSeconds ?? (this.config.get<number>('app.payroll.runLockTtlSeconds') ?? 300);

    if (!this.connected) {
      this.logger.warn('Redis unavailable — using in-memory fallback for payroll lock (not safe for multi-instance)');
      // Fallback: allow but warn. The DB unique constraint is the safety net.
    }

    try {
      const result = await this.client.set(key, lockToken, { NX: true, EX: ttl });

      if (result !== 'OK') {
        const ttlRemaining = await this.client.ttl(key);
        this.logger.warn(`Payroll lock contention: ${tenantId} ${month}/${year} — another run in progress (~${ttlRemaining}s remaining)`);
        throw new ConflictException(
          `Payroll run for ${month}/${year} is already in progress. Please wait ${Math.max(1, ttlRemaining)} seconds and retry.`
        );
      }

      this.logger.log(`Payroll lock acquired: ${tenantId} ${month}/${year} (TTL: ${ttl}s)`);

      return async () => {
        // Only release if we still own the lock (prevents releasing another instance's lock)
        const current = await this.client.get(key);
        if (current === lockToken) {
          await this.client.del(key);
          this.logger.log(`Payroll lock released: ${tenantId} ${month}/${year}`);
        }
      };
    } catch (err) {
      if (err instanceof ConflictException) throw err;
      this.logger.error('Redis lock error — falling through (DB constraint is safety net):', (err as Error).message);
      return async () => {}; // No-op release if Redis unavailable
    }
  }

  // ─── Cron Job Idempotency Lock ─────────────────────────────────────────────

  /**
   * Acquire a lock for a cron job.
   * Returns false if another instance already holds the lock.
   */
  async acquireCronLock(jobName: string, ttlSeconds = 300): Promise<boolean> {
    const key = `${CRON_LOCK_PREFIX}${jobName}`;
    try {
      const result = await this.client.set(key, 'running', { NX: true, EX: ttlSeconds });
      if (result === 'OK') {
        this.logger.debug(`Cron lock acquired: ${jobName}`);
        return true;
      }
      this.logger.debug(`Cron lock held by another instance: ${jobName} — skipping`);
      return false;
    } catch {
      this.logger.warn(`Cron lock failed for ${jobName} — proceeding without lock`);
      return true; // Allow execution if Redis is unavailable
    }
  }

  async releaseCronLock(jobName: string): Promise<void> {
    const key = `${CRON_LOCK_PREFIX}${jobName}`;
    try {
      await this.client.del(key);
    } catch {
      // Best effort
    }
  }

  // ─── Login Rate Limiter ───────────────────────────────────────────────────

  /**
   * Record a failed login attempt. Returns current attempt count.
   * Auto-expires after loginWindowSeconds.
   */
  async recordFailedLogin(identifier: string): Promise<{ attempts: number; locked: boolean }> {
    const attemptsKey = `${LOGIN_ATTEMPTS_PREFIX}${identifier}`;
    const lockoutKey = `${LOGIN_LOCKOUT_PREFIX}${identifier}`;

    try {
      const attempts = await this.client.incr(attemptsKey);

      // Set TTL on first failure
      if (attempts === 1) {
        await this.client.expire(attemptsKey, this.loginWindowSeconds);
      }

      if (attempts >= this.maxLoginAttempts) {
        await this.client.set(lockoutKey, 'locked', { EX: this.lockoutSeconds });
        this.logger.warn(`[SECURITY] Account locked after ${attempts} failed attempts: ${identifier}`);
        return { attempts, locked: true };
      }

      return { attempts, locked: false };
    } catch {
      return { attempts: 0, locked: false }; // Allow if Redis unavailable
    }
  }

  /**
   * Check if an account is currently locked out.
   */
  async isLockedOut(identifier: string): Promise<{ locked: boolean; remainingSeconds: number }> {
    const lockoutKey = `${LOGIN_LOCKOUT_PREFIX}${identifier}`;
    try {
      const locked = await this.client.exists(lockoutKey);
      if (!locked) return { locked: false, remainingSeconds: 0 };

      const ttl = await this.client.ttl(lockoutKey);
      return { locked: true, remainingSeconds: Math.max(0, ttl) };
    } catch {
      return { locked: false, remainingSeconds: 0 };
    }
  }

  /**
   * Clear failed login attempts after a successful login.
   */
  async clearLoginAttempts(identifier: string): Promise<void> {
    const attemptsKey = `${LOGIN_ATTEMPTS_PREFIX}${identifier}`;
    const lockoutKey = `${LOGIN_LOCKOUT_PREFIX}${identifier}`;
    try {
      await this.client.del(attemptsKey);
      await this.client.del(lockoutKey);
    } catch {
      // Best effort
    }
  }

  /**
   * Admin: manually unlock an account (e.g., via support ticket)
   */
  async unlockAccount(identifier: string): Promise<void> {
    await this.clearLoginAttempts(identifier);
    this.logger.log(`Account manually unlocked: ${identifier}`);
  }

  // ─── Generic Cache ─────────────────────────────────────────────────────────

  async get(key: string): Promise<string | null> {
    try { return await this.client.get(key); } catch { return null; }
  }

  async set(key: string, value: string, ttlSeconds?: number): Promise<void> {
    try {
      if (ttlSeconds) await this.client.set(key, value, { EX: ttlSeconds });
      else await this.client.set(key, value);
    } catch (err) {
      this.logger.warn(`Redis set failed for key ${key}:`, (err as Error).message);
    }
  }

  async del(...keys: string[]): Promise<void> {
    try { await this.client.del(keys); } catch {}
  }

  async ping(): Promise<boolean> {
    try {
      const result = await this.client.ping();
      return result === 'PONG';
    } catch {
      return false;
    }
  }
}
