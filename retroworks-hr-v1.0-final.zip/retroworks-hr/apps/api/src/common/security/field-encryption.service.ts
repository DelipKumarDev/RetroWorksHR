/**
 * SECURITY FIX C-03 — Field-Level Encryption Service
 * ─────────────────────────────────────────────────────
 * AES-256-GCM encryption for sensitive fields stored in PostgreSQL.
 * Used for: plugin API keys, webhook secrets, PAN, Aadhar (last 4),
 *           bank account numbers, OAuth tokens.
 *
 * Storage format: <iv_hex>:<authTag_hex>:<ciphertext_hex>
 * IV is unique per encryption operation (prevents IV reuse attacks).
 * Auth tag (16 bytes) validates integrity — tampered ciphertext is rejected.
 *
 * Key rotation: Old ciphertext can be re-encrypted by decrypting with
 * old key and encrypting with new key. See rotateKey() below.
 */

import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const IV_BYTES = 16;
const AUTH_TAG_BYTES = 16;
const KEY_BYTES = 32; // 256 bits
const SEPARATOR = ':';
const ENCRYPTED_PREFIX = 'enc:v1:'; // Version prefix for future migration

@Injectable()
export class FieldEncryptionService {
  private readonly logger = new Logger(FieldEncryptionService.name);
  private readonly key: Buffer;
  private readonly enabled: boolean;

  constructor(private readonly config: ConfigService) {
    const keyHex = config.get<string>('app.encryption.key') ?? '';

    if (!keyHex || keyHex.length !== 64) {
      // In development only — warn but allow empty key (uses dummy key)
      // In production: env-validator.ts will have already crashed the app
      const isDev = config.get<string>('app.env') !== 'production';
      if (isDev) {
        this.logger.warn('[DEV ONLY] ENCRYPTION_KEY not set — using insecure dev key. Never use in production!');
        this.key = Buffer.from('0'.repeat(64), 'hex');
        this.enabled = false;
      } else {
        throw new Error('ENCRYPTION_KEY must be a 64-char hex string (32 bytes). App cannot start.');
      }
    } else {
      this.key = Buffer.from(keyHex, 'hex');
      if (this.key.length !== KEY_BYTES) {
        throw new Error(`ENCRYPTION_KEY decoded to ${this.key.length} bytes, expected ${KEY_BYTES}`);
      }
      this.enabled = true;
    }
  }

  /**
   * Encrypt a string value.
   * Returns: "enc:v1:<iv_hex>:<authTag_hex>:<ciphertext_hex>"
   */
  encrypt(plaintext: string): string {
    if (!plaintext) return plaintext;

    // Idempotent: don't double-encrypt
    if (plaintext.startsWith(ENCRYPTED_PREFIX)) {
      this.logger.warn('encrypt() called on already-encrypted value — skipping');
      return plaintext;
    }

    try {
      const iv = crypto.randomBytes(IV_BYTES);
      const cipher = crypto.createCipheriv(ALGORITHM, this.key, iv);
      cipher.setAAD(Buffer.from('retroworks-hr-v1', 'utf8')); // Additional authenticated data

      const ciphertext = Buffer.concat([
        cipher.update(plaintext, 'utf8'),
        cipher.final(),
      ]);
      const authTag = cipher.getAuthTag();

      return (
        ENCRYPTED_PREFIX +
        iv.toString('hex') + SEPARATOR +
        authTag.toString('hex') + SEPARATOR +
        ciphertext.toString('hex')
      );
    } catch (err: unknown) {
      this.logger.error('Encryption failed', err instanceof Error ? err.message : String(err));
      throw new Error('Field encryption failed');
    }
  }

  /**
   * Decrypt an encrypted value.
   * Returns the original plaintext, or null if invalid.
   * Throws on authentication failure (tampered data).
   */
  decrypt(encrypted: string): string {
    if (!encrypted) return encrypted;

    // Handle unencrypted legacy data gracefully
    if (!encrypted.startsWith(ENCRYPTED_PREFIX)) {
      if (this.enabled) {
        this.logger.warn('decrypt() called on unencrypted value — returning as-is (migration needed)');
      }
      return encrypted;
    }

    try {
      const withoutPrefix = encrypted.slice(ENCRYPTED_PREFIX.length);
      const parts = withoutPrefix.split(SEPARATOR);

      if (parts.length !== 3) {
        throw new Error('Invalid encrypted format — expected 3 parts');
      }

      const [ivHex, authTagHex, ciphertextHex] = parts;
      const iv = Buffer.from(ivHex!, 'hex');
      const authTag = Buffer.from(authTagHex!, 'hex');
      const ciphertext = Buffer.from(ciphertextHex!, 'hex');

      const decipher = crypto.createDecipheriv(ALGORITHM, this.key, iv);
      decipher.setAAD(Buffer.from('retroworks-hr-v1', 'utf8'));
      decipher.setAuthTag(authTag);

      const plaintext = Buffer.concat([
        decipher.update(ciphertext),
        decipher.final(),
      ]);

      return plaintext.toString('utf8');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('Unsupported state') || msg.includes('auth')) {
        this.logger.error('[SECURITY] Authentication tag verification failed — possible data tampering');
        throw new Error('Encrypted field integrity check failed');
      }
      this.logger.error('Decryption failed:', msg);
      throw new Error('Field decryption failed');
    }
  }

  /**
   * Encrypt a JSON object (plugin config, etc.)
   * Encrypts only values marked as secrets in the schema.
   */
  encryptConfig(
    config: Record<string, unknown>,
    secretKeys: string[],
  ): Record<string, unknown> {
    const result = { ...config };
    for (const key of secretKeys) {
      if (result[key] && typeof result[key] === 'string') {
        result[key] = this.encrypt(result[key] as string);
      }
    }
    return result;
  }

  /**
   * Decrypt a JSON object — inverse of encryptConfig
   */
  decryptConfig(
    config: Record<string, unknown>,
    secretKeys: string[],
  ): Record<string, unknown> {
    const result = { ...config };
    for (const key of secretKeys) {
      if (result[key] && typeof result[key] === 'string') {
        result[key] = this.decrypt(result[key] as string);
      }
    }
    return result;
  }

  /**
   * Mask a sensitive value for safe logging.
   * Shows first 4 chars + stars.
   */
  mask(value: string, visibleChars = 4): string {
    if (!value) return '[EMPTY]';
    if (value.startsWith(ENCRYPTED_PREFIX)) return '[ENCRYPTED]';
    if (value.length <= visibleChars) return '[REDACTED]';
    return value.slice(0, visibleChars) + '****';
  }

  /**
   * Check if a value is currently encrypted by this service
   */
  isEncrypted(value: string): boolean {
    return typeof value === 'string' && value.startsWith(ENCRYPTED_PREFIX);
  }

  /**
   * Key rotation helper — re-encrypts a value with the current key.
   * Call with decrypted value from old key, returns ciphertext with new key.
   * In production: use a migration script that processes records in batches.
   */
  reEncrypt(oldPlaintext: string): string {
    return this.encrypt(oldPlaintext);
  }
}

/**
 * Secret keys in each plugin's config schema that should be encrypted.
 * Add new plugin secret keys here.
 */
export const PLUGIN_SECRET_FIELDS: Record<string, string[]> = {
  integration_jira: ['apiToken'],
  integration_gsuite: ['serviceAccountKey'],
  integration_accounting: ['apiSecret', 'password'],
  attendance_biometric: [],
  attendance_gps: [],
  benefits_flexi: ['providerApiKey'],
  benefits_insurance: ['portalPassword'],
  payroll_bank_file: ['bankApiKey'],
  compliance_form16: [],
  compliance_pf_challan: [],
  benefits_nps: [],
  integration_slack: ['botToken', 'signingSecret'],
};
