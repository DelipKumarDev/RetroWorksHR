/**
 * Tenant-Scoped Prisma Service
 * ──────────────────────────────────────────────────────────────────────────────
 * CHANGE LOG
 *   v1.0 — Initial
 *   v1.1 — payrollAdjustment added (AUDIT-PAYROLL-1)
 *   v1.2 — 15 payroll sub-module models added (AUDIT-PAYROLL-2):
 *           employeeTaxDeclaration, tDSProjection, tDSRecalculationLog,
 *           pfEcrRecord, esiContributionRecord, ptReturnRecord,
 *           tdsChallan, tdsReturn, tdsReturnAuditLog, tracesImportLog,
 *           form16Record, form16AuditLog, form16BulkJob,
 *           salaryRevision, arrearEntry
 *
 * $global-only models (no tenantId column — access via scope.$global):
 *   tenant, taxSlab, fyTaxConfig, tdsReturnEmployeeEntry
 *
 * upsert() with compound keys that embed tenantId is UNSAFE here.
 * Use findFirst + create/update instead. Affected models:
 *   employeeTaxDeclaration, tDSProjection, form16Record,
 *   pfEcrRecord, esiContributionRecord, ptReturnRecord, tdsReturn
 */

import { Injectable, Logger, ForbiddenException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

type D = ReturnType<typeof createTenantScopedDelegate>;

function createTenantScopedDelegate<T extends object>(
  delegate: T,
  tenantId: string,
  modelName: string,
  logger: Logger,
): T {
  return new Proxy(delegate, {
    get(target, method: string | symbol) {
      const fn = (target as Record<string, unknown>)[method as string];
      if (typeof fn !== 'function') return fn;

      if (['findFirst','findFirstOrThrow','findMany','findUnique',
           'findUniqueOrThrow','count','aggregate','groupBy'].includes(method as string)) {
        return (args?: Record<string, unknown>) =>
          (fn as Function).call(target, { ...args, where: { ...(args?.where as object ?? {}), tenantId } });
      }

      if (method === 'create') {
        return (args: { data: Record<string, unknown> }) => {
          if (args.data.tenantId && args.data.tenantId !== tenantId) {
            logger.error(`[SECURITY] create ${modelName}: foreign tenantId in data blocked`);
            throw new ForbiddenException('Cross-tenant data creation is not allowed');
          }
          return (fn as Function).call(target, { ...args, data: { ...args.data, tenantId } });
        };
      }

      if (method === 'createMany') {
        return (args: { data: Array<Record<string, unknown>> }) => {
          const safe = args.data.map(r => {
            if (r.tenantId && r.tenantId !== tenantId) {
              logger.error(`[SECURITY] createMany ${modelName}: cross-tenant record blocked`);
              throw new ForbiddenException('Cross-tenant bulk create is not allowed');
            }
            return { ...r, tenantId };
          });
          return (fn as Function).call(target, { ...args, data: safe });
        };
      }

      if (['update','updateMany','delete','deleteMany'].includes(method as string)) {
        return (args: Record<string, unknown>) => {
          if ((args.data as Record<string,unknown>)?.tenantId &&
              (args.data as Record<string,unknown>).tenantId !== tenantId) {
            logger.error(`[SECURITY] ${method as string} ${modelName}: tenantId mutation blocked`);
            throw new ForbiddenException('Cannot modify tenantId field');
          }
          return (fn as Function).call(target, { ...args, where: { ...(args.where as object ?? {}), tenantId } });
        };
      }

      // upsert intentionally excluded — callers must use findFirst + create/update
      return fn;
    },
  });
}

export interface TenantScopedDb {
  readonly employee:              D;
  readonly user:                  D;
  readonly salaryStructure:       D;
  readonly payrollRun:            D;
  readonly payslip:               D;
  readonly payrollAdjustment:     D;
  readonly employeeTaxDeclaration:D;
  readonly tDSProjection:         D;
  readonly tDSRecalculationLog:   D;
  readonly pfEcrRecord:           D;
  readonly esiContributionRecord: D;
  readonly ptReturnRecord:        D;
  readonly tdsChallan:            D;
  readonly tdsReturn:             D;
  readonly tdsReturnAuditLog:     D;
  readonly tracesImportLog:       D;
  readonly form16Record:          D;
  readonly form16AuditLog:        D;
  readonly form16BulkJob:         D;
  readonly salaryRevision:        D;
  readonly arrearEntry:           D;
  readonly leaveRequest:          D;
  readonly leaveBalance:          D;
  readonly attendanceRecord:      D;
  readonly ticket:                D;
  readonly ticketMessage:         D;
  readonly kbArticle:             D;
  readonly account:               D;
  readonly contact:               D;
  readonly $global:      PrismaClient;
  readonly $transaction: PrismaClient['$transaction'];
}

@Injectable()
export class PrismaTenantService {
  private readonly logger = new Logger(PrismaTenantService.name);
  constructor(private readonly prisma: PrismaClient) {}

  forTenant(tenantId: string): TenantScopedDb {
    if (!tenantId?.trim()) {
      this.logger.error('[SECURITY] forTenant() called with empty tenantId');
      throw new ForbiddenException('Invalid tenant context');
    }
    const s = (model: string): D =>
      createTenantScopedDelegate(
        (this.prisma as unknown as Record<string,unknown>)[model] as object,
        tenantId, model, this.logger,
      );
    return {
      employee:               s('employee'),
      user:                   s('user'),
      salaryStructure:        s('salaryStructure'),
      payrollRun:             s('payrollRun'),
      payslip:                s('payslip'),
      payrollAdjustment:      s('payrollAdjustment'),
      employeeTaxDeclaration: s('employeeTaxDeclaration'),
      tDSProjection:          s('tDSProjection'),
      tDSRecalculationLog:    s('tDSRecalculationLog'),
      pfEcrRecord:            s('pfEcrRecord'),
      esiContributionRecord:  s('esiContributionRecord'),
      ptReturnRecord:         s('ptReturnRecord'),
      tdsChallan:             s('tdsChallan'),
      tdsReturn:              s('tdsReturn'),
      tdsReturnAuditLog:      s('tdsReturnAuditLog'),
      tracesImportLog:        s('tracesImportLog'),
      form16Record:           s('form16Record'),
      form16AuditLog:         s('form16AuditLog'),
      form16BulkJob:          s('form16BulkJob'),
      salaryRevision:         s('salaryRevision'),
      arrearEntry:            s('arrearEntry'),
      leaveRequest:           s('leaveRequest'),
      leaveBalance:           s('leaveBalance'),
      attendanceRecord:       s('attendanceRecord'),
      ticket:                 s('ticket'),
      ticketMessage:          s('ticketMessage'),
      kbArticle:              s('kbArticle'),
      account:                s('account'),
      contact:                s('contact'),
      $global:      this.prisma,
      $transaction: this.prisma.$transaction.bind(this.prisma),
    } as TenantScopedDb;
  }

  async assertOwnership(model: string, resourceId: string, tenantId: string): Promise<void> {
    const delegate = (this.prisma as unknown as Record<string,{ findFirst:(a:object)=>Promise<unknown> }>)[model];
    if (!delegate?.findFirst) throw new Error(`Model ${model} has no findFirst`);
    const rec = await delegate.findFirst({ where: { id: resourceId, tenantId } });
    if (!rec) {
      this.logger.warn(`[SECURITY] ${model}/${resourceId} not found for tenant ${tenantId}`);
      throw new ForbiddenException('Resource not found or access denied');
    }
  }

  get $raw(): PrismaClient { return this.prisma; }
}
