/**
 * SECURITY FIX C-01 — Secure App Configuration
 * All secret fallbacks removed. App fails at boot via env-validator.ts
 * if required variables are absent.
 *
 * REQUIRED env vars (no defaults): JWT_SECRET, JWT_REFRESH_SECRET,
 * DATABASE_URL, ENCRYPTION_KEY, REDIS_URL, ALLOWED_ORIGINS, MAGIC_LINK_SECRET
 */
import { registerAs } from '@nestjs/config';

export default registerAs('app', () => ({
  name: process.env['APP_NAME'] ?? 'RetroWorks HR',
  env: process.env['NODE_ENV'] ?? 'development',
  port: parseInt(process.env['PORT'] ?? '3001', 10),
  version: process.env['npm_package_version'] ?? '0.1.0',

  databaseUrl: process.env['DATABASE_URL'],

  // JWT — NO FALLBACKS (required, validated at boot by env-validator.ts)
  jwt: {
    secret: process.env['JWT_SECRET'],
    expiresIn: process.env['JWT_EXPIRES_IN'] ?? '15m',
    refreshSecret: process.env['JWT_REFRESH_SECRET'],
    refreshExpiresIn: process.env['JWT_REFRESH_EXPIRES_IN'] ?? '7d',
  },

  redis: {
    url: process.env['REDIS_URL'],
    tls: process.env['REDIS_TLS'] === 'true',
    maxRetries: parseInt(process.env['REDIS_MAX_RETRIES'] ?? '3', 10),
  },

  aws: {
    region: process.env['AWS_REGION'] ?? 'ap-south-1',
    accessKeyId: process.env['AWS_ACCESS_KEY_ID'] ?? '',
    secretAccessKey: process.env['AWS_SECRET_ACCESS_KEY'] ?? '',
    s3Bucket: process.env['AWS_S3_BUCKET'] ?? 'retroworks-hr-dev',
    kmsKeyId: process.env['AWS_KMS_KEY_ID'] ?? '',
    sesFromEmail: process.env['AWS_SES_FROM_EMAIL'] ?? 'noreply@retroworks.hr',
    cloudfrontUrl: process.env['AWS_CLOUDFRONT_URL'] ?? '',
  },

  oidc: {
    issuerUrl: process.env['OIDC_ISSUER_URL'] ?? '',
    clientId: process.env['OIDC_CLIENT_ID'] ?? '',
    clientSecret: process.env['OIDC_CLIENT_SECRET'] ?? '',
  },

  magicLink: {
    expiresInMinutes: parseInt(process.env['MAGIC_LINK_EXPIRES_MINUTES'] ?? '15', 10),
    secret: process.env['MAGIC_LINK_SECRET'],
  },

  frontendUrl: process.env['FRONTEND_URL'] ?? 'http://localhost:3000',
  allowedOrigins: (process.env['ALLOWED_ORIGINS'] ?? 'http://localhost:3000').split(',').map(o => o.trim()),

  // Encryption (AES-256-GCM) — NO FALLBACK
  encryption: {
    algorithm: 'aes-256-gcm' as const,
    key: process.env['ENCRYPTION_KEY'],
    useKms: process.env['USE_KMS'] === 'true',
    kmsKeyAlias: process.env['KMS_KEY_ALIAS'] ?? 'alias/retroworks-hr',
  },

  backup: {
    dir: process.env['BACKUP_DIR'] ?? '/var/retroworks/backups',
    encryptionKey: process.env['BACKUP_ENCRYPTION_KEY'] ?? '',
    s3Bucket: process.env['BACKUP_S3_BUCKET'] ?? '',
    retainDailyDays: parseInt(process.env['BACKUP_RETAIN_DAILY'] ?? '7', 10),
    retainWeeklyWeeks: parseInt(process.env['BACKUP_RETAIN_WEEKLY'] ?? '4', 10),
  },

  webhook: {
    secret: process.env['WEBHOOK_SECRET'] ?? '',
    timeoutMs: parseInt(process.env['WEBHOOK_TIMEOUT_MS'] ?? '10000', 10),
    maxRetries: parseInt(process.env['WEBHOOK_MAX_RETRIES'] ?? '3', 10),
  },

  ai: {
    claudeApiKey: process.env['ANTHROPIC_API_KEY'] ?? '',
    openaiApiKey: process.env['OPENAI_API_KEY'] ?? '',
    embeddingModel: process.env['EMBEDDING_MODEL'] ?? 'text-embedding-3-small',
    chunkSize: parseInt(process.env['CHUNK_SIZE'] ?? '512', 10),
    chunkOverlap: parseInt(process.env['CHUNK_OVERLAP'] ?? '64', 10),
    vectorDimensions: parseInt(process.env['VECTOR_DIMENSIONS'] ?? '1536', 10),
    maxContextDocs: parseInt(process.env['MAX_CONTEXT_DOCS'] ?? '5', 10),
    confidenceThreshold: parseFloat(process.env['CONFIDENCE_THRESHOLD'] ?? '0.7'),
    // Safety: never log conversation payloads in production
    logPayloads: process.env['AI_LOG_PAYLOADS'] === 'true' && process.env['NODE_ENV'] !== 'production',
  },

  payroll: {
    runLockTtlSeconds: parseInt(process.env['PAYROLL_RUN_LOCK_TTL'] ?? '300', 10),
    batchSize: parseInt(process.env['PAYROLL_BATCH_SIZE'] ?? '50', 10),
  },

  rateLimit: {
    loginMaxAttempts: parseInt(process.env['LOGIN_MAX_ATTEMPTS'] ?? '5', 10),
    loginWindowMs: parseInt(process.env['LOGIN_WINDOW_MS'] ?? '900000', 10),
    apiMaxPerMinute: parseInt(process.env['API_MAX_PER_MINUTE'] ?? '200', 10),
  },

  logging: {
    level: process.env['LOG_LEVEL'] ?? 'info',
    format: process.env['LOG_FORMAT'] ?? 'json',
    maskPii: process.env['NODE_ENV'] === 'production',
  },

  health: {
    dbTimeoutMs: parseInt(process.env['HEALTH_DB_TIMEOUT_MS'] ?? '2000', 10),
    redisTimeoutMs: parseInt(process.env['HEALTH_REDIS_TIMEOUT_MS'] ?? '1000', 10),
  },

  metrics: {
    enabled: process.env['METRICS_ENABLED'] !== 'false',
    path: process.env['METRICS_PATH'] ?? '/metrics',
  },
}));
