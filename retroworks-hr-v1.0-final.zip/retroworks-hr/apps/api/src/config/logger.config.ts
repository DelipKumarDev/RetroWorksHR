import { utilities as nestWinstonModuleUtilities } from 'nest-winston';
import * as winston from 'winston';

const isProduction = process.env['NODE_ENV'] === 'production';

export const winstonConfig: winston.LoggerOptions = {
  level: process.env['LOG_LEVEL'] ?? 'info',
  format: isProduction
    ? winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json(),
      )
    : winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        nestWinstonModuleUtilities.format.nestLike('RetroWorksHR', {
          prettyPrint: true,
          colors: true,
        }),
      ),
  transports: [
    new winston.transports.Console({
      silent: process.env['NODE_ENV'] === 'test',
    }),
    ...(isProduction
      ? [
          new winston.transports.File({
            filename: 'logs/error.log',
            level: 'error',
            maxsize: 5_242_880, // 5MB
            maxFiles: 5,
          }),
          new winston.transports.File({
            filename: 'logs/combined.log',
            maxsize: 5_242_880,
            maxFiles: 10,
          }),
        ]
      : []),
  ],
  exceptionHandlers: [
    new winston.transports.Console(),
    ...(isProduction ? [new winston.transports.File({ filename: 'logs/exceptions.log' })] : []),
  ],
  rejectionHandlers: [
    new winston.transports.Console(),
  ],
};
