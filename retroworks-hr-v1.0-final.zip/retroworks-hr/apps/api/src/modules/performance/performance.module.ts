import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

@Injectable()
export class PerformanceService {
  private readonly logger = new Logger(PerformanceService.name);
  constructor(private readonly prisma: PrismaClient, private readonly events: EventEmitter2) {}

  async createCycle(tenantId: string, dto: any, createdBy: string) {
    return this.prisma.reviewCycle.create({
      data: {
        tenantId, name: dto.name, type: dto.type ?? 'annual',
        startDate: new Date(dto.startDate), endDate: new Date(dto.endDate),
        selfReviewDeadline: dto.selfReviewDeadline ? new Date(dto.selfReviewDeadline) : undefined,
        managerReviewDeadline: dto.managerReviewDeadline ? new Date(dto.managerReviewDeadline) : undefined,
        status: 'draft', createdBy, updatedBy: createdBy,
      },
    });
  }

  async listCycles(tenantId: string) {
    return this.prisma.reviewCycle.findMany({
      where: { tenantId, deletedAt: null },
      include: { _count: { select: { reviews: true } } },
      orderBy: { startDate: 'desc' },
    });
  }

  async activateCycle(tenantId: string, cycleId: string, activatedBy: string) {
    const cycle = await this.prisma.reviewCycle.findFirst({ where: { id: cycleId, tenantId } });
    if (!cycle) throw new NotFoundException('Cycle not found');
    if (cycle.status !== 'draft') throw new BadRequestException('Only draft cycles can be activated');

    const employees = await this.prisma.employee.findMany({
      where: { tenantId, status: 'active', deletedAt: null },
      select: { id: true, managerId: true },
    });

    await this.prisma.performanceReview.createMany({
      data: employees.map(emp => ({ tenantId, cycleId, employeeId: emp.id, reviewerId: emp.managerId, status: 'pending', createdBy: activatedBy })),
      skipDuplicates: true,
    });

    const updated = await this.prisma.reviewCycle.update({ where: { id: cycleId }, data: { status: 'active', updatedBy: activatedBy } });
    this.events.emit('review.cycle.activated', { tenantId, cycleId, employeeCount: employees.length });
    return updated;
  }

  async createGoal(tenantId: string, dto: any, createdBy: string) {
    return this.prisma.performanceGoal.create({
      data: {
        tenantId, employeeId: dto.employeeId ?? createdBy, cycleId: dto.cycleId,
        title: dto.title, description: dto.description, metric: dto.metric,
        targetValue: dto.targetValue, currentValue: dto.currentValue ?? 0,
        weightage: dto.weightage ?? 10, dueDate: dto.dueDate ? new Date(dto.dueDate) : undefined,
        status: 'not-started', createdBy, updatedBy: createdBy,
      },
    });
  }

  async updateGoalProgress(tenantId: string, goalId: string, dto: any, updatedBy: string) {
    const goal = await this.prisma.performanceGoal.findFirst({ where: { id: goalId, tenantId } });
    if (!goal) throw new NotFoundException('Goal not found');
    const progress = goal.targetValue > 0 ? Math.min(100, Math.round((dto.currentValue / goal.targetValue) * 100)) : 0;
    const status = progress >= 100 ? 'completed' : progress > 0 ? 'in-progress' : 'not-started';
    return this.prisma.performanceGoal.update({ where: { id: goalId }, data: { currentValue: dto.currentValue, progress, status, notes: dto.notes, updatedBy } });
  }

  async getMyGoals(tenantId: string, employeeId: string, cycleId?: string) {
    return this.prisma.performanceGoal.findMany({
      where: { tenantId, employeeId, ...(cycleId && { cycleId }), deletedAt: null },
      orderBy: { createdAt: 'desc' },
    });
  }

  async submitSelfReview(tenantId: string, reviewId: string, dto: any, submittedBy: string) {
    const review = await this.prisma.performanceReview.findFirst({ where: { id: reviewId, tenantId, employeeId: submittedBy } });
    if (!review) throw new NotFoundException('Review not found');
    if (review.selfReviewSubmittedAt) throw new BadRequestException('Self review already submitted');
    return this.prisma.performanceReview.update({
      where: { id: reviewId },
      data: { selfRating: dto.selfRating, selfComments: dto.selfComments, selfAchievements: dto.selfAchievements, selfChallenges: dto.selfChallenges, selfGoalsNextCycle: dto.selfGoalsNextCycle, selfReviewSubmittedAt: new Date() },
    });
  }

  async submitManagerReview(tenantId: string, reviewId: string, dto: any, reviewerId: string) {
    const review = await this.prisma.performanceReview.findFirst({ where: { id: reviewId, tenantId, reviewerId } });
    if (!review) throw new NotFoundException('Review not found');
    if (!review.selfReviewSubmittedAt) throw new BadRequestException('Employee must complete self-review first');
    const updated = await this.prisma.performanceReview.update({
      where: { id: reviewId },
      data: { managerRating: dto.managerRating, managerComments: dto.managerComments, managerStrengths: dto.managerStrengths, managerDevelopmentAreas: dto.managerDevelopmentAreas, rating: dto.rating, status: 'manager-reviewed', managerReviewSubmittedAt: new Date() },
    });
    this.events.emit('review.manager.submitted', { tenantId, reviewId, employeeId: review.employeeId });
    return updated;
  }

  async getMyReviews(tenantId: string, employeeId: string) {
    return this.prisma.performanceReview.findMany({
      where: { tenantId, employeeId },
      include: { cycle: { select: { name: true, type: true, startDate: true, endDate: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getTeamReviews(tenantId: string, managerId: string, cycleId?: string) {
    return this.prisma.performanceReview.findMany({
      where: { tenantId, reviewerId: managerId, ...(cycleId && { cycleId }) },
      include: { employee: { select: { firstName: true, lastName: true, designation: { select: { name: true } } } }, cycle: { select: { name: true, endDate: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  async request360Feedback(tenantId: string, reviewId: string, reviewerIds: string[], requestedBy: string) {
    const review = await this.prisma.performanceReview.findFirst({ where: { id: reviewId, tenantId } });
    if (!review) throw new NotFoundException('Review not found');
    const feedbacks = await this.prisma.peerFeedback.createMany({
      data: reviewerIds.map(reviewerId => ({ tenantId, reviewId, reviewerId, status: 'pending', createdBy: requestedBy })),
      skipDuplicates: true,
    });
    this.events.emit('review.360.requested', { tenantId, reviewId, reviewerIds });
    return { requested: feedbacks.count };
  }

  async submit360Feedback(tenantId: string, feedbackId: string, dto: any, submittedBy: string) {
    const feedback = await this.prisma.peerFeedback.findFirst({ where: { id: feedbackId, tenantId, reviewerId: submittedBy } });
    if (!feedback) throw new NotFoundException('Feedback request not found');
    return this.prisma.peerFeedback.update({ where: { id: feedbackId }, data: { rating: dto.rating, strengths: dto.strengths, improvements: dto.improvements, comments: dto.comments, status: 'submitted', submittedAt: new Date() } });
  }

  async getCycleAnalytics(tenantId: string, cycleId: string) {
    const reviews = await this.prisma.performanceReview.findMany({ where: { tenantId, cycleId }, select: { rating: true, managerRating: true, selfRating: true, status: true } });
    const byRating = reviews.reduce<Record<string, number>>((acc, r) => { if (r.rating) acc[r.rating] = (acc[r.rating] ?? 0) + 1; return acc; }, {});
    const completed = reviews.filter(r => r.status === 'manager-reviewed').length;
    const avgManagerRating = reviews.filter(r => r.managerRating).reduce((s, r) => s + (r.managerRating ?? 0), 0) / (reviews.filter(r => r.managerRating).length || 1);
    return { total: reviews.length, completed, byRating, avgManagerRating: Math.round(avgManagerRating * 10) / 10 };
  }
}

@ApiTags('performance')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('performance')
export class PerformanceController {
  constructor(private readonly performanceService: PerformanceService) {}

  @Post('cycles') @Roles('hr-admin', 'super-admin')
  createCycle(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.performanceService.createCycle(u.tid, dto, u.sub); }

  @Get('cycles')
  listCycles(@CurrentUser() u: JwtPayload) { return this.performanceService.listCycles(u.tid); }

  @Post('cycles/:id/activate') @Roles('hr-admin', 'super-admin')
  activateCycle(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.performanceService.activateCycle(u.tid, id, u.sub); }

  @Post('goals')
  createGoal(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.performanceService.createGoal(u.tid, dto, u.sub); }

  @Patch('goals/:id/progress')
  updateProgress(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.performanceService.updateGoalProgress(u.tid, id, dto, u.sub); }

  @Get('goals/me')
  myGoals(@Query('cycleId') cycleId: string | undefined, @CurrentUser() u: JwtPayload) { return this.performanceService.getMyGoals(u.tid, u.sub, cycleId); }

  @Get('reviews/me')
  myReviews(@CurrentUser() u: JwtPayload) { return this.performanceService.getMyReviews(u.tid, u.sub); }

  @Get('reviews/team') @Roles('manager', 'hr-admin', 'super-admin')
  teamReviews(@Query('cycleId') cycleId: string | undefined, @CurrentUser() u: JwtPayload) { return this.performanceService.getTeamReviews(u.tid, u.sub, cycleId); }

  @Post('reviews/:id/self')
  selfReview(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.performanceService.submitSelfReview(u.tid, id, dto, u.sub); }

  @Post('reviews/:id/manager')
  managerReview(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.performanceService.submitManagerReview(u.tid, id, dto, u.sub); }

  @Post('reviews/:id/360/request')
  request360(@Param('id') id: string, @Body('reviewerIds') reviewerIds: string[], @CurrentUser() u: JwtPayload) { return this.performanceService.request360Feedback(u.tid, id, reviewerIds, u.sub); }

  @Post('feedback/:feedbackId/submit')
  submit360(@Param('feedbackId') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.performanceService.submit360Feedback(u.tid, id, dto, u.sub); }

  @Get('cycles/:id/analytics') @Roles('hr-admin', 'super-admin')
  analytics(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.performanceService.getCycleAnalytics(u.tid, id); }
}

@Module({ controllers: [PerformanceController], providers: [PerformanceService], exports: [PerformanceService] })
export class PerformanceModule {}
