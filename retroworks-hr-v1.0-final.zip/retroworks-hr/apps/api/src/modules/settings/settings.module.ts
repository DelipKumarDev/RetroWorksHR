import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import {
  Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── Permissions Matrix ───────────────────────────────────

export const ROLE_PERMISSIONS: Record<string, string[]> = {
  'super-admin': ['*'],
  'hr-admin': [
    'employees:read', 'employees:write', 'employees:delete',
    'leave:read', 'leave:approve', 'leave:write',
    'payroll:read', 'payroll:write', 'payroll:run', 'payroll:approve',
    'ats:read', 'ats:write',
    'performance:read', 'performance:write',
    'reports:read',
    'onboarding:write',
    'announcements:write',
    'helpdesk:read', 'helpdesk:assign',
    'integrations:write',
    'settings:read',
  ],
  'manager': [
    'employees:read',
    'leave:read', 'leave:approve-team',
    'payroll:read-team',
    'ats:read', 'ats:write',
    'performance:read', 'performance:write-team',
    'reports:read-team',
    'helpdesk:read',
    'announcements:read',
  ],
  'employee': [
    'employees:read-self',
    'leave:read-self', 'leave:write-self',
    'payroll:read-self',
    'performance:read-self', 'performance:write-self',
    'helpdesk:write',
    'announcements:read',
    'expenses:write-self', 'expenses:read-self',
  ],
  'recruiter': [
    'ats:read', 'ats:write',
    'employees:read',
  ],
};

// ─── Service ─────────────────────────────────────────────

@Injectable()
export class SettingsService {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ── Tenant Settings ───────────────────────────────────────

  async getTenantSettings(tenantId: string) {
    const tenant = await this.prisma.tenant.findFirst({
      where: { id: tenantId },
      include: {
        settings: true,
        payrollConfig: true,
      },
    });
    if (!tenant) throw new NotFoundException('Tenant not found');
    return tenant;
  }

  async updateTenantSettings(tenantId: string, dto: any, updatedBy: string) {
    return this.prisma.tenantSettings.upsert({
      where: { tenantId },
      update: { ...dto, updatedBy },
      create: { tenantId, ...dto, createdBy: updatedBy, updatedBy },
    });
  }

  // ── Payroll Config ────────────────────────────────────────

  async getPayrollConfig(tenantId: string) {
    return this.prisma.payrollConfig.findFirst({ where: { tenantId } });
  }

  async upsertPayrollConfig(tenantId: string, dto: any, updatedBy: string) {
    return this.prisma.payrollConfig.upsert({
      where: { tenantId },
      update: { ...dto, updatedBy },
      create: {
        tenantId,
        defaultTaxRegime: dto.defaultTaxRegime ?? 'new',
        autoRun: dto.autoRun ?? false,
        runDay: dto.runDay ?? 28,
        defaultWorkingDays: dto.defaultWorkingDays ?? 26,
        defaultPfOptIn: dto.defaultPfOptIn ?? true,
        salaryRevisionMonth: dto.salaryRevisionMonth ?? 4,
        status: 'active',
        createdBy: updatedBy, updatedBy,
      },
    });
  }

  // ── Leave Types ───────────────────────────────────────────

  async listLeaveTypes(tenantId: string) {
    return this.prisma.leaveType.findMany({
      where: { tenantId },
      orderBy: { name: 'asc' },
    });
  }

  async createLeaveType(tenantId: string, dto: any, createdBy: string) {
    return this.prisma.leaveType.create({
      data: {
        tenantId,
        name: dto.name, code: dto.code.toUpperCase(),
        entitledDays: dto.entitledDays,
        isPaid: dto.isPaid ?? true,
        requiresApproval: dto.requiresApproval ?? true,
        requiresDocument: dto.requiresDocument ?? false,
        allowHalfDay: dto.allowHalfDay ?? false,
        accrualEnabled: dto.accrualEnabled ?? false,
        carryForwardDays: dto.carryForwardDays ?? 0,
        maxBackdatedDays: dto.maxBackdatedDays ?? 3,
        isActive: true, createdBy, updatedBy: createdBy,
      },
    });
  }

  async updateLeaveType(tenantId: string, id: string, dto: any, updatedBy: string) {
    const lt = await this.prisma.leaveType.findFirst({ where: { id, tenantId } });
    if (!lt) throw new NotFoundException('Leave type not found');
    return this.prisma.leaveType.update({ where: { id }, data: { ...dto, updatedBy } });
  }

  // ── Role & Permission Management ──────────────────────────

  async listRoles(tenantId: string) {
    const customRoles = await this.prisma.customRole.findMany({
      where: { tenantId, deletedAt: null },
      include: { _count: { select: { assignments: true } } },
    });

    const systemRoles = Object.entries(ROLE_PERMISSIONS).map(([name, perms]) => ({
      name, type: 'system', permissions: perms, memberCount: 0,
    }));

    return { systemRoles, customRoles };
  }

  async createCustomRole(tenantId: string, dto: any, createdBy: string) {
    const existing = await this.prisma.customRole.findFirst({ where: { tenantId, name: dto.name } });
    if (existing) throw new BadRequestException('Role with this name already exists');

    return this.prisma.customRole.create({
      data: {
        tenantId, name: dto.name, description: dto.description,
        permissions: dto.permissions ?? [], createdBy, updatedBy: createdBy,
      },
    });
  }

  async updateCustomRole(tenantId: string, roleId: string, dto: any, updatedBy: string) {
    const role = await this.prisma.customRole.findFirst({ where: { id: roleId, tenantId } });
    if (!role) throw new NotFoundException('Role not found');
    return this.prisma.customRole.update({ where: { id: roleId }, data: { ...dto, updatedBy } });
  }

  async assignRole(tenantId: string, employeeId: string, role: string, assignedBy: string) {
    const employee = await this.prisma.employee.findFirst({ where: { id: employeeId, tenantId } });
    if (!employee) throw new NotFoundException('Employee not found');

    const updated = await this.prisma.employee.update({
      where: { id: employeeId },
      data: { role, updatedBy: assignedBy },
    });

    this.events.emit('audit.created', {
      tenantId, userId: assignedBy, action: 'ROLE_ASSIGNED',
      resource: 'employee', resourceId: employeeId,
      newData: { role },
    });

    return updated;
  }

  async getPermissionsMatrix() {
    return ROLE_PERMISSIONS;
  }

  // ── Feature Flags ─────────────────────────────────────────

  async getFeatureFlags(tenantId: string) {
    const settings = await this.prisma.tenantSettings.findFirst({ where: { tenantId } });
    return {
      ai: settings?.featureAi ?? false,
      slackIntegration: settings?.featureSlack ?? false,
      zoomIntegration: settings?.featureZoom ?? false,
      advancedReports: settings?.featureAdvancedReports ?? true,
      lnd: settings?.featureLnd ?? true,
      expenses: settings?.featureExpenses ?? true,
      helpdesk: settings?.featureHelpdesk ?? true,
    };
  }

  async updateFeatureFlags(tenantId: string, flags: Record<string, boolean>, updatedBy: string) {
    return this.prisma.tenantSettings.upsert({
      where: { tenantId },
      update: {
        featureAi: flags.ai, featureSlack: flags.slackIntegration,
        featureZoom: flags.zoomIntegration, featureAdvancedReports: flags.advancedReports,
        featureLnd: flags.lnd, featureExpenses: flags.expenses, featureHelpdesk: flags.helpdesk,
        updatedBy,
      },
      create: {
        tenantId,
        featureAi: flags.ai ?? false, featureSlack: flags.slackIntegration ?? false,
        featureZoom: flags.zoomIntegration ?? false, featureAdvancedReports: flags.advancedReports ?? true,
        featureLnd: flags.lnd ?? true, featureExpenses: flags.expenses ?? true,
        featureHelpdesk: flags.helpdesk ?? true,
        createdBy: updatedBy, updatedBy,
      },
    });
  }

  // ── Department Management ─────────────────────────────────

  async listDepartments(tenantId: string) {
    return this.prisma.department.findMany({
      where: { tenantId, deletedAt: null },
      include: {
        _count: { select: { employees: true } },
        head: { select: { firstName: true, lastName: true } },
      },
      orderBy: { name: 'asc' },
    });
  }

  async createDepartment(tenantId: string, dto: any, createdBy: string) {
    return this.prisma.department.create({
      data: { tenantId, name: dto.name, code: dto.code, headId: dto.headId, parentId: dto.parentId, createdBy, updatedBy: createdBy },
    });
  }

  // ── Location Management ───────────────────────────────────

  async listLocations(tenantId: string) {
    return this.prisma.location.findMany({
      where: { tenantId, deletedAt: null },
      include: { _count: { select: { employees: true } } },
      orderBy: { name: 'asc' },
    });
  }

  async createLocation(tenantId: string, dto: any, createdBy: string) {
    return this.prisma.location.create({
      data: { tenantId, name: dto.name, code: dto.code, city: dto.city, state: dto.state, country: dto.country ?? 'India', stateCode: dto.stateCode, timezone: dto.timezone ?? 'Asia/Kolkata', createdBy, updatedBy: createdBy },
    });
  }

  // ── Audit Log ─────────────────────────────────────────────

  async getAuditLog(tenantId: string, filters: { resource?: string; userId?: string; limit?: number }) {
    return this.prisma.auditLog.findMany({
      where: {
        tenantId,
        ...(filters.resource && { resource: filters.resource }),
        ...(filters.userId && { userId: filters.userId }),
      },
      orderBy: { createdAt: 'desc' },
      take: filters.limit ?? 50,
      include: {
        user: { select: { firstName: true, lastName: true, email: true } },
      },
    });
  }
}

// ─── Controller ───────────────────────────────────────────

@ApiTags('settings')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('settings')
export class SettingsController {
  constructor(private readonly settingsService: SettingsService) {}

  // Tenant settings
  @Get()
  @Roles('hr-admin', 'super-admin')
  getTenant(@CurrentUser() u: JwtPayload) { return this.settingsService.getTenantSettings(u.tid); }

  @Patch()
  @Roles('super-admin')
  updateTenant(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.settingsService.updateTenantSettings(u.tid, dto, u.sub); }

  // Payroll config
  @Get('payroll')
  @Roles('hr-admin', 'super-admin')
  getPayrollConfig(@CurrentUser() u: JwtPayload) { return this.settingsService.getPayrollConfig(u.tid); }

  @Post('payroll')
  @Roles('hr-admin', 'super-admin')
  upsertPayrollConfig(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.settingsService.upsertPayrollConfig(u.tid, dto, u.sub); }

  // Leave types
  @Get('leave-types')
  @Roles('hr-admin', 'super-admin')
  listLeaveTypes(@CurrentUser() u: JwtPayload) { return this.settingsService.listLeaveTypes(u.tid); }

  @Post('leave-types')
  @Roles('hr-admin', 'super-admin')
  createLeaveType(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.settingsService.createLeaveType(u.tid, dto, u.sub); }

  @Patch('leave-types/:id')
  @Roles('hr-admin', 'super-admin')
  updateLeaveType(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.settingsService.updateLeaveType(u.tid, id, dto, u.sub); }

  // Roles & permissions
  @Get('roles')
  @Roles('hr-admin', 'super-admin')
  listRoles(@CurrentUser() u: JwtPayload) { return this.settingsService.listRoles(u.tid); }

  @Post('roles')
  @Roles('super-admin')
  createRole(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.settingsService.createCustomRole(u.tid, dto, u.sub); }

  @Patch('roles/:id')
  @Roles('super-admin')
  updateRole(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.settingsService.updateCustomRole(u.tid, id, dto, u.sub); }

  @Post('roles/assign')
  @Roles('hr-admin', 'super-admin')
  assignRole(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.settingsService.assignRole(u.tid, dto.employeeId, dto.role, u.sub); }

  @Get('permissions-matrix')
  getPermissions() { return this.settingsService.getPermissionsMatrix(); }

  // Feature flags
  @Get('features')
  @Roles('hr-admin', 'super-admin')
  getFeatures(@CurrentUser() u: JwtPayload) { return this.settingsService.getFeatureFlags(u.tid); }

  @Patch('features')
  @Roles('super-admin')
  updateFeatures(@Body() flags: Record<string, boolean>, @CurrentUser() u: JwtPayload) { return this.settingsService.updateFeatureFlags(u.tid, flags, u.sub); }

  // Departments
  @Get('departments')
  listDepts(@CurrentUser() u: JwtPayload) { return this.settingsService.listDepartments(u.tid); }

  @Post('departments')
  @Roles('hr-admin', 'super-admin')
  createDept(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.settingsService.createDepartment(u.tid, dto, u.sub); }

  // Locations
  @Get('locations')
  listLocations(@CurrentUser() u: JwtPayload) { return this.settingsService.listLocations(u.tid); }

  @Post('locations')
  @Roles('hr-admin', 'super-admin')
  createLocation(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.settingsService.createLocation(u.tid, dto, u.sub); }

  // Audit log
  @Get('audit-log')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Tenant-wide audit log with filters' })
  getAuditLog(
    @Query('resource') resource: string | undefined,
    @Query('userId') userId: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) { return this.settingsService.getAuditLog(u.tid, { resource, userId }); }
}

@Module({
  controllers: [SettingsController],
  providers: [SettingsService],
  exports: [SettingsService],
})
export class SettingsModule {}
