/**
 * RetroWorks HR — Education Mode Engine
 * ═══════════════════════════════════════════════════════════════════════════════
 * Pure TypeScript — no framework dependencies — fully testable.
 *
 * Education Mode transforms RetroWorks HR into a school/university HR system:
 *
 *   Terminology:
 *     Employee       → Staff
 *     Department     → Faculty / Department
 *     Payroll Group  → Pay Commission Grade
 *     Leave Year     → Academic Year (Jun–May)
 *     Performance    → Academic Appraisal
 *
 *   New Roles:
 *     teacher, hod (Head of Department), principal, bursar (school finance)
 *
 *   Academic Year:
 *     Starts 1 June, ends 31 May
 *     Leave year-end runs in May with June 1 opening
 *
 *   Module Restrictions:
 *     Recruitment → disabled (staff sourced via government deputation / ads)
 *     Expense     → restricted to academic purposes only
 *     ATS         → disabled
 *
 *   School Dashboard:
 *     Staff headcount by faculty
 *     Academic leave summary (EL/CL/ML)
 *     Teaching load allocation
 *     Pay commission grade distribution
 *
 *   Tenant Isolation:
 *     Education tenants are completely isolated from corporate tenants
 *     eduMode flag in tenant settings gates all education-specific logic
 * ═══════════════════════════════════════════════════════════════════════════════
 */

import type { Module, RoleDefinition, ResourcePermission, CrudAction, MenuNode } from '../security/role-permission.engine';

// ─────────────────────────────────────────────────────────────────────────────
// EDUCATION TENANT CONFIG
// ─────────────────────────────────────────────────────────────────────────────

export interface EducationTenantConfig {
  tenantId: string;
  tenantName: string;
  isEducationMode: boolean;       // Master toggle — must be true for all edu features
  institutionType: 'school' | 'college' | 'university' | 'coaching';
  academicYearStartMonth: number; // 6 = June (default for most Indian schools)
  academicYearEndMonth: number;   // 5 = May
  boardAffiliation: string;       // e.g. 'CBSE', 'ICSE', 'State Board'
  payCommission: '7th' | '8th' | 'custom';

  // Terminology overrides
  terminology: EducationTerminology;

  // Module gates
  enabledModules: Module[];
  disabledModules: Module[];

  // Leave policy
  leaveYearType: 'academic';
  teacherLeaveEntitlements: TeacherLeaveEntitlement[];
}

export interface EducationTerminology {
  employee: string;           // 'Staff' or 'Teacher' or 'Faculty'
  employees: string;          // 'Staff' or 'Teachers'
  department: string;         // 'Faculty' or 'Department'
  departments: string;        // 'Faculties' or 'Departments'
  payrollGroup: string;       // 'Pay Band' or 'Pay Commission Grade'
  leaveYear: string;          // 'Academic Year'
  manager: string;            // 'Head of Department' or 'HOD'
  performance: string;        // 'Academic Appraisal'
  designation: string;        // 'Teaching Post' or 'Designation'
  onboarding: string;         // 'Staff Induction'
  offboarding: string;        // 'Relieving'
}

export interface TeacherLeaveEntitlement {
  leaveTypeCode: string;
  leaveName: string;
  daysPerYear: number;
  carryForwardDays: number;
  encashable: boolean;
  applicableStaffTypes: string[];   // ['teaching', 'non-teaching', 'both']
}

// ─────────────────────────────────────────────────────────────────────────────
// DEFAULTS
// ─────────────────────────────────────────────────────────────────────────────

export const DEFAULT_EDUCATION_TERMINOLOGY: EducationTerminology = {
  employee: 'Staff',
  employees: 'Staff Members',
  department: 'Faculty',
  departments: 'Faculties',
  payrollGroup: 'Pay Commission Grade',
  leaveYear: 'Academic Year',
  manager: 'Head of Department (HOD)',
  performance: 'Academic Appraisal',
  designation: 'Teaching Post',
  onboarding: 'Staff Induction',
  offboarding: 'Relieving',
};

export const DEFAULT_TEACHER_LEAVE_ENTITLEMENTS: TeacherLeaveEntitlement[] = [
  { leaveTypeCode: 'EL', leaveName: 'Earned Leave',       daysPerYear: 30, carryForwardDays: 300, encashable: true,  applicableStaffTypes: ['both'] },
  { leaveTypeCode: 'CL', leaveName: 'Casual Leave',        daysPerYear: 8,  carryForwardDays: 0,   encashable: false, applicableStaffTypes: ['both'] },
  { leaveTypeCode: 'ML', leaveName: 'Medical Leave',        daysPerYear: 20, carryForwardDays: 0,   encashable: false, applicableStaffTypes: ['both'] },
  { leaveTypeCode: 'VL', leaveName: 'Vacation Leave',       daysPerYear: 50, carryForwardDays: 0,   encashable: false, applicableStaffTypes: ['teaching'] },
  { leaveTypeCode: 'SL', leaveName: 'Study Leave',          daysPerYear: 0,  carryForwardDays: 0,   encashable: false, applicableStaffTypes: ['teaching'] },
  { leaveTypeCode: 'MAL', leaveName: 'Maternity Leave',     daysPerYear: 180, carryForwardDays: 0,  encashable: false, applicableStaffTypes: ['both'] },
  { leaveTypeCode: 'PAL', leaveName: 'Paternity Leave',     daysPerYear: 15,  carryForwardDays: 0,  encashable: false, applicableStaffTypes: ['both'] },
  { leaveTypeCode: 'CCL', leaveName: 'Child Care Leave',    daysPerYear: 730, carryForwardDays: 0,  encashable: false, applicableStaffTypes: ['both'] },
];

export const EDUCATION_ENABLED_MODULES: Module[] = [
  'core-hr', 'leave', 'attendance', 'payroll', 'payroll-tds',
  'payroll-pf-esi', 'payroll-form16', 'performance', 'lnd',
  'reports', 'settings', 'roles', 'education',
];

export const EDUCATION_DISABLED_MODULES: Module[] = [
  'recruitment', 'expense', 'analytics',
];

// ─────────────────────────────────────────────────────────────────────────────
// CONFIG FACTORY
// ─────────────────────────────────────────────────────────────────────────────

export function createEducationTenantConfig(
  tenantId: string,
  tenantName: string,
  overrides: Partial<Omit<EducationTenantConfig, 'tenantId' | 'tenantName' | 'isEducationMode' | 'leaveYearType'>> = {},
): EducationTenantConfig {
  return {
    tenantId,
    tenantName,
    isEducationMode: true,
    institutionType: overrides.institutionType ?? 'school',
    academicYearStartMonth: overrides.academicYearStartMonth ?? 6,
    academicYearEndMonth: overrides.academicYearEndMonth ?? 5,
    boardAffiliation: overrides.boardAffiliation ?? 'CBSE',
    payCommission: overrides.payCommission ?? '7th',
    terminology: overrides.terminology ?? { ...DEFAULT_EDUCATION_TERMINOLOGY },
    enabledModules: overrides.enabledModules ?? [...EDUCATION_ENABLED_MODULES],
    disabledModules: overrides.disabledModules ?? [...EDUCATION_DISABLED_MODULES],
    leaveYearType: 'academic',
    teacherLeaveEntitlements: overrides.teacherLeaveEntitlements ?? [...DEFAULT_TEACHER_LEAVE_ENTITLEMENTS],
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// EDUCATION ISOLATION GUARD
// ─────────────────────────────────────────────────────────────────────────────

export interface IsolationCheckResult {
  isolated: boolean;
  violations: string[];
}

/**
 * Verify that an education tenant is fully isolated from corporate tenants.
 * Corporate config has isEducationMode=false, edu config has isEducationMode=true.
 * Cross-tenant data requests must be rejected.
 */
export function verifyTenantIsolation(
  requestingTenantId: string,
  requestingConfig: { isEducationMode: boolean },
  targetTenantId: string,
  targetConfig: { isEducationMode: boolean },
): IsolationCheckResult {
  const violations: string[] = [];

  // Cross-tenant request always denied
  if (requestingTenantId !== targetTenantId) {
    violations.push(`Cross-tenant access denied: ${requestingTenantId} cannot access ${targetTenantId}`);
  }

  // Education ↔ Corporate mode mismatch
  if (requestingConfig.isEducationMode !== targetConfig.isEducationMode) {
    violations.push(
      `Mode mismatch: requesting tenant is ${requestingConfig.isEducationMode ? 'education' : 'corporate'} ` +
      `but target tenant is ${targetConfig.isEducationMode ? 'education' : 'corporate'}`
    );
  }

  return { isolated: violations.length === 0, violations };
}

// ─────────────────────────────────────────────────────────────────────────────
// TERMINOLOGY RESOLVER
// ─────────────────────────────────────────────────────────────────────────────

export function getTerm(
  config: EducationTenantConfig,
  key: keyof EducationTerminology,
): string {
  if (!config.isEducationMode) {
    // Return default corporate terminology
    const defaults: EducationTerminology = {
      employee: 'Employee', employees: 'Employees',
      department: 'Department', departments: 'Departments',
      payrollGroup: 'Payroll Group', leaveYear: 'Leave Year',
      manager: 'Manager', performance: 'Performance Review',
      designation: 'Designation', onboarding: 'Onboarding',
      offboarding: 'Offboarding',
    };
    return defaults[key];
  }
  return config.terminology[key];
}

// ─────────────────────────────────────────────────────────────────────────────
// ACADEMIC YEAR UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

export interface AcademicYear {
  startYear: number;        // e.g. 2024
  endYear: number;          // e.g. 2025
  label: string;            // 'AY 2024-25'
  startDate: Date;
  endDate: Date;
  isCurrentYear: boolean;
}

export function getCurrentAcademicYear(
  config: EducationTenantConfig,
  now: Date = new Date(),
): AcademicYear {
  const month = now.getMonth() + 1; // 1-based
  const year = now.getFullYear();

  // If current month >= start month, we're in AY year→year+1
  // If current month < start month, we're in AY year-1→year
  const startYear = month >= config.academicYearStartMonth ? year : year - 1;
  return buildAcademicYear(config, startYear, now);
}

export function buildAcademicYear(
  config: EducationTenantConfig,
  startYear: number,
  now: Date = new Date(),
): AcademicYear {
  const endYear = startYear + 1;
  const startDate = new Date(`${startYear}-${String(config.academicYearStartMonth).padStart(2, '0')}-01`);
  // End: last day of end month
  const endDate = new Date(endYear, config.academicYearEndMonth, 0); // day 0 = last day of prev month
  const label = `AY ${startYear}-${String(endYear).slice(2)}`;
  const isCurrentYear = now >= startDate && now <= endDate;

  return { startYear, endYear, label, startDate, endDate, isCurrentYear };
}

export function getAcademicYearForDate(
  config: EducationTenantConfig,
  date: Date,
): AcademicYear {
  const month = date.getMonth() + 1;
  const year = date.getFullYear();
  const startYear = month >= config.academicYearStartMonth ? year : year - 1;
  return buildAcademicYear(config, startYear, date);
}

// ─────────────────────────────────────────────────────────────────────────────
// TEACHER / STAFF ROLE TEMPLATES
// ─────────────────────────────────────────────────────────────────────────────

export function buildEducationRoles(tenantId: string, performedBy: string): RoleDefinition[] {
  const now = new Date();
  const base = (id: string, name: string, displayName: string, desc: string) => ({
    id, tenantId, name, displayName, description: desc,
    isSystem: true, isActive: true, createdAt: now, updatedAt: now, createdBy: performedBy,
  });

  const teacherRole: RoleDefinition = {
    ...base('edu-teacher', 'teacher', 'Teacher / Lecturer', 'Teaching staff: self-service + leave + academic profile'),
    allowedModules: ['leave', 'attendance', 'lnd', 'education'] as Module[],
    globalMaskedFields: [],
    permissions: [
      { resource: 'employee', module: 'core-hr', actions: ['read'], conditions: [{ field: 'params.employeeId', operator: 'own-only' }] } as ResourcePermission,
      { resource: 'leave:request', module: 'leave', actions: ['create', 'read'], conditions: [{ field: 'params.employeeId', operator: 'own-only' }] } as ResourcePermission,
      { resource: 'payroll:payslip', module: 'payroll', actions: ['read'], conditions: [{ field: 'params.employeeId', operator: 'own-only' }] } as ResourcePermission,
      { resource: 'attendance', module: 'attendance', actions: ['read', 'create'], conditions: [{ field: 'params.employeeId', operator: 'own-only' }] } as ResourcePermission,
    ],
    menuVisibility: {
      'nav-leave': true, 'nav-attendance': true, 'nav-payroll-form16': true,
      'nav-lnd': true, 'nav-payroll': false, 'nav-reports': false, 'nav-settings': false,
    },
  };

  const hodRole: RoleDefinition = {
    ...base('edu-hod', 'hod', 'Head of Department', 'HOD: manage own department staff, approve leave, view attendance'),
    allowedModules: ['core-hr', 'leave', 'attendance', 'performance', 'lnd', 'education'] as Module[],
    globalMaskedFields: ['salary', 'ctc', 'bankAccountNumber', 'panNumber'],
    permissions: [
      { resource: 'employee', module: 'core-hr', actions: ['read'], conditions: [{ field: 'employee.departmentId', operator: 'eq', value: '{{departmentId}}' }], maskedFields: ['salary', 'ctc', 'bankAccountNumber', 'panNumber'] } as ResourcePermission,
      { resource: 'leave:request', module: 'leave', actions: ['read', 'approve'], conditions: [{ field: 'employee.departmentId', operator: 'eq', value: '{{departmentId}}' }] } as ResourcePermission,
      { resource: 'attendance', module: 'attendance', actions: ['read'], conditions: [{ field: 'employee.departmentId', operator: 'eq', value: '{{departmentId}}' }] } as ResourcePermission,
      { resource: 'performance', module: 'performance', actions: ['read', 'create', 'update'] } as ResourcePermission,
    ],
    menuVisibility: {
      'nav-leave': true, 'nav-attendance': true, 'nav-performance': true,
      'nav-employees': true, 'nav-payroll': false, 'nav-reports': false,
    },
  };

  const principalRole: RoleDefinition = {
    ...base('edu-principal', 'principal', 'Principal / Director', 'Full staff management, payroll approval, academic governance'),
    allowedModules: ['core-hr', 'leave', 'attendance', 'payroll', 'payroll-form16', 'performance', 'lnd', 'reports', 'settings', 'education'] as Module[],
    globalMaskedFields: [],
    permissions: [
      { resource: 'employee', module: 'core-hr', actions: ['read', 'update'] } as ResourcePermission,
      { resource: 'leave:request', module: 'leave', actions: ['read', 'approve'] } as ResourcePermission,
      { resource: 'leave:year-end', module: 'leave', actions: ['read', 'approve'] } as ResourcePermission,
      { resource: 'payroll:run', module: 'payroll', actions: ['read', 'approve'] } as ResourcePermission,
      { resource: 'payroll:form16', module: 'payroll-form16', actions: ['read', 'approve'] } as ResourcePermission,
      { resource: 'performance', module: 'performance', actions: ['read', 'approve'] } as ResourcePermission,
      { resource: 'report:staff', module: 'reports', actions: ['read', 'export'] } as ResourcePermission,
    ],
    menuVisibility: {
      'nav-leave': true, 'nav-attendance': true, 'nav-payroll': true,
      'nav-payroll-form16': true, 'nav-performance': true, 'nav-employees': true,
      'nav-reports': true, 'nav-settings': true,
    },
  };

  const bursarRole: RoleDefinition = {
    ...base('edu-bursar', 'bursar', 'Bursar / School Finance Officer', 'School finance: payroll processing, fee management, statutory compliance'),
    allowedModules: ['payroll', 'payroll-tds', 'payroll-pf-esi', 'payroll-form16', 'reports', 'education'] as Module[],
    globalMaskedFields: [],
    permissions: [
      { resource: 'employee', module: 'core-hr', actions: ['read'], maskedFields: ['bankAccountNumber', 'panNumber'] } as ResourcePermission,
      { resource: 'payroll:run', module: 'payroll', actions: ['create', 'read', 'update', 'approve', 'export'] } as ResourcePermission,
      { resource: 'payroll:payslip', module: 'payroll', actions: ['read', 'export'] } as ResourcePermission,
      { resource: 'payroll:tds', module: 'payroll-tds', actions: ['read', 'update', 'approve', 'export'] } as ResourcePermission,
      { resource: 'payroll:pf-ecr', module: 'payroll-pf-esi', actions: ['read', 'export', 'approve'] } as ResourcePermission,
      { resource: 'payroll:form16', module: 'payroll-form16', actions: ['create', 'read', 'approve', 'export'] } as ResourcePermission,
      { resource: 'report:financial', module: 'reports', actions: ['read', 'export'] } as ResourcePermission,
    ],
    menuVisibility: {
      'nav-payroll': true, 'nav-payroll-tds': true, 'nav-payroll-pf': true,
      'nav-payroll-form16': true, 'nav-reports': true,
      'nav-leave': false, 'nav-employees': false, 'nav-settings': false,
    },
  };

  return [teacherRole, hodRole, principalRole, bursarRole];
}

// ─────────────────────────────────────────────────────────────────────────────
// EDUCATION MODULE RESTRICTION GUARD
// ─────────────────────────────────────────────────────────────────────────────

export interface ModuleAccessResult {
  allowed: boolean;
  reason: string;
}

export function isModuleAllowedInEducationMode(
  config: EducationTenantConfig,
  module: Module,
): ModuleAccessResult {
  if (!config.isEducationMode) {
    return { allowed: true, reason: 'Not in education mode — all modules follow standard rules' };
  }
  if (config.disabledModules.includes(module)) {
    return {
      allowed: false,
      reason: `Module "${module}" is disabled in Education Mode for ${config.tenantName}. ${getEducationModeRestrictionReason(module)}`,
    };
  }
  if (config.enabledModules.includes(module)) {
    return { allowed: true, reason: 'Module enabled in education config' };
  }
  return { allowed: false, reason: `Module "${module}" is not in the education enabled list` };
}

function getEducationModeRestrictionReason(module: Module): string {
  const reasons: Partial<Record<Module, string>> = {
    recruitment: 'Schools use government deputation or direct advertisements; ATS-based recruitment is not applicable.',
    expense:     'School expenses follow academic budget heads; general expense module is not enabled.',
    analytics:   'Advanced analytics requires separate configuration for education institutions.',
  };
  return reasons[module] ?? 'Restricted in education mode.';
}

// ─────────────────────────────────────────────────────────────────────────────
// SCHOOL DASHBOARD DATA MODEL
// ─────────────────────────────────────────────────────────────────────────────

export interface StaffRecord {
  employeeId: string;
  name: string;
  staffType: 'teaching' | 'non-teaching' | 'admin';
  facultyId: string;
  facultyName: string;
  designation: string;
  joinDate: string;   // ISO date
  isActive: boolean;
  payCommissionGrade?: string;
}

export interface SchoolDashboardData {
  tenantId: string;
  academicYear: AcademicYear;
  institutionType: string;
  totalStaff: number;
  teachingStaff: number;
  nonTeachingStaff: number;
  adminStaff: number;
  byFaculty: Array<{
    facultyId: string;
    facultyName: string;
    staffCount: number;
    teachingCount: number;
  }>;
  leaveStats: {
    pendingApprovals: number;
    averageEarnedLeaveBalance: number;
    staffOnLeaveToday: number;
  };
  payrollStats: {
    lastPayrollRunDate: string | null;
    pendingApprovals: number;
    payCommissionDistribution: Record<string, number>;
  };
  academicYearLabel: string;
}

export function buildSchoolDashboard(
  config: EducationTenantConfig,
  staff: StaffRecord[],
  leaveStats: SchoolDashboardData['leaveStats'],
  payrollStats: SchoolDashboardData['payrollStats'],
  now: Date = new Date(),
): SchoolDashboardData {
  if (!config.isEducationMode) {
    throw new Error('buildSchoolDashboard requires education mode to be enabled');
  }

  const currentYear = getCurrentAcademicYear(config, now);
  const activeStaff = staff.filter(s => s.isActive);

  const byFaculty = Object.values(
    activeStaff.reduce<Record<string, { facultyId: string; facultyName: string; staffCount: number; teachingCount: number }>>(
      (acc, s) => {
        if (!acc[s.facultyId]) {
          acc[s.facultyId] = { facultyId: s.facultyId, facultyName: s.facultyName, staffCount: 0, teachingCount: 0 };
        }
        acc[s.facultyId]!.staffCount++;
        if (s.staffType === 'teaching') acc[s.facultyId]!.teachingCount++;
        return acc;
      },
      {},
    ),
  );

  return {
    tenantId: config.tenantId,
    academicYear: currentYear,
    institutionType: config.institutionType,
    totalStaff: activeStaff.length,
    teachingStaff: activeStaff.filter(s => s.staffType === 'teaching').length,
    nonTeachingStaff: activeStaff.filter(s => s.staffType === 'non-teaching').length,
    adminStaff: activeStaff.filter(s => s.staffType === 'admin').length,
    byFaculty,
    leaveStats,
    payrollStats,
    academicYearLabel: currentYear.label,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// PAYROLL RUN COMPATIBILITY CHECK FOR EDUCATION MODE
// ─────────────────────────────────────────────────────────────────────────────

export interface PayrollRunValidation {
  isValid: boolean;
  errors: string[];
  warnings: string[];
  payCommissionApplied: string;
}

export function validateEducationPayrollRun(
  config: EducationTenantConfig,
  payrollInput: {
    month: number;
    year: number;
    staffIds: string[];
    payCommission?: string;
  },
): PayrollRunValidation {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!config.isEducationMode) {
    return { isValid: true, errors: [], warnings: [], payCommissionApplied: 'standard' };
  }

  if (!payrollInput.staffIds.length) {
    errors.push('No staff members selected for payroll run');
  }

  if (payrollInput.payCommission && payrollInput.payCommission !== config.payCommission) {
    warnings.push(`Pay commission mismatch: tenant is configured for ${config.payCommission} Pay Commission, but run specifies ${payrollInput.payCommission}`);
  }

  // April is typically when arrears from DA hike are paid — flag it
  if (payrollInput.month === 4) {
    warnings.push('April payroll: verify if DA hike arrears need to be processed from January under 7th Pay Commission');
  }

  // Vacation months — teaching staff may have VL adjustments
  if ([5, 6].includes(payrollInput.month)) {
    warnings.push('May/June: check Vacation Leave (VL) entitlement for teaching staff — VL runs during school vacation period');
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
    payCommissionApplied: config.payCommission,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// PRINCIPAL WORKFLOW — Academic Leave Year Close Approval
// ─────────────────────────────────────────────────────────────────────────────

export interface PrincipalWorkflowStep {
  stepId: string;
  name: string;
  description: string;
  requiredRole: string;
  isCompleted: boolean;
  completedAt?: Date;
  completedBy?: string;
  notes?: string;
}

export interface AcademicLeaveCloseWorkflow {
  workflowId: string;
  tenantId: string;
  academicYear: string;
  status: 'pending' | 'in-progress' | 'pending-principal' | 'approved' | 'rejected';
  steps: PrincipalWorkflowStep[];
  createdAt: Date;
  approvedAt?: Date;
  approvedBy?: string;
}

export function initializeLeaveCloseWorkflow(
  config: EducationTenantConfig,
  academicYear: string,
): AcademicLeaveCloseWorkflow {
  return {
    workflowId: `lcw-${config.tenantId}-${academicYear.replace(/\//g, '-')}`,
    tenantId: config.tenantId,
    academicYear,
    status: 'pending',
    createdAt: new Date(),
    steps: [
      {
        stepId: 'step-1-verify',
        name: 'HR Verification',
        description: 'Verify all leave records are accurate and pending requests resolved',
        requiredRole: 'hr-admin',
        isCompleted: false,
      },
      {
        stepId: 'step-2-simulate',
        name: 'Simulate Year-End',
        description: 'Run simulation preview — confirm carry-forward, lapse, and encashment amounts',
        requiredRole: 'hr-admin',
        isCompleted: false,
      },
      {
        stepId: 'step-3-bursar',
        name: 'Bursar Sign-Off',
        description: 'Bursar reviews encashment amounts and confirms budget availability',
        requiredRole: 'bursar',
        isCompleted: false,
      },
      {
        stepId: 'step-4-principal',
        name: 'Principal Approval',
        description: 'Principal approves the academic year-end leave closing',
        requiredRole: 'principal',
        isCompleted: false,
      },
      {
        stepId: 'step-5-lock',
        name: 'Ledger Lock',
        description: 'HR locks ledger and initiates new academic year leave balances',
        requiredRole: 'hr-admin',
        isCompleted: false,
      },
    ],
  };
}

export function advanceWorkflowStep(
  workflow: AcademicLeaveCloseWorkflow,
  stepId: string,
  completedBy: string,
  notes?: string,
): AcademicLeaveCloseWorkflow {
  const steps = workflow.steps.map(s =>
    s.stepId === stepId
      ? { ...s, isCompleted: true, completedAt: new Date(), completedBy, notes }
      : s,
  );

  const allComplete = steps.every(s => s.isCompleted);
  const principalStep = steps.find(s => s.stepId === 'step-4-principal');
  const awaitingPrincipal = steps.slice(0, 3).every(s => s.isCompleted) && !principalStep?.isCompleted;

  const status = allComplete ? 'approved'
    : awaitingPrincipal ? 'pending-principal'
    : steps.some(s => s.isCompleted) ? 'in-progress'
    : 'pending';

  return {
    ...workflow,
    steps,
    status,
    approvedAt: allComplete ? new Date() : undefined,
    approvedBy: allComplete ? completedBy : undefined,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// STAFF VALIDATION (Education-specific)
// ─────────────────────────────────────────────────────────────────────────────

export interface StaffValidationResult {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

export function validateStaffOnboarding(
  config: EducationTenantConfig,
  staff: {
    name: string;
    staffType: 'teaching' | 'non-teaching' | 'admin';
    designation: string;
    qualifications?: string[];
    joinDate: string;
  },
): StaffValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!staff.name?.trim()) errors.push('Staff name is required');
  if (!staff.designation?.trim()) errors.push('Designation (Teaching Post) is required');
  if (!staff.joinDate) errors.push('Join date is required');

  if (staff.staffType === 'teaching') {
    if (!staff.qualifications?.length) {
      warnings.push('Teaching staff should have qualifications recorded for accreditation purposes');
    }
    // Join date should ideally be at start of academic year
    const joinMonth = new Date(staff.joinDate).getMonth() + 1;
    if (joinMonth !== config.academicYearStartMonth) {
      warnings.push(`Teaching staff typically join at the start of academic year (Month ${config.academicYearStartMonth}). Join month is ${joinMonth}.`);
    }
  }

  return { isValid: errors.length === 0, errors, warnings };
}

// ─────────────────────────────────────────────────────────────────────────────
// EDUCATION MODE TOGGLE
// ─────────────────────────────────────────────────────────────────────────────

export interface ModeToggleResult {
  success: boolean;
  previousMode: 'education' | 'corporate';
  newMode: 'education' | 'corporate';
  warnings: string[];
  requiredActions: string[];
}

export function toggleEducationMode(
  tenantId: string,
  currentConfig: { isEducationMode: boolean },
  enable: boolean,
  tenantHasPayrollData: boolean,
): ModeToggleResult {
  const warnings: string[] = [];
  const requiredActions: string[] = [];

  if (currentConfig.isEducationMode === enable) {
    return {
      success: false,
      previousMode: enable ? 'education' : 'corporate',
      newMode: enable ? 'education' : 'corporate',
      warnings: ['No change — mode is already set to the requested state'],
      requiredActions: [],
    };
  }

  if (enable) {
    // Enabling education mode
    if (tenantHasPayrollData) {
      warnings.push('Existing payroll data will remain but pay commission grade mappings must be reconfigured');
    }
    requiredActions.push('Configure academic year start/end months');
    requiredActions.push('Set board affiliation (CBSE / ICSE / State Board)');
    requiredActions.push('Configure pay commission (7th / 8th)');
    requiredActions.push('Create teacher leave entitlements (EL, CL, ML, VL)');
    requiredActions.push('Assign education roles (teacher, HOD, principal, bursar) to staff');
    requiredActions.push('Verify disabled modules: recruitment, expense, analytics');
  } else {
    // Disabling education mode — return to corporate
    warnings.push('Education-specific roles (teacher, HOD, principal, bursar) will remain but can be deleted');
    warnings.push('Academic year leave balances will need to be migrated to standard financial year');
    requiredActions.push('Re-enable standard modules: recruitment, expense, analytics');
    requiredActions.push('Reassign staff to corporate roles');
  }

  return {
    success: true,
    previousMode: currentConfig.isEducationMode ? 'education' : 'corporate',
    newMode: enable ? 'education' : 'corporate',
    warnings,
    requiredActions,
  };
}
