import { Controller, Get } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { PrismaClient } from '@prisma/client';
import * as os from 'os';

@ApiTags('health')
@Controller()
export class HealthController {
  constructor(private readonly prisma: PrismaClient) {}

  @Get('health')
  @ApiOperation({ summary: 'Liveness probe' })
  async health(): Promise<Record<string, unknown>> {
    return {
      status: 'ok',
      timestamp: new Date().toISOString(),
      version: process.env['npm_package_version'] ?? '0.1.0',
      uptime: process.uptime(),
    };
  }

  @Get('health/ready')
  @ApiOperation({ summary: 'Readiness probe — checks DB connectivity' })
  async ready(): Promise<Record<string, unknown>> {
    let dbStatus = 'ok';
    let dbLatencyMs = 0;

    try {
      const start = Date.now();
      await this.prisma.$queryRaw`SELECT 1`;
      dbLatencyMs = Date.now() - start;
    } catch (_e) {
      dbStatus = 'error';
    }

    const status = dbStatus === 'ok' ? 'ok' : 'degraded';

    return {
      status,
      timestamp: new Date().toISOString(),
      checks: {
        database: { status: dbStatus, latencyMs: dbLatencyMs },
        memory: {
          status: 'ok',
          heapUsedMb: Math.round(process.memoryUsage().heapUsed / 1_048_576),
          heapTotalMb: Math.round(process.memoryUsage().heapTotal / 1_048_576),
          freeMb: Math.round(os.freemem() / 1_048_576),
        },
      },
    };
  }
}
