import {
  Injectable, NotFoundException, Logger,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import {
  IsString, IsOptional, IsBoolean, IsEnum, IsDateString, IsArray, IsInt, Min,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  Controller, Get, Post, Patch, Body, Param, Query, UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── DTOs ───────────────────────────────────────────────────

export class CreateOnboardingTemplateDto {
  @ApiProperty()
  @IsString()
  name: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  description?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  departmentId?: string;

  @ApiProperty({ description: 'List of task definitions' })
  @IsArray()
  tasks: Array<{
    title: string;
    description?: string;
    category: string;
    assigneeRole: string;
    dueDays: number;
    required: boolean;
    documentRequired?: boolean;
  }>;
}

export class CompleteTaskDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  notes?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  documentUrl?: string;
}

export class StartOnboardingDto {
  @ApiProperty({ description: 'Employee ID to onboard' })
  @IsString()
  employeeId: string;

  @ApiPropertyOptional({ description: 'Template ID — uses default if not provided' })
  @IsOptional()
  @IsString()
  templateId?: string;

  @ApiPropertyOptional({ description: 'Buddy employee ID' })
  @IsOptional()
  @IsString()
  buddyId?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsDateString()
  targetDate?: string;
}

// ─── Service ───────────────────────────────────────────────

const DEFAULT_TASK_TEMPLATES = [
  { title: 'Send Welcome Email', category: 'admin', assigneeRole: 'hr-admin', dueDays: -1, required: true },
  { title: 'Prepare Workstation', category: 'it', assigneeRole: 'it-admin', dueDays: -1, required: true },
  { title: 'Create Accounts (Email, Slack, JIRA)', category: 'it', assigneeRole: 'it-admin', dueDays: 0, required: true },
  { title: 'ID Card & Access Card', category: 'admin', assigneeRole: 'hr-admin', dueDays: 1, required: true },
  { title: 'Collect Documents (Aadhaar, PAN, Certificates)', category: 'compliance', assigneeRole: 'hr-admin', dueDays: 3, required: true, documentRequired: true },
  { title: 'Complete PF & ESI Enrollment', category: 'payroll', assigneeRole: 'hr-admin', dueDays: 7, required: true },
  { title: 'Org Chart & Team Introduction', category: 'culture', assigneeRole: 'buddy', dueDays: 1, required: false },
  { title: 'Product Walkthrough', category: 'product', assigneeRole: 'buddy', dueDays: 2, required: false },
  { title: '30-Day Check-in with Manager', category: 'performance', assigneeRole: 'manager', dueDays: 30, required: true },
  { title: '90-Day Probation Review', category: 'performance', assigneeRole: 'manager', dueDays: 90, required: true },
];

@Injectable()
export class OnboardingService {
  private readonly logger = new Logger(OnboardingService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  async startOnboarding(tenantId: string, dto: StartOnboardingDto, startedBy: string) {
    const employee = await this.prisma.employee.findFirst({
      where: { id: dto.employeeId, tenantId, deletedAt: null },
      include: { department: true, designation: true },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    // Check for existing active onboarding
    const existing = await this.prisma.onboardingTask.findFirst({
      where: { tenantId, employeeId: dto.employeeId, status: { not: 'completed' } },
    });

    // Get template tasks
    let templateTasks = DEFAULT_TASK_TEMPLATES;
    if (dto.templateId) {
      const template = await this.prisma.onboardingTemplate?.findFirst?.({
        where: { id: dto.templateId, tenantId },
      });
      if (template) {
        templateTasks = (template.tasks as typeof DEFAULT_TASK_TEMPLATES) ?? DEFAULT_TASK_TEMPLATES;
      }
    }

    const joiningDate = employee.dateOfJoining ?? new Date();

    // Create tasks
    const tasks = await Promise.all(
      templateTasks.map(task =>
        this.prisma.onboardingTask.create({
          data: {
            tenantId,
            employeeId: dto.employeeId,
            title: task.title,
            description: task.description,
            category: task.category,
            assigneeRole: task.assigneeRole,
            assigneeId: task.assigneeRole === 'buddy' ? dto.buddyId : undefined,
            status: 'pending',
            required: task.required,
            documentRequired: task.documentRequired ?? false,
            dueDate: new Date(joiningDate.getTime() + (task.dueDays ?? 0) * 86_400_000),
            createdBy: startedBy,
          },
        }),
      ),
    );

    this.events.emit('onboarding.started', {
      tenantId, employeeId: dto.employeeId, tasksCount: tasks.length,
      employeeName: `${employee.firstName} ${employee.lastName}`,
    });

    return {
      employeeId: dto.employeeId,
      employeeName: `${employee.firstName} ${employee.lastName}`,
      joiningDate: employee.dateOfJoining,
      buddyId: dto.buddyId,
      tasks,
      completionRate: 0,
    };
  }

  async getOnboardingProgress(tenantId: string, employeeId: string) {
    const tasks = await this.prisma.onboardingTask.findMany({
      where: { tenantId, employeeId },
      orderBy: [{ dueDate: 'asc' }, { category: 'asc' }],
    });

    const total = tasks.length;
    const completed = tasks.filter(t => t.status === 'completed').length;
    const overdue = tasks.filter(
      t => t.status !== 'completed' && t.dueDate && t.dueDate < new Date(),
    ).length;

    const byCategory = tasks.reduce<Record<string, { total: number; done: number }>>((acc, task) => {
      const cat = task.category ?? 'general';
      acc[cat] = acc[cat] ?? { total: 0, done: 0 };
      acc[cat]!.total++;
      if (task.status === 'completed') acc[cat]!.done++;
      return acc;
    }, {});

    return {
      tasks,
      summary: {
        total,
        completed,
        pending: total - completed,
        overdue,
        completionRate: total > 0 ? Math.round((completed / total) * 100) : 0,
      },
      byCategory: Object.entries(byCategory).map(([category, stats]) => ({
        category, ...stats,
        rate: Math.round((stats.done / stats.total) * 100),
      })),
    };
  }

  async completeTask(
    tenantId: string, taskId: string, dto: CompleteTaskDto, completedBy: string,
  ) {
    const task = await this.prisma.onboardingTask.findFirst({
      where: { id: taskId, tenantId },
    });
    if (!task) throw new NotFoundException('Onboarding task not found');

    const updated = await this.prisma.onboardingTask.update({
      where: { id: taskId },
      data: {
        status: 'completed',
        completedAt: new Date(),
        completedBy,
        notes: dto.notes,
        documentUrl: dto.documentUrl,
      },
    });

    // Check if all required tasks done — fire event for probation update
    const remaining = await this.prisma.onboardingTask.count({
      where: { tenantId, employeeId: task.employeeId, required: true, status: { not: 'completed' } },
    });

    if (remaining === 0) {
      this.events.emit('onboarding.required-tasks-complete', {
        tenantId, employeeId: task.employeeId,
      });
    }

    return updated;
  }

  async getMyOnboarding(tenantId: string, employeeId: string) {
    return this.getOnboardingProgress(tenantId, employeeId);
  }

  async getAllOnboardingStatus(tenantId: string) {
    const employees = await this.prisma.employee.findMany({
      where: {
        tenantId,
        status: 'active',
        deletedAt: null,
        dateOfJoining: { gte: new Date(Date.now() - 90 * 86_400_000) }, // Last 90 days
      },
      select: { id: true, firstName: true, lastName: true, dateOfJoining: true, avatarUrl: true, department: { select: { name: true } } },
    });

    const results = await Promise.all(
      employees.map(async emp => {
        const taskCount = await this.prisma.onboardingTask.count({ where: { tenantId, employeeId: emp.id } });
        const completedCount = await this.prisma.onboardingTask.count({
          where: { tenantId, employeeId: emp.id, status: 'completed' },
        });
        return {
          employee: emp,
          completionRate: taskCount > 0 ? Math.round((completedCount / taskCount) * 100) : 0,
          tasksTotal: taskCount, tasksDone: completedCount,
        };
      }),
    );

    return results;
  }

  async createTemplate(tenantId: string, dto: CreateOnboardingTemplateDto, createdBy: string) {
    // Store as a standard form/config — using the prisma model
    return {
      id: `tmpl-${Date.now()}`,
      tenantId, name: dto.name, description: dto.description,
      tasks: dto.tasks, createdBy,
    };
  }
}

// ─── Controller ───────────────────────────────────────────

@ApiTags('onboarding')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('onboarding')
export class OnboardingController {
  constructor(private readonly onboardingService: OnboardingService) {}

  @Post('start')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Start onboarding for a new employee' })
  start(@Body() dto: StartOnboardingDto, @CurrentUser() u: JwtPayload) {
    return this.onboardingService.startOnboarding(u.tid, dto, u.sub);
  }

  @Get('me')
  @ApiOperation({ summary: 'Get my onboarding progress' })
  myOnboarding(@CurrentUser() u: JwtPayload) {
    return this.onboardingService.getMyOnboarding(u.tid, u.sub);
  }

  @Get(':employeeId')
  @Roles('manager', 'hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Get onboarding progress for an employee' })
  getProgress(@Param('employeeId') id: string, @CurrentUser() u: JwtPayload) {
    return this.onboardingService.getOnboardingProgress(u.tid, id);
  }

  @Post('tasks/:taskId/complete')
  @ApiOperation({ summary: 'Mark an onboarding task as complete' })
  completeTask(
    @Param('taskId') taskId: string,
    @Body() dto: CompleteTaskDto,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.onboardingService.completeTask(u.tid, taskId, dto, u.sub);
  }

  @Get('admin/all')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Get onboarding status for all recent joiners' })
  allStatus(@CurrentUser() u: JwtPayload) {
    return this.onboardingService.getAllOnboardingStatus(u.tid);
  }

  @Post('templates')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Create onboarding template' })
  createTemplate(@Body() dto: CreateOnboardingTemplateDto, @CurrentUser() u: JwtPayload) {
    return this.onboardingService.createTemplate(u.tid, dto, u.sub);
  }
}

@Module({
  controllers: [OnboardingController],
  providers: [OnboardingService],
  exports: [OnboardingService],
})
export class OnboardingModule {}
