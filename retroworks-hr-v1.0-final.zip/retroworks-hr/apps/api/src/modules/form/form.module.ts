import { Controller, Get, Post, Patch, Delete, Body, Param, Query, UseGuards, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { FormService, type CreateFormDto } from './form.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';
import { Module } from '@nestjs/common';

@ApiTags('admin')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('forms')
export class FormController {
  constructor(private readonly formService: FormService) {}

  @Post()
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Create a form definition' })
  create(@Body() dto: CreateFormDto, @CurrentUser() user: JwtPayload) {
    return this.formService.create(user.tid, dto, user.sub);
  }

  @Get()
  @ApiOperation({ summary: 'List all form definitions' })
  list(@Query('entityType') entityType: string | undefined, @CurrentUser() user: JwtPayload) {
    return this.formService.list(user.tid, entityType);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get a specific form definition' })
  getOne(@Param('id') id: string, @CurrentUser() user: JwtPayload) {
    return this.formService.getOne(user.tid, id);
  }

  @Get('entity/:entityType')
  @ApiOperation({ summary: 'Get forms for a specific entity type, filtered by role' })
  getForEntity(
    @Param('entityType') entityType: string,
    @Query('state') state: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.formService.getForEntity(user.tid, entityType, user.roles, state);
  }

  @Patch(':id')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Update a form definition' })
  update(@Param('id') id: string, @Body() dto: Partial<CreateFormDto>, @CurrentUser() user: JwtPayload) {
    return this.formService.update(user.tid, id, dto, user.sub);
  }

  @Delete(':id')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.NO_CONTENT)
  remove(@Param('id') id: string, @CurrentUser() user: JwtPayload) {
    return this.formService.remove(user.tid, id, user.sub);
  }
}

@Module({
  controllers: [FormController],
  providers: [FormService],
  exports: [FormService],
})
export class FormModule {}
