import { Injectable, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import type { FormDefinition, FormSection } from '@retroworks/types';

export interface CreateFormDto {
  name: string;
  entityType: string;
  sections: FormSection[];
  visibleForRoles?: string[];
  workflowStates?: string[];
}

@Injectable()
export class FormService {
  constructor(private readonly prisma: PrismaClient) {}

  async create(tenantId: string, dto: CreateFormDto, createdBy: string) {
    // Validate sections have unique field names
    this.validateSections(dto.sections);

    return this.prisma.formDefinition.create({
      data: {
        tenantId,
        name: dto.name,
        entityType: dto.entityType,
        version: 1,
        sections: dto.sections as object[],
        visibleForRoles: dto.visibleForRoles ?? [],
        workflowStates: dto.workflowStates ?? [],
        isActive: true,
        createdBy,
        updatedBy: createdBy,
      },
    });
  }

  async update(tenantId: string, id: string, dto: Partial<CreateFormDto>, updatedBy: string) {
    const form = await this.getOne(tenantId, id);
    if (dto.sections) this.validateSections(dto.sections);

    return this.prisma.formDefinition.update({
      where: { id },
      data: {
        ...(dto.name && { name: dto.name }),
        ...(dto.sections && { sections: dto.sections as object[] }),
        ...(dto.visibleForRoles && { visibleForRoles: dto.visibleForRoles }),
        ...(dto.workflowStates && { workflowStates: dto.workflowStates }),
        version: form.version + 1,
        updatedBy,
      },
    });
  }

  async list(tenantId: string, entityType?: string) {
    return this.prisma.formDefinition.findMany({
      where: { tenantId, deletedAt: null, isActive: true, ...(entityType && { entityType }) },
      orderBy: { name: 'asc' },
    });
  }

  async getOne(tenantId: string, id: string) {
    const form = await this.prisma.formDefinition.findFirst({
      where: { id, tenantId, deletedAt: null },
    });
    if (!form) throw new NotFoundException('Form not found');
    return form;
  }

  async getForEntity(tenantId: string, entityType: string, roles: string[], state?: string) {
    const forms = await this.prisma.formDefinition.findMany({
      where: {
        tenantId,
        entityType,
        isActive: true,
        deletedAt: null,
        ...(state && { workflowStates: { has: state } }),
      },
    });

    // Filter by role visibility and apply field masking
    return forms.map(form => ({
      ...form,
      sections: (form.sections as FormSection[]).map(section => ({
        ...section,
        fields: section.fields.filter(field => {
          if (!field.hiddenForRoles?.length) return true;
          return !field.hiddenForRoles.some(r => roles.includes(r));
        }).map(field => ({
          ...field,
          // Mask fields for restricted roles
          masked: field.maskedForRoles?.some(r => roles.includes(r)) ?? false,
          // Make readonly for restricted roles
          readonly: field.readonlyForRoles?.some(r => roles.includes(r)) ?? false,
        })),
      })),
    }));
  }

  async remove(tenantId: string, id: string, deletedBy: string) {
    await this.getOne(tenantId, id);
    await this.prisma.formDefinition.update({
      where: { id },
      data: { deletedAt: new Date(), isActive: false, updatedBy: deletedBy },
    });
  }

  private validateSections(sections: FormSection[]): void {
    const fieldNames = new Set<string>();
    for (const section of sections) {
      for (const field of section.fields) {
        if (fieldNames.has(field.name)) {
          throw new BadRequestException(`Duplicate field name: "${field.name}"`);
        }
        fieldNames.add(field.name);
      }
    }
  }
}
