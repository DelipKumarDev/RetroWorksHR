import {
  Controller, Get, Post, Patch, Delete,
  Body, Param, Query, UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation,
  ApiOkResponse, ApiCreatedResponse, ApiNoContentResponse, ApiParam,
} from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { EmployeeService } from './employee.service';
import {
  CreateEmployeeDto, UpdateEmployeeDto,
  EmployeeQueryDto, BulkUpsertEmployeeDto,
} from './dto/employee.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequirePermission } from '../../common/decorators/permissions.decorator';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

@ApiTags('employees')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard, PermissionsGuard)
@Controller('employees')
export class EmployeeController {
  constructor(private readonly employeeService: EmployeeService) {}

  @Post()
  @RequirePermission({ resource: 'employee', action: 'create' })
  @ApiOperation({ summary: 'Create a new employee' })
  @ApiCreatedResponse({ description: 'Employee created successfully' })
  async create(
    @Body() dto: CreateEmployeeDto,
    @CurrentUser() user: JwtPayload,
  ) {
    const canViewPii = user.roles.some(r => ['hr-admin', 'super-admin'].includes(r));
    return this.employeeService.create(user.tid, dto, user.sub, canViewPii);
  }

  @Get()
  @RequirePermission({ resource: 'employee', action: 'read' })
  @ApiOperation({ summary: 'List employees with cursor pagination' })
  @ApiOkResponse({ description: 'Paginated employee list' })
  async findAll(
    @Query() query: EmployeeQueryDto,
    @CurrentUser() user: JwtPayload,
  ) {
    const canViewPii = user.roles.some(r => ['hr-admin', 'super-admin'].includes(r));
    return this.employeeService.findAll(user.tid, query, canViewPii);
  }

  @Get('org-chart')
  @RequirePermission({ resource: 'employee', action: 'read' })
  @ApiOperation({ summary: 'Get org chart tree structure' })
  async getOrgChart(
    @Query('rootId') rootId: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.employeeService.getOrgChart(user.tid, rootId);
  }

  @Get(':id')
  @RequirePermission({ resource: 'employee', action: 'read' })
  @ApiOperation({ summary: 'Get employee by ID' })
  @ApiParam({ name: 'id', description: 'Employee ID' })
  async findOne(
    @Param('id') id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    const canViewPii = user.roles.some(r => ['hr-admin', 'super-admin'].includes(r));
    return this.employeeService.findOne(user.tid, id, canViewPii);
  }

  @Patch(':id')
  @RequirePermission({ resource: 'employee', action: 'update' })
  @ApiOperation({ summary: 'Update employee' })
  async update(
    @Param('id') id: string,
    @Body() dto: UpdateEmployeeDto,
    @CurrentUser() user: JwtPayload,
  ) {
    const canViewPii = user.roles.some(r => ['hr-admin', 'super-admin'].includes(r));
    return this.employeeService.update(user.tid, id, dto, user.sub, canViewPii);
  }

  @Delete(':id')
  @RequirePermission({ resource: 'employee', action: 'delete' })
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Soft-delete employee' })
  @ApiNoContentResponse()
  async remove(
    @Param('id') id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    await this.employeeService.remove(user.tid, id, user.sub);
  }

  @Post('bulk-upsert')
  @RequirePermission({ resource: 'employee', action: 'import' })
  @ApiOperation({ summary: 'Bulk create/update employees (DataOps import)' })
  async bulkUpsert(
    @Body() dto: BulkUpsertEmployeeDto,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.employeeService.bulkUpsert(user.tid, dto, user.sub);
  }
}
