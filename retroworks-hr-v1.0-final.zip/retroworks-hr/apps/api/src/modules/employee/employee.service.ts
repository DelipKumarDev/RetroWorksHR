import {
  Injectable,
  NotFoundException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { PrismaClient, type Prisma } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import type { CursorPaginationResult } from '@retroworks/types';
import type {
  CreateEmployeeDto,
  UpdateEmployeeDto,
  EmployeeQueryDto,
  BulkUpsertEmployeeDto,
} from './dto/employee.dto';

// PII fields — masked for non-HR roles
const PII_FIELDS = ['panNumber', 'aadhaarNumber', 'bankAccountNumber', 'ifscCode'] as const;
const ALLOWED_FIELDS = [
  'id', 'employeeCode', 'firstName', 'lastName', 'middleName', 'preferredName',
  'email', 'workEmail', 'phone', 'gender', 'dateOfBirth', 'dateOfJoining',
  'dateOfLeaving', 'employmentType', 'status', 'departmentId', 'designationId',
  'locationId', 'managerId', 'gradeId', 'noticePeriodDays', 'avatarUrl',
  'createdAt', 'updatedAt',
];

type EmployeeWithRelations = Prisma.EmployeeGetPayload<{
  include: {
    department: { select: { id: true; name: true; code: true } };
    designation: { select: { id: true; name: true; code: true } };
    location: { select: { id: true; name: true; city: true; state: true } };
    manager: { select: { id: true; firstName: true; lastName: true; avatarUrl: true } };
    grade: { select: { id: true; name: true; level: true } };
  };
}>;

@Injectable()
export class EmployeeService {
  private readonly logger = new Logger(EmployeeService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ─────────────────────────────────────────────
  // CREATE
  // ─────────────────────────────────────────────

  async create(
    tenantId: string,
    dto: CreateEmployeeDto,
    createdBy: string,
    canViewPii = false,
  ): Promise<EmployeeWithRelations> {
    // Check uniqueness
    const existing = await this.prisma.employee.findFirst({
      where: {
        tenantId,
        OR: [
          { employeeCode: dto.employeeCode },
          { workEmail: dto.workEmail.toLowerCase() },
        ],
      },
    });

    if (existing) {
      const field = existing.employeeCode === dto.employeeCode ? 'Employee code' : 'Work email';
      throw new ConflictException(`${field} already exists`);
    }

    const employee = await this.prisma.employee.create({
      data: {
        tenantId,
        employeeCode: dto.employeeCode.trim(),
        firstName: dto.firstName.trim(),
        lastName: dto.lastName.trim(),
        middleName: dto.middleName?.trim(),
        preferredName: dto.preferredName?.trim(),
        email: (dto.email ?? dto.workEmail).toLowerCase(),
        workEmail: dto.workEmail.toLowerCase(),
        phone: dto.phone,
        gender: dto.gender,
        dateOfBirth: dto.dateOfBirth ? new Date(dto.dateOfBirth) : undefined,
        dateOfJoining: new Date(dto.dateOfJoining),
        employmentType: dto.employmentType ?? 'full-time',
        status: 'active',
        departmentId: dto.departmentId,
        designationId: dto.designationId,
        locationId: dto.locationId,
        managerId: dto.managerId,
        gradeId: dto.gradeId,
        noticePeriodDays: dto.noticePeriodDays ?? 30,
        probationEndDate: dto.probationEndDate ? new Date(dto.probationEndDate) : undefined,
        // PII — encrypt in production (see encryption service)
        panNumber: dto.panNumber,
        aadhaarNumber: dto.aadhaarNumber,
        uanNumber: dto.uanNumber,
        bankAccountNumber: dto.bankAccountNumber,
        ifscCode: dto.ifscCode,
        bankName: dto.bankName,
        createdBy,
        updatedBy: createdBy,
      },
      include: this.defaultInclude(),
    });

    this.events.emit('employee.created', { tenantId, employee, createdBy });
    this.events.emit('audit.created', {
      tenantId, userId: createdBy, action: 'CREATE',
      resource: 'employee', resourceId: employee.id,
      newData: { employeeCode: employee.employeeCode, name: `${employee.firstName} ${employee.lastName}` },
    });

    return this.maskPii(employee, canViewPii) as EmployeeWithRelations;
  }

  // ─────────────────────────────────────────────
  // FIND ALL (cursor pagination)
  // ─────────────────────────────────────────────

  async findAll(
    tenantId: string,
    query: EmployeeQueryDto,
    canViewPii = false,
  ): Promise<CursorPaginationResult<EmployeeWithRelations>> {
    const limit = Math.min(query.limit ?? 25, 100);

    // Build where clause
    const where: Prisma.EmployeeWhereInput = {
      tenantId,
      deletedAt: null,
      ...(query.status && { status: query.status }),
      ...(query.departmentId && { departmentId: query.departmentId }),
      ...(query.locationId && { locationId: query.locationId }),
      ...(query.managerId && { managerId: query.managerId }),
      ...(query.gradeId && { gradeId: query.gradeId }),
      ...(query.employmentType && { employmentType: query.employmentType }),
      ...(query.search && {
        OR: [
          { firstName: { contains: query.search, mode: 'insensitive' } },
          { lastName: { contains: query.search, mode: 'insensitive' } },
          { employeeCode: { contains: query.search, mode: 'insensitive' } },
          { workEmail: { contains: query.search, mode: 'insensitive' } },
        ],
      }),
      ...(query.cursor && { id: { lt: query.cursor } }),
    };

    const orderBy = {
      [query.sortBy ?? 'createdAt']: query.sortOrder ?? 'desc',
    } as Prisma.EmployeeOrderByWithRelationInput;

    // Fetch limit + 1 to detect hasMore
    const employees = await this.prisma.employee.findMany({
      where,
      include: this.defaultInclude(),
      orderBy,
      take: limit + 1,
    });

    const hasMore = employees.length > limit;
    const data = employees.slice(0, limit);
    const nextCursor = hasMore ? data[data.length - 1]?.id : undefined;

    const total = await this.prisma.employee.count({ where: { tenantId, deletedAt: null } });

    return {
      data: data.map(e => this.maskPii(e, canViewPii)) as EmployeeWithRelations[],
      nextCursor,
      hasMore,
      total,
    };
  }

  // ─────────────────────────────────────────────
  // FIND ONE
  // ─────────────────────────────────────────────

  async findOne(
    tenantId: string,
    id: string,
    canViewPii = false,
  ): Promise<EmployeeWithRelations> {
    const employee = await this.prisma.employee.findFirst({
      where: { id, tenantId, deletedAt: null },
      include: this.defaultInclude(),
    });

    if (!employee) throw new NotFoundException(`Employee ${id} not found`);

    return this.maskPii(employee, canViewPii) as EmployeeWithRelations;
  }

  async findByCode(tenantId: string, code: string): Promise<EmployeeWithRelations> {
    const employee = await this.prisma.employee.findFirst({
      where: { tenantId, employeeCode: code, deletedAt: null },
      include: this.defaultInclude(),
    });
    if (!employee) throw new NotFoundException(`Employee ${code} not found`);
    return employee;
  }

  // ─────────────────────────────────────────────
  // UPDATE
  // ─────────────────────────────────────────────

  async update(
    tenantId: string,
    id: string,
    dto: UpdateEmployeeDto,
    updatedBy: string,
    canViewPii = false,
  ): Promise<EmployeeWithRelations> {
    const existing = await this.findOne(tenantId, id);

    const updated = await this.prisma.employee.update({
      where: { id },
      data: {
        ...(dto.firstName && { firstName: dto.firstName.trim() }),
        ...(dto.lastName && { lastName: dto.lastName.trim() }),
        ...(dto.middleName !== undefined && { middleName: dto.middleName?.trim() }),
        ...(dto.preferredName !== undefined && { preferredName: dto.preferredName?.trim() }),
        ...(dto.phone !== undefined && { phone: dto.phone }),
        ...(dto.gender && { gender: dto.gender }),
        ...(dto.dateOfBirth && { dateOfBirth: new Date(dto.dateOfBirth) }),
        ...(dto.dateOfLeaving && { dateOfLeaving: new Date(dto.dateOfLeaving) }),
        ...(dto.employmentType && { employmentType: dto.employmentType }),
        ...(dto.status && { status: dto.status }),
        ...(dto.departmentId !== undefined && { departmentId: dto.departmentId }),
        ...(dto.designationId !== undefined && { designationId: dto.designationId }),
        ...(dto.locationId !== undefined && { locationId: dto.locationId }),
        ...(dto.managerId !== undefined && { managerId: dto.managerId }),
        ...(dto.gradeId !== undefined && { gradeId: dto.gradeId }),
        ...(dto.noticePeriodDays !== undefined && { noticePeriodDays: dto.noticePeriodDays }),
        ...(dto.avatarUrl !== undefined && { avatarUrl: dto.avatarUrl }),
        ...(dto.panNumber !== undefined && { panNumber: dto.panNumber }),
        ...(dto.aadhaarNumber !== undefined && { aadhaarNumber: dto.aadhaarNumber }),
        ...(dto.bankAccountNumber !== undefined && { bankAccountNumber: dto.bankAccountNumber }),
        ...(dto.ifscCode !== undefined && { ifscCode: dto.ifscCode }),
        ...(dto.bankName !== undefined && { bankName: dto.bankName }),
        updatedBy,
      },
      include: this.defaultInclude(),
    });

    this.events.emit('employee.updated', { tenantId, employeeId: id, updatedBy });
    this.events.emit('audit.created', {
      tenantId, userId: updatedBy, action: 'UPDATE',
      resource: 'employee', resourceId: id,
      oldData: { status: existing.status },
      newData: { status: updated.status },
    });

    return this.maskPii(updated, canViewPii) as EmployeeWithRelations;
  }

  // ─────────────────────────────────────────────
  // SOFT DELETE
  // ─────────────────────────────────────────────

  async remove(tenantId: string, id: string, deletedBy: string): Promise<void> {
    await this.findOne(tenantId, id);

    await this.prisma.employee.update({
      where: { id },
      data: { deletedAt: new Date(), deletedBy, status: 'terminated', updatedBy: deletedBy },
    });

    this.events.emit('audit.created', {
      tenantId, userId: deletedBy, action: 'DELETE',
      resource: 'employee', resourceId: id,
    });
  }

  // ─────────────────────────────────────────────
  // BULK UPSERT (for DataOps import)
  // ─────────────────────────────────────────────

  async bulkUpsert(
    tenantId: string,
    dto: BulkUpsertEmployeeDto,
    createdBy: string,
  ): Promise<{ created: number; updated: number; errors: Array<{ row: number; message: string }> }> {
    let created = 0;
    let updated = 0;
    const errors: Array<{ row: number; message: string }> = [];

    for (let i = 0; i < dto.employees.length; i++) {
      const emp = dto.employees[i];
      if (!emp) continue;

      try {
        const existing = await this.prisma.employee.findFirst({
          where: { tenantId, employeeCode: emp.employeeCode, deletedAt: null },
        });

        if (existing) {
          await this.update(tenantId, existing.id, emp, createdBy);
          updated++;
        } else {
          await this.create(tenantId, emp, createdBy);
          created++;
        }
      } catch (e) {
        errors.push({
          row: i + 1,
          message: e instanceof Error ? e.message : 'Unknown error',
        });
      }
    }

    this.logger.log(`Bulk upsert: ${created} created, ${updated} updated, ${errors.length} errors`);
    return { created, updated, errors };
  }

  // ─────────────────────────────────────────────
  // ORG CHART
  // ─────────────────────────────────────────────

  async getOrgChart(tenantId: string, rootId?: string): Promise<unknown> {
    const employees = await this.prisma.employee.findMany({
      where: { tenantId, status: 'active', deletedAt: null },
      select: {
        id: true, firstName: true, lastName: true, avatarUrl: true,
        managerId: true, departmentId: true,
        designation: { select: { name: true } },
        department: { select: { name: true } },
      },
    });

    // Build tree structure
    const byId = new Map(employees.map(e => [e.id, { ...e, children: [] as typeof employees }]));
    const roots: typeof employees = [];

    for (const emp of employees) {
      if (!emp.managerId || !byId.has(emp.managerId)) {
        roots.push(byId.get(emp.id) ?? emp);
      } else {
        const manager = byId.get(emp.managerId);
        if (manager) {
          (manager as { children: typeof employees }).children.push(byId.get(emp.id) ?? emp);
        }
      }
    }

    return rootId ? byId.get(rootId) : roots;
  }

  // ─────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────

  private defaultInclude() {
    return {
      department: { select: { id: true, name: true, code: true } },
      designation: { select: { id: true, name: true, code: true } },
      location: { select: { id: true, name: true, city: true, state: true } },
      manager: { select: { id: true, firstName: true, lastName: true, avatarUrl: true } },
      grade: { select: { id: true, name: true, level: true } },
    } as const;
  }

  private maskPii(employee: Record<string, unknown>, canViewPii: boolean): Record<string, unknown> {
    if (canViewPii) return employee;

    const masked = { ...employee };
    for (const field of PII_FIELDS) {
      if (masked[field]) {
        const val = String(masked[field]);
        masked[field] = '****' + val.slice(-4);
      }
    }
    return masked;
  }
}
