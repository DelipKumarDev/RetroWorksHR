import { Test, type TestingModule } from '@nestjs/testing';
import { NotFoundException, ConflictException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { EmployeeService } from '../employee.service';

const TENANT_ID = 'tenant-123';
const USER_ID = 'user-123';

const mockEmployee = {
  id: 'emp-001',
  tenantId: TENANT_ID,
  employeeCode: 'EMP001',
  firstName: 'Arjun',
  lastName: 'Sharma',
  email: 'arjun.sharma@acme.com',
  workEmail: 'arjun.sharma@acme.com',
  phone: null,
  gender: 'male',
  dateOfBirth: null,
  dateOfJoining: new Date('2023-01-01'),
  dateOfLeaving: null,
  employmentType: 'full-time',
  status: 'active',
  departmentId: 'dept-1',
  designationId: 'desig-1',
  locationId: 'loc-1',
  managerId: null,
  gradeId: null,
  noticePeriodDays: 60,
  avatarUrl: null,
  panNumber: 'ABCDE1234F',
  aadhaarNumber: '123456789012',
  bankAccountNumber: '9876543210',
  ifscCode: 'HDFC0001234',
  createdAt: new Date(),
  updatedAt: new Date(),
  deletedAt: null,
  createdBy: USER_ID,
  updatedBy: USER_ID,
  department: { id: 'dept-1', name: 'Engineering', code: 'ENG' },
  designation: { id: 'desig-1', name: 'Software Engineer', code: 'SWE' },
  location: { id: 'loc-1', name: 'Bangalore HQ', city: 'Bengaluru', state: 'KA' },
  manager: null,
  grade: null,
};

const mockPrisma = {
  employee: {
    findFirst: jest.fn(),
    findMany: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    count: jest.fn(),
  },
};

const mockEventEmitter = { emit: jest.fn() };

describe('EmployeeService', () => {
  let service: EmployeeService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        EmployeeService,
        { provide: 'PrismaClient', useValue: mockPrisma },
        { provide: EventEmitter2, useValue: mockEventEmitter },
      ],
    }).compile();

    service = module.get<EmployeeService>(EmployeeService);
    jest.clearAllMocks();
  });

  // ─────────────────────────────────────────────
  // CREATE
  // ─────────────────────────────────────────────

  describe('create', () => {
    const createDto = {
      employeeCode: 'EMP002',
      firstName: 'Priya',
      lastName: 'Patel',
      workEmail: 'priya.patel@acme.com',
      dateOfJoining: '2024-01-15',
    };

    it('creates employee successfully', async () => {
      mockPrisma.employee.findFirst.mockResolvedValueOnce(null); // No duplicate
      mockPrisma.employee.create.mockResolvedValue({ ...mockEmployee, ...createDto });

      const result = await service.create(TENANT_ID, createDto, USER_ID);

      expect(mockPrisma.employee.create).toHaveBeenCalled();
      expect(mockEventEmitter.emit).toHaveBeenCalledWith('employee.created', expect.anything());
    });

    it('throws ConflictException for duplicate employee code', async () => {
      mockPrisma.employee.findFirst.mockResolvedValue(mockEmployee);

      await expect(service.create(TENANT_ID, createDto, USER_ID)).rejects.toThrow(ConflictException);
    });

    it('masks PII fields for non-HR roles', async () => {
      mockPrisma.employee.findFirst.mockResolvedValueOnce(null);
      mockPrisma.employee.create.mockResolvedValue(mockEmployee);

      const result = await service.create(TENANT_ID, createDto, USER_ID, false) as Record<string, unknown>;

      // PAN masked
      expect(result['panNumber']).toMatch(/^\*{4}/);
      expect(result['panNumber']).not.toBe('ABCDE1234F');
    });

    it('shows full PII for HR admin roles', async () => {
      mockPrisma.employee.findFirst.mockResolvedValueOnce(null);
      mockPrisma.employee.create.mockResolvedValue(mockEmployee);

      const result = await service.create(TENANT_ID, createDto, USER_ID, true) as Record<string, unknown>;

      expect(result['panNumber']).toBe('ABCDE1234F');
    });
  });

  // ─────────────────────────────────────────────
  // FIND ALL
  // ─────────────────────────────────────────────

  describe('findAll', () => {
    it('returns paginated results', async () => {
      mockPrisma.employee.findMany.mockResolvedValue([mockEmployee]);
      mockPrisma.employee.count.mockResolvedValue(1);

      const result = await service.findAll(TENANT_ID, { limit: 25 });

      expect(result.data).toHaveLength(1);
      expect(result.total).toBe(1);
      expect(result.hasMore).toBe(false);
    });

    it('sets hasMore when more results exist', async () => {
      // Return 26 items when limit is 25 → hasMore = true
      const manyEmployees = Array.from({ length: 26 }, (_, i) => ({
        ...mockEmployee, id: `emp-${i}`,
      }));
      mockPrisma.employee.findMany.mockResolvedValue(manyEmployees);
      mockPrisma.employee.count.mockResolvedValue(100);

      const result = await service.findAll(TENANT_ID, { limit: 25 });

      expect(result.hasMore).toBe(true);
      expect(result.data).toHaveLength(25); // Sliced to limit
      expect(result.nextCursor).toBeDefined();
    });

    it('respects max limit of 100', async () => {
      mockPrisma.employee.findMany.mockResolvedValue([]);
      mockPrisma.employee.count.mockResolvedValue(0);

      await service.findAll(TENANT_ID, { limit: 999 });

      expect(mockPrisma.employee.findMany).toHaveBeenCalledWith(
        expect.objectContaining({ take: 101 }), // 100 + 1
      );
    });
  });

  // ─────────────────────────────────────────────
  // FIND ONE
  // ─────────────────────────────────────────────

  describe('findOne', () => {
    it('returns employee by id', async () => {
      mockPrisma.employee.findFirst.mockResolvedValue(mockEmployee);

      const result = await service.findOne(TENANT_ID, 'emp-001');
      expect(result).toBeDefined();
    });

    it('throws NotFoundException for missing employee', async () => {
      mockPrisma.employee.findFirst.mockResolvedValue(null);

      await expect(service.findOne(TENANT_ID, 'nonexistent')).rejects.toThrow(NotFoundException);
    });
  });

  // ─────────────────────────────────────────────
  // SOFT DELETE
  // ─────────────────────────────────────────────

  describe('remove', () => {
    it('soft deletes employee', async () => {
      mockPrisma.employee.findFirst.mockResolvedValue(mockEmployee);
      mockPrisma.employee.update.mockResolvedValue({ ...mockEmployee, deletedAt: new Date(), status: 'terminated' });

      await service.remove(TENANT_ID, 'emp-001', USER_ID);

      expect(mockPrisma.employee.update).toHaveBeenCalledWith(
        expect.objectContaining({
          where: { id: 'emp-001' },
          data: expect.objectContaining({ deletedAt: expect.any(Date), status: 'terminated' }),
        }),
      );
    });
  });
});
