import {
  Injectable, Logger, OnModuleInit,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2, OnEvent } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import { Controller, Get, Post, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── Types ───────────────────────────────────────────────

type NotifType =
  | 'leave.submitted' | 'leave.approved' | 'leave.rejected'
  | 'review.assigned' | 'review.self-due' | 'review.completed'
  | 'payslip.ready' | 'payroll.processed'
  | 'helpdesk.ticket.created' | 'helpdesk.ticket.replied'
  | 'onboarding.started' | 'onboarding.task.due'
  | 'ats.interview.scheduled' | 'ats.offer.received'
  | 'announcement.published'
  | 'expense.approved' | 'expense.rejected'
  | 'birthday' | 'work-anniversary' | 'probation-due'
  | 'general';

interface NotifPayload {
  type: NotifType;
  title: string;
  message: string;
  link?: string;
  meta?: Record<string, unknown>;
  channels?: Array<'in-app' | 'email' | 'slack'>;
}

// ─── Email Sender ────────────────────────────────────────

@Injectable()
export class EmailService {
  private readonly logger = new Logger(EmailService.name);
  private readonly fromEmail: string;
  private readonly sendgridKey?: string;

  constructor(private readonly config: ConfigService) {
    this.fromEmail = config.get<string>('EMAIL_FROM') ?? 'hr@retroworks.app';
    this.sendgridKey = config.get<string>('SENDGRID_API_KEY');
  }

  async send(to: string, subject: string, html: string): Promise<boolean> {
    if (!this.sendgridKey) {
      this.logger.warn(`[DEV] Email suppressed → ${to}: ${subject}`);
      return true;
    }

    try {
      const res = await fetch('https://api.sendgrid.com/v3/mail/send', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${this.sendgridKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          personalizations: [{ to: [{ email: to }] }],
          from: { email: this.fromEmail, name: 'RetroWorks HR' },
          subject,
          content: [{ type: 'text/html', value: html }],
        }),
      });

      if (!res.ok) {
        this.logger.error(`SendGrid error: ${res.status} ${await res.text()}`);
        return false;
      }
      return true;
    } catch (err) {
      this.logger.error('Email send failed:', err);
      return false;
    }
  }

  buildHtml(title: string, body: string, ctaText?: string, ctaLink?: string): string {
    return `<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><style>
  body { font-family: 'Courier New', monospace; background: #080c08; color: #4ade80; margin: 0; padding: 20px; }
  .container { max-width: 600px; margin: 0 auto; background: #0d150d; border: 1px solid #1a2e1a; border-radius: 8px; overflow: hidden; }
  .header { background: #0a1a0a; padding: 24px; border-bottom: 1px solid #1a2e1a; }
  .header h1 { color: #4ade80; font-size: 14px; letter-spacing: 2px; margin: 0; }
  .body { padding: 24px; }
  .title { color: #86efac; font-size: 18px; margin: 0 0 16px; }
  p { color: #4ade80; line-height: 1.6; margin: 0 0 16px; }
  .cta { display: inline-block; background: #166534; color: #4ade80; padding: 12px 24px; border-radius: 4px; text-decoration: none; font-family: monospace; }
  .footer { padding: 16px 24px; border-top: 1px solid #1a2e1a; font-size: 11px; color: #1a4a1a; }
</style></head>
<body>
  <div class="container">
    <div class="header"><h1>RETROWORKS HR</h1></div>
    <div class="body">
      <h2 class="title">${title}</h2>
      ${body}
      ${ctaText && ctaLink ? `<br><a href="${ctaLink}" class="cta">${ctaText}</a>` : ''}
    </div>
    <div class="footer">This is an automated message from RetroWorks HR. Please do not reply to this email.</div>
  </div>
</body>
</html>`;
  }
}

// ─── Notification Service ────────────────────────────────

@Injectable()
export class NotificationsService {
  private readonly logger = new Logger(NotificationsService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly email: EmailService,
    private readonly events: EventEmitter2,
    private readonly config: ConfigService,
  ) {}

  async create(tenantId: string, recipientId: string, payload: NotifPayload): Promise<void> {
    const channels = payload.channels ?? ['in-app'];

    // In-app notification
    if (channels.includes('in-app')) {
      await this.prisma.notification.create({
        data: {
          tenantId, recipientId,
          type: payload.type,
          title: payload.title,
          message: payload.message,
          link: payload.link,
          meta: payload.meta as any ?? {},
          read: false, createdBy: 'system',
        },
      });
    }

    // Email notification
    if (channels.includes('email')) {
      const employee = await this.prisma.employee.findFirst({
        where: { id: recipientId, tenantId },
        select: { email: true, firstName: true },
      });

      if (employee?.email) {
        const html = this.email.buildHtml(
          payload.title,
          `<p>Hi ${employee.firstName},</p><p>${payload.message}</p>`,
          payload.link ? 'View in RetroWorks' : undefined,
          payload.link ? `${this.config.get('APP_URL')}${payload.link}` : undefined,
        );
        await this.email.send(employee.email, payload.title, html);
      }
    }
  }

  async createBulk(tenantId: string, recipientIds: string[], payload: NotifPayload): Promise<void> {
    await this.prisma.notification.createMany({
      data: recipientIds.map(recipientId => ({
        tenantId, recipientId,
        type: payload.type,
        title: payload.title,
        message: payload.message,
        link: payload.link,
        meta: payload.meta as any ?? {},
        read: false, createdBy: 'system',
      })),
    });
  }

  async getMyNotifications(tenantId: string, recipientId: string, unreadOnly = false) {
    return this.prisma.notification.findMany({
      where: {
        tenantId, recipientId,
        ...(unreadOnly && { read: false }),
      },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }

  async getUnreadCount(tenantId: string, recipientId: string): Promise<number> {
    return this.prisma.notification.count({
      where: { tenantId, recipientId, read: false },
    });
  }

  async markRead(tenantId: string, recipientId: string, notifIds?: string[]): Promise<void> {
    await this.prisma.notification.updateMany({
      where: {
        tenantId, recipientId,
        ...(notifIds?.length ? { id: { in: notifIds } } : {}),
      },
      data: { read: true, readAt: new Date() },
    });
  }

  // ─── EVENT LISTENERS ──────────────────────────────────────

  @OnEvent('leave.approved')
  async onLeaveApproved(evt: { tenantId: string; employeeId: string; leaveType: string; days: number }) {
    await this.create(evt.tenantId, evt.employeeId, {
      type: 'leave.approved',
      title: 'Leave Request Approved ✓',
      message: `Your ${evt.leaveType} leave request for ${evt.days} day${evt.days > 1 ? 's' : ''} has been approved.`,
      link: '/dashboard/leave',
      channels: ['in-app', 'email'],
    });
  }

  @OnEvent('leave.rejected')
  async onLeaveRejected(evt: { tenantId: string; employeeId: string; reason: string }) {
    await this.create(evt.tenantId, evt.employeeId, {
      type: 'leave.rejected',
      title: 'Leave Request Declined',
      message: `Your leave request was declined. Reason: ${evt.reason}`,
      link: '/dashboard/leave',
      channels: ['in-app', 'email'],
    });
  }

  @OnEvent('payroll.run.completed')
  async onPayrollCompleted(evt: { tenantId: string; month: number; year: number }) {
    // Notify HR team
    const hrUsers = await this.prisma.employee.findMany({
      where: { tenantId: evt.tenantId, status: 'active', role: { in: ['hr-admin', 'super-admin'] } },
      select: { id: true },
    });

    await this.createBulk(evt.tenantId, hrUsers.map(u => u.id), {
      type: 'payroll.processed',
      title: 'Payroll Processed',
      message: `Payroll for ${evt.month}/${evt.year} has been processed and is ready for review.`,
      link: '/dashboard/payroll/admin',
      channels: ['in-app', 'email'],
    });
  }

  @OnEvent('ats.interview.scheduled')
  async onInterviewScheduled(evt: { tenantId: string; candidateId: string; interviewerIds: string[]; scheduledAt: Date }) {
    await this.createBulk(evt.tenantId, evt.interviewerIds, {
      type: 'ats.interview.scheduled',
      title: 'Interview Scheduled',
      message: `You have an interview scheduled for ${new Date(evt.scheduledAt).toLocaleDateString('en-IN', { dateStyle: 'full', timeStyle: 'short' })}.`,
      link: '/dashboard/ats',
      channels: ['in-app', 'email'],
    });
  }

  @OnEvent('helpdesk.ticket.created')
  async onTicketCreated(evt: { tenantId: string; ticket: any }) {
    // Notify HR team
    const hrUsers = await this.prisma.employee.findMany({
      where: { tenantId: evt.tenantId, status: 'active', role: { in: ['hr-admin'] } },
      select: { id: true },
    });

    if (hrUsers.length) {
      await this.createBulk(evt.tenantId, hrUsers.map(u => u.id), {
        type: 'helpdesk.ticket.created',
        title: `New Ticket: ${evt.ticket.ticketNumber}`,
        message: `${evt.ticket.title} (Priority: ${evt.ticket.priority?.toUpperCase()})`,
        link: `/dashboard/helpdesk/${evt.ticket.id}`,
        channels: ['in-app'],
      });
    }
  }

  @OnEvent('review.manager.submitted')
  async onManagerReviewDone(evt: { tenantId: string; employeeId: string; reviewId: string }) {
    await this.create(evt.tenantId, evt.employeeId, {
      type: 'review.completed',
      title: 'Performance Review Completed',
      message: 'Your manager has submitted their performance review. Check your review to see the feedback.',
      link: '/dashboard/performance',
      channels: ['in-app', 'email'],
    });
  }

  @OnEvent('announcement.published')
  async onAnnouncement(evt: { tenantId: string; announcement: any; targetEmployeeIds: string[] }) {
    if (!evt.targetEmployeeIds?.length) return;
    await this.createBulk(evt.tenantId, evt.targetEmployeeIds, {
      type: 'announcement.published',
      title: evt.announcement.title,
      message: evt.announcement.content?.slice(0, 120) + '...',
      link: '/dashboard/announcements',
      channels: ['in-app'],
    });
  }

  // ─── DIGEST: Birthday & Anniversary ──────────────────────

  async sendDailyDigest(tenantId: string): Promise<void> {
    const today = new Date();
    const month = today.getMonth() + 1;
    const day = today.getDate();

    // Birthdays
    const birthdays = await this.prisma.employee.findMany({
      where: {
        tenantId, status: 'active', deletedAt: null,
        dateOfBirth: { not: null },
      },
      select: { id: true, firstName: true, lastName: true, dateOfBirth: true },
    });

    const todayBirthdays = birthdays.filter(e => {
      const dob = new Date(e.dateOfBirth!);
      return dob.getMonth() + 1 === month && dob.getDate() === day;
    });

    // Work anniversaries
    const joiners = await this.prisma.employee.findMany({
      where: {
        tenantId, status: 'active', deletedAt: null,
        dateOfJoining: { not: null },
      },
      select: { id: true, firstName: true, lastName: true, dateOfJoining: true },
    });

    const anniversaries = joiners.filter(e => {
      const doj = new Date(e.dateOfJoining!);
      return doj.getMonth() + 1 === month && doj.getDate() === day && doj.getFullYear() < today.getFullYear();
    });

    // Notify each birthday person
    for (const emp of todayBirthdays) {
      await this.create(tenantId, emp.id, {
        type: 'birthday',
        title: `🎂 Happy Birthday, ${emp.firstName}!`,
        message: 'Wishing you a wonderful birthday from the entire RetroWorks family!',
        channels: ['in-app'],
      });
    }

    // Notify each anniversary person
    for (const emp of anniversaries) {
      const years = today.getFullYear() - new Date(emp.dateOfJoining!).getFullYear();
      await this.create(tenantId, emp.id, {
        type: 'work-anniversary',
        title: `🎉 ${years} Year${years > 1 ? 's' : ''} at RetroWorks!`,
        message: `Happy work anniversary! Thank you for ${years} amazing year${years > 1 ? 's' : ''} with us.`,
        channels: ['in-app'],
      });
    }

    this.logger.log(`Daily digest: ${todayBirthdays.length} birthdays, ${anniversaries.length} anniversaries for tenant ${tenantId}`);
  }
}

// ─── Controller ───────────────────────────────────────────

@ApiTags('notifications')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('notifications')
export class NotificationsController {
  constructor(private readonly notificationsService: NotificationsService) {}

  @Get()
  @ApiOperation({ summary: 'Get my notifications (newest first)' })
  getAll(@Query('unread') unread: string | undefined, @CurrentUser() u: JwtPayload) {
    return this.notificationsService.getMyNotifications(u.tid, u.sub, unread === 'true');
  }

  @Get('count')
  @ApiOperation({ summary: 'Get unread notification count' })
  count(@CurrentUser() u: JwtPayload) {
    return this.notificationsService.getUnreadCount(u.tid, u.sub);
  }

  @Post('read')
  @ApiOperation({ summary: 'Mark notifications as read' })
  markRead(@Body('ids') ids: string[] | undefined, @CurrentUser() u: JwtPayload) {
    return this.notificationsService.markRead(u.tid, u.sub, ids);
  }
}

@Module({
  controllers: [NotificationsController],
  providers: [NotificationsService, EmailService],
  exports: [NotificationsService, EmailService],
})
export class NotificationsModule {}
