/**
 * Form 16 Module
 * AUDIT-PAYROLL-2: PrismaClient replaced with PrismaTenantService.
 */
import { Module } from '@nestjs/common';
import { Form16Service } from './form16.service';
import { Form16Controller } from './form16.controller';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import { PrismaClient } from '@prisma/client';

@Module({
  controllers: [Form16Controller],
  providers: [Form16Service, PrismaTenantService, PrismaClient],
  exports: [Form16Service],
})
export class Form16Module {}
