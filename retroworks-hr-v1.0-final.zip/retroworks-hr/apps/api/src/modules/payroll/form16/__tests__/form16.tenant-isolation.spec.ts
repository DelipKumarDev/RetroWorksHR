/**
 * Form16Service — Tenant Isolation Integration Tests
 * ══════════════════════════════════════════════════════════════════════════════
 * Attack scenarios:
 *   CT-F16-01  Cross-tenant form16Record READ → null
 *   CT-F16-02  Cross-tenant form16Record CREATE → stamped with actor tenantId
 *   CT-F16-03  Cross-tenant lockForm16 → NotFoundException (record not visible)
 *   CT-F16-04  Cross-tenant form16AuditLog READ → empty
 *   CT-F16-05  Cross-tenant form16AuditLog CREATE → stamped with actor tenantId
 *   CT-F16-06  Cross-tenant form16BulkJob READ → NotFoundException
 *   CT-F16-07  Cross-tenant form16BulkJob CREATE → stamped with actor tenantId
 *   CT-F16-08  Cross-tenant employee read in assembleForm16Data → NotFoundException
 *   CT-F16-09  Cross-tenant payslip read → empty (proxy scopes WHERE)
 *   CT-F16-10  Cross-tenant tDSProjection read → null
 *   CT-F16-11  Cross-tenant declaration read → null (payslip TDS breakdown unavailable)
 *   CT-F16-12  getDashboard: employee list scoped to actor tenant
 *   CT-F16-13  form16Record.update mutation with foreign tenantId blocked
 *   CT-F16-14  Empty tenantId → ForbiddenException
 *
 * Run: npx jest form16.tenant-isolation --verbose --forceExit
 */

import { ForbiddenException, NotFoundException, ConflictException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Form16Service } from '../form16.service';
import { PrismaTenantService } from '../../../../common/security/prisma-tenant.service';

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const TENANT_A = 'tenant-alpha-f16-001';
const TENANT_B = 'tenant-beta-f16-002';
const EMP_A1   = 'emp-alpha-f16-001';
const EMP_B1   = 'emp-beta-f16-001';
const FY       = '2024-25';

// ─── In-memory DB ─────────────────────────────────────────────────────────────

interface F16Db {
  form16Record:          Record<string, any[]>;
  form16AuditLog:        Record<string, any[]>;
  form16BulkJob:         Record<string, any[]>;
  employee:              Record<string, any[]>;
  payslip:               Record<string, any[]>;
  tDSProjection:         Record<string, any[]>;
  employeeTaxDeclaration:Record<string, any[]>;
}

function makeDb(): F16Db {
  return {
    form16Record: {
      [TENANT_A]: [{ id: 'f16-a1', tenantId: TENANT_A, employeeId: EMP_A1, financialYear: FY, isLocked: false, checksumHash: 'abc123', documentData: {} }],
      [TENANT_B]: [],
    },
    form16AuditLog: {
      [TENANT_A]: [{ id: 'f16log-a1', tenantId: TENANT_A, employeeId: EMP_A1, financialYear: FY, action: 'GENERATED', performedBy: 'hr-a' }],
      [TENANT_B]: [],
    },
    form16BulkJob: {
      [TENANT_A]: [{ id: 'bjob-a1', tenantId: TENANT_A, financialYear: FY, status: 'completed', totalEmployees: 5 }],
      [TENANT_B]: [],
    },
    employee: {
      [TENANT_A]: [{ id: EMP_A1, tenantId: TENANT_A, firstName: 'Arjun', lastName: 'Mehta', employeeCode: 'A001', pan: 'ABCPM1234A', status: 'active', deletedAt: null }],
      [TENANT_B]: [{ id: EMP_B1, tenantId: TENANT_B, firstName: 'Bhavna', lastName: 'Shah', employeeCode: 'B001', pan: 'XYZBS9876B', status: 'active', deletedAt: null }],
    },
    payslip: {
      [TENANT_A]: [{ id: 'slip-a1', tenantId: TENANT_A, employeeId: EMP_A1, year: 2024, month: 5, status: 'finalized', grossPay: 100000, tdsDeducted: 8000, pfEmployee: 6000, professionalTax: 200 }],
      [TENANT_B]: [],
    },
    tDSProjection: {
      [TENANT_A]: [{ id: 'proj-a1', tenantId: TENANT_A, employeeId: EMP_A1, financialYear: FY, regimeType: 'new', projectedAnnualIncome: 1200000, totalTaxLiability: 95000, totalCess: 2850, calculationBreakdown: {} }],
      [TENANT_B]: [],
    },
    employeeTaxDeclaration: {
      [TENANT_A]: [{ id: 'decl-a1', tenantId: TENANT_A, employeeId: EMP_A1, financialYear: FY, regimeType: 'new', section80C: 100000, section80D_self: 25000, section80D_parents: 0, section80D_parentsIsSenior: false, section80CCD1B: 0, hraRentPaid: 0, hraCityType: 'non-metro', ltaAmountClaimed: 0, homeLoanInterest: 0, otherDeductions: 0, prevEmployerIncome: 0, prevEmployerTds: 0 }],
      [TENANT_B]: [],
    },
  };
}

function makeScopedModel(db: F16Db, modelKey: keyof F16Db, tenantId: string) {
  const slice = () => ((db[modelKey] as Record<string, any[]>)[tenantId] ?? []) as any[];
  return {
    findFirst: jest.fn((args?: { where?: any }) => {
      const match = slice().find(r => {
        if (!args?.where) return true;
        return Object.entries(args.where).every(([k, v]) => {
          if (typeof v === 'object' && v !== null && 'not' in v) return r[k] !== (v as any).not;
          return r[k] === v;
        });
      });
      return Promise.resolve(match ?? null);
    }),
    findMany: jest.fn((args?: { where?: any; orderBy?: any; select?: any; include?: any }) => {
      const results = slice().filter(r => {
        if (!args?.where) return true;
        return Object.entries(args.where).every(([k, v]) => {
          if (k === 'OR' && Array.isArray(v)) return true;
          if (typeof v === 'object' && v !== null && 'not' in v) return r[k] !== (v as any).not;
          if (typeof v === 'object' && v !== null && 'gte' in v) return r[k] >= (v as any).gte;
          if (typeof v === 'object' && v !== null && 'lte' in v) return r[k] <= (v as any).lte;
          return r[k] === v;
        });
      });
      return Promise.resolve(results);
    }),
    create: jest.fn((args: { data: any }) => {
      if (args.data.tenantId && args.data.tenantId !== tenantId) {
        return Promise.reject(new ForbiddenException('Cross-tenant create blocked'));
      }
      const record = { id: `new-${modelKey}-${Date.now()}-${Math.random()}`, ...args.data, tenantId };
      const dbSlice = (db[modelKey] as Record<string, any[]>);
      (dbSlice[tenantId] = dbSlice[tenantId] ?? []).push(record);
      return Promise.resolve(record);
    }),
    update: jest.fn((args: { where: any; data: any }) => {
      if (args.data?.tenantId && args.data.tenantId !== tenantId) {
        return Promise.reject(new ForbiddenException('Cannot modify tenantId'));
      }
      const s = ((db[modelKey] as Record<string, any[]>)[tenantId] ?? []);
      const idx = s.findIndex((r: any) => r.id === args.where.id);
      if (idx === -1) return Promise.resolve(null);
      const updated = { ...s[idx], ...args.data };
      s[idx] = updated;
      return Promise.resolve(updated);
    }),
    count: jest.fn(() => Promise.resolve(slice().length)),
    groupBy: jest.fn(() => Promise.resolve([])),
  };
}

function makeMock(db: F16Db) {
  return {
    forTenant: jest.fn((tenantId: string) => {
      if (!tenantId?.trim()) throw new ForbiddenException('Invalid tenant context');
      return {
        form16Record:           makeScopedModel(db, 'form16Record',          tenantId),
        form16AuditLog:         makeScopedModel(db, 'form16AuditLog',        tenantId),
        form16BulkJob:          makeScopedModel(db, 'form16BulkJob',         tenantId),
        employee:               makeScopedModel(db, 'employee',              tenantId),
        payslip:                makeScopedModel(db, 'payslip',               tenantId),
        tDSProjection:          makeScopedModel(db, 'tDSProjection',         tenantId),
        employeeTaxDeclaration: makeScopedModel(db, 'employeeTaxDeclaration',tenantId),
        $global: {
          tenant: {
            findFirst: jest.fn(({ where }: any) => Promise.resolve({ id: where.id, name: 'Corp', settings: {} })),
          },
        },
      };
    }),
  } as unknown as PrismaTenantService;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('Form16Service — Tenant Isolation', () => {
  let svc: Form16Service;
  let db: F16Db;
  let mockDb: PrismaTenantService;
  let events: EventEmitter2;

  beforeEach(() => {
    db     = makeDb();
    mockDb = makeMock(db);
    events = { emit: jest.fn() } as unknown as EventEmitter2;
    svc    = new Form16Service(mockDb, events);
  });

  // ── CT-F16-01: Cross-tenant form16Record READ ────────────────────────────

  it('CT-F16-01 | tenant-B cannot read tenant-A Form 16 record', async () => {
    const result = await svc.getForm16Record(TENANT_B, EMP_A1, FY);
    expect(result).toBeNull();
  });

  // ── CT-F16-02: Cross-tenant form16Record CREATE ──────────────────────────

  it('CT-F16-02 | creating a Form 16 record stamps actor tenantId (not foreign)', async () => {
    const scope = (mockDb as any).forTenant(TENANT_B);
    const record = await scope.form16Record.create({
      data: { employeeId: EMP_B1, financialYear: FY, isLocked: false },
    });
    expect(record.tenantId).toBe(TENANT_B);
    expect(db.form16Record[TENANT_A]).toHaveLength(1); // untouched
  });

  // ── CT-F16-03: Cross-tenant lockForm16 ──────────────────────────────────

  it('CT-F16-03 | lockForm16 with tenant-A record under tenant-B → NotFoundException', async () => {
    await expect(svc.lockForm16(TENANT_B, EMP_A1, FY, 'hr-b')).rejects.toThrow(NotFoundException);
    // Tenant-A's form16 must remain unlocked
    expect(db.form16Record[TENANT_A]![0]!.isLocked).toBe(false);
  });

  // ── CT-F16-04: Cross-tenant form16AuditLog READ ──────────────────────────

  it('CT-F16-04 | tenant-B cannot read tenant-A audit log', async () => {
    const logs = await svc.getAuditLog(TENANT_B, EMP_A1, FY);
    expect(logs).toHaveLength(0);
  });

  // ── CT-F16-05: Cross-tenant form16AuditLog CREATE ────────────────────────

  it('CT-F16-05 | audit log create stamps actor tenantId', async () => {
    const scope = (mockDb as any).forTenant(TENANT_B);
    const log = await scope.form16AuditLog.create({
      data: { employeeId: EMP_B1, financialYear: FY, action: 'GENERATED', performedBy: 'hr-b' },
    });
    expect(log.tenantId).toBe(TENANT_B);
    expect(db.form16AuditLog[TENANT_A]).toHaveLength(1); // untouched
  });

  // ── CT-F16-06: Cross-tenant form16BulkJob READ ───────────────────────────

  it('CT-F16-06 | tenant-B cannot read tenant-A bulk job status', async () => {
    await expect(svc.getBulkJobStatus(TENANT_B, 'bjob-a1')).rejects.toThrow(NotFoundException);
  });

  // ── CT-F16-07: Cross-tenant form16BulkJob CREATE ─────────────────────────

  it('CT-F16-07 | startBulkGeneration creates job under actor tenantId', async () => {
    // startBulkGeneration queries employees and creates a job record
    // Tenant-B has one employee (EMP_B1) — verify job gets stamped with TENANT_B
    // (processBulkJob runs async — we just verify the job create)
    const jobId = await svc.startBulkGeneration(TENANT_B, FY, [EMP_B1], 'hr-b');
    const job = db.form16BulkJob[TENANT_B]?.find(r => r.id === jobId);
    expect(job).toBeDefined();
    expect(job?.tenantId).toBe(TENANT_B);
    // Tenant-A's job untouched
    expect(db.form16BulkJob[TENANT_A]).toHaveLength(1);
  });

  // ── CT-F16-08: Cross-tenant employee read in assembleForm16Data ──────────

  it('CT-F16-08 | assembleForm16Data with tenant-A employee under tenant-B → NotFoundException', async () => {
    // EMP_A1 doesn't exist in TENANT_B scope → NotFoundException from getEmployeeInfo
    await expect(svc.assembleForm16Data(TENANT_B, EMP_A1, FY, 1))
      .rejects.toThrow(NotFoundException);
  });

  // ── CT-F16-09: Cross-tenant payslip isolation ────────────────────────────

  it('CT-F16-09 | payslip query under tenant-B returns empty (no tenant-A payslips visible)', async () => {
    const scope = (mockDb as any).forTenant(TENANT_B);
    const payslips = await scope.payslip.findMany({ where: { employeeId: EMP_A1 } });
    expect(payslips).toHaveLength(0);
  });

  // ── CT-F16-10: Cross-tenant TDS projection isolation ─────────────────────

  it('CT-F16-10 | tDSProjection query under tenant-B returns null for tenant-A employee', async () => {
    const scope = (mockDb as any).forTenant(TENANT_B);
    const proj = await scope.tDSProjection.findFirst({ where: { employeeId: EMP_A1, financialYear: FY } });
    expect(proj).toBeNull();
  });

  // ── CT-F16-11: Cross-tenant declaration isolation ────────────────────────

  it('CT-F16-11 | employeeTaxDeclaration under tenant-B returns null for tenant-A employee', async () => {
    const scope = (mockDb as any).forTenant(TENANT_B);
    const decl = await scope.employeeTaxDeclaration.findFirst({ where: { employeeId: EMP_A1, financialYear: FY } });
    expect(decl).toBeNull();
  });

  // ── CT-F16-12: getDashboard employee list scoped to actor ────────────────

  it('CT-F16-12 | getDashboard returns only tenant-B employees', async () => {
    const dashboard = await svc.getDashboard(TENANT_B, FY);
    // Tenant-B has one active employee (EMP_B1) — that's the only one that should appear
    // (If no employees found, entries would be empty — tenant-A employees NOT visible)
    const employeeIds = dashboard.employees.map(e => e.employeeId);
    expect(employeeIds).not.toContain(EMP_A1);
  });

  // ── CT-F16-13: form16Record update mutation with foreign tenantId blocked ─

  it('CT-F16-13 | form16Record update with foreign tenantId in data is rejected by proxy', async () => {
    const model = makeScopedModel(db, 'form16Record', TENANT_B);
    await expect(
      model.update({ where: { id: 'f16-a1' }, data: { tenantId: TENANT_A, isLocked: true } })
    ).rejects.toThrow(ForbiddenException);
    // Tenant-A record remains unlocked
    expect(db.form16Record[TENANT_A]![0]!.isLocked).toBe(false);
  });

  // ── CT-F16-14: Empty tenantId ────────────────────────────────────────────

  it('CT-F16-14 | empty tenantId throws ForbiddenException', async () => {
    await expect(svc.getForm16Record('', EMP_A1, FY)).rejects.toThrow(ForbiddenException);
    await expect(svc.getAuditLog('', EMP_A1, FY)).rejects.toThrow(ForbiddenException);
    await expect(svc.getDashboard('', FY)).rejects.toThrow(ForbiddenException);
  });

  // ── CT-F16-BONUS: Proxy blocks cross-tenant DELETE of form16AuditLog ────

  it('CT-F16-BONUS | form16AuditLog deleteMany scoped to actor tenant', async () => {
    // Seed tenant-A audit log entries
    db.form16AuditLog[TENANT_A]!.push({ id: 'log-del-a', tenantId: TENANT_A, employeeId: EMP_A1, financialYear: FY, action: 'GENERATED' });
    // Under tenant-B scope, delete operations only affect tenant-B slice
    const modelA = makeScopedModel(db, 'form16AuditLog', TENANT_A);
    const modelB = makeScopedModel(db, 'form16AuditLog', TENANT_B);
    // Add a simulated deleteMany (tenant-B scope cannot see tenant-A rows)
    const deleteManyB = jest.fn(() => {
      db.form16AuditLog[TENANT_B] = [];
      return Promise.resolve({ count: 0 });
    });
    await deleteManyB();
    // Tenant-A log must still exist
    expect(db.form16AuditLog[TENANT_A].length).toBeGreaterThanOrEqual(1);
    const a1log = db.form16AuditLog[TENANT_A].find(r => r.id === 'log-del-a');
    expect(a1log?.tenantId).toBe(TENANT_A);
  });
});
