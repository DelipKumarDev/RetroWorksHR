#!/usr/bin/env python3
"""
RetroWorks HR — Form 16 PDF Generator
══════════════════════════════════════════════════════════════════════════════
Generates a CBDT-format Form 16 (Part A + Part B) PDF using ReportLab.

Usage:
    python3 form16_pdf_generator.py --input /tmp/form16_data.json --output /tmp/form16_EMP001.pdf

⚠️  DISCLAIMER:
    Generated Form 16 is based on payroll system data.
    Must be verified against TRACES before issuance to employees.
    Subject to CA review and Income Tax Department assessment.

Legal basis:
    Section 203, Income Tax Act 1961 | Rule 31, IT Rules 1962
    CBDT Notification No. 36/2019
══════════════════════════════════════════════════════════════════════════════
"""

import json
import sys
import argparse
import hashlib
from datetime import datetime
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.lib.colors import (
    HexColor, black, white, Color
)
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak, KeepTogether
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.lib import colors

# ─── Color palette ───────────────────────────────────────────────────────────
BRAND_BLUE   = HexColor('#0F4C81')
DARK         = HexColor('#1A202C')
GRAY         = HexColor('#718096')
LIGHT_GRAY   = HexColor('#E2E8F0')
RED          = HexColor('#C53030')
GREEN        = HexColor('#276749')
GOLD         = HexColor('#B7791F')
GOLD_BG      = HexColor('#FFFFF0')
GREEN_BG     = HexColor('#F0FFF4')
RED_BG       = HexColor('#FFF5F5')
TABLE_HEADER = HexColor('#EBF8FF')
TABLE_ALT    = HexColor('#F7FAFC')
WARNING_BG   = HexColor('#FFFBEB')

# ─────────────────────────────────────────────────────────────────────────────

def fmt_inr(amount):
    """Format number as Indian Rupee string."""
    if amount is None:
        return '₹0.00'
    try:
        amount = float(amount)
        sign = '-' if amount < 0 else ''
        amount = abs(amount)
        # Indian number formatting
        s = f'{amount:,.2f}'
        return f'{sign}₹{s}'
    except (ValueError, TypeError):
        return '₹0.00'


def fmt_date(date_str):
    """Format ISO date string to DD-MMM-YYYY."""
    try:
        if 'T' in str(date_str):
            dt = datetime.fromisoformat(str(date_str).replace('Z', '+00:00'))
        else:
            dt = datetime.strptime(str(date_str)[:10], '%Y-%m-%d')
        return dt.strftime('%d-%b-%Y')
    except (ValueError, TypeError):
        return str(date_str)


class Form16PdfGenerator:
    """Generates a CBDT-compliant Form 16 PDF."""

    def __init__(self, data: dict):
        self.data = data
        self.part_a = data.get('partA', {})
        self.part_b = data.get('partB', {})
        self.employer = self.part_a.get('employer', {})
        self.employee = self.part_a.get('employee', {})
        self.tax = self.part_b.get('taxComputation', {})
        self.styles = self._build_styles()

    def _build_styles(self):
        base = getSampleStyleSheet()
        styles = {}

        styles['title'] = ParagraphStyle(
            'Title', parent=base['Normal'],
            fontSize=14, fontName='Helvetica-Bold',
            textColor=BRAND_BLUE, alignment=TA_CENTER,
            spaceAfter=4
        )
        styles['subtitle'] = ParagraphStyle(
            'Subtitle', parent=base['Normal'],
            fontSize=10, fontName='Helvetica',
            textColor=GRAY, alignment=TA_CENTER,
            spaceAfter=2
        )
        styles['section_header'] = ParagraphStyle(
            'SectionHeader', parent=base['Normal'],
            fontSize=10, fontName='Helvetica-Bold',
            textColor=white, alignment=TA_LEFT,
            spaceAfter=0, spaceBefore=0
        )
        styles['label'] = ParagraphStyle(
            'Label', parent=base['Normal'],
            fontSize=8, fontName='Helvetica',
            textColor=GRAY
        )
        styles['value'] = ParagraphStyle(
            'Value', parent=base['Normal'],
            fontSize=9, fontName='Helvetica-Bold',
            textColor=DARK
        )
        styles['body'] = ParagraphStyle(
            'Body', parent=base['Normal'],
            fontSize=8.5, fontName='Helvetica',
            textColor=DARK, leading=12
        )
        styles['disclaimer'] = ParagraphStyle(
            'Disclaimer', parent=base['Normal'],
            fontSize=7.5, fontName='Helvetica-Oblique',
            textColor=GRAY, alignment=TA_CENTER, leading=10
        )
        styles['amount'] = ParagraphStyle(
            'Amount', parent=base['Normal'],
            fontSize=9, fontName='Helvetica-Bold',
            textColor=DARK, alignment=TA_RIGHT
        )
        styles['total_label'] = ParagraphStyle(
            'TotalLabel', parent=base['Normal'],
            fontSize=9.5, fontName='Helvetica-Bold',
            textColor=DARK
        )
        styles['total_amount'] = ParagraphStyle(
            'TotalAmount', parent=base['Normal'],
            fontSize=9.5, fontName='Helvetica-Bold',
            textColor=BRAND_BLUE, alignment=TA_RIGHT
        )
        styles['warning'] = ParagraphStyle(
            'Warning', parent=base['Normal'],
            fontSize=8, fontName='Helvetica-Bold',
            textColor=GOLD, alignment=TA_CENTER
        )
        return styles

    def _section_header(self, text):
        """Creates a styled section header bar."""
        data = [[Paragraph(text, self.styles['section_header'])]]
        t = Table(data, colWidths=[170 * mm])
        t.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), BRAND_BLUE),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ]))
        return t

    def _kv_row(self, label, value, label_width=80):
        """Key-value row for header sections."""
        return [
            Paragraph(label, self.styles['label']),
            Paragraph(str(value), self.styles['value']),
        ]

    def _amount_row(self, label, amount, indent=0, bold=False, total=False, refund=False):
        """Row for tax computation table."""
        label_style = self.styles['total_label'] if total else self.styles['body']
        amount_style = self.styles['total_amount'] if total else self.styles['amount']
        color = RED if (refund and float(amount or 0) < 0) else (GREEN if total else DARK)
        label_p = Paragraph(('    ' * indent) + label, label_style)
        amount_p = Paragraph(fmt_inr(amount), amount_style)
        return [label_p, amount_p]

    def _hr(self, color=LIGHT_GRAY, thickness=0.5):
        return HRFlowable(width='100%', thickness=thickness, color=color, spaceAfter=4, spaceBefore=4)

    def _spacer(self, h=4):
        return Spacer(1, h * mm)

    # ─── COVER / HEADER ───────────────────────────────────────────────────────

    def build_document_header(self, elements):
        elements.append(Paragraph('FORM NO. 16', self.styles['title']))
        elements.append(Paragraph(
            '[See rule 31(1)(a) of the Income Tax Rules, 1962]',
            self.styles['subtitle']
        ))
        elements.append(Paragraph(
            'Certificate of deduction of tax at source under section 203 of the Income-tax Act, 1961',
            ParagraphStyle('subhead', fontSize=9, fontName='Helvetica-Oblique',
                           textColor=DARK, alignment=TA_CENTER)
        ))
        elements.append(self._spacer(3))
        elements.append(self._hr(BRAND_BLUE, 1.5))
        elements.append(self._spacer(2))

    # ─── PART A ───────────────────────────────────────────────────────────────

    def build_part_a(self, elements):
        elements.append(self._section_header('PART A — TDS Certificate Summary'))
        elements.append(self._spacer(3))

        # Certificate & period info
        cert_data = [
            ['Certificate No.', self.part_a.get('certificateNumber', 'N/A'),
             'Financial Year', self.part_a.get('financialYear', 'N/A')],
            ['Assessment Year', self.part_a.get('assessmentYear', 'N/A'),
             'Period', f"{self.part_a.get('periodFrom', '')} to {self.part_a.get('periodTo', '')}"],
        ]
        cert_style = [
            ('GRID', (0, 0), (-1, -1), 0.5, LIGHT_GRAY),
            ('BACKGROUND', (0, 0), (0, -1), TABLE_HEADER),
            ('BACKGROUND', (2, 0), (2, -1), TABLE_HEADER),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica-Bold'),
            ('FONTNAME', (3, 0), (3, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
        ]
        t = Table(cert_data, colWidths=[40*mm, 55*mm, 35*mm, 40*mm])
        t.setStyle(TableStyle(cert_style))
        elements.append(t)
        elements.append(self._spacer(4))

        # Employer & Employee side by side
        emp_header_style = [
            ('BACKGROUND', (0, 0), (-1, 0), TABLE_HEADER),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('FONTNAME', (0, 1), (0, -1), 'Helvetica'),
            ('FONTNAME', (1, 1), (1, -1), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, LIGHT_GRAY),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 5),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]

        employer_data = [
            ['EMPLOYER / DEDUCTOR', ''],
            ['Name', self.employer.get('name', '')],
            ['PAN', self.employer.get('pan', 'N/A')],
            ['TAN', self.employer.get('tan', 'N/A')],
            ['Address', self.employer.get('address', '')],
            ['City / State', f"{self.employer.get('city', '')} — {self.employer.get('state', '')}"],
        ]
        t_emp = Table(employer_data, colWidths=[28*mm, 52*mm])
        t_emp.setStyle(TableStyle(emp_header_style))

        employee_data = [
            ['EMPLOYEE / DEDUCTEE', ''],
            ['Name', self.employee.get('name', '')],
            ['PAN', self.employee.get('pan', 'N/A')],
            ['Employee Code', self.employee.get('employeeCode', '')],
            ['Designation', self.employee.get('designation', '')],
            ['Address', self.employee.get('address', '')],
        ]
        t_ee = Table(employee_data, colWidths=[28*mm, 52*mm])
        t_ee.setStyle(TableStyle(emp_header_style))

        combined = Table([[t_emp, t_ee]], colWidths=[83*mm, 83*mm])
        combined.setStyle(TableStyle([('LEFTPADDING', (0, 0), (-1, -1), 0),
                                       ('RIGHTPADDING', (0, 0), (-1, -1), 0),
                                       ('TOPPADDING', (0, 0), (-1, -1), 0),
                                       ('BOTTOMPADDING', (0, 0), (-1, -1), 0),
                                       ('VALIGN', (0, 0), (-1, -1), 'TOP')]))
        elements.append(combined)
        elements.append(self._spacer(5))

        # Quarterly TDS table
        elements.append(self._section_header('  Quarterly TDS Summary'))
        elements.append(self._spacer(2))

        q_data = [['Quarter', 'Period', 'Gross Salary Paid', 'TDS Deducted', 'TDS Deposited', 'Challan / Receipt']]
        q_periods = {'Q1': 'Apr–Jun', 'Q2': 'Jul–Sep', 'Q3': 'Oct–Dec', 'Q4': 'Jan–Mar'}
        quarterly = self.part_a.get('quarterlyTds', [])
        total_gross = total_tds = 0

        for q in quarterly:
            period = q_periods.get(q.get('quarter', ''), '')
            gross = q.get('grossSalaryPaid', 0)
            tds = q.get('tdsDeducted', 0)
            total_gross += gross
            total_tds += tds
            receipts = ', '.join(q.get('receiptNumbers', [])) or 'Pending TRACES'
            q_data.append([
                q.get('quarter', ''), period,
                fmt_inr(gross), fmt_inr(tds), fmt_inr(q.get('tdsDeposited', tds)),
                receipts
            ])

        q_data.append(['TOTAL', '', fmt_inr(total_gross), fmt_inr(total_tds), fmt_inr(total_tds), ''])

        q_style = [
            ('BACKGROUND', (0, 0), (-1, 0), BRAND_BLUE),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('ALIGN', (2, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (1, -1), 'CENTER'),
            ('GRID', (0, 0), (-1, -1), 0.5, LIGHT_GRAY),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('LEFTPADDING', (0, 0), (-1, -1), 5),
            ('BACKGROUND', (0, -1), (-1, -1), TABLE_HEADER),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('ROWBACKGROUNDS', (0, 1), (-1, -2), [white, TABLE_ALT]),
        ]
        t_q = Table(q_data, colWidths=[16*mm, 20*mm, 34*mm, 30*mm, 30*mm, 40*mm])
        t_q.setStyle(TableStyle(q_style))
        elements.append(t_q)
        elements.append(self._spacer(3))

        # Acknowledgement
        ack = self.part_a.get('acknowledgement', 'Pending TRACES integration')
        elements.append(Paragraph(
            f'TRACES Acknowledgement: {ack}',
            ParagraphStyle('ack', fontSize=8, fontName='Helvetica-Oblique', textColor=GRAY)
        ))

    # ─── PART B ───────────────────────────────────────────────────────────────

    def build_part_b(self, elements):
        elements.append(PageBreak())
        elements.append(self._section_header('PART B — Salary & Income Tax Computation'))
        elements.append(self._spacer(3))

        # Employee & FY info bar
        regime = self.part_b.get('regimeType', 'new').upper()
        info_data = [
            ['Employee', self.employee.get('name', ''), 'PAN', self.employee.get('pan', 'N/A'),
             'Regime', f'{regime} REGIME'],
            ['FY', self.part_b.get('financialYear', ''), 'AY',
             self.part_b.get('assessmentYear', ''), 'Employee Code', self.employee.get('employeeCode', '')]
        ]
        t_info = Table(info_data, colWidths=[18*mm, 55*mm, 12*mm, 32*mm, 22*mm, 31*mm])
        t_info.setStyle(TableStyle([
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica-Bold'),
            ('FONTNAME', (2, 0), (2, -1), 'Helvetica'),
            ('FONTNAME', (3, 0), (3, -1), 'Helvetica-Bold'),
            ('FONTNAME', (4, 0), (4, -1), 'Helvetica'),
            ('FONTNAME', (5, 0), (5, -1), 'Helvetica-Bold'),
            ('BACKGROUND', (0, 0), (0, -1), TABLE_HEADER),
            ('BACKGROUND', (2, 0), (2, -1), TABLE_HEADER),
            ('BACKGROUND', (4, 0), (4, -1), TABLE_HEADER),
            ('GRID', (0, 0), (-1, -1), 0.5, LIGHT_GRAY),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 5),
        ]))
        elements.append(t_info)
        elements.append(self._spacer(5))

        # Main tax computation table
        t_data = self._build_tax_computation_table()
        col_w = [130*mm, 40*mm]
        t_main = Table(t_data, colWidths=col_w)
        t_main.setStyle(self._tax_table_style(t_data))
        elements.append(t_main)
        elements.append(self._spacer(5))

        # Chapter VI-A deductions detail
        if self.part_b.get('regimeType') == 'old':
            elements.append(self._build_deductions_section())
            elements.append(self._spacer(3))

        # HRA exemption detail
        hra = self.part_b.get('hraExemption')
        if hra:
            elements.append(self._build_hra_section(hra))
            elements.append(self._spacer(3))

        # Slab-wise breakdown
        elements.append(self._build_slab_breakdown())
        elements.append(self._spacer(3))

        # Monthly TDS ledger
        elements.append(self._build_monthly_ledger())

    def _build_tax_computation_table(self):
        tax = self.tax
        sal = self.part_b.get('salaryComponents', {})
        gross = sal.get('totalGrossSalary', 0) or tax.get('grossSalary', 0)
        hra_ex = tax.get('hraExemption', 0)
        lta_ex = tax.get('ltaExemption', 0)
        other_s10 = tax.get('otherSection10Exemptions', 0)
        std_ded = tax.get('standardDeduction', 0)
        pt_ded = tax.get('professionalTaxDeduction', 0)
        income_chargeable = tax.get('incomeChargeable', 0)
        other_income = tax.get('otherIncome', 0)
        gross_total = tax.get('grossTotalIncome', 0)
        ch_via = tax.get('totalDeductions_ChVI_A', 0)
        taxable = tax.get('totalTaxableIncome', 0)
        tax_before_rebate = tax.get('taxBeforeRebate', 0)
        rebate = tax.get('rebate87A', 0)
        tax_after_rebate = tax.get('taxAfterRebate', 0)
        surcharge = tax.get('surcharge', 0)
        cess = tax.get('educationCess', 0)
        total_tax = tax.get('totalTaxLiability', 0)
        tds_deducted = tax.get('totalTdsDeducted', 0)
        payable = tax.get('taxPayableOrRefund', 0)

        hdr = lambda t: Paragraph(t, self.styles['section_header'])
        lbl = lambda t, i=0: Paragraph(('      ' * i) + t, self.styles['body'])
        amt = lambda a: Paragraph(fmt_inr(a), self.styles['amount'])
        tot_lbl = lambda t: Paragraph(t, self.styles['total_label'])
        tot_amt = lambda a, neg=False: Paragraph(
            fmt_inr(a),
            ParagraphStyle('ta', fontSize=10, fontName='Helvetica-Bold',
                           textColor=RED if (neg and float(a or 0) < 0) else BRAND_BLUE,
                           alignment=TA_RIGHT)
        )

        rows = [
            # Gross salary
            [lbl('1. Gross Salary (u/s 17(1))'), amt(gross)],
            [lbl('     Basic Pay', 1), amt(sal.get('basicPay', 0))],
            [lbl('     House Rent Allowance', 1), amt(sal.get('hraReceived', 0))],
            [lbl('     Special Allowance', 1), amt(sal.get('specialAllowance', 0))],
            [lbl('     Leave Travel Allowance', 1), amt(sal.get('ltaReceived', 0))],
            [lbl('     Medical Allowance', 1), amt(sal.get('medicalAllowance', 0))],
            [lbl('     Other Allowances', 1), amt(sal.get('otherAllowances', 0))],
            [lbl('     Bonus / Ex-Gratia', 1), amt(sal.get('bonus', 0))],
            # Perquisites
            [lbl('2. Perquisites u/s 17(2)'), amt(self.part_b.get('perquisites', 0))],
            [lbl('3. Profits in lieu of salary u/s 17(3)'), amt(self.part_b.get('profitsInLieuOfSalary', 0))],
            # TOTAL before exemptions
            [tot_lbl('   TOTAL (1+2+3)'), tot_amt(gross)],
        ]

        # Exemptions
        if hra_ex > 0 or lta_ex > 0 or other_s10 > 0:
            rows.append([lbl('4. Exemptions under Section 10'), amt('')])
            if hra_ex > 0:
                rows.append([lbl('     HRA Exemption [u/s 10(13A)]', 1), amt(-hra_ex)])
            if lta_ex > 0:
                rows.append([lbl('     LTA Exemption [u/s 10(5)]', 1), amt(-lta_ex)])
            if other_s10 > 0:
                rows.append([lbl('     Other Section 10 exemptions', 1), amt(-other_s10)])
            rows.append([lbl('   Income after exemptions'), amt(gross - hra_ex - lta_ex - other_s10)])

        # Standard deduction & PT
        rows += [
            [lbl('5. Standard Deduction [u/s 16(ia)]'), amt(-std_ded)],
            [lbl('6. Professional Tax [u/s 16(iii)]'), amt(-pt_ded)],
            [tot_lbl('   Income chargeable under "Salaries"'), tot_amt(income_chargeable)],
        ]

        # Other income
        if other_income > 0:
            rows.append([lbl('7. Income from previous employer / other heads'), amt(other_income)])

        rows += [
            [tot_lbl('   Gross Total Income'), tot_amt(gross_total)],
        ]

        # Chapter VI-A
        if ch_via > 0:
            rows += [
                [lbl('8. Deductions under Chapter VI-A'), amt(-ch_via)],
            ]

        rows += [
            [tot_lbl('   TOTAL TAXABLE INCOME'), tot_amt(taxable)],
            [Paragraph('', self.styles['body']), Paragraph('', self.styles['body'])],  # spacer
            [lbl('   Tax on total income (slab rates)'), amt(tax_before_rebate)],
        ]

        if rebate > 0:
            rows.append([lbl('   Less: Rebate u/s 87A'), amt(-rebate)])
        rows.append([lbl('   Tax after rebate'), amt(tax_after_rebate)])
        if surcharge > 0:
            rows.append([lbl('   Add: Surcharge'), amt(surcharge)])
        rows.append([lbl('   Add: Health & Education Cess @ 4%'), amt(cess)])
        rows += [
            [tot_lbl('   TOTAL TAX LIABILITY'), tot_amt(total_tax)],
            [lbl('   Less: Total TDS deducted'), amt(-tds_deducted)],
            [Paragraph('', self.styles['body']), Paragraph('', self.styles['body'])],
            [tot_lbl('   TAX PAYABLE / (REFUND)'), tot_amt(payable, neg=True)],
        ]

        return rows

    def _tax_table_style(self, data):
        n = len(data)
        style_cmds = [
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 5),
            ('RIGHTPADDING', (0, 0), (-1, -1), 5),
            ('LINEABOVE', (0, 0), (-1, 0), 1, BRAND_BLUE),
            ('LINEBELOW', (0, -1), (-1, -1), 1.5, BRAND_BLUE),
            ('ROWBACKGROUNDS', (0, 0), (-1, -1), [white, TABLE_ALT]),
        ]
        return TableStyle(style_cmds)

    def _build_deductions_section(self):
        ded = self.part_b.get('deductions', {})
        rows = [
            ['Chapter VI-A Deductions', 'Amount'],
            ['80C — PPF, ELSS, LIC, Home Loan Principal etc.', fmt_inr(ded.get('section80C', 0))],
            ['80D — Health Insurance (Self + Family)', fmt_inr(ded.get('section80D_self', 0))],
            ['80D — Health Insurance (Parents)', fmt_inr(ded.get('section80D_parents', 0))],
            ['80CCD(1B) — NPS Additional', fmt_inr(ded.get('section80CCD1B', 0))],
            ['24(b) — Home Loan Interest', fmt_inr(ded.get('homeLoanInterest_24b', 0))],
            ['Other Deductions', fmt_inr(ded.get('otherDeductions', 0))],
            ['TOTAL Chapter VI-A', fmt_inr(
                sum([ded.get(k, 0) for k in ['section80C', 'section80D_self', 'section80D_parents',
                                              'section80CCD1B', 'homeLoanInterest_24b', 'otherDeductions']])
            )],
        ]
        style = [
            ('BACKGROUND', (0, 0), (-1, 0), BRAND_BLUE),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('BACKGROUND', (0, -1), (-1, -1), TABLE_HEADER),
            ('GRID', (0, 0), (-1, -1), 0.5, LIGHT_GRAY),
            ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
            ('ROWBACKGROUNDS', (0, 1), (-1, -2), [white, TABLE_ALT]),
        ]
        t = Table(rows, colWidths=[130*mm, 40*mm])
        t.setStyle(TableStyle(style))
        return t

    def _build_hra_section(self, hra):
        rows = [
            ['HRA Exemption Computation (Section 10(13A))', 'Amount'],
            ['Actual HRA received (annual)', fmt_inr(hra.get('annualHraReceived', 0))],
            ['Annual rent paid', fmt_inr(hra.get('rentPaidAnnual', 0))],
            ['Annual basic salary', fmt_inr(hra.get('basicAnnual', 0))],
            ['Limit 1: Actual HRA received', fmt_inr(hra.get('limit1_actualHra', 0))],
            ['Limit 2: Rent paid - 10% of basic', fmt_inr(hra.get('limit2_rentMinusBasic10', 0))],
            ['Limit 3: 50%/40% of basic (metro/non-metro)', fmt_inr(hra.get('limit3_percentOfBasic', 0))],
            ['HRA Exemption (Minimum of 3 limits)', fmt_inr(hra.get('exemptionClaimed', 0))],
        ]
        style = [
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#4A5568')),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('BACKGROUND', (0, -1), (-1, -1), GREEN_BG),
            ('GRID', (0, 0), (-1, -1), 0.5, LIGHT_GRAY),
            ('ALIGN', (1, 0), (1, -1), 'RIGHT'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
            ('ROWBACKGROUNDS', (0, 1), (-1, -2), [white, TABLE_ALT]),
        ]
        t = Table(rows, colWidths=[130*mm, 40*mm])
        t.setStyle(TableStyle(style))
        return t

    def _build_slab_breakdown(self):
        slabs = self.tax.get('slabWiseBreakdown', [])
        if not slabs:
            return Spacer(1, 1)

        rows = [['Tax Slab', 'Rate', 'Income in Slab', 'Tax']]
        for s in slabs:
            rows.append([
                s.get('slabRange', ''), s.get('rate', ''),
                fmt_inr(s.get('income', 0)), fmt_inr(s.get('tax', 0))
            ])

        style = [
            ('BACKGROUND', (0, 0), (-1, 0), HexColor('#2D3748')),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('GRID', (0, 0), (-1, -1), 0.5, LIGHT_GRAY),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, TABLE_ALT]),
        ]
        t = Table(rows, colWidths=[70*mm, 20*mm, 45*mm, 35*mm])
        t.setStyle(TableStyle(style))
        return t

    def _build_monthly_ledger(self):
        ledger = self.part_b.get('monthlyLedger', [])
        if not ledger:
            return Spacer(1, 1)

        rows = [['Month', 'Gross Pay', 'PF Deduction', 'Professional Tax', 'TDS Deducted']]
        total_gross = total_pf = total_pt = total_tds = 0

        months_map = {1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May', 6: 'Jun',
                      7: 'Jul', 8: 'Aug', 9: 'Sep', 10: 'Oct', 11: 'Nov', 12: 'Dec'}

        for p in sorted(ledger, key=lambda x: (x.get('year', 0), x.get('month', 0))):
            m = months_map.get(p.get('month', 0), '')
            y = p.get('year', '')
            g = p.get('grossPay', 0)
            pf = p.get('pfEmployee', 0)
            pt = p.get('professionalTax', 0)
            tds = p.get('tdsDeducted', 0)
            total_gross += g; total_pf += pf; total_pt += pt; total_tds += tds
            rows.append([f'{m} {y}', fmt_inr(g), fmt_inr(pf), fmt_inr(pt), fmt_inr(tds)])

        rows.append(['TOTAL (FY)', fmt_inr(total_gross), fmt_inr(total_pf), fmt_inr(total_pt), fmt_inr(total_tds)])

        style = [
            ('BACKGROUND', (0, 0), (-1, 0), BRAND_BLUE),
            ('TEXTCOLOR', (0, 0), (-1, 0), white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            ('BACKGROUND', (0, -1), (-1, -1), TABLE_HEADER),
            ('GRID', (0, 0), (-1, -1), 0.5, LIGHT_GRAY),
            ('ALIGN', (1, 0), (-1, -1), 'RIGHT'),
            ('ALIGN', (0, 0), (0, -1), 'CENTER'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
            ('ROWBACKGROUNDS', (0, 1), (-1, -2), [white, TABLE_ALT]),
        ]
        t = Table(rows, colWidths=[25*mm, 36*mm, 36*mm, 36*mm, 37*mm])
        t.setStyle(TableStyle(style))
        return t

    # ─── SIGNATURE SECTION ────────────────────────────────────────────────────

    def build_signature_section(self, elements):
        elements.append(self._spacer(8))
        elements.append(self._hr(BRAND_BLUE, 1))
        elements.append(self._spacer(3))

        sig_data = [
            [
                Paragraph('Place: ________________', self.styles['body']),
                Paragraph('Signature: ________________________', self.styles['body']),
            ],
            [
                Paragraph('Date: ________________', self.styles['body']),
                Paragraph(f'Name: {self.employer.get("signatoryName", "_________________")}', self.styles['body']),
            ],
            [
                Paragraph('', self.styles['body']),
                Paragraph(f'Designation: {self.employer.get("designation", "_________________")}', self.styles['body']),
            ],
            [
                Paragraph('', self.styles['body']),
                Paragraph(f'For: {self.employer.get("name", "")}', self.styles['body']),
            ],
        ]
        t_sig = Table(sig_data, colWidths=[85*mm, 85*mm])
        t_sig.setStyle(TableStyle([
            ('FONTSIZE', (0, 0), (-1, -1), 8.5),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        elements.append(t_sig)
        elements.append(self._spacer(6))

        # Disclaimer
        elements.append(Table([[
            Paragraph(
                '⚠️  IMPORTANT DISCLAIMER: This Form 16 is generated from RetroWorks HR Payroll System '
                'and is based on the salary and declaration data available in the system. '
                'It must be verified against TRACES (TDS Reconciliation Analysis and Correction Enabling System) '
                'before issuance. The accuracy of this certificate is subject to CA review. '
                'Final tax liability will be determined by the Income Tax Department on assessment.',
                self.styles['disclaimer']
            )
        ]], colWidths=[170*mm], style=''))
        t_disc = Table([[
            Paragraph(
                '⚠️  IMPORTANT DISCLAIMER: This Form 16 is generated from RetroWorks HR Payroll System '
                'based on payroll data. Must be verified against TRACES before issuance. Subject to CA review.',
                self.styles['disclaimer']
            )
        ]], colWidths=[170*mm])
        t_disc.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), WARNING_BG),
            ('BOX', (0, 0), (-1, -1), 0.5, GOLD),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('LEFTPADDING', (0, 0), (-1, -1), 8),
            ('RIGHTPADDING', (0, 0), (-1, -1), 8),
        ]))
        elements.append(t_disc)

    # ─── PAGE TEMPLATE ────────────────────────────────────────────────────────

    @staticmethod
    def _on_page(canvas, doc):
        """Page header/footer on every page."""
        canvas.saveState()
        w, h = A4

        # Top header bar
        canvas.setFillColor(BRAND_BLUE)
        canvas.rect(0, h - 18*mm, w, 18*mm, fill=1, stroke=0)
        canvas.setFillColor(white)
        canvas.setFont('Helvetica-Bold', 10)
        canvas.drawString(15*mm, h - 10*mm, 'FORM 16 — INCOME TAX CERTIFICATE u/s 203')
        canvas.setFont('Helvetica', 8)
        canvas.drawRightString(w - 15*mm, h - 10*mm, 'Confidential | Generated by RetroWorks HR')

        # Footer
        canvas.setFillColor(BRAND_BLUE)
        canvas.rect(0, 0, w, 12*mm, fill=1, stroke=0)
        canvas.setFillColor(white)
        canvas.setFont('Helvetica', 7)
        canvas.drawString(15*mm, 4*mm, 'RetroWorks HR Payroll System | Subject to TRACES Verification | Not valid without employer signature')
        canvas.setFont('Helvetica-Bold', 8)
        canvas.drawRightString(w - 15*mm, 4*mm, f'Page {doc.page}')

        canvas.restoreState()

    # ─── MAIN GENERATE ────────────────────────────────────────────────────────

    def generate(self, output_path: str):
        doc = SimpleDocTemplate(
            output_path,
            pagesize=A4,
            rightMargin=20*mm, leftMargin=20*mm,
            topMargin=25*mm, bottomMargin=22*mm,
            title=f"Form 16 — {self.employee.get('name', '')} — FY {self.data.get('financialYear', '')}",
            author='RetroWorks HR Payroll System',
            subject='Certificate u/s 203 Income Tax Act 1961',
        )

        elements = []
        self.build_document_header(elements)
        self.build_part_a(elements)
        self.build_part_b(elements)
        self.build_signature_section(elements)

        doc.build(elements, onFirstPage=self._on_page, onLaterPages=self._on_page)
        return output_path


# ─────────────────────────────────────────────────────────────────────────────
# CLI ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description='Generate Form 16 PDF')
    parser.add_argument('--input', required=True, help='Path to JSON input file')
    parser.add_argument('--output', required=True, help='Path for output PDF')
    args = parser.parse_args()

    with open(args.input, 'r', encoding='utf-8') as f:
        data = json.load(f)

    generator = Form16PdfGenerator(data)
    output_path = generator.generate(args.output)

    # Print checksum to stdout for verification
    with open(output_path, 'rb') as f:
        checksum = hashlib.sha256(f.read()).hexdigest()
    print(json.dumps({'status': 'ok', 'path': output_path, 'sha256': checksum}))


if __name__ == '__main__':
    main()
