/**
 * RetroWorks HR — Form 16 Engine
 * ══════════════════════════════════════════════════════════════════════════════
 * Assembles the canonical Form 16 data structure from payroll ledger,
 * TDS projections, and employee declarations.
 *
 * Architecture: Pure functions only — zero DB access, fully testable.
 *
 * Legal basis:
 *   ▸ Section 203, Income Tax Act 1961
 *   ▸ Rule 31 of Income Tax Rules 1962
 *   ▸ CBDT Notification No. 36/2019 (Part B format)
 *   ▸ Finance Act 2024 (FY 2024-25)
 *
 * ⚠️  DISCLAIMER: Generated Form 16 is a computed document based on
 *     payroll system data. Must be verified against TRACES before
 *     issuing to employees. Subject to CA review.
 * ══════════════════════════════════════════════════════════════════════════════
 */

// ─────────────────────────────────────────────────────────────────────────────
// TYPES — Input data contracts
// ─────────────────────────────────────────────────────────────────────────────

export interface EmployerInfo {
  name: string;
  tan: string;          // TAN: XXXXX0000X format
  pan: string;          // PAN: XXXXXDDDDX format
  address: string;
  city: string;
  pincode: string;
  state: string;
  designation: string;  // Authorised signatory designation
  signatoryName: string;
}

export interface EmployeeInfo {
  id: string;
  name: string;
  pan: string;          // "APPLIED" if not yet received
  address: string;
  city: string;
  pincode: string;
  state: string;
  employeeCode: string;
  designation: string;
  department: string;
  dateOfJoining: string;
}

export interface QuarterlyTds {
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';     // Q1: Apr-Jun, Q2: Jul-Sep, Q3: Oct-Dec, Q4: Jan-Mar
  receiptNumbers: string[];                   // Challan / TRACES receipt
  tdsDeducted: number;
  tdsDeposited: number;
  grossSalaryPaid: number;
}

export interface MonthlyPayslipSummary {
  period: string;       // "2024-04"
  month: number;
  year: number;
  grossPay: number;
  tdsDeducted: number;
  pfEmployee: number;
  professionalTax: number;
}

// Chapter VI-A deductions breakdown
export interface DeductionBreakdown {
  standardDeduction: number;         // ₹50K (old) / ₹75K (new)
  section80C: number;                // Cap ₹1.5L
  section80D_self: number;           // ₹25K
  section80D_parents: number;        // ₹25K / ₹50K senior
  section80CCD1B: number;            // NPS ₹50K
  homeLoanInterest_24b: number;      // ₹2L
  otherDeductions: number;
  totalDeductions: number;
}

export interface HraExemptionBreakdown {
  annualHraReceived: number;
  rentPaidAnnual: number;
  basicAnnual: number;
  limit1_actualHra: number;
  limit2_rentMinusBasic10: number;
  limit3_percentOfBasic: number;
  exemptionClaimed: number;
}

export interface TaxComputation {
  grossSalary: number;              // Before any deductions
  hraExemption: number;             // Section 10(13A)
  ltaExemption: number;             // Section 10(5)
  otherSection10Exemptions: number;
  netSalaryAfterExemptions: number;
  standardDeduction: number;        // Section 16(ia)
  professionalTaxDeduction: number; // Section 16(iii)
  incomeChargeable: number;         // Under head "Salaries"
  otherIncome: number;
  grossTotalIncome: number;
  totalDeductions_ChVI_A: number;   // Chapter VI-A
  totalTaxableIncome: number;
  taxBeforeRebate: number;
  rebate87A: number;
  taxAfterRebate: number;
  surcharge: number;
  marginalRelief: number;
  educationCess: number;            // 4%
  totalTaxLiability: number;
  totalTdsDeducted: number;
  taxPayableOrRefund: number;       // Positive = payable, negative = refund
  effectiveTaxRate: number;         // %
  regimeType: 'old' | 'new';
  slabWiseBreakdown: Array<{
    slabRange: string;
    rate: string;
    income: number;
    tax: number;
  }>;
}

// ─────────────────────────────────────────────────────────────────────────────
// FORM 16 CANONICAL STRUCTURE
// ─────────────────────────────────────────────────────────────────────────────

export interface Form16PartA {
  // Certificate details
  certificateNumber: string;        // Unique per issuance
  financialYear: string;            // "2024-25"
  assessmentYear: string;           // "2025-26"
  periodFrom: string;               // "01-Apr-2024"
  periodTo: string;                 // "31-Mar-2025"
  // Parties
  employer: EmployerInfo;
  employee: EmployeeInfo;
  // TDS summary
  quarterlyTds: QuarterlyTds[];
  totalAmountPaidOrCredited: number;
  totalTdsDeducted: number;
  totalTdsDeposited: number;
  // Acknowledgement
  acknowledgement?: string;         // TRACES acknowledgement (stub if not integrated)
}

export interface Form16PartB {
  financialYear: string;
  assessmentYear: string;
  employer: Pick<EmployerInfo, 'name' | 'tan' | 'pan'>;
  employee: Pick<EmployeeInfo, 'name' | 'pan' | 'employeeCode'>;
  // Gross salary breakdown (Section 17(1))
  salaryComponents: {
    basicPay: number;
    hraReceived: number;
    specialAllowance: number;
    ltaReceived: number;
    medicalAllowance: number;
    otherAllowances: number;
    bonus: number;
    totalGrossSalary: number;
  };
  // Perquisites and profits (Section 17(2) & 17(3))
  perquisites: number;
  profitsInLieuOfSalary: number;
  // Exemptions under Section 10
  hraExemption: HraExemptionBreakdown | null;
  ltaExemption: number;
  otherSection10: number;
  // Chapter VI-A deductions
  deductions: DeductionBreakdown;
  // Tax computation
  taxComputation: TaxComputation;
  // Monthly TDS ledger
  monthlyLedger: MonthlyPayslipSummary[];
  // Regime
  regimeType: 'old' | 'new';
}

export interface Form16Document {
  id: string;
  checksumHash: string;
  generatedAt: Date;
  financialYear: string;
  assessmentYear: string;
  partA: Form16PartA;
  partB: Form16PartB;
  templateVersion: string;
  disclaimer: string;
  isLocked: boolean;
}

// ─────────────────────────────────────────────────────────────────────────────
// VALIDATION ERRORS
// ─────────────────────────────────────────────────────────────────────────────

export interface Form16ValidationError {
  code: string;
  field: string;
  message: string;
  severity: 'blocking' | 'warning';
}

export interface Form16ValidationResult {
  isValid: boolean;
  blockingErrors: Form16ValidationError[];
  warnings: Form16ValidationError[];
}

// ─────────────────────────────────────────────────────────────────────────────
// ASSEMBLY INPUT
// ─────────────────────────────────────────────────────────────────────────────

export interface Form16AssemblyInput {
  financialYear: string;            // "2024-25"
  employer: EmployerInfo;
  employee: EmployeeInfo;
  monthlyPayslips: MonthlyPayslipSummary[];
  tdsProjection: {
    regimeType: 'old' | 'new';
    projectedAnnualIncome: number;
    totalTaxLiability: number;
    totalCess: number;
    taxableIncome: number;
    taxBeforeRebate: number;
    rebate87A: number;
    taxAfterRebate: number;
    surcharge: number;
    cess: number;
    effectiveTaxRate: number;
    slabWiseBreakdown: Array<{
      slabFrom: number;
      slabTo: number;
      rate: number;
      incomeInSlab: number;
      taxInSlab: number;
    }>;
  };
  declaration: {
    regimeType: 'old' | 'new';
    section80C: number;
    section80D_self: number;
    section80D_parents: number;
    section80D_parentsIsSenior: boolean;
    section80CCD1B: number;
    hraRentPaid: number;
    hraCityType: 'metro' | 'non-metro';
    ltaAmountClaimed: number;
    homeLoanInterest: number;
    otherDeductions: number;
    prevEmployerIncome: number;
    prevEmployerTds: number;
  } | null;
  hraBreakdown?: {
    exemptionAnnual: number;
    rentPaidAnnual: number;
    basicAnnual: number;
    annualHraReceived: number;
    limit1_actualHra: number;
    limit2_rentMinusBasic10: number;
    limit3_percentOfBasic: number;
  };
  deductionsBreakdown?: {
    standardDeduction: number;
    section80C_allowed: number;
    section80D_allowed: number;
    section80CCD1B: number;
    hraExemption: number;
    ltaExemption: number;
    homeLoanInterest: number;
    otherDeductions: number;
    totalDeductions: number;
  };
  professionalTaxPaid: number;
  certificationNumber?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// PURE UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

export function r2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function getAssessmentYear(financialYear: string): string {
  // "2024-25" → "2025-26"
  const [startYear] = financialYear.split('-');
  const fy = parseInt(startYear ?? '2024', 10);
  return `${fy + 1}-${String(fy + 2).slice(2)}`;
}

export function fyToDateRange(financialYear: string): { from: string; to: string } {
  const [startYear] = financialYear.split('-');
  const fy = parseInt(startYear ?? '2024', 10);
  return {
    from: `01-Apr-${fy}`,
    to: `31-Mar-${fy + 1}`,
  };
}

export function getQuarterForMonth(calMonth: number): 1 | 2 | 3 | 4 {
  // Apr(4)-Jun(6)=Q1, Jul(7)-Sep(9)=Q2, Oct(10)-Dec(12)=Q3, Jan(1)-Mar(3)=Q4
  if (calMonth >= 4 && calMonth <= 6) return 1;
  if (calMonth >= 7 && calMonth <= 9) return 2;
  if (calMonth >= 10 && calMonth <= 12) return 3;
  return 4;
}

export function aggregateQuarterlyTds(payslips: MonthlyPayslipSummary[]): QuarterlyTds[] {
  const quarters: Record<number, QuarterlyTds> = {
    1: { quarter: 'Q1', receiptNumbers: [], tdsDeducted: 0, tdsDeposited: 0, grossSalaryPaid: 0 },
    2: { quarter: 'Q2', receiptNumbers: [], tdsDeducted: 0, tdsDeposited: 0, grossSalaryPaid: 0 },
    3: { quarter: 'Q3', receiptNumbers: [], tdsDeducted: 0, tdsDeposited: 0, grossSalaryPaid: 0 },
    4: { quarter: 'Q4', receiptNumbers: [], tdsDeducted: 0, tdsDeposited: 0, grossSalaryPaid: 0 },
  };

  for (const p of payslips) {
    const q = getQuarterForMonth(p.month);
    const qData = quarters[q]!;
    qData.tdsDeducted = r2(qData.tdsDeducted + p.tdsDeducted);
    qData.tdsDeposited = r2(qData.tdsDeposited + p.tdsDeducted); // Assumed deposited == deducted
    qData.grossSalaryPaid = r2(qData.grossSalaryPaid + p.grossPay);
  }

  return Object.values(quarters).filter(q => q.grossSalaryPaid > 0);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

// ─────────────────────────────────────────────────────────────────────────────
// VALIDATION ENGINE
// ─────────────────────────────────────────────────────────────────────────────

export function validateForm16Input(input: Form16AssemblyInput): Form16ValidationResult {
  const blocking: Form16ValidationError[] = [];
  const warnings: Form16ValidationError[] = [];

  // ── Employer validations ──
  if (!input.employer.tan || !/^[A-Z]{4}[0-9]{5}[A-Z]{1}$/.test(input.employer.tan)) {
    blocking.push({
      code: 'INVALID_TAN',
      field: 'employer.tan',
      message: `Employer TAN "${input.employer.tan}" is invalid. Format: XXXXX00000X (4 letters, 5 digits, 1 letter).`,
      severity: 'blocking',
    });
  }
  if (!input.employer.pan || !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(input.employer.pan)) {
    blocking.push({
      code: 'INVALID_EMPLOYER_PAN',
      field: 'employer.pan',
      message: `Employer PAN "${input.employer.pan}" is invalid. Format: XXXXXDDDDX.`,
      severity: 'blocking',
    });
  }
  if (!input.employer.name?.trim()) {
    blocking.push({ code: 'MISSING_EMPLOYER_NAME', field: 'employer.name', message: 'Employer name is required.', severity: 'blocking' });
  }

  // ── Employee validations ──
  if (!input.employee.pan) {
    blocking.push({ code: 'MISSING_EMPLOYEE_PAN', field: 'employee.pan', message: 'Employee PAN is required for Form 16.', severity: 'blocking' });
  } else if (input.employee.pan !== 'APPLIED' && !/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(input.employee.pan)) {
    blocking.push({
      code: 'INVALID_EMPLOYEE_PAN',
      field: 'employee.pan',
      message: `Employee PAN "${input.employee.pan}" is invalid.`,
      severity: 'blocking',
    });
  } else if (input.employee.pan === 'APPLIED') {
    warnings.push({
      code: 'EMPLOYEE_PAN_NOT_RECEIVED',
      field: 'employee.pan',
      message: 'Employee PAN not yet received. TDS rate may differ. Form 16 will show "APPLIED".',
      severity: 'warning',
    });
  }

  // ── TDS data validations ──
  if (!input.tdsProjection) {
    blocking.push({ code: 'MISSING_TDS_PROJECTION', field: 'tdsProjection', message: 'TDS projection not found. Run payroll for all months first.', severity: 'blocking' });
  }

  if (input.monthlyPayslips.length === 0) {
    blocking.push({ code: 'NO_PAYSLIPS', field: 'monthlyPayslips', message: 'No payslips found for this financial year.', severity: 'blocking' });
  }

  // ── TDS mismatch check ──
  const ledgerTds = r2(input.monthlyPayslips.reduce((s, p) => s + p.tdsDeducted, 0));
  const projectionTds = r2(input.tdsProjection?.totalTaxLiability ?? 0);
  const mismatch = Math.abs(ledgerTds - projectionTds);

  if (mismatch > 1) {
    // Mismatch > ₹1 is blocking
    blocking.push({
      code: 'TDS_MISMATCH',
      field: 'totalTdsDeducted',
      message: `TDS mismatch: Payroll ledger shows ₹${ledgerTds.toLocaleString('en-IN')} deducted, but TDS projection shows ₹${projectionTds.toLocaleString('en-IN')}. Difference: ₹${mismatch.toLocaleString('en-IN')}. Reconcile before generating Form 16.`,
      severity: 'blocking',
    });
  } else if (mismatch > 0) {
    warnings.push({
      code: 'TDS_ROUNDING_DIFF',
      field: 'totalTdsDeducted',
      message: `Minor rounding difference of ₹${mismatch} between ledger and projection. Acceptable (≤ ₹1).`,
      severity: 'warning',
    });
  }

  // ── Declaration warnings ──
  if (!input.declaration) {
    warnings.push({
      code: 'NO_DECLARATION',
      field: 'declaration',
      message: 'No tax declaration submitted by employee. New regime with no deductions assumed.',
      severity: 'warning',
    });
  }

  // ── Zero TDS ──
  if (ledgerTds === 0) {
    warnings.push({
      code: 'ZERO_TDS',
      field: 'totalTdsDeducted',
      message: 'Total TDS deducted is ₹0. Form 16 can still be generated but verify income is below tax threshold.',
      severity: 'warning',
    });
  }

  // ── Financial year format ──
  if (!/^\d{4}-\d{2}$/.test(input.financialYear)) {
    blocking.push({ code: 'INVALID_FY', field: 'financialYear', message: 'Financial year must be in format YYYY-YY (e.g., 2024-25)', severity: 'blocking' });
  }

  return {
    isValid: blocking.length === 0,
    blockingErrors: blocking,
    warnings,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// FORM 16 ASSEMBLY — PURE FUNCTION
// ─────────────────────────────────────────────────────────────────────────────

export function assembleForm16(
  input: Form16AssemblyInput,
  certNumber: string,
  templateVersion: string = '2024-25-v1',
): Form16Document {
  const fy = input.financialYear;
  const ay = getAssessmentYear(fy);
  const { from: periodFrom, to: periodTo } = fyToDateRange(fy);

  // ── Aggregate annual totals from payslips ──
  const totalGrossSalary = r2(input.monthlyPayslips.reduce((s, p) => s + p.grossPay, 0));
  const totalTdsDeducted = r2(input.monthlyPayslips.reduce((s, p) => s + p.tdsDeducted, 0));
  const totalPfDeducted = r2(input.monthlyPayslips.reduce((s, p) => s + p.pfEmployee, 0));
  const totalPtDeducted = r2(input.monthlyPayslips.reduce((s, p) => s + p.professionalTax, 0));

  // ── Salary component estimation from payslips ──
  // Note: Payslips carry full component detail; here we work with the aggregate
  const regimeType = (input.declaration?.regimeType ?? input.tdsProjection.regimeType) as 'old' | 'new';

  // ── Exemptions ──
  const hraExemption = input.hraBreakdown?.exemptionAnnual ?? 0;
  const ltaExemption = r2(input.declaration?.ltaAmountClaimed ?? 0);
  const otherSection10 = 0; // Extend as needed

  // ── Deductions breakdown ──
  const deductionsBD = input.deductionsBreakdown;
  const standardDeduction = deductionsBD?.standardDeduction ?? (regimeType === 'new' ? 75_000 : 50_000);
  const ptDeduction = totalPtDeducted; // Section 16(iii)

  // ── Tax computation ──
  const proj = input.tdsProjection;
  const grossTotalIncome = r2(totalGrossSalary + (input.declaration?.prevEmployerIncome ?? 0));
  const incomeAfterExemptions = r2(Math.max(0, grossTotalIncome - hraExemption - ltaExemption - otherSection10));
  const incomeChargeable = r2(Math.max(0, incomeAfterExemptions - standardDeduction - ptDeduction));
  const totalDeductions_ChVIA = r2(deductionsBD?.totalDeductions ?? standardDeduction) - standardDeduction; // Exclude std deduction
  const totalTaxableIncome = proj.taxableIncome;

  const taxComputation: TaxComputation = {
    grossSalary: totalGrossSalary,
    hraExemption,
    ltaExemption,
    otherSection10Exemptions: otherSection10,
    netSalaryAfterExemptions: incomeAfterExemptions,
    standardDeduction,
    professionalTaxDeduction: ptDeduction,
    incomeChargeable,
    otherIncome: input.declaration?.prevEmployerIncome ?? 0,
    grossTotalIncome,
    totalDeductions_ChVI_A: Math.max(0, totalDeductions_ChVIA),
    totalTaxableIncome,
    taxBeforeRebate: proj.taxBeforeRebate,
    rebate87A: proj.rebate87A,
    taxAfterRebate: proj.taxAfterRebate,
    surcharge: proj.surcharge,
    marginalRelief: 0,
    educationCess: proj.cess,
    totalTaxLiability: proj.totalTaxLiability,
    totalTdsDeducted,
    taxPayableOrRefund: r2(proj.totalTaxLiability - totalTdsDeducted),
    effectiveTaxRate: proj.effectiveTaxRate,
    regimeType,
    slabWiseBreakdown: proj.slabWiseBreakdown.map(s => ({
      slabRange: `₹${s.slabFrom.toLocaleString('en-IN')} – ${s.slabTo >= 999_999_999 ? 'Above' : '₹' + s.slabTo.toLocaleString('en-IN')}`,
      rate: `${(s.rate * 100).toFixed(0)}%`,
      income: s.incomeInSlab,
      tax: s.taxInSlab,
    })),
  };

  // ── Part A ──
  const quarterlyTds = aggregateQuarterlyTds(input.monthlyPayslips);

  const partA: Form16PartA = {
    certificateNumber: certNumber,
    financialYear: fy,
    assessmentYear: ay,
    periodFrom,
    periodTo,
    employer: input.employer,
    employee: input.employee,
    quarterlyTds,
    totalAmountPaidOrCredited: totalGrossSalary,
    totalTdsDeducted,
    totalTdsDeposited: totalTdsDeducted, // Assumed deposited == deducted
    acknowledgement: 'Pending TRACES integration',
  };

  // ── Part B deductions ──
  const deductionBreakdown: DeductionBreakdown = {
    standardDeduction,
    section80C: deductionsBD?.section80C_allowed ?? 0,
    section80D_self: deductionsBD ? (input.declaration?.section80D_self ?? 0) : 0,
    section80D_parents: deductionsBD ? (input.declaration?.section80D_parents ?? 0) : 0,
    section80CCD1B: deductionsBD?.section80CCD1B ?? 0,
    homeLoanInterest_24b: deductionsBD?.homeLoanInterest ?? 0,
    otherDeductions: deductionsBD?.otherDeductions ?? 0,
    totalDeductions: deductionsBD?.totalDeductions ?? standardDeduction,
  };

  // ── Part B ──
  const partB: Form16PartB = {
    financialYear: fy,
    assessmentYear: ay,
    employer: { name: input.employer.name, tan: input.employer.tan, pan: input.employer.pan },
    employee: { name: input.employee.name, pan: input.employee.pan, employeeCode: input.employee.employeeCode },
    salaryComponents: {
      basicPay: 0,        // Summed from payslips — populated by service layer
      hraReceived: 0,
      specialAllowance: 0,
      ltaReceived: 0,
      medicalAllowance: 0,
      otherAllowances: 0,
      bonus: 0,
      totalGrossSalary,
    },
    perquisites: 0,
    profitsInLieuOfSalary: 0,
    hraExemption: input.hraBreakdown ? {
      annualHraReceived: input.hraBreakdown.annualHraReceived,
      rentPaidAnnual: input.hraBreakdown.rentPaidAnnual,
      basicAnnual: input.hraBreakdown.basicAnnual,
      limit1_actualHra: input.hraBreakdown.limit1_actualHra,
      limit2_rentMinusBasic10: input.hraBreakdown.limit2_rentMinusBasic10,
      limit3_percentOfBasic: input.hraBreakdown.limit3_percentOfBasic,
      exemptionClaimed: input.hraBreakdown.exemptionAnnual,
    } : null,
    ltaExemption,
    otherSection10,
    deductions: deductionBreakdown,
    taxComputation,
    monthlyLedger: input.monthlyPayslips,
    regimeType,
  };

  // ── Build final document ──
  const docData = JSON.stringify({ partA, partB });
  const checksumHash = computeChecksum(docData);

  return {
    id: certNumber,
    checksumHash,
    generatedAt: new Date(),
    financialYear: fy,
    assessmentYear: ay,
    partA,
    partB,
    templateVersion,
    disclaimer: '⚠️ This Form 16 is generated from RetroWorks HR Payroll System. It must be verified against TRACES before issuance. Subject to CA review. Final tax liability as per Income Tax Department assessment.',
    isLocked: false,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// CHECKSUM — for tamper detection
// ─────────────────────────────────────────────────────────────────────────────

export function computeChecksum(data: string): string {
  // Simple deterministic hash for tamper detection
  // Production: use crypto.createHash('sha256')
  let hash = 0;
  for (let i = 0; i < data.length; i++) {
    const chr = data.charCodeAt(i);
    hash = ((hash << 5) - hash) + chr;
    hash |= 0;
  }
  return Math.abs(hash).toString(16).padStart(8, '0').toUpperCase();
}

export function generateCertificateNumber(
  tenantId: string,
  employeeCode: string,
  financialYear: string,
  sequenceNum: number,
): string {
  const fyCode = financialYear.replace('-', '');
  const seq = String(sequenceNum).padStart(4, '0');
  return `F16-${fyCode}-${employeeCode}-${seq}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// SUMMARY DASHBOARD DATA
// ─────────────────────────────────────────────────────────────────────────────

export interface Form16DashboardEntry {
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  pan: string;
  regimeType: string;
  grossSalary: number;
  totalTdsDeducted: number;
  taxLiability: number;
  taxPayableOrRefund: number;
  status: 'generated' | 'pending' | 'mismatch' | 'locked';
  generatedAt?: Date;
  mismatchAmount?: number;
}

export function buildDashboardEntry(
  employeeId: string,
  employeeName: string,
  employeeCode: string,
  pan: string,
  payslips: MonthlyPayslipSummary[],
  projection: { totalTaxLiability: number; regimeType: string } | null,
  form16Record: { generatedAt: Date; isLocked: boolean } | null,
): Form16DashboardEntry {
  const totalGross = r2(payslips.reduce((s, p) => s + p.grossPay, 0));
  const totalTds = r2(payslips.reduce((s, p) => s + p.tdsDeducted, 0));
  const taxLiability = projection?.totalTaxLiability ?? 0;
  const mismatch = r2(Math.abs(totalTds - taxLiability));

  let status: Form16DashboardEntry['status'] = 'pending';
  if (form16Record?.isLocked) status = 'locked';
  else if (form16Record) status = 'generated';
  else if (mismatch > 1) status = 'mismatch';

  return {
    employeeId,
    employeeName,
    employeeCode,
    pan: pan ?? 'NOT PROVIDED',
    regimeType: projection?.regimeType ?? 'new',
    grossSalary: totalGross,
    totalTdsDeducted: totalTds,
    taxLiability,
    taxPayableOrRefund: r2(taxLiability - totalTds),
    status,
    generatedAt: form16Record?.generatedAt,
    mismatchAmount: mismatch > 0 ? mismatch : undefined,
  };
}
