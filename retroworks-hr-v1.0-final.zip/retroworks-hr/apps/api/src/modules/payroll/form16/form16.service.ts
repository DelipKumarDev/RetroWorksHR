/**
 * Form 16 Service — Database-backed Form 16 lifecycle management
 * ══════════════════════════════════════════════════════════════════
 * AUDIT-PAYROLL-2: Refactored to use PrismaTenantService exclusively.
 *
 * BEFORE: 25 direct this.prisma.* calls.
 * AFTER:  Zero. All tenant ops via scope = db.forTenant(tenantId).
 *
 * GLOBAL via $global (no tenantId column):
 *   tenant — the master tenant record
 *
 * upsert → findFirst+create/update:
 *   form16Record: compound key tenantId_employeeId_financialYear unsafe with proxy
 */

import {
  Injectable, Logger, NotFoundException,
  ConflictException, BadRequestException,
} from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import * as path from 'path';
import * as fs from 'fs/promises';
import * as os from 'os';
import { createWriteStream, existsSync } from 'fs';
import { execFile } from 'child_process';
import { promisify } from 'util';
import * as archiver from 'archiver';

import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import {
  assembleForm16, validateForm16Input, generateCertificateNumber,
  buildDashboardEntry,
  type Form16AssemblyInput, type Form16Document,
  type Form16DashboardEntry, type EmployerInfo, type EmployeeInfo,
  type MonthlyPayslipSummary,
} from './form16.engine';

const execFileAsync = promisify(execFile);
const PDF_GENERATOR_SCRIPT = path.join(__dirname, 'form16_pdf_generator.py');
const TEMPLATE_VERSION = '2024-25-v1';
const BULK_JOB_BATCH_SIZE = 10;

@Injectable()
export class Form16Service {
  private readonly logger = new Logger(Form16Service.name);

  constructor(
    private readonly db: PrismaTenantService,
    private readonly events: EventEmitter2,
  ) {}

  // ─── Employer / Employee Info ──────────────────────────────────────────────

  private async getEmployerInfo(tenantId: string): Promise<EmployerInfo> {
    // tenant record is global (no tenantId column) — use $global
    const scope = this.db.forTenant(tenantId);
    const tenant = await scope.$global.tenant.findFirst({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Tenant not found');
    const s = (tenant.settings as any) ?? {};
    return {
      name: tenant.name, tan: s.tan ?? 'XXXX00000X', pan: s.pan ?? 'XXXXX0000X',
      address: s.address ?? '', city: s.city ?? '', pincode: s.pincode ?? '',
      state: s.state ?? '', designation: s.signatoryDesignation ?? 'Authorised Signatory',
      signatoryName: s.signatoryName ?? 'HR Manager',
    };
  }

  private async getEmployeeInfo(tenantId: string, employeeId: string): Promise<EmployeeInfo> {
    const scope = this.db.forTenant(tenantId);
    const emp = await scope.employee.findFirst({
      where: { id: employeeId },
      include: {
        department: { select: { name: true } },
        designation: { select: { title: true } },
      },
    });
    if (!emp) throw new NotFoundException(`Employee ${employeeId} not found`);
    return {
      id: (emp as any).id,
      name: `${(emp as any).firstName} ${(emp as any).lastName}`,
      pan: (emp as any).pan ?? 'APPLIED',
      address: (emp as any).address ?? '', city: (emp as any).city ?? '',
      pincode: (emp as any).pincode ?? '', state: (emp as any).state ?? '',
      employeeCode: (emp as any).employeeCode,
      designation: (emp as any).designation?.title ?? '',
      department: (emp as any).department?.name ?? '',
    };
  }

  // ─── Data Assembly ────────────────────────────────────────────────────────

  async assembleForm16Data(
    tenantId: string, employeeId: string,
    financialYear: string, sequenceNum: number,
  ): Promise<{ document: Form16Document; validationResult: ReturnType<typeof validateForm16Input> }> {
    const scope = this.db.forTenant(tenantId);

    const [employer, employee] = await Promise.all([
      this.getEmployerInfo(tenantId),
      this.getEmployeeInfo(tenantId, employeeId),
    ]);

    const fyStartYear = parseInt(financialYear.split('-')[0]!, 10);
    // proxy injects tenantId — no manual tenantId in where
    const payslips = await scope.payslip.findMany({
      where: {
        employeeId,
        status: { not: 'cancelled' },
        OR: [
          { year: fyStartYear, month: { gte: 4 } },
          { year: fyStartYear + 1, month: { lte: 3 } },
        ],
      },
      orderBy: [{ year: 'asc' }, { month: 'asc' }],
    });

    const monthlyPayslips: MonthlyPayslipSummary[] = (payslips as any[]).map(p => ({
      period: `${p.year}-${String(p.month).padStart(2, '0')}`,
      month: p.month, year: p.year,
      grossPay: Number(p.grossPay), tdsDeducted: Number(p.tdsDeducted ?? 0),
      pfEmployee: Number(p.pfEmployee ?? 0), professionalTax: Number(p.professionalTax ?? 0),
    }));

    const [tdsProjection, declaration] = await Promise.all([
      scope.tDSProjection.findFirst({ where: { employeeId, financialYear } }),
      scope.employeeTaxDeclaration.findFirst({ where: { employeeId, financialYear } }),
    ]);

    const projBreakdown = (tdsProjection as any)?.calculationBreakdown as any;
    const tdsProj = tdsProjection ? {
      regimeType: (tdsProjection as any).regimeType as 'old' | 'new',
      projectedAnnualIncome: Number((tdsProjection as any).projectedAnnualIncome),
      totalTaxLiability:     Number((tdsProjection as any).totalTaxLiability),
      totalCess:             Number((tdsProjection as any).totalCess),
      taxableIncome:         projBreakdown?.taxableIncome ?? 0,
      taxBeforeRebate:       projBreakdown?.taxBeforeRebate ?? 0,
      rebate87A:             projBreakdown?.rebate87A ?? 0,
      taxAfterRebate:        projBreakdown?.taxAfterRebate ?? 0,
      surcharge:             projBreakdown?.surcharge ?? 0,
      cess:                  projBreakdown?.cess ?? 0,
      effectiveTaxRate:      projBreakdown?.effectiveTaxRate ?? 0,
      slabWiseBreakdown:     projBreakdown?.slabWiseBreakdown ?? [],
    } : null;

    const certNum = generateCertificateNumber(tenantId, employee.employeeCode, financialYear, sequenceNum);
    const deductionsBD = projBreakdown?.deductions;
    const hraBreakdown = projBreakdown?.hraBreakdown ?? null;
    const profTaxTotal = monthlyPayslips.reduce((s, p) => s + p.professionalTax, 0);

    const assemblyInput: Form16AssemblyInput = {
      financialYear, employer, employee, monthlyPayslips,
      tdsProjection: tdsProj as any,
      declaration: declaration ? {
        regimeType:                (declaration as any).regimeType as 'old' | 'new',
        section80C:                Number((declaration as any).section80C),
        section80D_self:           Number((declaration as any).section80D_self),
        section80D_parents:        Number((declaration as any).section80D_parents),
        section80D_parentsIsSenior:(declaration as any).section80D_parentsIsSenior,
        section80CCD1B:            Number((declaration as any).section80CCD1B),
        hraRentPaid:               Number((declaration as any).hraRentPaid),
        hraCityType:               (declaration as any).hraCityType as 'metro' | 'non-metro',
        ltaAmountClaimed:          Number((declaration as any).ltaAmountClaimed),
        homeLoanInterest:          Number((declaration as any).homeLoanInterest),
        otherDeductions:           Number((declaration as any).otherDeductions),
        prevEmployerIncome:        Number((declaration as any).prevEmployerIncome),
        prevEmployerTds:           Number((declaration as any).prevEmployerTds),
      } : null,
      hraBreakdown: hraBreakdown ? {
        exemptionAnnual:       hraBreakdown.exemptionAnnual ?? 0,
        rentPaidAnnual:        hraBreakdown.rentPaidAnnual ?? 0,
        basicAnnual:           hraBreakdown.basicAnnual ?? 0,
        annualHraReceived:     hraBreakdown.annualHraReceived ?? 0,
        limit1_actualHra:      hraBreakdown.limit1_actualHra ?? 0,
        limit2_rentMinusBasic10: hraBreakdown.limit2_rentMinusBasic10 ?? 0,
        limit3_percentOfBasic: hraBreakdown.limit3_percentOfBasic ?? 0,
      } : undefined,
      deductionsBreakdown: deductionsBD ? {
        standardDeduction:   deductionsBD.standardDeduction ?? 0,
        section80C_allowed:  deductionsBD.section80C_allowed ?? 0,
        section80D_allowed:  deductionsBD.section80D_allowed ?? 0,
        section80CCD1B:      deductionsBD.section80CCD1B ?? 0,
        hraExemption:        deductionsBD.hraExemption ?? 0,
        ltaExemption:        deductionsBD.ltaExemption ?? 0,
        homeLoanInterest:    deductionsBD.homeLoanInterest ?? 0,
        otherDeductions:     deductionsBD.otherDeductions ?? 0,
        totalDeductions:     deductionsBD.totalDeductions ?? 0,
      } : undefined,
      professionalTaxPaid: profTaxTotal,
      certificationNumber: certNum,
    };

    const validationResult = validateForm16Input(assemblyInput);
    const document = assembleForm16(assemblyInput, certNum, TEMPLATE_VERSION);
    return { document, validationResult };
  }

  // ─── PDF Generation ───────────────────────────────────────────────────────

  async generatePdf(form16Doc: Form16Document, outputDir: string): Promise<{ pdfPath: string; sha256: string }> {
    const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'form16-'));
    const inputPath = path.join(tmpDir, `input_${form16Doc.id}.json`);
    const outputPath = path.join(outputDir, `Form16_${form16Doc.partA.employee.employeeCode}_FY${form16Doc.financialYear.replace('-', '')}.pdf`);
    try {
      await fs.writeFile(inputPath, JSON.stringify(form16Doc, null, 2), 'utf-8');
      await fs.mkdir(outputDir, { recursive: true });
      const { stdout, stderr } = await execFileAsync('python3', [
        PDF_GENERATOR_SCRIPT, '--input', inputPath, '--output', outputPath,
      ], { timeout: 60_000 });
      if (stderr) this.logger.warn(`PDF stderr: ${stderr}`);
      const result = JSON.parse(stdout.trim());
      if (result.status !== 'ok') throw new Error(`PDF failed: ${JSON.stringify(result)}`);
      return { pdfPath: outputPath, sha256: result.sha256 };
    } finally {
      await fs.unlink(inputPath).catch(() => {});
      await fs.rmdir(tmpDir).catch(() => {});
    }
  }

  // ─── Generate & Save ──────────────────────────────────────────────────────

  async generateForm16(
    tenantId: string, employeeId: string, financialYear: string,
    generatedBy: string, options: { force?: boolean } = {},
  ): Promise<{ record: any; validationResult: any; warnings: string[] }> {
    const scope = this.db.forTenant(tenantId);

    // proxy injects tenantId
    const existing = await scope.form16Record.findFirst({
      where: { employeeId, financialYear },
    });

    if (existing && (existing as any).isLocked && !options.force) {
      throw new ConflictException('Form 16 is locked. Use force=true to regenerate (requires admin).');
    }
    if (existing && !options.force) {
      throw new ConflictException('Form 16 already generated. Use force=true to regenerate.');
    }

    // count without exposing tenantId manually
    const count = await scope.form16Record.count({ where: { financialYear } });
    const seqNum = (count as unknown as number) + 1;

    const { document, validationResult } = await this.assembleForm16Data(
      tenantId, employeeId, financialYear, seqNum,
    );

    if (!validationResult.isValid) {
      const errors = validationResult.blockingErrors.map((e: any) => e.message).join('; ');
      throw new BadRequestException(`Form 16 blocked: ${errors}`);
    }

    const outputDir = process.env.FORM16_OUTPUT_DIR ?? '/tmp/form16-pdfs';
    const { pdfPath, sha256 } = await this.generatePdf(document, outputDir);

    const recordData = {
      employeeId, financialYear,
      assessmentYear:    document.assessmentYear,
      regimeType:        document.partB.regimeType,
      certificateNumber: document.id,
      checksumHash:      sha256, pdfPath,
      templateVersion:   TEMPLATE_VERSION,
      generatedBy,       generatedAt: new Date(),
      isLocked:          false,
      totalGrossSalary:  document.partB.taxComputation.grossSalary,
      totalTaxLiability: document.partB.taxComputation.totalTaxLiability,
      totalTdsDeducted:  document.partB.taxComputation.totalTdsDeducted,
      taxPayableOrRefund:document.partB.taxComputation.taxPayableOrRefund,
      documentData:      document as any,
    };

    // findFirst + create/update — proxy-safe
    let record: any;
    if (existing) {
      record = await scope.form16Record.update({
        where: { id: (existing as any).id },
        data: { ...recordData, updatedBy: generatedBy },
      });
    } else {
      record = await scope.form16Record.create({
        data: { ...recordData, createdBy: generatedBy },
      });
    }

    await scope.form16AuditLog.create({
      data: {
        employeeId, financialYear,
        action:               existing ? 'REGENERATED' : 'GENERATED',
        performedBy:          generatedBy,
        previousChecksumHash: (existing as any)?.checksumHash ?? null,
        newChecksumHash:      sha256,
        reason:               options.force ? 'Force regeneration by admin' : 'Initial generation',
        metadata:             { warnings: validationResult.warnings.map((w: any) => w.message) } as any,
        createdAt:            new Date(),
      },
    });

    this.logger.log(`Form 16 generated: ${employeeId} FY${financialYear} → ${pdfPath}`);
    this.events.emit('form16.generated', { tenantId, employeeId, financialYear, certNum: document.id });

    return { record, validationResult, warnings: validationResult.warnings.map((w: any) => w.message) };
  }

  // ─── Lock ─────────────────────────────────────────────────────────────────

  async lockForm16(tenantId: string, employeeId: string, financialYear: string, lockedBy: string): Promise<void> {
    const scope = this.db.forTenant(tenantId);
    const record = await scope.form16Record.findFirst({ where: { employeeId, financialYear } });
    if (!record) throw new NotFoundException('Form 16 not found. Generate first.');
    if ((record as any).isLocked) throw new ConflictException('Form 16 is already locked.');

    await scope.form16Record.update({
      where: { id: (record as any).id },
      data: { isLocked: true, lockedAt: new Date(), lockedBy },
    });
    await scope.form16AuditLog.create({
      data: {
        employeeId, financialYear, action: 'LOCKED', performedBy: lockedBy,
        previousChecksumHash: (record as any).checksumHash,
        newChecksumHash:      (record as any).checksumHash,
        reason: 'Final approval lock', createdAt: new Date(),
      },
    });
    this.logger.log(`Form 16 locked: ${employeeId} FY${financialYear} by ${lockedBy}`);
  }

  // ─── Bulk Generation ──────────────────────────────────────────────────────

  async startBulkGeneration(
    tenantId: string, financialYear: string,
    employeeIds: string[] | 'all', startedBy: string,
  ): Promise<string> {
    const scope = this.db.forTenant(tenantId);
    let empIds: string[];
    if (employeeIds === 'all') {
      const emps = await scope.employee.findMany({
        where: { status: 'active', deletedAt: null },
        select: { id: true },
      });
      empIds = (emps as any[]).map(e => e.id);
    } else {
      empIds = employeeIds;
    }

    const job = await scope.form16BulkJob.create({
      data: {
        financialYear, status: 'queued',
        totalEmployees: empIds.length, completedEmployees: 0, failedEmployees: 0,
        employeeIds: empIds, startedBy, createdAt: new Date(),
      },
    });

    this.processBulkJob((job as any).id, tenantId, financialYear, empIds, startedBy).catch(err => {
      this.logger.error(`Bulk job ${(job as any).id} failed: ${err.message}`, err.stack);
    });
    return (job as any).id;
  }

  private async processBulkJob(
    jobId: string, tenantId: string, financialYear: string,
    empIds: string[], startedBy: string,
  ): Promise<void> {
    const scope = this.db.forTenant(tenantId);
    await scope.form16BulkJob.update({
      where: { id: jobId },
      data: { status: 'processing', startedAt: new Date() },
    });

    let completed = 0, failed = 0;
    const errors: Array<{ employeeId: string; error: string }> = [];

    for (let i = 0; i < empIds.length; i += BULK_JOB_BATCH_SIZE) {
      const batch = empIds.slice(i, i + BULK_JOB_BATCH_SIZE);
      await Promise.allSettled(batch.map(async empId => {
        try {
          await this.generateForm16(tenantId, empId, financialYear, startedBy, { force: false });
          completed++;
        } catch (err: any) {
          failed++;
          errors.push({ employeeId: empId, error: err.message });
        }
      }));
      await scope.form16BulkJob.update({
        where: { id: jobId },
        data: { completedEmployees: completed, failedEmployees: failed },
      });
    }

    let zipPath: string | undefined;
    if (completed > 0) zipPath = await this.buildBulkZip(tenantId, financialYear, jobId);

    await scope.form16BulkJob.update({
      where: { id: jobId },
      data: {
        status: failed === empIds.length ? 'failed' : failed > 0 ? 'partial' : 'completed',
        completedAt: new Date(), zipPath: zipPath ?? null, errors: errors as any,
      },
    });
    this.logger.log(`Bulk job ${jobId}: ${completed} done, ${failed} failed`);
  }

  async buildBulkZip(tenantId: string, financialYear: string, jobId: string): Promise<string> {
    const scope = this.db.forTenant(tenantId);
    const records = await scope.form16Record.findMany({
      where: { financialYear },
      include: { employee: { select: { employeeCode: true, firstName: true, lastName: true } } },
    });

    const zipDir = process.env.FORM16_OUTPUT_DIR ?? '/tmp/form16-pdfs';
    const zipPath = path.join(zipDir, `Form16_Bulk_${financialYear.replace('-', '')}_${jobId}.zip`);

    await new Promise<void>((resolve, reject) => {
      const output = createWriteStream(zipPath);
      const archive = archiver('zip', { zlib: { level: 9 } });
      output.on('close', resolve);
      archive.on('error', reject);
      archive.pipe(output);
      for (const record of records as any[]) {
        if (record.pdfPath && existsSync(record.pdfPath)) {
          const emp = record.employee;
          const name = `${emp?.employeeCode ?? 'UNKNOWN'}_${emp?.firstName ?? ''}_${emp?.lastName ?? ''}`;
          archive.file(record.pdfPath, { name: `Form16_${name}.pdf` });
        }
      }
      archive.finalize();
    });
    return zipPath;
  }

  // ─── Queries ──────────────────────────────────────────────────────────────

  async getForm16Record(tenantId: string, employeeId: string, financialYear: string) {
    return this.db.forTenant(tenantId).form16Record.findFirst({ where: { employeeId, financialYear } });
  }

  async getBulkJobStatus(tenantId: string, jobId: string) {
    const job = await this.db.forTenant(tenantId).form16BulkJob.findFirst({ where: { id: jobId } });
    if (!job) throw new NotFoundException('Bulk job not found');
    return job;
  }

  async getAuditLog(tenantId: string, employeeId: string, financialYear: string) {
    return this.db.forTenant(tenantId).form16AuditLog.findMany({
      where: { employeeId, financialYear },
      orderBy: { createdAt: 'desc' },
    });
  }

  // ─── Dashboard ────────────────────────────────────────────────────────────

  async getDashboard(tenantId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);
    const fyStartYear = parseInt(financialYear.split('-')[0]!, 10);

    const [employees, records, projections, payslipAgg] = await Promise.all([
      scope.employee.findMany({
        where: { status: 'active', deletedAt: null },
        select: { id: true, firstName: true, lastName: true, employeeCode: true },
      }),
      scope.form16Record.findMany({ where: { financialYear } }),
      scope.tDSProjection.findMany({ where: { financialYear } }),
      scope.payslip.groupBy({
        by: ['employeeId'],
        where: {
          status: { not: 'cancelled' },
          OR: [
            { year: fyStartYear, month: { gte: 4 } },
            { year: fyStartYear + 1, month: { lte: 3 } },
          ],
        },
        _sum: { grossPay: true, tdsDeducted: true },
      }),
    ]);

    const recordMap = new Map((records as any[]).map(r => [r.employeeId, r]));
    const projMap   = new Map((projections as any[]).map(p => [p.employeeId, p]));
    const payMap    = new Map((payslipAgg as any[]).map(p => [
      p.employeeId,
      { grossPay: Number(p._sum.grossPay ?? 0), tdsDeducted: Number(p._sum.tdsDeducted ?? 0) },
    ]));

    const entries: Form16DashboardEntry[] = (employees as any[]).map(emp => {
      const record = recordMap.get(emp.id);
      const proj   = projMap.get(emp.id);
      const ps     = payMap.get(emp.id) ?? { grossPay: 0, tdsDeducted: 0 };
      const payslips = [{ period: '', month: 0, year: 0, grossPay: ps.grossPay, tdsDeducted: ps.tdsDeducted, pfEmployee: 0, professionalTax: 0 }];
      return buildDashboardEntry(
        emp.id, `${emp.firstName} ${emp.lastName}`, emp.employeeCode,
        emp.pan ?? 'NOT PROVIDED', payslips,
        proj ? { totalTaxLiability: Number(proj.totalTaxLiability), regimeType: proj.regimeType } : null,
        record ? { generatedAt: record.generatedAt, isLocked: record.isLocked } : null,
      );
    });

    const summary = {
      total:     entries.length,
      generated: entries.filter(e => e.status === 'generated').length,
      locked:    entries.filter(e => e.status === 'locked').length,
      pending:   entries.filter(e => e.status === 'pending').length,
      mismatch:  entries.filter(e => e.status === 'mismatch').length,
    };
    return { summary, employees: entries };
  }
}
