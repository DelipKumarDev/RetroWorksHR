/**
 * Form 16 Controller — REST API
 * ══════════════════════════════
 * POST /form16/generate/:employeeId          — Generate Form 16 for one employee
 * GET  /form16/:employeeId                   — Get Form 16 record + PDF URL
 * GET  /form16/:employeeId/download          — Download PDF (employee self-service)
 * POST /form16/:employeeId/lock              — Lock Form 16 (payroll admin)
 * GET  /form16/:employeeId/preview           — Preview assembled data (no PDF)
 * GET  /form16/:employeeId/validate          — Validate without generating
 * GET  /form16/:employeeId/audit             — Audit log
 * POST /form16/bulk/generate                 — Start bulk generation job
 * GET  /form16/bulk/jobs/:jobId              — Poll bulk job status
 * GET  /form16/bulk/jobs/:jobId/download     — Download bulk ZIP
 * GET  /form16/dashboard                     — Summary dashboard
 */

import {
  Controller, Get, Post, Param, Query, Body,
  UseGuards, HttpCode, HttpStatus, Res, Logger,
  StreamableFile,
} from '@nestjs/common';
import {
  ApiTags, ApiOperation, ApiBearerAuth, ApiQuery, ApiParam,
} from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { IsString, IsArray, IsOptional, IsBoolean, IsIn } from 'class-validator';
import type { Response } from 'express';
import * as fs from 'fs';
import { Form16Service } from './form16.service';
import { TenantGuard } from '../../../common/guards/tenant.guard';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { Roles } from '../../../common/decorators/permissions.decorator';
import { getCurrentFy } from '../tds/tds.engine';
import type { JwtPayload } from '@retroworks/types';

// ─────────────────────────────────────────────────────────────────────────────
// DTOs
// ─────────────────────────────────────────────────────────────────────────────

export class BulkGenerateDto {
  @IsIn(['all']) @IsString()
  employees!: 'all' | string[];

  @IsOptional() @IsString()
  financialYear?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTROLLER
// ─────────────────────────────────────────────────────────────────────────────

@ApiTags('Form 16')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('form16')
export class Form16Controller {
  private readonly logger = new Logger(Form16Controller.name);

  constructor(private readonly form16Service: Form16Service) {}

  // ─── Individual generation ─────────────────────────────────────────────

  @Post('generate/:employeeId')
  @Roles('payroll-admin', 'hr-admin', 'super-admin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Generate Form 16 for one employee',
    description: 'Assembles Form 16 from payroll ledger + TDS engine + declarations and generates PDF. Blocked if TDS mismatch > ₹1.',
  })
  @ApiQuery({ name: 'financialYear', required: false, example: '2024-25' })
  @ApiQuery({ name: 'force', required: false, type: Boolean })
  async generateForm16(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @Query('force') force: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const result = await this.form16Service.generateForm16(
      user.tid, employeeId, fy, user.sub,
      { force: force === 'true' },
    );
    return {
      success: true,
      certificateNumber: result.record.certificateNumber,
      financialYear: fy,
      warnings: result.warnings,
      record: {
        id: result.record.id,
        pdfPath: result.record.pdfPath,
        generatedAt: result.record.generatedAt,
        isLocked: result.record.isLocked,
        checksumHash: result.record.checksumHash,
        totalTaxLiability: result.record.totalTaxLiability,
        totalTdsDeducted: result.record.totalTdsDeducted,
        taxPayableOrRefund: result.record.taxPayableOrRefund,
      },
      disclaimer: '⚠️ Form 16 must be verified against TRACES before issuance to employees.',
    };
  }

  @Get(':employeeId')
  @ApiOperation({ summary: 'Get Form 16 record for an employee' })
  @ApiQuery({ name: 'financialYear', required: false })
  async getRecord(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const record = await this.form16Service.getForm16Record(user.tid, employeeId, fy);
    return {
      financialYear: fy,
      employeeId,
      found: !!record,
      record: record ? {
        id: record.id,
        certificateNumber: record.certificateNumber,
        assessmentYear: record.assessmentYear,
        regimeType: record.regimeType,
        isLocked: record.isLocked,
        generatedAt: record.generatedAt,
        totalGrossSalary: Number(record.totalGrossSalary),
        totalTaxLiability: Number(record.totalTaxLiability),
        totalTdsDeducted: Number(record.totalTdsDeducted),
        taxPayableOrRefund: Number(record.taxPayableOrRefund),
        templateVersion: record.templateVersion,
      } : null,
    };
  }

  @Get(':employeeId/download')
  @ApiOperation({
    summary: 'Download Form 16 PDF',
    description: 'Employees can download only their own Form 16. Payroll admins can download any.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async downloadPdf(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
    @Res({ passthrough: true }) res: Response,
  ) {
    // Employees can only download their own
    if (user.role === 'employee' && user.employeeId !== employeeId) {
      throw new Error('Forbidden: You can only download your own Form 16.');
    }

    const fy = financialYear ?? getCurrentFy();
    const record = await this.form16Service.getForm16Record(user.tid, employeeId, fy);
    if (!record?.pdfPath) {
      return { error: 'Form 16 not yet generated for this employee and financial year.' };
    }
    if (!record.isLocked) {
      return {
        warning: 'Form 16 has not been locked/finalized yet. Download anyway at your own discretion.',
        pdfPath: record.pdfPath,
      };
    }

    const fileStream = fs.createReadStream(record.pdfPath);
    const fileName = `Form16_${record.certificateNumber}.pdf`;
    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename="${fileName}"`,
      'X-Form16-Certificate': record.certificateNumber,
      'X-Form16-Checksum': record.checksumHash,
    });
    return new StreamableFile(fileStream);
  }

  @Post(':employeeId/lock')
  @Roles('payroll-admin', 'hr-admin', 'super-admin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Lock Form 16 (final approval)',
    description: 'Locks Form 16 — prevents regeneration without explicit force + audit. Employees can download after locking.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async lockForm16(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    await this.form16Service.lockForm16(user.tid, employeeId, fy, user.sub);
    return {
      success: true,
      message: `Form 16 for FY ${fy} has been locked. Employee can now download.`,
      lockedBy: user.sub,
      lockedAt: new Date(),
    };
  }

  @Get(':employeeId/preview')
  @Roles('payroll-admin', 'hr-admin', 'super-admin')
  @ApiOperation({
    summary: 'Preview assembled Form 16 data (JSON, no PDF)',
    description: 'Returns the full structured Form 16 data object for CA review before PDF generation.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async previewForm16(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const count = await this.form16Service['prisma'].form16Record.count({
      where: { tenantId: user.tid, financialYear: fy },
    });
    const { document, validationResult } = await this.form16Service.assembleForm16Data(
      user.tid, employeeId, fy, count + 1,
    );
    return {
      financialYear: fy,
      validationResult,
      canGenerate: validationResult.isValid,
      document: {
        ...document,
        disclaimer: document.disclaimer,
      },
    };
  }

  @Get(':employeeId/validate')
  @Roles('payroll-admin', 'hr-admin', 'super-admin')
  @ApiOperation({
    summary: 'Validate Form 16 data without generating',
    description: 'Checks TDS consistency, PAN validity, missing fields. Returns blocking errors and warnings.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async validateForm16(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const { validationResult } = await this.form16Service.assembleForm16Data(
      user.tid, employeeId, fy, 0,
    );
    return {
      financialYear: fy,
      isValid: validationResult.isValid,
      canGenerate: validationResult.isValid,
      blockingErrors: validationResult.blockingErrors,
      warnings: validationResult.warnings,
      message: validationResult.isValid
        ? '✅ All validations passed. Form 16 is ready to generate.'
        : `❌ ${validationResult.blockingErrors.length} blocking error(s) must be resolved first.`,
    };
  }

  @Get(':employeeId/audit')
  @Roles('payroll-admin', 'hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Form 16 audit trail for an employee' })
  @ApiQuery({ name: 'financialYear', required: false })
  async getAuditLog(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const logs = await this.form16Service.getAuditLog(user.tid, employeeId, fy);
    return { employeeId, financialYear: fy, totalEntries: logs.length, log: logs };
  }

  // ─── Bulk operations ───────────────────────────────────────────────────

  @Post('bulk/generate')
  @Roles('payroll-admin', 'super-admin')
  @HttpCode(HttpStatus.ACCEPTED)
  @ApiOperation({
    summary: 'Start bulk Form 16 generation',
    description: 'Queues a background job. Poll /bulk/jobs/:jobId for progress. Returns job ID immediately.',
  })
  async bulkGenerate(
    @Body() dto: BulkGenerateDto,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = dto.financialYear ?? getCurrentFy();
    const jobId = await this.form16Service.startBulkGeneration(
      user.tid, fy,
      dto.employees as 'all' | string[],
      user.sub,
    );
    return {
      success: true,
      jobId,
      financialYear: fy,
      message: 'Bulk Form 16 generation queued. Poll /form16/bulk/jobs/:jobId for status.',
      pollUrl: `/api/v1/form16/bulk/jobs/${jobId}`,
    };
  }

  @Get('bulk/jobs/:jobId')
  @Roles('payroll-admin', 'super-admin')
  @ApiOperation({ summary: 'Poll bulk generation job status' })
  async getBulkJobStatus(
    @Param('jobId') jobId: string,
    @CurrentUser() user: JwtPayload,
  ) {
    const job = await this.form16Service.getBulkJobStatus(user.tid, jobId);
    return {
      jobId,
      status: job.status,
      totalEmployees: job.totalEmployees,
      completedEmployees: job.completedEmployees,
      failedEmployees: job.failedEmployees,
      progressPercent: Math.round((Number(job.completedEmployees) / Math.max(1, Number(job.totalEmployees))) * 100),
      startedAt: job.startedAt,
      completedAt: job.completedAt,
      zipAvailable: !!job.zipPath,
      downloadUrl: job.zipPath ? `/api/v1/form16/bulk/jobs/${jobId}/download` : null,
      errors: job.errors,
    };
  }

  @Get('bulk/jobs/:jobId/download')
  @Roles('payroll-admin', 'super-admin')
  @ApiOperation({ summary: 'Download bulk Form 16 ZIP archive' })
  async downloadBulkZip(
    @Param('jobId') jobId: string,
    @CurrentUser() user: JwtPayload,
    @Res({ passthrough: true }) res: Response,
  ) {
    const job = await this.form16Service.getBulkJobStatus(user.tid, jobId);
    if (!job.zipPath) {
      return { error: 'ZIP not yet available. Wait for job completion.' };
    }
    const fileStream = fs.createReadStream(job.zipPath);
    res.set({
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="Form16_Bulk_${job.financialYear}_${jobId}.zip"`,
    });
    return new StreamableFile(fileStream);
  }

  // ─── Dashboard ─────────────────────────────────────────────────────────

  @Get('dashboard')
  @Roles('payroll-admin', 'hr-admin', 'super-admin')
  @ApiOperation({
    summary: 'Form 16 generation dashboard',
    description: 'Summary of generated vs pending employees, mismatch warnings, for all active employees.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async getDashboard(
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const { summary, employees } = await this.form16Service.getDashboard(user.tid, fy);
    return {
      financialYear: fy,
      summary,
      employees,
      generatedAt: new Date(),
      disclaimer: '⚠️ All Form 16 documents must be verified against TRACES before issuance.',
    };
  }
}
