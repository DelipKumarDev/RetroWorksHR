/**
 * RetroWorks HR — Form 16 Engine Test Suite
 * ══════════════════════════════════════════════
 * 25 unit tests covering:
 *   ▸ Validation: missing PAN, TAN, mismatch, zero TDS
 *   ▸ Assembly: Part A quarterly aggregation, Part B tax computation
 *   ▸ Edge cases: APPLIED PAN, surcharge, rebate 87A, mid-year joiner
 *   ▸ Old vs new regime rendering
 *   ▸ Lock / audit logic
 *   ▸ Certificate number generation
 *   ▸ Checksum determinism
 *
 * Run: npx jest form16.engine.spec --verbose
 */

import {
  validateForm16Input,
  assembleForm16,
  generateCertificateNumber,
  computeChecksum,
  getAssessmentYear,
  getQuarterForMonth,
  aggregateQuarterlyTds,
  buildDashboardEntry,
  type Form16AssemblyInput,
  type EmployerInfo,
  type EmployeeInfo,
  type MonthlyPayslipSummary,
} from '../form16.engine';

// ─────────────────────────────────────────────────────────────────────────────
// TEST FIXTURES
// ─────────────────────────────────────────────────────────────────────────────

const EMPLOYER: EmployerInfo = {
  name: 'RetroWorks Technologies Pvt Ltd',
  tan: 'BLRR01234A',
  pan: 'AABCR1234D',
  address: '100 MG Road',
  city: 'Bengaluru',
  pincode: '560001',
  state: 'Karnataka',
  designation: 'Director — Finance',
  signatoryName: 'Priya Sharma',
};

const EMPLOYEE: EmployeeInfo = {
  id: 'emp-001',
  name: 'Ramesh Kumar',
  pan: 'ABCPK1234F',
  address: '12 Brigade Road',
  city: 'Bengaluru',
  pincode: '560025',
  state: 'Karnataka',
  employeeCode: 'RW0042',
  designation: 'Senior Engineer',
  department: 'Engineering',
};

// 12 months of payslips (Apr 2024 – Mar 2025)
const PAYSLIPS_12M: MonthlyPayslipSummary[] = Array.from({ length: 12 }, (_, i) => {
  const month = i < 9 ? i + 4 : i - 8;   // Apr=4 ... Mar=3
  const year  = month >= 4 ? 2024 : 2025;
  return {
    period: `${year}-${String(month).padStart(2, '0')}`,
    month,
    year,
    grossPay: 91_250,     // ₹91,250 × 12 = ₹10,95,000
    tdsDeducted: 7_500,   // ₹7,500 × 12 = ₹90,000
    pfEmployee: 1_800,
    professionalTax: 200,
  };
});

const TDS_PROJECTION = {
  regimeType: 'new' as const,
  projectedAnnualIncome: 10_95_000,
  totalTaxLiability: 90_000,
  totalCess: 3_000,
  taxableIncome: 10_20_000,
  taxBeforeRebate: 86_538,
  rebate87A: 0,
  taxAfterRebate: 86_538,
  surcharge: 0,
  cess: 3_462,
  effectiveTaxRate: 8.82,
  slabWiseBreakdown: [
    { slabFrom: 0,      slabTo: 300000,  rate: 0,    incomeInSlab: 300000, taxInSlab: 0 },
    { slabFrom: 300001, slabTo: 600000,  rate: 0.05, incomeInSlab: 300000, taxInSlab: 15000 },
    { slabFrom: 600001, slabTo: 900000,  rate: 0.10, incomeInSlab: 300000, taxInSlab: 30000 },
    { slabFrom: 900001, slabTo: 1200000, rate: 0.15, incomeInSlab: 120000, taxInSlab: 18000 },
  ],
};

function makeInput(overrides: Partial<Form16AssemblyInput> = {}): Form16AssemblyInput {
  return {
    financialYear: '2024-25',
    employer: EMPLOYER,
    employee: EMPLOYEE,
    monthlyPayslips: PAYSLIPS_12M,
    tdsProjection: TDS_PROJECTION,
    declaration: {
      regimeType: 'new',
      section80C: 0, section80D_self: 0, section80D_parents: 0,
      section80D_parentsIsSenior: false, section80CCD1B: 0,
      hraRentPaid: 0, hraCityType: 'non-metro',
      ltaAmountClaimed: 0, homeLoanInterest: 0, otherDeductions: 0,
      prevEmployerIncome: 0, prevEmployerTds: 0,
    },
    professionalTaxPaid: 2_400,
    ...overrides,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

describe('Utility Functions', () => {

  test('U01 — getAssessmentYear: 2024-25 → 2025-26', () => {
    expect(getAssessmentYear('2024-25')).toBe('2025-26');
  });

  test('U02 — getAssessmentYear: 2023-24 → 2024-25', () => {
    expect(getAssessmentYear('2023-24')).toBe('2024-25');
  });

  test('U03 — getQuarterForMonth: Apr=Q1, Jul=Q2, Oct=Q3, Jan=Q4', () => {
    expect(getQuarterForMonth(4)).toBe(1);
    expect(getQuarterForMonth(7)).toBe(2);
    expect(getQuarterForMonth(10)).toBe(3);
    expect(getQuarterForMonth(1)).toBe(4);
  });

  test('U04 — getQuarterForMonth: boundary months Jun=Q1, Sep=Q2, Dec=Q3, Mar=Q4', () => {
    expect(getQuarterForMonth(6)).toBe(1);
    expect(getQuarterForMonth(9)).toBe(2);
    expect(getQuarterForMonth(12)).toBe(3);
    expect(getQuarterForMonth(3)).toBe(4);
  });

  test('U05 — aggregateQuarterlyTds: 12 months → 4 quarters', () => {
    const quarters = aggregateQuarterlyTds(PAYSLIPS_12M);
    expect(quarters.length).toBe(4);
    const totalTds = quarters.reduce((s, q) => s + q.tdsDeducted, 0);
    expect(Math.round(totalTds)).toBe(90_000);
  });

  test('U06 — aggregateQuarterlyTds: Q1 = Apr+May+Jun', () => {
    const quarters = aggregateQuarterlyTds(PAYSLIPS_12M);
    const q1 = quarters.find(q => q.quarter === 'Q1');
    expect(q1).toBeDefined();
    expect(q1!.tdsDeducted).toBe(7_500 * 3); // 3 months in Q1
  });

  test('U07 — generateCertificateNumber format', () => {
    const cert = generateCertificateNumber('tenant1', 'RW0042', '2024-25', 1);
    expect(cert).toBe('F16-202425-RW0042-0001');
  });

  test('U08 — computeChecksum is deterministic', () => {
    const data = JSON.stringify({ test: 'hello', value: 42 });
    expect(computeChecksum(data)).toBe(computeChecksum(data));
  });

  test('U09 — computeChecksum differs for different data', () => {
    expect(computeChecksum('data1')).not.toBe(computeChecksum('data2'));
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 2. VALIDATION — BLOCKING ERRORS
// ─────────────────────────────────────────────────────────────────────────────

describe('Form 16 Validation — Blocking Errors', () => {

  test('V01 — Missing employee PAN blocks generation', () => {
    const input = makeInput({
      employee: { ...EMPLOYEE, pan: '' },
    });
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'MISSING_EMPLOYEE_PAN')).toBe(true);
  });

  test('V02 — Invalid employee PAN format blocks generation', () => {
    const input = makeInput({
      employee: { ...EMPLOYEE, pan: 'INVALID123' },
    });
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'INVALID_EMPLOYEE_PAN')).toBe(true);
  });

  test('V03 — Missing employer TAN blocks generation', () => {
    const input = makeInput({
      employer: { ...EMPLOYER, tan: '' },
    });
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'INVALID_TAN')).toBe(true);
  });

  test('V04 — Invalid TAN format blocks generation', () => {
    const input = makeInput({
      employer: { ...EMPLOYER, tan: 'BADTAN123' },
    });
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'INVALID_TAN')).toBe(true);
  });

  test('V05 — Invalid employer PAN format blocks generation', () => {
    const input = makeInput({
      employer: { ...EMPLOYER, pan: 'BADPAN' },
    });
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'INVALID_EMPLOYER_PAN')).toBe(true);
  });

  test('V06 — No payslips blocks generation', () => {
    const input = makeInput({ monthlyPayslips: [] });
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'NO_PAYSLIPS')).toBe(true);
  });

  test('V07 — TDS mismatch > ₹1 blocks generation', () => {
    // Payslips show ₹90,000 TDS but projection says ₹1,00,000
    const input = makeInput({
      tdsProjection: { ...TDS_PROJECTION, totalTaxLiability: 1_00_000 },
    });
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'TDS_MISMATCH')).toBe(true);
  });

  test('V08 — Invalid financial year format blocks generation', () => {
    const input = makeInput({ financialYear: '2024' }); // wrong format
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'INVALID_FY')).toBe(true);
  });

  test('V09 — Missing employer name blocks generation', () => {
    const input = makeInput({
      employer: { ...EMPLOYER, name: '' },
    });
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'MISSING_EMPLOYER_NAME')).toBe(true);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 3. VALIDATION — WARNINGS (non-blocking)
// ─────────────────────────────────────────────────────────────────────────────

describe('Form 16 Validation — Warnings', () => {

  test('V10 — PAN = "APPLIED" produces warning, not blocking error', () => {
    const input = makeInput({
      employee: { ...EMPLOYEE, pan: 'APPLIED' },
    });
    const result = validateForm16Input(input);
    // Should NOT be a blocking error
    expect(result.blockingErrors.some(e => e.code === 'INVALID_EMPLOYEE_PAN')).toBe(false);
    // Should produce a warning
    expect(result.warnings.some(w => w.code === 'EMPLOYEE_PAN_NOT_RECEIVED')).toBe(true);
  });

  test('V11 — No tax declaration produces warning (assumes new regime)', () => {
    const input = makeInput({ declaration: null });
    const result = validateForm16Input(input);
    expect(result.warnings.some(w => w.code === 'NO_DECLARATION')).toBe(true);
  });

  test('V12 — Zero TDS deducted produces warning (not blocking)', () => {
    const input = makeInput({
      monthlyPayslips: PAYSLIPS_12M.map(p => ({ ...p, tdsDeducted: 0 })),
      tdsProjection: { ...TDS_PROJECTION, totalTaxLiability: 0 },
    });
    const result = validateForm16Input(input);
    expect(result.isValid).toBe(true); // Not blocked
    expect(result.warnings.some(w => w.code === 'ZERO_TDS')).toBe(true);
  });

  test('V13 — Valid input with all fields → no blocking errors', () => {
    const result = validateForm16Input(makeInput());
    expect(result.isValid).toBe(true);
    expect(result.blockingErrors).toHaveLength(0);
  });

  test('V14 — TDS mismatch ≤ ₹1 is a warning, not blocking', () => {
    // ₹90,000 in payslips vs ₹90,000.50 in projection → diff of ₹0.50
    const input = makeInput({
      tdsProjection: { ...TDS_PROJECTION, totalTaxLiability: 90_000.50 },
    });
    const result = validateForm16Input(input);
    // Should NOT block (diff ≤ ₹1)
    expect(result.blockingErrors.some(e => e.code === 'TDS_MISMATCH')).toBe(false);
    expect(result.warnings.some(w => w.code === 'TDS_ROUNDING_DIFF')).toBe(true);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 4. FORM 16 ASSEMBLY
// ─────────────────────────────────────────────────────────────────────────────

describe('Form 16 Assembly', () => {

  test('A01 — assembleForm16 produces correct financial year and AY', () => {
    const doc = assembleForm16(makeInput(), 'F16-202425-RW0042-0001', '2024-25-v1');
    expect(doc.financialYear).toBe('2024-25');
    expect(doc.assessmentYear).toBe('2025-26');
  });

  test('A02 — Part A contains correct quarterly TDS breakdown', () => {
    const doc = assembleForm16(makeInput(), 'F16-202425-RW0042-0001');
    expect(doc.partA.quarterlyTds.length).toBe(4);
    const totalQ = doc.partA.quarterlyTds.reduce((s, q) => s + q.tdsDeducted, 0);
    expect(Math.round(totalQ)).toBe(90_000);
  });

  test('A03 — Part A employer TAN and PAN are correct', () => {
    const doc = assembleForm16(makeInput(), 'cert-001');
    expect(doc.partA.employer.tan).toBe('BLRR01234A');
    expect(doc.partA.employer.pan).toBe('AABCR1234D');
  });

  test('A04 — Part A employee PAN is present', () => {
    const doc = assembleForm16(makeInput(), 'cert-001');
    expect(doc.partA.employee.pan).toBe('ABCPK1234F');
  });

  test('A05 — Part B total gross salary matches payslip sum', () => {
    const doc = assembleForm16(makeInput(), 'cert-001');
    const expectedGross = 91_250 * 12;
    expect(doc.partB.taxComputation.grossSalary).toBe(expectedGross);
  });

  test('A06 — Part B tax liability matches projection', () => {
    const doc = assembleForm16(makeInput(), 'cert-001');
    expect(doc.partB.taxComputation.totalTaxLiability).toBe(90_000);
  });

  test('A07 — Part B TDS deducted matches payslip sum', () => {
    const doc = assembleForm16(makeInput(), 'cert-001');
    expect(doc.partB.taxComputation.totalTdsDeducted).toBe(90_000);
  });

  test('A08 — Part B tax payable/refund = liability - TDS deducted', () => {
    const doc = assembleForm16(makeInput(), 'cert-001');
    const expected = doc.partB.taxComputation.totalTaxLiability - doc.partB.taxComputation.totalTdsDeducted;
    expect(doc.partB.taxComputation.taxPayableOrRefund).toBe(expected);
  });

  test('A09 — Checksum is non-empty and deterministic', () => {
    const doc1 = assembleForm16(makeInput(), 'cert-001');
    const doc2 = assembleForm16(makeInput(), 'cert-001');
    expect(doc1.checksumHash).toBeTruthy();
    expect(doc1.checksumHash).toBe(doc2.checksumHash);
  });

  test('A10 — Different employee produces different checksum', () => {
    const doc1 = assembleForm16(makeInput(), 'cert-001');
    const doc2 = assembleForm16(
      makeInput({ employee: { ...EMPLOYEE, pan: 'XYZAB1234C', name: 'Other Employee' } }),
      'cert-001',
    );
    expect(doc1.checksumHash).not.toBe(doc2.checksumHash);
  });

  test('A11 — Disclaimer is present', () => {
    const doc = assembleForm16(makeInput(), 'cert-001');
    expect(doc.disclaimer).toContain('TRACES');
    expect(doc.disclaimer).toContain('CA');
  });

  test('A12 — Part B monthly ledger has 12 entries', () => {
    const doc = assembleForm16(makeInput(), 'cert-001');
    expect(doc.partB.monthlyLedger.length).toBe(12);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 5. EDGE CASES
// ─────────────────────────────────────────────────────────────────────────────

describe('Edge Cases', () => {

  test('E01 — High income with surcharge: surcharge is reflected in Part B', () => {
    const highIncomeProjection = {
      ...TDS_PROJECTION,
      totalTaxLiability: 15_00_000,
      totalTaxableIncome: 60_00_000,
      surcharge: 1_50_000,   // 10% surcharge on 60L income
      taxableIncome: 60_00_000,
      taxBeforeRebate: 14_00_000,
    };
    const doc = assembleForm16(
      makeInput({ tdsProjection: highIncomeProjection }),
      'cert-high',
    );
    expect(doc.partB.taxComputation.surcharge).toBe(1_50_000);
  });

  test('E02 — Rebate 87A: reflected when taxable income ≤ ₹7L', () => {
    const lowIncomeProjection = {
      ...TDS_PROJECTION,
      totalTaxLiability: 0,
      taxableIncome: 6_50_000,
      taxBeforeRebate: 17_500,
      rebate87A: 17_500,   // Full rebate
      taxAfterRebate: 0,
      cess: 0,
    };
    const doc = assembleForm16(
      makeInput({ tdsProjection: lowIncomeProjection }),
      'cert-rebate',
    );
    expect(doc.partB.taxComputation.rebate87A).toBe(17_500);
    expect(doc.partB.taxComputation.totalTaxLiability).toBe(0);
  });

  test('E03 — Negative tax payable (refund scenario)', () => {
    // Employee paid more TDS than liability
    const overpaidPayslips = PAYSLIPS_12M.map(p => ({ ...p, tdsDeducted: 10_000 }));
    const overpaidProjection = {
      ...TDS_PROJECTION,
      totalTaxLiability: 90_000,
    };
    // 10K × 12 = 1,20,000 TDS paid vs 90,000 liability → refund of 30,000
    const input = makeInput({
      monthlyPayslips: overpaidPayslips,
      tdsProjection: { ...overpaidProjection, totalTaxLiability: 90_000 },
    });
    const doc = assembleForm16(input, 'cert-refund');
    expect(doc.partB.taxComputation.taxPayableOrRefund).toBeLessThan(0);
    expect(doc.partB.taxComputation.taxPayableOrRefund).toBe(-30_000);
  });

  test('E04 — Mid-year joiner: previous employer income in Part B', () => {
    const doc = assembleForm16(
      makeInput({
        declaration: {
          regimeType: 'old',
          section80C: 0, section80D_self: 0, section80D_parents: 0,
          section80D_parentsIsSenior: false, section80CCD1B: 0,
          hraRentPaid: 0, hraCityType: 'non-metro',
          ltaAmountClaimed: 0, homeLoanInterest: 0, otherDeductions: 0,
          prevEmployerIncome: 3_60_000,
          prevEmployerTds: 18_000,
        },
      }),
      'cert-midyear',
    );
    expect(doc.partB.taxComputation.otherIncome).toBe(3_60_000);
  });

  test('E05 — Old regime: standard deduction is ₹50,000', () => {
    const doc = assembleForm16(
      makeInput({
        declaration: {
          regimeType: 'old',
          section80C: 1_50_000, section80D_self: 25_000, section80D_parents: 0,
          section80D_parentsIsSenior: false, section80CCD1B: 0,
          hraRentPaid: 0, hraCityType: 'non-metro',
          ltaAmountClaimed: 0, homeLoanInterest: 0, otherDeductions: 0,
          prevEmployerIncome: 0, prevEmployerTds: 0,
        },
        deductionsBreakdown: {
          standardDeduction: 50_000,
          section80C_allowed: 1_50_000,
          section80D_allowed: 25_000,
          section80CCD1B: 0,
          hraExemption: 0,
          ltaExemption: 0,
          homeLoanInterest: 0,
          otherDeductions: 0,
          totalDeductions: 2_25_000,
        },
      }),
      'cert-old',
    );
    expect(doc.partB.taxComputation.standardDeduction).toBe(50_000);
    expect(doc.partB.regimeType).toBe('old');
  });

  test('E06 — New regime: standard deduction is ₹75,000', () => {
    const doc = assembleForm16(makeInput(), 'cert-new');
    expect(doc.partB.taxComputation.standardDeduction).toBe(75_000);
    expect(doc.partB.regimeType).toBe('new');
  });

  test('E07 — HRA exemption is included in Part B when declared', () => {
    const doc = assembleForm16(
      makeInput({
        hraBreakdown: {
          exemptionAnnual: 1_20_000,
          rentPaidAnnual: 2_40_000,
          basicAnnual: 6_00_000,
          annualHraReceived: 2_40_000,
          limit1_actualHra: 2_40_000,
          limit2_rentMinusBasic10: 1_80_000,
          limit3_percentOfBasic: 2_40_000,
        },
      }),
      'cert-hra',
    );
    expect(doc.partB.hraExemption).not.toBeNull();
    expect(doc.partB.hraExemption!.exemptionClaimed).toBe(1_20_000);
    expect(doc.partB.taxComputation.hraExemption).toBe(1_20_000);
  });

  test('E08 — Zero TDS case: Form 16 still assembles successfully', () => {
    const zeroTdsPayslips = PAYSLIPS_12M.map(p => ({ ...p, tdsDeducted: 0 }));
    const doc = assembleForm16(
      makeInput({
        monthlyPayslips: zeroTdsPayslips,
        tdsProjection: { ...TDS_PROJECTION, totalTaxLiability: 0 },
      }),
      'cert-zero',
    );
    expect(doc.partB.taxComputation.totalTdsDeducted).toBe(0);
    expect(doc.partB.taxComputation.totalTaxLiability).toBe(0);
    expect(doc.partB.taxComputation.taxPayableOrRefund).toBe(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 6. DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────

describe('Dashboard Entry Builder', () => {

  test('D01 — Status is "pending" when no Form 16 generated', () => {
    const entry = buildDashboardEntry('emp1', 'Raj Kumar', 'RW001', 'ABCPQ1234R',
      PAYSLIPS_12M, { totalTaxLiability: 90_000, regimeType: 'new' }, null);
    expect(entry.status).toBe('pending');
  });

  test('D02 — Status is "generated" when Form 16 exists but not locked', () => {
    const entry = buildDashboardEntry('emp1', 'Raj Kumar', 'RW001', 'ABCPQ1234R',
      PAYSLIPS_12M, { totalTaxLiability: 90_000, regimeType: 'new' },
      { generatedAt: new Date(), isLocked: false });
    expect(entry.status).toBe('generated');
  });

  test('D03 — Status is "locked" when Form 16 is finalized', () => {
    const entry = buildDashboardEntry('emp1', 'Raj Kumar', 'RW001', 'ABCPQ1234R',
      PAYSLIPS_12M, { totalTaxLiability: 90_000, regimeType: 'new' },
      { generatedAt: new Date(), isLocked: true });
    expect(entry.status).toBe('locked');
  });

  test('D04 — Status is "mismatch" when TDS > ₹1 difference', () => {
    // Payslips: 90K TDS, projection: 95K liability → mismatch of 5K
    const entry = buildDashboardEntry('emp1', 'Raj Kumar', 'RW001', 'ABCPQ1234R',
      PAYSLIPS_12M, { totalTaxLiability: 95_000, regimeType: 'new' }, null);
    expect(entry.status).toBe('mismatch');
    expect(entry.mismatchAmount).toBe(5_000);
  });

  test('D05 — Missing PAN shown as "NOT PROVIDED"', () => {
    const entry = buildDashboardEntry('emp1', 'Raj Kumar', 'RW001', '',
      PAYSLIPS_12M, null, null);
    expect(entry.pan).toBe('NOT PROVIDED');
  });
});
