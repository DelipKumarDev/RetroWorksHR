/**
 * TDS Returns Controller — 24Q REST API
 * ═══════════════════════════════════════════════════════════════════════════
 * POST /tds-returns/generate/:quarter             — Generate 24Q return
 * GET  /tds-returns/:quarter                      — Get return + validation status
 * POST /tds-returns/:quarter/validate             — Validate without filing
 * POST /tds-returns/:quarter/mark-filed           — Mark as filed (immutable after)
 * GET  /tds-returns/:quarter/export-fvu           — Download FVU TXT export
 * GET  /tds-returns/:quarter/audit                — Audit trail
 * POST /tds-returns/challans                      — Add challan manually
 * GET  /tds-returns/challans                      — List all challans
 * DELETE /tds-returns/challans/:id               — Delete unlinked challan
 * POST /tds-returns/challans/import-csv           — Bulk import from CSV
 * POST /tds-returns/traces/import/:quarter        — Upload TRACES Part A CSV
 * GET  /tds-returns/traces/logs                   — TRACES import history
 * POST /tds-returns/traces/populate-form16        — Push challan data → Form 16 Part A
 * GET  /tds-returns/dashboard                     — All quarters status
 */

import {
  Controller, Get, Post, Delete, Param, Query, Body,
  UseGuards, HttpCode, HttpStatus, Res, Logger,
  UploadedFile, UseInterceptors,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery, ApiConsumes } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import type { Response } from 'express';

import { TdsReturnService } from './tds-returns.service';
import { ChallanService, CreateChallanDto } from './challan.service';
import { TracesService } from './traces.service';
import { TenantGuard } from '../../../common/guards/tenant.guard';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { Roles } from '../../../common/decorators/permissions.decorator';
import { getCurrentFy } from '../tds/tds.engine';
import type { Quarter } from './return.engine';
import type { JwtPayload } from '@retroworks/types';

// ─────────────────────────────────────────────────────────────────────────────
// CONTROLLER
// ─────────────────────────────────────────────────────────────────────────────

@ApiTags('24Q TDS Returns')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('payroll-admin', 'super-admin')
@Controller('tds-returns')
export class TdsReturnsController {
  private readonly logger = new Logger(TdsReturnsController.name);

  constructor(
    private readonly returnService: TdsReturnService,
    private readonly challanService: ChallanService,
    private readonly tracesService: TracesService,
  ) {}

  // ─── Dashboard (first — before :quarter catches it) ───────────────────────

  @Get('dashboard')
  @ApiOperation({
    summary: 'All-quarters 24Q dashboard',
    description: 'Shows Q1–Q4 status: deducted, deposited, filed, TRACES reconciled, Form 16 ready indicator.',
  })
  @ApiQuery({ name: 'financialYear', required: false, example: '2024-25' })
  async getDashboard(
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    return this.returnService.getDashboard(user.tid, fy);
  }

  // ─── 24Q Return Management ────────────────────────────────────────────────

  @Post('generate/:quarter')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Generate 24Q return for a quarter',
    description: 'Assembles Annexure I (Q1–Q3) or Annexure I + II (Q4) from payroll ledger. Returns validation status.',
  })
  async generate(
    @Param('quarter') quarter: Quarter,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const { returnRecord, returnData, validationSummary } = await this.returnService.generate24QReturn(
      user.tid, fy, quarter, user.sub,
    );
    return {
      success: true,
      returnId: returnRecord.id,
      quarter, financialYear: fy,
      assessmentYear: returnData.assessmentYear,
      status: returnRecord.status,
      totals: {
        totalEmployees: returnRecord.totalEmployees,
        totalTaxDeducted: Number(returnRecord.totalTaxDeducted),
        totalTaxDeposited: Number(returnRecord.totalTaxDeposited),
        challanLinked: returnRecord.challanLinked,
      },
      validationSummary,
      canFile: validationSummary.isValid && returnRecord.challanLinked,
      disclaimer: '⚠️ 24Q export is for CA review and NSDL FVU upload. Not a direct filing.',
    };
  }

  @Get(':quarter')
  @ApiOperation({ summary: 'Get 24Q return record for a quarter' })
  @ApiQuery({ name: 'financialYear', required: false })
  async getReturn(
    @Param('quarter') quarter: Quarter,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const rec = await this.returnService.getReturn(user.tid, fy, quarter);
    return {
      quarter, financialYear: fy,
      id: rec.id, status: rec.status,
      totalTaxDeducted: Number(rec.totalTaxDeducted),
      totalTaxDeposited: Number(rec.totalTaxDeposited),
      totalEmployees: rec.totalEmployees,
      challanLinked: rec.challanLinked,
      tracesReconciled: (rec as any).tracesReconciled ?? false,
      generatedAt: rec.generatedAt,
      filedAt: (rec as any).filedAt ?? null,
      acknowledgementNumber: (rec as any).acknowledgementNumber ?? null,
    };
  }

  @Post(':quarter/validate')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Validate return without filing — checks PAN, challan coverage, TDS mismatch' })
  async validateReturn(
    @Param('quarter') quarter: Quarter,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    return this.returnService.validateReturn(user.tid, fy, quarter);
  }

  @Post(':quarter/mark-filed')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Mark 24Q return as filed',
    description: 'IRREVERSIBLE. Locks the return. Challans become immutable. Must have valid challans and TDS match.',
  })
  async markFiled(
    @Param('quarter') quarter: Quarter,
    @Query('financialYear') financialYear: string | undefined,
    @Body() body: { acknowledgementNumber?: string },
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    await this.returnService.markFiled(user.tid, fy, quarter, user.sub, body.acknowledgementNumber);
    return {
      success: true,
      message: `24Q ${quarter} ${fy} marked as FILED. Return is now immutable.`,
      quarter, financialYear: fy,
      filedBy: user.sub,
      filedAt: new Date(),
      acknowledgementNumber: body.acknowledgementNumber ?? null,
      warning: '⚠️ This action cannot be undone. Verify the NSDL acknowledgement before marking filed.',
    };
  }

  @Get(':quarter/export-fvu')
  @ApiOperation({
    summary: 'Export FVU-compatible TXT for NSDL upload',
    description: 'Generates the structured pipe-delimited file for upload to NSDL FVU utility. Export only — CA must validate before submission.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async exportFvu(
    @Param('quarter') quarter: Quarter,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
    @Res({ passthrough: true }) res: Response,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const fvuContent = await this.returnService.exportFVU(user.tid, fy, quarter);
    const filename = `24Q_${fy.replace('-', '')}_${quarter}_${user.tid.slice(0, 8)}.txt`;

    res.set({
      'Content-Type': 'text/plain; charset=utf-8',
      'Content-Disposition': `attachment; filename="${filename}"`,
      'X-FVU-Version': '27',
      'X-Export-Warning': 'EXPORT-ONLY-NOT-DIRECT-FILING',
    });
    res.send(fvuContent);
  }

  @Get(':quarter/audit')
  @ApiOperation({ summary: 'Audit trail for a quarter return' })
  async getAuditLog(
    @Param('quarter') quarter: Quarter,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const logs = await this.returnService.getAuditLog(user.tid, fy, quarter);
    return { quarter, financialYear: fy, totalEntries: logs.length, log: logs };
  }

  // ─── Challan Management ───────────────────────────────────────────────────

  @Post('challans')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Add challan manually (BSR code, serial, date, amount)' })
  async createChallan(
    @Body() dto: CreateChallanDto,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.challanService.createChallan(user.tid, dto, user.sub);
  }

  @Get('challans')
  @ApiOperation({ summary: 'List challans for a financial year, optionally filtered by quarter' })
  @ApiQuery({ name: 'financialYear', required: false })
  @ApiQuery({ name: 'quarter', required: false, enum: ['Q1', 'Q2', 'Q3', 'Q4'] })
  async getChallans(
    @Query('financialYear') financialYear: string | undefined,
    @Query('quarter') quarter: Quarter | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    return this.challanService.getChallans(user.tid, fy, quarter);
  }

  @Delete('challans/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Delete an unlinked challan' })
  async deleteChallan(
    @Param('id') id: string,
    @CurrentUser() user: JwtPayload,
  ) {
    await this.challanService.deleteChallan(user.tid, id, user.sub);
    return { success: true, message: `Challan ${id} deleted.` };
  }

  @Post('challans/import-csv')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Bulk import challans from CSV',
    description: 'Expected columns: BSR Code,Serial Number,Date (DD/MM/YYYY),Total Amount,TDS Amount,Bank Name',
  })
  async importChallanCsv(
    @Body() body: { financialYear?: string; quarter: Quarter; csvContent: string },
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = body.financialYear ?? getCurrentFy();
    return this.challanService.importFromCsv(user.tid, fy, body.quarter, body.csvContent, user.sub);
  }

  // ─── TRACES Integration ───────────────────────────────────────────────────

  @Post('traces/import/:quarter')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Import TRACES Part A CSV for reconciliation',
    description: 'Upload TRACES Part A statement. System compares with internal records and flags mismatches. Must reconcile before Form 16 can be locked.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async importTraces(
    @Param('quarter') quarter: Quarter,
    @Body() body: { financialYear?: string; csvContent: string },
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = body.financialYear ?? getCurrentFy();
    const result = await this.tracesService.importTracesFile(
      user.tid, fy, quarter, body.csvContent, user.sub,
    );
    return {
      quarter, financialYear: fy,
      parsed: result.parsed,
      parseErrors: result.errors,
      reconciliation: {
        isReconciled: result.reconciliation.isReconciled,
        totalInternalTds: result.reconciliation.totalInternalTds,
        totalTracesTds: result.reconciliation.totalTracesTds,
        variance: result.reconciliation.variance,
        matchedEmployees: result.reconciliation.matchedEmployees,
        mismatchCount: result.reconciliation.mismatchedEmployees.length,
        unmatchedInInternalCount: result.reconciliation.unmatchedInInternal.length,
        challanMatchSummary: result.reconciliation.challanMatches,
        mismatches: result.reconciliation.mismatchedEmployees,
      },
      message: result.reconciliation.isReconciled
        ? '✅ TRACES reconciliation PASSED. Form 16 Part A can now be populated with challan details.'
        : `❌ TRACES reconciliation FAILED. ${result.reconciliation.mismatchedEmployees.length} employee mismatch(es). Resolve before Form 16 issuance.`,
      disclaimer: '⚠️ TRACES data is authoritative. Internal mismatches must be corrected before filing.',
    };
  }

  @Get('traces/logs')
  @ApiOperation({ summary: 'TRACES import history for a financial year' })
  @ApiQuery({ name: 'financialYear', required: false })
  async getTracesLogs(
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const logs = await this.tracesService.getAllImportLogs(user.tid, fy);
    return { financialYear: fy, logs };
  }

  @Post('traces/populate-form16')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Push TRACES challan data into Form 16 Part A',
    description: 'Requires all 4 quarters to be TRACES-reconciled. Updates Form 16 Part A with verified BSR codes, CINs, and acknowledgement.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async populateForm16(
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const result = await this.tracesService.populateForm16PartAChallanData(user.tid, fy);
    return {
      success: true,
      financialYear: fy,
      ...result,
      message: `Form 16 Part A updated with TRACES challan data for ${result.updated} employees.`,
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE
// ─────────────────────────────────────────────────────────────────────────────

import { Module } from '@nestjs/common';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { PrismaClient } from '@prisma/client';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';

@Module({
  imports: [EventEmitterModule.forRoot()],
  controllers: [TdsReturnsController],
  providers: [TdsReturnService, ChallanService, TracesService, PrismaTenantService, PrismaClient],
  exports: [TdsReturnService, ChallanService, TracesService],
})
export class TdsReturnsModule {}
