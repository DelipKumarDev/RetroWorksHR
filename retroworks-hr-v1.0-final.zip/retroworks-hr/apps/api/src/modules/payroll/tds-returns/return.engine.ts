/**
 * RetroWorks HR — 24Q TDS Return Engine
 * ══════════════════════════════════════════════════════════════════════════════
 * Pure functions for assembling NSDL 24Q quarterly TDS return data.
 *
 * Legal basis:
 *   ▸ Section 200 read with Rule 31A, Income Tax Act 1961
 *   ▸ NSDL e-TDS/TCS Return Preparation Utility (RPU) spec v2.7+
 *   ▸ 24Q: TDS from salaries under Section 192
 *   ▸ Annexure I: Q1–Q3 (quarter-level summary per employee)
 *   ▸ Annexure II: Q4 only (full FY salary details per employee)
 *
 * ⚠️  DISCLAIMER: This engine generates return data for CA review and
 *     upload to NSDL FVU. It does NOT directly file with the
 *     Income Tax Department. Final filing is employer's responsibility.
 * ══════════════════════════════════════════════════════════════════════════════
 */

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────

export const QUARTERS = ['Q1', 'Q2', 'Q3', 'Q4'] as const;
export type Quarter = typeof QUARTERS[number];

// Quarter → calendar months
export const QUARTER_MONTHS: Record<Quarter, number[]> = {
  Q1: [4, 5, 6],          // Apr–Jun
  Q2: [7, 8, 9],          // Jul–Sep
  Q3: [10, 11, 12],       // Oct–Dec
  Q4: [1, 2, 3],          // Jan–Mar
};

// Quarter due dates (returns to be filed by)
export const QUARTER_DUE_DATES: Record<Quarter, string> = {
  Q1: '31 July',
  Q2: '31 October',
  Q3: '31 January',
  Q4: '31 May',
};

// Section 192: TDS on salary
export const SECTION_192 = '192';

// FVU format version (NSDL RPU 2.7)
export const FVU_FORMAT_VERSION = '27';

// ─────────────────────────────────────────────────────────────────────────────
// TYPE DEFINITIONS
// ─────────────────────────────────────────────────────────────────────────────

export interface DeductorInfo {
  tan: string;                    // TAN of employer  (format: XXXXX00000X)
  pan: string;                    // PAN of employer
  name: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
  email: string;
  responsiblePersonName: string;  // Person responsible for deduction
  responsiblePersonPan: string;
  responsiblePersonDesignation: string;
  deductorType: 'Company' | 'Government' | 'Individual' | 'Other';
}

export interface ChallanRecord {
  id: string;
  bsrCode: string;               // 7-digit BSR code of bank branch
  challanSerialNumber: string;   // Challan Identification Number (CIN) serial
  challanDate: string;           // DD/MM/YYYY
  totalAmountDeposited: number;
  tdsAmount: number;
  surchargeAmount: number;
  educationCessAmount: number;
  interestAmount: number;
  penaltyAmount: number;
  otherAmount: number;
  bankName: string;
  section: string;               // '192' for salary TDS
  quarter: Quarter;
  financialYear: string;
  isLinkedToReturn: boolean;
}

export interface EmployeeDeducteeRecord {
  employeeId: string;
  name: string;
  pan: string;                   // 'APPLIED' if pending
  category: 'Resident' | 'Non-Resident' | 'Foreign Company';
  // Salary details (required for Annexure II / Q4)
  grossSalary: number;
  hraExemption: number;
  ltaExemption: number;
  otherSection10Exemptions: number;
  standardDeduction: number;
  professionalTax: number;
  totalDeductionsChapterVIA: number;
  taxableIncome: number;
  // Tax
  taxOnIncome: number;
  surcharge: number;
  educationCess: number;
  totalTaxLiability: number;
  reliefUnder89: number;         // Section 89 relief (not common, defaults to 0)
  netTaxPayable: number;
  totalTdsDeducted: number;
  tdsDeductedThisQuarter: number;
  regimeType: 'old' | 'new';
  // For Annexure I (Q1–Q3): just quarter TDS
  quarterlyGrossSalary: number;
  quarterlyTds: number;
}

export interface AnnexureI {
  // Q1, Q2, Q3 — lighter format
  quarter: Quarter;
  financialYear: string;
  deductor: DeductorInfo;
  challans: ChallanRecord[];
  deductees: Array<{
    employeeId: string;
    name: string;
    pan: string;
    grossSalaryQuarter: number;
    tdsDeductedQuarter: number;
    section: string;
    // Challan reference
    challanBsrCode: string;
    challanSerialNumber: string;
    challanDate: string;
  }>;
  totals: {
    totalEmployees: number;
    totalGrossSalaryQuarter: number;
    totalTdsDeductedQuarter: number;
    totalChallanAmount: number;
    variance: number;           // challans - TDS (should be ≤ ₹1)
  };
}

export interface AnnexureII {
  // Q4 only — full FY salary details
  quarter: 'Q4';
  financialYear: string;
  deductor: DeductorInfo;
  challans: ChallanRecord[];    // All 4 quarters' challans
  deductees: EmployeeDeducteeRecord[];
  totals: {
    totalEmployees: number;
    totalGrossSalaryFY: number;
    totalTaxableIncomeFY: number;
    totalTaxLiabilityFY: number;
    totalTdsDeductedFY: number;
    totalChallanAmountFY: number;
    variance: number;
    totalSurcharge: number;
    totalCess: number;
  };
}

export interface Return24Q {
  id: string;
  tenantId: string;
  financialYear: string;
  quarter: Quarter;
  assessmentYear: string;
  deductor: DeductorInfo;
  annexure: Quarter extends 'Q4' ? AnnexureII : AnnexureI;
  annexureI?: AnnexureI;
  annexureII?: AnnexureII;       // Only for Q4
  status: 'draft' | 'validated' | 'filed' | 'reconciled';
  generatedAt: Date;
  checksumHash: string;
  validationErrors: ValidationError[];
  warnings: string[];
  templateVersion: string;
}

export interface ValidationError {
  code: string;
  field: string;
  message: string;
  severity: 'blocking' | 'warning';
  employeeId?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

export function r2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function getQuarterForMonth(calMonth: number): Quarter {
  if (calMonth >= 4 && calMonth <= 6) return 'Q1';
  if (calMonth >= 7 && calMonth <= 9) return 'Q2';
  if (calMonth >= 10 && calMonth <= 12) return 'Q3';
  return 'Q4';
}

export function getAssessmentYear(fy: string): string {
  const [startYear] = fy.split('-');
  const fyNum = parseInt(startYear ?? '2024', 10);
  return `${fyNum + 1}-${String(fyNum + 2).slice(2)}`;
}

export function getFyYearRange(fy: string): { startYear: number; endYear: number } {
  const [startYear] = fy.split('-');
  const startNum = parseInt(startYear ?? '2024', 10);
  return { startYear: startNum, endYear: startNum + 1 };
}

export function isQuarterMonth(calMonth: number, quarter: Quarter): boolean {
  return QUARTER_MONTHS[quarter].includes(calMonth);
}

export function validateTAN(tan: string): boolean {
  return /^[A-Z]{4}[0-9]{5}[A-Z]{1}$/.test(tan ?? '');
}

export function validatePAN(pan: string): boolean {
  if (pan === 'APPLIED' || pan === 'PANNOTAVBL') return true; // Special cases
  return /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(pan ?? '');
}

export function validateBSRCode(bsr: string): boolean {
  return /^\d{7}$/.test(bsr ?? '');
}

export function formatChallanDate(dateStr: string): string {
  // Normalize to DD/MM/YYYY
  if (/^\d{2}\/\d{2}\/\d{4}$/.test(dateStr)) return dateStr;
  try {
    const d = new Date(dateStr);
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yyyy = d.getFullYear();
    return `${dd}/${mm}/${yyyy}`;
  } catch {
    return dateStr;
  }
}

export function getCIN(challan: ChallanRecord): string {
  // CIN = BSR Code + Date (DDMMYYYY) + Serial Number
  const dateParts = challan.challanDate.split('/');
  const dateForCIN = dateParts.length === 3
    ? `${dateParts[0]}${dateParts[1]}${dateParts[2]}`
    : challan.challanDate.replace(/-/g, '').slice(0, 8);
  return `${challan.bsrCode}${dateForCIN}${challan.challanSerialNumber.padStart(5, '0')}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// VALIDATION ENGINE
// ─────────────────────────────────────────────────────────────────────────────

export interface ReturnValidationInput {
  deductor: DeductorInfo;
  challans: ChallanRecord[];
  deductees: EmployeeDeducteeRecord[];
  quarter: Quarter;
  financialYear: string;
}

export function validateReturn(input: ReturnValidationInput): {
  isValid: boolean;
  blockingErrors: ValidationError[];
  warnings: ValidationError[];
} {
  const blocking: ValidationError[] = [];
  const warnings: ValidationError[] = [];

  // ── Deductor validations ──
  if (!validateTAN(input.deductor.tan)) {
    blocking.push({ code: 'INVALID_TAN', field: 'deductor.tan',
      message: `Employer TAN "${input.deductor.tan}" is invalid. Required: XXXXX00000X format.`, severity: 'blocking' });
  }
  if (!validatePAN(input.deductor.pan) || input.deductor.pan === 'APPLIED') {
    blocking.push({ code: 'INVALID_DEDUCTOR_PAN', field: 'deductor.pan',
      message: `Employer PAN "${input.deductor.pan}" is invalid.`, severity: 'blocking' });
  }
  if (!input.deductor.responsiblePersonPan || !validatePAN(input.deductor.responsiblePersonPan)) {
    blocking.push({ code: 'INVALID_RESPONSIBLE_PERSON_PAN', field: 'deductor.responsiblePersonPan',
      message: 'Responsible person PAN is required and must be valid.', severity: 'blocking' });
  }

  // ── Challan validations ──
  if (input.challans.length === 0) {
    blocking.push({ code: 'NO_CHALLANS', field: 'challans',
      message: 'At least one challan must be linked before filing 24Q.', severity: 'blocking' });
  }

  for (const challan of input.challans) {
    if (!validateBSRCode(challan.bsrCode)) {
      blocking.push({ code: 'INVALID_BSR_CODE', field: `challan.${challan.id}.bsrCode`,
        message: `Challan BSR code "${challan.bsrCode}" is invalid. Must be 7 digits.`, severity: 'blocking' });
    }
    if (!challan.challanSerialNumber?.trim()) {
      blocking.push({ code: 'MISSING_CHALLAN_SERIAL', field: `challan.${challan.id}.serial`,
        message: 'Challan serial number is required.', severity: 'blocking' });
    }
    if (challan.totalAmountDeposited <= 0) {
      blocking.push({ code: 'ZERO_CHALLAN_AMOUNT', field: `challan.${challan.id}.amount`,
        message: 'Challan amount must be greater than zero.', severity: 'blocking' });
    }
  }

  // ── TDS vs Challan reconciliation ──
  const totalTdsDeducted = r2(input.deductees.reduce((s, d) => s + d.tdsDeductedThisQuarter, 0));
  const totalChallanDeposited = r2(input.challans.reduce((s, c) => s + c.totalAmountDeposited, 0));
  const variance = r2(Math.abs(totalChallanDeposited - totalTdsDeducted));

  if (variance > 1) {
    blocking.push({
      code: 'CHALLAN_TDS_MISMATCH', field: 'totals',
      message: `TDS deducted (₹${totalTdsDeducted.toLocaleString('en-IN')}) does not match ` +
        `challan deposited (₹${totalChallanDeposited.toLocaleString('en-IN')}). ` +
        `Variance: ₹${variance.toLocaleString('en-IN')}. Reconcile before filing.`,
      severity: 'blocking',
    });
  } else if (variance > 0) {
    warnings.push({ code: 'CHALLAN_ROUNDING_DIFF', field: 'totals',
      message: `Minor rounding difference of ₹${variance} between TDS and challan. Acceptable (≤ ₹1).`, severity: 'warning' });
  }

  // ── Employee PAN validations ──
  const noPanCount = input.deductees.filter(d => !d.pan || d.pan === 'APPLIED' || d.pan === 'PANNOTAVBL').length;
  if (noPanCount > 0) {
    warnings.push({ code: 'EMPLOYEES_WITHOUT_PAN', field: 'deductees',
      message: `${noPanCount} employee(s) do not have valid PAN. TDS rate may be higher. Update PAN before filing.`, severity: 'warning' });
  }

  // ── Q4 Annexure II check ──
  if (input.quarter === 'Q4') {
    const noDeclaration = input.deductees.filter(d => d.totalDeductionsChapterVIA === 0 && d.grossSalary > 0).length;
    if (noDeclaration > 0) {
      warnings.push({ code: 'Q4_NO_DECLARATION', field: 'deductees',
        message: `${noDeclaration} employee(s) have no Chapter VI-A declarations. Annexure II may be incomplete.`, severity: 'warning' });
    }
    // Check that total FY TDS matches sum
    for (const emp of input.deductees) {
      if (emp.totalTdsDeducted !== emp.netTaxPayable && Math.abs(emp.totalTdsDeducted - emp.netTaxPayable) > 100) {
        warnings.push({ code: 'EMP_TDS_TAX_MISMATCH', field: `employee.${emp.employeeId}`,
          employeeId: emp.employeeId,
          message: `Employee ${emp.pan}: TDS deducted ₹${emp.totalTdsDeducted} vs tax liability ₹${emp.netTaxPayable}. Difference: ₹${Math.abs(emp.totalTdsDeducted - emp.netTaxPayable)}.`, severity: 'warning' });
      }
    }
  }

  // ── Zero-deductee quarters ──
  if (input.deductees.length === 0) {
    warnings.push({ code: 'NO_DEDUCTEES', field: 'deductees',
      message: 'No deductees found for this quarter. If no salary was paid, this is expected. File NIL return if required.', severity: 'warning' });
  }

  return { isValid: blocking.length === 0, blockingErrors: blocking, warnings };
}

// ─────────────────────────────────────────────────────────────────────────────
// ANNEXURE I ASSEMBLER (Q1, Q2, Q3)
// ─────────────────────────────────────────────────────────────────────────────

export interface AssembleAnnexureIInput {
  quarter: Quarter;
  financialYear: string;
  deductor: DeductorInfo;
  challans: ChallanRecord[];
  deductees: EmployeeDeducteeRecord[];
}

export function assembleAnnexureI(input: AssembleAnnexureIInput): AnnexureI {
  if (input.quarter === 'Q4') {
    throw new Error('Annexure I is for Q1, Q2, Q3 only. Use assembleAnnexureII for Q4.');
  }

  const totalGross = r2(input.deductees.reduce((s, d) => s + d.quarterlyGrossSalary, 0));
  const totalTds = r2(input.deductees.reduce((s, d) => s + d.quarterlyTds, 0));
  const totalChallan = r2(input.challans.reduce((s, c) => s + c.totalAmountDeposited, 0));

  // Map each deductee to the first challan (simplification — real FVU maps per-deductee)
  const primaryChallan = input.challans[0];

  return {
    quarter: input.quarter,
    financialYear: input.financialYear,
    deductor: input.deductor,
    challans: input.challans,
    deductees: input.deductees.map(d => ({
      employeeId: d.employeeId,
      name: d.name,
      pan: d.pan || 'PANNOTAVBL',
      grossSalaryQuarter: d.quarterlyGrossSalary,
      tdsDeductedQuarter: d.quarterlyTds,
      section: SECTION_192,
      challanBsrCode: primaryChallan?.bsrCode ?? '',
      challanSerialNumber: primaryChallan?.challanSerialNumber ?? '',
      challanDate: primaryChallan?.challanDate ?? '',
    })),
    totals: {
      totalEmployees: input.deductees.length,
      totalGrossSalaryQuarter: totalGross,
      totalTdsDeductedQuarter: totalTds,
      totalChallanAmount: totalChallan,
      variance: r2(Math.abs(totalChallan - totalTds)),
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// ANNEXURE II ASSEMBLER (Q4 only — full FY details)
// ─────────────────────────────────────────────────────────────────────────────

export interface AssembleAnnexureIIInput {
  financialYear: string;
  deductor: DeductorInfo;
  allQuarterChallans: ChallanRecord[];   // All 4 quarters
  deductees: EmployeeDeducteeRecord[];  // Full FY data per employee
}

export function assembleAnnexureII(input: AssembleAnnexureIIInput): AnnexureII {
  const totalGross = r2(input.deductees.reduce((s, d) => s + d.grossSalary, 0));
  const totalTaxable = r2(input.deductees.reduce((s, d) => s + d.taxableIncome, 0));
  const totalLiability = r2(input.deductees.reduce((s, d) => s + d.totalTaxLiability, 0));
  const totalTdsDeducted = r2(input.deductees.reduce((s, d) => s + d.totalTdsDeducted, 0));
  const totalChallan = r2(input.allQuarterChallans.reduce((s, c) => s + c.totalAmountDeposited, 0));
  const totalSurcharge = r2(input.deductees.reduce((s, d) => s + d.surcharge, 0));
  const totalCess = r2(input.deductees.reduce((s, d) => s + d.educationCess, 0));

  return {
    quarter: 'Q4',
    financialYear: input.financialYear,
    deductor: input.deductor,
    challans: input.allQuarterChallans,
    deductees: input.deductees,
    totals: {
      totalEmployees: input.deductees.length,
      totalGrossSalaryFY: totalGross,
      totalTaxableIncomeFY: totalTaxable,
      totalTaxLiabilityFY: totalLiability,
      totalTdsDeductedFY: totalTdsDeducted,
      totalChallanAmountFY: totalChallan,
      variance: r2(Math.abs(totalChallan - totalTdsDeducted)),
      totalSurcharge,
      totalCess,
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// FULL 24Q RETURN ASSEMBLER
// ─────────────────────────────────────────────────────────────────────────────

export function assemble24QReturn(
  tenantId: string,
  quarter: Quarter,
  financialYear: string,
  deductor: DeductorInfo,
  challans: ChallanRecord[],
  deductees: EmployeeDeducteeRecord[],
  allFyChallans?: ChallanRecord[],   // Required for Q4
  allFyDeductees?: EmployeeDeducteeRecord[], // Required for Q4 Annexure II
): Return24Q {
  const validationResult = validateReturn({ deductor, challans, deductees, quarter, financialYear });

  const returnId = `24Q-${financialYear.replace('-', '')}-${quarter}-${tenantId.slice(0, 8).toUpperCase()}`;

  let annexureI: AnnexureI | undefined;
  let annexureII: AnnexureII | undefined;

  if (quarter !== 'Q4') {
    annexureI = assembleAnnexureI({ quarter, financialYear, deductor, challans, deductees });
  } else {
    // Q4 needs both
    annexureI = assembleAnnexureI({ quarter: 'Q4' as any, financialYear, deductor, challans, deductees });
    if (allFyChallans && allFyDeductees) {
      annexureII = assembleAnnexureII({
        financialYear, deductor,
        allQuarterChallans: allFyChallans,
        deductees: allFyDeductees,
      });
    }
  }

  const docStr = JSON.stringify({ quarter, financialYear, tenantId, annexureI, annexureII });
  const checksumHash = simpleHash(docStr);

  return {
    id: returnId,
    tenantId,
    financialYear,
    quarter,
    assessmentYear: getAssessmentYear(financialYear),
    deductor,
    annexure: (annexureI ?? {}) as any,
    annexureI,
    annexureII,
    status: validationResult.isValid ? 'draft' : 'draft',
    generatedAt: new Date(),
    checksumHash,
    validationErrors: [...validationResult.blockingErrors, ...validationResult.warnings],
    warnings: validationResult.warnings.map(w => w.message),
    templateVersion: '24Q-2024-v1',
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// FVU EXPORT — NSDL 24Q TXT FORMAT
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Generates NSDL FVU-compatible TXT format for 24Q return.
 *
 * Structure:
 *   Line 1:   File Header (FH)
 *   Lines 2+: Batch Header per challan (BH)
 *   Lines n+: Deductee Detail per employee (DD)
 *   Last:     File Trailer (FT) with record count
 *
 * ⚠️  This is a structured export for upload to NSDL FVU utility.
 *     NOT a direct filing. CA must validate before submission.
 */
export function generateFVUExport(returnData: Return24Q): string {
  const lines: string[] = [];
  const annexure = returnData.annexureI ?? returnData.annexureII;
  if (!annexure) return '';

  const d = returnData.deductor;
  const fy = returnData.financialYear;
  const fyShort = fy.replace('-', '-20').slice(0, 7); // e.g., 2024-2025
  const quarter = returnData.quarter;
  const qNum = quarter.replace('Q', '');

  // ── File Header (FH) ──────────────────────────────────────────────────────
  // Fields: Record Type | Batch No | TAN | PAN | FY | Quarter | Deductor Type | ... 
  const fh = [
    'FH',                             // Record type
    '1',                              // Batch number
    d.tan,                            // TAN
    d.pan,                            // PAN of deductor
    fy.replace('-', '-'),             // FY e.g., 2024-25
    qNum,                             // Quarter 1/2/3/4
    '24Q',                            // Form type
    FVU_FORMAT_VERSION,               // FVU version
    d.name.slice(0, 75),              // Deductor name
    d.address.slice(0, 255),         // Address
    d.city.slice(0, 25),
    d.state.slice(0, 25),
    d.pincode.slice(0, 6),
    d.phone.slice(0, 10),
    d.email.slice(0, 50),
    d.responsiblePersonName.slice(0, 75),
    d.responsiblePersonPan,
    d.responsiblePersonDesignation.slice(0, 25),
    returnData.generatedAt.toISOString().slice(0, 10).replace(/-/g, '/'),
    'RetroWorks HR Payroll System',   // Prepared by
  ].join('|');

  lines.push(fh);

  // ── Challan Blocks + Deductee Details ────────────────────────────────────
  let deducteeSeq = 1;
  const challans = annexure.challans ?? [];
  // For simplicity, assign all deductees to the first challan
  // Real FVU maps each deductee to a specific challan
  const deductees = 'deductees' in annexure ? annexure.deductees : [];

  for (let ci = 0; ci < Math.max(1, challans.length); ci++) {
    const challan = challans[ci];

    // ── Batch Header (BH) ────────────────────────────────────────────────
    const bh = [
      'BH',                           // Record type
      String(ci + 1),                 // Batch number
      challan?.bsrCode ?? '0000000',
      challan?.challanDate ?? '',
      challan?.challanSerialNumber ?? '',
      String(challan?.totalAmountDeposited ?? 0),
      String(challan?.tdsAmount ?? 0),
      String(challan?.surchargeAmount ?? 0),
      String(challan?.educationCessAmount ?? 0),
      String(challan?.interestAmount ?? 0),
      String(challan?.penaltyAmount ?? 0),
      SECTION_192,                    // Section code
      challan?.bankName ?? '',
      getCIN(challan as ChallanRecord),
    ].join('|');
    lines.push(bh);

    // ── Deductee Details (DD) ─────────────────────────────────────────────
    const batchDeductees = ci === 0 ? deductees : [];
    for (const emp of batchDeductees) {
      const empPan = (emp as any).pan || (emp as any).pan || 'PANNOTAVBL';
      const grossQ = (emp as any).grossSalaryQuarter ?? (emp as any).quarterlyGrossSalary ?? 0;
      const tdsQ = (emp as any).tdsDeductedQuarter ?? (emp as any).quarterlyTds ?? 0;

      const dd = [
        'DD',                         // Record type
        String(deducteeSeq++),        // Sequence
        empPan.slice(0, 10),
        ((emp as any).name ?? '').slice(0, 75),
        String(grossQ),               // Amount paid
        String(tdsQ),                 // TDS deducted
        String(challan?.bsrCode ?? ''),
        String(challan?.challanDate ?? ''),
        String(challan?.challanSerialNumber ?? ''),
        SECTION_192,
        '0',                          // Certificate issue date (0 = not issued yet)
        'R',                          // Resident
        '',                           // Remarks
      ].join('|');
      lines.push(dd);
    }
  }

  // ── File Trailer (FT) ────────────────────────────────────────────────────
  const totalDeducteeRecords = deductees.length;
  const totalChallanRecords = challans.length;
  const totalTds = r2(deductees.reduce((s: number, d: any) => s + (d.tdsDeductedQuarter ?? d.quarterlyTds ?? 0), 0));

  const ft = [
    'FT',                             // Record type
    String(totalChallanRecords),      // Total challan records
    String(totalDeducteeRecords),     // Total deductee records
    String(totalTds),                 // Total TDS amount
    returnData.checksumHash,          // Checksum
    '⚠️ EXPORT ONLY — NOT FOR DIRECT FILING — VALIDATE WITH NSDL FVU UTILITY BEFORE SUBMISSION',
  ].join('|');
  lines.push(ft);

  return lines.join('\r\n'); // NSDL uses Windows line endings
}

// ─────────────────────────────────────────────────────────────────────────────
// TRACES RECONCILIATION ENGINE
// ─────────────────────────────────────────────────────────────────────────────

export interface TracesRecord {
  pan: string;
  employeeName: string;
  bsrCode: string;
  challanDate: string;
  challanSerialNumber: string;
  tdsDeposited: number;
  section: string;
}

export interface ReconciliationResult {
  isReconciled: boolean;
  totalInternalTds: number;
  totalTracesTds: number;
  variance: number;
  matchedEmployees: number;
  mismatchedEmployees: Array<{
    pan: string;
    internalTds: number;
    tracesTds: number;
    difference: number;
  }>;
  unmatchedInInternal: string[];   // PANs in internal but not in TRACES
  unmatchedInTraces: string[];     // PANs in TRACES but not internal
  challanMatches: Array<{
    bsrCode: string;
    serial: string;
    date: string;
    internalAmount: number;
    tracesAmount: number;
    matched: boolean;
    difference: number;
  }>;
}

export function reconcileWithTraces(
  internalDeductees: Array<{ pan: string; totalTdsDeducted: number }>,
  tracesRecords: TracesRecord[],
  internalChallans: ChallanRecord[],
): ReconciliationResult {

  // Build lookup maps
  const internalByPan = new Map(internalDeductees.map(e => [e.pan, e.totalTdsDeducted]));
  const tracesByPan = new Map(tracesRecords.map(t => [t.pan, t.tdsDeposited]));

  const mismatchedEmployees: ReconciliationResult['mismatchedEmployees'] = [];
  const unmatchedInInternal: string[] = [];
  const unmatchedInTraces: string[] = [];
  let matchedCount = 0;

  // Check internal vs TRACES
  for (const [pan, internalTds] of internalByPan.entries()) {
    if (pan === 'APPLIED' || pan === 'PANNOTAVBL') continue;
    const tracesTds = tracesByPan.get(pan);
    if (tracesTds === undefined) {
      unmatchedInInternal.push(pan);
    } else {
      const diff = r2(Math.abs(internalTds - tracesTds));
      if (diff > 1) {
        mismatchedEmployees.push({ pan, internalTds, tracesTds, difference: diff });
      } else {
        matchedCount++;
      }
    }
  }

  // Find PANs in TRACES not in internal
  for (const [pan] of tracesByPan.entries()) {
    if (!internalByPan.has(pan)) {
      unmatchedInTraces.push(pan);
    }
  }

  // Challan reconciliation
  const tracesChallanMap = new Map(
    tracesRecords.map(t => [`${t.bsrCode}-${t.challanSerialNumber}-${t.challanDate}`, t.tdsDeposited])
  );

  const challanMatches = internalChallans.map(c => {
    const key = `${c.bsrCode}-${c.challanSerialNumber}-${c.challanDate}`;
    const tracesAmt = tracesChallanMap.get(key) ?? 0;
    const diff = r2(Math.abs(c.totalAmountDeposited - tracesAmt));
    return {
      bsrCode: c.bsrCode,
      serial: c.challanSerialNumber,
      date: c.challanDate,
      internalAmount: c.totalAmountDeposited,
      tracesAmount: tracesAmt,
      matched: diff <= 1,
      difference: diff,
    };
  });

  const totalInternalTds = r2(internalDeductees.reduce((s, d) => s + d.totalTdsDeducted, 0));
  const totalTracesTds = r2(tracesRecords.reduce((s, t) => s + t.tdsDeposited, 0));
  const variance = r2(Math.abs(totalInternalTds - totalTracesTds));

  return {
    isReconciled: mismatchedEmployees.length === 0 && unmatchedInInternal.length === 0 && variance <= 1,
    totalInternalTds,
    totalTracesTds,
    variance,
    matchedEmployees: matchedCount,
    mismatchedEmployees,
    unmatchedInInternal,
    unmatchedInTraces,
    challanMatches,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// TRACES CSV PARSER
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Parses TRACES Part A statement CSV file.
 * Expected columns: PAN | Employee Name | BSR Code | Challan Date | Challan Serial | TDS Deposited | Section
 */
export function parseTracesCsv(csvContent: string): {
  records: TracesRecord[];
  errors: string[];
} {
  const records: TracesRecord[] = [];
  const errors: string[] = [];
  const lines = csvContent.split('\n').map(l => l.trim()).filter(Boolean);

  if (lines.length < 2) {
    errors.push('TRACES CSV is empty or has no data rows.');
    return { records, errors };
  }

  // Skip header row
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i]!.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
    if (cols.length < 6) {
      errors.push(`Row ${i + 1}: insufficient columns (expected 7, got ${cols.length})`);
      continue;
    }

    const [pan, employeeName, bsrCode, challanDate, challanSerial, tdsStr, section] = cols;

    if (!pan || !validatePAN(pan!.toUpperCase())) {
      errors.push(`Row ${i + 1}: invalid PAN "${pan}"`);
      continue;
    }

    const tds = parseFloat(tdsStr ?? '0');
    if (isNaN(tds)) {
      errors.push(`Row ${i + 1}: invalid TDS amount "${tdsStr}"`);
      continue;
    }

    records.push({
      pan: pan!.toUpperCase(),
      employeeName: employeeName ?? '',
      bsrCode: bsrCode ?? '',
      challanDate: challanDate ?? '',
      challanSerialNumber: challanSerial ?? '',
      tdsDeposited: r2(tds),
      section: section ?? SECTION_192,
    });
  }

  return { records, errors };
}

// ─────────────────────────────────────────────────────────────────────────────
// DASHBOARD SUMMARY
// ─────────────────────────────────────────────────────────────────────────────

export interface QuarterDashboardEntry {
  quarter: Quarter;
  financialYear: string;
  totalEmployees: number;
  totalGrossSalary: number;
  totalTdsDeducted: number;
  totalChallanDeposited: number;
  variance: number;
  challanLinked: boolean;
  status: 'draft' | 'validated' | 'filed' | 'reconciled' | 'not_started' | 'mismatch';
  tracesReconciled: boolean;
  form16Ready: boolean;
  dueDate: string;
}

export function buildQuarterDashboard(
  quarter: Quarter,
  financialYear: string,
  payslipTotals: { employeeCount: number; grossSalary: number; tdsDeducted: number } | null,
  challans: ChallanRecord[],
  returnRecord: { status: string; tracesReconciled?: boolean } | null,
): QuarterDashboardEntry {
  const totalChallan = r2(challans.reduce((s, c) => s + c.totalAmountDeposited, 0));
  const variance = payslipTotals
    ? r2(Math.abs(totalChallan - payslipTotals.tdsDeducted))
    : 0;

  let status: QuarterDashboardEntry['status'] = 'not_started';
  if (returnRecord) {
    status = returnRecord.status as any;
    if (variance > 1 && returnRecord.status === 'draft') status = 'mismatch';
  }

  return {
    quarter,
    financialYear,
    totalEmployees: payslipTotals?.employeeCount ?? 0,
    totalGrossSalary: payslipTotals?.grossSalary ?? 0,
    totalTdsDeducted: payslipTotals?.tdsDeducted ?? 0,
    totalChallanDeposited: totalChallan,
    variance,
    challanLinked: challans.length > 0,
    status,
    tracesReconciled: returnRecord?.tracesReconciled ?? false,
    form16Ready: returnRecord?.status === 'reconciled',
    dueDate: QUARTER_DUE_DATES[quarter],
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

function simpleHash(data: string): string {
  let hash = 5381;
  for (let i = 0; i < data.length; i++) {
    hash = ((hash << 5) + hash) + data.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash).toString(16).toUpperCase().padStart(8, '0');
}

export function generateReturnId(tenantId: string, fy: string, quarter: Quarter): string {
  return `24Q-${fy.replace('-', '')}-${quarter}-${tenantId.slice(0, 8).toUpperCase()}`;
}

export function isReturnFiled(status: string): boolean {
  return status === 'filed' || status === 'reconciled';
}
