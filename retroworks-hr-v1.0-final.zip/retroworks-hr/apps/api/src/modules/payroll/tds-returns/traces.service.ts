/**
 * TRACES Service — TDS Reconciliation
 * AUDIT-PAYROLL-2: Refactored — zero raw PrismaClient.
 *
 * GLOBAL via $global:
 *   form16Record — already tenant-scoped via scope.form16Record
 *   tracesImportLog — scoped via scope.tracesImportLog
 * All ops via scope = db.forTenant(tenantId).
 */
import { Injectable, Logger, BadRequestException } from '@nestjs/common';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import {
  parseTracesCsv, reconcileWithTraces,
  type TracesRecord, type ReconciliationResult, type Quarter,
} from './return.engine';

@Injectable()
export class TracesService {
  private readonly logger = new Logger(TracesService.name);
  constructor(private readonly db: PrismaTenantService) {}

  async importTracesFile(
    tenantId: string, financialYear: string, quarter: Quarter,
    csvContent: string, importedBy: string,
  ): Promise<{ log: any; parsed: number; errors: string[]; reconciliation: ReconciliationResult }> {
    if (!csvContent?.trim()) throw new BadRequestException('TRACES file content is empty.');

    const { records, errors } = parseTracesCsv(csvContent);
    if (records.length === 0 && errors.length > 0) {
      throw new BadRequestException(`Failed to parse TRACES: ${errors.slice(0, 3).join('; ')}`);
    }

    const scope = this.db.forTenant(tenantId);
    const { fyStartYear } = this._fyRange(financialYear);

    const [internalPayslips, internalChallans] = await Promise.all([
      this._getInternalTdsByEmployee(scope, tenantId, financialYear, quarter, fyStartYear),
      scope.tdsChallan.findMany({ where: { financialYear, quarter } }),
    ]);

    const reconciliation = reconcileWithTraces(
      internalPayslips, records,
      (internalChallans as any[]).map(c => ({
        id: c.id, bsrCode: c.bsrCode, challanSerialNumber: c.challanSerialNumber,
        challanDate: c.challanDate, totalAmountDeposited: Number(c.totalAmountDeposited),
        tdsAmount: Number(c.tdsAmount), surchargeAmount: Number(c.surchargeAmount ?? 0),
        educationCessAmount: Number(c.educationCessAmount ?? 0),
        interestAmount: Number(c.interestAmount ?? 0), penaltyAmount: Number(c.penaltyAmount ?? 0),
        otherAmount: 0, bankName: c.bankName, section: '192',
        quarter: c.quarter as Quarter, financialYear: c.financialYear,
        isLinkedToReturn: c.isLinkedToReturn,
      })),
    );

    const contentHash = this._hash(csvContent);
    const log = await scope.tracesImportLog.create({
      data: {
        financialYear, quarter, importedBy, importedAt: new Date(),
        recordCount: records.length,
        mismatchCount: reconciliation.mismatchedEmployees.length + reconciliation.unmatchedInInternal.length,
        parseErrors: errors.length,
        status: reconciliation.isReconciled ? 'reconciled' : 'mismatch',
        totalTracesTds: reconciliation.totalTracesTds,
        totalInternalTds: reconciliation.totalInternalTds,
        variance: reconciliation.variance, contentHash,
        mismatchDetail: {
          mismatchedEmployees: reconciliation.mismatchedEmployees,
          unmatchedInInternal: reconciliation.unmatchedInInternal,
          unmatchedInTraces:   reconciliation.unmatchedInTraces,
          challanMatches:      reconciliation.challanMatches,
        } as any,
      },
    });

    if (reconciliation.isReconciled) {
      await scope.tdsReturn.updateMany({
        where: { financialYear, quarter, status: { not: 'filed' } },
        data: { status: 'reconciled', tracesReconciled: true, reconciledAt: new Date() },
      });

      for (const tc of records) {
        await scope.tdsChallan.updateMany({
          where: { financialYear, quarter, bsrCode: tc.bsrCode, challanSerialNumber: tc.challanSerialNumber },
          data: { tracesVerified: true, tracesDepositedAmount: tc.tdsDeposited },
        });
      }
      this.logger.log(`TRACES reconciled: ${tenantId} FY${financialYear} ${quarter}`);
    } else {
      this.logger.warn(`TRACES FAILED: ${tenantId} FY${financialYear} ${quarter}. Mismatches: ${reconciliation.mismatchedEmployees.length}`);
    }

    return { log, parsed: records.length, errors, reconciliation };
  }

  async getLatestReconciliation(tenantId: string, financialYear: string, quarter: Quarter) {
    return this.db.forTenant(tenantId).tracesImportLog.findFirst({
      where: { financialYear, quarter },
      orderBy: { importedAt: 'desc' },
    });
  }

  async getAllImportLogs(tenantId: string, financialYear: string) {
    return this.db.forTenant(tenantId).tracesImportLog.findMany({
      where: { financialYear },
      orderBy: [{ quarter: 'asc' }, { importedAt: 'desc' }],
    });
  }

  async populateForm16PartAChallanData(tenantId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);
    const logs = await scope.tracesImportLog.findMany({ where: { financialYear, status: 'reconciled' } });
    const reconciledQuarters = new Set((logs as any[]).map(l => l.quarter));
    if (reconciledQuarters.size < 4) {
      throw new BadRequestException(
        `Not all quarters TRACES-reconciled. Reconciled: ${[...reconciledQuarters].join(', ')}. ` +
        `Missing: ${['Q1','Q2','Q3','Q4'].filter(q => !reconciledQuarters.has(q)).join(', ')}`,
      );
    }

    const challans = await scope.tdsChallan.findMany({ where: { financialYear, tracesVerified: true } });
    const challanArray = (challans as any[]).map(c => ({
      bsrCode: c.bsrCode, cin: c.cin, challanDate: c.challanDate,
      amount: Number(c.tracesDepositedAmount ?? c.totalAmountDeposited),
      quarter: c.quarter, tracesVerified: c.tracesVerified,
    }));

    const form16Records = await scope.form16Record.findMany({ where: { financialYear } });
    let updated = 0, skipped = 0;

    for (const record of form16Records as any[]) {
      if (record.isLocked) { skipped++; continue; }
      const docData = record.documentData as any;
      if (docData?.partA) {
        docData.partA.quarterlyTds = docData.partA.quarterlyTds?.map((q: any) => ({
          ...q,
          receiptNumbers: (challans as any[]).filter(c => c.quarter === q.quarter).map(c => c.cin),
        }));
        docData.partA.tracesVerified = true;
        docData.partA.acknowledgement = `TRACES verified. Challans: ${challanArray.map(c => c.cin).join(', ')}`;
      }
      await scope.form16Record.update({
        where: { id: record.id },
        data: { documentData: docData, updatedAt: new Date() },
      });
      updated++;
    }

    this.logger.log(`Form 16 Part A updated with TRACES: ${updated} records`);
    return { updated, skipped };
  }

  generateSampleTracesCsv(employees: Array<{ pan: string; name: string; tds: number }>): string {
    const header = 'PAN,Employee Name,BSR Code,Challan Date,Challan Serial,TDS Deposited,Section';
    return [header, ...employees.map(e => `${e.pan},"${e.name}",1234567,01/07/2024,00001,${e.tds},192`)].join('\n');
  }

  private async _getInternalTdsByEmployee(
    scope: ReturnType<PrismaTenantService['forTenant']>,
    tenantId: string, financialYear: string, quarter: Quarter, fyStartYear: number,
  ) {
    const quarterMonths: Record<string, number[]> = {
      Q1: [4,5,6], Q2: [7,8,9], Q3: [10,11,12], Q4: [1,2,3],
    };
    const months = quarterMonths[quarter] ?? [];

    const payslips = await scope.payslip.findMany({
      where: {
        status: { not: 'cancelled' },
        month: { in: months },
        year: quarter === 'Q4' ? fyStartYear + 1 : fyStartYear,
      },
      select: { employeeId: true, tdsDeducted: true },
    });

    const empMap = new Map<string, number>();
    for (const p of payslips as any[]) {
      empMap.set(p.employeeId, (empMap.get(p.employeeId) ?? 0) + Number(p.tdsDeducted ?? 0));
    }

    const employees = await scope.employee.findMany({
      where: { id: { in: [...empMap.keys()] } },
      select: { id: true },
    });

    return (employees as any[]).map(e => ({
      pan: e.pan ?? 'APPLIED',
      totalTdsDeducted: empMap.get(e.id) ?? 0,
    }));
  }

  private _fyRange(fy: string) {
    return { fyStartYear: parseInt(fy.split('-')[0] ?? '2024', 10) };
  }

  private _hash(data: string): string {
    let h = 0;
    for (let i = 0; i < data.length; i++) { h = ((h << 5) - h) + data.charCodeAt(i); h |= 0; }
    return Math.abs(h).toString(16).toUpperCase().padStart(8, '0');
  }
}
