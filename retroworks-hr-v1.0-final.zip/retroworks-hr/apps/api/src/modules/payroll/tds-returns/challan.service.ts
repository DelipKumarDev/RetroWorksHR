/**
 * Challan Service — TDS Challan lifecycle
 * AUDIT-PAYROLL-2: Refactored — zero raw PrismaClient.
 * All ops via scope = db.forTenant(tenantId).
 * deleteChallan: proxy adds tenantId to DELETE WHERE — cross-tenant delete impossible.
 */
import {
  Injectable, Logger, NotFoundException,
  ConflictException, BadRequestException,
} from '@nestjs/common';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import {
  validateBSRCode, formatChallanDate, r2,
  type ChallanRecord, type Quarter,
} from './return.engine';

export class CreateChallanDto {
  financialYear!: string;
  quarter!: Quarter;
  bsrCode!: string;
  challanSerialNumber!: string;
  challanDate!: string;
  totalAmountDeposited!: number;
  tdsAmount!: number;
  surchargeAmount?: number;
  educationCessAmount?: number;
  interestAmount?: number;
  penaltyAmount?: number;
  bankName!: string;
}

@Injectable()
export class ChallanService {
  private readonly logger = new Logger(ChallanService.name);
  constructor(private readonly db: PrismaTenantService) {}

  async createChallan(tenantId: string, dto: CreateChallanDto, createdBy: string) {
    if (!validateBSRCode(dto.bsrCode)) throw new BadRequestException(`Invalid BSR "${dto.bsrCode}" — must be 7 digits.`);
    if (!/^\d{4}-\d{2}$/.test(dto.financialYear)) throw new BadRequestException('Financial year must be YYYY-YY');

    const scope = this.db.forTenant(tenantId);
    const normalizedDate = formatChallanDate(dto.challanDate);

    // proxy injects tenantId — no manual tenantId in where
    const existing = await scope.tdsChallan.findFirst({
      where: {
        bsrCode: dto.bsrCode,
        challanSerialNumber: dto.challanSerialNumber,
        challanDate: normalizedDate,
      },
    });
    if (existing) {
      throw new ConflictException(`Challan BSR ${dto.bsrCode}/Serial ${dto.challanSerialNumber}/Date ${normalizedDate} exists.`);
    }

    // proxy injects tenantId into CREATE data
    const challan = await scope.tdsChallan.create({
      data: {
        financialYear:        dto.financialYear,
        quarter:              dto.quarter,
        bsrCode:              dto.bsrCode,
        challanSerialNumber:  dto.challanSerialNumber,
        challanDate:          normalizedDate,
        totalAmountDeposited: dto.totalAmountDeposited,
        tdsAmount:            dto.tdsAmount,
        surchargeAmount:      dto.surchargeAmount ?? 0,
        educationCessAmount:  dto.educationCessAmount ?? 0,
        interestAmount:       dto.interestAmount ?? 0,
        penaltyAmount:        dto.penaltyAmount ?? 0,
        bankName:             dto.bankName,
        cin:                  this._buildCIN(dto.bsrCode, normalizedDate, dto.challanSerialNumber),
        isLinkedToReturn:     false,
        createdBy,            createdAt: new Date(),
      },
    });

    this.logger.log(`Challan created: ${(challan as any).cin} for ${tenantId} FY${dto.financialYear} ${dto.quarter}`);
    return challan;
  }

  async importFromCsv(
    tenantId: string, financialYear: string, quarter: Quarter,
    csvContent: string, importedBy: string,
  ): Promise<{ created: number; skipped: number; errors: string[] }> {
    const lines = csvContent.split('\n').map(l => l.trim()).filter(Boolean);
    const errors: string[] = [];
    let created = 0, skipped = 0;

    for (let i = 1; i < lines.length; i++) {
      const cols = lines[i]!.split(',').map(c => c.trim().replace(/^"|"$/g, ''));
      if (cols.length < 6) { errors.push(`Row ${i + 1}: insufficient columns`); skipped++; continue; }
      const [bsr, serial, date, totalAmt, tdsAmt, bankName] = cols;
      try {
        await this.createChallan(tenantId, {
          financialYear, quarter,
          bsrCode: bsr ?? '', challanSerialNumber: serial ?? '',
          challanDate: date ?? '',
          totalAmountDeposited: parseFloat(totalAmt ?? '0'),
          tdsAmount: parseFloat(tdsAmt ?? '0'),
          bankName: bankName ?? '',
        }, importedBy);
        created++;
      } catch (err: any) {
        if (err instanceof ConflictException) skipped++;
        else { errors.push(`Row ${i + 1}: ${err.message}`); skipped++; }
      }
    }
    return { created, skipped, errors };
  }

  async getChallans(tenantId: string, financialYear: string, quarter?: Quarter) {
    return this.db.forTenant(tenantId).tdsChallan.findMany({
      where: { financialYear, ...(quarter ? { quarter } : {}) },
      orderBy: [{ quarter: 'asc' }, { challanDate: 'asc' }],
    });
  }

  async getChallanById(tenantId: string, id: string) {
    // proxy injects tenantId — id from another tenant will return null → 404
    const c = await this.db.forTenant(tenantId).tdsChallan.findFirst({ where: { id } });
    if (!c) throw new NotFoundException(`Challan ${id} not found`);
    return c;
  }

  async deleteChallan(tenantId: string, id: string, deletedBy: string) {
    const c = await this.getChallanById(tenantId, id);
    if ((c as any).isLinkedToReturn) {
      throw new ConflictException('Cannot delete a challan linked to a filed return.');
    }
    // proxy scopes DELETE WHERE to { id, tenantId } — cross-tenant delete structurally impossible
    await this.db.forTenant(tenantId).tdsChallan.delete({ where: { id } });
    this.logger.log(`Challan ${id} deleted by ${deletedBy}`);
  }

  async validateChallanCoverage(
    tenantId: string, financialYear: string, quarter: Quarter, totalTdsDeducted: number,
  ) {
    const challans = await this.getChallans(tenantId, financialYear, quarter);
    const totalDeposited = r2((challans as any[]).reduce((s, c) => s + Number(c.totalAmountDeposited), 0));
    const variance = r2(Math.abs(totalDeposited - totalTdsDeducted));
    return {
      isValid: variance <= 1, variance, totalDeposited,
      message: variance <= 1
        ? `✅ Challan ₹${totalDeposited.toLocaleString('en-IN')} matches TDS ₹${totalTdsDeducted.toLocaleString('en-IN')}`
        : `❌ Variance ₹${variance.toLocaleString('en-IN')}: TDS ₹${totalTdsDeducted.toLocaleString('en-IN')} vs deposited ₹${totalDeposited.toLocaleString('en-IN')}`,
    };
  }

  async markChallansLinked(tenantId: string, challanIds: string[]) {
    // proxy adds tenantId to updateMany WHERE — cross-tenant update impossible
    await this.db.forTenant(tenantId).tdsChallan.updateMany({
      where: { id: { in: challanIds } },
      data: { isLinkedToReturn: true, updatedAt: new Date() },
    });
  }

  private _buildCIN(bsr: string, date: string, serial: string): string {
    const parts = date.split('/');
    const dateStr = parts.length === 3 ? `${parts[0]}${parts[1]}${parts[2]}` : date.replace(/-/g, '').slice(0, 8);
    return `${bsr}${dateStr}${serial.padStart(5, '0')}`;
  }
}
