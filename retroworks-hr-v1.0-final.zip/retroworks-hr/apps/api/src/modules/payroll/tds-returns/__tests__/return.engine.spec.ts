/**
 * RetroWorks HR — 24Q TDS Return Engine Test Suite
 * ═════════════════════════════════════════════════════
 * 35 tests across:
 *   ▸ Utility functions (quarter mapping, CIN, validation)
 *   ▸ Validation engine (blocking errors + warnings)
 *   ▸ Annexure I assembly (Q1–Q3)
 *   ▸ Annexure II assembly (Q4 full FY)
 *   ▸ FVU export format
 *   ▸ TRACES CSV parsing
 *   ▸ Reconciliation engine
 *   ▸ Edge cases: no payroll, high volume, multiple challans, PAN missing
 *
 * Run: npx jest return.engine.spec --verbose
 */

import {
  validateTAN, validatePAN, validateBSRCode,
  getQuarterForMonth, formatChallanDate, getCIN,
  validateReturn, assembleAnnexureI, assembleAnnexureII,
  assemble24QReturn, generateFVUExport, parseTracesCsv,
  reconcileWithTraces, buildQuarterDashboard, isReturnFiled,
  QUARTER_MONTHS, QUARTER_DUE_DATES,
  type Quarter, type DeductorInfo, type ChallanRecord,
  type EmployeeDeducteeRecord,
} from '../return.engine';

// ─────────────────────────────────────────────────────────────────────────────
// FIXTURES
// ─────────────────────────────────────────────────────────────────────────────

const DEDUCTOR: DeductorInfo = {
  tan: 'BLRR01234A',
  pan: 'AABCR1234D',
  name: 'RetroWorks Technologies Pvt Ltd',
  address: '100 MG Road',
  city: 'Bengaluru',
  state: 'Karnataka',
  pincode: '560001',
  phone: '9876543210',
  email: 'payroll@retroworks.in',
  responsiblePersonName: 'Priya Sharma',
  responsiblePersonPan: 'ABCPS1234Z',
  responsiblePersonDesignation: 'Director Finance',
  deductorType: 'Company',
};

function makeChallan(overrides: Partial<ChallanRecord> = {}): ChallanRecord {
  return {
    id: 'chal-001',
    bsrCode: '1234567',
    challanSerialNumber: '00001',
    challanDate: '01/07/2024',
    totalAmountDeposited: 90000,
    tdsAmount: 90000,
    surchargeAmount: 0,
    educationCessAmount: 0,
    interestAmount: 0,
    penaltyAmount: 0,
    otherAmount: 0,
    bankName: 'State Bank of India',
    section: '192',
    quarter: 'Q1',
    financialYear: '2024-25',
    isLinkedToReturn: false,
    ...overrides,
  };
}

function makeEmployee(overrides: Partial<EmployeeDeducteeRecord> = {}): EmployeeDeducteeRecord {
  return {
    employeeId: 'emp-001',
    name: 'Ramesh Kumar',
    pan: 'ABCPK1234F',
    category: 'Resident',
    grossSalary: 91_250 * 3,
    hraExemption: 15000,
    ltaExemption: 0,
    otherSection10Exemptions: 0,
    standardDeduction: 75000,
    professionalTax: 600,
    totalDeductionsChapterVIA: 0,
    taxableIncome: 200000,
    taxOnIncome: 22500,
    surcharge: 0,
    educationCess: 900,
    totalTaxLiability: 23400,
    reliefUnder89: 0,
    netTaxPayable: 23400,
    totalTdsDeducted: 22500,
    tdsDeductedThisQuarter: 22500,
    regimeType: 'new',
    quarterlyGrossSalary: 91_250 * 3,
    quarterlyTds: 22500,
    ...overrides,
  };
}

const EMPLOYEES_10 = Array.from({ length: 10 }, (_, i) =>
  makeEmployee({ employeeId: `emp-${i.toString().padStart(3, '0')}`, pan: `ABCPK${(1234 + i).toString().padStart(4, '0')}F` })
);

// ─────────────────────────────────────────────────────────────────────────────
// 1. UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

describe('Utility Functions', () => {

  test('U01 — validateTAN: valid TAN passes', () => {
    expect(validateTAN('BLRR01234A')).toBe(true);
    expect(validateTAN('DELI12345B')).toBe(true);
  });

  test('U02 — validateTAN: invalid TAN fails', () => {
    expect(validateTAN('BADTAN')).toBe(false);
    expect(validateTAN('12345678901')).toBe(false);
    expect(validateTAN('')).toBe(false);
  });

  test('U03 — validatePAN: valid PAN passes', () => {
    expect(validatePAN('ABCPK1234F')).toBe(true);
    expect(validatePAN('AABCR1234D')).toBe(true);
  });

  test('U04 — validatePAN: APPLIED and PANNOTAVBL are allowed special cases', () => {
    expect(validatePAN('APPLIED')).toBe(true);
    expect(validatePAN('PANNOTAVBL')).toBe(true);
  });

  test('U05 — validateBSRCode: 7-digit code is valid', () => {
    expect(validateBSRCode('1234567')).toBe(true);
    expect(validateBSRCode('0000000')).toBe(true);
    expect(validateBSRCode('123456')).toBe(false);  // 6 digits
    expect(validateBSRCode('12345678')).toBe(false); // 8 digits
    expect(validateBSRCode('ABCDEFG')).toBe(false);  // non-numeric
  });

  test('U06 — getQuarterForMonth: all 12 months map correctly', () => {
    expect(getQuarterForMonth(4)).toBe('Q1');
    expect(getQuarterForMonth(6)).toBe('Q1');
    expect(getQuarterForMonth(7)).toBe('Q2');
    expect(getQuarterForMonth(9)).toBe('Q2');
    expect(getQuarterForMonth(10)).toBe('Q3');
    expect(getQuarterForMonth(12)).toBe('Q3');
    expect(getQuarterForMonth(1)).toBe('Q4');
    expect(getQuarterForMonth(3)).toBe('Q4');
  });

  test('U07 — getCIN: correct format BSR+DATE+SERIAL', () => {
    const challan = makeChallan({ bsrCode: '1234567', challanDate: '01/07/2024', challanSerialNumber: '00001' });
    const cin = getCIN(challan);
    expect(cin).toBe('1234567010720240000100001'); // BSR(7) + DD(2) + MM(2) + YYYY(4) + serial(5) padded
  });

  test('U08 — formatChallanDate: ISO → DD/MM/YYYY', () => {
    expect(formatChallanDate('2024-07-01')).toBe('01/07/2024');
  });

  test('U09 — formatChallanDate: already formatted passes through', () => {
    expect(formatChallanDate('01/07/2024')).toBe('01/07/2024');
  });

  test('U10 — QUARTER_MONTHS: Q1=Apr-Jun, Q4=Jan-Mar', () => {
    expect(QUARTER_MONTHS.Q1).toEqual([4, 5, 6]);
    expect(QUARTER_MONTHS.Q4).toEqual([1, 2, 3]);
  });

  test('U11 — QUARTER_DUE_DATES: Q1 due 31 July, Q4 due 31 May', () => {
    expect(QUARTER_DUE_DATES.Q1).toBe('31 July');
    expect(QUARTER_DUE_DATES.Q4).toBe('31 May');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 2. VALIDATION ENGINE
// ─────────────────────────────────────────────────────────────────────────────

describe('Return Validation', () => {

  test('V01 — Valid return with matched TDS+challan passes', () => {
    const result = validateReturn({
      deductor: DEDUCTOR, quarter: 'Q1', financialYear: '2024-25',
      challans: [makeChallan({ totalAmountDeposited: 22500 })],
      deductees: [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    });
    expect(result.isValid).toBe(true);
    expect(result.blockingErrors).toHaveLength(0);
  });

  test('V02 — Invalid TAN blocks return', () => {
    const result = validateReturn({
      deductor: { ...DEDUCTOR, tan: 'BADTAN' }, quarter: 'Q1', financialYear: '2024-25',
      challans: [makeChallan()], deductees: [makeEmployee()],
    });
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'INVALID_TAN')).toBe(true);
  });

  test('V03 — Missing challans blocks return', () => {
    const result = validateReturn({
      deductor: DEDUCTOR, quarter: 'Q1', financialYear: '2024-25',
      challans: [], deductees: [makeEmployee()],
    });
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'NO_CHALLANS')).toBe(true);
  });

  test('V04 — Challan TDS mismatch > ₹1 blocks return', () => {
    // TDS deducted: 22500, challan deposited: 10000 → mismatch 12500
    const result = validateReturn({
      deductor: DEDUCTOR, quarter: 'Q1', financialYear: '2024-25',
      challans: [makeChallan({ totalAmountDeposited: 10000 })],
      deductees: [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    });
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'CHALLAN_TDS_MISMATCH')).toBe(true);
  });

  test('V05 — Challan exactly ₹1 less than TDS → warning, not blocking', () => {
    const result = validateReturn({
      deductor: DEDUCTOR, quarter: 'Q1', financialYear: '2024-25',
      challans: [makeChallan({ totalAmountDeposited: 22499 })],
      deductees: [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    });
    expect(result.isValid).toBe(true);
    expect(result.warnings.some(w => w.code === 'CHALLAN_ROUNDING_DIFF')).toBe(true);
  });

  test('V06 — Invalid BSR code blocks return', () => {
    const result = validateReturn({
      deductor: DEDUCTOR, quarter: 'Q1', financialYear: '2024-25',
      challans: [makeChallan({ bsrCode: 'BADBSR' })],
      deductees: [makeEmployee()],
    });
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'INVALID_BSR_CODE')).toBe(true);
  });

  test('V07 — Employee without PAN produces warning', () => {
    const result = validateReturn({
      deductor: DEDUCTOR, quarter: 'Q1', financialYear: '2024-25',
      challans: [makeChallan({ totalAmountDeposited: 22500 })],
      deductees: [makeEmployee({ pan: 'APPLIED', tdsDeductedThisQuarter: 22500 })],
    });
    expect(result.isValid).toBe(true);
    expect(result.warnings.some(w => w.code === 'EMPLOYEES_WITHOUT_PAN')).toBe(true);
  });

  test('V08 — Zero challan amount blocks return', () => {
    const result = validateReturn({
      deductor: DEDUCTOR, quarter: 'Q1', financialYear: '2024-25',
      challans: [makeChallan({ totalAmountDeposited: 0 })],
      deductees: [makeEmployee()],
    });
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'ZERO_CHALLAN_AMOUNT')).toBe(true);
  });

  test('V09 — No deductees produces warning (NIL return)', () => {
    const result = validateReturn({
      deductor: DEDUCTOR, quarter: 'Q1', financialYear: '2024-25',
      challans: [makeChallan()], deductees: [],
    });
    expect(result.warnings.some(w => w.code === 'NO_DEDUCTEES')).toBe(true);
  });

  test('V10 — Missing responsible person PAN blocks return', () => {
    const result = validateReturn({
      deductor: { ...DEDUCTOR, responsiblePersonPan: '' }, quarter: 'Q1', financialYear: '2024-25',
      challans: [makeChallan({ totalAmountDeposited: 22500 })],
      deductees: [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    });
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'INVALID_RESPONSIBLE_PERSON_PAN')).toBe(true);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 3. ANNEXURE I ASSEMBLY
// ─────────────────────────────────────────────────────────────────────────────

describe('Annexure I Assembly (Q1–Q3)', () => {

  test('A01 — Annexure I has correct quarter and FY', () => {
    const ann = assembleAnnexureI({
      quarter: 'Q1', financialYear: '2024-25',
      deductor: DEDUCTOR, challans: [makeChallan({ totalAmountDeposited: 22500 })],
      deductees: [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    });
    expect(ann.quarter).toBe('Q1');
    expect(ann.financialYear).toBe('2024-25');
  });

  test('A02 — Annexure I totals match deductee sum', () => {
    const deductees = EMPLOYEES_10.map(e => ({ ...e, tdsDeductedThisQuarter: 9000, quarterlyTds: 9000 }));
    const ann = assembleAnnexureI({
      quarter: 'Q2', financialYear: '2024-25', deductor: DEDUCTOR,
      challans: [makeChallan({ totalAmountDeposited: 90000, quarter: 'Q2' })],
      deductees,
    });
    expect(ann.totals.totalEmployees).toBe(10);
    expect(ann.totals.totalTdsDeductedQuarter).toBe(90000);
    expect(ann.totals.variance).toBe(0);
  });

  test('A03 — Annexure I throws for Q4', () => {
    expect(() => assembleAnnexureI({
      quarter: 'Q4' as any, financialYear: '2024-25',
      deductor: DEDUCTOR, challans: [makeChallan()], deductees: [makeEmployee()],
    })).toThrow('Annexure I is for Q1, Q2, Q3 only');
  });

  test('A04 — Multiple challans in same quarter sum correctly', () => {
    const challans = [
      makeChallan({ id: 'c1', totalAmountDeposited: 45000 }),
      makeChallan({ id: 'c2', totalAmountDeposited: 45000, challanSerialNumber: '00002' }),
    ];
    const deductees = EMPLOYEES_10.map(e => ({ ...e, tdsDeductedThisQuarter: 9000, quarterlyTds: 9000 }));
    const ann = assembleAnnexureI({
      quarter: 'Q1', financialYear: '2024-25', deductor: DEDUCTOR,
      challans, deductees,
    });
    expect(ann.totals.totalChallanAmount).toBe(90000);
    expect(ann.totals.variance).toBe(0);
  });

  test('A05 — Deductee records use PANNOTAVBL for missing PANs', () => {
    const ann = assembleAnnexureI({
      quarter: 'Q1', financialYear: '2024-25', deductor: DEDUCTOR,
      challans: [makeChallan({ totalAmountDeposited: 22500 })],
      deductees: [makeEmployee({ pan: '', tdsDeductedThisQuarter: 22500 })],
    });
    expect(ann.deductees[0]!.pan).toBe('PANNOTAVBL');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 4. ANNEXURE II ASSEMBLY (Q4)
// ─────────────────────────────────────────────────────────────────────────────

describe('Annexure II Assembly (Q4 Full FY)', () => {

  test('A06 — Annexure II computes correct FY totals for 10 employees', () => {
    const deductees = EMPLOYEES_10.map(e => ({
      ...e,
      grossSalary: 10_95_000,
      totalTdsDeducted: 90_000,
      taxableIncome: 9_50_000,
      totalTaxLiability: 90_000,
      netTaxPayable: 90_000,
    }));
    const ann = assembleAnnexureII({
      financialYear: '2024-25', deductor: DEDUCTOR,
      allQuarterChallans: ['Q1','Q2','Q3','Q4'].map((q, i) =>
        makeChallan({ id: `c-${i}`, quarter: q as Quarter, totalAmountDeposited: 90_000 * 10 })
      ),
      deductees,
    });
    expect(ann.totals.totalEmployees).toBe(10);
    expect(ann.totals.totalGrossSalaryFY).toBe(10_95_000 * 10);
    expect(ann.totals.totalTdsDeductedFY).toBe(90_000 * 10);
  });

  test('A07 — Annexure II quarter is always Q4', () => {
    const ann = assembleAnnexureII({
      financialYear: '2024-25', deductor: DEDUCTOR,
      allQuarterChallans: [makeChallan()],
      deductees: [makeEmployee()],
    });
    expect(ann.quarter).toBe('Q4');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 5. FULL 24Q ASSEMBLY
// ─────────────────────────────────────────────────────────────────────────────

describe('Full 24Q Return Assembly', () => {

  test('F01 — assemble24QReturn produces ID with quarter and FY', () => {
    const ret = assemble24QReturn(
      'tenant-abc', 'Q1', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500 })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    expect(ret.id).toContain('Q1');
    expect(ret.id).toContain('202425');
    expect(ret.financialYear).toBe('2024-25');
    expect(ret.assessmentYear).toBe('2025-26');
  });

  test('F02 — assemble24QReturn includes validation errors for mismatch', () => {
    const ret = assemble24QReturn(
      'tenant-abc', 'Q2', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 5000, quarter: 'Q2' })], // Too low
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    const hasError = ret.validationErrors.some(e => e.code === 'CHALLAN_TDS_MISMATCH');
    expect(hasError).toBe(true);
  });

  test('F03 — Q4 return includes Annexure II', () => {
    const fyDeductees = [makeEmployee({ grossSalary: 10_95_000, totalTdsDeducted: 90_000, netTaxPayable: 90_000 })];
    const ret = assemble24QReturn(
      'tenant-abc', 'Q4', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500, quarter: 'Q4' })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
      [makeChallan({ totalAmountDeposited: 90_000 })],
      fyDeductees,
    );
    expect(ret.annexureII).toBeDefined();
    expect(ret.annexureII?.quarter).toBe('Q4');
  });

  test('F04 — Checksum is deterministic for same input', () => {
    const make = () => assemble24QReturn(
      'tenant-xyz', 'Q1', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500 })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    expect(make().checksumHash).toBe(make().checksumHash);
  });

  test('F05 — isReturnFiled: filed and reconciled return true', () => {
    expect(isReturnFiled('filed')).toBe(true);
    expect(isReturnFiled('reconciled')).toBe(true);
    expect(isReturnFiled('draft')).toBe(false);
    expect(isReturnFiled('validated')).toBe(false);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 6. FVU EXPORT
// ─────────────────────────────────────────────────────────────────────────────

describe('FVU Export', () => {

  test('E01 — FVU export starts with FH record', () => {
    const ret = assemble24QReturn(
      'tenant-abc', 'Q1', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500 })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    const fvu = generateFVUExport(ret);
    expect(fvu.split('\r\n')[0]).toMatch(/^FH\|/);
  });

  test('E02 — FVU export contains BH (batch header) for challan', () => {
    const ret = assemble24QReturn(
      'tenant-abc', 'Q1', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500 })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    const fvu = generateFVUExport(ret);
    expect(fvu).toContain('BH|');
  });

  test('E03 — FVU export contains DD (deductee detail) per employee', () => {
    const ret = assemble24QReturn(
      'tenant-abc', 'Q1', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500 })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    const fvu = generateFVUExport(ret);
    expect(fvu).toContain('DD|');
  });

  test('E04 — FVU export ends with FT record', () => {
    const ret = assemble24QReturn(
      'tenant-abc', 'Q1', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500 })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    const fvu = generateFVUExport(ret);
    const lines = fvu.split('\r\n').filter(Boolean);
    expect(lines[lines.length - 1]).toMatch(/^FT\|/);
  });

  test('E05 — FVU export contains EXPORT ONLY disclaimer', () => {
    const ret = assemble24QReturn(
      'tenant-abc', 'Q1', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500 })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    const fvu = generateFVUExport(ret);
    expect(fvu).toContain('EXPORT ONLY');
  });

  test('E06 — FVU export uses Windows CRLF line endings', () => {
    const ret = assemble24QReturn(
      'tenant-abc', 'Q1', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500 })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    const fvu = generateFVUExport(ret);
    expect(fvu).toContain('\r\n');
  });

  test('E07 — FVU export contains employer TAN', () => {
    const ret = assemble24QReturn(
      'tenant-abc', 'Q1', '2024-25', DEDUCTOR,
      [makeChallan({ totalAmountDeposited: 22500 })],
      [makeEmployee({ tdsDeductedThisQuarter: 22500 })],
    );
    const fvu = generateFVUExport(ret);
    expect(fvu).toContain('BLRR01234A');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 7. TRACES CSV PARSER
// ─────────────────────────────────────────────────────────────────────────────

describe('TRACES CSV Parser', () => {

  test('T01 — Valid CSV parses correctly', () => {
    const csv = `PAN,Employee Name,BSR Code,Challan Date,Challan Serial,TDS Deposited,Section
ABCPK1234F,Ramesh Kumar,1234567,01/07/2024,00001,22500,192
XYZAB5678G,Sunita Rao,1234567,01/07/2024,00001,15000,192`;
    const { records, errors } = parseTracesCsv(csv);
    expect(records).toHaveLength(2);
    expect(errors).toHaveLength(0);
    expect(records[0]!.pan).toBe('ABCPK1234F');
    expect(records[0]!.tdsDeposited).toBe(22500);
  });

  test('T02 — Invalid PAN rows are skipped with error', () => {
    const csv = `PAN,Employee Name,BSR Code,Challan Date,Challan Serial,TDS Deposited,Section
BADPAN,Bad Employee,1234567,01/07/2024,00001,5000,192
ABCPK1234F,Good Employee,1234567,01/07/2024,00001,10000,192`;
    const { records, errors } = parseTracesCsv(csv);
    expect(records).toHaveLength(1);
    expect(errors).toHaveLength(1);
  });

  test('T03 — Empty CSV returns error', () => {
    const { records, errors } = parseTracesCsv('');
    expect(records).toHaveLength(0);
    expect(errors.length).toBeGreaterThan(0);
  });

  test('T04 — Insufficient columns skipped with error', () => {
    const csv = `PAN,Employee Name,BSR Code
ABCPK1234F,Ramesh Kumar`;
    const { records, errors } = parseTracesCsv(csv);
    expect(records).toHaveLength(0);
    expect(errors.length).toBeGreaterThan(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 8. RECONCILIATION ENGINE
// ─────────────────────────────────────────────────────────────────────────────

describe('Reconciliation Engine', () => {

  test('R01 — Perfect match → isReconciled = true', () => {
    const internal = [{ pan: 'ABCPK1234F', totalTdsDeducted: 22500 }];
    const traces = [{ pan: 'ABCPK1234F', employeeName: 'Ramesh', bsrCode: '1234567',
      challanDate: '01/07/2024', challanSerialNumber: '00001', tdsDeposited: 22500, section: '192' }];
    const result = reconcileWithTraces(internal, traces, [makeChallan({ totalAmountDeposited: 22500 })]);
    expect(result.isReconciled).toBe(true);
    expect(result.mismatchedEmployees).toHaveLength(0);
    expect(result.variance).toBe(0);
  });

  test('R02 — TDS mismatch per employee → flagged', () => {
    const internal = [{ pan: 'ABCPK1234F', totalTdsDeducted: 22500 }];
    const traces = [{ pan: 'ABCPK1234F', employeeName: 'Ramesh', bsrCode: '1234567',
      challanDate: '01/07/2024', challanSerialNumber: '00001', tdsDeposited: 20000, section: '192' }]; // diff 2500
    const result = reconcileWithTraces(internal, traces, [makeChallan({ totalAmountDeposited: 22500 })]);
    expect(result.isReconciled).toBe(false);
    expect(result.mismatchedEmployees).toHaveLength(1);
    expect(result.mismatchedEmployees[0]!.difference).toBe(2500);
  });

  test('R03 — Employee in internal but not TRACES → unmatchedInInternal', () => {
    const internal = [{ pan: 'ABCPK1234F', totalTdsDeducted: 5000 }];
    const traces: any[] = [];
    const result = reconcileWithTraces(internal, traces, []);
    expect(result.unmatchedInInternal).toContain('ABCPK1234F');
    expect(result.isReconciled).toBe(false);
  });

  test('R04 — Employee in TRACES but not internal → unmatchedInTraces', () => {
    const internal: any[] = [];
    const traces = [{ pan: 'XYZAB5678G', employeeName: 'Unknown', bsrCode: '1234567',
      challanDate: '01/07/2024', challanSerialNumber: '00001', tdsDeposited: 10000, section: '192' }];
    const result = reconcileWithTraces(internal, traces, []);
    expect(result.unmatchedInTraces).toContain('XYZAB5678G');
  });

  test('R05 — APPLIED PAN is excluded from reconciliation', () => {
    const internal = [{ pan: 'APPLIED', totalTdsDeducted: 5000 }];
    const traces: any[] = [];
    const result = reconcileWithTraces(internal, traces, []);
    // APPLIED should not be in unmatchedInInternal since we skip it
    expect(result.unmatchedInInternal).not.toContain('APPLIED');
  });

  test('R06 — High volume: 1000 employees reconcile correctly', () => {
    const internal = Array.from({ length: 1000 }, (_, i) => ({
      pan: `ABCDE${String(i).padStart(4, '0')}F`,
      totalTdsDeducted: 5000,
    }));
    const traces = internal.map(e => ({
      pan: e.pan, employeeName: 'Employee', bsrCode: '1234567',
      challanDate: '01/07/2024', challanSerialNumber: '00001', tdsDeposited: 5000, section: '192',
    }));
    const result = reconcileWithTraces(internal, traces, []);
    expect(result.isReconciled).toBe(true);
    expect(result.matchedEmployees).toBe(1000);
    expect(result.mismatchedEmployees).toHaveLength(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 9. DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────

describe('Quarter Dashboard', () => {

  test('D01 — Status is not_started when no return', () => {
    const entry = buildQuarterDashboard('Q1', '2024-25', null, [], null);
    expect(entry.status).toBe('not_started');
    expect(entry.form16Ready).toBe(false);
  });

  test('D02 — Status is mismatch when variance > ₹1 and draft', () => {
    const payslips = { employeeCount: 5, grossSalary: 400000, tdsDeducted: 22500 };
    const challans = [makeChallan({ totalAmountDeposited: 10000 })]; // Mismatch 12500
    const entry = buildQuarterDashboard('Q1', '2024-25', payslips, challans, { status: 'draft' });
    expect(entry.status).toBe('mismatch');
  });

  test('D03 — form16Ready is true only when tracesReconciled', () => {
    const entry = buildQuarterDashboard('Q1', '2024-25', null, [], { status: 'reconciled', tracesReconciled: true });
    expect(entry.form16Ready).toBe(true);
    expect(entry.tracesReconciled).toBe(true);
  });

  test('D04 — Due dates are present', () => {
    const entry = buildQuarterDashboard('Q1', '2024-25', null, [], null);
    expect(entry.dueDate).toBe('31 July');
  });
});
