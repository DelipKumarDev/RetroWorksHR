/**
 * TDS Returns Service — 24Q return lifecycle
 * AUDIT-PAYROLL-2: Refactored — zero raw PrismaClient.
 *
 * GLOBAL via $global:
 *   tenant (no tenantId col)
 *   tdsReturnEmployeeEntry — join table (no tenantId col, scoped via returnId)
 *
 * upsert → findFirst+create/update:
 *   tdsReturn: compound key tenantId_financialYear_quarter unsafe with proxy
 */
import {
  Injectable, Logger, NotFoundException,
  BadRequestException, ConflictException,
} from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import {
  assemble24QReturn, validateReturn, generateFVUExport,
  buildQuarterDashboard, QUARTERS,
  type Quarter, type Return24Q, type DeductorInfo,
  type ChallanRecord, type EmployeeDeducteeRecord,
} from './return.engine';
import { ChallanService } from './challan.service';

const RETURN_TEMPLATE_VERSION = '24Q-2024-v1';

@Injectable()
export class TdsReturnService {
  private readonly logger = new Logger(TdsReturnService.name);

  constructor(
    private readonly db: PrismaTenantService,
    private readonly events: EventEmitter2,
    private readonly challanService: ChallanService,
  ) {}

  private async getDeductorInfo(tenantId: string): Promise<DeductorInfo> {
    const scope = this.db.forTenant(tenantId);
    const tenant = await scope.$global.tenant.findFirst({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Tenant not found');
    const s = (tenant.settings as any) ?? {};
    const f16 = (tenant as any).form16_config ?? s;
    return {
      tan: f16.tan ?? s.tan ?? 'XXXX00000X',
      pan: f16.pan ?? s.pan ?? 'XXXXX0000X',
      name: tenant.name,
      address: f16.address ?? s.address ?? '',
      city: f16.city ?? s.city ?? '',
      state: f16.state ?? s.state ?? '',
      pincode: f16.pincode ?? s.pincode ?? '',
      phone: f16.phone ?? s.phone ?? '',
      email: f16.email ?? s.email ?? '',
      responsiblePersonName: f16.signatoryName ?? s.signatoryName ?? '',
      responsiblePersonPan:  f16.responsiblePersonPan ?? 'XXXXX0000X',
      responsiblePersonDesignation: f16.signatoryDesignation ?? '',
      deductorType: 'Company',
    };
  }

  private async getQuarterPayslips(
    tenantId: string, financialYear: string, quarter: Quarter,
  ): Promise<{ deductees: EmployeeDeducteeRecord[]; totals: { employeeCount: number; grossSalary: number; tdsDeducted: number } }> {
    const scope = this.db.forTenant(tenantId);
    const fyStart = parseInt(financialYear.split('-')[0]!, 10);
    const monthMap: Record<Quarter, { months: number[]; year: number }> = {
      Q1: { months: [4,5,6],    year: fyStart     },
      Q2: { months: [7,8,9],    year: fyStart     },
      Q3: { months: [10,11,12], year: fyStart     },
      Q4: { months: [1,2,3],    year: fyStart + 1 },
    };
    const { months, year } = monthMap[quarter];

    const payslips = await scope.payslip.findMany({
      where: { status: { not: 'cancelled' }, month: { in: months }, year },
      include: { employee: { select: { id: true, firstName: true, lastName: true } } },
    });

    const empMap = new Map<string, { name:string; pan:string; grossPay:number; tdsDeducted:number; pfEmployee:number; professionalTax:number }>();
    for (const p of payslips as any[]) {
      const e = empMap.get(p.employeeId) ?? {
        name: `${p.employee.firstName} ${p.employee.lastName}`,
        pan: p.employee.pan ?? 'APPLIED',
        grossPay: 0, tdsDeducted: 0, pfEmployee: 0, professionalTax: 0,
      };
      e.grossPay     += Number(p.grossPay);
      e.tdsDeducted  += Number(p.tdsDeducted ?? 0);
      e.pfEmployee   += Number(p.pfEmployee ?? 0);
      e.professionalTax += Number(p.professionalTax ?? 0);
      empMap.set(p.employeeId, e);
    }

    const deductees: EmployeeDeducteeRecord[] = [...empMap.entries()].map(([empId, d]) => ({
      employeeId: empId, name: d.name, pan: d.pan, category: 'Resident' as const,
      grossSalary: d.grossPay, hraExemption: 0, ltaExemption: 0, otherSection10Exemptions: 0,
      standardDeduction: 75000, professionalTax: d.professionalTax, totalDeductionsChapterVIA: 0,
      taxableIncome: d.grossPay, taxOnIncome: d.tdsDeducted, surcharge: 0, educationCess: 0,
      totalTaxLiability: d.tdsDeducted, reliefUnder89: 0, netTaxPayable: d.tdsDeducted,
      totalTdsDeducted: d.tdsDeducted, tdsDeductedThisQuarter: d.tdsDeducted, regimeType: 'new',
      quarterlyGrossSalary: d.grossPay, quarterlyTds: d.tdsDeducted,
    }));

    return {
      deductees,
      totals: {
        employeeCount: empMap.size,
        grossSalary:   [...empMap.values()].reduce((s,e) => s+e.grossPay, 0),
        tdsDeducted:   [...empMap.values()].reduce((s,e) => s+e.tdsDeducted, 0),
      },
    };
  }

  async generate24QReturn(
    tenantId: string, financialYear: string, quarter: Quarter, generatedBy: string,
  ): Promise<{ returnRecord: any; returnData: Return24Q; validationSummary: any }> {
    const scope = this.db.forTenant(tenantId);

    const existing = await scope.tdsReturn.findFirst({ where: { financialYear, quarter } });
    if (existing && ['filed','reconciled'].includes((existing as any).status)) {
      throw new ConflictException(`24Q ${quarter} ${financialYear} is already ${(existing as any).status}.`);
    }

    const [deductor, { deductees, totals }, challans] = await Promise.all([
      this.getDeductorInfo(tenantId),
      this.getQuarterPayslips(tenantId, financialYear, quarter),
      this.challanService.getChallans(tenantId, financialYear, quarter),
    ]);

    let allFyChallans: ChallanRecord[] | undefined;
    let allFyDeductees: EmployeeDeducteeRecord[] | undefined;
    if (quarter === 'Q4') {
      const [fyChallansRaw, q4Full] = await Promise.all([
        this.challanService.getChallans(tenantId, financialYear),
        this.getFullFyDeductees(tenantId, financialYear),
      ]);
      allFyChallans  = (fyChallansRaw as any[]).map(c => this._mapChallan(c));
      allFyDeductees = q4Full;
    }

    const challanRecords = (challans as any[]).map(c => this._mapChallan(c));
    const returnData = assemble24QReturn(
      tenantId, quarter, financialYear, deductor, challanRecords, deductees,
      allFyChallans, allFyDeductees,
    );

    const totalDeducted  = totals.tdsDeducted;
    const totalDeposited = (challans as any[]).reduce((s, c) => s + Number(c.totalAmountDeposited), 0);

    const retData = {
      financialYear, quarter,
      assessmentYear:    returnData.assessmentYear,
      totalTaxDeducted:  totalDeducted,
      totalTaxDeposited: totalDeposited,
      totalEmployees:    totals.employeeCount,
      challanLinked:     (challans as any[]).length > 0,
      status:            'draft',
      checksumHash:      returnData.checksumHash,
      templateVersion:   RETURN_TEMPLATE_VERSION,
      returnData:        returnData as any,
      generatedBy,       generatedAt: new Date(),
    };

    // findFirst + create/update — proxy-safe
    let returnRecord: any;
    if (existing) {
      returnRecord = await scope.tdsReturn.update({
        where: { id: (existing as any).id },
        data: { ...retData, updatedAt: new Date() },
      });
    } else {
      returnRecord = await scope.tdsReturn.create({
        data: { ...retData, createdAt: new Date() },
      });
    }

    // tdsReturnEmployeeEntry — join table, no tenantId col → $global
    await scope.$global.tdsReturnEmployeeEntry.deleteMany({ where: { returnId: returnRecord.id } });
    if (deductees.length > 0) {
      await scope.$global.tdsReturnEmployeeEntry.createMany({
        data: deductees.map(d => ({
          returnId: returnRecord.id, employeeId: d.employeeId, pan: d.pan,
          totalSalaryPaid: d.quarterlyGrossSalary, totalTdsDeducted: d.quarterlyTds,
          sectionCode: '192', createdAt: new Date(),
        })),
      });
    }

    await this._auditLog(scope, tenantId, financialYear, quarter, 'GENERATED', generatedBy,
      `Return generated. ${totals.employeeCount} employees, TDS ₹${totalDeducted.toLocaleString('en-IN')}`);

    const blockingErrors = returnData.validationErrors.filter(e => (e as any).severity === 'blocking');
    this.logger.log(`24Q generated: ${quarter} ${financialYear} for ${tenantId}`);

    return { returnRecord, returnData, validationSummary: { isValid: blockingErrors.length === 0, blockingErrors, warnings: returnData.warnings } };
  }

  async validateReturn(tenantId: string, financialYear: string, quarter: Quarter) {
    const scope = this.db.forTenant(tenantId);
    const rec = await this._getReturn(scope, tenantId, financialYear, quarter);
    await scope.tdsReturn.update({ where: { id: rec.id }, data: { status: 'validated', updatedAt: new Date() } });
    await this._auditLog(scope, tenantId, financialYear, quarter, 'VALIDATED', 'system', 'Return validated');
    return { status: 'validated', returnData: rec.returnData };
  }

  async markFiled(
    tenantId: string, financialYear: string, quarter: Quarter,
    filedBy: string, acknowledgementNumber?: string,
  ) {
    const scope = this.db.forTenant(tenantId);
    const rec = await this._getReturn(scope, tenantId, financialYear, quarter);
    if (!(rec as any).challanLinked) throw new BadRequestException('No challans linked to this return.');
    if (['filed','reconciled'].includes((rec as any).status)) throw new ConflictException('Return already filed.');

    await scope.tdsReturn.update({
      where: { id: rec.id },
      data: { status: 'filed', filedAt: new Date(), filedBy, acknowledgementNumber: acknowledgementNumber ?? null, updatedAt: new Date() },
    });

    const challans = await this.challanService.getChallans(tenantId, financialYear, quarter);
    await this.challanService.markChallansLinked(tenantId, (challans as any[]).map(c => c.id));

    await this._auditLog(scope, tenantId, financialYear, quarter, 'FILED', filedBy, `Return filed. Ack: ${acknowledgementNumber ?? 'N/A'}`);
    this.logger.log(`24Q filed: ${quarter} ${financialYear} by ${filedBy}`);
    this.events.emit('tds-return.filed', { tenantId, financialYear, quarter });
  }

  async exportFVU(tenantId: string, financialYear: string, quarter: Quarter): Promise<string> {
    const scope = this.db.forTenant(tenantId);
    const rec = await this._getReturn(scope, tenantId, financialYear, quarter);
    if (!(rec as any).challanLinked) throw new BadRequestException('No challans linked — cannot export FVU.');
    const fvuContent = generateFVUExport(rec.returnData as unknown as Return24Q);
    await this._auditLog(scope, tenantId, financialYear, quarter, 'FVU_EXPORTED', tenantId, 'FVU exported');
    return fvuContent;
  }

  async getDashboard(tenantId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);
    const [returns, allChallans] = await Promise.all([
      scope.tdsReturn.findMany({ where: { financialYear } }),
      this.challanService.getChallans(tenantId, financialYear),
    ]);

    const returnMap = new Map((returns as any[]).map(r => [r.quarter, r]));

    const quarters = await Promise.all(QUARTERS.map(async quarter => {
      const { totals } = await this.getQuarterPayslips(tenantId, financialYear, quarter).catch(() => ({
        totals: { employeeCount: 0, grossSalary: 0, tdsDeducted: 0 },
      }));
      const qChallans = (allChallans as any[]).filter(c => c.quarter === quarter).map(c => ({
        id: c.id, bsrCode: c.bsrCode, challanSerialNumber: c.challanSerialNumber,
        challanDate: c.challanDate, totalAmountDeposited: Number(c.totalAmountDeposited),
        tdsAmount: Number(c.tdsAmount ?? 0), surchargeAmount: 0, educationCessAmount: 0,
        interestAmount: 0, penaltyAmount: 0, otherAmount: 0,
        bankName: c.bankName, section: '192', quarter: c.quarter, financialYear,
        isLinkedToReturn: c.isLinkedToReturn,
      }));
      const ret = returnMap.get(quarter);
      return buildQuarterDashboard(
        quarter, financialYear,
        totals.employeeCount > 0 ? totals : null,
        qChallans,
        ret ? { status: (ret as any).status, tracesReconciled: (ret as any).tracesReconciled ?? false } : null,
      );
    }));

    const totalTdsDeducted     = quarters.reduce((s, q) => s + q.totalTdsDeducted, 0);
    const totalChallanDeposited = quarters.reduce((s, q) => s + q.totalChallanDeposited, 0);
    return {
      financialYear, quarters,
      summary: {
        totalTdsDeducted, totalChallanDeposited,
        totalVariance:          Math.abs(totalTdsDeducted - totalChallanDeposited),
        allChallansLinked:      quarters.every(q => q.challanLinked),
        allQuartersFiled:       quarters.every(q => ['filed','reconciled'].includes(q.status as string)),
        allTracesReconciled:    quarters.every(q => q.tracesReconciled),
        form16ReadyForIssuance: quarters.every(q => q.tracesReconciled),
      },
      disclaimer: '⚠️ RetroWorks exports data — it does NOT directly file with Income Tax Department.',
    };
  }

  async getFullFyDeductees(tenantId: string, financialYear: string): Promise<EmployeeDeducteeRecord[]> {
    const scope = this.db.forTenant(tenantId);
    const fyStart = parseInt(financialYear.split('-')[0]!, 10);
    const [payslips, projections] = await Promise.all([
      scope.payslip.findMany({
        where: {
          status: { not: 'cancelled' },
          OR: [{ year: fyStart, month: { gte: 4 } }, { year: fyStart + 1, month: { lte: 3 } }],
        },
        include: { employee: { select: { id: true, firstName: true, lastName: true } } },
      }),
      scope.tDSProjection.findMany({ where: { financialYear } }),
    ]);

    const projMap = new Map((projections as any[]).map(p => [p.employeeId, p]));
    const empMap = new Map<string, any>();
    for (const p of payslips as any[]) {
      const e = empMap.get(p.employeeId) ?? { name: `${p.employee.firstName} ${p.employee.lastName}`, pan: p.employee.pan ?? 'APPLIED', grossPay: 0, tdsDeducted: 0 };
      e.grossPay    += Number(p.grossPay);
      e.tdsDeducted += Number(p.tdsDeducted ?? 0);
      empMap.set(p.employeeId, e);
    }

    return [...empMap.entries()].map(([empId, data]) => {
      const proj = projMap.get(empId);
      const bd = (proj?.calculationBreakdown as any) ?? {};
      return {
        employeeId: empId, name: data.name, pan: data.pan, category: 'Resident' as const,
        grossSalary: data.grossPay, hraExemption: bd.hraExemption ?? 0,
        ltaExemption: bd.ltaExemption ?? 0, otherSection10Exemptions: 0,
        standardDeduction: bd.standardDeduction ?? 75000, professionalTax: bd.professionalTax ?? 0,
        totalDeductionsChapterVIA: bd.totalDeductionsChapterVIA ?? 0,
        taxableIncome: proj ? Number(proj.taxableIncome ?? 0) : data.grossPay,
        taxOnIncome: Number(proj?.totalTaxLiability ?? data.tdsDeducted),
        surcharge: Number(proj?.surchargeAmount ?? 0), educationCess: Number(proj?.totalCess ?? 0),
        totalTaxLiability: Number(proj?.totalTaxLiability ?? data.tdsDeducted),
        reliefUnder89: 0, netTaxPayable: Number(proj?.totalTaxLiability ?? data.tdsDeducted),
        totalTdsDeducted: data.tdsDeducted, tdsDeductedThisQuarter: data.tdsDeducted,
        regimeType: (proj?.regimeType ?? 'new') as 'old' | 'new',
        quarterlyGrossSalary: data.grossPay, quarterlyTds: data.tdsDeducted,
      };
    });
  }

  async getReturn(tenantId: string, financialYear: string, quarter: Quarter) {
    const scope = this.db.forTenant(tenantId);
    return this._getReturn(scope, tenantId, financialYear, quarter);
  }

  async getAuditLog(tenantId: string, financialYear: string, quarter?: Quarter) {
    return this.db.forTenant(tenantId).tdsReturnAuditLog.findMany({
      where: { financialYear, ...(quarter ? { quarter } : {}) },
      orderBy: { createdAt: 'desc' },
    });
  }

  private async _auditLog(
    scope: ReturnType<PrismaTenantService['forTenant']>,
    tenantId: string, financialYear: string, quarter: string,
    action: string, performedBy: string, notes: string,
  ) {
    await scope.tdsReturnAuditLog.create({
      data: { financialYear, quarter, action, performedBy, notes, createdAt: new Date() },
    });
  }

  private async _getReturn(
    scope: ReturnType<PrismaTenantService['forTenant']>,
    tenantId: string, financialYear: string, quarter: Quarter,
  ) {
    const rec = await scope.tdsReturn.findFirst({ where: { financialYear, quarter } });
    if (!rec) throw new NotFoundException(`24Q ${quarter} ${financialYear} not found. Generate first.`);
    return rec;
  }

  private _mapChallan(c: any): ChallanRecord {
    return {
      id: c.id, bsrCode: c.bsrCode, challanSerialNumber: c.challanSerialNumber,
      challanDate: c.challanDate, totalAmountDeposited: Number(c.totalAmountDeposited),
      tdsAmount: Number(c.tdsAmount ?? 0), surchargeAmount: Number(c.surchargeAmount ?? 0),
      educationCessAmount: Number(c.educationCessAmount ?? 0), interestAmount: Number(c.interestAmount ?? 0),
      penaltyAmount: Number(c.penaltyAmount ?? 0), otherAmount: 0,
      bankName: c.bankName, section: '192', quarter: c.quarter, financialYear: c.financialYear,
      isLinkedToReturn: c.isLinkedToReturn,
    };
  }
}
