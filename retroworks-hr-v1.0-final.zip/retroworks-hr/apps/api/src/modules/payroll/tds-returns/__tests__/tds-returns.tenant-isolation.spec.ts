/**
 * TDS Returns — Tenant Isolation Integration Tests
 * ══════════════════════════════════════════════════════════════════════════════
 * Covers: TdsReturnService, ChallanService, TracesService
 *
 * Attack scenarios:
 *   CT-RET-01   Cross-tenant 24Q return READ → null
 *   CT-RET-02   Cross-tenant 24Q return CREATE → stamped with actor tenantId
 *   CT-RET-03   Cross-tenant return status UPDATE → NotFoundException (wrong tenant)
 *   CT-RET-04   Cross-tenant return data mutation blocked by proxy
 *
 *   CT-CHAL-05  Cross-tenant challan READ → null
 *   CT-CHAL-06  Cross-tenant challan CREATE → stamped with actor tenantId
 *   CT-CHAL-07  Cross-tenant challan UPDATE → ForbiddenException
 *   CT-CHAL-08  Cross-tenant challan DELETE → cannot find → NotFoundException
 *   CT-CHAL-09  markChallansLinked: proxy scopes updateMany to actor tenant
 *
 *   CT-TRACES-10 Cross-tenant TRACES import log READ → null
 *   CT-TRACES-11 TRACES import → log stamped with actor tenantId
 *   CT-TRACES-12 TRACES reconciliation updates only actor tenant's tdsReturn
 *   CT-TRACES-13 populateForm16PartAChallanData: only actor tenant's form16 records updated
 *
 *   CT-RET-14   Empty tenantId → ForbiddenException
 *
 * Run: npx jest tds-returns.tenant-isolation --verbose --forceExit
 */

import { ForbiddenException, NotFoundException, ConflictException, BadRequestException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { TdsReturnService } from '../tds-returns.service';
import { ChallanService, CreateChallanDto } from '../challan.service';
import { TracesService } from '../traces.service';
import { PrismaTenantService } from '../../../../common/security/prisma-tenant.service';

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const TENANT_A = 'tenant-alpha-ret-001';
const TENANT_B = 'tenant-beta-ret-002';
const FY       = '2024-25';
const QUARTER  = 'Q1' as const;
const EMP_A1   = 'emp-alpha-ret-001';
const EMP_B1   = 'emp-beta-ret-001';

// ─── In-memory DB ─────────────────────────────────────────────────────────────

interface ReturnDb {
  tdsReturn:             Record<string, any[]>;
  tdsReturnAuditLog:     Record<string, any[]>;
  tdsChallan:            Record<string, any[]>;
  tracesImportLog:       Record<string, any[]>;
  form16Record:          Record<string, any[]>;
  payslip:               Record<string, any[]>;
  tDSProjection:         Record<string, any[]>;
  tdsReturnEmployeeEntry:any[];   // join table, no tenantId
}

function makeDb(): ReturnDb {
  return {
    tdsReturn: {
      [TENANT_A]: [{ id: 'ret-a1', tenantId: TENANT_A, financialYear: FY, quarter: QUARTER, status: 'draft', totalTaxDeducted: 200000, totalTaxDeposited: 200000, totalEmployees: 5, challanLinked: false, returnData: {} }],
      [TENANT_B]: [],
    },
    tdsReturnAuditLog: {
      [TENANT_A]: [],
      [TENANT_B]: [],
    },
    tdsChallan: {
      [TENANT_A]: [{ id: 'chal-a1', tenantId: TENANT_A, financialYear: FY, quarter: QUARTER, bsrCode: '1234567', challanSerialNumber: '00001', challanDate: '01/04/2024', totalAmountDeposited: 200000, tdsAmount: 200000, bankName: 'SBI', cin: '123456701042024000010001', isLinkedToReturn: false }],
      [TENANT_B]: [],
    },
    tracesImportLog: {
      [TENANT_A]: [],
      [TENANT_B]: [],
    },
    form16Record: {
      [TENANT_A]: [{ id: 'f16-a1', tenantId: TENANT_A, financialYear: FY, employeeId: EMP_A1, isLocked: false, documentData: { partA: { quarterlyTds: [{ quarter: QUARTER }] } } }],
      [TENANT_B]: [],
    },
    payslip: {
      [TENANT_A]: [{ id: 'slip-a1', tenantId: TENANT_A, employeeId: EMP_A1, year: 2024, month: 4, status: 'finalized', grossPay: 100000, tdsDeducted: 8000, employee: { id: EMP_A1, firstName: 'Arjun', lastName: 'Mehta', pan: 'ABCPM1234A' } }],
      [TENANT_B]: [{ id: 'slip-b1', tenantId: TENANT_B, employeeId: EMP_B1, year: 2024, month: 4, status: 'finalized', grossPay: 90000, tdsDeducted: 7000, employee: { id: EMP_B1, firstName: 'Bhavna', lastName: 'Shah', pan: 'XYZBS9876B' } }],
    },
    tDSProjection: {
      [TENANT_A]: [],
      [TENANT_B]: [],
    },
    tdsReturnEmployeeEntry: [],
  };
}

function makeScopedModel(db: ReturnDb, modelKey: keyof Omit<ReturnDb, 'tdsReturnEmployeeEntry'>, tenantId: string) {
  const rows = () => ((db[modelKey] as Record<string, any[]>)[tenantId] ?? []) as any[];
  return {
    findFirst: jest.fn((args?: { where?: any; orderBy?: any }) => {
      const match = rows().find(r => {
        if (!args?.where) return true;
        return Object.entries(args.where).every(([k, v]) => {
          if (typeof v === 'object' && v !== null && 'not' in v) return r[k] !== (v as any).not;
          return r[k] === v;
        });
      });
      return Promise.resolve(match ?? null);
    }),
    findMany: jest.fn((args?: { where?: any; orderBy?: any; include?: any; select?: any }) => {
      const results = rows().filter(r => {
        if (!args?.where) return true;
        return Object.entries(args.where).every(([k, v]) => {
          if (typeof v === 'object' && v !== null && 'not' in v) return r[k] !== (v as any).not;
          if (typeof v === 'object' && v !== null && 'in' in v) return (v as any).in.includes(r[k]);
          if (k === 'OR' && Array.isArray(v)) return true; // simplification
          return r[k] === v;
        });
      });
      return Promise.resolve(results);
    }),
    create: jest.fn((args: { data: any }) => {
      if (args.data.tenantId && args.data.tenantId !== tenantId) {
        return Promise.reject(new ForbiddenException('Cross-tenant create blocked'));
      }
      const record = { id: `new-${modelKey}-${Date.now()}-${Math.random()}`, ...args.data, tenantId };
      const slice = (db[modelKey] as Record<string, any[]>);
      (slice[tenantId] = slice[tenantId] ?? []).push(record);
      return Promise.resolve(record);
    }),
    update: jest.fn((args: { where: any; data: any }) => {
      if (args.data?.tenantId && args.data.tenantId !== tenantId) {
        return Promise.reject(new ForbiddenException('Cannot modify tenantId'));
      }
      const slice = ((db[modelKey] as Record<string, any[]>)[tenantId] ?? []);
      const idx = slice.findIndex((r: any) => r.id === args.where.id);
      if (idx === -1) return Promise.resolve(null);
      const updated = { ...slice[idx], ...args.data };
      slice[idx] = updated;
      return Promise.resolve(updated);
    }),
    updateMany: jest.fn((args?: { where?: any; data?: any }) => {
      if (args?.data?.tenantId && args.data.tenantId !== tenantId) {
        return Promise.reject(new ForbiddenException('Cannot modify tenantId'));
      }
      return Promise.resolve({ count: 0 });
    }),
    count: jest.fn(() => Promise.resolve(rows().length)),
    delete: jest.fn((args: { where: any }) => {
      const slice = (db[modelKey] as Record<string, any[]>)[tenantId] ?? [];
      const idx = slice.findIndex((r: any) => r.id === args.where.id);
      if (idx === -1) return Promise.resolve(null);
      slice.splice(idx, 1);
      return Promise.resolve({});
    }),
  };
}

function makeGlobalEntryModel(db: ReturnDb) {
  return {
    deleteMany: jest.fn(() => Promise.resolve({ count: 0 })),
    createMany: jest.fn((args: { data: any[] }) => {
      db.tdsReturnEmployeeEntry.push(...args.data);
      return Promise.resolve({ count: args.data.length });
    }),
  };
}

function makeMock(db: ReturnDb) {
  const svc = {
    forTenant: jest.fn((tenantId: string) => {
      if (!tenantId?.trim()) throw new ForbiddenException('Invalid tenant context');
      return {
        tdsReturn:         makeScopedModel(db, 'tdsReturn',         tenantId),
        tdsReturnAuditLog: makeScopedModel(db, 'tdsReturnAuditLog', tenantId),
        tdsChallan:        makeScopedModel(db, 'tdsChallan',        tenantId),
        tracesImportLog:   makeScopedModel(db, 'tracesImportLog',   tenantId),
        form16Record:      makeScopedModel(db, 'form16Record',      tenantId),
        payslip:           makeScopedModel(db, 'payslip',           tenantId),
        tDSProjection:     makeScopedModel(db, 'tDSProjection',     tenantId),
        employee:          {
          findMany: jest.fn(() => Promise.resolve([])),
        },
        $global: {
          tenant: { findFirst: jest.fn(({ where }: any) => Promise.resolve({ id: where.id, name: 'Corp', settings: {} })) },
          tdsReturnEmployeeEntry: makeGlobalEntryModel(db),
        },
      };
    }),
  } as unknown as PrismaTenantService;
  return svc;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('TDS Returns — Tenant Isolation', () => {
  let db: ReturnDb;
  let mockDb: PrismaTenantService;
  let returnSvc: TdsReturnService;
  let challanSvc: ChallanService;
  let tracesSvc: TracesService;
  let events: EventEmitter2;

  beforeEach(() => {
    db         = makeDb();
    mockDb     = makeMock(db);
    events     = { emit: jest.fn() } as unknown as EventEmitter2;
    challanSvc = new ChallanService(mockDb);
    returnSvc  = new TdsReturnService(mockDb, events, challanSvc);
    tracesSvc  = new TracesService(mockDb);
  });

  // ── CT-RET-01: Cross-tenant 24Q return READ ──────────────────────────────

  it('CT-RET-01 | tenant-B cannot read tenant-A 24Q return', async () => {
    await expect(returnSvc.getReturn(TENANT_B, FY, QUARTER)).rejects.toThrow(NotFoundException);
  });

  // ── CT-RET-02: Cross-tenant 24Q return CREATE ────────────────────────────

  it('CT-RET-02 | generate24QReturn stamps new return with actor tenantId', async () => {
    await returnSvc.generate24QReturn(TENANT_B, FY, QUARTER, 'hr-b');
    const created = db.tdsReturn[TENANT_B]?.find(r => r.quarter === QUARTER);
    expect(created).toBeDefined();
    expect(created?.tenantId).toBe(TENANT_B);
    // Tenant-A untouched
    expect(db.tdsReturn[TENANT_A]).toHaveLength(1);
    expect(db.tdsReturn[TENANT_A]![0]!.tenantId).toBe(TENANT_A);
  });

  // ── CT-RET-03: Cross-tenant return status UPDATE via markFiled ───────────

  it('CT-RET-03 | markFiled with tenant-A return under tenant-B → NotFoundException', async () => {
    await expect(returnSvc.markFiled(TENANT_B, FY, QUARTER, 'hr-b', 'ACK001'))
      .rejects.toThrow(NotFoundException);
  });

  // ── CT-RET-04: Proxy blocks foreign tenantId mutation ────────────────────

  it('CT-RET-04 | updating a return with foreign tenantId in data is rejected', async () => {
    const model = makeScopedModel(db, 'tdsReturn', TENANT_B);
    await expect(
      model.update({ where: { id: 'ret-a1' }, data: { tenantId: TENANT_A, status: 'filed' } })
    ).rejects.toThrow(ForbiddenException);
  });

  // ── CT-CHAL-05: Cross-tenant challan READ ───────────────────────────────

  it('CT-CHAL-05 | tenant-B cannot read tenant-A challans', async () => {
    const challans = await challanSvc.getChallans(TENANT_B, FY, QUARTER);
    expect(challans).toHaveLength(0);
  });

  // ── CT-CHAL-06: Cross-tenant challan CREATE ──────────────────────────────

  it('CT-CHAL-06 | createChallan stamps record with actor tenantId', async () => {
    const dto: CreateChallanDto = {
      financialYear: FY, quarter: QUARTER,
      bsrCode: '9876543', challanSerialNumber: '00001',
      challanDate: '01/04/2024', totalAmountDeposited: 100000,
      tdsAmount: 100000, bankName: 'HDFC',
    };
    await challanSvc.createChallan(TENANT_B, dto, 'hr-b');
    const created = db.tdsChallan[TENANT_B]?.find(r => r.bsrCode === '9876543');
    expect(created).toBeDefined();
    expect(created?.tenantId).toBe(TENANT_B);
    // Tenant-A challans untouched
    expect(db.tdsChallan[TENANT_A]).toHaveLength(1);
  });

  // ── CT-CHAL-07: Cross-tenant challan UPDATE ──────────────────────────────

  it('CT-CHAL-07 | proxy rejects challan update with foreign tenantId in data', async () => {
    const model = makeScopedModel(db, 'tdsChallan', TENANT_B);
    await expect(
      model.update({ where: { id: 'chal-a1' }, data: { tenantId: TENANT_A, isLinkedToReturn: true } })
    ).rejects.toThrow(ForbiddenException);
  });

  // ── CT-CHAL-08: Cross-tenant challan DELETE ──────────────────────────────

  it('CT-CHAL-08 | deleteChallan with tenant-A challan under tenant-B → NotFoundException', async () => {
    // getChallanById under TENANT_B scope → chal-a1 not visible → 404
    await expect(challanSvc.deleteChallan(TENANT_B, 'chal-a1', 'hr-b'))
      .rejects.toThrow(NotFoundException);
    // Verify tenant-A challan still exists
    expect(db.tdsChallan[TENANT_A]).toHaveLength(1);
  });

  // ── CT-CHAL-09: markChallansLinked scoped to actor tenant ────────────────

  it('CT-CHAL-09 | markChallansLinked under tenant-B cannot affect tenant-A challans', async () => {
    // Pass tenant-A's challan IDs — updateMany under tenant-B scope won't match
    await challanSvc.markChallansLinked(TENANT_B, ['chal-a1']);
    // Tenant-A's challan must remain un-linked
    expect(db.tdsChallan[TENANT_A]![0]!.isLinkedToReturn).toBe(false);
  });

  // ── CT-TRACES-10: Cross-tenant TRACES import log READ ────────────────────

  it('CT-TRACES-10 | tenant-B cannot read tenant-A TRACES import log', async () => {
    db.tracesImportLog[TENANT_A]!.push({ id: 'tl-a1', tenantId: TENANT_A, financialYear: FY, quarter: QUARTER, status: 'reconciled' });
    const log = await tracesSvc.getLatestReconciliation(TENANT_B, FY, QUARTER);
    expect(log).toBeNull();
  });

  // ── CT-TRACES-11: TRACES import stamps log with actor tenantId ───────────

  it('CT-TRACES-11 | importTracesFile stamps log with actor tenantId', async () => {
    const csv = tracesSvc.generateSampleTracesCsv([{ pan: 'XYZBS9876B', name: 'Bhavna Shah', tds: 7000 }]);
    await tracesSvc.importTracesFile(TENANT_B, FY, QUARTER, csv, 'hr-b');
    const log = db.tracesImportLog[TENANT_B]?.find(r => r.quarter === QUARTER);
    expect(log).toBeDefined();
    expect(log?.tenantId).toBe(TENANT_B);
    // Tenant-A log untouched
    expect(db.tracesImportLog[TENANT_A]).toHaveLength(0);
  });

  // ── CT-TRACES-12: TRACES reconciliation scoped to actor tenant ───────────

  it('CT-TRACES-12 | TRACES reconciliation updateMany scoped to actor tenant', async () => {
    // Tenant-A has a 'draft' return — tenant-B reconciliation should NOT touch it
    const csv = tracesSvc.generateSampleTracesCsv([{ pan: 'XYZBS9876B', name: 'Bhavna Shah', tds: 7000 }]);
    await tracesSvc.importTracesFile(TENANT_B, FY, QUARTER, csv, 'hr-b');
    // Tenant-A's return must still be 'draft'
    expect(db.tdsReturn[TENANT_A]![0]!.status).toBe('draft');
  });

  // ── CT-TRACES-13: populateForm16PartAChallanData scoped to actor ─────────

  it('CT-TRACES-13 | populateForm16PartAChallanData requires all quarters reconciled', async () => {
    // Only Q1 is reconciled for tenant-B (from CT-TRACES-11 seed won't carry over — fresh db)
    // Should throw BadRequestException (not all quarters reconciled)
    await expect(tracesSvc.populateForm16PartAChallanData(TENANT_B, FY))
      .rejects.toThrow(BadRequestException);
    // Tenant-A's form16 record untouched
    const f16 = db.form16Record[TENANT_A]![0]!;
    expect(f16.tenantId).toBe(TENANT_A);
  });

  // ── CT-RET-14: Empty tenantId ────────────────────────────────────────────

  it('CT-RET-14 | empty tenantId throws ForbiddenException for return service', async () => {
    await expect(returnSvc.getReturn('', FY, QUARTER)).rejects.toThrow(ForbiddenException);
    await expect(challanSvc.getChallans('', FY)).rejects.toThrow(ForbiddenException);
    await expect(tracesSvc.getAllImportLogs('', FY)).rejects.toThrow(ForbiddenException);
  });
});
