/**
 * PF / ESI / PT Controller — Statutory Filing REST API
 * ════════════════════════════════════════════════════════════════════════
 * POST /pf-esi/ecr/generate               — Generate monthly ECR
 * GET  /pf-esi/ecr/export/:year/:month    — Download ECR TXT for EPFO
 * POST /pf-esi/ecr/status/:year/:month    — Mark ECR submitted/paid + TRRN
 * GET  /pf-esi/ecr/:year/:month           — Get ECR record + validation
 * POST /pf-esi/esi/generate               — Generate ESI contribution
 * GET  /pf-esi/esi/export/:year/:month    — Download ESI CSV for ESIC
 * POST /pf-esi/esi/status/:year/:month    — Mark ESI submitted/paid
 * POST /pf-esi/pt/generate                — Generate PT return
 * GET  /pf-esi/pt/:year/:month            — Get PT return data
 * GET  /pf-esi/dashboard/:year/:month     — All-statutory monthly dashboard
 * GET  /pf-esi/annual-summary/:fy         — Annual PF Form 3A summary
 * POST /pf-esi/uan/:employeeId            — Update employee UAN
 * POST /pf-esi/uan/bulk-import            — Bulk UAN CSV import
 * GET  /pf-esi/rates                      — Current statutory rates
 * GET  /pf-esi/pt-slabs/:stateCode        — PT slabs for a state
 * GET  /pf-esi/due-dates/:year/:month     — Filing due dates
 */

import {
  Controller, Get, Post, Param, Query, Body,
  UseGuards, HttpCode, HttpStatus, Res, Logger,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth, ApiQuery } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import type { Response } from 'express';

import { PfEsiService } from './pf-esi.service';
import { TenantGuard } from '../../../common/guards/tenant.guard';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { Roles } from '../../../common/decorators/permissions.decorator';
import {
  PF_WAGE_CEILING, PF_RATE_EMPLOYEE, PF_EPS_RATE, PF_EPF_EMPLOYER_RATE,
  EPS_MAX_MONTHLY, EDLI_RATE, EDLI_WAGE_CEILING, PF_ADMIN_CHARGE_RATE,
  PF_ADMIN_CHARGE_MINIMUM, ESI_WAGE_LIMIT, ESI_RATE_EMPLOYEE, ESI_RATE_EMPLOYER,
  PT_SLABS, PT_FILING_DUE_DATES,
} from './pf-esi.engine';
import type { JwtPayload } from '@retroworks/types';

@ApiTags('PF / ESI / Professional Tax')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('payroll-admin', 'super-admin')
@Controller('pf-esi')
export class PfEsiController {
  private readonly logger = new Logger(PfEsiController.name);

  constructor(private readonly pfEsiService: PfEsiService) {}

  // ─── Static / Reference ───────────────────────────────────────────────────

  @Get('rates')
  @ApiOperation({ summary: 'Current statutory PF / ESI rates (no DB hit)' })
  getRates() {
    return {
      pf: {
        pfWageCeiling: PF_WAGE_CEILING,
        employeeContributionRate: `${PF_RATE_EMPLOYEE * 100}%`,
        employerEpfRate: `${PF_EPF_EMPLOYER_RATE * 100}% (3.67% → EPF account)`,
        employerEpsRate: `${PF_EPS_RATE * 100}% (8.33% → EPS, max ₹${EPS_MAX_MONTHLY}/month)`,
        edliRate: `${EDLI_RATE * 100}% on wages up to ₹${EDLI_WAGE_CEILING}`,
        adminChargeRate: `${PF_ADMIN_CHARGE_RATE * 100}% (min ₹${PF_ADMIN_CHARGE_MINIMUM}/month)`,
        totalEmployerCost: '13.67% + admin on PF wages',
        applicability: 'All establishments with 20+ employees. Voluntary for smaller.',
      },
      esi: {
        wageLimit: `₹${ESI_WAGE_LIMIT}/month gross`,
        employeeRate: `${ESI_RATE_EMPLOYEE * 100}%`,
        employerRate: `${ESI_RATE_EMPLOYER * 100}%`,
        totalRate: `${(ESI_RATE_EMPLOYEE + ESI_RATE_EMPLOYER) * 100}%`,
        applicability: 'Gross wages ≤ ₹21,000/month. Establishments with 10+ employees.',
      },
      fyNote: 'Rates effective FY 2024-25. Verify with latest EPFO/ESIC circular.',
      disclaimer: '⚠️ Employer must verify statutory rates with EPFO/ESIC before filing.',
    };
  }

  @Get('pt-slabs/:stateCode')
  @ApiOperation({ summary: 'Professional Tax slabs for a state' })
  getPtSlabs(@Param('stateCode') stateCode: string) {
    const slabs = PT_SLABS[stateCode.toUpperCase()];
    if (!slabs) {
      return { stateCode, slabs: null, message: `No PT slabs configured for state ${stateCode}. May not have PT.` };
    }
    return {
      stateCode: stateCode.toUpperCase(),
      slabs,
      dueDate: PT_FILING_DUE_DATES[stateCode.toUpperCase()] ?? 'Check state PT act',
      annualMaximum: Math.max(...slabs.map(s => s.monthlyPt)) * 12,
    };
  }

  @Get('due-dates/:year/:month')
  @ApiOperation({ summary: 'Statutory filing due dates for a wage month' })
  getDueDates(@Param('year') year: string, @Param('month') month: string) {
    const y = parseInt(year), m = parseInt(month);
    const nextM = m === 12 ? 1 : m + 1;
    const nextY = m === 12 ? y + 1 : y;
    return {
      wageMonth: `${String(m).padStart(2, '0')}/${y}`,
      dueDates: {
        pf_ecr: `15 ${new Date(nextY, nextM - 1, 15).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })} — Section 6(1), EPF Act 1952`,
        esi: `21 ${new Date(nextY, nextM - 1, 21).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })} — Reg 31, ESI (Central) Rules 1950`,
        pt: 'Varies by state — see /pf-esi/pt-slabs/:stateCode',
      },
      penalties: {
        pf_late: 'Interest: 12% p.a. (Sec 7Q) + Damages: 5–25% (Sec 14B) depending on delay',
        esi_late: 'Simple interest at 12% p.a. under Reg 31C',
        pt_late: 'State-specific penalty (usually 2% per month)',
      },
    };
  }

  // ─── EPF ECR ──────────────────────────────────────────────────────────────

  @Post('ecr/generate')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Generate monthly EPF ECR from payroll data',
    description: 'Assembles ECR 2.0 format from current month payslips. Validates UANs and PF registration.',
  })
  @ApiQuery({ name: 'year', required: false })
  @ApiQuery({ name: 'month', required: false })
  async generateEcr(
    @Query('year') year: string | undefined,
    @Query('month') month: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const now = new Date();
    const y = year ? parseInt(year) : now.getFullYear();
    const m = month ? parseInt(month) : now.getMonth() + 1;

    const result = await this.pfEsiService.generateEcr(user.tid, y, m, user.sub);
    return {
      success: true,
      wageMonth: `${String(m).padStart(2, '0')}/${y}`,
      status: result.record.status,
      totals: {
        totalMembers: result.ecrData.totals.totalMembers,
        totalEpfEmployee: result.ecrData.totals.totalEpfContributionEmployee,
        totalEpfEmployer: result.ecrData.totals.totalEpfContributionEmployer,
        totalEps: result.ecrData.totals.totalEpsContribution,
        totalEdli: result.ecrData.totals.totalEdliContribution,
        adminCharge: result.ecrData.totals.totalAdminCharge,
        grandTotalPayable: result.ecrData.totals.grandTotalPayable,
      },
      validation: result.validation,
      dueDate: result.dueDate,
      nextStep: 'Export ECR: GET /pf-esi/ecr/export/:year/:month — upload to EPFO Unified Portal',
    };
  }

  @Get('ecr/export/:year/:month')
  @ApiOperation({
    summary: 'Download ECR 2.0 TXT for EPFO Unified Portal upload',
    description: 'Export-only. CA/HR must validate before upload to https://unifiedportal-emp.epfindia.gov.in',
  })
  async exportEcr(
    @Param('year') year: string,
    @Param('month') month: string,
    @CurrentUser() user: JwtPayload,
    @Res({ passthrough: true }) res: Response,
  ) {
    const content = await this.pfEsiService.exportEcrText(user.tid, parseInt(year), parseInt(month));
    const filename = `ECR_${year}_${String(month).padStart(2,'0')}_${user.tid.slice(0,8)}.txt`;
    res.set({
      'Content-Type': 'text/plain; charset=utf-8',
      'Content-Disposition': `attachment; filename="${filename}"`,
      'X-Export-Warning': 'UPLOAD-TO-EPFO-UNIFIED-PORTAL-ONLY',
    });
    res.send(content);
  }

  @Post('ecr/status/:year/:month')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Mark ECR as submitted (TRRN assigned) or paid' })
  async updateEcrStatus(
    @Param('year') year: string,
    @Param('month') month: string,
    @Body() body: { status: 'submitted' | 'paid'; trrnNumber?: string },
    @CurrentUser() user: JwtPayload,
  ) {
    await this.pfEsiService.updateEcrStatus(
      user.tid, parseInt(year), parseInt(month),
      body.status, body.trrnNumber, user.sub,
    );
    return {
      success: true,
      wageMonth: `${String(month).padStart(2, '0')}/${year}`,
      status: body.status,
      trrnNumber: body.trrnNumber ?? null,
      message: body.status === 'paid'
        ? '✅ ECR marked as paid. PF compliance complete for this month.'
        : `ECR submitted. TRRN: ${body.trrnNumber ?? 'N/A'}`,
    };
  }

  @Get('ecr/:year/:month')
  @ApiOperation({ summary: 'Get ECR record and validation for a month' })
  async getEcr(
    @Param('year') year: string,
    @Param('month') month: string,
    @CurrentUser() user: JwtPayload,
  ) {
    const result = await this.pfEsiService.generateEcr(user.tid, parseInt(year), parseInt(month), user.sub);
    return result;
  }

  // ─── ESI ──────────────────────────────────────────────────────────────────

  @Post('esi/generate')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Generate ESI monthly contribution statement' })
  @ApiQuery({ name: 'year', required: false })
  @ApiQuery({ name: 'month', required: false })
  async generateEsi(
    @Query('year') year: string | undefined,
    @Query('month') month: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const now = new Date();
    const y = year ? parseInt(year) : now.getFullYear();
    const m = month ? parseInt(month) : now.getMonth() + 1;

    const result = await this.pfEsiService.generateEsiContribution(user.tid, y, m, user.sub);
    return {
      success: true,
      wageMonth: `${String(m).padStart(2, '0')}/${y}`,
      contributionPeriod: result.esiData.contributionPeriod,
      totals: result.esiData.totals,
      validation: result.validation,
      dueDate: result.dueDate,
    };
  }

  @Get('esi/export/:year/:month')
  @ApiOperation({ summary: 'Download ESI contribution CSV for ESIC portal upload' })
  async exportEsi(
    @Param('year') year: string,
    @Param('month') month: string,
    @CurrentUser() user: JwtPayload,
    @Res({ passthrough: true }) res: Response,
  ) {
    const result = await this.pfEsiService.generateEsiContribution(user.tid, parseInt(year), parseInt(month), user.sub);
    const { generateEsiExport: genEsi } = require('./pf-esi.engine');
    const content = generateEsiExport(result.esiData);
    const filename = `ESI_${year}_${String(month).padStart(2,'0')}_${user.tid.slice(0,8)}.txt`;
    res.set({
      'Content-Type': 'text/plain; charset=utf-8',
      'Content-Disposition': `attachment; filename="${filename}"`,
    });
    res.send(content);
  }

  // ─── Professional Tax ─────────────────────────────────────────────────────

  @Post('pt/generate')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Generate monthly Professional Tax return' })
  @ApiQuery({ name: 'year', required: false })
  @ApiQuery({ name: 'month', required: false })
  async generatePt(
    @Query('year') year: string | undefined,
    @Query('month') month: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const now = new Date();
    const y = year ? parseInt(year) : now.getFullYear();
    const m = month ? parseInt(month) : now.getMonth() + 1;

    const result = await this.pfEsiService.generatePtReturn(user.tid, y, m, user.sub);
    return {
      success: true,
      wageMonth: `${String(m).padStart(2, '0')}/${y}`,
      stateCode: result.ptData.stateCode,
      totals: result.ptData.totals,
      dueDate: result.dueDate,
    };
  }

  // ─── Dashboard + Summary ──────────────────────────────────────────────────

  @Get('dashboard/:year/:month')
  @ApiOperation({ summary: 'All-statutory monthly dashboard: PF + ESI + PT totals and status' })
  async getDashboard(
    @Param('year') year: string,
    @Param('month') month: string,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.pfEsiService.getMonthlyDashboard(user.tid, parseInt(year), parseInt(month));
  }

  @Get('annual-summary/:fy')
  @ApiOperation({ summary: 'Annual PF summary per employee (for Form 3A / annual return)' })
  async getAnnualSummary(
    @Param('fy') fy: string,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.pfEsiService.getAnnualPfSummary(user.tid, fy);
  }

  // ─── UAN Management ───────────────────────────────────────────────────────

  @Post('uan/:employeeId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Update employee Universal Account Number (UAN)' })
  async updateUAN(
    @Param('employeeId') employeeId: string,
    @Body() body: { uan: string },
    @CurrentUser() user: JwtPayload,
  ) {
    return this.pfEsiService.updateUAN(user.tid, employeeId, body.uan, user.sub);
  }

  @Post('uan/bulk-import')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Bulk import UANs from CSV',
    description: 'CSV format: Employee Code,UAN (header required)',
  })
  async bulkImportUANs(
    @Body() body: { csvContent: string },
    @CurrentUser() user: JwtPayload,
  ) {
    return this.pfEsiService.bulkImportUANs(user.tid, body.csvContent, user.sub);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE
// ─────────────────────────────────────────────────────────────────────────────

import { Module } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';

@Module({
  controllers: [PfEsiController],
  providers: [PfEsiService, PrismaTenantService, PrismaClient],
  exports: [PfEsiService],
})
export class PfEsiModule {}
