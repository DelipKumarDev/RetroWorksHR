/**
 * PF / ESI / PT Service
 * AUDIT-PAYROLL-2: Refactored — zero raw PrismaClient.
 *
 * GLOBAL via $global:  tenant (no tenantId col)
 * upsert → findFirst+create/update:
 *   pfEcrRecord, esiContributionRecord, ptReturnRecord (compound keys include tenantId)
 */
import {
  Injectable, Logger, NotFoundException,
  BadRequestException, ConflictException,
} from '@nestjs/common';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import {
  assembleEcr, assembleEsiContribution, assemblePtReturn,
  generateEcrExport, validateEcrInput, validateEsiInput,
  assembleAnnualPfSummary, buildMonthlyDashboard,
  type EmployerDetails, type MonthlyPayslipInput, type EcrRecord,
} from './pf-esi.engine';

@Injectable()
export class PfEsiService {
  private readonly logger = new Logger(PfEsiService.name);
  constructor(private readonly db: PrismaTenantService) {}

  private async getEmployerDetails(tenantId: string): Promise<EmployerDetails> {
    const scope = this.db.forTenant(tenantId);
    // tenant is a global record — use $global
    const tenant = await scope.$global.tenant.findFirst({ where: { id: tenantId } });
    if (!tenant) throw new NotFoundException('Tenant not found');
    const s = (tenant.settings as any) ?? {};
    const pf = (tenant as any).pf_config ?? s;
    return {
      establishmentName:    tenant.name,
      pfRegistrationNumber: pf.pfRegistrationNumber ?? s.pfRegistrationNumber ?? '',
      esiRegistrationNumber:pf.esiRegistrationNumber ?? s.esiRegistrationNumber ?? '',
      tan: pf.tan ?? s.tan ?? '',
      pan: pf.pan ?? s.pan ?? '',
      address: pf.address ?? s.address ?? '',
      state: pf.state ?? s.state ?? 'KA',
    };
  }

  private async getMonthlyPayslipInputs(
    tenantId: string, year: number, month: number,
  ): Promise<MonthlyPayslipInput[]> {
    const scope = this.db.forTenant(tenantId);
    // proxy injects tenantId
    const payslips = await scope.payslip.findMany({
      where: { year, month, status: { not: 'cancelled' } },
      include: { employee: { select: { id: true, firstName: true, lastName: true } } },
    });
    return (payslips as any[]).map(p => {
      const emp = p.employee;
      return {
        employeeId:        p.employeeId,
        name:              `${emp.firstName} ${emp.lastName}`,
        uan:               emp.uan ?? emp.pfUan ?? '',
        esiInsuranceNumber:emp.esiIpNumber ?? '',
        basicWages:        Number(p.basicPay ?? 0),
        grossWages:        Number(p.grossPay ?? 0),
        ncpDays:           Number(p.components?.ncpDays ?? 0),
        vpfContribution:   Number(p.components?.vpfContribution ?? 0),
        isEsiApplicable:   emp.esiEligible !== false,
        daysWorked:        Number(p.components?.daysWorked ?? 26),
        halfDayLeave:      0,
        memberIdPf:        emp.pfMemberId ?? '',
      };
    });
  }

  // ─── ECR ──────────────────────────────────────────────────────────────────

  async generateEcr(tenantId: string, year: number, month: number, generatedBy: string) {
    const scope = this.db.forTenant(tenantId);

    const existing = await scope.pfEcrRecord.findFirst({
      where: { wageYear: year, wageMonth: month },
    });
    if (existing && ['submitted', 'paid'].includes((existing as any).status)) {
      throw new ConflictException(`ECR for ${String(month).padStart(2,'0')}/${year} is already ${(existing as any).status}.`);
    }

    const [employer, employees] = await Promise.all([
      this.getEmployerDetails(tenantId),
      this.getMonthlyPayslipInputs(tenantId, year, month),
    ]);
    const ecr = assembleEcr(employer, year, month, employees);
    const validation = validateEcrInput(ecr);

    const ecrData = {
      wageYear: year, wageMonth: month,
      financialYear:        ecr.financialYear,
      pfRegistrationNumber: employer.pfRegistrationNumber,
      totalMembers:         ecr.totals.totalMembers,
      totalEpfEmployee:     ecr.totals.totalEpfContributionEmployee,
      totalEpfEmployer:     ecr.totals.totalEpfContributionEmployer,
      totalEps:             ecr.totals.totalEpsContribution,
      totalEdli:            ecr.totals.totalEdliContribution,
      totalAdminCharge:     ecr.totals.totalAdminCharge,
      totalVpf:             ecr.totals.totalVpfContribution,
      grandTotalPayable:    ecr.totals.grandTotalPayable,
      ecrData:              ecr as any,
      checksumHash:         ecr.checksumHash,
      status:               'draft',
      generatedBy,          generatedAt: new Date(),
    };

    // findFirst + create/update (compound key includes tenantId)
    let record: any;
    if (existing) {
      record = await scope.pfEcrRecord.update({
        where: { id: (existing as any).id },
        data: { ...ecrData, updatedAt: new Date() },
      });
    } else {
      record = await scope.pfEcrRecord.create({
        data: { ...ecrData, createdAt: new Date() },
      });
    }

    this.logger.log(`ECR generated: ${month}/${year} for ${tenantId}. Members: ${ecr.totals.totalMembers}`);
    return { record, ecrData: ecr, validation: { isValid: validation.isValid, blockingErrors: validation.blockingErrors, warnings: validation.warnings }, dueDate: '15th of following month' };
  }

  async exportEcrText(tenantId: string, year: number, month: number): Promise<string> {
    const scope = this.db.forTenant(tenantId);
    const record = await scope.pfEcrRecord.findFirst({ where: { wageYear: year, wageMonth: month } });
    if (!record) throw new NotFoundException(`ECR for ${month}/${year} not found. Generate first.`);
    return generateEcrExport((record as any).ecrData as EcrRecord);
  }

  async updateEcrStatus(
    tenantId: string, year: number, month: number,
    status: 'submitted' | 'paid', trrnNumber?: string, updatedBy?: string,
  ) {
    const scope = this.db.forTenant(tenantId);
    const record = await scope.pfEcrRecord.findFirst({ where: { wageYear: year, wageMonth: month } });
    if (!record) throw new NotFoundException(`ECR for ${month}/${year} not found.`);
    if ((record as any).status === 'paid') throw new ConflictException('ECR is already marked as paid.');
    await scope.pfEcrRecord.update({
      where: { id: (record as any).id },
      data: {
        status, trrnNumber: trrnNumber ?? (record as any).trrnNumber,
        submittedAt: status === 'submitted' ? new Date() : (record as any).submittedAt,
        paidAt:      status === 'paid' ? new Date() : null,
        updatedAt:   new Date(),
      },
    });
    this.logger.log(`ECR status → ${status}: ${month}/${year} for ${tenantId}`);
  }

  // ─── ESI ──────────────────────────────────────────────────────────────────

  async generateEsiContribution(tenantId: string, year: number, month: number, generatedBy: string) {
    const scope = this.db.forTenant(tenantId);
    const [employer, employees] = await Promise.all([
      this.getEmployerDetails(tenantId),
      this.getMonthlyPayslipInputs(tenantId, year, month),
    ]);
    const esi = assembleEsiContribution(employer, year, month, employees);
    const validation = validateEsiInput(esi);

    const esiData = {
      wageYear: year, wageMonth: month,
      contributionPeriod: esi.contributionPeriod,
      totalMembers:       esi.totals.totalMembers,
      totalEsiEmployee:   esi.totals.totalEsiEmployee,
      totalEsiEmployer:   esi.totals.totalEsiEmployer,
      totalEsiPayable:    esi.totals.totalEsiPayable,
      esiData:            esi as any,
      checksumHash:       esi.checksumHash,
      status:             'draft',
      generatedBy,        generatedAt: new Date(),
    };

    const existing = await scope.esiContributionRecord.findFirst({
      where: { wageYear: year, wageMonth: month },
    });
    let record: any;
    if (existing) {
      record = await scope.esiContributionRecord.update({
        where: { id: (existing as any).id },
        data: { ...esiData, updatedAt: new Date() },
      });
    } else {
      record = await scope.esiContributionRecord.create({
        data: { ...esiData, createdAt: new Date() },
      });
    }
    return { record, esiData: esi, validation, dueDate: '21st of following month' };
  }

  // ─── PT ───────────────────────────────────────────────────────────────────

  async generatePtReturn(tenantId: string, year: number, month: number, generatedBy: string) {
    const scope = this.db.forTenant(tenantId);
    const [employer, payslips] = await Promise.all([
      this.getEmployerDetails(tenantId),
      this.getMonthlyPayslipInputs(tenantId, year, month),
    ]);
    const ptInput = payslips.map(p => ({ employeeId: p.employeeId, name: p.name, monthlyGross: p.grossWages }));
    const pt = assemblePtReturn(employer, year, month, ptInput);

    const ptData = {
      wageYear: year, wageMonth: month,
      stateCode: pt.stateCode, financialYear: pt.financialYear,
      totalEmployees: pt.totals.totalEmployees,
      totalPtPayable: pt.totals.totalPtPayable,
      ptData: pt as any, dueDate: pt.dueDate,
      status: 'draft', generatedBy, generatedAt: new Date(),
    };

    const existing = await scope.ptReturnRecord.findFirst({ where: { wageYear: year, wageMonth: month } });
    if (existing) {
      await scope.ptReturnRecord.update({
        where: { id: (existing as any).id },
        data: { ...ptData, updatedAt: new Date() },
      });
    } else {
      await scope.ptReturnRecord.create({ data: { ...ptData, createdAt: new Date() } });
    }
    return { ptData: pt, dueDate: pt.dueDate };
  }

  // ─── Dashboard ────────────────────────────────────────────────────────────

  async getMonthlyDashboard(tenantId: string, year: number, month: number) {
    const scope = this.db.forTenant(tenantId);
    const [ecrRecord, esiRecord, ptRecord] = await Promise.all([
      scope.pfEcrRecord.findFirst({ where: { wageYear: year, wageMonth: month } }),
      scope.esiContributionRecord.findFirst({ where: { wageYear: year, wageMonth: month } }),
      scope.ptReturnRecord.findFirst({ where: { wageYear: year, wageMonth: month } }),
    ]);

    const dash = buildMonthlyDashboard(
      year, month,
      ecrRecord ? (ecrRecord as any).ecrData : null,
      esiRecord ? (esiRecord as any).esiData : null,
      ptRecord  ? (ptRecord  as any).ptData  : null,
      ((ecrRecord as any)?.status ?? 'not_started') as any,
      ((esiRecord as any)?.status ?? 'not_started') as any,
    );
    return { ...dash, disclaimer: '⚠️ PF due: 15th | ESI due: 21st of following month.' };
  }

  async getAnnualPfSummary(tenantId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);
    const records = await scope.pfEcrRecord.findMany({
      where: { financialYear },
      orderBy: [{ wageYear: 'asc' }, { wageMonth: 'asc' }],
    });
    const monthlyEcrs = (records as any[]).map(r => r.ecrData as EcrRecord);
    const summary = assembleAnnualPfSummary(monthlyEcrs);
    const totals = summary.reduce((acc, e) => ({
      totalEpfEmployee: acc.totalEpfEmployee + e.totalEpfEmployee,
      totalEpfEmployer: acc.totalEpfEmployer + e.totalEpfEmployer,
      totalEps:         acc.totalEps         + e.totalEps,
      totalEdli:        acc.totalEdli        + e.totalEdli,
    }), { totalEpfEmployee: 0, totalEpfEmployer: 0, totalEps: 0, totalEdli: 0 });
    return { financialYear, employees: summary, totals, months: (records as any[]).length };
  }

  // ─── UAN Management ───────────────────────────────────────────────────────

  async updateUAN(tenantId: string, employeeId: string, uan: string, updatedBy: string) {
    if (!/^\d{12}$/.test(uan)) throw new BadRequestException(`UAN "${uan}" invalid — must be 12 digits.`);
    const scope = this.db.forTenant(tenantId);
    // proxy scopes both reads/writes to this tenant — cross-tenant impossible
    await scope.employee.update({
      where: { id: employeeId },
      data: { uan, updatedAt: new Date() } as any,
    });
    this.logger.log(`UAN updated for ${employeeId}: ${uan} by ${updatedBy}`);
    return { employeeId, uan, updatedBy };
  }

  async bulkImportUANs(tenantId: string, csvContent: string, importedBy: string) {
    const scope = this.db.forTenant(tenantId);
    const lines = csvContent.split('\n').map(l => l.trim()).filter(Boolean).slice(1);
    const errors: string[] = [];
    let updated = 0;

    for (let i = 0; i < lines.length; i++) {
      const [empCode, uan] = (lines[i] ?? '').split(',').map(c => c.trim().replace(/"/g, ''));
      if (!empCode || !uan) { errors.push(`Row ${i + 2}: empty code or UAN`); continue; }
      try {
        const emp = await scope.employee.findFirst({ where: { employeeCode: empCode } as any });
        if (!emp) { errors.push(`Row ${i + 2}: code "${empCode}" not found`); continue; }
        await this.updateUAN(tenantId, (emp as any).id, uan, importedBy);
        updated++;
      } catch (err: any) {
        errors.push(`Row ${i + 2}: ${err.message}`);
      }
    }
    return { updated, errors };
  }
}
