/**
 * RetroWorks HR — PF / ESI / Professional Tax Statutory Filing Engine
 * ═══════════════════════════════════════════════════════════════════════════
 * Pure TypeScript functions for assembling:
 *
 *   ▸ EPF ECR (Electronic Challan cum Return) — EPFO Unified Portal format
 *   ▸ ESI Monthly Contribution Statement — ESIC Portal format
 *   ▸ Professional Tax returns — state-wise (Karnataka, Maharashtra, WB…)
 *
 * Legal basis:
 *   ▸ Employees' Provident Funds & Misc. Provisions Act, 1952
 *   ▸ EPF Scheme, 1952 | EPS Scheme, 1995 | EDLI Scheme, 1976
 *   ▸ Employees' State Insurance Act, 1948
 *   ▸ State Professional Tax Acts (varies by state)
 *   ▸ EPFO Circular: ECR 2.0 — effective April 2012
 *
 * ⚠️  DISCLAIMER: This engine exports filing data for employer review and
 *     upload to EPFO/ESIC Unified Portal. It does NOT directly file with
 *     any government portal. Employer remains legally responsible.
 *
 * Due dates:
 *   ▸ PF ECR + challan:     15th of following month
 *   ▸ ESI contribution:     21st of following month
 *   ▸ Professional Tax:     State-specific (see PT_FILING_DUE_DATES)
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS — FY 2024-25
// ─────────────────────────────────────────────────────────────────────────────

/** EPF wage ceiling for contribution — Section 6(1) EPF Act 1952 */
export const PF_WAGE_CEILING = 15_000;

/** Employee contribution: 12% of PF wages */
export const PF_RATE_EMPLOYEE = 0.12;

/** Employer contribution split: 8.33% to EPS (capped at ₹1,250/mo) + 3.67% to EPF */
export const PF_EPS_RATE = 0.0833;
export const PF_EPF_EMPLOYER_RATE = 0.0367;

/** EPS cap: 8.33% × ₹15,000 = ₹1,250/month */
export const EPS_MAX_MONTHLY = 1_250;

/** EDLI: 0.5% of EPF wages (capped at ₹15,000) — Employer pays, no employee share */
export const EDLI_RATE = 0.005;
export const EDLI_WAGE_CEILING = 15_000;

/** Employer admin charge: 0.50% of EPF wages (min ₹500/month for establishment) */
export const PF_ADMIN_CHARGE_RATE = 0.005;
export const PF_ADMIN_CHARGE_MINIMUM = 500;

/** ESI applicability: gross wage ≤ ₹21,000/month */
export const ESI_WAGE_LIMIT = 21_000;
export const ESI_RATE_EMPLOYEE = 0.0075;   // 0.75%
export const ESI_RATE_EMPLOYER = 0.0325;   // 3.25%

/** Professional Tax: state code → monthly slabs */
export const PT_SLABS: Record<string, Array<{ upTo: number; monthlyPt: number; annualNote?: string }>> = {
  KA: [
    { upTo: 14_999, monthlyPt: 0 },
    { upTo: 99_999_999, monthlyPt: 200, annualNote: 'No PT in April — ₹200 × 11 = ₹2,200/year (not ₹2,400)' },
  ],
  MH: [
    { upTo: 7_500, monthlyPt: 0 },
    { upTo: 10_000, monthlyPt: 175 },
    { upTo: 99_999_999, monthlyPt: 200, annualNote: 'Feb = ₹300 in MH' },
  ],
  WB: [
    { upTo: 10_000, monthlyPt: 0 },
    { upTo: 15_000, monthlyPt: 110 },
    { upTo: 25_000, monthlyPt: 130 },
    { upTo: 40_000, monthlyPt: 150 },
    { upTo: 99_999_999, monthlyPt: 200 },
  ],
  AP: [
    { upTo: 15_000, monthlyPt: 0 },
    { upTo: 20_000, monthlyPt: 150 },
    { upTo: 99_999_999, monthlyPt: 200 },
  ],
  TS: [
    { upTo: 15_000, monthlyPt: 0 },
    { upTo: 20_000, monthlyPt: 150 },
    { upTo: 99_999_999, monthlyPt: 200 },
  ],
  TN: [
    { upTo: 21_000, monthlyPt: 0 },
    { upTo: 30_000, monthlyPt: 135 },
    { upTo: 45_000, monthlyPt: 315 },
    { upTo: 60_000, monthlyPt: 690 },
    { upTo: 75_000, monthlyPt: 1_025 },
    { upTo: 99_999_999, monthlyPt: 1_250 },
  ],
  GJ: [{ upTo: 99_999_999, monthlyPt: 0, annualNote: 'Gujarat: no Professional Tax' }],
  DL: [{ upTo: 99_999_999, monthlyPt: 0, annualNote: 'Delhi: no Professional Tax' }],
  HR: [{ upTo: 99_999_999, monthlyPt: 0, annualNote: 'Haryana: no Professional Tax' }],
  RJ: [{ upTo: 99_999_999, monthlyPt: 0, annualNote: 'Rajasthan: no Professional Tax' }],
  MP: [{ upTo: 99_999_999, monthlyPt: 0, annualNote: 'Madhya Pradesh: no Professional Tax' }],
};

export const PT_FILING_DUE_DATES: Record<string, string> = {
  KA: '20th of the following month',
  MH: 'Last day of the month (annual return: 31 March)',
  WB: '21st of the following month',
  AP: '10th of the following month',
  TS: '10th of the following month',
  TN: '1st of the following month (quarterly return)',
};

// ─────────────────────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────────────────────

export interface EmployerDetails {
  establishmentName: string;
  pfRegistrationNumber: string;    // EPFO registration (format: XX/XXXXX/000/000)
  esiRegistrationNumber?: string;  // ESIC employer code
  tan: string;
  pan: string;
  address: string;
  state: string;                   // ISO state code e.g. 'KA'
}

export interface EmployeePfRecord {
  employeeId: string;
  name: string;
  uan: string;                     // Universal Account Number (12 digits)
  memberId?: string;               // PF member ID (establishment-specific)
  grossWages: number;              // Gross salary for the month
  basicWages: number;              // Basic salary (PF wage basis)
  pfWages: number;                 // = min(basicWages, PF_WAGE_CEILING)
  epfWages: number;                // Same as pfWages in most cases
  epsWages: number;                // Same as pfWages (capped at 15,000)
  edliWages: number;               // Same as pfWages (capped at 15,000)
  epfContributionEmployee: number; // 12% of pfWages
  epfContributionEmployer: number; // 3.67% of pfWages
  epsContribution: number;         // 8.33% of epsWages (max ₹1,250)
  edliContribution: number;        // 0.5% of edliWages
  ncpDays: number;                 // Non-contributing days (leave without pay etc.)
  refundOfAdvances: number;        // PF advance repayment if any
  isVoluntaryHigherContribution: boolean; // Employee opts for >12% VPF
  vpfContribution: number;         // Voluntary PF contribution (above 12%)
}

export interface EmployeeEsiRecord {
  employeeId: string;
  name: string;
  esiInsuranceNumber?: string;     // ESI IP number (IP = Insured Person)
  grossWages: number;
  esiWages: number;                // Same as grossWages for ESI
  esiEmployee: number;             // 0.75% of esiWages
  esiEmployer: number;             // 3.25% of esiWages
  isEsiApplicable: boolean;        // false if grossWages > ₹21,000
  daysWorked: number;
  halfDayLeave: number;
}

export interface MonthlyPayslipInput {
  employeeId: string;
  name: string;
  uan: string;
  esiInsuranceNumber?: string;
  basicWages: number;
  grossWages: number;
  ncpDays: number;
  vpfContribution: number;
  isEsiApplicable: boolean;
  daysWorked: number;
  halfDayLeave: number;
  memberIdPf?: string;
}

// ─── ECR Types ──────────────────────────────────────────────────────────────

export interface EcrRecord {
  establishment: EmployerDetails;
  wageMonth: string;               // "MM/YYYY" e.g. "06/2024"
  financialYear: string;
  trrnNumber?: string;             // TRRN assigned by EPFO portal after upload
  members: EmployeePfRecord[];
  totals: EcrTotals;
  generatedAt: Date;
  checksumHash: string;
  status: 'draft' | 'submitted' | 'acknowledged';
}

export interface EcrTotals {
  totalMembers: number;
  totalEpfContributionEmployee: number;
  totalEpfContributionEmployer: number;
  totalEpsContribution: number;
  totalEdliContribution: number;
  totalAdminCharge: number;
  totalVpfContribution: number;
  totalGrossWages: number;
  totalPfWages: number;
  grandTotalPayable: number;       // EPF(employee) + EPF(employer) + EPS + EDLI + admin
}

// ─── ESI Types ───────────────────────────────────────────────────────────────

export interface EsiContributionRecord {
  establishment: EmployerDetails;
  contributionPeriod: string;      // "April 2024 – September 2024" or "Oct 2024 – March 2025"
  wageMonth: string;               // "MM/YYYY"
  members: EmployeeEsiRecord[];
  totals: {
    totalMembers: number;
    totalEsiWages: number;
    totalEsiEmployee: number;
    totalEsiEmployer: number;
    totalEsiPayable: number;
  };
  generatedAt: Date;
  checksumHash: string;
}

// ─── PT Types ────────────────────────────────────────────────────────────────

export interface PtDeductionRecord {
  employeeId: string;
  name: string;
  monthlyGross: number;
  ptMonthly: number;
}

export interface PtReturnRecord {
  establishment: EmployerDetails;
  stateCode: string;
  wageMonth: string;
  financialYear: string;
  employees: PtDeductionRecord[];
  totals: {
    totalEmployees: number;
    totalPtDeducted: number;
    totalPtPayable: number;
  };
  dueDate: string;
  generatedAt: Date;
}

// ─── Validation ──────────────────────────────────────────────────────────────

export interface FilingValidationError {
  code: string;
  field: string;
  message: string;
  severity: 'blocking' | 'warning';
  employeeId?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

export function r2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function ri(n: number): number {
  return Math.round(n);
}

export function validateUAN(uan: string): boolean {
  return /^\d{12}$/.test(uan ?? '');
}

export function validatePfRegistration(reg: string): boolean {
  // Format: XX/XXXXX/000/000 (state/district/est-code/ext)
  return /^[A-Z]{2}\/[A-Z0-9]{5}\/[0-9]{3}\/[0-9]{7}$/.test(reg ?? '');
}

export function getWageMonth(year: number, month: number): string {
  return `${String(month).padStart(2, '0')}/${year}`;
}

export function computePfWages(basicWages: number, useCeiling = true): number {
  return useCeiling ? Math.min(basicWages, PF_WAGE_CEILING) : basicWages;
}

export function computeEpfContributionEmployee(pfWages: number): number {
  return ri(pfWages * PF_RATE_EMPLOYEE);
}

export function computeEpfContributionEmployer(pfWages: number): number {
  return ri(pfWages * PF_EPF_EMPLOYER_RATE);
}

export function computeEpsContribution(epsWages: number): number {
  return Math.min(ri(epsWages * PF_EPS_RATE), EPS_MAX_MONTHLY);
}

export function computeEdliContribution(edliWages: number): number {
  const wages = Math.min(edliWages, EDLI_WAGE_CEILING);
  return ri(wages * EDLI_RATE);
}

export function computeAdminCharge(totalPfWages: number, memberCount: number): number {
  const computed = ri(totalPfWages * PF_ADMIN_CHARGE_RATE);
  // Minimum ₹500 if any PF members exist
  return memberCount > 0 ? Math.max(computed, PF_ADMIN_CHARGE_MINIMUM) : computed;
}

export function computeMonthlyPt(monthlyGross: number, stateCode: string, month: number): number {
  const slabs = PT_SLABS[stateCode];
  if (!slabs) return 0;

  const slab = slabs.find(s => monthlyGross <= s.upTo);
  if (!slab) return 0;

  // Karnataka: no PT in April (month 4)
  if (stateCode === 'KA' && month === 4) return 0;

  // Maharashtra: February = ₹300 instead of ₹200
  if (stateCode === 'MH' && month === 2 && monthlyGross > 10_000) return 300;

  return slab.monthlyPt;
}

export function computeEsiContribution(grossWages: number): {
  esiEmployee: number;
  esiEmployer: number;
  isApplicable: boolean;
} {
  if (grossWages > ESI_WAGE_LIMIT) {
    return { esiEmployee: 0, esiEmployer: 0, isApplicable: false };
  }
  return {
    esiEmployee: ri(grossWages * ESI_RATE_EMPLOYEE),
    esiEmployer: ri(grossWages * ESI_RATE_EMPLOYER),
    isApplicable: true,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// PF RECORD ASSEMBLY PER EMPLOYEE
// ─────────────────────────────────────────────────────────────────────────────

export function assembleEmployeePfRecord(input: MonthlyPayslipInput): EmployeePfRecord {
  const pfWages = computePfWages(input.basicWages);
  const epfEmployee = computeEpfContributionEmployee(pfWages);
  const epfEmployer = computeEpfContributionEmployer(pfWages);
  const eps = computeEpsContribution(pfWages);
  const edli = computeEdliContribution(pfWages);

  return {
    employeeId: input.employeeId,
    name: input.name,
    uan: input.uan,
    memberId: input.memberIdPf ?? '',
    grossWages: input.grossWages,
    basicWages: input.basicWages,
    pfWages,
    epfWages: pfWages,
    epsWages: pfWages,
    edliWages: pfWages,
    epfContributionEmployee: epfEmployee,
    epfContributionEmployer: epfEmployer,
    epsContribution: eps,
    edliContribution: edli,
    ncpDays: input.ncpDays,
    refundOfAdvances: 0,
    isVoluntaryHigherContribution: input.vpfContribution > 0,
    vpfContribution: input.vpfContribution,
  };
}

export function assembleEmployeeEsiRecord(input: MonthlyPayslipInput): EmployeeEsiRecord {
  const { esiEmployee, esiEmployer, isApplicable } = computeEsiContribution(input.grossWages);
  return {
    employeeId: input.employeeId,
    name: input.name,
    esiInsuranceNumber: input.esiInsuranceNumber ?? '',
    grossWages: input.grossWages,
    esiWages: input.grossWages,
    esiEmployee,
    esiEmployer,
    isEsiApplicable: input.isEsiApplicable && isApplicable,
    daysWorked: input.daysWorked,
    halfDayLeave: input.halfDayLeave,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// ECR ASSEMBLY — FULL ESTABLISHMENT FOR A MONTH
// ─────────────────────────────────────────────────────────────────────────────

export function assembleEcr(
  establishment: EmployerDetails,
  year: number,
  month: number,
  employees: MonthlyPayslipInput[],
): EcrRecord {
  const members = employees.map(assembleEmployeePfRecord);
  const wageMonth = getWageMonth(year, month);
  const fyYear = month >= 4 ? year : year - 1;
  const financialYear = `${fyYear}-${String(fyYear + 1).slice(2)}`;

  const totalEpfEmployee = r2(members.reduce((s, m) => s + m.epfContributionEmployee, 0));
  const totalEpfEmployer = r2(members.reduce((s, m) => s + m.epfContributionEmployer, 0));
  const totalEps = r2(members.reduce((s, m) => s + m.epsContribution, 0));
  const totalEdli = r2(members.reduce((s, m) => s + m.edliContribution, 0));
  const totalVpf = r2(members.reduce((s, m) => s + m.vpfContribution, 0));
  const totalGross = r2(members.reduce((s, m) => s + m.grossWages, 0));
  const totalPfWages = r2(members.reduce((s, m) => s + m.pfWages, 0));
  const adminCharge = computeAdminCharge(totalPfWages, members.length);

  const grandTotal = r2(totalEpfEmployee + totalEpfEmployer + totalEps + totalEdli + adminCharge + totalVpf);

  const totals: EcrTotals = {
    totalMembers: members.length,
    totalEpfContributionEmployee: totalEpfEmployee,
    totalEpfContributionEmployer: totalEpfEmployer,
    totalEpsContribution: totalEps,
    totalEdliContribution: totalEdli,
    totalAdminCharge: adminCharge,
    totalVpfContribution: totalVpf,
    totalGrossWages: totalGross,
    totalPfWages,
    grandTotalPayable: grandTotal,
  };

  return {
    establishment,
    wageMonth,
    financialYear,
    members,
    totals,
    generatedAt: new Date(),
    checksumHash: simpleHash(JSON.stringify({ establishment: establishment.pfRegistrationNumber, wageMonth, totals })),
    status: 'draft',
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// ESI ASSEMBLY
// ─────────────────────────────────────────────────────────────────────────────

export function assembleEsiContribution(
  establishment: EmployerDetails,
  year: number,
  month: number,
  employees: MonthlyPayslipInput[],
): EsiContributionRecord {
  const esiMembers = employees
    .map(assembleEmployeeEsiRecord)
    .filter(e => e.isEsiApplicable);

  const wageMonth = getWageMonth(year, month);
  const halfYear = month >= 4 && month <= 9
    ? `April ${year} – September ${year}`
    : `October ${year} – March ${year + 1}`;

  const totalWages = r2(esiMembers.reduce((s, e) => s + e.esiWages, 0));
  const totalEsiEmp = r2(esiMembers.reduce((s, e) => s + e.esiEmployee, 0));
  const totalEsiEr = r2(esiMembers.reduce((s, e) => s + e.esiEmployer, 0));

  return {
    establishment,
    contributionPeriod: halfYear,
    wageMonth,
    members: esiMembers,
    totals: {
      totalMembers: esiMembers.length,
      totalEsiWages: totalWages,
      totalEsiEmployee: totalEsiEmp,
      totalEsiEmployer: totalEsiEr,
      totalEsiPayable: r2(totalEsiEmp + totalEsiEr),
    },
    generatedAt: new Date(),
    checksumHash: simpleHash(JSON.stringify({ reg: establishment.esiRegistrationNumber, wageMonth, totalEsiEmp, totalEsiEr })),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// PROFESSIONAL TAX ASSEMBLY
// ─────────────────────────────────────────────────────────────────────────────

export function assemblePtReturn(
  establishment: EmployerDetails,
  year: number,
  month: number,
  employees: Array<{ employeeId: string; name: string; monthlyGross: number }>,
): PtReturnRecord {
  const stateCode = establishment.state;
  const fyYear = month >= 4 ? year : year - 1;
  const financialYear = `${fyYear}-${String(fyYear + 1).slice(2)}`;

  const employeePt: PtDeductionRecord[] = employees.map(e => ({
    employeeId: e.employeeId,
    name: e.name,
    monthlyGross: e.monthlyGross,
    ptMonthly: computeMonthlyPt(e.monthlyGross, stateCode, month),
  }));

  const totalPt = r2(employeePt.reduce((s, e) => s + e.ptMonthly, 0));

  return {
    establishment,
    stateCode,
    wageMonth: getWageMonth(year, month),
    financialYear,
    employees: employeePt,
    totals: {
      totalEmployees: employeePt.length,
      totalPtDeducted: totalPt,
      totalPtPayable: totalPt,
    },
    dueDate: PT_FILING_DUE_DATES[stateCode] ?? 'Refer state PT act',
    generatedAt: new Date(),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// ECR TEXT EXPORT — EPFO Unified Portal format (ECR 2.0)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Generates EPFO ECR 2.0 text file.
 *
 * Format: #~ delimited, one member per line
 * Header: #OALGSNO|MEMBERNAME|GROSSWAGES|EPFWAGES|EPSWAGES|EDLIWAGES|
 *         EPFCONTRIEMPEE|EPFCONTRIEMPER|EPSCONTRI|EDLICONTRI|NCPDAYS|REFUND#
 *
 * ⚠️  Upload to: https://unifiedportal-emp.epfindia.gov.in
 *     NOT for direct API submission. Employer must review before upload.
 */
export function generateEcrExport(ecr: EcrRecord): string {
  const lines: string[] = [];

  // ── Header comment ──────────────────────────────────────────────────────
  lines.push(`# ECR 2.0 | ${ecr.establishment.establishmentName} | ${ecr.wageMonth}`);
  lines.push(`# PF Reg: ${ecr.establishment.pfRegistrationNumber} | Generated: ${ecr.generatedAt.toISOString().slice(0, 10)}`);
  lines.push(`# ⚠️ UPLOAD TO EPFO UNIFIED PORTAL — NOT FOR DIRECT FILING`);
  lines.push(`# TRRN: ${ecr.trrnNumber ?? 'TO BE ASSIGNED BY EPFO PORTAL'}`);
  lines.push('');

  // ── Column header ──────────────────────────────────────────────────────
  lines.push(
    '#~UAN~#MEMBERNAME~#GROSSWAGES~#EPFWAGES~#EPSWAGES~#EDLIWAGES~' +
    '#EPFCONTRIEMPEE~#EPFCONTRIEMPER~#EPSCONTRI~#EDLICONTRI~#NCPDAYS~#REFUND'
  );

  // ── Member rows ────────────────────────────────────────────────────────
  for (const m of ecr.members) {
    const row = [
      m.uan,
      m.name.slice(0, 50).replace(/[,~#]/g, ' '),
      ri(m.grossWages),
      ri(m.epfWages),
      ri(m.epsWages),
      ri(m.edliWages),
      m.epfContributionEmployee,
      m.epfContributionEmployer,
      m.epsContribution,
      m.edliContribution,
      m.ncpDays,
      m.refundOfAdvances,
    ].join('~#');
    lines.push(`#~${row}`);
  }

  lines.push('');

  // ── Summary footer ─────────────────────────────────────────────────────
  const t = ecr.totals;
  lines.push(`# SUMMARY | Members: ${t.totalMembers} | EPF(Employee): ${t.totalEpfContributionEmployee} | EPF(Employer): ${t.totalEpfContributionEmployer}`);
  lines.push(`# EPS: ${t.totalEpsContribution} | EDLI: ${t.totalEdliContribution} | Admin: ${t.totalAdminCharge} | GRAND TOTAL: ${t.grandTotalPayable}`);
  lines.push(`# CHECKSUM: ${ecr.checksumHash}`);

  return lines.join('\r\n');
}

// ─────────────────────────────────────────────────────────────────────────────
// ESI TEXT EXPORT — ESIC Unified Portal format
// ─────────────────────────────────────────────────────────────────────────────

export function generateEsiExport(esi: EsiContributionRecord): string {
  const lines: string[] = [];

  lines.push(`# ESI Contribution | ${esi.establishment.establishmentName} | ${esi.wageMonth}`);
  lines.push(`# ESI Reg: ${esi.establishment.esiRegistrationNumber ?? 'NOT CONFIGURED'}`);
  lines.push(`# Contribution Period: ${esi.contributionPeriod}`);
  lines.push(`# ⚠️ UPLOAD TO ESIC PORTAL — NOT FOR DIRECT FILING`);
  lines.push('');
  lines.push('#IP_NUMBER,EMPLOYEE_NAME,GROSS_WAGES,ESI_EMPLOYEE,ESI_EMPLOYER,DAYS_WORKED');

  for (const m of esi.members) {
    lines.push(
      `${m.esiInsuranceNumber || 'APPLIED'},` +
      `"${m.name.replace(/,/g, ' ')}",` +
      `${m.esiWages},${m.esiEmployee},${m.esiEmployer},${m.daysWorked}`
    );
  }

  lines.push('');
  lines.push(`# TOTALS | Members: ${esi.totals.totalMembers} | Employee ESI: ${esi.totals.totalEsiEmployee} | Employer ESI: ${esi.totals.totalEsiEmployer} | Payable: ${esi.totals.totalEsiPayable}`);

  return lines.join('\r\n');
}

// ─────────────────────────────────────────────────────────────────────────────
// VALIDATION
// ─────────────────────────────────────────────────────────────────────────────

export function validateEcrInput(ecr: EcrRecord): {
  isValid: boolean;
  blockingErrors: FilingValidationError[];
  warnings: FilingValidationError[];
} {
  const blocking: FilingValidationError[] = [];
  const warnings: FilingValidationError[] = [];

  // Establishment
  if (!ecr.establishment.pfRegistrationNumber) {
    blocking.push({ code: 'MISSING_PF_REG', field: 'establishment.pfRegistrationNumber',
      message: 'EPF registration number is required. Configure in tenant settings.', severity: 'blocking' });
  }
  if (!ecr.establishment.establishmentName?.trim()) {
    blocking.push({ code: 'MISSING_ESTABLISHMENT_NAME', field: 'establishment.establishmentName',
      message: 'Establishment name is required.', severity: 'blocking' });
  }

  // Members
  if (ecr.members.length === 0) {
    warnings.push({ code: 'NO_MEMBERS', field: 'members',
      message: 'No PF members for this month. NIL return may still be required.', severity: 'warning' });
  }

  for (const m of ecr.members) {
    if (!validateUAN(m.uan)) {
      warnings.push({ code: 'INVALID_UAN', field: `member.${m.employeeId}.uan`,
        employeeId: m.employeeId,
        message: `Employee ${m.name}: UAN "${m.uan}" is invalid. Must be 12 digits.`, severity: 'warning' });
    }
    if (m.epfContributionEmployee < 0 || m.epfContributionEmployer < 0) {
      blocking.push({ code: 'NEGATIVE_CONTRIBUTION', field: `member.${m.employeeId}`,
        employeeId: m.employeeId,
        message: `Employee ${m.name}: Negative PF contribution is invalid.`, severity: 'blocking' });
    }
    if (m.pfWages > PF_WAGE_CEILING + 1) {
      warnings.push({ code: 'PF_WAGES_EXCEED_CEILING', field: `member.${m.employeeId}.pfWages`,
        employeeId: m.employeeId,
        message: `Employee ${m.name}: PF wages ₹${m.pfWages} exceed ceiling ₹${PF_WAGE_CEILING}. Verify if this is VPF.`, severity: 'warning' });
    }
  }

  // Admin charge minimum
  if (ecr.totals.totalAdminCharge < PF_ADMIN_CHARGE_MINIMUM && ecr.members.length > 0) {
    warnings.push({ code: 'ADMIN_CHARGE_BELOW_MINIMUM', field: 'totals.adminCharge',
      message: `Admin charge ₹${ecr.totals.totalAdminCharge} is below minimum ₹${PF_ADMIN_CHARGE_MINIMUM}.`, severity: 'warning' });
  }

  return { isValid: blocking.length === 0, blockingErrors: blocking, warnings };
}

export function validateEsiInput(esi: EsiContributionRecord): {
  isValid: boolean;
  blockingErrors: FilingValidationError[];
  warnings: FilingValidationError[];
} {
  const blocking: FilingValidationError[] = [];
  const warnings: FilingValidationError[] = [];

  if (!esi.establishment.esiRegistrationNumber) {
    warnings.push({ code: 'MISSING_ESI_REG', field: 'establishment.esiRegistrationNumber',
      message: 'ESI registration number not configured. Required for filing.', severity: 'warning' });
  }

  for (const m of esi.members) {
    if (!m.esiInsuranceNumber) {
      warnings.push({ code: 'MISSING_IP_NUMBER', field: `member.${m.employeeId}.esiInsuranceNumber`,
        employeeId: m.employeeId,
        message: `Employee ${m.name}: ESI IP number not assigned. Apply via ESIC portal.`, severity: 'warning' });
    }
    if (m.esiWages > ESI_WAGE_LIMIT) {
      blocking.push({ code: 'ESI_WAGE_OVER_LIMIT', field: `member.${m.employeeId}.esiWages`,
        employeeId: m.employeeId,
        message: `Employee ${m.name}: ESI wages ₹${m.esiWages} exceed ₹${ESI_WAGE_LIMIT} limit but is marked ESI-applicable.`, severity: 'blocking' });
    }
  }

  return { isValid: blocking.length === 0, blockingErrors: blocking, warnings };
}

// ─────────────────────────────────────────────────────────────────────────────
// DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────

export interface MonthlyStatutoryDashboard {
  wageMonth: string;
  pf: {
    totalMembers: number;
    totalPayable: number;
    status: 'not_started' | 'generated' | 'submitted' | 'paid';
    dueDate: string;
  };
  esi: {
    totalMembers: number;
    totalPayable: number;
    status: 'not_started' | 'generated' | 'submitted' | 'paid';
    dueDate: string;
  };
  pt: {
    totalEmployees: number;
    totalPayable: number;
    stateCode: string;
    dueDate: string;
  };
  totalStatutoryPayable: number;
}

export function buildMonthlyDashboard(
  year: number,
  month: number,
  ecr: EcrRecord | null,
  esi: EsiContributionRecord | null,
  pt: PtReturnRecord | null,
  pfStatus: 'not_started' | 'generated' | 'submitted' | 'paid' = 'not_started',
  esiStatus: 'not_started' | 'generated' | 'submitted' | 'paid' = 'not_started',
): MonthlyStatutoryDashboard {
  const wageMonth = getWageMonth(year, month);
  const pfPayable = ecr?.totals.grandTotalPayable ?? 0;
  const esiPayable = esi?.totals.totalEsiPayable ?? 0;
  const ptPayable = pt?.totals.totalPtPayable ?? 0;

  return {
    wageMonth,
    pf: {
      totalMembers: ecr?.totals.totalMembers ?? 0,
      totalPayable: pfPayable,
      status: pfStatus,
      dueDate: '15th of following month',
    },
    esi: {
      totalMembers: esi?.totals.totalMembers ?? 0,
      totalPayable: esiPayable,
      status: esiStatus,
      dueDate: '21st of following month',
    },
    pt: {
      totalEmployees: pt?.totals.totalEmployees ?? 0,
      totalPayable: ptPayable,
      stateCode: pt?.stateCode ?? '',
      dueDate: pt?.dueDate ?? '',
    },
    totalStatutoryPayable: r2(pfPayable + esiPayable + ptPayable),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// ANNUAL PF SUMMARY (for Form 3A / Annual Return)
// ─────────────────────────────────────────────────────────────────────────────

export interface AnnualPfSummaryEmployee {
  employeeId: string;
  name: string;
  uan: string;
  memberId: string;
  totalEpfEmployee: number;
  totalEpfEmployer: number;
  totalEps: number;
  totalEdli: number;
  totalVpf: number;
  totalPfWages: number;
  months: number;                // Number of months contributed
  ncpDays: number;               // Total NCP days in year
}

export function assembleAnnualPfSummary(
  monthlyEcrs: EcrRecord[],
): AnnualPfSummaryEmployee[] {
  const empMap = new Map<string, AnnualPfSummaryEmployee>();

  for (const ecr of monthlyEcrs) {
    for (const m of ecr.members) {
      const existing = empMap.get(m.employeeId) ?? {
        employeeId: m.employeeId, name: m.name, uan: m.uan,
        memberId: m.memberId ?? '', totalEpfEmployee: 0, totalEpfEmployer: 0,
        totalEps: 0, totalEdli: 0, totalVpf: 0, totalPfWages: 0, months: 0, ncpDays: 0,
      };
      existing.totalEpfEmployee = r2(existing.totalEpfEmployee + m.epfContributionEmployee);
      existing.totalEpfEmployer = r2(existing.totalEpfEmployer + m.epfContributionEmployer);
      existing.totalEps = r2(existing.totalEps + m.epsContribution);
      existing.totalEdli = r2(existing.totalEdli + m.edliContribution);
      existing.totalVpf = r2(existing.totalVpf + m.vpfContribution);
      existing.totalPfWages = r2(existing.totalPfWages + m.pfWages);
      existing.months += 1;
      existing.ncpDays += m.ncpDays;
      empMap.set(m.employeeId, existing);
    }
  }

  return [...empMap.values()];
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVATE
// ─────────────────────────────────────────────────────────────────────────────

function simpleHash(data: string): string {
  let h = 5381;
  for (let i = 0; i < data.length; i++) {
    h = ((h << 5) + h) + data.charCodeAt(i); h |= 0;
  }
  return Math.abs(h).toString(16).toUpperCase().padStart(8, '0');
}
