/**
 * India Statutory Payroll Computation Engine
 * ─────────────────────────────────────────────
 * Handles: PF (EPF), ESI, Professional Tax (state-wise),
 *          TDS (old/new regime), Gratuity, HRA exemption,
 *          LTA, standard deduction, surcharge
 *
 * All monetary values in INR paise (integer) internally,
 * displayed in rupees with 2 decimal places.
 */

// ─────────────────────────────────────────────
// CONSTANTS  (FY 2024-25)
// ─────────────────────────────────────────────

export const PF_RATE_EMPLOYEE = 0.12;       // 12% of basic
export const PF_RATE_EMPLOYER = 0.12;       // 12% of basic (split: 8.33% EPS + 3.67% EPF)
export const PF_EPS_RATE = 0.0833;          // Employer share to EPS
export const PF_EPF_EMPLOYER_RATE = 0.0367; // Employer share to EPF
export const PF_WAGE_CEILING = 15_000;      // ₹15,000/month statutory ceiling
export const PF_ADMIN_CHARGE = 0.005;       // 0.5% employer admin charge

export const ESI_RATE_EMPLOYEE = 0.0075;    // 0.75%
export const ESI_RATE_EMPLOYER = 0.0325;    // 3.25%
export const ESI_WAGE_LIMIT = 21_000;       // ₹21,000/month gross

export const STANDARD_DEDUCTION = 75_000;   // FY2024-25 budget update

// Professional Tax slabs by state (annual amounts)
export const PT_SLABS: Record<string, Array<{ upTo: number; monthlyPt: number }>> = {
  KA: [ // Karnataka
    { upTo: 15_000, monthlyPt: 0 },
    { upTo: 99_999_999, monthlyPt: 200 }, // ₹200/month (₹2,400/year)
  ],
  MH: [ // Maharashtra
    { upTo: 7_500, monthlyPt: 0 },
    { upTo: 10_000, monthlyPt: 175 },
    { upTo: 99_999_999, monthlyPt: 200 },
  ],
  WB: [ // West Bengal
    { upTo: 10_000, monthlyPt: 0 },
    { upTo: 15_000, monthlyPt: 110 },
    { upTo: 25_000, monthlyPt: 130 },
    { upTo: 40_000, monthlyPt: 150 },
    { upTo: 99_999_999, monthlyPt: 200 },
  ],
  AP: [ // Andhra Pradesh
    { upTo: 15_000, monthlyPt: 0 },
    { upTo: 20_000, monthlyPt: 150 },
    { upTo: 99_999_999, monthlyPt: 200 },
  ],
  TN: [ // Tamil Nadu
    { upTo: 21_000, monthlyPt: 0 },
    { upTo: 30_000, monthlyPt: 135 },
    { upTo: 45_000, monthlyPt: 315 },
    { upTo: 60_000, monthlyPt: 690 },
    { upTo: 75_000, monthlyPt: 1025 },
    { upTo: 99_999_999, monthlyPt: 1250 },
  ],
  TS: [ // Telangana
    { upTo: 15_000, monthlyPt: 0 },
    { upTo: 20_000, monthlyPt: 150 },
    { upTo: 99_999_999, monthlyPt: 200 },
  ],
  GJ: [ // Gujarat (no PT)
    { upTo: 99_999_999, monthlyPt: 0 },
  ],
  DL: [ // Delhi (no PT)
    { upTo: 99_999_999, monthlyPt: 0 },
  ],
};

// TDS — Income Tax Slabs FY 2024-25
// NEW REGIME (default after Budget 2023)
export const NEW_REGIME_SLABS = [
  { upTo: 300_000, rate: 0 },
  { upTo: 600_000, rate: 0.05 },
  { upTo: 900_000, rate: 0.10 },
  { upTo: 1_200_000, rate: 0.15 },
  { upTo: 1_500_000, rate: 0.20 },
  { upTo: 99_999_999, rate: 0.30 },
];

// OLD REGIME
export const OLD_REGIME_SLABS = [
  { upTo: 250_000, rate: 0 },
  { upTo: 500_000, rate: 0.05 },
  { upTo: 1_000_000, rate: 0.20 },
  { upTo: 99_999_999, rate: 0.30 },
];

export const SURCHARGE_SLABS = [
  { upTo: 5_000_000, rate: 0 },
  { upTo: 10_000_000, rate: 0.10 },
  { upTo: 20_000_000, rate: 0.15 },
  { upTo: 50_000_000, rate: 0.25 },
  { upTo: 99_999_999, rate: 0.37 },
];

export const HEALTH_EDUCATION_CESS = 0.04; // 4%

// ─────────────────────────────────────────────
// INPUT / OUTPUT TYPES
// ─────────────────────────────────────────────

export interface SalaryStructure {
  basic: number;           // Monthly basic
  hra: number;             // Monthly HRA
  specialAllowance: number;
  lta: number;             // Monthly LTA component
  medicalAllowance: number;
  otherAllowances: number;
  bonus?: number;          // One-time / periodic
}

export interface PayrollInput {
  employeeId: string;
  month: number;   // 1-12
  year: number;
  salaryStructure: SalaryStructure;
  stateCode: string;  // KA, MH, WB, AP, TN, TS, GJ, DL, etc.
  pfOptIn: boolean;
  esiEligible?: boolean; // Auto-computed from gross
  taxRegime: 'old' | 'new';
  declarationsOld?: {    // Only for old regime
    section80C?: number; // PPF, LIC, etc. (max ₹1.5L)
    section80D?: number; // Medical insurance (max ₹25K self + ₹50K parents)
    hra?: number;        // HRA exemption (computed)
    lta?: number;        // LTA exemption
    nps80CCD1B?: number; // NPS additional (max ₹50K)
  };
  lopDays?: number;   // Loss of pay days
  workingDays?: number; // Default 26
  arrears?: number;
  previousTdsDeducted?: number; // Deducted in earlier months of FY
  previousTaxableIncome?: number; // For annualization
}

export interface PayComponentBreakdown {
  name: string;
  type: 'earning' | 'deduction' | 'employer-contribution' | 'info';
  amount: number;
  isStatutory: boolean;
  description?: string;
}

export interface PayslipComputedData {
  // Earnings
  grossPay: number;
  basicPay: number;
  hraReceived: number;
  specialAllowance: number;
  ltaReceived: number;
  medicalAllowance: number;
  otherAllowances: number;
  bonus: number;
  lopDeduction: number;
  netEarnings: number; // After LOP

  // Employee Deductions
  pfEmployee: number;
  esiEmployee: number;
  professionalTax: number;
  tdsDeducted: number;
  totalDeductions: number;

  // Employer Contributions
  pfEmployer: number;
  pfEps: number;
  esiEmployer: number;
  pfAdminCharge: number;
  totalEmployerCost: number; // CTC component

  // Net
  netPay: number;
  ctcMonthly: number;

  // Tax computation
  annualGross: number;
  hraExemption: number;
  taxableIncome: number;
  annualTax: number;
  monthlyTax: number;
  surcharge: number;
  cess: number;
  effectiveTaxRate: number;

  // Metadata
  pfWage: number;        // Amount on which PF computed
  esiWage: number;
  pfCeiling: number;
  esiApplicable: boolean;
  pfApplicable: boolean;

  components: PayComponentBreakdown[];
}

// ─────────────────────────────────────────────
// CORE ENGINE
// ─────────────────────────────────────────────

export class IndiaPayrollEngine {

  compute(input: PayrollInput): PayslipComputedData {
    const wd = input.workingDays ?? 26;
    const lopDays = Math.min(input.lopDays ?? 0, wd);
    const lopFactor = (wd - lopDays) / wd;

    // ── Step 1: Gross components after LOP ──
    const basic = round2(input.salaryStructure.basic * lopFactor);
    const hra = round2(input.salaryStructure.hra * lopFactor);
    const special = round2(input.salaryStructure.specialAllowance * lopFactor);
    const lta = round2(input.salaryStructure.lta * lopFactor);
    const medical = round2(input.salaryStructure.medicalAllowance * lopFactor);
    const other = round2(input.salaryStructure.otherAllowances * lopFactor);
    const bonus = round2(input.salaryStructure.bonus ?? 0);

    const grossPay = basic + hra + special + lta + medical + other + bonus;
    const lopDeduction = round2(
      (input.salaryStructure.basic + input.salaryStructure.hra +
       input.salaryStructure.specialAllowance + input.salaryStructure.lta +
       input.salaryStructure.medicalAllowance + input.salaryStructure.otherAllowances) * (lopDays / wd),
    );

    // ── Step 2: PF computation ──
    const pfApplicable = input.pfOptIn;
    const pfWage = pfApplicable ? Math.min(basic, PF_WAGE_CEILING) : 0;
    const pfEmployee = pfApplicable ? round2(pfWage * PF_RATE_EMPLOYEE) : 0;
    const pfEmployer = pfApplicable ? round2(pfWage * PF_EPF_EMPLOYER_RATE) : 0;
    const pfEps = pfApplicable ? round2(pfWage * PF_EPS_RATE) : 0;
    const pfAdminCharge = pfApplicable ? round2(pfWage * PF_ADMIN_CHARGE) : 0;

    // ── Step 3: ESI computation ──
    const esiApplicable = (input.esiEligible !== false) && grossPay <= ESI_WAGE_LIMIT;
    const esiWage = esiApplicable ? grossPay : 0;
    const esiEmployee = esiApplicable ? round2(esiWage * ESI_RATE_EMPLOYEE) : 0;
    const esiEmployer = esiApplicable ? round2(esiWage * ESI_RATE_EMPLOYER) : 0;

    // ── Step 4: Professional Tax ──
    const pt = this.computePT(grossPay, input.stateCode);

    // ── Step 5: HRA Exemption (old regime only) ──
    let hraExemption = 0;
    if (input.taxRegime === 'old' && input.declarationsOld?.hra !== undefined) {
      hraExemption = input.declarationsOld.hra;
    } else if (input.taxRegime === 'old') {
      // Auto-compute HRA exemption (least of):
      // 1. HRA received
      // 2. 50% of basic (metro) / 40% of basic (non-metro)
      // 3. Rent paid - 10% of basic (if rent paid)
      // Using 50% metro assumption
      hraExemption = Math.min(hra, basic * 0.5);
    }

    // ── Step 6: TDS / Income Tax ──
    const tdsResult = this.computeTDS({
      input,
      grossPay,
      basic,
      hra,
      hraExemption,
      pfEmployee,
      pt,
    });

    // ── Step 7: Totals ──
    const totalDeductions = pfEmployee + esiEmployee + pt + tdsResult.monthlyTds;
    const netPay = round2(grossPay - totalDeductions);
    const totalEmployerCost = round2(grossPay + pfEmployer + pfEps + pfAdminCharge + esiEmployer);

    // ── Step 8: Build components breakdown ──
    const components: PayComponentBreakdown[] = [
      { name: 'Basic Pay', type: 'earning', amount: basic, isStatutory: false },
      { name: 'House Rent Allowance', type: 'earning', amount: hra, isStatutory: false },
      { name: 'Special Allowance', type: 'earning', amount: special, isStatutory: false },
      ...(lta > 0 ? [{ name: 'Leave Travel Allowance', type: 'earning' as const, amount: lta, isStatutory: false }] : []),
      ...(medical > 0 ? [{ name: 'Medical Allowance', type: 'earning' as const, amount: medical, isStatutory: false }] : []),
      ...(other > 0 ? [{ name: 'Other Allowances', type: 'earning' as const, amount: other, isStatutory: false }] : []),
      ...(bonus > 0 ? [{ name: 'Bonus / Ex-Gratia', type: 'earning' as const, amount: bonus, isStatutory: false }] : []),
      ...(lopDeduction > 0 ? [{ name: 'Loss of Pay', type: 'deduction' as const, amount: -lopDeduction, isStatutory: false, description: `${lopDays} LOP days` }] : []),
      ...(pfEmployee > 0 ? [{ name: 'Provident Fund (Employee)', type: 'deduction' as const, amount: pfEmployee, isStatutory: true, description: `12% of ₹${pfWage.toLocaleString('en-IN')} PF wage` }] : []),
      ...(esiEmployee > 0 ? [{ name: 'ESI (Employee)', type: 'deduction' as const, amount: esiEmployee, isStatutory: true, description: '0.75% of gross' }] : []),
      ...(pt > 0 ? [{ name: 'Professional Tax', type: 'deduction' as const, amount: pt, isStatutory: true, description: `${input.stateCode} state PT` }] : []),
      ...(tdsResult.monthlyTds > 0 ? [{ name: 'TDS (Income Tax)', type: 'deduction' as const, amount: tdsResult.monthlyTds, isStatutory: true, description: `${input.taxRegime.toUpperCase()} regime` }] : []),
      ...(pfEmployer > 0 ? [{ name: 'Provident Fund (Employer)', type: 'employer-contribution' as const, amount: pfEmployer, isStatutory: true }] : []),
      ...(pfEps > 0 ? [{ name: 'EPS (Employer)', type: 'employer-contribution' as const, amount: pfEps, isStatutory: true }] : []),
      ...(esiEmployer > 0 ? [{ name: 'ESI (Employer)', type: 'employer-contribution' as const, amount: esiEmployer, isStatutory: true }] : []),
      { name: 'Net Pay', type: 'info', amount: netPay, isStatutory: false },
    ];

    return {
      grossPay,
      basicPay: basic,
      hraReceived: hra,
      specialAllowance: special,
      ltaReceived: lta,
      medicalAllowance: medical,
      otherAllowances: other,
      bonus,
      lopDeduction,
      netEarnings: grossPay - lopDeduction,

      pfEmployee,
      esiEmployee,
      professionalTax: pt,
      tdsDeducted: tdsResult.monthlyTds,
      totalDeductions,

      pfEmployer,
      pfEps,
      esiEmployer,
      pfAdminCharge,
      totalEmployerCost,

      netPay,
      ctcMonthly: totalEmployerCost,

      annualGross: tdsResult.annualGross,
      hraExemption,
      taxableIncome: tdsResult.taxableIncome,
      annualTax: tdsResult.annualTax,
      monthlyTax: tdsResult.monthlyTds,
      surcharge: tdsResult.surcharge,
      cess: tdsResult.cess,
      effectiveTaxRate: tdsResult.annualGross > 0
        ? round2((tdsResult.annualTax / tdsResult.annualGross) * 100)
        : 0,

      pfWage,
      esiWage,
      pfCeiling: PF_WAGE_CEILING,
      esiApplicable,
      pfApplicable,

      components,
    };
  }

  // ─────────────────────────────────────────────
  // PROFESSIONAL TAX
  // ─────────────────────────────────────────────

  computePT(monthlyGross: number, stateCode: string): number {
    const slabs = PT_SLABS[stateCode] ?? PT_SLABS['KA']!;
    for (const slab of slabs) {
      if (monthlyGross <= slab.upTo) return slab.monthlyPt;
    }
    return 0;
  }

  // ─────────────────────────────────────────────
  // TDS / INCOME TAX
  // ─────────────────────────────────────────────

  private computeTDS(ctx: {
    input: PayrollInput;
    grossPay: number;
    basic: number;
    hra: number;
    hraExemption: number;
    pfEmployee: number;
    pt: number;
  }): { monthlyTds: number; annualGross: number; taxableIncome: number; annualTax: number; surcharge: number; cess: number } {
    const { input, grossPay, hraExemption, pfEmployee, pt } = ctx;

    // Annualize remaining months
    const monthsRemaining = 12 - input.month + 1;
    const monthsElapsed = input.month - 1;

    const projectedAnnualGross = round2(
      (input.previousTaxableIncome ?? 0) + (grossPay * monthsRemaining) + (input.arrears ?? 0),
    );

    // ── Old Regime deductions ──
    let deductions = 0;
    if (input.taxRegime === 'old') {
      const d = input.declarationsOld ?? {};
      deductions += Math.min(d.section80C ?? 0, 150_000);
      deductions += Math.min(d.section80D ?? 0, 75_000); // self 25K + parents 50K
      deductions += Math.min(d.nps80CCD1B ?? 0, 50_000);
      deductions += hraExemption * 12;
      deductions += STANDARD_DEDUCTION;
      deductions += Math.min(d.lta ?? 0, 36_000);
      // PF employee contribution deductible under 80C (part of 1.5L cap)
      // Already included in section80C typically, so not double-counted
    }

    // ── New Regime ──
    if (input.taxRegime === 'new') {
      deductions = STANDARD_DEDUCTION; // ₹75,000 from Budget 2024
    }

    const taxableIncome = Math.max(0, projectedAnnualGross - deductions);

    // ── Tax computation ──
    const slabs = input.taxRegime === 'new' ? NEW_REGIME_SLABS : OLD_REGIME_SLABS;
    let annualTax = this.computeSlabTax(taxableIncome, slabs);

    // ── Rebate u/s 87A ──
    // New regime: rebate up to ₹25,000 if income ≤ ₹7L
    // Old regime: rebate up to ₹12,500 if income ≤ ₹5L
    if (input.taxRegime === 'new' && taxableIncome <= 700_000) {
      annualTax = Math.max(0, annualTax - 25_000);
    } else if (input.taxRegime === 'old' && taxableIncome <= 500_000) {
      annualTax = Math.max(0, annualTax - 12_500);
    }

    // ── Surcharge ──
    const surcharge = this.computeSurcharge(annualTax, taxableIncome);
    const taxWithSurcharge = annualTax + surcharge;

    // ── Health & Education Cess ──
    const cess = round2(taxWithSurcharge * HEALTH_EDUCATION_CESS);
    const totalAnnualTax = round2(taxWithSurcharge + cess);

    // ── Monthly TDS ──
    const taxYetToDeduce = Math.max(0, totalAnnualTax - (input.previousTdsDeducted ?? 0));
    const monthlyTds = monthsRemaining > 0 ? round2(taxYetToDeduce / monthsRemaining) : 0;

    return {
      monthlyTds,
      annualGross: projectedAnnualGross,
      taxableIncome,
      annualTax: totalAnnualTax,
      surcharge,
      cess,
    };
  }

  private computeSlabTax(income: number, slabs: Array<{ upTo: number; rate: number }>): number {
    let tax = 0;
    let prev = 0;
    for (const slab of slabs) {
      if (income <= prev) break;
      const taxableInSlab = Math.min(income, slab.upTo) - prev;
      tax += taxableInSlab * slab.rate;
      prev = slab.upTo;
    }
    return round2(tax);
  }

  private computeSurcharge(tax: number, income: number): number {
    let rate = 0;
    for (const slab of SURCHARGE_SLABS) {
      if (income <= slab.upTo) { rate = slab.rate; break; }
    }
    return round2(tax * rate);
  }

  // ─────────────────────────────────────────────
  // GRATUITY
  // ─────────────────────────────────────────────

  computeGratuity(basicLastDrawn: number, yearsOfService: number): number {
    if (yearsOfService < 5) return 0;
    // Gratuity = (Basic + DA) × 15/26 × Years of Service
    return round2(basicLastDrawn * (15 / 26) * yearsOfService);
  }

  // ─────────────────────────────────────────────
  // FULL & FINAL SETTLEMENT
  // ─────────────────────────────────────────────

  computeFnF(params: {
    basic: number;
    yearsOfService: number;
    earnedLeaveBalance: number; // days
    noticePeriodShortfall?: number; // days
    otherRecoveries?: number;
    otherPayouts?: number;
  }): {
    gratuity: number;
    earnedLeaveEncashment: number;
    noticePeriodRecovery: number;
    totalPayable: number;
  } {
    const gratuity = this.computeGratuity(params.basic, params.yearsOfService);

    // Leave encashment: Basic/30 × EL balance (max 30 days usually)
    const earnedLeaveEncashment = round2((params.basic / 30) * Math.min(params.earnedLeaveBalance, 30));

    // Notice period shortfall recovery
    const noticePeriodRecovery = params.noticePeriodShortfall
      ? round2((params.basic / 30) * params.noticePeriodShortfall)
      : 0;

    const totalPayable = round2(
      gratuity +
      earnedLeaveEncashment +
      (params.otherPayouts ?? 0) -
      noticePeriodRecovery -
      (params.otherRecoveries ?? 0),
    );

    return { gratuity, earnedLeaveEncashment, noticePeriodRecovery, totalPayable };
  }
}

// ─────────────────────────────────────────────
// UTILITY
// ─────────────────────────────────────────────

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

export const payrollEngine = new IndiaPayrollEngine();
