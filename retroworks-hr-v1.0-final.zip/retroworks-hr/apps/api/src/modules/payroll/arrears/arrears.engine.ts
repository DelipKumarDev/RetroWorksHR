/**
 * RetroWorks HR — Salary Revision, Arrears & Section 89 Relief Engine
 * ═══════════════════════════════════════════════════════════════════════════
 * Pure TypeScript functions for:
 *
 *   ▸ Retrospective salary revision + per-month arrear computation
 *   ▸ Section 89(1) relief — tax saved by spreading arrears across prior FYs
 *   ▸ Form 10E computation — required to claim Section 89 relief from AO
 *   ▸ Revised TDS projection — post-arrear monthly deduction schedule
 *   ▸ Arrear payslip generation
 *
 * Legal basis:
 *   ▸ Section 89(1), Income Tax Act 1961
 *   ▸ Rule 21A, Income Tax Rules 1962
 *   ▸ Form 10E (mandatory to claim relief — ITD circular)
 *   ▸ CBDT Circular No. 13/2017 (online Form 10E mandatory)
 *
 * Key principle — Section 89(1):
 *   If arrears received in current FY relate to past FY(s), the taxpayer can
 *   claim relief equal to the EXTRA tax paid on those arrears in the current
 *   year vs what they would have paid in the relevant past years.
 *   Relief = Tax(current income) − Tax(current income − arrear) − Tax(past income + arrear) + Tax(past income)
 *
 * ⚠️  DISCLAIMER: Section 89 computation is for employer payroll processing only.
 *     The employee must file Form 10E independently on the Income Tax portal
 *     (https://www.incometax.gov.in) BEFORE filing ITR to claim this relief.
 *     Employer deducting less TDS based on Section 89 does NOT substitute for
 *     employee filing Form 10E.
 * ═══════════════════════════════════════════════════════════════════════════
 */

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS + HISTORICAL TAX CONFIGS
// ─────────────────────────────────────────────────────────────────────────────

/** Historical FY configs for Section 89 backward computation. */
export const HISTORICAL_FY_CONFIGS: Record<string, HistoricalFyConfig> = {
  '2024-25': {
    financialYear: '2024-25',
    assessmentYear: '2025-26',
    standardDeductionNew: 75_000,
    standardDeductionOld: 50_000,
    max87AThresholdNew: 7_00_000,
    max87ARebateNew: 25_000,
    max87AThresholdOld: 5_00_000,
    max87ARebateOld: 12_500,
    cessRate: 0.04,
    newRegimeSlabs: [
      { from: 0,        to: 3_00_000, rate: 0 },
      { from: 3_00_001, to: 6_00_000, rate: 0.05 },
      { from: 6_00_001, to: 9_00_000, rate: 0.10 },
      { from: 9_00_001, to: 12_00_000, rate: 0.15 },
      { from: 12_00_001, to: 15_00_000, rate: 0.20 },
      { from: 15_00_001, to: 999_999_999, rate: 0.30 },
    ],
    oldRegimeSlabs: [
      { from: 0,        to: 2_50_000, rate: 0 },
      { from: 2_50_001, to: 5_00_000, rate: 0.05 },
      { from: 5_00_001, to: 10_00_000, rate: 0.20 },
      { from: 10_00_001, to: 999_999_999, rate: 0.30 },
    ],
  },
  '2023-24': {
    financialYear: '2023-24',
    assessmentYear: '2024-25',
    standardDeductionNew: 50_000,  // Budget 2023 (₹75K only from FY24-25)
    standardDeductionOld: 50_000,
    max87AThresholdNew: 7_00_000,
    max87ARebateNew: 25_000,
    max87AThresholdOld: 5_00_000,
    max87ARebateOld: 12_500,
    cessRate: 0.04,
    newRegimeSlabs: [
      { from: 0,        to: 3_00_000, rate: 0 },
      { from: 3_00_001, to: 6_00_000, rate: 0.05 },
      { from: 6_00_001, to: 9_00_000, rate: 0.10 },
      { from: 9_00_001, to: 12_00_000, rate: 0.15 },
      { from: 12_00_001, to: 15_00_000, rate: 0.20 },
      { from: 15_00_001, to: 999_999_999, rate: 0.30 },
    ],
    oldRegimeSlabs: [
      { from: 0,        to: 2_50_000, rate: 0 },
      { from: 2_50_001, to: 5_00_000, rate: 0.05 },
      { from: 5_00_001, to: 10_00_000, rate: 0.20 },
      { from: 10_00_001, to: 999_999_999, rate: 0.30 },
    ],
  },
  '2022-23': {
    financialYear: '2022-23',
    assessmentYear: '2023-24',
    standardDeductionNew: 0,       // New regime introduced FY22-23 (no std deduction then)
    standardDeductionOld: 50_000,
    max87AThresholdNew: 5_00_000,
    max87ARebateNew: 12_500,
    max87AThresholdOld: 5_00_000,
    max87ARebateOld: 12_500,
    cessRate: 0.04,
    newRegimeSlabs: [
      { from: 0,        to: 2_50_000, rate: 0 },
      { from: 2_50_001, to: 5_00_000, rate: 0.05 },
      { from: 5_00_001, to: 7_50_000, rate: 0.10 },
      { from: 7_50_001, to: 10_00_000, rate: 0.15 },
      { from: 10_00_001, to: 12_50_000, rate: 0.20 },
      { from: 12_50_001, to: 15_00_000, rate: 0.25 },
      { from: 15_00_001, to: 999_999_999, rate: 0.30 },
    ],
    oldRegimeSlabs: [
      { from: 0,        to: 2_50_000, rate: 0 },
      { from: 2_50_001, to: 5_00_000, rate: 0.05 },
      { from: 5_00_001, to: 10_00_000, rate: 0.20 },
      { from: 10_00_001, to: 999_999_999, rate: 0.30 },
    ],
  },
  '2021-22': {
    financialYear: '2021-22',
    assessmentYear: '2022-23',
    standardDeductionNew: 0,
    standardDeductionOld: 50_000,
    max87AThresholdNew: 5_00_000,
    max87ARebateNew: 12_500,
    max87AThresholdOld: 5_00_000,
    max87ARebateOld: 12_500,
    cessRate: 0.04,
    newRegimeSlabs: [
      { from: 0,        to: 2_50_000, rate: 0 },
      { from: 2_50_001, to: 5_00_000, rate: 0.05 },
      { from: 5_00_001, to: 7_50_000, rate: 0.10 },
      { from: 7_50_001, to: 10_00_000, rate: 0.15 },
      { from: 10_00_001, to: 12_50_000, rate: 0.20 },
      { from: 12_50_001, to: 15_00_000, rate: 0.25 },
      { from: 15_00_001, to: 999_999_999, rate: 0.30 },
    ],
    oldRegimeSlabs: [
      { from: 0,        to: 2_50_000, rate: 0 },
      { from: 2_50_001, to: 5_00_000, rate: 0.05 },
      { from: 5_00_001, to: 10_00_000, rate: 0.20 },
      { from: 10_00_001, to: 999_999_999, rate: 0.30 },
    ],
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────────────────────

export interface TaxSlab {
  from: number;
  to: number;
  rate: number;
}

export interface HistoricalFyConfig {
  financialYear: string;
  assessmentYear: string;
  standardDeductionNew: number;
  standardDeductionOld: number;
  max87AThresholdNew: number;
  max87ARebateNew: number;
  max87AThresholdOld: number;
  max87ARebateOld: number;
  cessRate: number;
  newRegimeSlabs: TaxSlab[];
  oldRegimeSlabs: TaxSlab[];
}

export interface SalaryRevisionInput {
  employeeId: string;
  employeeName: string;
  pan: string;
  regimeType: 'old' | 'new';
  effectiveFrom: string;         // ISO date — revision effective from this date
  revisionAnnouncedDate: string; // When revision was announced/processed
  currentFinancialYear: string;

  // Old salary structure (pre-revision)
  oldMonthlyBasic: number;
  oldMonthlyHRA: number;
  oldMonthlySpecialAllowance: number;
  oldMonthlyOtherAllowances: number;
  oldMonthlyGross: number;

  // New salary structure (post-revision)
  newMonthlyBasic: number;
  newMonthlyHRA: number;
  newMonthlySpecialAllowance: number;
  newMonthlyOtherAllowances: number;
  newMonthlyGross: number;

  // Annual tax figures (current FY, without arrears)
  currentFyTaxableIncome: number;     // As computed by TDS projection
  currentFyTotalTaxPaid: number;      // TDS already deducted this FY
  currentFyRemainingMonths: number;   // Months left in FY

  // Historical figures for Section 89
  priorFyIncomesAndTax: Array<{
    financialYear: string;
    taxableIncome: number;          // Income actually earned that FY
    taxActuallyPaid: number;        // Tax actually paid/deducted that FY
  }>;
}

export interface ArrearsMonthBreakdown {
  month: number;       // Calendar month
  year: number;
  financialYear: string;
  oldGross: number;
  newGross: number;
  arrearAmount: number;
  // Component-wise
  basicArrear: number;
  hraArrear: number;
  specialArrear: number;
  otherArrear: number;
}

export interface ArrearsComputationResult {
  employeeId: string;
  employeeName: string;
  effectiveFrom: string;
  revisionAnnouncedDate: string;

  // Month-by-month arrear breakdown
  monthwiseArrears: ArrearsMonthBreakdown[];

  // Totals
  totalArrearAmount: number;
  totalBasicArrear: number;
  totalHraArrear: number;
  totalSpecialArrear: number;
  totalOtherArrear: number;
  arrearsPerFy: Record<string, number>;  // FY → arrear amount in that FY

  // Tax impact (without Section 89 relief)
  additionalTaxWithoutRelief: number;

  // Section 89(1) relief
  section89Relief: Section89Relief | null;

  // Revised TDS schedule
  revisedMonthlyTds: number;
  additionalTdsToRecover: number;  // (totalTaxDue - section89Relief - alreadyDeducted) / remainingMonths
}

export interface Section89Relief {
  // The Formula per Rule 21A:
  // Relief = A − B − C + D
  // A = Tax on (currentIncome + arrears) in current FY
  // B = Tax on currentIncome in current FY (without arrears)
  // C = Tax on (pastIncome + pastFyArrear) in relevant past FY
  // D = Tax on pastIncome in relevant past FY

  financialYear: string;        // Current FY
  totalArrearAmount: number;

  // FY-wise Section 89 workings
  fyWise: Array<{
    financialYear: string;
    arrearRelatingToFy: number;
    taxWithArrear: number;       // Tax on (pastIncome + arrear)
    taxWithoutArrear: number;    // Tax on pastIncome
    excessTax: number;           // = taxWithArrear − taxWithoutArrear  (C − D per FY)
  }>;

  // Current year tax impact
  taxInCurrentYearWithArrear: number;    // A — Tax on total income + arrears
  taxInCurrentYearWithoutArrear: number; // B — Tax on income without arrears

  extraTaxInCurrentYear: number;          // A − B (additional burden from arrears)
  excessTaxInPriorYears: number;          // Sum of (C − D) across all relevant FYs
  section89ReliefAmount: number;          // = (A − B) − (C − D sum), if positive; else 0
  isReliefAvailable: boolean;
  netTaxAfterRelief: number;

  // Form 10E reference
  form10ERequired: boolean;
  form10ENote: string;
}

export interface RevisedTdsSchedule {
  employeeId: string;
  financialYear: string;
  totalAnnualTaxLiability: number;
  section89ReliefApplied: number;
  netTaxAfterRelief: number;
  alreadyDeductedTds: number;
  remainingTdsToDeduct: number;
  remainingMonths: number;
  revisedMonthlyTds: number;
  schedule: Array<{
    month: number;
    year: number;
    salaryMonth: string;
    monthlyTds: number;
    cumulativeTds: number;
  }>;
}

export interface Form10EComputation {
  employeeId: string;
  employeeName: string;
  pan: string;
  assessmentYear: string;          // Current AY e.g. "2025-26"
  financialYear: string;
  totalArrearAmount: number;
  arrearsReceivedInAY: string;     // Assessment year when arrear received

  // Table A: Annexure I details per prior FY
  annexureI: Array<{
    year: string;                  // Prior FY e.g. "2023-24"
    arrearAmount: number;
    totalIncomeWithArrear: number;
    taxOnTotalWithArrear: number;
    totalIncomeWithout: number;
    taxOnTotalWithout: number;
    differentialTax: number;       // Column 7 − Column 6 in Form 10E
  }>;

  // Main computation
  totalDifferentialTax: number;    // Sum of differential from all relevant years
  taxOnTotalIncomeCurrentYear: number;   // Column 4 in Form 10E
  taxOnIncomeExcludingArrear: number;    // Column 5 in Form 10E
  section89ReliefAmount: number;         // Column 6 = min(4−5, totalDifferential)
  disclaimer: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

export function r2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function ri(n: number): number {
  return Math.round(n);
}

/**
 * Compute slab-wise income tax from a list of tax slabs.
 * Returns total tax before cess/surcharge.
 */
export function computeSlabTax(taxableIncome: number, slabs: TaxSlab[]): number {
  let tax = 0;
  for (const slab of slabs) {
    if (taxableIncome <= 0) break;
    const slabStart = slab.from === 0 ? 0 : slab.from;
    const incomeInSlab = Math.min(taxableIncome, slab.to) - slabStart + (slab.from === 0 ? 0 : 1);
    if (incomeInSlab > 0 && taxableIncome > slab.from) {
      const applicable = Math.min(taxableIncome, slab.to) - Math.max(0, slab.from);
      tax += r2(applicable * slab.rate);
    }
  }
  return r2(tax);
}

/**
 * Compute total tax on income for a given FY and regime.
 * Returns: { taxBeforeCess, rebate87A, cess, totalTax }
 */
export function computeTaxForFy(
  taxableIncome: number,
  regime: 'old' | 'new',
  fyConfig: HistoricalFyConfig,
): {
  taxableIncome: number;
  taxBeforeCess: number;
  rebate87A: number;
  cess: number;
  totalTax: number;
} {
  if (taxableIncome <= 0) {
    return { taxableIncome: 0, taxBeforeCess: 0, rebate87A: 0, cess: 0, totalTax: 0 };
  }

  const slabs = regime === 'new' ? fyConfig.newRegimeSlabs : fyConfig.oldRegimeSlabs;
  const stdDed = regime === 'new' ? fyConfig.standardDeductionNew : fyConfig.standardDeductionOld;

  // Apply standard deduction (already reflected in taxableIncome param — caller handles it)
  const taxOnIncome = computeSlabTax(taxableIncome, slabs);

  // Section 87A rebate
  const rebateThreshold = regime === 'new' ? fyConfig.max87AThresholdNew : fyConfig.max87AThresholdOld;
  const maxRebate = regime === 'new' ? fyConfig.max87ARebateNew : fyConfig.max87ARebateOld;
  const rebate87A = taxableIncome <= rebateThreshold ? Math.min(taxOnIncome, maxRebate) : 0;

  const taxAfterRebate = Math.max(0, r2(taxOnIncome - rebate87A));
  const cess = r2(taxAfterRebate * fyConfig.cessRate);
  const totalTax = r2(taxAfterRebate + cess);

  return { taxableIncome, taxBeforeCess: taxOnIncome, rebate87A, cess, totalTax };
}

/** Get the financial year string for a given calendar month + year (India FY: Apr–Mar) */
export function getFyForMonth(calMonth: number, calYear: number): string {
  const fyStart = calMonth >= 4 ? calYear : calYear - 1;
  return `${fyStart}-${String(fyStart + 1).slice(2)}`;
}

/** Count calendar months between two dates (inclusive) */
export function monthsBetween(fromDate: Date, toDate: Date): number {
  return (toDate.getFullYear() - fromDate.getFullYear()) * 12 +
    (toDate.getMonth() - fromDate.getMonth()) + 1;
}

/** Get all months between two dates as {year, month} */
export function getMonthRange(from: Date, to: Date): Array<{ year: number; month: number }> {
  const months: Array<{ year: number; month: number }> = [];
  const cur = new Date(from.getFullYear(), from.getMonth(), 1);
  const end = new Date(to.getFullYear(), to.getMonth(), 1);
  while (cur <= end) {
    months.push({ year: cur.getFullYear(), month: cur.getMonth() + 1 });
    cur.setMonth(cur.getMonth() + 1);
  }
  return months;
}

// ─────────────────────────────────────────────────────────────────────────────
// ARREAR COMPUTATION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute month-by-month arrear amount from salary revision.
 * Works for retrospective revisions — effective date can be in a prior FY.
 */
export function computeArrearsMonthwise(input: {
  effectiveFrom: string;         // ISO date
  processedDate: string;         // Date arrear is being paid
  oldMonthlyGross: number;
  newMonthlyGross: number;
  oldMonthlyBasic: number;
  newMonthlyBasic: number;
  oldMonthlyHRA: number;
  newMonthlyHRA: number;
  oldMonthlySpecial: number;
  newMonthlySpecial: number;
  oldMonthlyOther: number;
  newMonthlyOther: number;
}): {
  monthwiseArrears: ArrearsMonthBreakdown[];
  totalArrear: number;
  arrearsPerFy: Record<string, number>;
} {
  const from = new Date(input.effectiveFrom);
  // Up to last month (not current — current month gets the new salary directly)
  const to = new Date(input.processedDate);
  to.setDate(1);
  to.setMonth(to.getMonth() - 1);

  const months = getMonthRange(from, to);
  const monthwiseArrears: ArrearsMonthBreakdown[] = [];
  const arrearsPerFy: Record<string, number> = {};
  let totalArrear = 0;

  for (const { year, month } of months) {
    const fy = getFyForMonth(month, year);
    const diff = r2(input.newMonthlyGross - input.oldMonthlyGross);
    if (diff <= 0) continue; // Salary cut — no arrear

    const arrearEntry: ArrearsMonthBreakdown = {
      month, year, financialYear: fy,
      oldGross: input.oldMonthlyGross,
      newGross: input.newMonthlyGross,
      arrearAmount: diff,
      basicArrear: r2(input.newMonthlyBasic - input.oldMonthlyBasic),
      hraArrear: r2(input.newMonthlyHRA - input.oldMonthlyHRA),
      specialArrear: r2(input.newMonthlySpecial - input.oldMonthlySpecial),
      otherArrear: r2(input.newMonthlyOther - input.oldMonthlyOther),
    };

    monthwiseArrears.push(arrearEntry);
    arrearsPerFy[fy] = r2((arrearsPerFy[fy] ?? 0) + diff);
    totalArrear = r2(totalArrear + diff);
  }

  return { monthwiseArrears, totalArrear, arrearsPerFy };
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION 89(1) RELIEF COMPUTATION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute Section 89(1) relief per Rule 21A.
 *
 * The relief allows an employee to pay tax as if the arrear income was
 * received in the FY it actually related to, rather than the FY of receipt.
 *
 * Formula per Annexure I of Form 10E:
 *   For each prior FY the arrear relates to:
 *     C_fy = Tax(priorIncome + arrear_fy) − Tax(priorIncome)  [extra tax in prior FY]
 *
 *   A = Tax(currentIncome + totalArrear) in current FY
 *   B = Tax(currentIncome) in current FY
 *   ExtraInCurrentYear = A − B
 *
 *   Relief = ExtraInCurrentYear − Sum(C_fy)
 *   If Relief < 0 → no relief available
 */
export function computeSection89Relief(params: {
  regime: 'old' | 'new';
  currentFyConfig: HistoricalFyConfig;
  currentFyTaxableIncome: number;       // Taxable income WITHOUT arrears
  totalArrearAmount: number;
  arrearsPerFy: Record<string, number>; // FY → arrear amount
  priorFyIncomesAndTax: Array<{
    financialYear: string;
    taxableIncome: number;              // That FY's income WITHOUT arrear
    taxActuallyPaid: number;
  }>;
}): Section89Relief {
  const {
    regime, currentFyConfig, currentFyTaxableIncome,
    totalArrearAmount, arrearsPerFy, priorFyIncomesAndTax,
  } = params;

  const currentFy = currentFyConfig.financialYear;

  // A — Tax on (current income + all arrears)
  const incomeWithArrear = currentFyTaxableIncome + totalArrearAmount;
  const taxA = computeTaxForFy(incomeWithArrear, regime, currentFyConfig);

  // B — Tax on current income (without arrears)
  const taxB = computeTaxForFy(currentFyTaxableIncome, regime, currentFyConfig);

  const extraTaxInCurrentYear = r2(taxA.totalTax - taxB.totalTax);

  // C_fy − D_fy for each prior FY
  const fyWise: Section89Relief['fyWise'] = [];
  let totalExcessInPriorYears = 0;

  for (const [fy, arrearForFy] of Object.entries(arrearsPerFy)) {
    if (arrearForFy <= 0) continue;

    const priorFyData = priorFyIncomesAndTax.find(p => p.financialYear === fy);
    const priorFyConfig = HISTORICAL_FY_CONFIGS[fy];

    if (!priorFyData || !priorFyConfig) {
      // If we don't have prior FY data, skip (conservative — no relief for unknown FY)
      fyWise.push({
        financialYear: fy,
        arrearRelatingToFy: arrearForFy,
        taxWithArrear: 0,
        taxWithoutArrear: 0,
        excessTax: 0,
      });
      continue;
    }

    // C — Tax on (prior FY income + this FY's arrear portion)
    const taxC = computeTaxForFy(
      priorFyData.taxableIncome + arrearForFy,
      regime,
      priorFyConfig,
    );

    // D — Tax on prior FY income (without arrear)
    const taxD = computeTaxForFy(priorFyData.taxableIncome, regime, priorFyConfig);

    const excessTax = r2(Math.max(0, taxC.totalTax - taxD.totalTax));
    totalExcessInPriorYears = r2(totalExcessInPriorYears + excessTax);

    fyWise.push({
      financialYear: fy,
      arrearRelatingToFy: arrearForFy,
      taxWithArrear: taxC.totalTax,
      taxWithoutArrear: taxD.totalTax,
      excessTax,
    });
  }

  // Relief = Extra tax in current year − Sum of excess in prior years
  const rawRelief = r2(extraTaxInCurrentYear - totalExcessInPriorYears);
  const section89ReliefAmount = Math.max(0, rawRelief);
  const isReliefAvailable = section89ReliefAmount > 0;
  const netTaxAfterRelief = r2(taxA.totalTax - section89ReliefAmount);

  return {
    financialYear: currentFy,
    totalArrearAmount,
    fyWise,
    taxInCurrentYearWithArrear: taxA.totalTax,
    taxInCurrentYearWithoutArrear: taxB.totalTax,
    extraTaxInCurrentYear,
    excessTaxInPriorYears: totalExcessInPriorYears,
    section89ReliefAmount,
    isReliefAvailable,
    netTaxAfterRelief,
    form10ERequired: isReliefAvailable,
    form10ENote: isReliefAvailable
      ? '⚠️ Employee MUST file Form 10E on Income Tax Portal (https://www.incometax.gov.in) BEFORE filing ITR to claim this relief. Employer cannot file on behalf of employee.'
      : 'No Section 89(1) relief available. Arrears are taxable in year of receipt.',
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// REVISED TDS SCHEDULE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute revised monthly TDS after arrear processing.
 * The remaining additional TDS is spread equally over remaining FY months.
 */
export function computeRevisedTdsSchedule(params: {
  employeeId: string;
  financialYear: string;
  totalAnnualTaxLiability: number;  // Including arrears in current FY
  section89ReliefAmount: number;
  alreadyDeductedTds: number;
  remainingMonths: number;
  startMonth: number;                // Calendar month where revised TDS starts
  startYear: number;
}): RevisedTdsSchedule {
  const {
    employeeId, financialYear,
    totalAnnualTaxLiability, section89ReliefAmount,
    alreadyDeductedTds, remainingMonths, startMonth, startYear,
  } = params;

  const netTaxAfterRelief = r2(totalAnnualTaxLiability - section89ReliefAmount);
  const remainingTds = r2(Math.max(0, netTaxAfterRelief - alreadyDeductedTds));
  const monthlyTds = remainingMonths > 0 ? ri(remainingTds / remainingMonths) : 0;

  const schedule: RevisedTdsSchedule['schedule'] = [];
  let cumulative = alreadyDeductedTds;
  let curMonth = startMonth;
  let curYear = startYear;

  for (let i = 0; i < remainingMonths; i++) {
    // Last month gets any rounding residual
    const tdsThisMonth = i === remainingMonths - 1
      ? ri(netTaxAfterRelief - cumulative)
      : monthlyTds;

    cumulative = r2(cumulative + tdsThisMonth);

    const monthName = new Date(curYear, curMonth - 1, 1)
      .toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });

    schedule.push({
      month: curMonth,
      year: curYear,
      salaryMonth: monthName,
      monthlyTds: tdsThisMonth,
      cumulativeTds: cumulative,
    });

    curMonth++;
    if (curMonth > 12) { curMonth = 1; curYear++; }
  }

  return {
    employeeId,
    financialYear,
    totalAnnualTaxLiability,
    section89ReliefApplied: section89ReliefAmount,
    netTaxAfterRelief,
    alreadyDeductedTds,
    remainingTdsToDeduct: remainingTds,
    remainingMonths,
    revisedMonthlyTds: monthlyTds,
    schedule,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// FORM 10E COMPUTATION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Generate Form 10E data (Annexure I — Salary arrears).
 * This data is for the employer's reference and for the employee to file
 * on the Income Tax portal. Employer cannot file Form 10E on behalf of employee.
 */
export function generateForm10EData(params: {
  employeeId: string;
  employeeName: string;
  pan: string;
  currentFinancialYear: string;
  regime: 'old' | 'new';
  currentFyTaxableIncome: number;      // Without arrears
  totalArrearAmount: number;
  arrearsPerFy: Record<string, number>;
  priorFyIncomesAndTax: Array<{
    financialYear: string;
    taxableIncome: number;
  }>;
}): Form10EComputation {
  const {
    employeeId, employeeName, pan,
    currentFinancialYear, regime,
    currentFyTaxableIncome, totalArrearAmount, arrearsPerFy, priorFyIncomesAndTax,
  } = params;

  const ayParts = currentFinancialYear.split('-');
  const currentAY = `20${ayParts[1]}-${String(parseInt(ayParts[1] ?? '25') + 1).padStart(2, '0')}`;

  const currentConfig = HISTORICAL_FY_CONFIGS[currentFinancialYear];
  if (!currentConfig) {
    throw new Error(`No FY config for ${currentFinancialYear}. Check HISTORICAL_FY_CONFIGS.`);
  }

  // Annexure I per prior FY
  const annexureI: Form10EComputation['annexureI'] = [];
  let totalDifferentialTax = 0;

  for (const [fy, arrear] of Object.entries(arrearsPerFy)) {
    if (arrear <= 0) continue;
    const priorData = priorFyIncomesAndTax.find(p => p.financialYear === fy);
    const priorConfig = HISTORICAL_FY_CONFIGS[fy];

    if (!priorData || !priorConfig) continue;

    const taxWith = computeTaxForFy(priorData.taxableIncome + arrear, regime, priorConfig);
    const taxWithout = computeTaxForFy(priorData.taxableIncome, regime, priorConfig);
    const diff = r2(Math.max(0, taxWith.totalTax - taxWithout.totalTax));
    totalDifferentialTax = r2(totalDifferentialTax + diff);

    annexureI.push({
      year: fy,
      arrearAmount: arrear,
      totalIncomeWithArrear: priorData.taxableIncome + arrear,
      taxOnTotalWithArrear: taxWith.totalTax,
      totalIncomeWithout: priorData.taxableIncome,
      taxOnTotalWithout: taxWithout.totalTax,
      differentialTax: diff,
    });
  }

  const taxWithArrear = computeTaxForFy(
    currentFyTaxableIncome + totalArrearAmount, regime, currentConfig,
  );
  const taxWithout = computeTaxForFy(currentFyTaxableIncome, regime, currentConfig);
  const extraCurrentYear = r2(taxWithArrear.totalTax - taxWithout.totalTax);
  const relief = r2(Math.max(0, extraCurrentYear - totalDifferentialTax));

  return {
    employeeId, employeeName, pan,
    assessmentYear: currentAY,
    financialYear: currentFinancialYear,
    totalArrearAmount,
    arrearsReceivedInAY: currentAY,
    annexureI,
    totalDifferentialTax,
    taxOnTotalIncomeCurrentYear: taxWithArrear.totalTax,
    taxOnIncomeExcludingArrear: taxWithout.totalTax,
    section89ReliefAmount: relief,
    disclaimer:
      '⚠️  Employee must file Form 10E on the Income Tax Portal (https://www.incometax.gov.in) ' +
      'under e-File → Income Tax Forms → Form 10E. This must be done BEFORE filing ITR. ' +
      'Failure to file Form 10E will result in rejection of Section 89(1) relief by ITD. ' +
      'Ref: CBDT Circular No. 13/2017 dated 11.04.2017.',
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// FULL ARREAR PROCESSING PIPELINE
// ─────────────────────────────────────────────────────────────────────────────

export function processRevisionAndArrears(input: SalaryRevisionInput): ArrearsComputationResult {
  // Step 1: Compute month-wise arrears
  const { monthwiseArrears, totalArrear, arrearsPerFy } = computeArrearsMonthwise({
    effectiveFrom: input.effectiveFrom,
    processedDate: input.revisionAnnouncedDate,
    oldMonthlyGross: input.oldMonthlyGross,
    newMonthlyGross: input.newMonthlyGross,
    oldMonthlyBasic: input.oldMonthlyBasic,
    newMonthlyBasic: input.newMonthlyBasic,
    oldMonthlyHRA: input.oldMonthlyHRA,
    newMonthlyHRA: input.newMonthlyHRA,
    oldMonthlySpecial: input.oldMonthlySpecialAllowance,
    newMonthlySpecial: input.newMonthlySpecialAllowance,
    oldMonthlyOther: input.oldMonthlyOtherAllowances,
    newMonthlyOther: input.newMonthlyOtherAllowances,
  });

  // Step 2: Section 89 relief
  const currentFyConfig = HISTORICAL_FY_CONFIGS[input.currentFinancialYear];
  let section89Relief: Section89Relief | null = null;
  let additionalTaxWithoutRelief = 0;

  if (totalArrear > 0 && currentFyConfig) {
    section89Relief = computeSection89Relief({
      regime: input.regimeType,
      currentFyConfig,
      currentFyTaxableIncome: input.currentFyTaxableIncome,
      totalArrearAmount: totalArrear,
      arrearsPerFy,
      priorFyIncomesAndTax: input.priorFyIncomesAndTax,
    });

    // Additional tax burden from arrears (before relief)
    additionalTaxWithoutRelief = r2(
      section89Relief.taxInCurrentYearWithArrear - section89Relief.taxInCurrentYearWithoutArrear,
    );
  }

  // Step 3: Revised monthly TDS
  const reliefAmount = section89Relief?.section89ReliefAmount ?? 0;
  const totalTaxWithArrear = section89Relief?.taxInCurrentYearWithArrear ?? 0;
  const netTax = r2(totalTaxWithArrear - reliefAmount);
  const remainingTds = r2(Math.max(0, netTax - input.currentFyTotalTaxPaid));
  const revisedMonthlyTds = input.currentFyRemainingMonths > 0
    ? ri(remainingTds / input.currentFyRemainingMonths)
    : 0;

  const totalBasicArrear = r2(monthwiseArrears.reduce((s, m) => s + m.basicArrear, 0));
  const totalHraArrear = r2(monthwiseArrears.reduce((s, m) => s + m.hraArrear, 0));
  const totalSpecialArrear = r2(monthwiseArrears.reduce((s, m) => s + m.specialArrear, 0));
  const totalOtherArrear = r2(monthwiseArrears.reduce((s, m) => s + m.otherArrear, 0));

  return {
    employeeId: input.employeeId,
    employeeName: input.employeeName,
    effectiveFrom: input.effectiveFrom,
    revisionAnnouncedDate: input.revisionAnnouncedDate,
    monthwiseArrears,
    totalArrearAmount: totalArrear,
    totalBasicArrear,
    totalHraArrear,
    totalSpecialArrear,
    totalOtherArrear,
    arrearsPerFy,
    additionalTaxWithoutRelief,
    section89Relief,
    revisedMonthlyTds,
    additionalTdsToRecover: remainingTds,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// VALIDATION
// ─────────────────────────────────────────────────────────────────────────────

export interface RevisionValidationResult {
  isValid: boolean;
  blockingErrors: Array<{ code: string; message: string }>;
  warnings: Array<{ code: string; message: string }>;
}

export function validateRevisionInput(input: SalaryRevisionInput): RevisionValidationResult {
  const blocking: Array<{ code: string; message: string }> = [];
  const warnings: Array<{ code: string; message: string }> = [];

  const from = new Date(input.effectiveFrom);
  const announced = new Date(input.revisionAnnouncedDate);

  if (isNaN(from.getTime())) {
    blocking.push({ code: 'INVALID_EFFECTIVE_DATE', message: 'effectiveFrom is not a valid date.' });
  }
  if (isNaN(announced.getTime())) {
    blocking.push({ code: 'INVALID_ANNOUNCED_DATE', message: 'revisionAnnouncedDate is not a valid date.' });
  }
  if (from > announced) {
    blocking.push({ code: 'FUTURE_EFFECTIVE_DATE', message: 'effectiveFrom cannot be after revisionAnnouncedDate.' });
  }
  if (input.newMonthlyGross <= input.oldMonthlyGross) {
    warnings.push({ code: 'NO_SALARY_INCREASE', message: 'New gross is not higher than old gross. No positive arrear will be generated.' });
  }
  if (!input.pan || !/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(input.pan)) {
    warnings.push({ code: 'INVALID_PAN', message: 'Employee PAN is missing or invalid. Section 89 relief computation may be incomplete.' });
  }
  if (!HISTORICAL_FY_CONFIGS[input.currentFinancialYear]) {
    blocking.push({ code: 'UNSUPPORTED_FY', message: `Financial year "${input.currentFinancialYear}" is not in HISTORICAL_FY_CONFIGS. Add config to proceed.` });
  }

  const arrearsSpanMoreThanFourYears = (() => {
    const diffMonths = (announced.getFullYear() - from.getFullYear()) * 12 +
      (announced.getMonth() - from.getMonth());
    return diffMonths > 48;
  })();
  if (arrearsSpanMoreThanFourYears) {
    warnings.push({ code: 'LARGE_ARREAR_SPAN', message: 'Arrears span more than 4 years. Section 89 relief may only cover FYs in HISTORICAL_FY_CONFIGS.' });
  }

  if (input.currentFyRemainingMonths <= 0) {
    blocking.push({ code: 'NO_REMAINING_MONTHS', message: 'currentFyRemainingMonths must be > 0 to compute revised TDS schedule.' });
  }

  return { isValid: blocking.length === 0, blockingErrors: blocking, warnings };
}
