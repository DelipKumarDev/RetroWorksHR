/**
 * ArrearsService — Tenant Isolation Integration Tests
 * ══════════════════════════════════════════════════════════════════════════════
 * Attack scenarios:
 *   CT-ARR-01  Cross-tenant salaryRevision READ → NotFoundException
 *   CT-ARR-02  Cross-tenant salaryRevision CREATE → stamped with actor tenantId
 *   CT-ARR-03  Cross-tenant revision processing → NotFoundException (not found under actor scope)
 *   CT-ARR-04  Cross-tenant salaryRevision UPDATE via processRevision → blocked
 *   CT-ARR-05  Cross-tenant arrearEntry CREATE → stamped with actor tenantId
 *   CT-ARR-06  Cross-tenant arrearEntry DELETE → scoped (only actor tenant's entries deleted)
 *   CT-ARR-07  Cross-tenant tDSProjection UPDATE → actor tenant projection only
 *   CT-ARR-08  Cross-tenant payslip CREATE (arrear) → stamped with actor tenantId
 *   CT-ARR-09  getEmployeeRevisions: tenant-B cannot see tenant-A revisions
 *   CT-ARR-10  getTenantRevisions: tenant-B sees only their revisions
 *   CT-ARR-11  Employee cross-tenant check: tenant-B cannot see tenant-A employee
 *   CT-ARR-12  Prior FY data load scoped: tenant-B cannot see tenant-A projections
 *   CT-ARR-13  batchCreateRevisions: each revision stamped with correct tenantId
 *   CT-ARR-14  Empty tenantId → ForbiddenException
 *
 * Run: npx jest arrears.tenant-isolation --verbose --forceExit
 */

import { ForbiddenException, NotFoundException, ConflictException } from '@nestjs/common';
import { ArrearsService, CreateRevisionDto } from '../arrears.service';
import { PrismaTenantService } from '../../../../common/security/prisma-tenant.service';

// ─── Fixtures ─────────────────────────────────────────────────────────────────

const TENANT_A = 'tenant-alpha-arr-001';
const TENANT_B = 'tenant-beta-arr-002';
const EMP_A1   = 'emp-alpha-arr-001';
const EMP_B1   = 'emp-beta-arr-002';
const FY       = '2024-25';
const REV_A1   = 'rev-alpha-arr-001';

const BASE_DTO: Omit<CreateRevisionDto, 'employeeId'> = {
  effectiveFrom:          '2024-04-01',
  revisionAnnouncedDate:  '2024-10-01',
  oldMonthlyBasic:        50000,
  oldMonthlyHRA:          20000,
  oldMonthlySpecialAllowance: 20000,
  oldMonthlyOtherAllowances:  5000,
  oldMonthlyGross:        95000,
  newMonthlyBasic:        60000,
  newMonthlyHRA:          24000,
  newMonthlySpecialAllowance: 24000,
  newMonthlyOtherAllowances:  6000,
  newMonthlyGross:        114000,
  reason:                 'Annual appraisal',
  financialYear:          FY,
};

// ─── In-memory DB ─────────────────────────────────────────────────────────────

interface ArrearsDb {
  salaryRevision: Record<string, any[]>;
  arrearEntry:    Record<string, any[]>;
  employee:       Record<string, any[]>;
  tDSProjection:  Record<string, any[]>;
  payslip:        Record<string, any[]>;
}

function makeDb(): ArrearsDb {
  return {
    salaryRevision: {
      [TENANT_A]: [{ id: REV_A1, tenantId: TENANT_A, employeeId: EMP_A1, effectiveFrom: '2024-04-01', revisionAnnouncedDate: '2024-10-01', financialYear: FY, status: 'pending', oldMonthlyBasic: 50000, oldMonthlyHRA: 20000, oldMonthlySpecialAllowance: 20000, oldMonthlyOtherAllowances: 5000, oldMonthlyGross: 95000, newMonthlyBasic: 60000, newMonthlyHRA: 24000, newMonthlySpecialAllowance: 24000, newMonthlyOtherAllowances: 6000, newMonthlyGross: 114000 }],
      [TENANT_B]: [],
    },
    arrearEntry: {
      [TENANT_A]: [],
      [TENANT_B]: [],
    },
    employee: {
      [TENANT_A]: [{ id: EMP_A1, tenantId: TENANT_A, firstName: 'Arjun', lastName: 'Mehta', employeeCode: 'A001', pan: 'ABCPM1234A', status: 'active', deletedAt: null }],
      [TENANT_B]: [{ id: EMP_B1, tenantId: TENANT_B, firstName: 'Bhavna', lastName: 'Shah',  employeeCode: 'B001', pan: 'XYZBS9876B', status: 'active', deletedAt: null }],
    },
    tDSProjection: {
      [TENANT_A]: [{ id: 'proj-a1', tenantId: TENANT_A, employeeId: EMP_A1, financialYear: FY, regimeType: 'new', projectedAnnualIncome: 1140000, totalTaxLiability: 85000, totalTdsDeducted: 42000, taxableIncome: 1040000, calculationBreakdown: {} }],
      [TENANT_B]: [],
    },
    payslip: {
      [TENANT_A]: [],
      [TENANT_B]: [],
    },
  };
}

function makeScopedModel(db: ArrearsDb, modelKey: keyof ArrearsDb, tenantId: string) {
  const slice = () => ((db[modelKey] as Record<string, any[]>)[tenantId] ?? []) as any[];
  return {
    findFirst: jest.fn((args?: { where?: any; orderBy?: any }) => {
      const match = slice().find(r => {
        if (!args?.where) return true;
        return Object.entries(args.where).every(([k, v]) => {
          if (typeof v === 'object' && v !== null && 'not' in v) return r[k] !== (v as any).not;
          return r[k] === v;
        });
      });
      return Promise.resolve(match ?? null);
    }),
    findMany: jest.fn((args?: { where?: any; orderBy?: any }) => {
      const results = slice().filter(r => {
        if (!args?.where) return true;
        return Object.entries(args.where).every(([k, v]) => {
          if (typeof v === 'object' && v !== null && 'in' in v) return (v as any).in.includes(r[k]);
          if (typeof v === 'object' && v !== null && 'not' in v) return r[k] !== (v as any).not;
          return r[k] === v;
        });
      });
      return Promise.resolve(results);
    }),
    create: jest.fn((args: { data: any }) => {
      if (args.data.tenantId && args.data.tenantId !== tenantId) {
        return Promise.reject(new ForbiddenException('Cross-tenant create blocked'));
      }
      const record = { id: `new-${modelKey}-${Date.now()}-${Math.random()}`, ...args.data, tenantId };
      const dbSlice = (db[modelKey] as Record<string, any[]>);
      (dbSlice[tenantId] = dbSlice[tenantId] ?? []).push(record);
      return Promise.resolve(record);
    }),
    createMany: jest.fn((args: { data: any[] }) => {
      const blocked = args.data.find(r => r.tenantId && r.tenantId !== tenantId);
      if (blocked) return Promise.reject(new ForbiddenException('Cross-tenant createMany blocked'));
      const records = args.data.map(r => ({ id: `nm-${Date.now()}-${Math.random()}`, ...r, tenantId }));
      const dbSlice = (db[modelKey] as Record<string, any[]>);
      (dbSlice[tenantId] = dbSlice[tenantId] ?? []).push(...records);
      return Promise.resolve({ count: records.length });
    }),
    update: jest.fn((args: { where: any; data: any }) => {
      if (args.data?.tenantId && args.data.tenantId !== tenantId) {
        return Promise.reject(new ForbiddenException('Cannot modify tenantId'));
      }
      const s = ((db[modelKey] as Record<string, any[]>)[tenantId] ?? []);
      const idx = s.findIndex((r: any) => r.id === args.where.id);
      if (idx === -1) return Promise.resolve(null);
      const updated = { ...s[idx], ...args.data };
      s[idx] = updated;
      return Promise.resolve(updated);
    }),
    deleteMany: jest.fn((args?: { where?: any }) => {
      const s = ((db[modelKey] as Record<string, any[]>)[tenantId] ?? []);
      const before = s.length;
      // Only delete if revisionId matches and record is in this tenant's slice
      const keep = s.filter((r: any) => {
        if (!args?.where) return false;
        return !Object.entries(args.where).every(([k, v]) => r[k] === v);
      });
      (db[modelKey] as Record<string, any[]>)[tenantId] = keep;
      return Promise.resolve({ count: before - keep.length });
    }),
  };
}

function makeMock(db: ArrearsDb) {
  return {
    forTenant: jest.fn((tenantId: string) => {
      if (!tenantId?.trim()) throw new ForbiddenException('Invalid tenant context');
      return {
        salaryRevision: makeScopedModel(db, 'salaryRevision', tenantId),
        arrearEntry:    makeScopedModel(db, 'arrearEntry',    tenantId),
        employee:       makeScopedModel(db, 'employee',       tenantId),
        tDSProjection:  makeScopedModel(db, 'tDSProjection',  tenantId),
        payslip:        makeScopedModel(db, 'payslip',        tenantId),
      };
    }),
  } as unknown as PrismaTenantService;
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('ArrearsService — Tenant Isolation', () => {
  let svc: ArrearsService;
  let db: ArrearsDb;
  let mockDb: PrismaTenantService;

  beforeEach(() => {
    db     = makeDb();
    mockDb = makeMock(db);
    svc    = new ArrearsService(mockDb);
  });

  // ── CT-ARR-01: Cross-tenant revision READ ───────────────────────────────

  it('CT-ARR-01 | tenant-B cannot read tenant-A salary revision', async () => {
    await expect(svc.getRevision(TENANT_B, REV_A1)).rejects.toThrow(NotFoundException);
  });

  // ── CT-ARR-02: Cross-tenant revision CREATE ──────────────────────────────

  it('CT-ARR-02 | createRevision for tenant-B stamps record with tenant-B tenantId', async () => {
    await svc.createRevision(TENANT_B, { ...BASE_DTO, employeeId: EMP_B1 }, 'hr-b');
    const created = db.salaryRevision[TENANT_B]?.find(r => r.employeeId === EMP_B1);
    expect(created).toBeDefined();
    expect(created?.tenantId).toBe(TENANT_B);
    // Tenant-A untouched
    expect(db.salaryRevision[TENANT_A]).toHaveLength(1);
    expect(db.salaryRevision[TENANT_A]![0]!.tenantId).toBe(TENANT_A);
  });

  // ── CT-ARR-03: Cross-tenant processRevision ──────────────────────────────

  it('CT-ARR-03 | processRevision with tenant-A revisionId under tenant-B → NotFoundException', async () => {
    await expect(svc.processRevision(TENANT_B, REV_A1, 'hr-b')).rejects.toThrow(NotFoundException);
  });

  // ── CT-ARR-04: Proxy blocks salaryRevision UPDATE with foreign tenantId ──

  it('CT-ARR-04 | update with foreign tenantId in data is rejected by proxy', async () => {
    const model = makeScopedModel(db, 'salaryRevision', TENANT_B);
    await expect(
      model.update({ where: { id: REV_A1 }, data: { tenantId: TENANT_A, status: 'processed' } })
    ).rejects.toThrow(ForbiddenException);
  });

  // ── CT-ARR-05: Cross-tenant arrearEntry CREATE ───────────────────────────

  it('CT-ARR-05 | arrearEntry createMany stamps records with actor tenantId', async () => {
    const model = makeScopedModel(db, 'arrearEntry', TENANT_B);
    await model.createMany({
      data: [
        { revisionId: 'rev-b1', employeeId: EMP_B1, month: 4, year: 2024, financialYear: FY, arrearAmount: 10000 },
      ],
    });
    const entries = db.arrearEntry[TENANT_B];
    expect(entries).toHaveLength(1);
    expect(entries![0]!.tenantId).toBe(TENANT_B);
    // Tenant-A untouched
    expect(db.arrearEntry[TENANT_A]).toHaveLength(0);
  });

  // ── CT-ARR-06: Cross-tenant arrearEntry DELETE scoped ────────────────────

  it('CT-ARR-06 | arrearEntry deleteMany under tenant-B cannot delete tenant-A entries', async () => {
    // Seed an entry for tenant-A
    db.arrearEntry[TENANT_A]!.push({ id: 'ae-a1', tenantId: TENANT_A, revisionId: REV_A1 });
    // Delete under tenant-B scope — only tenant-B's slice is modified
    const model = makeScopedModel(db, 'arrearEntry', TENANT_B);
    await model.deleteMany({ where: { revisionId: REV_A1 } });
    // Tenant-A's entry must still exist
    expect(db.arrearEntry[TENANT_A]).toHaveLength(1);
    expect(db.arrearEntry[TENANT_A]![0]!.tenantId).toBe(TENANT_A);
  });

  // ── CT-ARR-07: Cross-tenant tDSProjection UPDATE ─────────────────────────

  it('CT-ARR-07 | tDSProjection update under tenant-B cannot affect tenant-A projection', async () => {
    const model = makeScopedModel(db, 'tDSProjection', TENANT_B);
    // 'proj-a1' doesn't exist in TENANT_B slice → update returns null (no effect)
    const result = await model.update({ where: { id: 'proj-a1' }, data: { section89Relief: 25000 } });
    expect(result).toBeNull();
    // Tenant-A's projection is untouched
    expect(db.tDSProjection[TENANT_A]![0]).not.toMatchObject({ section89Relief: 25000 });
  });

  // ── CT-ARR-08: Cross-tenant arrear payslip CREATE ────────────────────────

  it('CT-ARR-08 | generateArrearPayslip stamps payslip with actor tenantId', async () => {
    // Set up a processed revision for tenant-B
    db.salaryRevision[TENANT_B]!.push({
      id: 'rev-b1', tenantId: TENANT_B, employeeId: EMP_B1,
      status: 'processed', revisionAnnouncedDate: '2024-10-01', effectiveFrom: '2024-04-01', reason: 'test',
      arrearData: {
        totalArrearAmount: 57000, totalBasicArrear: 40000, totalHraArrear: 10000,
        totalSpecialArrear: 7000, totalOtherArrear: 0, arrearsPerFy: [], monthwiseArrears: [],
        section89Relief: { section89ReliefAmount: 0, isReliefAvailable: false, form10ERequired: false, form10ENote: '' },
      },
    });
    await svc.generateArrearPayslip(TENANT_B, 'rev-b1', 'hr-b');
    const payslip = db.payslip[TENANT_B]?.find(r => r.payslipType === 'arrear');
    expect(payslip).toBeDefined();
    expect(payslip?.tenantId).toBe(TENANT_B);
    // Tenant-A payslips untouched
    expect(db.payslip[TENANT_A]).toHaveLength(0);
  });

  // ── CT-ARR-09: getEmployeeRevisions isolation ────────────────────────────

  it('CT-ARR-09 | getEmployeeRevisions: tenant-B sees no tenant-A revisions', async () => {
    const revisions = await svc.getEmployeeRevisions(TENANT_B, EMP_A1);
    expect(revisions).toHaveLength(0);
  });

  // ── CT-ARR-10: getTenantRevisions isolation ──────────────────────────────

  it('CT-ARR-10 | getTenantRevisions: tenant-B sees only their revisions', async () => {
    // Add a revision for tenant-B
    db.salaryRevision[TENANT_B]!.push({ id: 'rev-b2', tenantId: TENANT_B, employeeId: EMP_B1, financialYear: FY, status: 'pending' });
    const revisions = await svc.getTenantRevisions(TENANT_B, FY);
    expect(revisions).toHaveLength(1);
    expect((revisions[0] as any).tenantId).toBe(TENANT_B);
  });

  // ── CT-ARR-11: Employee cross-tenant check in createRevision ─────────────

  it('CT-ARR-11 | createRevision fails when employee belongs to different tenant', async () => {
    // EMP_A1 not visible under TENANT_B → proxy returns null → NotFoundException
    await expect(
      svc.createRevision(TENANT_B, { ...BASE_DTO, employeeId: EMP_A1 }, 'hr-b')
    ).rejects.toThrow(NotFoundException);
    // Ensure no revision was created for tenant-B
    expect(db.salaryRevision[TENANT_B]).toHaveLength(0);
  });

  // ── CT-ARR-12: Prior FY data load scoped to actor ────────────────────────

  it('CT-ARR-12 | _loadPriorFyData under tenant-B returns empty (no tenant-A projections)', async () => {
    // Seed prior FY projections for tenant-A
    db.tDSProjection[TENANT_A]!.push({ id: 'proj-prior-a', tenantId: TENANT_A, employeeId: EMP_A1, financialYear: '2023-24', projectedAnnualIncome: 1000000, totalTaxLiability: 70000, totalTdsDeducted: 70000, taxableIncome: 900000 });
    // Tenant-B queries prior FY projections for its own employee — should see nothing cross-tenant
    const scope = (mockDb as any).forTenant(TENANT_B);
    const projections = await scope.tDSProjection.findMany({
      where: { employeeId: EMP_A1, financialYear: { in: ['2023-24', '2022-23'] } },
    });
    expect(projections).toHaveLength(0);
  });

  // ── CT-ARR-13: batchCreateRevisions isolation ────────────────────────────

  it('CT-ARR-13 | batchCreateRevisions: each revision stamped with correct tenantId', async () => {
    const result = await svc.batchCreateRevisions(
      TENANT_B,
      [{ ...BASE_DTO, employeeId: EMP_B1 }],
      'hr-b',
    );
    expect(result.created).toBe(1);
    expect(result.errors).toHaveLength(0);
    const created = db.salaryRevision[TENANT_B]?.find(r => r.employeeId === EMP_B1);
    expect(created?.tenantId).toBe(TENANT_B);
    // Tenant-A still has only its original revision
    expect(db.salaryRevision[TENANT_A]).toHaveLength(1);
  });

  // ── CT-ARR-14: Empty tenantId ────────────────────────────────────────────

  it('CT-ARR-14 | empty tenantId throws ForbiddenException before any DB query', async () => {
    await expect(svc.getRevision('', REV_A1)).rejects.toThrow(ForbiddenException);
    await expect(svc.getEmployeeRevisions('', EMP_A1)).rejects.toThrow(ForbiddenException);
    await expect(svc.getTenantRevisions('')).rejects.toThrow(ForbiddenException);
  });
});
