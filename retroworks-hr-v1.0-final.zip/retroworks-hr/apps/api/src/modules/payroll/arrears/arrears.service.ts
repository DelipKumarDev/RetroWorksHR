/**
 * Arrears Service — Salary Revision Lifecycle
 * AUDIT-PAYROLL-2: Refactored — zero raw PrismaClient.
 *
 * All ops via scope = db.forTenant(tenantId).
 * proxy injects tenantId into every WHERE and CREATE data.
 *
 * Models used:
 *   salaryRevision   — SCOPED (tenantId col)
 *   arrearEntry      — SCOPED (tenantId col)
 *   tDSProjection    — SCOPED (tenantId col)
 *   employee         — SCOPED (already in proxy)
 *   payslip          — SCOPED (already in proxy)
 */
import {
  Injectable, Logger, NotFoundException,
  BadRequestException, ConflictException,
} from '@nestjs/common';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import {
  processRevisionAndArrears, computeRevisedTdsSchedule,
  generateForm10EData, validateRevisionInput, HISTORICAL_FY_CONFIGS,
  type SalaryRevisionInput, type ArrearsComputationResult,
  type RevisedTdsSchedule, type Form10EComputation,
} from './arrears.engine';
import { getCurrentFy } from '../tds/tds.engine';

export class CreateRevisionDto {
  employeeId!: string;
  effectiveFrom!: string;
  revisionAnnouncedDate!: string;
  oldMonthlyBasic!: number;
  oldMonthlyHRA!: number;
  oldMonthlySpecialAllowance!: number;
  oldMonthlyOtherAllowances!: number;
  oldMonthlyGross!: number;
  newMonthlyBasic!: number;
  newMonthlyHRA!: number;
  newMonthlySpecialAllowance!: number;
  newMonthlyOtherAllowances!: number;
  newMonthlyGross!: number;
  reason?: string;
  approvedBy?: string;
  financialYear?: string;
}

@Injectable()
export class ArrearsService {
  private readonly logger = new Logger(ArrearsService.name);
  constructor(private readonly db: PrismaTenantService) {}

  // ─── Create Revision ──────────────────────────────────────────────────────

  async createRevision(tenantId: string, dto: CreateRevisionDto, createdBy: string) {
    const scope = this.db.forTenant(tenantId);

    // proxy injects tenantId — cross-tenant employee lookup structurally impossible
    const employee = await scope.employee.findFirst({ where: { id: dto.employeeId } });
    if (!employee) throw new NotFoundException(`Employee ${dto.employeeId} not found`);

    const existing = await scope.salaryRevision.findFirst({
      where: { employeeId: dto.employeeId, effectiveFrom: dto.effectiveFrom },
    });
    if (existing) {
      throw new ConflictException(
        `A revision effective from ${dto.effectiveFrom} already exists for this employee.`,
      );
    }

    const fy = dto.financialYear ?? getCurrentFy();
    const revision = await scope.salaryRevision.create({
      data: {
        employeeId:              dto.employeeId,
        effectiveFrom:           dto.effectiveFrom,
        revisionAnnouncedDate:   dto.revisionAnnouncedDate,
        financialYear:           fy,
        oldMonthlyBasic:         dto.oldMonthlyBasic,
        oldMonthlyHRA:           dto.oldMonthlyHRA,
        oldMonthlySpecialAllowance: dto.oldMonthlySpecialAllowance,
        oldMonthlyOtherAllowances:  dto.oldMonthlyOtherAllowances,
        oldMonthlyGross:         dto.oldMonthlyGross,
        newMonthlyBasic:         dto.newMonthlyBasic,
        newMonthlyHRA:           dto.newMonthlyHRA,
        newMonthlySpecialAllowance: dto.newMonthlySpecialAllowance,
        newMonthlyOtherAllowances:  dto.newMonthlyOtherAllowances,
        newMonthlyGross:         dto.newMonthlyGross,
        reason:                  dto.reason ?? '',
        approvedBy:              dto.approvedBy ?? '',
        status:                  'pending',
        createdBy,               createdAt: new Date(),
      },
    });

    this.logger.log(`Revision created: ${(employee as any).firstName} ${(employee as any).lastName} from ${dto.effectiveFrom}`);
    return { revision, message: 'Revision created. Call /process to compute arrears and Section 89 relief.' };
  }

  // ─── Process Arrears ──────────────────────────────────────────────────────

  async processRevision(
    tenantId: string, revisionId: string, processedBy: string,
  ): Promise<{ result: ArrearsComputationResult; revisedSchedule: RevisedTdsSchedule; form10E: Form10EComputation | null; warnings: string[] }> {
    const scope = this.db.forTenant(tenantId);

    const revision = await scope.salaryRevision.findFirst({ where: { id: revisionId } });
    if (!revision) throw new NotFoundException(`Revision ${revisionId} not found`);
    if ((revision as any).status === 'processed') {
      throw new ConflictException('Revision already processed. Call /reprocess to recalculate.');
    }

    const employee = await scope.employee.findFirst({ where: { id: (revision as any).employeeId } });
    if (!employee) throw new NotFoundException('Employee not found');

    const fy = (revision as any).financialYear;
    const emp = employee as any;

    const tdsProjection = await scope.tDSProjection.findFirst({
      where: { employeeId: (revision as any).employeeId, financialYear: fy },
      orderBy: { createdAt: 'desc' },
    });

    const priorFyIncomesAndTax = await this._loadPriorFyData(scope, (revision as any).employeeId, fy);

    const announced = new Date((revision as any).revisionAnnouncedDate);
    const fyEndYear  = parseInt(fy.split('-')[0]!) + 1;
    const fyEnd      = new Date(fyEndYear, 3, 0);
    const remainingMonths = Math.max(1,
      (fyEnd.getFullYear() - announced.getFullYear()) * 12 +
      (fyEnd.getMonth()    - announced.getMonth()),
    );

    const input: SalaryRevisionInput = {
      employeeId:          (revision as any).employeeId,
      employeeName:        `${emp.firstName} ${emp.lastName}`,
      pan:                 emp.pan ?? 'APPLIED',
      regimeType:          ((tdsProjection as any)?.regimeType ?? 'new') as 'old' | 'new',
      effectiveFrom:       (revision as any).effectiveFrom,
      revisionAnnouncedDate:(revision as any).revisionAnnouncedDate,
      currentFinancialYear: fy,
      oldMonthlyBasic:     Number((revision as any).oldMonthlyBasic),
      oldMonthlyHRA:       Number((revision as any).oldMonthlyHRA),
      oldMonthlySpecialAllowance: Number((revision as any).oldMonthlySpecialAllowance),
      oldMonthlyOtherAllowances:  Number((revision as any).oldMonthlyOtherAllowances),
      oldMonthlyGross:     Number((revision as any).oldMonthlyGross),
      newMonthlyBasic:     Number((revision as any).newMonthlyBasic),
      newMonthlyHRA:       Number((revision as any).newMonthlyHRA),
      newMonthlySpecialAllowance: Number((revision as any).newMonthlySpecialAllowance),
      newMonthlyOtherAllowances:  Number((revision as any).newMonthlyOtherAllowances),
      newMonthlyGross:     Number((revision as any).newMonthlyGross),
      currentFyTaxableIncome: Number((tdsProjection as any)?.taxableIncome ?? 0),
      currentFyTotalTaxPaid:  Number((tdsProjection as any)?.totalTdsDeducted ?? 0),
      currentFyRemainingMonths: remainingMonths,
      priorFyIncomesAndTax,
    };

    const validation = validateRevisionInput(input);
    if (!validation.isValid) {
      throw new BadRequestException(
        `Revision validation failed: ${validation.blockingErrors.map((e: any) => e.message).join('; ')}`,
      );
    }

    const result = processRevisionAndArrears(input);
    const revisedSchedule = computeRevisedTdsSchedule({
      employeeId:           (revision as any).employeeId,
      financialYear:        fy,
      totalAnnualTaxLiability: result.section89Relief?.taxInCurrentYearWithArrear ?? 0,
      section89ReliefAmount:   result.section89Relief?.section89ReliefAmount ?? 0,
      alreadyDeductedTds:   Number((tdsProjection as any)?.totalTdsDeducted ?? 0),
      remainingMonths,
      startMonth: announced.getMonth() + 1,
      startYear:  announced.getFullYear(),
    });

    let form10E: Form10EComputation | null = null;
    if (result.section89Relief?.isReliefAvailable) {
      try {
        form10E = generateForm10EData({
          employeeId:           (revision as any).employeeId,
          employeeName:         input.employeeName,
          pan:                  input.pan,
          currentFinancialYear: fy,
          regime:               input.regimeType,
          currentFyTaxableIncome: input.currentFyTaxableIncome,
          totalArrearAmount:    result.totalArrearAmount,
          arrearsPerFy:         result.arrearsPerFy,
          priorFyIncomesAndTax,
        });
      } catch (e: any) {
        this.logger.warn(`Form 10E computation failed: ${e.message}`);
      }
    }

    // persist results — proxy injects tenantId into WHERE on update
    await scope.salaryRevision.update({
      where: { id: revisionId },
      data: {
        status:               'processed',
        totalArrearAmount:    result.totalArrearAmount,
        section89ReliefAmount:result.section89Relief?.section89ReliefAmount ?? 0,
        revisedMonthlyTds:    revisedSchedule.revisedMonthlyTds,
        arrearData:           result as any,
        form10EData:          form10E as any,
        revisedTdsSchedule:   revisedSchedule as any,
        processedBy,          processedAt: new Date(), updatedAt: new Date(),
      },
    });

    // save month-wise arrear entries — proxy injects tenantId into createMany
    await scope.arrearEntry.deleteMany({ where: { revisionId } });
    if (result.monthwiseArrears.length > 0) {
      await scope.arrearEntry.createMany({
        data: result.monthwiseArrears.map(m => ({
          revisionId,
          employeeId:   (revision as any).employeeId,
          month:        m.month, year: m.year,
          financialYear:m.financialYear,
          arrearAmount: m.arrearAmount,
          basicArrear:  m.basicArrear, hraArrear: m.hraArrear,
          specialArrear:m.specialArrear, otherArrear: m.otherArrear,
          createdAt:    new Date(),
        })),
      });
    }

    // update TDS projection with Section 89 relief
    if (tdsProjection && result.section89Relief?.section89ReliefAmount) {
      await scope.tDSProjection.update({
        where: { id: (tdsProjection as any).id },
        data: {
          section89Relief: result.section89Relief.section89ReliefAmount,
          arrearIncome:    result.totalArrearAmount,
          updatedAt:       new Date(),
        } as any,
      });
    }

    const warnings = validation.warnings.map((w: any) => w.message);
    if (result.section89Relief?.form10ERequired) warnings.push(result.section89Relief.form10ENote);

    this.logger.log(
      `Revision processed: ${input.employeeName}, Arrear: ₹${result.totalArrearAmount.toLocaleString('en-IN')}, ` +
      `S89: ₹${result.section89Relief?.section89ReliefAmount?.toLocaleString('en-IN') ?? '0'}`,
    );
    return { result, revisedSchedule, form10E, warnings };
  }

  // ─── Arrear Payslip ───────────────────────────────────────────────────────

  async generateArrearPayslip(tenantId: string, revisionId: string, generatedBy: string) {
    const scope = this.db.forTenant(tenantId);

    const revision = await scope.salaryRevision.findFirst({ where: { id: revisionId } });
    if (!revision) throw new NotFoundException('Revision not found');
    if ((revision as any).status !== 'processed') {
      throw new BadRequestException('Process revision first before generating arrear payslip.');
    }

    const arrearData = (revision as any).arrearData as ArrearsComputationResult;
    const announced  = new Date((revision as any).revisionAnnouncedDate);

    // proxy injects tenantId into CREATE data
    const payslip = await scope.payslip.create({
      data: {
        employeeId: (revision as any).employeeId,
        month:      announced.getMonth() + 1,
        year:       announced.getFullYear(),
        payslipType:'arrear',
        grossPay:   arrearData.totalArrearAmount,
        basicPay:   arrearData.totalBasicArrear,
        netPay:     arrearData.totalArrearAmount,
        tdsDeducted:0,
        pfEmployee: 0,
        components: {
          arrearDetails: {
            basicArrear:     arrearData.totalBasicArrear,
            hraArrear:       arrearData.totalHraArrear,
            specialArrear:   arrearData.totalSpecialArrear,
            otherArrear:     arrearData.totalOtherArrear,
            totalArrear:     arrearData.totalArrearAmount,
            arrearsPerFy:    arrearData.arrearsPerFy,
            section89ReliefAmount: arrearData.section89Relief?.section89ReliefAmount ?? 0,
          },
          monthwiseBreakdown: arrearData.monthwiseArrears,
        } as any,
        status:      'generated',
        revisionId,
        notes:       `Salary revision arrear. Effective from ${(revision as any).effectiveFrom}. ${(revision as any).reason}`,
        generatedBy, createdAt: new Date(),
      },
    });

    await scope.salaryRevision.update({
      where: { id: revisionId },
      data: { status: 'arrear_payslip_generated', updatedAt: new Date() },
    });
    return { payslip, totalArrear: arrearData.totalArrearAmount };
  }

  // ─── Queries ──────────────────────────────────────────────────────────────

  async getRevision(tenantId: string, revisionId: string) {
    const scope = this.db.forTenant(tenantId);
    const revision = await scope.salaryRevision.findFirst({ where: { id: revisionId } });
    if (!revision) throw new NotFoundException(`Revision ${revisionId} not found`);
    return revision;
  }

  async getEmployeeRevisions(tenantId: string, employeeId: string) {
    return this.db.forTenant(tenantId).salaryRevision.findMany({
      where: { employeeId },
      orderBy: { effectiveFrom: 'desc' },
    });
  }

  async getTenantRevisions(tenantId: string, financialYear?: string) {
    return this.db.forTenant(tenantId).salaryRevision.findMany({
      where: { ...(financialYear ? { financialYear } : {}) },
      orderBy: [{ financialYear: 'desc' }, { processedAt: 'desc' }],
    });
  }

  async getForm10E(tenantId: string, revisionId: string): Promise<Form10EComputation> {
    const revision = await this.getRevision(tenantId, revisionId);
    if (!(revision as any).form10EData) {
      throw new BadRequestException('No Form 10E data. Revision not processed or no Section 89 relief available.');
    }
    return (revision as any).form10EData as Form10EComputation;
  }

  async batchCreateRevisions(
    tenantId: string, revisions: CreateRevisionDto[], createdBy: string,
  ): Promise<{ created: number; errors: Array<{ employeeId: string; error: string }> }> {
    let created = 0;
    const errors: Array<{ employeeId: string; error: string }> = [];
    for (const dto of revisions) {
      try { await this.createRevision(tenantId, dto, createdBy); created++; }
      catch (err: any) { errors.push({ employeeId: dto.employeeId, error: err.message }); }
    }
    return { created, errors };
  }

  // ─── Private helpers ──────────────────────────────────────────────────────

  private async _loadPriorFyData(
    scope: ReturnType<PrismaTenantService['forTenant']>,
    employeeId: string, currentFy: string,
  ): Promise<Array<{ financialYear: string; taxableIncome: number; taxActuallyPaid: number }>> {
    const currentFyStart = parseInt(currentFy.split('-')[0]!);
    const priorFyStrings = [1, 2, 3].map(n => {
      const s = currentFyStart - n;
      return `${s}-${String(s + 1).slice(2)}`;
    });
    // proxy injects tenantId — cross-tenant prior FY data leak impossible
    const projections = await scope.tDSProjection.findMany({
      where: { employeeId, financialYear: { in: priorFyStrings } },
      orderBy: { financialYear: 'desc' },
    });
    return (projections as any[]).map(p => ({
      financialYear:    p.financialYear,
      taxableIncome:    Number(p.taxableIncome ?? 0),
      taxActuallyPaid:  Number(p.totalTdsDeducted ?? 0),
    }));
  }
}
