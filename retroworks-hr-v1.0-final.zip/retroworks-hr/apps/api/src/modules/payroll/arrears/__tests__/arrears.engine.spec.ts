/**
 * RetroWorks HR — Arrears & Section 89 Engine Test Suite
 * ═══════════════════════════════════════════════════════════════════════
 * 45 tests covering:
 *   ▸ Slab tax computation (new/old regime, historical FYs)
 *   ▸ Section 87A rebate edge cases
 *   ▸ Month-wise arrear computation (same FY, cross-FY)
 *   ▸ Section 89(1) relief formula
 *   ▸ Form 10E data generation
 *   ▸ Revised TDS schedule
 *   ▸ Edge cases: salary cut, single month, multi-year arrear
 *   ▸ Validation: date errors, missing config, salary cut warning
 *
 * Run: npx jest arrears.engine.spec --verbose
 */

import {
  computeSlabTax, computeTaxForFy, computeSection89Relief,
  computeArrearsMonthwise, computeRevisedTdsSchedule,
  generateForm10EData, processRevisionAndArrears,
  validateRevisionInput, getFyForMonth, getMonthRange,
  HISTORICAL_FY_CONFIGS,
  type SalaryRevisionInput, type HistoricalFyConfig,
} from '../arrears.engine';

// ─────────────────────────────────────────────────────────────────────────────
// FIXTURES
// ─────────────────────────────────────────────────────────────────────────────

const FY2425 = HISTORICAL_FY_CONFIGS['2024-25']!;
const FY2324 = HISTORICAL_FY_CONFIGS['2023-24']!;
const FY2223 = HISTORICAL_FY_CONFIGS['2022-23']!;

function makeRevisionInput(overrides: Partial<SalaryRevisionInput> = {}): SalaryRevisionInput {
  return {
    employeeId: 'emp-001',
    employeeName: 'Ramesh Kumar',
    pan: 'ABCPK1234F',
    regimeType: 'new',
    effectiveFrom: '2024-04-01',
    revisionAnnouncedDate: '2024-09-01',
    currentFinancialYear: '2024-25',
    oldMonthlyBasic: 50_000,
    oldMonthlyHRA: 20_000,
    oldMonthlySpecialAllowance: 20_000,
    oldMonthlyOtherAllowances: 10_000,
    oldMonthlyGross: 1_00_000,
    newMonthlyBasic: 60_000,
    newMonthlyHRA: 24_000,
    newMonthlySpecialAllowance: 24_000,
    newMonthlyOtherAllowances: 12_000,
    newMonthlyGross: 1_20_000,
    currentFyTaxableIncome: 10_50_000,
    currentFyTotalTaxPaid: 42_000,
    currentFyRemainingMonths: 7,
    priorFyIncomesAndTax: [
      { financialYear: '2023-24', taxableIncome: 9_00_000, taxActuallyPaid: 52_000 },
      { financialYear: '2022-23', taxableIncome: 7_50_000, taxActuallyPaid: 31_200 },
    ],
    ...overrides,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. SLAB TAX COMPUTATION
// ─────────────────────────────────────────────────────────────────────────────

describe('Slab Tax Computation', () => {

  test('ST01 — Zero income → zero tax', () => {
    expect(computeSlabTax(0, FY2425.newRegimeSlabs)).toBe(0);
  });

  test('ST02 — New regime FY24-25: ₹3L → 0 tax (nil slab)', () => {
    expect(computeSlabTax(3_00_000, FY2425.newRegimeSlabs)).toBe(0);
  });

  test('ST03 — New regime FY24-25: ₹5L → 5% on ₹2L = ₹10,000', () => {
    expect(computeSlabTax(5_00_000, FY2425.newRegimeSlabs)).toBe(10_000);
  });

  test('ST04 — New regime FY24-25: ₹10L → 5%×3L + 10%×3L + 15%×1L = 60,000', () => {
    // 3L-6L: 5% × 3L = 15000
    // 6L-9L: 10% × 3L = 30000
    // 9L-10L: 15% × 1L = 15000
    // Total = 60000
    const tax = computeSlabTax(10_00_000, FY2425.newRegimeSlabs);
    expect(tax).toBe(60_000);
  });

  test('ST05 — Old regime: ₹5L → 5% on ₹2.5L = ₹12,500', () => {
    expect(computeSlabTax(5_00_000, FY2425.oldRegimeSlabs)).toBe(12_500);
  });

  test('ST06 — Old regime: ₹10L → 5%×2.5L + 20%×5L = 1,12,500', () => {
    // 2.5L-5L: 5% × 2.5L = 12500
    // 5L-10L: 20% × 5L = 100000
    expect(computeSlabTax(10_00_000, FY2425.oldRegimeSlabs)).toBe(1_12_500);
  });

  test('ST07 — FY22-23 new regime had different slabs (7 slabs)', () => {
    // FY22-23: 10% slab starts at ₹5L
    const tax = computeSlabTax(8_00_000, FY2223.newRegimeSlabs);
    // 2.5L-5L: 5% × 2.5L = 12500
    // 5L-7.5L: 10% × 2.5L = 25000
    // 7.5L-8L: 15% × 0.5L = 7500
    expect(tax).toBe(45_000);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 2. FULL TAX COMPUTATION (with cess + rebate)
// ─────────────────────────────────────────────────────────────────────────────

describe('Full Tax Computation (with cess and 87A)', () => {

  test('TC01 — Income ≤ ₹7L in new regime FY24-25 → rebate wipes tax', () => {
    const result = computeTaxForFy(7_00_000, 'new', FY2425);
    // Slab tax on 7L: 5%×3L + 10%×1L = 15000+10000 = 25000
    // Rebate 87A = min(25000, 25000) = 25000 → tax after rebate = 0
    expect(result.totalTax).toBe(0);
    expect(result.rebate87A).toBe(25_000);
  });

  test('TC02 — Income ₹7,00,001 in new regime → rebate NOT available', () => {
    const result = computeTaxForFy(7_00_001, 'new', FY2425);
    expect(result.rebate87A).toBe(0);
    expect(result.totalTax).toBeGreaterThan(0);
  });

  test('TC03 — Income ≤ ₹5L in old regime → rebate wipes tax', () => {
    const result = computeTaxForFy(5_00_000, 'old', FY2425);
    expect(result.totalTax).toBe(0);
    expect(result.rebate87A).toBe(12_500);
  });

  test('TC04 — Tax includes 4% cess', () => {
    const result = computeTaxForFy(10_00_000, 'new', FY2425);
    const expectedCess = Math.round(result.taxBeforeCess * 0.04 * 100) / 100;
    expect(result.cess).toBe(expectedCess);
    expect(result.totalTax).toBe(result.taxBeforeCess + expectedCess);
  });

  test('TC05 — Historical FY22-23 standard deduction was ₹0 for new regime', () => {
    expect(FY2223.standardDeductionNew).toBe(0);
    expect(FY2425.standardDeductionNew).toBe(75_000);
  });

  test('TC06 — Zero income returns all zeros', () => {
    const result = computeTaxForFy(0, 'new', FY2425);
    expect(result.taxBeforeCess).toBe(0);
    expect(result.totalTax).toBe(0);
    expect(result.cess).toBe(0);
    expect(result.rebate87A).toBe(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 3. MONTH-WISE ARREAR COMPUTATION
// ─────────────────────────────────────────────────────────────────────────────

describe('Month-wise Arrear Computation', () => {

  test('AR01 — 5-month arrear (Apr–Aug) = ₹20,000 × 5', () => {
    const result = computeArrearsMonthwise({
      effectiveFrom: '2024-04-01',
      processedDate: '2024-09-01',
      oldMonthlyGross: 1_00_000, newMonthlyGross: 1_20_000,
      oldMonthlyBasic: 50_000, newMonthlyBasic: 60_000,
      oldMonthlyHRA: 20_000, newMonthlyHRA: 24_000,
      oldMonthlySpecial: 20_000, newMonthlySpecial: 24_000,
      oldMonthlyOther: 10_000, newMonthlyOther: 12_000,
    });
    expect(result.monthwiseArrears).toHaveLength(5); // Apr, May, Jun, Jul, Aug
    expect(result.totalArrear).toBe(1_00_000);        // 5 × 20,000
  });

  test('AR02 — Each month arrear = gross diff', () => {
    const result = computeArrearsMonthwise({
      effectiveFrom: '2024-06-01',
      processedDate: '2024-08-01',
      oldMonthlyGross: 80_000, newMonthlyGross: 90_000,
      oldMonthlyBasic: 40_000, newMonthlyBasic: 45_000,
      oldMonthlyHRA: 16_000, newMonthlyHRA: 18_000,
      oldMonthlySpecial: 16_000, newMonthlySpecial: 18_000,
      oldMonthlyOther: 8_000, newMonthlyOther: 9_000,
    });
    expect(result.monthwiseArrears[0]!.arrearAmount).toBe(10_000);
    expect(result.monthwiseArrears[0]!.basicArrear).toBe(5_000);
    expect(result.monthwiseArrears[0]!.hraArrear).toBe(2_000);
  });

  test('AR03 — Cross-FY arrear (Jan 2024 effective, Sep 2024 processed)', () => {
    const result = computeArrearsMonthwise({
      effectiveFrom: '2024-01-01',
      processedDate: '2024-09-01',
      oldMonthlyGross: 80_000, newMonthlyGross: 1_00_000,
      oldMonthlyBasic: 40_000, newMonthlyBasic: 50_000,
      oldMonthlyHRA: 16_000, newMonthlyHRA: 20_000,
      oldMonthlySpecial: 16_000, newMonthlySpecial: 20_000,
      oldMonthlyOther: 8_000, newMonthlyOther: 10_000,
    });
    // Jan–Mar = Q4 of FY23-24, Apr–Aug = Q1-Q2 of FY24-25
    expect(result.arrearsPerFy['2023-24']).toBe(60_000); // 3 × 20K
    expect(result.arrearsPerFy['2024-25']).toBe(1_00_000); // 5 × 20K
  });

  test('AR04 — Same-month effective and processed → zero arrears', () => {
    const result = computeArrearsMonthwise({
      effectiveFrom: '2024-09-01',
      processedDate: '2024-09-01',
      oldMonthlyGross: 80_000, newMonthlyGross: 1_00_000,
      oldMonthlyBasic: 40_000, newMonthlyBasic: 50_000,
      oldMonthlyHRA: 16_000, newMonthlyHRA: 20_000,
      oldMonthlySpecial: 16_000, newMonthlySpecial: 20_000,
      oldMonthlyOther: 8_000, newMonthlyOther: 10_000,
    });
    expect(result.monthwiseArrears).toHaveLength(0);
    expect(result.totalArrear).toBe(0);
  });

  test('AR05 — Salary cut produces no arrear (zero diff)', () => {
    const result = computeArrearsMonthwise({
      effectiveFrom: '2024-04-01',
      processedDate: '2024-07-01',
      oldMonthlyGross: 1_20_000, newMonthlyGross: 1_00_000, // CUT
      oldMonthlyBasic: 60_000, newMonthlyBasic: 50_000,
      oldMonthlyHRA: 24_000, newMonthlyHRA: 20_000,
      oldMonthlySpecial: 24_000, newMonthlySpecial: 20_000,
      oldMonthlyOther: 12_000, newMonthlyOther: 10_000,
    });
    expect(result.totalArrear).toBe(0);
    expect(result.monthwiseArrears).toHaveLength(0);
  });

  test('AR06 — getFyForMonth correctly identifies FY', () => {
    expect(getFyForMonth(4, 2024)).toBe('2024-25');
    expect(getFyForMonth(3, 2025)).toBe('2024-25');
    expect(getFyForMonth(3, 2024)).toBe('2023-24');
    expect(getFyForMonth(4, 2023)).toBe('2023-24');
  });

  test('AR07 — getMonthRange returns all months inclusive', () => {
    const range = getMonthRange(new Date(2024, 3, 1), new Date(2024, 7, 1)); // Apr–Aug
    expect(range).toHaveLength(5);
    expect(range[0]).toEqual({ year: 2024, month: 4 });
    expect(range[4]).toEqual({ year: 2024, month: 8 });
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 4. SECTION 89(1) RELIEF
// ─────────────────────────────────────────────────────────────────────────────

describe('Section 89(1) Relief', () => {

  test('S89-01 — No prior FY data → no relief', () => {
    const result = computeSection89Relief({
      regime: 'new',
      currentFyConfig: FY2425,
      currentFyTaxableIncome: 10_00_000,
      totalArrearAmount: 2_00_000,
      arrearsPerFy: { '2023-24': 2_00_000 },
      priorFyIncomesAndTax: [],  // no prior data
    });
    // All C-D = 0, so Relief = ExtraCurrentYear - 0 = positive
    // Actually — if prior FY config exists but no income data, we treat as 0 excess
    // Relief could still be positive in this case
    expect(result.section89ReliefAmount).toBeGreaterThanOrEqual(0);
  });

  test('S89-02 — Arrear does NOT push income into higher slab → relief is 0', () => {
    // Low income: ₹4L + arrear ₹50K = ₹4.5L — both in same slab
    const result = computeSection89Relief({
      regime: 'new',
      currentFyConfig: FY2425,
      currentFyTaxableIncome: 4_00_000,
      totalArrearAmount: 50_000,
      arrearsPerFy: { '2023-24': 50_000 },
      priorFyIncomesAndTax: [{ financialYear: '2023-24', taxableIncome: 3_00_000, taxActuallyPaid: 0 }],
    });
    // Both with and without arrear covered by 87A rebate → no marginal difference
    expect(result.isReliefAvailable).toBe(false);
    expect(result.section89ReliefAmount).toBe(0);
  });

  test('S89-03 — Relief formula: extraCurrentYear − excessPriorYears', () => {
    const result = computeSection89Relief({
      regime: 'new',
      currentFyConfig: FY2425,
      currentFyTaxableIncome: 12_00_000,
      totalArrearAmount: 2_00_000,
      arrearsPerFy: { '2023-24': 2_00_000 },
      priorFyIncomesAndTax: [{ financialYear: '2023-24', taxableIncome: 9_00_000, taxActuallyPaid: 52_000 }],
    });
    const reliefCheck = Math.max(0,
      result.extraTaxInCurrentYear - result.excessTaxInPriorYears
    );
    expect(result.section89ReliefAmount).toBe(reliefCheck);
  });

  test('S89-04 — Current FY tax with arrear > without arrear', () => {
    const result = computeSection89Relief({
      regime: 'new',
      currentFyConfig: FY2425,
      currentFyTaxableIncome: 14_00_000,
      totalArrearAmount: 3_00_000,
      arrearsPerFy: { '2023-24': 3_00_000 },
      priorFyIncomesAndTax: [{ financialYear: '2023-24', taxableIncome: 12_00_000, taxActuallyPaid: 0 }],
    });
    expect(result.taxInCurrentYearWithArrear).toBeGreaterThan(result.taxInCurrentYearWithoutArrear);
    expect(result.extraTaxInCurrentYear).toBeGreaterThan(0);
  });

  test('S89-05 — fyWise entries created for each relevant FY', () => {
    const result = computeSection89Relief({
      regime: 'new',
      currentFyConfig: FY2425,
      currentFyTaxableIncome: 14_00_000,
      totalArrearAmount: 4_00_000,
      arrearsPerFy: { '2023-24': 2_00_000, '2022-23': 2_00_000 },
      priorFyIncomesAndTax: [
        { financialYear: '2023-24', taxableIncome: 12_00_000, taxActuallyPaid: 0 },
        { financialYear: '2022-23', taxableIncome: 10_00_000, taxActuallyPaid: 0 },
      ],
    });
    expect(result.fyWise).toHaveLength(2);
    expect(result.fyWise.map(f => f.financialYear)).toContain('2023-24');
    expect(result.fyWise.map(f => f.financialYear)).toContain('2022-23');
  });

  test('S89-06 — Form 10E required only when relief is available', () => {
    const withRelief = computeSection89Relief({
      regime: 'new',
      currentFyConfig: FY2425,
      currentFyTaxableIncome: 14_00_000,
      totalArrearAmount: 3_00_000,
      arrearsPerFy: { '2023-24': 3_00_000 },
      priorFyIncomesAndTax: [{ financialYear: '2023-24', taxableIncome: 9_00_000, taxActuallyPaid: 0 }],
    });
    const noRelief = computeSection89Relief({
      regime: 'new',
      currentFyConfig: FY2425,
      currentFyTaxableIncome: 4_00_000,
      totalArrearAmount: 50_000,
      arrearsPerFy: { '2023-24': 50_000 },
      priorFyIncomesAndTax: [{ financialYear: '2023-24', taxableIncome: 3_00_000, taxActuallyPaid: 0 }],
    });
    expect(withRelief.form10ERequired).toBe(withRelief.isReliefAvailable);
    expect(noRelief.form10ERequired).toBe(false);
  });

  test('S89-07 — Net tax after relief = taxWithArrear − relief', () => {
    const result = computeSection89Relief({
      regime: 'new',
      currentFyConfig: FY2425,
      currentFyTaxableIncome: 14_00_000,
      totalArrearAmount: 3_00_000,
      arrearsPerFy: { '2023-24': 3_00_000 },
      priorFyIncomesAndTax: [{ financialYear: '2023-24', taxableIncome: 9_00_000, taxActuallyPaid: 0 }],
    });
    const expected = Math.round((result.taxInCurrentYearWithArrear - result.section89ReliefAmount) * 100) / 100;
    expect(result.netTaxAfterRelief).toBe(expected);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 5. REVISED TDS SCHEDULE
// ─────────────────────────────────────────────────────────────────────────────

describe('Revised TDS Schedule', () => {

  test('TDS01 — Remaining TDS spread equally over remaining months', () => {
    const schedule = computeRevisedTdsSchedule({
      employeeId: 'emp-001',
      financialYear: '2024-25',
      totalAnnualTaxLiability: 1_50_000,
      section89ReliefAmount: 10_000,
      alreadyDeductedTds: 80_000,
      remainingMonths: 6,
      startMonth: 10,
      startYear: 2024,
    });
    // Net = 150000 - 10000 = 140000; Remaining = 140000 - 80000 = 60000; Monthly = 10000
    expect(schedule.revisedMonthlyTds).toBe(10_000);
    expect(schedule.remainingMonths).toBe(6);
  });

  test('TDS02 — Cumulative TDS reaches net tax by last month', () => {
    const schedule = computeRevisedTdsSchedule({
      employeeId: 'emp-001',
      financialYear: '2024-25',
      totalAnnualTaxLiability: 1_00_000,
      section89ReliefAmount: 0,
      alreadyDeductedTds: 60_000,
      remainingMonths: 4,
      startMonth: 12,
      startYear: 2024,
    });
    const lastMonth = schedule.schedule[schedule.schedule.length - 1]!;
    expect(lastMonth.cumulativeTds).toBe(1_00_000);
  });

  test('TDS03 — Schedule has correct number of entries', () => {
    const schedule = computeRevisedTdsSchedule({
      employeeId: 'emp-001',
      financialYear: '2024-25',
      totalAnnualTaxLiability: 1_00_000,
      section89ReliefAmount: 0,
      alreadyDeductedTds: 50_000,
      remainingMonths: 7,
      startMonth: 9,
      startYear: 2024,
    });
    expect(schedule.schedule).toHaveLength(7);
  });

  test('TDS04 — Already-paid excess → remaining TDS = 0', () => {
    const schedule = computeRevisedTdsSchedule({
      employeeId: 'emp-001',
      financialYear: '2024-25',
      totalAnnualTaxLiability: 80_000,
      section89ReliefAmount: 0,
      alreadyDeductedTds: 1_00_000, // Over-deducted
      remainingMonths: 4,
      startMonth: 12,
      startYear: 2024,
    });
    expect(schedule.remainingTdsToDeduct).toBe(0);
    expect(schedule.revisedMonthlyTds).toBe(0);
  });

  test('TDS05 — Month rolls over year boundary correctly', () => {
    const schedule = computeRevisedTdsSchedule({
      employeeId: 'emp-001',
      financialYear: '2024-25',
      totalAnnualTaxLiability: 60_000,
      section89ReliefAmount: 0,
      alreadyDeductedTds: 40_000,
      remainingMonths: 4,
      startMonth: 12,   // Dec → Jan → Feb → Mar
      startYear: 2024,
    });
    const months = schedule.schedule.map(s => s.month);
    expect(months).toEqual([12, 1, 2, 3]);
    expect(schedule.schedule[1]!.year).toBe(2025); // January 2025
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 6. FORM 10E DATA
// ─────────────────────────────────────────────────────────────────────────────

describe('Form 10E Generation', () => {

  test('F10E-01 — Annexure I has entry for each relevant prior FY', () => {
    const form = generateForm10EData({
      employeeId: 'emp-001',
      employeeName: 'Ramesh Kumar',
      pan: 'ABCPK1234F',
      currentFinancialYear: '2024-25',
      regime: 'new',
      currentFyTaxableIncome: 14_00_000,
      totalArrearAmount: 4_00_000,
      arrearsPerFy: { '2023-24': 2_00_000, '2022-23': 2_00_000 },
      priorFyIncomesAndTax: [
        { financialYear: '2023-24', taxableIncome: 11_00_000 },
        { financialYear: '2022-23', taxableIncome: 9_00_000 },
      ],
    });
    expect(form.annexureI).toHaveLength(2);
  });

  test('F10E-02 — Form 10E includes disclaimer about mandatory filing', () => {
    const form = generateForm10EData({
      employeeId: 'emp-001',
      employeeName: 'Ramesh Kumar',
      pan: 'ABCPK1234F',
      currentFinancialYear: '2024-25',
      regime: 'new',
      currentFyTaxableIncome: 12_00_000,
      totalArrearAmount: 2_00_000,
      arrearsPerFy: { '2023-24': 2_00_000 },
      priorFyIncomesAndTax: [{ financialYear: '2023-24', taxableIncome: 9_00_000 }],
    });
    expect(form.disclaimer).toContain('Form 10E');
    expect(form.disclaimer).toContain('CBDT Circular');
  });

  test('F10E-03 — Assessment year computed correctly from FY', () => {
    const form = generateForm10EData({
      employeeId: 'emp-001',
      employeeName: 'Test',
      pan: 'ABCDE1234F',
      currentFinancialYear: '2024-25',
      regime: 'new',
      currentFyTaxableIncome: 10_00_000,
      totalArrearAmount: 1_00_000,
      arrearsPerFy: { '2023-24': 1_00_000 },
      priorFyIncomesAndTax: [{ financialYear: '2023-24', taxableIncome: 8_00_000 }],
    });
    expect(form.assessmentYear).toBe('2025-26');
  });

  test('F10E-04 — Differential tax in Annexure I is C − D (non-negative)', () => {
    const form = generateForm10EData({
      employeeId: 'emp-001',
      employeeName: 'Test',
      pan: 'ABCDE1234F',
      currentFinancialYear: '2024-25',
      regime: 'new',
      currentFyTaxableIncome: 14_00_000,
      totalArrearAmount: 2_00_000,
      arrearsPerFy: { '2023-24': 2_00_000 },
      priorFyIncomesAndTax: [{ financialYear: '2023-24', taxableIncome: 11_00_000 }],
    });
    for (const row of form.annexureI) {
      expect(row.differentialTax).toBeGreaterThanOrEqual(0);
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 7. FULL PIPELINE
// ─────────────────────────────────────────────────────────────────────────────

describe('Full Revision Pipeline', () => {

  test('PIPE01 — Same FY revision: arrear + revised TDS schedule', () => {
    const input = makeRevisionInput();
    const result = processRevisionAndArrears(input);
    expect(result.totalArrearAmount).toBe(1_00_000); // 5 months × ₹20K
    expect(result.monthwiseArrears).toHaveLength(5);
    expect(result.revisedMonthlyTds).toBeGreaterThan(0);
  });

  test('PIPE02 — Arrear components sum to total', () => {
    const result = processRevisionAndArrears(makeRevisionInput());
    const componentSum = Math.round((
      result.totalBasicArrear + result.totalHraArrear +
      result.totalSpecialArrear + result.totalOtherArrear
    ) * 100) / 100;
    expect(componentSum).toBe(result.totalArrearAmount);
  });

  test('PIPE03 — Section 89 is computed when arrears relate to prior FY', () => {
    // Effective from Jan 2024 (FY23-24), announced Sep 2024 (FY24-25)
    const input = makeRevisionInput({
      effectiveFrom: '2024-01-01',
      revisionAnnouncedDate: '2024-09-01',
    });
    const result = processRevisionAndArrears(input);
    expect(result.arrearsPerFy['2023-24']).toBeGreaterThan(0);
    expect(result.section89Relief).not.toBeNull();
  });

  test('PIPE04 — Same-FY-only arrear: no Section 89 prior FY entries', () => {
    const input = makeRevisionInput({
      effectiveFrom: '2024-04-01',
      revisionAnnouncedDate: '2024-09-01',
    });
    const result = processRevisionAndArrears(input);
    // All arrears in 2024-25 → prior FY entries in fyWise should have 0 excess
    if (result.section89Relief) {
      const priorEntries = result.section89Relief.fyWise.filter(f => f.financialYear !== '2024-25');
      priorEntries.forEach(e => expect(e.excessTax).toBe(0));
    }
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 8. VALIDATION
// ─────────────────────────────────────────────────────────────────────────────

describe('Validation', () => {

  test('VAL01 — Valid input passes', () => {
    const result = validateRevisionInput(makeRevisionInput());
    expect(result.isValid).toBe(true);
    expect(result.blockingErrors).toHaveLength(0);
  });

  test('VAL02 — effectiveFrom after processedDate is blocking', () => {
    const result = validateRevisionInput(makeRevisionInput({
      effectiveFrom: '2024-12-01',
      revisionAnnouncedDate: '2024-09-01',
    }));
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'FUTURE_EFFECTIVE_DATE')).toBe(true);
  });

  test('VAL03 — Salary cut produces warning (not blocking)', () => {
    const result = validateRevisionInput(makeRevisionInput({
      newMonthlyGross: 90_000,  // LESS than old 1,00,000
    }));
    expect(result.isValid).toBe(true);
    expect(result.warnings.some(w => w.code === 'NO_SALARY_INCREASE')).toBe(true);
  });

  test('VAL04 — Unsupported FY is blocking', () => {
    const result = validateRevisionInput(makeRevisionInput({
      currentFinancialYear: '2019-20',
    }));
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'UNSUPPORTED_FY')).toBe(true);
  });

  test('VAL05 — Zero remaining months is blocking', () => {
    const result = validateRevisionInput(makeRevisionInput({
      currentFyRemainingMonths: 0,
    }));
    expect(result.isValid).toBe(false);
    expect(result.blockingErrors.some(e => e.code === 'NO_REMAINING_MONTHS')).toBe(true);
  });

  test('VAL06 — Invalid PAN produces warning', () => {
    const result = validateRevisionInput(makeRevisionInput({ pan: 'BADPAN' }));
    expect(result.warnings.some(w => w.code === 'INVALID_PAN')).toBe(true);
    expect(result.isValid).toBe(true); // Warning not blocking
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 9. HISTORICAL FY CONFIGS
// ─────────────────────────────────────────────────────────────────────────────

describe('Historical FY Configs', () => {

  test('HFY01 — All expected FYs are configured', () => {
    expect(HISTORICAL_FY_CONFIGS).toHaveProperty('2024-25');
    expect(HISTORICAL_FY_CONFIGS).toHaveProperty('2023-24');
    expect(HISTORICAL_FY_CONFIGS).toHaveProperty('2022-23');
    expect(HISTORICAL_FY_CONFIGS).toHaveProperty('2021-22');
  });

  test('HFY02 — FY24-25 standard deduction new regime = ₹75,000', () => {
    expect(FY2425.standardDeductionNew).toBe(75_000);
  });

  test('HFY03 — FY22-23 new regime standard deduction = ₹0 (pre-Budget 2023)', () => {
    expect(FY2223.standardDeductionNew).toBe(0);
  });

  test('HFY04 — Cess rate is 4% across all FYs', () => {
    for (const [, cfg] of Object.entries(HISTORICAL_FY_CONFIGS)) {
      expect(cfg.cessRate).toBe(0.04);
    }
  });

  test('HFY05 — Each FY has non-empty slab arrays', () => {
    for (const [, cfg] of Object.entries(HISTORICAL_FY_CONFIGS)) {
      expect(cfg.newRegimeSlabs.length).toBeGreaterThan(0);
      expect(cfg.oldRegimeSlabs.length).toBeGreaterThan(0);
    }
  });
});
