/**
 * Payroll DTOs — Typed & Validated
 * AUDIT-04: Replaced all `dto: any` in PayrollController with proper class-validator DTOs.
 * Mass assignment protection: forbidNonWhitelisted = true in global ValidationPipe
 * means any extra field sent by client is REJECTED (not silently ignored).
 */

import {
  IsString, IsNumber, IsOptional, IsEnum, IsInt,
  IsPositive, Min, Max, IsNotEmpty, ValidateNested,
  IsArray, IsDateString, IsBoolean,
} from 'class-validator';
import { Type } from 'class-transformer';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

// ─── Salary Structure ────────────────────────────────────────────────────────

export class SalaryComponentDto {
  @ApiProperty({ description: 'Component name', example: 'Basic Salary' })
  @IsString() @IsNotEmpty()
  name!: string;

  @ApiProperty({ description: 'Monthly amount in INR', example: 50000 })
  @IsNumber() @IsPositive()
  amount!: number;

  @ApiPropertyOptional({ enum: ['fixed', 'percentage', 'formula'] })
  @IsOptional() @IsEnum(['fixed', 'percentage', 'formula'])
  type?: 'fixed' | 'percentage' | 'formula';

  @ApiPropertyOptional({ description: 'Taxable flag' })
  @IsOptional() @IsBoolean()
  taxable?: boolean;
}

export class UpsertSalaryStructureDto {
  @ApiProperty({ description: 'Employee ID' })
  @IsString() @IsNotEmpty()
  employeeId!: string;

  @ApiProperty({ description: 'Monthly basic salary (INR)', example: 50000 })
  @IsNumber() @IsPositive()
  basicSalary!: number;

  @ApiProperty({ description: 'Monthly HRA (INR)', example: 20000 })
  @IsNumber() @Min(0)
  hra!: number;

  @ApiProperty({ description: 'Special allowance (INR)', example: 20000 })
  @IsNumber() @Min(0)
  specialAllowance!: number;

  @ApiPropertyOptional({ description: 'LTA monthly equivalent', example: 4167 })
  @IsOptional() @IsNumber() @Min(0)
  lta?: number;

  @ApiPropertyOptional({ description: 'Medical allowance (INR)', example: 1250 })
  @IsOptional() @IsNumber() @Min(0)
  medicalAllowance?: number;

  @ApiPropertyOptional({ description: 'Other allowances (INR)' })
  @IsOptional() @IsNumber() @Min(0)
  otherAllowances?: number;

  @ApiPropertyOptional({ description: 'Monthly voluntary PF contribution beyond 12%' })
  @IsOptional() @IsNumber() @Min(0)
  voluntaryPf?: number;

  @ApiPropertyOptional({ description: 'Monthly NPS contribution' })
  @IsOptional() @IsNumber() @Min(0)
  npsContribution?: number;

  @ApiPropertyOptional({ description: 'Annual CTC (total cost to company)' })
  @IsOptional() @IsNumber() @IsPositive()
  annualCtc?: number;

  @ApiPropertyOptional({ description: 'Effective from date (ISO)', example: '2024-04-01' })
  @IsOptional() @IsDateString()
  effectiveFrom?: string;

  @ApiPropertyOptional({ description: 'Remarks or revision reason' })
  @IsOptional() @IsString()
  remarks?: string;

  @ApiPropertyOptional({ type: [SalaryComponentDto], description: 'Additional custom components' })
  @IsOptional() @IsArray() @ValidateNested({ each: true }) @Type(() => SalaryComponentDto)
  customComponents?: SalaryComponentDto[];
}

// ─── Payroll Run ─────────────────────────────────────────────────────────────

export class RunPayrollDto {
  @ApiProperty({ description: 'Calendar month (1-12)', example: 6 })
  @IsInt() @Min(1) @Max(12)
  month!: number;

  @ApiProperty({ description: 'Calendar year', example: 2024 })
  @IsInt() @Min(2020) @Max(2099)
  year!: number;

  @ApiPropertyOptional({
    description: 'Include specific employees only (empty = all active)',
    type: [String],
  })
  @IsOptional() @IsArray() @IsString({ each: true })
  employeeIds?: string[];

  @ApiPropertyOptional({
    description: 'Exclude specific employees from this run',
    type: [String],
  })
  @IsOptional() @IsArray() @IsString({ each: true })
  excludeEmployeeIds?: string[];

  @ApiPropertyOptional({ description: 'Include salary arrears if any pending' })
  @IsOptional() @IsBoolean()
  includeArrears?: boolean;

  @ApiPropertyOptional({ description: 'Dry run — compute without persisting' })
  @IsOptional() @IsBoolean()
  dryRun?: boolean;

  @ApiPropertyOptional({ description: 'Notes for this payroll run' })
  @IsOptional() @IsString()
  notes?: string;
}

// ─── Payroll Adjustment ──────────────────────────────────────────────────────

export type AdjustmentType =
  | 'bonus'
  | 'deduction'
  | 'advance_recovery'
  | 'reimbursement'
  | 'loss_of_pay'
  | 'overtime'
  | 'incentive'
  | 'other';

export class AddAdjustmentDto {
  @ApiProperty({ description: 'Employee ID' })
  @IsString() @IsNotEmpty()
  employeeId!: string;

  @ApiProperty({ description: 'Month (1-12)', example: 6 })
  @IsInt() @Min(1) @Max(12)
  month!: number;

  @ApiProperty({ description: 'Year', example: 2024 })
  @IsInt() @Min(2020) @Max(2099)
  year!: number;

  @ApiProperty({
    enum: ['bonus','deduction','advance_recovery','reimbursement','loss_of_pay','overtime','incentive','other'],
    description: 'Adjustment type',
  })
  @IsEnum(['bonus','deduction','advance_recovery','reimbursement','loss_of_pay','overtime','incentive','other'])
  type!: AdjustmentType;

  @ApiProperty({ description: 'Amount in INR', example: 5000 })
  @IsNumber() @IsPositive()
  amount!: number;

  @ApiProperty({ description: 'Description / reason', example: 'Q1 performance bonus' })
  @IsString() @IsNotEmpty()
  description!: string;

  @ApiPropertyOptional({ description: 'Whether this adjustment is taxable' })
  @IsOptional() @IsBoolean()
  taxable?: boolean;

  @ApiPropertyOptional({ description: 'Reference number (e.g. advance slip number)' })
  @IsOptional() @IsString()
  referenceNumber?: string;
}

// ─── Tax Declaration (existing employees amending investment proofs) ──────────

export class TaxDeclarationDto {
  @ApiPropertyOptional({ description: 'Section 80C total (max ₹1,50,000)' })
  @IsOptional() @IsNumber() @Min(0)
  section80C?: number;

  @ApiPropertyOptional({ description: 'Section 80D - self health insurance' })
  @IsOptional() @IsNumber() @Min(0)
  section80D_self?: number;

  @ApiPropertyOptional({ description: 'Section 80D - parents health insurance' })
  @IsOptional() @IsNumber() @Min(0)
  section80D_parents?: number;

  @ApiPropertyOptional({ description: 'Section 80CCD(1B) - NPS additional' })
  @IsOptional() @IsNumber() @Min(0)
  section80CCD1B?: number;

  @ApiPropertyOptional({ description: 'HRA exemption amount (leave blank to auto-compute)' })
  @IsOptional() @IsNumber() @Min(0)
  hraExemption?: number;

  @ApiPropertyOptional({ enum: ['new', 'old'], description: 'Tax regime choice' })
  @IsOptional() @IsEnum(['new', 'old'])
  regimeType?: 'new' | 'old';

  @ApiPropertyOptional({ description: 'Rent paid monthly (for HRA)' })
  @IsOptional() @IsNumber() @Min(0)
  monthlyRent?: number;

  @ApiPropertyOptional({ description: 'City type for HRA (metro = 50%, non-metro = 40%)' })
  @IsOptional() @IsEnum(['metro', 'non-metro'])
  cityType?: 'metro' | 'non-metro';
}
