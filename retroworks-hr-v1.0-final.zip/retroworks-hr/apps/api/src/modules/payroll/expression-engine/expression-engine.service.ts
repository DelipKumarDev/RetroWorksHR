/**
 * Expression Engine Service — Phase 2B
 * ──────────────────────────────────────────────────────────────────────────────
 * Orchestrates: formula validation → component versioning → graph caching →
 *               topological evaluation → payroll integration → audit logging.
 *
 * INTEGRATION CONTRACT:
 *   - Called by PayrollService before statutory computation
 *   - Returns ExpressionEngineResult which augments PayrollInput
 *   - Never modifies locked payroll runs
 *   - Never re-evaluates historical payslips
 *   - Tenant-isolated via PrismaTenantService
 *
 * PERFORMANCE:
 *   - Dependency graph cached per (tenantId, payrollGroupVersion)
 *   - AST pre-parsed and cached — no re-parse per employee
 *   - Pure in-memory evaluation — zero DB calls inside evaluator
 *   - 1000 employees target: < 200ms
 */

import { Injectable, Logger, BadRequestException, ConflictException } from '@nestjs/common';
import * as crypto from 'crypto';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import { AuditService } from '../../../common/services/audit.service';
import { parse } from './parser';
import { evaluate } from './evaluator';
import { buildDependencyGraph, topologicalSort } from './dependency-graph';
import { validateFormula, validateComponentSet } from './validator';
import type {
  PayComponentDefinition, EvalContext, ExpressionEngineResult,
  ComponentResult, ValidationResult, RoundingRule, AstNode,
} from './types';
import { ENGINE_LIMITS } from './types';

interface CachedGraph {
  order: string[];
  astMap: Map<string, AstNode>;
  graphHash: string;
  cachedAt: number;
}

const GRAPH_CACHE_TTL_MS = 30_000; // 30 seconds per payroll run

@Injectable()
export class ExpressionEngineService {
  private readonly logger = new Logger(ExpressionEngineService.name);
  private readonly graphCache = new Map<string, CachedGraph>();

  constructor(
    private readonly db: PrismaTenantService,
    private readonly auditSvc: AuditService,
  ) {}

  // ─── FORMULA VALIDATION (called from admin UI before save) ─────────────────

  async validateFormulaForTenant(
    tenantId: string,
    formula: string,
    componentCode: string,
    canOverrideBasic = false,
  ): Promise<ValidationResult> {
    const scope = this.db.forTenant(tenantId);
    const allComponents = await scope.payComponent.findMany({
      where: { isActive: true },
      select: { code: true },
    });
    const knownCodes = new Set(allComponents.map((c: any) => c.code as string));

    return validateFormula(formula, knownCodes, componentCode, canOverrideBasic);
  }

  // ─── SAVE / UPDATE FORMULA (with versioning) ───────────────────────────────

  async saveFormula(
    tenantId: string,
    componentId: string,
    formula: string,
    changedBy: string,
    changeNote?: string,
  ): Promise<{ version: number; hash: string }> {
    const scope = this.db.forTenant(tenantId);

    const component = await scope.payComponent.findFirst({
      where: { id: componentId },
    });
    if (!component) throw new BadRequestException('Component not found');
    if ((component as any).isLocked) throw new ConflictException('Component is locked — cannot modify');

    // Validate before saving
    const allCodes = await scope.payComponent.findMany({
      where: { isActive: true },
      select: { code: true },
    });
    const knownCodes = new Set(allCodes.map((c: any) => c.code as string));
    const validation = validateFormula(
      formula, knownCodes, (component as any).code,
      (component as any).canOverrideBasic,
    );

    if (!validation.valid) {
      throw new BadRequestException({
        message: 'Formula validation failed',
        issues: validation.issues,
      });
    }

    // Check for cycles after this formula change
    const allComponents = await scope.payComponent.findMany({
      where: { isActive: true, type: 'FORMULA' },
    });
    // Temporarily apply the new formula to validate the full graph
    const simulatedComponents = allComponents.map((c: any) =>
      c.id === componentId ? { ...c, formula } : c
    );
    const cycleCheck = validateComponentSet(simulatedComponents as any[]);
    if (!cycleCheck.valid) {
      throw new BadRequestException({
        message: `Circular dependency detected: ${cycleCheck.cycles?.join(' → ')}`,
        cycles: cycleCheck.cycles,
      });
    }

    const formulaHash = crypto.createHash('sha256').update(formula).digest('hex').slice(0, 16);
    const newVersion = ((component as any).version ?? 0) + 1;

    // Snapshot current formula to version history
    await scope.payComponentVersion.create({
      data: {
        componentId,
        formula,
        version: newVersion,
        changedBy,
        changeNote: changeNote ?? null,
        formulaHash,
      },
    });

    // Update the component
    await scope.payComponent.update?.({
      where: { id: componentId },
      data: { formula, version: newVersion, updatedAt: new Date() },
    });

    // Invalidate graph cache for this tenant
    this.invalidateCache(tenantId);

    // Audit log
    await this.auditSvc.log({
      tenantId,
      action: 'paycomponent_formula_updated',
      resourceType: 'pay_component',
      resourceId: componentId,
      performedBy: changedBy,
      metadata: {
        oldFormula: (component as any).formula,
        newFormula: formula,
        version: newVersion,
        hash: formulaHash,
        changeNote,
      },
    });

    this.logger.log(`[${tenantId}] Component ${(component as any).code} formula updated to v${newVersion}`);
    return { version: newVersion, hash: formulaHash };
  }

  // ─── ROLLBACK TO PREVIOUS VERSION ─────────────────────────────────────────

  async rollbackFormula(
    tenantId: string,
    componentId: string,
    targetVersion: number,
    rolledBackBy: string,
  ): Promise<{ version: number }> {
    const scope = this.db.forTenant(tenantId);

    const versionRecord = await scope.payComponentVersion.findFirst({
      where: { componentId, version: targetVersion },
    });
    if (!versionRecord) throw new BadRequestException(`Version ${targetVersion} not found`);

    return this.saveFormula(
      tenantId,
      componentId,
      (versionRecord as any).formula,
      rolledBackBy,
      `Rollback to version ${targetVersion}`,
    );
  }

  // ─── LOAD & CACHE DEPENDENCY GRAPH ────────────────────────────────────────

  private async loadGraph(tenantId: string): Promise<CachedGraph> {
    const cached = this.graphCache.get(tenantId);
    if (cached && (Date.now() - cached.cachedAt) < GRAPH_CACHE_TTL_MS) {
      return cached;
    }

    const scope = this.db.forTenant(tenantId);
    const components = await scope.payComponent.findMany({
      where: { isActive: true },
      orderBy: { code: 'asc' },
    }) as any[];

    if (components.length > ENGINE_LIMITS.MAX_COMPONENTS) {
      throw new BadRequestException(`Component count ${components.length} exceeds limit of ${ENGINE_LIMITS.MAX_COMPONENTS}`);
    }

    const codes = new Set(components.map((c: any) => c.code as string));
    const formulaComponents = components.filter((c: any) => c.type === 'FORMULA' && c.formula);

    // Build graph and sort
    const graph = buildDependencyGraph(formulaComponents as any, codes);
    const topoResult = topologicalSort(graph);

    if (!topoResult.success) {
      throw new BadRequestException({
        message: `Circular dependency detected in pay components: ${topoResult.cycle?.join(' → ')}`,
        cycles: topoResult.cycle,
      });
    }

    // Pre-parse all formula ASTs
    const astMap = new Map<string, AstNode>();
    for (const comp of formulaComponents) {
      if (comp.formula) {
        astMap.set(comp.code, parse(comp.formula));
      }
    }

    // Build graph hash from all formula hashes
    const formulaStr = formulaComponents
      .sort((a: any, b: any) => a.code.localeCompare(b.code))
      .map((c: any) => `${c.code}:${c.version}:${c.formula}`)
      .join('|');
    const graphHash = crypto.createHash('sha256').update(formulaStr).digest('hex').slice(0, 16);

    // Build full evaluation order: fixed components first, then formula components in topo order
    const fixedCodes = components.filter((c: any) => c.type === 'FIXED').map((c: any) => c.code);
    const formulaOrder = (topoResult.order ?? []).filter((code: string) => !fixedCodes.includes(code));
    const fullOrder = [...fixedCodes, ...formulaOrder];

    const entry: CachedGraph = {
      order: fullOrder,
      astMap,
      graphHash,
      cachedAt: Date.now(),
    };
    this.graphCache.set(tenantId, entry);
    return entry;
  }

  private invalidateCache(tenantId: string) {
    this.graphCache.delete(tenantId);
  }

  // ─── EVALUATE FOR ONE EMPLOYEE ─────────────────────────────────────────────

  async evaluateForEmployee(
    tenantId: string,
    ctx: EvalContext,
    fixedComponents: Record<string, number>,
  ): Promise<ExpressionEngineResult> {
    const startMs = Date.now();
    const { order, astMap, graphHash } = await this.loadGraph(tenantId);
    const scope = this.db.forTenant(tenantId);

    // Load component definitions (from cache ideally — here we accept they come pre-loaded)
    const components = await scope.payComponent.findMany({
      where: { isActive: true },
    }) as any[];
    const compMap = new Map(components.map((c: any) => [c.code, c]));

    // Seed context with fixed component values
    const resolvedComponents = { ...fixedComponents };
    ctx.components = resolvedComponents;

    const results: ComponentResult[] = [];
    const warnings: string[] = [];
    const errors: string[] = [];

    // Evaluate in topological order
    for (const code of order) {
      const comp = compMap.get(code);
      if (!comp) continue;

      let value: number;

      if (comp.type === 'FIXED') {
        value = fixedComponents[code] ?? 0;
      } else if (comp.type === 'FORMULA' && comp.formula) {
        const ast = astMap.get(code);
        if (!ast) {
          errors.push(`AST not found for ${code}`);
          continue;
        }

        // Timeout guard
        if (Date.now() - startMs > ENGINE_LIMITS.TIMEOUT_MS) {
          errors.push(`Evaluation timeout exceeded for component ${code}`);
          break;
        }

        try {
          const result = evaluate(ast, ctx);
          warnings.push(...result.warnings.map(w => `[${code}] ${w}`));
          value = result.value;
        } catch (e: any) {
          errors.push(`[${code}] ${e.message}`);
          value = 0;
        }
      } else if (comp.type === 'STATUTORY') {
        // Statutory components are computed by the statutory engine, not here
        value = resolvedComponents[code] ?? 0;
      } else {
        value = 0;
      }

      // Apply rounding
      value = applyRounding(value, comp.roundingRule ?? 'ROUND');

      // Apply bounds
      if (comp.minValue !== undefined && comp.minValue !== null && value < comp.minValue) {
        warnings.push(`[${code}] Value ${value} below minimum ${comp.minValue} — clamped`);
        value = comp.minValue;
      }
      if (comp.maxValue !== undefined && comp.maxValue !== null && value > comp.maxValue) {
        warnings.push(`[${code}] Value ${value} above maximum ${comp.maxValue} — clamped`);
        value = comp.maxValue;
      }

      // Safety: no negative statutory outputs
      if (!comp.isDeduction && !comp.canOverrideBasic && value < 0) {
        warnings.push(`[${code}] Negative earning clamped to 0`);
        value = 0;
      }

      // Update running GROSS in context
      if (!comp.isDeduction) {
        ctx.GROSS = (ctx.GROSS ?? 0) + value;
      }

      resolvedComponents[code] = value;
      ctx.components = resolvedComponents;

      results.push({
        code: comp.code,
        name: comp.name,
        value,
        formulaUsed: comp.type === 'FORMULA' ? comp.formula : undefined,
        version: comp.version,
        isDeduction: comp.isDeduction ?? false,
        isTaxable: comp.isTaxable ?? true,
        computedAt: new Date(),
      });
    }

    const earnings   = results.filter(r => !r.isDeduction);
    const deductions = results.filter(r => r.isDeduction);
    const grossEarnings   = earnings.reduce((s, r) => s + r.value, 0);
    const totalDeductions = deductions.reduce((s, r) => s + r.value, 0);
    const taxableIncome   = earnings.filter(r => r.isTaxable).reduce((s, r) => s + r.value, 0);

    return {
      employeeId: ctx.components['__employeeId__'] ? String(ctx.components['__employeeId__']) : '',
      components: results,
      earnings,
      deductions,
      grossEarnings,
      totalDeductions,
      taxableIncome,
      formulaGraphHash: graphHash,
      evaluationOrder: order,
      warnings,
      errors,
    };
  }

  // ─── BATCH: evaluate 1000 employees ────────────────────────────────────────

  async evaluateBatch(
    tenantId: string,
    employees: Array<{ ctx: EvalContext; fixedComponents: Record<string, number>; employeeId: string }>,
  ): Promise<Map<string, ExpressionEngineResult>> {
    // Pre-load graph once (cached)
    await this.loadGraph(tenantId);

    const results = new Map<string, ExpressionEngineResult>();
    const t0 = Date.now();

    for (const emp of employees) {
      const result = await this.evaluateForEmployee(tenantId, emp.ctx, emp.fixedComponents);
      results.set(emp.employeeId, { ...result, employeeId: emp.employeeId });
    }

    const elapsed = Date.now() - t0;
    this.logger.log(`[${tenantId}] Batch evaluation: ${employees.length} employees in ${elapsed}ms`);
    if (elapsed > 200) {
      this.logger.warn(`[${tenantId}] Batch exceeded 200ms target: ${elapsed}ms`);
    }

    return results;
  }

  // ─── VERSION HISTORY ───────────────────────────────────────────────────────

  async getVersionHistory(tenantId: string, componentId: string) {
    const scope = this.db.forTenant(tenantId);
    return scope.payComponentVersion.findMany({
      where: { componentId },
      orderBy: { version: 'desc' },
    });
  }

  async getComponents(tenantId: string) {
    const scope = this.db.forTenant(tenantId);
    return scope.payComponent.findMany({
      where: { isActive: true },
      orderBy: { code: 'asc' },
    });
  }
}

// ─── Rounding helper ──────────────────────────────────────────────────────────

function applyRounding(value: number, rule: RoundingRule): number {
  switch (rule) {
    case 'ROUND': return Math.round(value);
    case 'FLOOR': return Math.floor(value);
    case 'CEIL':  return Math.ceil(value);
    default:      return value;
  }
}
