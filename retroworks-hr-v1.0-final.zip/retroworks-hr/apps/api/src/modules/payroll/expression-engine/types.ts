/**
 * Expression Engine — Type Definitions
 * ──────────────────────────────────────────────────────────────────────────────
 * Complete type system for the payroll formula DSL.
 * No runtime mutations. All types are readonly-friendly.
 */

// ─── TOKEN TYPES ──────────────────────────────────────────────────────────────

export type TokenType =
  // Literals
  | 'NUMBER'
  | 'IDENTIFIER'
  | 'STRING'
  // Arithmetic operators
  | 'PLUS' | 'MINUS' | 'STAR' | 'SLASH' | 'PERCENT'
  // Comparison operators
  | 'GT' | 'LT' | 'GTE' | 'LTE' | 'EQ' | 'NEQ'
  // Logical operators (keyword tokens)
  | 'AND' | 'OR' | 'NOT'
  // Grouping
  | 'LPAREN' | 'RPAREN'
  // Comma (for function args)
  | 'COMMA'
  // Dot (for property access: workerCategory.applyPF)
  | 'DOT'
  // Special
  | 'EOF';

export interface Token {
  type: TokenType;
  value: string;
  pos: number; // character position for error reporting
}

// ─── AST NODE TYPES ───────────────────────────────────────────────────────────

export type NodeType =
  | 'Number'
  | 'Identifier'
  | 'PropertyAccess'   // workerCategory.applyPF
  | 'BinaryOp'
  | 'UnaryOp'
  | 'FunctionCall'     // IF, MIN, MAX, ROUND, FLOOR, CEIL, ABS
  | 'Conditional';     // IF(cond, then, else) — sugar over FunctionCall

export interface NumberNode {
  type: 'Number';
  value: number;
}

export interface IdentifierNode {
  type: 'Identifier';
  name: string; // BASIC, GROSS, HRA, SPECIAL_ALLOWANCE, etc.
}

export interface PropertyAccessNode {
  type: 'PropertyAccess';
  object: string;    // workerCategory, legalEntity
  property: string;  // applyPF, isPayrollEligible, state
}

export type BinaryOperator = '+' | '-' | '*' | '/' | '%' | '>' | '<' | '>=' | '<=' | '==' | '!=' | 'AND' | 'OR';

export interface BinaryOpNode {
  type: 'BinaryOp';
  op: BinaryOperator;
  left: AstNode;
  right: AstNode;
}

export interface UnaryOpNode {
  type: 'UnaryOp';
  op: '-' | 'NOT';
  operand: AstNode;
}

export type BuiltinFunction = 'IF' | 'MIN' | 'MAX' | 'ROUND' | 'FLOOR' | 'CEIL' | 'ABS';

export interface FunctionCallNode {
  type: 'FunctionCall';
  name: BuiltinFunction;
  args: AstNode[];
}

export type AstNode =
  | NumberNode
  | IdentifierNode
  | PropertyAccessNode
  | BinaryOpNode
  | UnaryOpNode
  | FunctionCallNode;

// ─── FORMULA & COMPONENT TYPES ────────────────────────────────────────────────

export type ComponentType = 'FIXED' | 'FORMULA' | 'STATUTORY';
export type RoundingRule = 'NONE' | 'ROUND' | 'FLOOR' | 'CEIL';

export interface PayComponentDefinition {
  id: string;
  tenantId: string;
  code: string;           // HRA, SPECIAL_ALLOWANCE, CUSTOM_ALLOWANCE_1, etc.
  name: string;           // Display name
  type: ComponentType;
  formula?: string;       // Raw formula string (if type=FORMULA)
  formulaAst?: AstNode;   // Parsed AST (populated by engine, not stored)
  version: number;
  isActive: boolean;
  isTaxable: boolean;     // Include in TDS computation
  isDeduction: boolean;   // True = deduction, False = earning
  roundingRule: RoundingRule;
  canOverrideBasic: boolean;
  maxValue?: number;      // Hard cap (e.g. LTA: ₹20K/year)
  minValue?: number;      // Hard floor
  description?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PayComponentVersion {
  id: string;
  componentId: string;
  formula: string;
  version: number;
  changedBy: string;
  changeNote?: string;
  formulaHash: string;  // SHA-256 of formula for integrity
  createdAt: Date;
}

// ─── EVALUATION CONTEXT ───────────────────────────────────────────────────────

export interface WorkerCategory {
  code: string;
  applyPF: boolean;
  applyESI: boolean;
  isPayrollEligible: boolean;
  isContractWorker: boolean;
}

export interface LegalEntity {
  id: string;
  state: string;   // State code: KA, MH, etc.
  pfTrustExempt: boolean;
}

export interface EvalContext {
  // System variables
  BASIC: number;
  GROSS: number;          // Running gross (sum of earnings so far)
  CTC: number;            // Annual CTC (may be 0 if not set)
  WORKING_DAYS: number;   // Standard working days in month (default 26)
  LOP_DAYS: number;       // Loss of pay days
  ATTENDANCE_DAYS: number; // Actual days attended
  YEARS_OF_SERVICE: number;

  // Context objects
  workerCategory: WorkerCategory;
  legalEntity: LegalEntity;

  // Resolved component values (populated as evaluation progresses)
  components: Record<string, number>; // { HRA: 5000, SPECIAL_ALLOWANCE: 3000, ... }
}

// ─── ENGINE RESULTS ────────────────────────────────────────────────────────────

export interface ComponentResult {
  code: string;
  name: string;
  value: number;
  formulaUsed?: string;
  version: number;
  isDeduction: boolean;
  isTaxable: boolean;
  computedAt: Date;
}

export interface ExpressionEngineResult {
  employeeId: string;
  components: ComponentResult[];
  earnings: ComponentResult[];
  deductions: ComponentResult[];
  grossEarnings: number;
  totalDeductions: number;
  taxableIncome: number;
  formulaGraphHash: string;   // Hash of the dependency graph used
  evaluationOrder: string[];  // Component codes in topological order
  warnings: string[];
  errors: string[];
}

// ─── VALIDATION ────────────────────────────────────────────────────────────────

export type ValidationSeverity = 'ERROR' | 'WARNING';

export interface ValidationIssue {
  severity: ValidationSeverity;
  code: string;
  message: string;
  pos?: number; // Character position in formula
}

export interface ValidationResult {
  valid: boolean;
  issues: ValidationIssue[];
  ast?: AstNode;
  dependencies: string[]; // Component codes this formula depends on
  systemVars: string[];   // System variables used
  contextVars: string[];  // Context vars used (workerCategory.*, legalEntity.*)
}

// ─── DEPENDENCY GRAPH ─────────────────────────────────────────────────────────

export interface DependencyGraph {
  nodes: string[];                    // Component codes
  edges: Map<string, Set<string>>;    // code → Set<dependency codes>
  reverseEdges: Map<string, Set<string>>; // dependency → Set<dependents>
}

export interface TopologicalResult {
  success: boolean;
  order?: string[];   // Evaluation order (dependencies first)
  cycle?: string[];   // Cycle path if detected
}

// ─── SAFETY CONSTRAINTS ───────────────────────────────────────────────────────

export const ENGINE_LIMITS = {
  MAX_FORMULA_LENGTH: 1_000,
  MAX_DEPTH: 20,           // Max AST nesting depth
  MAX_COMPONENTS: 200,     // Max components per tenant
  TIMEOUT_MS: 50,          // Per-employee evaluation timeout
  MAX_ARGS: 3,             // Max function arguments (IF takes exactly 3)
} as const;

export const SYSTEM_VARIABLES = new Set([
  'BASIC', 'GROSS', 'CTC',
  'WORKING_DAYS', 'LOP_DAYS', 'ATTENDANCE_DAYS',
  'YEARS_OF_SERVICE',
]);

export const CONTEXT_OBJECTS = new Set(['workerCategory', 'legalEntity']);

export const WORKER_CATEGORY_PROPS = new Set([
  'applyPF', 'applyESI', 'isPayrollEligible', 'isContractWorker',
]);

export const LEGAL_ENTITY_PROPS = new Set([
  'state', 'pfTrustExempt',
]);

export const BUILTIN_FUNCTIONS = new Set<BuiltinFunction>([
  'IF', 'MIN', 'MAX', 'ROUND', 'FLOOR', 'CEIL', 'ABS',
]);

export const FUNCTION_ARITY: Record<BuiltinFunction, number | [number, number]> = {
  IF: 3,
  MIN: 2,
  MAX: 2,
  ROUND: 2,
  FLOOR: 1,
  CEIL: 1,
  ABS: 1,
};
