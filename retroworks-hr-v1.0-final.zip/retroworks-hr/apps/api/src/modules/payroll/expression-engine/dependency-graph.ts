/**
 * Expression Engine — Dependency Graph
 * ──────────────────────────────────────────────────────────────────────────────
 * Builds a directed dependency graph from all formula components.
 * Performs topological sort (Kahn's algorithm — O(V+E)).
 * Detects cycles with path reconstruction for error messages.
 *
 * Example:
 *   BONUS = BASIC * 0.1
 *   SPECIAL = GROSS - BASIC - HRA - BONUS
 *
 *   Graph: BONUS → BASIC
 *          SPECIAL → GROSS, BASIC, HRA, BONUS
 *
 *   Topo order: BASIC, HRA, BONUS, SPECIAL
 *
 * Circular detection:
 *   A = B * 0.1
 *   B = A + 100
 *   → Cycle: A → B → A
 *   → Blocks payroll with descriptive error
 */

import { parse } from './parser';
import type {
  AstNode, PayComponentDefinition,
  DependencyGraph, TopologicalResult,
} from './types';
import { SYSTEM_VARIABLES, CONTEXT_OBJECTS } from './types';

// ─── Extract all identifiers referenced in an AST ─────────────────────────────

export function extractDependencies(ast: AstNode): {
  components: Set<string>;
  systemVars: Set<string>;
  contextVars: Set<string>;
} {
  const components = new Set<string>();
  const systemVars = new Set<string>();
  const contextVars = new Set<string>();

  function walk(node: AstNode): void {
    switch (node.type) {
      case 'Number':
        break;

      case 'Identifier':
        if (SYSTEM_VARIABLES.has(node.name)) {
          systemVars.add(node.name);
        } else if (!CONTEXT_OBJECTS.has(node.name)) {
          // Not a system var, not a context object root → component reference
          components.add(node.name);
        }
        break;

      case 'PropertyAccess':
        contextVars.add(`${node.object}.${node.property}`);
        break;

      case 'BinaryOp':
        walk(node.left);
        walk(node.right);
        break;

      case 'UnaryOp':
        walk(node.operand);
        break;

      case 'FunctionCall':
        for (const arg of node.args) walk(arg);
        break;
    }
  }

  walk(ast);
  return { components, systemVars, contextVars };
}

// ─── Build directed dependency graph ─────────────────────────────────────────

export function buildDependencyGraph(
  components: PayComponentDefinition[],
  knownCodes: Set<string>,
): DependencyGraph {
  const nodes: string[] = [];
  const edges   = new Map<string, Set<string>>();
  const reverseEdges = new Map<string, Set<string>>();

  for (const comp of components) {
    nodes.push(comp.code);
    edges.set(comp.code, new Set());
    if (!reverseEdges.has(comp.code)) reverseEdges.set(comp.code, new Set());

    if (comp.type === 'FORMULA' && comp.formula) {
      const ast = parse(comp.formula);
      const { components: deps } = extractDependencies(ast);

      for (const dep of deps) {
        if (!knownCodes.has(dep)) continue; // skip unknown refs (caught by validator)
        edges.get(comp.code)!.add(dep);
        if (!reverseEdges.has(dep)) reverseEdges.set(dep, new Set());
        reverseEdges.get(dep)!.add(comp.code);
      }
    }
  }

  return { nodes, edges, reverseEdges };
}

// ─── Topological sort (Kahn's algorithm) ─────────────────────────────────────

export function topologicalSort(graph: DependencyGraph): TopologicalResult {
  // in-degree: number of incoming edges per node
  const inDegree = new Map<string, number>();
  for (const node of graph.nodes) {
    inDegree.set(node, 0);
  }
  for (const [, deps] of graph.edges) {
    for (const dep of deps) {
      inDegree.set(dep, (inDegree.get(dep) ?? 0)); // dep itself doesn't change
    }
  }
  // Actually: in-degree = how many nodes depend on this node
  // For payroll eval order: we want deps before dependents
  // So in-degree of X = number of components that X depends on
  for (const [node, deps] of graph.edges) {
    inDegree.set(node, deps.size);
  }

  const queue: string[] = [];
  for (const [node, deg] of inDegree) {
    if (deg === 0) queue.push(node);
  }

  // Sort queue for determinism
  queue.sort();

  const order: string[] = [];
  const remaining = new Map(inDegree);

  while (queue.length > 0) {
    // Pick lowest-alphabetical for determinism
    queue.sort();
    const node = queue.shift()!;
    order.push(node);

    // For each component that depends on this node, decrement in-degree
    const dependents = graph.reverseEdges.get(node) ?? new Set();
    for (const dep of dependents) {
      const newDeg = (remaining.get(dep) ?? 1) - 1;
      remaining.set(dep, newDeg);
      if (newDeg === 0) queue.push(dep);
    }
  }

  if (order.length !== graph.nodes.length) {
    // Cycle detected — reconstruct cycle path for error message
    const inCycle = graph.nodes.filter(n => !order.includes(n));
    const cycle = reconstructCycle(graph, inCycle);
    return { success: false, cycle };
  }

  return { success: true, order };
}

// ─── Cycle path reconstruction ────────────────────────────────────────────────

function reconstructCycle(graph: DependencyGraph, candidates: string[]): string[] {
  const candidateSet = new Set(candidates);

  for (const start of candidates) {
    const path = dfsDetectCycle(graph, start, candidateSet);
    if (path.length > 0) return path;
  }

  return candidates; // fallback: return all candidates
}

function dfsDetectCycle(
  graph: DependencyGraph,
  start: string,
  candidates: Set<string>,
): string[] {
  const visited = new Set<string>();
  const path: string[] = [];

  function dfs(node: string): boolean {
    if (path.includes(node)) {
      // Found cycle — extract the cycle portion
      const cycleStart = path.indexOf(node);
      path.splice(0, cycleStart); // keep only the cycle
      path.push(node); // close the cycle
      return true;
    }
    if (visited.has(node)) return false;
    visited.add(node);
    path.push(node);

    for (const dep of graph.edges.get(node) ?? new Set()) {
      if (candidates.has(dep)) {
        if (dfs(dep)) return true;
      }
    }

    path.pop();
    return false;
  }

  dfs(start);
  return path;
}
