/**
 * Expression Engine — Parser
 * ──────────────────────────────────────────────────────────────────────────────
 * Recursive-descent parser. Builds a typed AST from the token stream.
 * Enforces operator precedence correctly:
 *
 *   Precedence (lowest → highest):
 *     1. OR
 *     2. AND
 *     3. NOT (unary)
 *     4. Comparison: > < >= <= == !=
 *     5. Addition/Subtraction: + -
 *     6. Multiplication/Division/Modulo: * / %
 *     7. Unary minus: -expr
 *     8. Primary: number | identifier | property access | function call | (expr)
 *
 * No eval(). No Function(). Pure recursive descent.
 * Depth-limited to ENGINE_LIMITS.MAX_DEPTH to prevent stack overflow.
 */

import { tokenize, LexerError } from './lexer';
import type {
  Token, TokenType, AstNode, NumberNode, IdentifierNode,
  PropertyAccessNode, BinaryOpNode, UnaryOpNode, FunctionCallNode,
  BinaryOperator, BuiltinFunction,
} from './types';
import {
  BUILTIN_FUNCTIONS, FUNCTION_ARITY, CONTEXT_OBJECTS,
  ENGINE_LIMITS,
} from './types';

export class ParseError extends Error {
  constructor(message: string, public pos: number) {
    super(`Parse error at position ${pos}: ${message}`);
    this.name = 'ParseError';
  }
}

export function parse(source: string): AstNode {
  if (source.length > ENGINE_LIMITS.MAX_FORMULA_LENGTH) {
    throw new ParseError(`Formula exceeds ${ENGINE_LIMITS.MAX_FORMULA_LENGTH} character limit`, 0);
  }

  const tokens = tokenize(source);
  let pos = 0;

  function peek(): Token { return tokens[pos]!; }
  function advance(): Token { return tokens[pos++]!; }
  function check(type: TokenType): boolean { return peek().type === type; }

  function expect(type: TokenType): Token {
    const t = advance();
    if (t.type !== type) {
      throw new ParseError(`Expected ${type}, got ${t.type} ('${t.value}')`, t.pos);
    }
    return t;
  }

  function match(...types: TokenType[]): boolean {
    if (types.includes(peek().type)) { advance(); return true; }
    return false;
  }

  // ── Depth guard ───────────────────────────────────────────────────────────
  let depth = 0;
  function withDepth<T>(fn: () => T): T {
    if (++depth > ENGINE_LIMITS.MAX_DEPTH) {
      throw new ParseError(`Formula too deeply nested (max ${ENGINE_LIMITS.MAX_DEPTH} levels)`, peek().pos);
    }
    const result = fn();
    depth--;
    return result;
  }

  // ── Grammar rules (lowest to highest precedence) ──────────────────────────

  function expression(): AstNode { return orExpr(); }

  function orExpr(): AstNode {
    let left = andExpr();
    while (check('OR')) {
      const p = peek().pos; advance();
      const right = andExpr();
      left = { type: 'BinaryOp', op: 'OR', left, right } as BinaryOpNode;
    }
    return left;
  }

  function andExpr(): AstNode {
    let left = notExpr();
    while (check('AND')) {
      const p = peek().pos; advance();
      const right = notExpr();
      left = { type: 'BinaryOp', op: 'AND', left, right } as BinaryOpNode;
    }
    return left;
  }

  function notExpr(): AstNode {
    if (check('NOT')) {
      const p = peek().pos; advance();
      const operand = withDepth(notExpr);
      return { type: 'UnaryOp', op: 'NOT', operand } as UnaryOpNode;
    }
    return comparison();
  }

  function comparison(): AstNode {
    let left = addSub();
    const cmpOps: Partial<Record<TokenType, BinaryOperator>> = {
      GT: '>', LT: '<', GTE: '>=', LTE: '<=', EQ: '==', NEQ: '!=',
    };
    while (cmpOps[peek().type]) {
      const op = cmpOps[peek().type]!;
      advance();
      const right = addSub();
      left = { type: 'BinaryOp', op, left, right } as BinaryOpNode;
    }
    return left;
  }

  function addSub(): AstNode {
    let left = mulDiv();
    while (check('PLUS') || check('MINUS')) {
      const op = peek().value as '+' | '-'; advance();
      const right = mulDiv();
      left = { type: 'BinaryOp', op, left, right } as BinaryOpNode;
    }
    return left;
  }

  function mulDiv(): AstNode {
    let left = unaryMinus();
    while (check('STAR') || check('SLASH') || check('PERCENT')) {
      const op = peek().value as '*' | '/' | '%'; advance();
      const right = unaryMinus();
      left = { type: 'BinaryOp', op, left, right } as BinaryOpNode;
    }
    return left;
  }

  function unaryMinus(): AstNode {
    if (check('MINUS')) {
      const p = peek().pos; advance();
      const operand = withDepth(unaryMinus);
      return { type: 'UnaryOp', op: '-', operand } as UnaryOpNode;
    }
    return primary();
  }

  function primary(): AstNode {
    const t = peek();

    // Number literal
    if (t.type === 'NUMBER') {
      advance();
      return { type: 'Number', value: parseFloat(t.value) } as NumberNode;
    }

    // Parenthesised expression
    if (t.type === 'LPAREN') {
      advance();
      const expr = withDepth(expression);
      expect('RPAREN');
      return expr;
    }

    // Identifier — could be:
    //   1. function call: IF(...)  MIN(...)  MAX(...)
    //   2. property access: workerCategory.applyPF
    //   3. simple variable: BASIC  HRA  SPECIAL_ALLOWANCE
    if (t.type === 'IDENTIFIER') {
      advance();
      const name = t.value;

      // Property access: workerCategory.X or legalEntity.X
      if (check('DOT') && CONTEXT_OBJECTS.has(name)) {
        advance(); // consume DOT
        const propTok = expect('IDENTIFIER');
        return {
          type: 'PropertyAccess',
          object: name,
          property: propTok.value,
        } as PropertyAccessNode;
      }

      // Function call
      if (check('LPAREN')) {
        if (!BUILTIN_FUNCTIONS.has(name.toUpperCase() as BuiltinFunction)) {
          throw new ParseError(`Unknown function '${name}'`, t.pos);
        }
        const fnName = name.toUpperCase() as BuiltinFunction;
        advance(); // consume LPAREN
        const args: AstNode[] = [];

        if (!check('RPAREN')) {
          args.push(withDepth(expression));
          while (check('COMMA')) {
            advance();
            args.push(withDepth(expression));
          }
        }
        expect('RPAREN');

        // Arity validation
        const arity = FUNCTION_ARITY[fnName];
        const expectedArity = typeof arity === 'number' ? arity : arity;
        const arityNum = typeof expectedArity === 'number' ? expectedArity : expectedArity[0];
        if (args.length !== arityNum) {
          throw new ParseError(
            `Function ${fnName} requires exactly ${arityNum} argument(s), got ${args.length}`,
            t.pos,
          );
        }
        if (args.length > ENGINE_LIMITS.MAX_ARGS) {
          throw new ParseError(`Function ${fnName} exceeds max argument count`, t.pos);
        }

        return { type: 'FunctionCall', name: fnName, args } as FunctionCallNode;
      }

      // Simple variable/component reference
      return { type: 'Identifier', name } as IdentifierNode;
    }

    throw new ParseError(`Unexpected token '${t.value}' (${t.type})`, t.pos);
  }

  // ── Top-level parse ───────────────────────────────────────────────────────
  const ast = expression();
  if (!check('EOF')) {
    throw new ParseError(`Unexpected token '${peek().value}' after expression`, peek().pos);
  }
  return ast;
}
