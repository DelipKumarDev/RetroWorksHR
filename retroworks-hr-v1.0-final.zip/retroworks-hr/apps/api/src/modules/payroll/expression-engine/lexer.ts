/**
 * Expression Engine — Lexer
 * ──────────────────────────────────────────────────────────────────────────────
 * Converts raw formula string into a flat token stream.
 * Pure function. No side effects. No external dependencies.
 *
 * Grammar handled:
 *   Numbers:       123, 123.45, .5
 *   Identifiers:   BASIC, HRA, workerCategory, IF, MIN, MAX
 *   Operators:     + - * / % > < >= <= == != ( ) , .
 *   Keywords:      AND OR NOT
 */

import type { Token, TokenType } from './types';

export class LexerError extends Error {
  constructor(message: string, public pos: number) {
    super(`Lexer error at position ${pos}: ${message}`);
    this.name = 'LexerError';
  }
}

const KEYWORDS: Record<string, TokenType> = {
  AND: 'AND',
  OR: 'OR',
  NOT: 'NOT',
};

export function tokenize(source: string): Token[] {
  const tokens: Token[] = [];
  let i = 0;

  while (i < source.length) {
    // Skip whitespace
    if (/\s/.test(source[i]!)) { i++; continue; }

    const pos = i;
    const ch = source[i]!;

    // ── Numbers ────────────────────────────────────────────────────────────
    if (/[0-9]/.test(ch) || (ch === '.' && /[0-9]/.test(source[i + 1] ?? ''))) {
      let num = '';
      let hasDot = false;
      while (i < source.length && (/[0-9]/.test(source[i]!) || (!hasDot && source[i] === '.'))) {
        if (source[i] === '.') hasDot = true;
        num += source[i++];
      }
      tokens.push({ type: 'NUMBER', value: num, pos });
      continue;
    }

    // ── Identifiers and keywords ────────────────────────────────────────────
    if (/[A-Za-z_]/.test(ch)) {
      let id = '';
      while (i < source.length && /[A-Za-z0-9_]/.test(source[i]!)) {
        id += source[i++];
      }
      const kw = KEYWORDS[id.toUpperCase()];
      if (kw) {
        tokens.push({ type: kw, value: id.toUpperCase(), pos });
      } else {
        tokens.push({ type: 'IDENTIFIER', value: id, pos });
      }
      continue;
    }

    // ── Two-character operators ─────────────────────────────────────────────
    const two = source.slice(i, i + 2);
    if (two === '>=') { tokens.push({ type: 'GTE', value: '>=', pos }); i += 2; continue; }
    if (two === '<=') { tokens.push({ type: 'LTE', value: '<=', pos }); i += 2; continue; }
    if (two === '==') { tokens.push({ type: 'EQ',  value: '==', pos }); i += 2; continue; }
    if (two === '!=') { tokens.push({ type: 'NEQ', value: '!=', pos }); i += 2; continue; }

    // ── Single-character operators ──────────────────────────────────────────
    const single: Record<string, TokenType> = {
      '+': 'PLUS', '-': 'MINUS', '*': 'STAR', '/': 'SLASH',
      '%': 'PERCENT', '>': 'GT', '<': 'LT',
      '(': 'LPAREN', ')': 'RPAREN', ',': 'COMMA', '.': 'DOT',
    };
    if (single[ch]) {
      tokens.push({ type: single[ch]!, value: ch, pos });
      i++;
      continue;
    }

    throw new LexerError(`Unexpected character '${ch}'`, pos);
  }

  tokens.push({ type: 'EOF', value: '', pos: source.length });
  return tokens;
}
