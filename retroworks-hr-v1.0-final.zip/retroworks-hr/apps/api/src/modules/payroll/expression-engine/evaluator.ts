/**
 * Expression Engine — Safe Evaluator
 * ──────────────────────────────────────────────────────────────────────────────
 * Evaluates a parsed AST against an EvalContext.
 * SAFETY CONTRACT:
 *   - No eval()
 *   - No Function()
 *   - No dynamic property access beyond approved context objects
 *   - Division by zero → returns 0 with warning (not throw)
 *   - Undefined variable → throws EvalError with name
 *   - Depth limited to ENGINE_LIMITS.MAX_DEPTH
 *   - Returns NaN only when explicitly reported as error
 *   - All monetary values rounded to 2 decimal places at output boundary
 */

import type {
  AstNode, EvalContext, BuiltinFunction,
} from './types';
import {
  SYSTEM_VARIABLES, CONTEXT_OBJECTS,
  WORKER_CATEGORY_PROPS, LEGAL_ENTITY_PROPS,
  ENGINE_LIMITS,
} from './types';

export class EvalError extends Error {
  constructor(message: string, public code: string) {
    super(message);
    this.name = 'EvalError';
  }
}

export interface EvalResult {
  value: number;
  warnings: string[];
}

export function evaluate(ast: AstNode, ctx: EvalContext): EvalResult {
  const warnings: string[] = [];
  let depth = 0;

  function evalNode(node: AstNode): number {
    if (++depth > ENGINE_LIMITS.MAX_DEPTH) {
      throw new EvalError('Formula evaluation depth exceeded', 'DEPTH_EXCEEDED');
    }

    let result: number;

    switch (node.type) {

      // ── Literals ──────────────────────────────────────────────────────────
      case 'Number':
        result = node.value;
        break;

      // ── Variable reference ─────────────────────────────────────────────────
      case 'Identifier': {
        const name = node.name;

        // System variables
        if (SYSTEM_VARIABLES.has(name)) {
          const v = (ctx as Record<string, unknown>)[name];
          if (v === undefined || v === null) {
            throw new EvalError(`System variable '${name}' is not defined in context`, 'UNDEFINED_VAR');
          }
          result = v as number;
          break;
        }

        // Component reference
        if (Object.prototype.hasOwnProperty.call(ctx.components, name)) {
          result = ctx.components[name]!;
          break;
        }

        throw new EvalError(`Unknown variable or component '${name}'`, 'UNDEFINED_VAR');
      }

      // ── Property access ────────────────────────────────────────────────────
      case 'PropertyAccess': {
        const obj = node.object;
        const prop = node.property;

        if (obj === 'workerCategory') {
          if (!WORKER_CATEGORY_PROPS.has(prop)) {
            throw new EvalError(`Unknown property 'workerCategory.${prop}'`, 'UNKNOWN_PROPERTY');
          }
          const val = (ctx.workerCategory as Record<string, unknown>)[prop];
          // Boolean properties → 1 (true) or 0 (false)
          result = val === true ? 1 : val === false ? 0 : (val as number);
          break;
        }

        if (obj === 'legalEntity') {
          if (!LEGAL_ENTITY_PROPS.has(prop)) {
            throw new EvalError(`Unknown property 'legalEntity.${prop}'`, 'UNKNOWN_PROPERTY');
          }
          const val = (ctx.legalEntity as Record<string, unknown>)[prop];
          result = val === true ? 1 : val === false ? 0 : (val as number);
          break;
        }

        throw new EvalError(`Unknown context object '${obj}'`, 'UNKNOWN_CONTEXT');
      }

      // ── Binary operations ──────────────────────────────────────────────────
      case 'BinaryOp': {
        const left  = evalNode(node.left);
        const right = evalNode(node.right);

        switch (node.op) {
          case '+': result = left + right; break;
          case '-': result = left - right; break;
          case '*': result = left * right; break;
          case '/':
            if (right === 0) {
              warnings.push('Division by zero encountered — returning 0');
              result = 0;
            } else {
              result = left / right;
            }
            break;
          case '%':
            if (right === 0) {
              warnings.push('Modulo by zero encountered — returning 0');
              result = 0;
            } else {
              result = left % right;
            }
            break;
          // Comparisons → 1 (true) or 0 (false)
          case '>':  result = left > right  ? 1 : 0; break;
          case '<':  result = left < right  ? 1 : 0; break;
          case '>=': result = left >= right ? 1 : 0; break;
          case '<=': result = left <= right ? 1 : 0; break;
          case '==': result = left === right ? 1 : 0; break;
          case '!=': result = left !== right ? 1 : 0; break;
          case 'AND': result = (left !== 0 && right !== 0) ? 1 : 0; break;
          case 'OR':  result = (left !== 0 || right !== 0) ? 1 : 0; break;
          default:
            throw new EvalError(`Unknown operator '${node.op}'`, 'UNKNOWN_OP');
        }
        break;
      }

      // ── Unary operations ───────────────────────────────────────────────────
      case 'UnaryOp': {
        const operand = evalNode(node.operand);
        if (node.op === '-') {
          result = -operand;
        } else if (node.op === 'NOT') {
          result = operand === 0 ? 1 : 0;
        } else {
          throw new EvalError(`Unknown unary operator '${node.op}'`, 'UNKNOWN_OP');
        }
        break;
      }

      // ── Function calls ─────────────────────────────────────────────────────
      case 'FunctionCall': {
        const fn = node.name as BuiltinFunction;
        const args = node.args.map(a => evalNode(a));

        switch (fn) {
          case 'IF': {
            // IF(condition, trueValue, falseValue)
            // Condition is truthy if non-zero
            const [cond, thenVal, elseVal] = args as [number, number, number];
            result = cond !== 0 ? thenVal : elseVal;
            break;
          }
          case 'MIN': result = Math.min(args[0]!, args[1]!); break;
          case 'MAX': result = Math.max(args[0]!, args[1]!); break;
          case 'ROUND': {
            const precision = args[1] ?? 0;
            const factor = Math.pow(10, precision);
            result = Math.round(args[0]! * factor) / factor;
            break;
          }
          case 'FLOOR': result = Math.floor(args[0]!); break;
          case 'CEIL':  result = Math.ceil(args[0]!);  break;
          case 'ABS':   result = Math.abs(args[0]!);   break;
          default:
            throw new EvalError(`Unknown function '${fn}'`, 'UNKNOWN_FUNCTION');
        }
        break;
      }

      default:
        throw new EvalError(`Unknown AST node type`, 'UNKNOWN_NODE');
    }

    depth--;

    // Safety: never return NaN or Infinity from evaluator
    if (!isFinite(result) || isNaN(result)) {
      warnings.push(`Computation produced ${result} — returning 0`);
      return 0;
    }

    return result;
  }

  const value = evalNode(ast);
  return { value, warnings };
}

// ─── Convenience: evaluate a formula string directly ─────────────────────────

export function evaluateFormula(
  formula: string,
  ctx: EvalContext,
  ast: import('./types').AstNode,
): EvalResult {
  return evaluate(ast, ctx);
}
