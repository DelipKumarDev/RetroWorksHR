/**
 * Expression Engine — Formula Validator
 * ──────────────────────────────────────────────────────────────────────────────
 * Static analysis pass: validates formula BEFORE it is saved or executed.
 * Never runs the formula. Only inspects the AST.
 *
 * Catches:
 *   - Syntax errors (via parser)
 *   - Unknown functions
 *   - Unknown variables (not in system vars, context, or known components)
 *   - Formula too long
 *   - Potential division by zero (static literal check)
 *   - BASIC override without explicit permission
 *   - Circular dependencies (via dependency graph)
 *   - Negative statutory output (heuristic check)
 */

import { parse, ParseError } from './parser';
import { LexerError } from './lexer';
import { extractDependencies } from './dependency-graph';
import type {
  ValidationResult, ValidationIssue, PayComponentDefinition,
  AstNode,
} from './types';
import {
  SYSTEM_VARIABLES, CONTEXT_OBJECTS, WORKER_CATEGORY_PROPS,
  LEGAL_ENTITY_PROPS, BUILTIN_FUNCTIONS, ENGINE_LIMITS,
} from './types';

export function validateFormula(
  formula: string,
  knownComponentCodes: Set<string>,
  currentCode: string,
  canOverrideBasic = false,
): ValidationResult {
  const issues: ValidationIssue[] = [];

  // ── 1. Length check ───────────────────────────────────────────────────────
  if (formula.length > ENGINE_LIMITS.MAX_FORMULA_LENGTH) {
    issues.push({
      severity: 'ERROR',
      code: 'FORMULA_TOO_LONG',
      message: `Formula exceeds ${ENGINE_LIMITS.MAX_FORMULA_LENGTH} character limit (${formula.length} chars)`,
    });
    return { valid: false, issues, dependencies: [], systemVars: [], contextVars: [] };
  }

  // ── 2. Syntax (parse) ─────────────────────────────────────────────────────
  let ast: AstNode;
  try {
    ast = parse(formula);
  } catch (e) {
    const pos = (e as ParseError | LexerError).pos;
    issues.push({
      severity: 'ERROR',
      code: 'SYNTAX_ERROR',
      message: (e as Error).message,
      pos,
    });
    return { valid: false, issues, dependencies: [], systemVars: [], contextVars: [] };
  }

  // ── 3. Extract all references ──────────────────────────────────────────────
  const { components, systemVars, contextVars } = extractDependencies(ast);

  const deps = Array.from(components);
  const sysVarList = Array.from(systemVars);
  const ctxVarList = Array.from(contextVars);

  // ── 4. Check for self-reference ───────────────────────────────────────────
  if (components.has(currentCode)) {
    issues.push({
      severity: 'ERROR',
      code: 'SELF_REFERENCE',
      message: `Formula references its own component code '${currentCode}'`,
    });
  }

  // ── 5. Unknown component references ───────────────────────────────────────
  for (const dep of components) {
    if (!knownComponentCodes.has(dep) && !SYSTEM_VARIABLES.has(dep)) {
      issues.push({
        severity: 'ERROR',
        code: 'UNKNOWN_COMPONENT',
        message: `Unknown component reference '${dep}'. Not a system variable or known component code.`,
      });
    }
  }

  // ── 6. Context object property validation ─────────────────────────────────
  for (const ctxVar of contextVars) {
    const [obj, prop] = ctxVar.split('.');
    if (obj === 'workerCategory' && !WORKER_CATEGORY_PROPS.has(prop!)) {
      issues.push({
        severity: 'ERROR',
        code: 'UNKNOWN_PROPERTY',
        message: `Unknown property 'workerCategory.${prop}'. Valid: ${Array.from(WORKER_CATEGORY_PROPS).join(', ')}`,
      });
    }
    if (obj === 'legalEntity' && !LEGAL_ENTITY_PROPS.has(prop!)) {
      issues.push({
        severity: 'ERROR',
        code: 'UNKNOWN_PROPERTY',
        message: `Unknown property 'legalEntity.${prop}'. Valid: ${Array.from(LEGAL_ENTITY_PROPS).join(', ')}`,
      });
    }
  }

  // ── 7. BASIC override check ────────────────────────────────────────────────
  if (!canOverrideBasic && formula.toUpperCase().includes('BASIC')) {
    // Warning only — BASIC is a valid input to computations, just not output target
    issues.push({
      severity: 'WARNING',
      code: 'BASIC_REFERENCE',
      message: 'Formula references BASIC. If this component is meant to override basic salary, set canOverrideBasic=true.',
    });
  }

  // ── 8. Static division-by-zero detection (literal zero divisor) ───────────
  checkDivisionByZeroStatic(ast, issues);

  // ── 9. Redundant double-negation warning ──────────────────────────────────
  checkDoubleNegation(ast, issues);

  const hasErrors = issues.some(i => i.severity === 'ERROR');

  return {
    valid: !hasErrors,
    issues,
    ast: hasErrors ? undefined : ast,
    dependencies: deps,
    systemVars: sysVarList,
    contextVars: ctxVarList,
  };
}

// ─── Static literal division-by-zero check ────────────────────────────────────

function checkDivisionByZeroStatic(node: AstNode, issues: ValidationIssue[]): void {
  if (
    node.type === 'BinaryOp' &&
    (node.op === '/' || node.op === '%') &&
    node.right.type === 'Number' &&
    node.right.value === 0
  ) {
    issues.push({
      severity: 'ERROR',
      code: 'DIVISION_BY_ZERO',
      message: 'Formula contains literal division by zero',
    });
  }
  if (node.type === 'BinaryOp') {
    checkDivisionByZeroStatic(node.left, issues);
    checkDivisionByZeroStatic(node.right, issues);
  }
  if (node.type === 'UnaryOp') checkDivisionByZeroStatic(node.operand, issues);
  if (node.type === 'FunctionCall') node.args.forEach(a => checkDivisionByZeroStatic(a, issues));
}

// ─── Double negation warning ──────────────────────────────────────────────────

function checkDoubleNegation(node: AstNode, issues: ValidationIssue[]): void {
  if (node.type === 'UnaryOp' && node.op === '-' && node.operand.type === 'UnaryOp' && node.operand.op === '-') {
    issues.push({
      severity: 'WARNING',
      code: 'DOUBLE_NEGATION',
      message: 'Double negation (--x) detected. Consider removing.',
    });
  }
  if (node.type === 'BinaryOp') {
    checkDoubleNegation(node.left, issues);
    checkDoubleNegation(node.right, issues);
  }
  if (node.type === 'UnaryOp') checkDoubleNegation(node.operand, issues);
  if (node.type === 'FunctionCall') node.args.forEach(a => checkDoubleNegation(a, issues));
}

// ─── Validate all components together (for cycle detection) ──────────────────

import { buildDependencyGraph, topologicalSort } from './dependency-graph';

export function validateComponentSet(
  components: PayComponentDefinition[],
): { valid: boolean; cycles?: string[]; evaluationOrder?: string[] } {
  const codes = new Set(components.map(c => c.code));

  const graph = buildDependencyGraph(
    components.filter(c => c.type === 'FORMULA'),
    codes,
  );

  const result = topologicalSort(graph);

  if (!result.success) {
    return { valid: false, cycles: result.cycle };
  }

  // Return full evaluation order including FIXED components first
  const formulaOrder = result.order ?? [];
  const fixedComponents = components
    .filter(c => c.type === 'FIXED')
    .map(c => c.code);

  // Fixed components don't depend on formulas — evaluate first
  const fullOrder = [...fixedComponents, ...formulaOrder.filter(c => !fixedComponents.includes(c))];

  return { valid: true, evaluationOrder: fullOrder };
}
