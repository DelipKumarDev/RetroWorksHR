/**
 * Expression Engine Module — Phase 2B
 * Controller: admin pay component CRUD + formula validation + version management
 */

import {
  Controller, Get, Post, Put, Body, Param, Query,
  UseGuards, HttpCode, HttpStatus, BadRequestException,
} from '@nestjs/common';
import { Module } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { IsString, IsBoolean, IsOptional, IsNumber, IsEnum } from 'class-validator';
import { ExpressionEngineService } from './expression-engine.service';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { Roles } from '../../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

class SaveFormulaDto {
  @IsString() formula!: string;
  @IsString() @IsOptional() changeNote?: string;
}

class ValidateFormulaDto {
  @IsString() formula!: string;
  @IsString() componentCode!: string;
  @IsBoolean() @IsOptional() canOverrideBasic?: boolean;
}

class RollbackDto {
  @IsNumber() targetVersion!: number;
}

@ApiTags('payroll/components')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('payroll/components')
export class ExpressionEngineController {
  constructor(private readonly engine: ExpressionEngineService) {}

  @Get()
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'List all pay components' })
  getComponents(@CurrentUser() u: JwtPayload) {
    return this.engine.getComponents(u.tid);
  }

  @Post('validate')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Validate a formula before saving — returns AST analysis and dependency list' })
  validateFormula(
    @Body() dto: ValidateFormulaDto,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.engine.validateFormulaForTenant(
      u.tid,
      dto.formula,
      dto.componentCode,
      dto.canOverrideBasic ?? false,
    );
  }

  @Put(':componentId/formula')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Save formula — validates, creates version snapshot, invalidates cache' })
  saveFormula(
    @Param('componentId') id: string,
    @Body() dto: SaveFormulaDto,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.engine.saveFormula(u.tid, id, dto.formula, u.sub, dto.changeNote);
  }

  @Get(':componentId/versions')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Version history for a component' })
  getVersions(
    @Param('componentId') id: string,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.engine.getVersionHistory(u.tid, id);
  }

  @Post(':componentId/rollback')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Rollback to a previous formula version' })
  rollback(
    @Param('componentId') id: string,
    @Body() dto: RollbackDto,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.engine.rollbackFormula(u.tid, id, dto.targetVersion, u.sub);
  }
}

@Module({
  controllers: [ExpressionEngineController],
  providers: [ExpressionEngineService],
  exports: [ExpressionEngineService],
})
export class ExpressionEngineModule {}
