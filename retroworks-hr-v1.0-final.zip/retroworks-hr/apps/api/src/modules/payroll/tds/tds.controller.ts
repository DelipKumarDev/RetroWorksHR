/**
 * TDS Controller — REST API for India TDS module
 * ══════════════════════════════════════════════════
 * Endpoints:
 *   POST   /tds/declarations/:employeeId          — Save tax declaration
 *   GET    /tds/declarations/:employeeId          — Get tax declaration
 *   GET    /tds/projections/:employeeId           — Get TDS projection
 *   POST   /tds/regime-compare/:employeeId        — Compare old vs new regime
 *   GET    /tds/summary/:employeeId               — Annual TDS summary (Form 16 data)
 *   GET    /tds/summary/bulk                      — All employees TDS summary
 *   GET    /tds/log/:employeeId                   — Recalculation audit log
 *   GET    /tds/slabs/:financialYear              — View tax slabs for FY
 *   POST   /tds/slabs/:financialYear/seed         — Seed default slabs (super-admin)
 */

import {
  Controller, Get, Post, Put, Body, Param, Query,
  UseGuards, HttpCode, HttpStatus, Logger,
} from '@nestjs/common';
import {
  ApiTags, ApiOperation, ApiBearerAuth, ApiParam,
  ApiQuery, ApiOkResponse, ApiCreatedResponse,
} from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { IsString, IsEnum, IsOptional, IsNumber, IsBoolean, Min, Max } from 'class-validator';
import { Transform } from 'class-transformer';
import { TdsService } from './tds.service';
import { TenantGuard } from '../../../common/guards/tenant.guard';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { Roles } from '../../../common/decorators/permissions.decorator';
import { getCurrentFy } from './tds.engine';
import type { JwtPayload } from '@retroworks/types';

// ─────────────────────────────────────────────────────────────────────────────
// DTOs
// ─────────────────────────────────────────────────────────────────────────────

export class SaveDeclarationRequestDto {
  @IsEnum(['old', 'new'])
  regimeType!: 'old' | 'new';

  @IsOptional() @IsNumber() @Min(0) @Max(150_000)
  section80C?: number;

  @IsOptional() @IsNumber() @Min(0) @Max(25_000)
  section80D_self?: number;

  @IsOptional() @IsNumber() @Min(0) @Max(50_000)
  section80D_parents?: number;

  @IsOptional() @IsBoolean()
  section80D_parentsIsSenior?: boolean;

  @IsOptional() @IsNumber() @Min(0) @Max(50_000)
  section80CCD1B?: number;

  @IsOptional() @IsNumber() @Min(0)
  hraRentPaid?: number;

  @IsOptional() @IsEnum(['metro', 'non-metro'])
  hraCityType?: 'metro' | 'non-metro';

  @IsOptional() @IsNumber() @Min(0)
  ltaAmountClaimed?: number;

  @IsOptional() @IsNumber() @Min(0) @Max(200_000)
  homeLoanInterest?: number;

  @IsOptional() @IsNumber() @Min(0)
  otherDeductions?: number;

  @IsOptional() @IsNumber() @Min(0)
  prevEmployerIncome?: number;

  @IsOptional() @IsNumber() @Min(0)
  prevEmployerTds?: number;

  @IsOptional() @IsNumber() @Min(0)
  prevEmployerPfContrib?: number;

  @IsOptional() @IsNumber() @Min(0)
  projectedBonusForFy?: number;
}

export class RegimeCompareRequestDto {
  @IsNumber() @Min(1) @Max(12)
  month!: number;

  @IsNumber()
  year!: number;

  @IsOptional() @IsString()
  financialYear?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// CONTROLLER
// ─────────────────────────────────────────────────────────────────────────────

@ApiTags('TDS & Income Tax')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('tds')
export class TdsController {
  private readonly logger = new Logger(TdsController.name);

  constructor(private readonly tdsService: TdsService) {}

  // ─── Declarations ─────────────────────────────────────────────────────────

  @Post('declarations/:employeeId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Save employee tax declaration',
    description: 'Employee or HR saves investment declarations and regime choice. Triggers TDS recalculation.',
  })
  async saveDeclaration(
    @Param('employeeId') employeeId: string,
    @Body() dto: SaveDeclarationRequestDto,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const result = await this.tdsService.saveDeclaration(
      user.tid, employeeId, fy, dto, user.sub,
    );
    return {
      success: true,
      declaration: result,
      message: 'Tax declaration saved. TDS will be recalculated in next payroll run.',
      disclaimer: '⚠️ Final tax liability subject to CA validation.',
    };
  }

  @Get('declarations/:employeeId')
  @ApiOperation({ summary: 'Get employee tax declaration' })
  @ApiQuery({ name: 'financialYear', required: false, example: '2024-25' })
  async getDeclaration(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const declaration = await this.tdsService.getDeclaration(user.tid, employeeId, fy);
    return {
      employeeId,
      financialYear: fy,
      declaration: declaration ?? null,
      hasDeclaration: !!declaration,
      defaultRegime: 'new',
      disclaimer: '⚠️ Declarations must be submitted before the specified cut-off date.',
    };
  }

  // ─── Projections ──────────────────────────────────────────────────────────

  @Get('projections/:employeeId')
  @ApiOperation({
    summary: 'Get TDS projection for employee',
    description: 'Returns the latest calculated TDS projection including full tax breakdown.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async getProjection(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const projection = await this.tdsService.getProjection(user.tid, employeeId, fy);
    if (!projection) {
      return {
        employeeId,
        financialYear: fy,
        projection: null,
        message: 'No TDS projection calculated yet. Run payroll to generate projection.',
      };
    }
    return {
      employeeId,
      financialYear: fy,
      projection: {
        regimeType: projection.regimeType,
        projectedAnnualIncome: Number(projection.projectedAnnualIncome),
        totalTaxLiability: Number(projection.totalTaxLiability),
        totalCess: Number(projection.totalCess),
        monthlyTDS: Number(projection.monthlyTDS),
        recalculatedAt: projection.recalculatedAt,
        breakdown: projection.calculationBreakdown,
      },
      disclaimer: '⚠️ This is a projected estimate. Final liability subject to CA validation.',
    };
  }

  // ─── Regime Comparison ────────────────────────────────────────────────────

  @Post('regime-compare/:employeeId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Compare Old vs New tax regime',
    description: 'Returns detailed comparison of both regimes with recommendation.',
  })
  async compareRegimes(
    @Param('employeeId') employeeId: string,
    @Body() dto: RegimeCompareRequestDto,
    @CurrentUser() user: JwtPayload,
  ) {
    // Get salary structure for comparison
    const employee = await this.tdsService['prisma'].employee.findFirst({
      where: { id: employeeId, tenantId: user.tid },
      include: { salaryStructure: true },
    });
    if (!employee?.salaryStructure) {
      return { error: 'No salary structure found for employee' };
    }

    const ss = employee.salaryStructure;

    const comparison = await this.tdsService.compareRegimesForEmployee(
      user.tid,
      employeeId,
      dto.month,
      dto.year,
      {
        basic: Number(ss.basic),
        hra: Number(ss.hra),
        specialAllowance: Number(ss.specialAllowance),
        lta: Number(ss.lta),
        medicalAllowance: Number(ss.medicalAllowance),
        otherAllowances: Number(ss.otherAllowances),
        pfEmployeeMonthly: Number(ss.basic) <= 15000
          ? Number(ss.basic) * 0.12
          : 1800,
      },
      { ytdGrossPaid: 0, ytdTdsDeducted: 0, ytdPfDeducted: 0 },
    );

    return {
      ...comparison,
      summary: {
        recommendedRegime: comparison.recommendedRegime,
        annualSaving: comparison.annualSavings,
        monthlySaving: comparison.monthlySavings,
        oldRegimeTax: comparison.oldRegime.annualTax,
        newRegimeTax: comparison.newRegime.annualTax,
        oldRegimeMonthly: comparison.oldRegime.monthlyTax,
        newRegimeMonthly: comparison.newRegime.monthlyTax,
      },
    };
  }

  // ─── Reports ─────────────────────────────────────────────────────────────

  @Get('summary/bulk')
  @Roles('hr-admin', 'payroll-admin', 'super-admin')
  @ApiOperation({
    summary: 'All employees TDS summary',
    description: 'Payroll team view — all employees projected TDS for a financial year.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async getBulkSummary(
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    return this.tdsService.getBulkTdsSummary(user.tid, fy);
  }

  @Get('summary/:employeeId')
  @ApiOperation({
    summary: 'Annual TDS summary (Form 16 data)',
    description: 'Full annual tax computation for one employee. Used for Form 16 Part B.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async getAnnualSummary(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    return this.tdsService.getAnnualTdsSummary(user.tid, employeeId, fy);
  }

  @Get('log/:employeeId')
  @ApiOperation({
    summary: 'TDS recalculation audit log',
    description: 'Full history of every TDS recalculation — shows what changed and why.',
  })
  @ApiQuery({ name: 'financialYear', required: false })
  async getLog(
    @Param('employeeId') employeeId: string,
    @Query('financialYear') financialYear: string | undefined,
    @CurrentUser() user: JwtPayload,
  ) {
    const fy = financialYear ?? getCurrentFy();
    const logs = await this.tdsService.getRecalculationLog(user.tid, employeeId, fy);
    return {
      employeeId,
      financialYear: fy,
      totalRecalculations: logs.length,
      log: logs,
    };
  }

  // ─── Slab Management ─────────────────────────────────────────────────────

  @Get('slabs/:financialYear')
  @Roles('hr-admin', 'payroll-admin', 'super-admin')
  @ApiOperation({ summary: 'View tax slabs for a financial year' })
  async getSlabs(
    @Param('financialYear') financialYear: string,
    @CurrentUser() _user: JwtPayload,
  ) {
    const slabs = await this.tdsService.getSlabsForFy(financialYear);
    return {
      financialYear,
      slabCount: slabs.length,
      slabs,
      note: 'These slabs are loaded from DB. Edit via admin panel or seed defaults for a new FY.',
    };
  }

  @Post('slabs/:financialYear/seed')
  @Roles('super-admin')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Seed default tax slabs for a financial year (super-admin)',
    description: 'Seeds Finance Act compliant slabs. Overwrites existing slabs for this FY.',
  })
  async seedSlabs(
    @Param('financialYear') financialYear: string,
    @CurrentUser() user: JwtPayload,
  ) {
    const result = await this.tdsService.seedDefaultSlabs(financialYear, user.sub);
    return {
      success: true,
      financialYear,
      slabsCreated: result.count,
      message: `Tax slabs seeded for FY ${financialYear}. Old slabs replaced.`,
    };
  }

  // ─── Utility ─────────────────────────────────────────────────────────────

  @Get('current-fy')
  @ApiOperation({ summary: 'Get current financial year string' })
  getCurrentFy() {
    return {
      financialYear: getCurrentFy(),
      note: 'Indian Financial Year runs April to March.',
    };
  }
}
