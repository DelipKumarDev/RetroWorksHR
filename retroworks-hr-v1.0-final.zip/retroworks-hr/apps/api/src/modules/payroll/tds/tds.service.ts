/**
 * TDS Service — Database-backed TDS Management
 * ══════════════════════════════════════════════
 * AUDIT-PAYROLL-2: Refactored to use PrismaTenantService exclusively.
 *
 * BEFORE: 14 direct this.prisma.* calls.
 * AFTER:  Zero. All tenant-scoped reads/writes go through scope = db.forTenant(tenantId).
 *
 * GLOBAL via $global (no tenantId column):
 *   taxSlab    — system-wide FY tax config, shared across all tenants
 *   fyTaxConfig — (optional) non-slab FY parameters
 *
 * upsert → findFirst+create/update:
 *   employeeTaxDeclaration: compound key tenantId_employeeId_financialYear unsafe with proxy
 *   tDSProjection:          compound key tenantId_employeeId_financialYear unsafe with proxy
 */

import { Injectable, NotFoundException, Logger, BadRequestException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import {
  DEFAULT_FY_CONFIG, FyConfig, TaxSlabRow, SurchargeSlabRow,
  TaxDeclaration, TdsProjectionInput, MonthlyTdsResult, RegimeComparisonResult,
  projectTds, compareRegimes, calendarToFyMonth, getCurrentFy,
} from './tds.engine';

export interface SaveDeclarationDto {
  regimeType: 'old' | 'new';
  section80C?: number;
  section80D_self?: number;
  section80D_parents?: number;
  section80D_parentsIsSenior?: boolean;
  section80CCD1B?: number;
  hraRentPaid?: number;
  hraCityType?: 'metro' | 'non-metro';
  ltaAmountClaimed?: number;
  homeLoanInterest?: number;
  otherDeductions?: number;
  prevEmployerIncome?: number;
  prevEmployerTds?: number;
  prevEmployerPfContrib?: number;
  projectedBonusForFy?: number;
  isLocked?: boolean;
}

@Injectable()
export class TdsService {
  private readonly logger = new Logger(TdsService.name);
  private fyConfigCache = new Map<string, FyConfig>();

  constructor(
    private readonly db: PrismaTenantService,
    private readonly events: EventEmitter2,
  ) {}

  // ─── FY Configuration (global — taxSlab has no tenantId) ──────────────────

  async getFyConfig(financialYear: string): Promise<FyConfig> {
    const cached = this.fyConfigCache.get(financialYear);
    if (cached) return cached;

    // taxSlab is a global config table — no tenantId column, use $global
    const db = this.db.forTenant('__system__'); // gives us $global
    const slabRows = await db.$global.taxSlab.findMany({
      where: { financialYear },
      orderBy: [{ regimeType: 'asc' }, { slabFrom: 'asc' }],
    });

    if (slabRows.length === 0) {
      this.logger.warn(`No TaxSlab rows for FY ${financialYear} — using built-in defaults`);
      return DEFAULT_FY_CONFIG;
    }

    const fyConfigRow = await (db.$global as any).fyTaxConfig?.findFirst({
      where: { financialYear },
    }).catch(() => null);

    const d = DEFAULT_FY_CONFIG;
    const config: FyConfig = {
      financialYear,
      standardDeduction:           fyConfigRow?.standardDeductionNew   ?? d.standardDeduction,
      standardDeductionOld:        fyConfigRow?.standardDeductionOld   ?? d.standardDeductionOld,
      maxSection80C:               fyConfigRow?.maxSection80C          ?? d.maxSection80C,
      maxSection80D_self:          fyConfigRow?.maxSection80D_self     ?? d.maxSection80D_self,
      maxSection80D_parents:       fyConfigRow?.maxSection80D_parents  ?? d.maxSection80D_parents,
      maxSection80D_parentsSenior: fyConfigRow?.maxSection80D_parentsSenior ?? d.maxSection80D_parentsSenior,
      maxSection80CCD1B:           fyConfigRow?.maxSection80CCD1B      ?? d.maxSection80CCD1B,
      max87ARebate_new:            fyConfigRow?.max87ARebate_new       ?? d.max87ARebate_new,
      max87AThreshold_new:         fyConfigRow?.max87AThreshold_new    ?? d.max87AThreshold_new,
      max87ARebate_old:            fyConfigRow?.max87ARebate_old       ?? d.max87ARebate_old,
      max87AThreshold_old:         fyConfigRow?.max87AThreshold_old    ?? d.max87AThreshold_old,
      cessRate:                    fyConfigRow?.cessRate               ?? d.cessRate,
      newRegimeSlabs: slabRows
        .filter(s => s.regimeType === 'new')
        .map(s => ({ slabFrom: Number(s.slabFrom), slabTo: Number(s.slabTo), taxRate: Number(s.taxRate) })) as TaxSlabRow[],
      oldRegimeSlabs: slabRows
        .filter(s => s.regimeType === 'old')
        .map(s => ({ slabFrom: Number(s.slabFrom), slabTo: Number(s.slabTo), taxRate: Number(s.taxRate) })) as TaxSlabRow[],
      surchargeSlabs: d.surchargeSlabs as SurchargeSlabRow[],
    };

    if (config.newRegimeSlabs.length === 0) config.newRegimeSlabs = d.newRegimeSlabs;
    if (config.oldRegimeSlabs.length === 0) config.oldRegimeSlabs = d.oldRegimeSlabs;

    this.fyConfigCache.set(financialYear, config);
    return config;
  }

  invalidateFyCache(financialYear?: string): void {
    if (financialYear) this.fyConfigCache.delete(financialYear);
    else this.fyConfigCache.clear();
  }

  // ─── Tax Declarations ─────────────────────────────────────────────────────

  async getDeclaration(tenantId: string, employeeId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);
    // proxy injects tenantId
    return scope.employeeTaxDeclaration.findFirst({
      where: { employeeId, financialYear },
    });
  }

  async saveDeclaration(
    tenantId: string, employeeId: string, financialYear: string,
    dto: SaveDeclarationDto, savedBy: string,
  ) {
    const scope = this.db.forTenant(tenantId);

    const employee = await scope.employee.findFirst({
      where: { id: employeeId, deletedAt: null },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    const existing = await this.getDeclaration(tenantId, employeeId, financialYear);
    if ((existing as any)?.isLocked && !dto.isLocked) {
      throw new BadRequestException('Tax declaration is locked. Contact HR to unlock.');
    }

    const sharedData = {
      employeeId, financialYear,
      regimeType:                dto.regimeType,
      section80C:                dto.section80C                ?? 0,
      section80D_self:           dto.section80D_self           ?? 0,
      section80D_parents:        dto.section80D_parents        ?? 0,
      section80D_parentsIsSenior:dto.section80D_parentsIsSenior ?? false,
      section80CCD1B:            dto.section80CCD1B            ?? 0,
      hraRentPaid:               dto.hraRentPaid               ?? 0,
      hraCityType:               dto.hraCityType               ?? 'non-metro',
      ltaAmountClaimed:          dto.ltaAmountClaimed          ?? 0,
      homeLoanInterest:          dto.homeLoanInterest          ?? 0,
      otherDeductions:           dto.otherDeductions           ?? 0,
      prevEmployerIncome:        dto.prevEmployerIncome        ?? 0,
      prevEmployerTds:           dto.prevEmployerTds           ?? 0,
      prevEmployerPfContrib:     dto.prevEmployerPfContrib     ?? 0,
      projectedBonusForFy:       dto.projectedBonusForFy       ?? 0,
      isLocked:                  dto.isLocked                  ?? false,
      updatedBy:                 savedBy,
    };

    // findFirst + create/update — proxy-safe (no compound-key upsert)
    let declaration: any;
    if (existing) {
      declaration = await scope.employeeTaxDeclaration.update({
        where: { id: (existing as any).id },
        data: sharedData,
      });
    } else {
      declaration = await scope.employeeTaxDeclaration.create({
        data: { ...sharedData, createdBy: savedBy },
      });
    }

    this.events.emit('tds.declaration.updated', { tenantId, employeeId, financialYear });
    this.events.emit('audit.created', {
      tenantId, userId: savedBy, action: existing ? 'UPDATE' : 'CREATE',
      resource: 'tax-declaration', resourceId: declaration.id,
    });
    return declaration;
  }

  // ─── TDS Projection ───────────────────────────────────────────────────────

  async calculateAndSaveProjection(
    tenantId: string,
    employeeId: string,
    calendarMonth: number,
    year: number,
    salaryContext: {
      basic: number; hra: number; specialAllowance: number;
      lta: number; medicalAllowance: number; otherAllowances: number;
      bonus?: number; pfEmployeeMonthly: number;
    },
    ytdContext: { ytdGrossPaid: number; ytdTdsDeducted: number; ytdPfDeducted: number },
    triggeredBy: 'payroll_run' | 'declaration_update' | 'salary_revision' | 'manual',
  ): Promise<MonthlyTdsResult> {
    const scope = this.db.forTenant(tenantId);
    const { fyMonth, financialYear } = calendarToFyMonth(calendarMonth, year);
    const fyConfig = await this.getFyConfig(financialYear);

    const declarationRow = await this.getDeclaration(tenantId, employeeId, financialYear);
    const declaration: TaxDeclaration = declarationRow
      ? {
          regimeType:                (declarationRow as any).regimeType as 'old' | 'new',
          section80C:                Number((declarationRow as any).section80C),
          section80D_self:           Number((declarationRow as any).section80D_self),
          section80D_parents:        Number((declarationRow as any).section80D_parents),
          section80D_parentsIsSenior:(declarationRow as any).section80D_parentsIsSenior,
          section80CCD1B:            Number((declarationRow as any).section80CCD1B),
          hraRentPaid:               Number((declarationRow as any).hraRentPaid),
          hraCityType:               (declarationRow as any).hraCityType as 'metro' | 'non-metro',
          ltaAmountClaimed:          Number((declarationRow as any).ltaAmountClaimed),
          homeLoanInterest:          Number((declarationRow as any).homeLoanInterest),
          otherDeductions:           Number((declarationRow as any).otherDeductions),
          prevEmployerIncome:        Number((declarationRow as any).prevEmployerIncome),
          prevEmployerTds:           Number((declarationRow as any).prevEmployerTds),
          prevEmployerPfContrib:     Number((declarationRow as any).prevEmployerPfContrib),
        }
      : { regimeType: 'new' };

    const projectionInput: TdsProjectionInput = {
      employeeId, financialYear,
      currentMonth: fyMonth, currentCalendarMonth: calendarMonth, currentYear: year,
      salaryComponents: salaryContext, declaration,
      pfEmployeeMonthly: salaryContext.pfEmployeeMonthly,
      ytdGrossPaid: ytdContext.ytdGrossPaid,
      ytdTdsDeducted: ytdContext.ytdTdsDeducted,
      ytdPfDeducted: ytdContext.ytdPfDeducted,
      projectedBonusForFy: Number((declarationRow as any)?.projectedBonusForFy ?? 0),
      fyConfig,
    };

    const result = projectTds(projectionInput);

    // findFirst + create/update — proxy-safe (compound key includes tenantId)
    const existingProjection = await scope.tDSProjection.findFirst({
      where: { employeeId, financialYear },
    });

    const projData = {
      employeeId, financialYear,
      regimeType:             declaration.regimeType,
      projectedAnnualIncome:  result.projectedAnnualGross,
      totalTaxLiability:      result.totalAnnualTaxLiability,
      totalCess:              result.taxBreakdown.cess,
      totalTDS:               result.totalAnnualTaxLiability,
      monthlyTDS:             result.monthlyTdsAmount,
      recalculatedAt:         new Date(),
      calculationInput:       projectionInput as any,
      calculationBreakdown:   result.taxBreakdown as any,
      triggeredBy,
    };

    if (existingProjection) {
      await scope.tDSProjection.update({
        where: { id: (existingProjection as any).id },
        data: { ...projData, updatedBy: 'system' },
      });
    } else {
      await scope.tDSProjection.create({
        data: { ...projData, createdBy: 'system' },
      });
    }

    // Append to recalculation log
    await scope.tDSRecalculationLog.create({
      data: {
        employeeId, financialYear, calendarMonth, year,
        regimeType:          declaration.regimeType,
        previousMonthlyTds:  ytdContext.ytdTdsDeducted,
        newMonthlyTds:       result.monthlyTdsAmount,
        trigger:             triggeredBy,
        snapshot:            result as any,
        createdAt:           new Date(),
      },
    });

    this.logger.log(`TDS: ${employeeId} ${financialYear} M${fyMonth} → ₹${result.monthlyTdsAmount} (${declaration.regimeType})`);
    return result;
  }

  async getProjection(tenantId: string, employeeId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);
    return scope.tDSProjection.findFirst({ where: { employeeId, financialYear } });
  }

  async getRecalculationLog(tenantId: string, employeeId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);
    return scope.tDSRecalculationLog.findMany({
      where: { employeeId, financialYear },
      orderBy: { createdAt: 'desc' },
    });
  }

  // ─── Regime Comparison ────────────────────────────────────────────────────

  async compareRegimesForEmployee(
    tenantId: string, employeeId: string,
    calendarMonth: number, year: number,
    salaryContext: any, ytdContext: any,
  ): Promise<RegimeComparisonResult> {
    const { fyMonth, financialYear } = calendarToFyMonth(calendarMonth, year);
    const fyConfig = await this.getFyConfig(financialYear);
    const declarationRow = await this.getDeclaration(tenantId, employeeId, financialYear);
    const declarationBase = declarationRow ? {
      section80C:                Number((declarationRow as any).section80C),
      section80D_self:           Number((declarationRow as any).section80D_self),
      section80D_parents:        Number((declarationRow as any).section80D_parents),
      section80D_parentsIsSenior:(declarationRow as any).section80D_parentsIsSenior,
      section80CCD1B:            Number((declarationRow as any).section80CCD1B),
      hraRentPaid:               Number((declarationRow as any).hraRentPaid),
      hraCityType:               (declarationRow as any).hraCityType as 'metro' | 'non-metro',
      prevEmployerIncome:        Number((declarationRow as any).prevEmployerIncome),
      prevEmployerTds:           Number((declarationRow as any).prevEmployerTds),
      prevEmployerPfContrib:     Number((declarationRow as any).prevEmployerPfContrib),
    } : {};

    return compareRegimes({
      employeeId, financialYear,
      currentMonth: fyMonth, currentCalendarMonth: calendarMonth, currentYear: year,
      salaryComponents: salaryContext, declarationBase,
      pfEmployeeMonthly: salaryContext.pfEmployeeMonthly,
      ytdGrossPaid: ytdContext.ytdGrossPaid,
      ytdTdsDeducted: ytdContext.ytdTdsDeducted,
      ytdPfDeducted: ytdContext.ytdPfDeducted,
      fyConfig,
    });
  }

  // ─── TDS Summary Reports ──────────────────────────────────────────────────

  async getAnnualTdsSummary(tenantId: string, employeeId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);

    const employee = await scope.employee.findFirst({
      where: { id: employeeId },
      select: { id: true, firstName: true, lastName: true, employeeCode: true } as any,
    });
    if (!employee) throw new NotFoundException('Employee not found');

    const [projection, declaration] = await Promise.all([
      this.getProjection(tenantId, employeeId, financialYear),
      this.getDeclaration(tenantId, employeeId, financialYear),
    ]);

    const payslips = await scope.payslip.findMany({
      where: { employeeId, status: { not: 'cancelled' } as any } as any,
      select: { period: true, grossPay: true, components: true } as any,
      orderBy: { period: 'asc' } as any,
    });

    const monthlyLedger = (payslips as any[]).map((ps: any) => {
      const components = ps.components as any[];
      const tdsLine = components?.find?.((c: any) => c.name?.includes('TDS') || c.name?.includes('Income Tax'));
      return { period: ps.period, grossPay: Number(ps.grossPay), tdsDeducted: tdsLine?.amount ?? 0 };
    });
    const totalTdsDeducted = monthlyLedger.reduce((s, m) => s + m.tdsDeducted, 0);

    return {
      employee: {
        id: (employee as any).id,
        name: `${(employee as any).firstName} ${(employee as any).lastName}`,
        employeeCode: (employee as any).employeeCode,
        pan: (employee as any).pan ?? 'Not provided',
      },
      financialYear,
      regimeType: (declaration as any)?.regimeType ?? 'new',
      projectedAnnualIncome: projection ? Number((projection as any).projectedAnnualIncome) : null,
      totalTaxLiability:     projection ? Number((projection as any).totalTaxLiability) : null,
      totalTdsDeducted,
      balance: projection ? Number((projection as any).totalTaxLiability) - totalTdsDeducted : null,
      monthlyLedger, declaration: declaration ?? null,
      breakdown: (projection as any)?.calculationBreakdown ?? null,
      disclaimer: '⚠️ Final tax liability subject to CA validation.',
    };
  }

  async getBulkTdsSummary(tenantId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);
    const projections = await scope.tDSProjection.findMany({
      where: { financialYear },
      include: {
        employee: {
          select: {
            firstName: true, lastName: true, employeeCode: true,
            department: { select: { name: true } },
          },
        },
      },
      orderBy: { monthlyTDS: 'desc' },
    });

    const totals = (projections as any[]).reduce((acc, p) => ({
      totalProjectedIncome: acc.totalProjectedIncome + Number(p.projectedAnnualIncome),
      totalAnnualTax:       acc.totalAnnualTax       + Number(p.totalTaxLiability),
      totalMonthlyTds:      acc.totalMonthlyTds      + Number(p.monthlyTDS),
    }), { totalProjectedIncome: 0, totalAnnualTax: 0, totalMonthlyTds: 0 });

    return {
      financialYear, employeeCount: (projections as any[]).length, ...totals,
      projections: (projections as any[]).map(p => ({
        employeeId:       p.employeeId,
        name:             `${p.employee.firstName} ${p.employee.lastName}`,
        employeeCode:     p.employee.employeeCode,
        department:       p.employee.department?.name,
        regime:           p.regimeType,
        projectedIncome:  Number(p.projectedAnnualIncome),
        annualTax:        Number(p.totalTaxLiability),
        monthlyTds:       Number(p.monthlyTDS),
        recalculatedAt:   p.recalculatedAt,
      })),
      disclaimer: '⚠️ All figures are estimates. Subject to CA validation.',
    };
  }

  // ─── Slab Management (global config — no tenantId) ────────────────────────

  async getSlabsForFy(financialYear: string) {
    // taxSlab is a global table — no tenantId column
    const g = this.db.forTenant('__system__').$global;
    return g.taxSlab.findMany({
      where: { financialYear },
      orderBy: [{ regimeType: 'asc' }, { slabFrom: 'asc' }],
    });
  }

  async seedDefaultSlabs(financialYear: string, createdBy: string) {
    const g = this.db.forTenant('__system__').$global;
    const config = DEFAULT_FY_CONFIG;
    const slabs = [
      ...config.newRegimeSlabs.map(s => ({ ...s, regimeType: 'new', financialYear })),
      ...config.oldRegimeSlabs.map(s => ({ ...s, regimeType: 'old', financialYear })),
    ];
    await g.taxSlab.deleteMany({ where: { financialYear } });
    const created = await g.taxSlab.createMany({
      data: slabs.map(s => ({
        financialYear: s.financialYear, regimeType: s.regimeType,
        slabFrom: s.slabFrom, slabTo: s.slabTo, taxRate: s.taxRate, createdBy,
      })),
    });
    this.invalidateFyCache(financialYear);
    this.logger.log(`Seeded ${created.count} tax slabs for FY ${financialYear}`);
    return created;
  }
}
