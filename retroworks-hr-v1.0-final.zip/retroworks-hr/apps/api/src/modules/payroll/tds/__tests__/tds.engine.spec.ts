/**
 * RetroWorks HR — India TDS Engine Test Suite
 * ══════════════════════════════════════════════
 * 33 unit tests covering:
 *   ▸ Slab boundary cases
 *   ▸ Zero & high income
 *   ▸ New regime vs old regime
 *   ▸ HRA exemption (metro/non-metro)
 *   ▸ 80C cap enforcement
 *   ▸ 80D cap enforcement
 *   ▸ Section 87A rebate
 *   ▸ Education cess
 *   ▸ Surcharge thresholds
 *   ▸ Mid-year joiner
 *   ▸ Salary revision / monthly equalization
 *   ▸ YTD TDS adjustment
 *   ▸ Negative TDS prevention
 *   ▸ Regime comparison
 *   ▸ FY month utility functions
 *
 * Run: npx jest tds.engine.spec --verbose --coverage
 */

import {
  computeSlabTax,
  computeSurcharge,
  computeHraExemption,
  computeDeductions,
  computeAnnualTax,
  projectTds,
  compareRegimes,
  calendarToFyMonth,
  getCurrentFy,
  DEFAULT_FY_CONFIG,
  r2,
  type TdsProjectionInput,
  type TaxDeclaration,
} from '../tds.engine';

// ─────────────────────────────────────────────────────────────────────────────
// TEST HELPERS
// ─────────────────────────────────────────────────────────────────────────────

const FY = DEFAULT_FY_CONFIG;

const makeSalary = (basic: number, hra?: number, special?: number) => ({
  basic,
  hra: hra ?? basic * 0.4,
  specialAllowance: special ?? basic * 0.3,
  lta: 2000,
  medicalAllowance: 1250,
  otherAllowances: 0,
});

const makeInput = (
  override: Partial<TdsProjectionInput> & { basic: number }
): TdsProjectionInput => ({
  employeeId: 'test-emp',
  financialYear: '2024-25',
  currentMonth: 1,     // April = FY Month 1
  currentCalendarMonth: 4,
  currentYear: 2024,
  salaryComponents: makeSalary(override.basic),
  declaration: { regimeType: 'new' },
  pfEmployeeMonthly: Math.min(override.basic, 15000) * 0.12,
  ytdGrossPaid: 0,
  ytdTdsDeducted: 0,
  ytdPfDeducted: 0,
  fyConfig: FY,
  ...override,
});

// ─────────────────────────────────────────────────────────────────────────────
// 1. PURE SLAB TAX COMPUTATION
// ─────────────────────────────────────────────────────────────────────────────

describe('computeSlabTax', () => {

  test('T01 — Zero income = zero tax', () => {
    const { total } = computeSlabTax(0, FY.newRegimeSlabs);
    expect(total).toBe(0);
  });

  test('T02 — Income exactly at slab boundary (₹3,00,000 new regime = ₹0)', () => {
    const { total } = computeSlabTax(3_00_000, FY.newRegimeSlabs);
    expect(total).toBe(0);
  });

  test('T03 — Income ₹1 above first slab boundary = tax on ₹1', () => {
    const { total } = computeSlabTax(3_00_001, FY.newRegimeSlabs);
    // ₹1 at 5% = ₹0.05
    expect(total).toBeCloseTo(0.05, 2);
  });

  test('T04 — New regime ₹6,00,000 = ₹15,000 tax (5% of 3L)', () => {
    const { total } = computeSlabTax(6_00_000, FY.newRegimeSlabs);
    expect(total).toBe(15_000);
  });

  test('T05 — New regime ₹9,00,000 = ₹45,000 tax', () => {
    // 5% of 3L = 15,000 + 10% of 3L = 30,000 → total 45,000
    const { total } = computeSlabTax(9_00_000, FY.newRegimeSlabs);
    expect(total).toBe(45_000);
  });

  test('T06 — New regime ₹15,00,000 = ₹1,50,000 tax', () => {
    // 5%*3L + 10%*3L + 15%*3L + 20%*3L = 15K + 30K + 45K + 60K = 1,50,000
    const { total } = computeSlabTax(15_00_000, FY.newRegimeSlabs);
    expect(total).toBe(1_50_000);
  });

  test('T07 — Old regime ₹2,50,000 = ₹0 (within exemption)', () => {
    const { total } = computeSlabTax(2_50_000, FY.oldRegimeSlabs);
    expect(total).toBe(0);
  });

  test('T08 — Old regime ₹5,00,000 = ₹12,500 (5% on 2.5L)', () => {
    const { total } = computeSlabTax(5_00_000, FY.oldRegimeSlabs);
    expect(total).toBe(12_500);
  });

  test('T09 — Old regime ₹10,00,000 = ₹1,12,500', () => {
    // 0 on 2.5L + 5% on 2.5L = 12,500 + 20% on 5L = 1,00,000 → 1,12,500
    const { total } = computeSlabTax(10_00_000, FY.oldRegimeSlabs);
    expect(total).toBe(1_12_500);
  });

  test('T10 — Slab-wise breakdown is accurate', () => {
    const { total, slabWise } = computeSlabTax(9_00_000, FY.newRegimeSlabs);
    expect(slabWise.length).toBeGreaterThanOrEqual(2);
    const sumOfParts = slabWise.reduce((s, b) => s + b.taxInSlab, 0);
    expect(r2(sumOfParts)).toBe(total);
  });

  test('T11 — Very high income ₹2 crore', () => {
    const { total } = computeSlabTax(2_00_00_000, FY.newRegimeSlabs);
    // 30% of (2Cr - 15L) + flat amounts below
    expect(total).toBeGreaterThan(50_00_000);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 2. SECTION 87A REBATE
// ─────────────────────────────────────────────────────────────────────────────

describe('Section 87A Rebate', () => {

  test('T12 — New regime: ₹7L income = ₹0 tax (full rebate)', () => {
    const result = computeAnnualTax({
      taxableIncome: 7_00_000,
      regimeType: 'new',
      grossForSurcharge: 7_00_000,
      fyConfig: FY,
    });
    // Tax = 20K, rebate = min(20K, 25K) = 20K → net tax = 0
    expect(result.totalAnnualTax).toBe(0);
    expect(result.rebate87A).toBe(20_000);
  });

  test('T13 — New regime: ₹7,00,001 income — rebate NOT available', () => {
    const result = computeAnnualTax({
      taxableIncome: 7_00_001,
      regimeType: 'new',
      grossForSurcharge: 7_00_001,
      fyConfig: FY,
    });
    // Tax > 0 (₹1 above threshold = no rebate)
    expect(result.rebate87A).toBe(0);
    expect(result.totalAnnualTax).toBeGreaterThan(0);
  });

  test('T14 — Old regime: ₹5L income = ₹0 tax (rebate)', () => {
    const result = computeAnnualTax({
      taxableIncome: 5_00_000,
      regimeType: 'old',
      grossForSurcharge: 5_00_000,
      fyConfig: FY,
    });
    expect(result.totalAnnualTax).toBe(0);
    expect(result.rebate87A).toBe(12_500);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 3. EDUCATION CESS
// ─────────────────────────────────────────────────────────────────────────────

describe('Education Cess', () => {

  test('T15 — Cess is exactly 4% of (tax + surcharge)', () => {
    const result = computeAnnualTax({
      taxableIncome: 12_00_000,
      regimeType: 'new',
      grossForSurcharge: 12_00_000,
      fyConfig: FY,
    });
    const expectedCess = r2(result.taxAfterRebate * 1.04) - result.taxAfterRebate;
    expect(result.cess).toBeCloseTo(expectedCess, 0);
  });

  test('T16 — Zero tax = zero cess', () => {
    const result = computeAnnualTax({
      taxableIncome: 1_00_000,
      regimeType: 'new',
      grossForSurcharge: 1_00_000,
      fyConfig: FY,
    });
    expect(result.cess).toBe(0);
    expect(result.totalAnnualTax).toBe(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 4. HRA EXEMPTION
// ─────────────────────────────────────────────────────────────────────────────

describe('HRA Exemption (Old Regime)', () => {

  test('T17 — Metro city: limit3 = 50% of basic', () => {
    const hra = computeHraExemption({
      monthlyBasic: 50_000,
      monthlyHra: 20_000,
      monthlyRentPaid: 25_000,
      cityType: 'metro',
      remainingMonths: 12,
      elapsedMonths: 0,
    });
    // limit3 = 50% of 6L = 3L
    expect(hra.limit3_percentOfBasic).toBe(3_00_000);
  });

  test('T18 — Non-metro city: limit3 = 40% of basic', () => {
    const hra = computeHraExemption({
      monthlyBasic: 50_000,
      monthlyHra: 20_000,
      monthlyRentPaid: 25_000,
      cityType: 'non-metro',
      remainingMonths: 12,
      elapsedMonths: 0,
    });
    // limit3 = 40% of 6L = 2.4L
    expect(hra.limit3_percentOfBasic).toBe(2_40_000);
  });

  test('T19 — Exemption = minimum of 3 limits', () => {
    const hra = computeHraExemption({
      monthlyBasic: 50_000,
      monthlyHra: 20_000,   // limit1 = 2.4L
      monthlyRentPaid: 15_000,  // limit2 = 1.8L - 0.6L = 1.2L
      cityType: 'metro',   // limit3 = 3L
      remainingMonths: 12,
      elapsedMonths: 0,
    });
    // min(2.4L, 1.2L, 3L) = 1.2L
    expect(hra.exemptionAnnual).toBe(1_20_000);
  });

  test('T20 — Zero rent paid = zero exemption', () => {
    const hra = computeHraExemption({
      monthlyBasic: 50_000,
      monthlyHra: 20_000,
      monthlyRentPaid: 0,
      cityType: 'metro',
      remainingMonths: 12,
      elapsedMonths: 0,
    });
    expect(hra.exemptionAnnual).toBe(0);
    expect(hra.limit2_rentMinusBasic10).toBe(0);
  });

  test('T21 — Rent below 10% of basic = zero limit2', () => {
    const hra = computeHraExemption({
      monthlyBasic: 50_000,
      monthlyHra: 20_000,
      monthlyRentPaid: 4_000, // < 10% of 50K = 5K
      cityType: 'metro',
      remainingMonths: 12,
      elapsedMonths: 0,
    });
    expect(hra.limit2_rentMinusBasic10).toBe(0);
    expect(hra.exemptionAnnual).toBe(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 5. DEDUCTION CAPS
// ─────────────────────────────────────────────────────────────────────────────

describe('Deduction Caps', () => {

  test('T22 — 80C capped at ₹1,50,000 even if declared more', () => {
    const d = computeDeductions({
      declaration: { regimeType: 'old', section80C: 2_00_000 }, // Over cap
      pfEmployeeAnnual: 0,
      fyConfig: FY,
      regimeType: 'old',
    });
    expect(d.section80C_allowed).toBe(1_50_000);
  });

  test('T23 — 80C: PF contribution counted toward 80C cap', () => {
    const d = computeDeductions({
      declaration: { regimeType: 'old', section80C: 1_00_000 },
      pfEmployeeAnnual: 1_00_000, // PF alone = 1L
      fyConfig: FY,
      regimeType: 'old',
    });
    // Total = 2L, but cap = 1.5L
    expect(d.section80C_totalClaimed).toBe(2_00_000);
    expect(d.section80C_allowed).toBe(1_50_000);
  });

  test('T24 — 80D self capped at ₹25,000', () => {
    const d = computeDeductions({
      declaration: { regimeType: 'old', section80D_self: 40_000 },
      pfEmployeeAnnual: 0,
      fyConfig: FY,
      regimeType: 'old',
    });
    expect(d.section80D_self).toBe(25_000);
  });

  test('T25 — 80D senior citizen parents capped at ₹50,000', () => {
    const d = computeDeductions({
      declaration: {
        regimeType: 'old',
        section80D_parents: 60_000,
        section80D_parentsIsSenior: true,
      },
      pfEmployeeAnnual: 0,
      fyConfig: FY,
      regimeType: 'old',
    });
    expect(d.section80D_parents).toBe(50_000);
  });

  test('T26 — New regime: only standard deduction (₹75,000)', () => {
    const d = computeDeductions({
      declaration: { regimeType: 'new', section80C: 1_50_000, section80D_self: 25_000 },
      pfEmployeeAnnual: 21_600,
      fyConfig: FY,
      regimeType: 'new',
    });
    expect(d.totalDeductions).toBe(75_000);
    expect(d.section80C_allowed).toBe(0); // Not allowed in new regime
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 6. FULL PROJECTION — MONTHLY TDS
// ─────────────────────────────────────────────────────────────────────────────

describe('Monthly TDS Projection', () => {

  test('T27 — Low income employee (₹20K/month) = ₹0 TDS', () => {
    const result = projectTds(makeInput({ basic: 12_000 }));
    expect(result.monthlyTdsAmount).toBe(0);
  });

  test('T28 — Medium income (₹50K/month, new regime) TDS > 0', () => {
    // Annual gross ≈ 50K * various = ~11L after components, taxable > 7L
    const result = projectTds(makeInput({ basic: 50_000 }));
    // Projected ~11.1L gross - 75K std = 10.35L taxable → tax ~1.1L → monthly ~9K+
    expect(result.monthlyTdsAmount).toBeGreaterThan(0);
  });

  test('T29 — Monthly TDS = (annual tax − YTD TDS) ÷ remaining months', () => {
    const result = projectTds(makeInput({ basic: 50_000 }));
    const expectedMonthly = Math.round(
      result.remainingTaxLiability / result.remainingMonths
    );
    expect(result.monthlyTdsAmount).toBe(expectedMonthly);
  });

  test('T30 — YTD TDS adjustment reduces monthly TDS', () => {
    const baseResult = projectTds(makeInput({ basic: 80_000 }));

    // Same employee, same month, but with significant YTD TDS already paid
    const ytdResult = projectTds(makeInput({
      basic: 80_000,
      ytdTdsDeducted: baseResult.totalAnnualTaxLiability * 0.5, // 50% already paid
    }));

    expect(ytdResult.monthlyTdsAmount).toBeLessThan(baseResult.monthlyTdsAmount);
    expect(ytdResult.remainingTaxLiability).toBeLessThan(baseResult.totalAnnualTaxLiability);
  });

  test('T31 — Negative TDS prevention: TDS is always ≥ 0', () => {
    // YTD TDS > annual tax liability (over-deducted scenario)
    const annualTaxResult = projectTds(makeInput({ basic: 30_000 }));
    const overPaidResult = projectTds(makeInput({
      basic: 30_000,
      ytdTdsDeducted: annualTaxResult.totalAnnualTaxLiability + 5_000, // Over-deducted
    }));
    expect(overPaidResult.monthlyTdsAmount).toBe(0);
    expect(overPaidResult.remainingTaxLiability).toBe(0);
  });

  test('T32 — Last month of FY: all remaining tax in one month', () => {
    const lastMonthResult = projectTds(makeInput({
      basic: 80_000,
      currentMonth: 12, // March = FY month 12
      currentCalendarMonth: 3,
      currentYear: 2025,
      ytdTdsDeducted: 0, // Nothing paid yet (unusual but tests the logic)
    }));
    // remainingMonths = 1, so monthlyTDS = remainingTaxLiability
    expect(lastMonthResult.remainingMonths).toBe(1);
    expect(lastMonthResult.monthlyTdsAmount).toBe(lastMonthResult.remainingTaxLiability);
  });

  test('T33 — Mid-year joiner (joined in October = FY month 7)', () => {
    // Joined October, so FY months 1-6 are with previous employer
    const result = projectTds(makeInput({
      basic: 60_000,
      currentMonth: 7, // October = FY month 7
      currentCalendarMonth: 10,
      currentYear: 2024,
      declaration: {
        regimeType: 'old',
        prevEmployerIncome: 3_60_000, // ₹60K/month × 6 months
        prevEmployerTds: 15_000,       // Previous employer deducted
      } as TaxDeclaration,
    }));

    // Previous employer income should be included in taxable gross
    expect(result.taxBreakdown.prevEmployerIncome).toBe(3_60_000);
    expect(result.taxBreakdown.totalTaxableGross).toBeGreaterThan(result.projectedAnnualGross);
    // Previous employer TDS should be subtracted from remaining liability
    expect(result.ytdTdsDeducted).toBe(15_000);
  });

  test('T34 — Salary revision mid-year recalculates correctly', () => {
    // Month 1: ₹50K basic
    const month1 = projectTds(makeInput({ basic: 50_000, currentMonth: 1 }));

    // Month 7: Salary revised to ₹70K — YTD based on old salary
    const month7AfterRevision = projectTds(makeInput({
      basic: 70_000,     // New salary
      currentMonth: 7,
      currentCalendarMonth: 10,
      currentYear: 2024,
      ytdGrossPaid: Number((50_000 + 50_000 * 0.4 + 50_000 * 0.3 + 2000 + 1250) * 6), // 6 months at old salary
      ytdTdsDeducted: month1.monthlyTdsAmount * 6, // 6 months of old TDS
    }));

    // After revision, monthly TDS should be higher (higher salary, catch-up needed)
    expect(month7AfterRevision.monthlyTdsAmount).toBeGreaterThan(month1.monthlyTdsAmount);
  });

  test('T35 — Old regime with full deductions reduces TDS significantly', () => {
    const newRegimeResult = projectTds(makeInput({ basic: 80_000 }));

    const oldRegimeResult = projectTds(makeInput({
      basic: 80_000,
      declaration: {
        regimeType: 'old',
        section80C: 1_50_000,
        section80D_self: 25_000,
        hraRentPaid: 25_000,
        hraCityType: 'metro',
        section80CCD1B: 50_000,
      } as TaxDeclaration,
    }));

    // Old regime with max deductions should have lower tax for high-income earner
    // (because ₹80K/month = ₹9.6L which benefits from 80C etc.)
    expect(oldRegimeResult.totalAnnualTaxLiability).toBeLessThanOrEqual(
      newRegimeResult.totalAnnualTaxLiability
    );
  });

  test('T36 — High income employee (₹3L/month) has surcharge', () => {
    const result = projectTds(makeInput({ basic: 3_00_000, currentMonth: 1 }));
    // ₹3L/month basic → ~5.1L/month gross → ~61L annual → surcharge applies
    expect(result.taxBreakdown.surcharge).toBeGreaterThan(0);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 7. REGIME COMPARISON
// ─────────────────────────────────────────────────────────────────────────────

describe('Regime Comparison', () => {

  test('T37 — Comparison returns both regimes with tax amounts', () => {
    const comparison = compareRegimes({
      employeeId: 'emp-1',
      financialYear: '2024-25',
      currentMonth: 1,
      currentCalendarMonth: 4,
      currentYear: 2024,
      salaryComponents: makeSalary(60_000),
      declarationBase: {
        section80C: 1_50_000,
        hraRentPaid: 20_000,
        hraCityType: 'metro',
      },
      pfEmployeeMonthly: 1_800,
      ytdGrossPaid: 0,
      ytdTdsDeducted: 0,
      ytdPfDeducted: 0,
      fyConfig: FY,
    });

    expect(comparison.oldRegime.annualTax).toBeGreaterThanOrEqual(0);
    expect(comparison.newRegime.annualTax).toBeGreaterThanOrEqual(0);
    expect(['old', 'new']).toContain(comparison.recommendedRegime);
    expect(comparison.annualSavings).toBeGreaterThanOrEqual(0);
  });

  test('T38 — Low-income employee: new regime recommended (fewer deductions needed)', () => {
    // For ₹5L income, new regime is usually better (87A rebate, higher std deduction)
    const comparison = compareRegimes({
      employeeId: 'emp-2',
      financialYear: '2024-25',
      currentMonth: 1,
      currentCalendarMonth: 4,
      currentYear: 2024,
      salaryComponents: makeSalary(30_000),
      declarationBase: {},
      pfEmployeeMonthly: 1_800,
      ytdGrossPaid: 0,
      ytdTdsDeducted: 0,
      ytdPfDeducted: 0,
      fyConfig: FY,
    });

    // Both should have low/zero tax at ₹30K/month
    expect(comparison.newRegime.annualTax).toBe(0); // 87A covers it
    expect(comparison.oldRegime.annualTax).toBe(0);
  });

  test('T39 — Disclaimer included in comparison result', () => {
    const comparison = compareRegimes({
      employeeId: 'emp-3',
      financialYear: '2024-25',
      currentMonth: 1,
      currentCalendarMonth: 4,
      currentYear: 2024,
      salaryComponents: makeSalary(50_000),
      declarationBase: {},
      pfEmployeeMonthly: 1_800,
      ytdGrossPaid: 0,
      ytdTdsDeducted: 0,
      ytdPfDeducted: 0,
      fyConfig: FY,
    });
    expect(comparison.disclaimer).toContain('CA');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 8. UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

describe('FY Utility Functions', () => {

  test('T40 — April = FY month 1', () => {
    const { fyMonth, financialYear } = calendarToFyMonth(4, 2024);
    expect(fyMonth).toBe(1);
    expect(financialYear).toBe('2024-25');
  });

  test('T41 — March = FY month 12', () => {
    const { fyMonth, financialYear } = calendarToFyMonth(3, 2025);
    expect(fyMonth).toBe(12);
    expect(financialYear).toBe('2024-25');
  });

  test('T42 — October = FY month 7', () => {
    const { fyMonth } = calendarToFyMonth(10, 2024);
    expect(fyMonth).toBe(7);
  });

  test('T43 — January = FY month 10', () => {
    const { fyMonth, financialYear } = calendarToFyMonth(1, 2025);
    expect(fyMonth).toBe(10);
    expect(financialYear).toBe('2024-25');
  });

  test('T44 — r2 rounds correctly', () => {
    expect(r2(0.005)).toBe(0.01);
    expect(r2(1234.567)).toBe(1234.57);
    expect(r2(0)).toBe(0);
    expect(r2(-0.5)).toBe(-0.5);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 9. EDGE CASES
// ─────────────────────────────────────────────────────────────────────────────

describe('Edge Cases', () => {

  test('T45 — Very high income (₹1 crore/month) — multiple surcharge tiers', () => {
    const result = projectTds(makeInput({ basic: 1_00_00_000, currentMonth: 1 }));
    expect(result.monthlyTdsAmount).toBeGreaterThan(0);
    expect(result.taxBreakdown.surcharge).toBeGreaterThan(0);
    expect(result.taxBreakdown.totalAnnualTax).toBeGreaterThan(0);
    // Tax should not exceed income
    expect(result.totalAnnualTaxLiability).toBeLessThan(result.projectedAnnualGross);
  });

  test('T46 — Employee joins in last month (March = FY month 12)', () => {
    const result = projectTds(makeInput({
      basic: 50_000,
      currentMonth: 12,
      currentCalendarMonth: 3,
      currentYear: 2025,
    }));
    expect(result.remainingMonths).toBe(1);
    // All liability in last month
    expect(result.monthlyTdsAmount).toBe(result.remainingTaxLiability);
  });

  test('T47 — HRA exemption not computed for new regime', () => {
    const result = projectTds(makeInput({
      basic: 50_000,
      declaration: {
        regimeType: 'new',
        hraRentPaid: 20_000, // Should be ignored in new regime
      } as TaxDeclaration,
    }));
    expect(result.hraBreakdown).toBeUndefined();
    expect(result.taxBreakdown.deductions.hraExemption).toBe(0);
  });

  test('T48 — Disclaimer present in all results', () => {
    const result = projectTds(makeInput({ basic: 50_000 }));
    expect(result.disclaimer).toContain('CA');
    expect(result.disclaimer.length).toBeGreaterThan(20);
  });
});
