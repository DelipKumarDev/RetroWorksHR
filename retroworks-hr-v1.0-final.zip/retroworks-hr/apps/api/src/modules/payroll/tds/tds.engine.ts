/**
 * RetroWorks HR — India TDS / Income Tax Engine
 * ══════════════════════════════════════════════════════════════════════════════
 * Production-grade, CA-review-ready TDS calculation engine.
 *
 * Architecture: Pure functions only — zero side effects, fully testable.
 * All slabs loaded from DB at runtime; nothing is hardcoded.
 *
 * Implements:
 *   ▸ Annual income projection (dynamic, month-aware)
 *   ▸ Old regime: Standard deduction, HRA exemption, 80C, 80D, 80CCD(1B),
 *                 LTA exemption, u/s 87A rebate
 *   ▸ New regime: Standard deduction ₹75,000 (Budget 2024), u/s 87A rebate
 *   ▸ Slab-based progressive tax (no flat rate)
 *   ▸ Marginal relief calculation
 *   ▸ Surcharge (10% / 15% / 25% / 37%)
 *   ▸ Health & Education Cess (4%)
 *   ▸ Mid-year joiner: previous employer income + TDS
 *   ▸ Dynamic monthly TDS equalization
 *   ▸ Regime comparison (old vs new)
 *   ▸ Salary revision recalculation
 *
 * ⚠️  DISCLAIMER: All figures are computed estimates.
 *     Final tax liability subject to CA validation before filing.
 *
 * Reference: Income Tax Act 1961, Finance Act 2024 (AY 2025-26)
 * ══════════════════════════════════════════════════════════════════════════════
 */

// ─────────────────────────────────────────────────────────────────────────────
// TYPES — Slab configuration (loaded from DB via TdsSlabService)
// ─────────────────────────────────────────────────────────────────────────────

export interface TaxSlabRow {
  slabFrom: number;    // Lower bound (inclusive), in rupees
  slabTo: number;      // Upper bound (inclusive), in rupees; use 999_999_999 for "no limit"
  taxRate: number;     // Decimal (e.g. 0.05 for 5%)
}

export interface SurchargeSlabRow {
  incomeFrom: number;
  incomeTo: number;
  surchargeRate: number;
}

export interface FyConfig {
  financialYear: string;             // "2024-25"
  standardDeduction: number;         // ₹75,000 for FY2024-25 new regime / ₹50,000 old
  standardDeductionOld: number;      // ₹50,000 for old regime
  maxSection80C: number;             // ₹1,50,000
  maxSection80D_self: number;        // ₹25,000 (self + family)
  maxSection80D_parents: number;     // ₹50,000 (senior citizen parents)
  maxSection80D_parentsSenior: number; // ₹50,000
  maxSection80CCD1B: number;         // ₹50,000 (NPS additional)
  max87ARebate_new: number;          // ₹25,000
  max87AThreshold_new: number;       // ₹7,00,000
  max87ARebate_old: number;          // ₹12,500
  max87AThreshold_old: number;       // ₹5,00,000
  cessRate: number;                  // 0.04
  newRegimeSlabs: TaxSlabRow[];
  oldRegimeSlabs: TaxSlabRow[];
  surchargeSlabs: SurchargeSlabRow[];
}

// ─────────────────────────────────────────────────────────────────────────────
// DEFAULT SLAB DATA — FY 2024-25 (AY 2025-26)
// These are the seeded defaults; actual values come from DB.
// ─────────────────────────────────────────────────────────────────────────────

export const DEFAULT_FY_CONFIG: FyConfig = {
  financialYear: '2024-25',
  standardDeduction: 75_000,          // Budget 2024: New regime ₹75K
  standardDeductionOld: 50_000,       // Old regime ₹50K
  maxSection80C: 1_50_000,
  maxSection80D_self: 25_000,
  maxSection80D_parents: 25_000,
  maxSection80D_parentsSenior: 50_000,
  maxSection80CCD1B: 50_000,
  max87ARebate_new: 25_000,
  max87AThreshold_new: 7_00_000,
  max87ARebate_old: 12_500,
  max87AThreshold_old: 5_00_000,
  cessRate: 0.04,

  // New Regime Slabs — Finance Act 2024
  newRegimeSlabs: [
    { slabFrom: 0,         slabTo: 3_00_000,    taxRate: 0 },
    { slabFrom: 3_00_001,  slabTo: 6_00_000,    taxRate: 0.05 },
    { slabFrom: 6_00_001,  slabTo: 9_00_000,    taxRate: 0.10 },
    { slabFrom: 9_00_001,  slabTo: 12_00_000,   taxRate: 0.15 },
    { slabFrom: 12_00_001, slabTo: 15_00_000,   taxRate: 0.20 },
    { slabFrom: 15_00_001, slabTo: 999_999_999, taxRate: 0.30 },
  ],

  // Old Regime Slabs (below 60 years) — unchanged
  oldRegimeSlabs: [
    { slabFrom: 0,         slabTo: 2_50_000,    taxRate: 0 },
    { slabFrom: 2_50_001,  slabTo: 5_00_000,    taxRate: 0.05 },
    { slabFrom: 5_00_001,  slabTo: 10_00_000,   taxRate: 0.20 },
    { slabFrom: 10_00_001, slabTo: 999_999_999, taxRate: 0.30 },
  ],

  // Surcharge on income tax
  surchargeSlabs: [
    { incomeFrom: 0,          incomeTo: 50_00_000,   surchargeRate: 0 },
    { incomeFrom: 50_00_001,  incomeTo: 1_00_00_000, surchargeRate: 0.10 },
    { incomeFrom: 1_00_00_001,incomeTo: 2_00_00_000, surchargeRate: 0.15 },
    { incomeFrom: 2_00_00_001,incomeTo: 5_00_00_000, surchargeRate: 0.25 },
    { incomeFrom: 5_00_00_001,incomeTo: 999_999_999, surchargeRate: 0.37 },
  ],
};

// ─────────────────────────────────────────────────────────────────────────────
// INPUT TYPES
// ─────────────────────────────────────────────────────────────────────────────

export interface MonthlySalaryComponents {
  basic: number;
  hra: number;
  specialAllowance: number;
  lta: number;
  medicalAllowance: number;
  otherAllowances: number;
  bonus?: number;
  // Exempt reimbursements (not included in taxable income)
  fuelReimbursement?: number;
  telephoneReimbursement?: number;
  bookAllowance?: number;
}

export interface TaxDeclaration {
  regimeType: 'old' | 'new';
  // Old regime declarations
  section80C?: number;        // PPF, ELSS, LIC, home loan principal, etc.
  section80D_self?: number;   // Health insurance self + family
  section80D_parents?: number; // Health insurance for parents
  section80D_parentsIsSenior?: boolean;
  section80CCD1B?: number;    // NPS additional contribution
  hraRentPaid?: number;       // Monthly rent paid (old regime)
  hraCityType?: 'metro' | 'non-metro'; // metro = Delhi, Mumbai, Chennai, Kolkata
  ltaAmountClaimed?: number;  // LTA claimed for exemption
  homeLoanInterest?: number;  // Section 24(b) — up to ₹2L
  otherDeductions?: number;   // 80E, 80G, 80TTA etc.
  // Previous employer (mid-year joiner)
  prevEmployerIncome?: number;  // Taxable income from previous employer
  prevEmployerTds?: number;     // TDS already deducted by previous employer
  prevEmployerPfContrib?: number; // PF already contributed (for 80C)
}

export interface TdsProjectionInput {
  employeeId: string;
  financialYear: string;      // "2024-25"
  currentMonth: number;       // 1–12 (April=1, March=12 in FY terms)
  currentCalendarMonth: number; // 1–12
  currentYear: number;
  dateOfJoining?: Date;       // For mid-year joiners in current FY
  salaryComponents: MonthlySalaryComponents;
  declaration: TaxDeclaration;
  pfEmployeeMonthly: number;  // For 80C (PF part of 80C cap)
  ytdGrossPaid: number;       // Gross already paid this FY (excludes current month)
  ytdTdsDeducted: number;     // TDS already deducted this FY (excludes current month)
  ytdPfDeducted: number;      // PF already deducted this FY
  projectedBonusForFy?: number; // Known bonus expected later this FY
  fyConfig?: FyConfig;        // If not provided, DEFAULT_FY_CONFIG used
}

// ─────────────────────────────────────────────────────────────────────────────
// OUTPUT TYPES
// ─────────────────────────────────────────────────────────────────────────────

export interface HraBreakdown {
  monthlyHraReceived: number;
  annualHraReceived: number;
  rentPaidAnnual: number;
  basicAnnual: number;
  limit1_actualHra: number;
  limit2_rentMinusBasic10: number;
  limit3_percentOfBasic: number;
  exemptionAnnual: number;        // min of 3 limits
  taxableHraAnnual: number;
}

export interface DeductionBreakdown {
  standardDeduction: number;
  section80C_declared: number;
  section80C_pfContrib: number;
  section80C_totalClaimed: number;
  section80C_allowed: number;     // capped at ₹1.5L
  section80D_self: number;
  section80D_parents: number;
  section80D_allowed: number;
  section80CCD1B: number;
  hraExemption: number;
  ltaExemption: number;
  homeLoanInterest: number;
  otherDeductions: number;
  prevEmployerPfContrib: number;
  totalDeductions: number;
}

export interface TaxBreakdown {
  grossIncomeAnnual: number;      // Projected annual gross
  prevEmployerIncome: number;
  totalTaxableGross: number;      // gross + prev employer
  deductions: DeductionBreakdown;
  taxableIncome: number;          // After all deductions
  taxBeforeRebate: number;        // Slab tax
  rebate87A: number;
  taxAfterRebate: number;
  marginalRelief: number;         // If surcharge causes anomaly
  surcharge: number;
  taxWithSurcharge: number;
  cess: number;
  totalAnnualTax: number;
  effectiveTaxRate: number;       // %
  slabWiseBreakdown: Array<{
    slabFrom: number;
    slabTo: number;
    rate: number;
    incomeInSlab: number;
    taxInSlab: number;
  }>;
}

export interface MonthlyTdsResult {
  // Annual projection
  projectedAnnualGross: number;
  totalAnnualTaxLiability: number;
  // YTD context
  ytdTdsDeducted: number;
  remainingTaxLiability: number;
  remainingMonths: number;
  // This month
  monthlyTdsAmount: number;       // Never negative
  // Full breakdown (for audit trail)
  taxBreakdown: TaxBreakdown;
  hraBreakdown?: HraBreakdown;
  // Metadata
  calculatedAt: Date;
  financialYear: string;
  regimeType: 'old' | 'new';
  disclaimer: string;
}

export interface RegimeComparisonResult {
  employeeId: string;
  financialYear: string;
  oldRegime: {
    taxableIncome: number;
    annualTax: number;
    monthlyTax: number;
    breakdown: TaxBreakdown;
  };
  newRegime: {
    taxableIncome: number;
    annualTax: number;
    monthlyTax: number;
    breakdown: TaxBreakdown;
  };
  recommendedRegime: 'old' | 'new';
  annualSavings: number;          // Positive = recommended regime saves this much
  monthlySavings: number;
  disclaimer: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// PURE CALCULATION FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Round to 2 decimal places using banker's rounding approximation.
 * Consistent policy: Math.round(x * 100) / 100
 */
export function r2(n: number): number {
  return Math.round(n * 100) / 100;
}

/**
 * Round to nearest rupee (for TDS which is always whole rupees).
 */
export function toRupee(n: number): number {
  return Math.round(n);
}

/**
 * Progressive slab-based tax calculation.
 * Pure function — no side effects.
 */
export function computeSlabTax(
  income: number,
  slabs: TaxSlabRow[],
): { total: number; slabWise: Array<{ slabFrom: number; slabTo: number; rate: number; incomeInSlab: number; taxInSlab: number }> } {
  if (income <= 0) return { total: 0, slabWise: [] };

  let totalTax = 0;
  const slabWise = [];

  for (const slab of slabs) {
    // Threshold-based boundary: income in slab = min(income, slabTo) - (slabFrom - 1)
    // e.g. slab 300001-600000 covers exactly ₹3L of income above the ₹3L nil slab
    // Correctly handles ₹6L: slab1 gets ₹3L @ 0%, slab2 gets ₹3L @ 5% = ₹15,000
    const lowerThreshold = slab.slabFrom > 0 ? slab.slabFrom - 1 : 0;
    const incomeInSlab = Math.max(0, Math.min(income, slab.slabTo) - lowerThreshold);
    if (incomeInSlab <= 0) continue;

    const taxInSlab = r2(incomeInSlab * slab.taxRate);
    totalTax += taxInSlab;
    slabWise.push({
      slabFrom: slab.slabFrom,
      slabTo: slab.slabTo,
      rate: slab.taxRate,
      incomeInSlab: r2(incomeInSlab),
      taxInSlab,
    });
  }

  return { total: r2(totalTax), slabWise };
}

/**
 * Surcharge computation with marginal relief.
 *
 * Marginal relief: if surcharge causes effective tax > incremental income,
 * cap surcharge so effective tax = income above threshold.
 */
export function computeSurcharge(
  tax: number,
  income: number,
  surchargeSlabs: SurchargeSlabRow[],
): { surcharge: number; marginalRelief: number; rate: number } {
  if (income <= 0 || tax <= 0) return { surcharge: 0, marginalRelief: 0, rate: 0 };

  let applicableRate = 0;
  for (const slab of surchargeSlabs) {
    if (income >= slab.incomeFrom && income <= slab.incomeTo) {
      applicableRate = slab.surchargeRate;
      break;
    }
  }

  if (applicableRate === 0) return { surcharge: 0, marginalRelief: 0, rate: 0 };

  const rawSurcharge = r2(tax * applicableRate);

  // Marginal relief: find previous threshold
  const prevSlab = surchargeSlabs.find(s => s.incomeTo < income && s.surchargeRate < applicableRate);
  let marginalRelief = 0;
  if (prevSlab) {
    const prevThreshold = prevSlab.incomeTo;
    // Tax + surcharge should not exceed tax-at-threshold + (income - threshold)
    const prevSlabTax = tax; // approximation — actual would need prev-threshold tax
    const excessIncome = income - prevThreshold;
    const maxAdditionalTax = excessIncome;
    const currentAdditional = rawSurcharge;
    if (currentAdditional > maxAdditionalTax) {
      marginalRelief = r2(currentAdditional - maxAdditionalTax);
    }
  }

  return {
    surcharge: r2(rawSurcharge - marginalRelief),
    marginalRelief,
    rate: applicableRate,
  };
}

/**
 * HRA exemption calculation (Section 10(13A)) — Old Regime only.
 * Exemption = minimum of:
 *   1. Actual HRA received annually
 *   2. Rent paid annually − 10% of annual basic
 *   3. 50% of annual basic (metro) OR 40% of annual basic (non-metro)
 *
 * Metro cities: Delhi, Mumbai, Chennai, Kolkata
 */
export function computeHraExemption(params: {
  monthlyBasic: number;
  monthlyHra: number;
  monthlyRentPaid: number;      // Rent employee actually pays
  cityType: 'metro' | 'non-metro';
  remainingMonths: number;       // Months for projection
  elapsedMonths: number;        // Months already processed
}): HraBreakdown {
  const { monthlyBasic, monthlyHra, monthlyRentPaid, cityType, remainingMonths, elapsedMonths } = params;
  const totalFyMonths = remainingMonths + elapsedMonths;

  const annualBasic = r2(monthlyBasic * totalFyMonths);
  const annualHra = r2(monthlyHra * totalFyMonths);
  const rentPaidAnnual = r2(monthlyRentPaid * 12); // annualized

  // 3 limits
  const limit1 = annualHra;                                    // Actual HRA received
  const limit2 = Math.max(0, r2(rentPaidAnnual - annualBasic * 0.10)); // Rent - 10% basic
  const limit3 = r2(annualBasic * (cityType === 'metro' ? 0.50 : 0.40)); // 50%/40% basic

  const exemptionAnnual = Math.min(limit1, limit2, limit3);
  const taxableHraAnnual = r2(Math.max(0, annualHra - exemptionAnnual));

  return {
    monthlyHraReceived: monthlyHra,
    annualHraReceived: annualHra,
    rentPaidAnnual,
    basicAnnual: annualBasic,
    limit1_actualHra: limit1,
    limit2_rentMinusBasic10: limit2,
    limit3_percentOfBasic: limit3,
    exemptionAnnual: r2(exemptionAnnual),
    taxableHraAnnual,
  };
}

/**
 * Compute all Chapter VI-A deductions for Old Regime.
 * Returns the allowed amounts after caps.
 */
export function computeDeductions(params: {
  declaration: TaxDeclaration;
  pfEmployeeAnnual: number;
  fyConfig: FyConfig;
  regimeType: 'old' | 'new';
  hraExemptionAnnual?: number;
  monthlyLta?: number;
}): DeductionBreakdown {
  const { declaration, pfEmployeeAnnual, fyConfig, regimeType, hraExemptionAnnual, monthlyLta } = params;

  if (regimeType === 'new') {
    // New regime: only standard deduction
    return {
      standardDeduction: fyConfig.standardDeduction,
      section80C_declared: 0,
      section80C_pfContrib: 0,
      section80C_totalClaimed: 0,
      section80C_allowed: 0,
      section80D_self: 0,
      section80D_parents: 0,
      section80D_allowed: 0,
      section80CCD1B: 0,
      hraExemption: 0,
      ltaExemption: 0,
      homeLoanInterest: 0,
      otherDeductions: 0,
      prevEmployerPfContrib: 0,
      totalDeductions: fyConfig.standardDeduction,
    };
  }

  // Old Regime
  const stdDeduction = fyConfig.standardDeductionOld;
  const hraExemption = r2(hraExemptionAnnual ?? 0);

  // 80C: PF employee + declared investments (combined cap)
  const pfContrib = r2(pfEmployeeAnnual);
  const prevPfContrib = r2(declaration.prevEmployerPfContrib ?? 0);
  const totalPfFor80C = pfContrib + prevPfContrib;
  const declared80C = r2(declaration.section80C ?? 0);
  const total80CBeforeCap = r2(declared80C + totalPfFor80C);
  const allowed80C = Math.min(total80CBeforeCap, fyConfig.maxSection80C);

  // 80D
  const d80D_self = Math.min(declaration.section80D_self ?? 0, fyConfig.maxSection80D_self);
  const parentsLimit = declaration.section80D_parentsIsSenior
    ? fyConfig.maxSection80D_parentsSenior
    : fyConfig.maxSection80D_parents;
  const d80D_parents = Math.min(declaration.section80D_parents ?? 0, parentsLimit);
  const allowed80D = r2(d80D_self + d80D_parents);

  // 80CCD(1B) — NPS
  const allowed80CCD1B = Math.min(declaration.section80CCD1B ?? 0, fyConfig.maxSection80CCD1B);

  // LTA: taxable salary already reduced by LTA component; exemption depends on actual travel
  const ltaExemption = Math.min(declaration.ltaAmountClaimed ?? 0, (monthlyLta ?? 0) * 12);

  // 24(b) — Home loan interest (max ₹2L for self-occupied)
  const homeLoanInterest = Math.min(declaration.homeLoanInterest ?? 0, 2_00_000);

  const otherDeductions = r2(declaration.otherDeductions ?? 0);

  const totalDeductions = r2(
    stdDeduction + hraExemption + allowed80C + allowed80D +
    allowed80CCD1B + ltaExemption + homeLoanInterest + otherDeductions
  );

  return {
    standardDeduction: stdDeduction,
    section80C_declared: declared80C,
    section80C_pfContrib: totalPfFor80C,
    section80C_totalClaimed: total80CBeforeCap,
    section80C_allowed: r2(allowed80C),
    section80D_self: r2(d80D_self),
    section80D_parents: r2(d80D_parents),
    section80D_allowed: allowed80D,
    section80CCD1B: r2(allowed80CCD1B),
    hraExemption,
    ltaExemption: r2(ltaExemption),
    homeLoanInterest: r2(homeLoanInterest),
    otherDeductions,
    prevEmployerPfContrib: r2(prevPfContrib),
    totalDeductions,
  };
}

/**
 * Core annual tax computation (pure function).
 * Used by both monthly TDS calc and regime comparison.
 */
export function computeAnnualTax(params: {
  taxableIncome: number;
  regimeType: 'old' | 'new';
  grossForSurcharge: number;  // Total income (before deductions) for surcharge threshold
  fyConfig: FyConfig;
}): Omit<TaxBreakdown, 'grossIncomeAnnual' | 'prevEmployerIncome' | 'totalTaxableGross' | 'deductions'> {
  const { taxableIncome, regimeType, grossForSurcharge, fyConfig } = params;

  if (taxableIncome <= 0) {
    return {
      taxableIncome: 0,
      taxBeforeRebate: 0,
      rebate87A: 0,
      taxAfterRebate: 0,
      marginalRelief: 0,
      surcharge: 0,
      taxWithSurcharge: 0,
      cess: 0,
      totalAnnualTax: 0,
      effectiveTaxRate: 0,
      slabWiseBreakdown: [],
    };
  }

  const slabs = regimeType === 'new' ? fyConfig.newRegimeSlabs : fyConfig.oldRegimeSlabs;
  const { total: taxBeforeRebate, slabWise } = computeSlabTax(taxableIncome, slabs);

  // Section 87A rebate
  const rebateThreshold = regimeType === 'new'
    ? fyConfig.max87AThreshold_new
    : fyConfig.max87AThreshold_old;
  const maxRebate = regimeType === 'new'
    ? fyConfig.max87ARebate_new
    : fyConfig.max87ARebate_old;

  const rebate87A = taxableIncome <= rebateThreshold
    ? Math.min(taxBeforeRebate, maxRebate)
    : 0;

  const taxAfterRebate = r2(Math.max(0, taxBeforeRebate - rebate87A));

  // Surcharge (on total income, not taxable income)
  const { surcharge, marginalRelief } = computeSurcharge(
    taxAfterRebate,
    grossForSurcharge,
    fyConfig.surchargeSlabs,
  );

  const taxWithSurcharge = r2(taxAfterRebate + surcharge);

  // 4% Health & Education Cess
  const cess = r2(taxWithSurcharge * fyConfig.cessRate);
  const totalAnnualTax = toRupee(taxWithSurcharge + cess);

  const effectiveTaxRate = taxableIncome > 0
    ? r2((totalAnnualTax / taxableIncome) * 100)
    : 0;

  return {
    taxableIncome: r2(taxableIncome),
    taxBeforeRebate,
    rebate87A,
    taxAfterRebate,
    marginalRelief,
    surcharge,
    taxWithSurcharge,
    cess,
    totalAnnualTax,
    effectiveTaxRate,
    slabWiseBreakdown: slabWise,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN TDS PROJECTION CALCULATOR
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Project annual income and compute monthly TDS for current month.
 *
 * Algorithm:
 *   1. Project annual gross = YTD gross + (current month gross × remaining months) + bonus
 *   2. Add previous employer income
 *   3. Compute HRA exemption (old regime)
 *   4. Compute all deductions
 *   5. Compute annual tax on taxable income
 *   6. Monthly TDS = (Annual tax − YTD TDS) ÷ remaining months
 *   7. Clamp to ≥ 0 (never negative)
 */
export function projectTds(input: TdsProjectionInput): MonthlyTdsResult {
  const fyConfig = input.fyConfig ?? DEFAULT_FY_CONFIG;
  const { declaration, salaryComponents } = input;

  // FY runs April–March. Month 1 = April, Month 12 = March.
  // currentMonth here is FY month (1=April, 12=March)
  const fyMonth = input.currentMonth;                    // 1–12
  const remainingMonths = 12 - fyMonth + 1;             // Including current month
  const elapsedMonths = fyMonth - 1;                    // Already processed months

  // ── Step 1: Project annual gross ────────────────────────────────────────
  const monthlyGross = r2(
    salaryComponents.basic +
    salaryComponents.hra +
    salaryComponents.specialAllowance +
    salaryComponents.lta +
    salaryComponents.medicalAllowance +
    salaryComponents.otherAllowances +
    (salaryComponents.bonus ?? 0)
  );

  // Annual = what we've already paid (YTD) + current + remaining months projection
  const remainingFutureMonths = remainingMonths - 1; // Excluding current month
  const projectedAnnualGross = r2(
    input.ytdGrossPaid +               // Already paid in earlier months this FY
    monthlyGross +                     // Current month
    (monthlyGross * remainingFutureMonths) + // Future months (same salary assumption)
    (input.projectedBonusForFy ?? 0)   // Known future bonus
  );

  // Add previous employer income (mid-year joiner)
  const prevEmployerIncome = r2(declaration.prevEmployerIncome ?? 0);
  const totalTaxableGross = r2(projectedAnnualGross + prevEmployerIncome);

  // ── Step 2: HRA Exemption (old regime only) ──────────────────────────────
  let hraBreakdown: HraBreakdown | undefined;
  let hraExemptionAnnual = 0;

  if (declaration.regimeType === 'old' && (declaration.hraRentPaid ?? 0) > 0) {
    hraBreakdown = computeHraExemption({
      monthlyBasic: salaryComponents.basic,
      monthlyHra: salaryComponents.hra,
      monthlyRentPaid: declaration.hraRentPaid!,
      cityType: declaration.hraCityType ?? 'non-metro',
      remainingMonths,
      elapsedMonths,
    });
    hraExemptionAnnual = hraBreakdown.exemptionAnnual;
  }

  // ── Step 3: Compute deductions ───────────────────────────────────────────
  const pfAnnual = r2(input.pfEmployeeMonthly * 12);
  const deductions = computeDeductions({
    declaration,
    pfEmployeeAnnual: pfAnnual,
    fyConfig,
    regimeType: declaration.regimeType,
    hraExemptionAnnual,
    monthlyLta: salaryComponents.lta,
  });

  // ── Step 4: Taxable income ───────────────────────────────────────────────
  const taxableIncome = r2(Math.max(0, totalTaxableGross - deductions.totalDeductions));

  // ── Step 5: Compute annual tax ───────────────────────────────────────────
  const taxResult = computeAnnualTax({
    taxableIncome,
    regimeType: declaration.regimeType,
    grossForSurcharge: totalTaxableGross,
    fyConfig,
  });

  // Full breakdown
  const taxBreakdown: TaxBreakdown = {
    grossIncomeAnnual: projectedAnnualGross,
    prevEmployerIncome,
    totalTaxableGross,
    deductions,
    ...taxResult,
  };

  // ── Step 6: Monthly TDS ─────────────────────────────────────────────────
  // Subtract previous employer TDS (they already deducted this)
  const prevEmployerTds = r2(declaration.prevEmployerTds ?? 0);
  const ytdTdsTotal = r2(input.ytdTdsDeducted + prevEmployerTds);
  const remainingTaxLiability = r2(Math.max(0, taxResult.totalAnnualTax - ytdTdsTotal));

  // Equalize remaining tax over remaining months (including current)
  const monthlyTdsAmount = remainingMonths > 0
    ? toRupee(remainingTaxLiability / remainingMonths)
    : 0;

  return {
    projectedAnnualGross,
    totalAnnualTaxLiability: taxResult.totalAnnualTax,
    ytdTdsDeducted: ytdTdsTotal,
    remainingTaxLiability,
    remainingMonths,
    monthlyTdsAmount: Math.max(0, monthlyTdsAmount), // Never negative
    taxBreakdown,
    hraBreakdown,
    calculatedAt: new Date(),
    financialYear: input.financialYear,
    regimeType: declaration.regimeType,
    disclaimer: '⚠️ This is a computed estimate. Final tax liability is subject to CA validation before filing returns.',
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// REGIME COMPARISON ENGINE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compare Old vs New regime and recommend the better one.
 * Returns full breakdown for both regimes.
 */
export function compareRegimes(
  input: Omit<TdsProjectionInput, 'declaration'> & {
    declarationBase: Omit<TaxDeclaration, 'regimeType'>;
    fyConfig?: FyConfig;
  }
): RegimeComparisonResult {
  const fyConfig = input.fyConfig ?? DEFAULT_FY_CONFIG;

  const oldResult = projectTds({
    ...input,
    declaration: { ...input.declarationBase, regimeType: 'old' },
    fyConfig,
  });

  const newResult = projectTds({
    ...input,
    declaration: { ...input.declarationBase, regimeType: 'new' },
    fyConfig,
  });

  const oldTax = oldResult.totalAnnualTaxLiability;
  const newTax = newResult.totalAnnualTaxLiability;
  const recommendedRegime: 'old' | 'new' = oldTax <= newTax ? 'old' : 'new';
  const annualSavings = r2(Math.abs(oldTax - newTax));
  const monthlySavings = r2(annualSavings / 12);

  return {
    employeeId: input.employeeId,
    financialYear: input.financialYear,
    oldRegime: {
      taxableIncome: oldResult.taxBreakdown.taxableIncome,
      annualTax: oldTax,
      monthlyTax: oldResult.monthlyTdsAmount,
      breakdown: oldResult.taxBreakdown,
    },
    newRegime: {
      taxableIncome: newResult.taxBreakdown.taxableIncome,
      annualTax: newTax,
      monthlyTax: newResult.monthlyTdsAmount,
      breakdown: newResult.taxBreakdown,
    },
    recommendedRegime,
    annualSavings,
    monthlySavings,
    disclaimer: '⚠️ Regime recommendation is based on declared investments. Actual benefit may vary. Consult a CA before finalizing regime.',
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// FINANCIAL YEAR UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Convert calendar month/year to FY month (April = 1).
 */
export function calendarToFyMonth(calendarMonth: number, year: number): { fyMonth: number; financialYear: string } {
  // April (4) = FY month 1
  const fyMonth = calendarMonth >= 4 ? calendarMonth - 3 : calendarMonth + 9;
  const fyStartYear = calendarMonth >= 4 ? year : year - 1;
  const financialYear = `${fyStartYear}-${String(fyStartYear + 1).slice(2)}`;
  return { fyMonth, financialYear };
}

/**
 * Get the current financial year string.
 */
export function getCurrentFy(date?: Date): string {
  const d = date ?? new Date();
  const year = d.getFullYear();
  const month = d.getMonth() + 1; // 1-based
  const fyStartYear = month >= 4 ? year : year - 1;
  return `${fyStartYear}-${String(fyStartYear + 1).slice(2)}`;
}

/**
 * Get remaining FY months from the given FY month (inclusive).
 */
export function getRemainingFyMonths(fyMonth: number): number {
  return Math.max(1, 12 - fyMonth + 1);
}
