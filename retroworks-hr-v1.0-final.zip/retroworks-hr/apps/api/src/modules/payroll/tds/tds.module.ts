/**
 * TDS Module
 * AUDIT-PAYROLL-2: PrismaClient replaced with PrismaTenantService.
 */
import { Module } from '@nestjs/common';
import { TdsService } from './tds.service';
import { TdsController } from './tds.controller';
import { PrismaTenantService } from '../../../common/security/prisma-tenant.service';
import { PrismaClient } from '@prisma/client';

@Module({
  controllers: [TdsController],
  providers: [TdsService, PrismaTenantService, PrismaClient],
  exports: [TdsService],
})
export class TdsModule {}
