/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * MASTER AUDIT — PART 3
 * Leave Year-End Processing + Advanced Role & Permission Engine + Education Mode
 * Self-contained ts-node runner (no jest required)
 * ═══════════════════════════════════════════════════════════════════════════════
 */

// ─── Minimal test harness ────────────────────────────────────────────────────
let _passed = 0, _failed = 0, _total = 0;
let _currentBlock = '';
const _failures: string[] = [];

function describe(label: string, fn: () => void) {
  _currentBlock = label;
  console.log(`\n  ${label}`);
  fn();
}

function it(label: string, fn: () => void) {
  _total++;
  try {
    fn();
    console.log(`    ✅  ${label}`);
    _passed++;
  } catch (e: any) {
    const msg = `    ❌  ${label}\n       ${e.message}`;
    console.log(msg);
    _failures.push(`[${_currentBlock}] ${label}\n       ${e.message}`);
    _failed++;
  }
}

function expect(actual: any) {
  return {
    toBe: (expected: any) => {
      if (actual !== expected) throw new Error(`Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
    },
    toEqual: (expected: any) => {
      if (JSON.stringify(actual) !== JSON.stringify(expected))
        throw new Error(`Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
    },
    toBeCloseTo: (expected: number, decimals = 2) => {
      const diff = Math.abs(actual - expected);
      const tol = decimals === 0 ? 0.5 : 1 / Math.pow(10, decimals);
      if (diff > tol) throw new Error(`Expected ~${expected} (±${tol}), got ${actual}`);
    },
    toBeGreaterThan: (n: number) => { if (!(actual > n)) throw new Error(`Expected ${actual} > ${n}`); },
    toBeGreaterThanOrEqual: (n: number) => { if (!(actual >= n)) throw new Error(`Expected ${actual} >= ${n}`); },
    toBeLessThan: (n: number) => { if (!(actual < n)) throw new Error(`Expected ${actual} < ${n}`); },
    toBeLessThanOrEqual: (n: number) => { if (!(actual <= n)) throw new Error(`Expected ${actual} <= ${n}`); },
    toHaveLength: (n: number) => { if (actual?.length !== n) throw new Error(`Expected length ${n}, got ${actual?.length}`); },
    toBeDefined: () => { if (actual === undefined || actual === null) throw new Error(`Expected defined, got ${actual}`); },
    toBeUndefined: () => { if (actual !== undefined) throw new Error(`Expected undefined, got ${JSON.stringify(actual)}`); },
    toContain: (sub: string) => { if (!String(actual).includes(sub)) throw new Error(`"${actual}" does not contain "${sub}"`); },
    toMatch: (re: RegExp) => { if (!re.test(actual)) throw new Error(`"${actual}" does not match ${re}`); },
    not: {
      toBe: (expected: any) => { if (actual === expected) throw new Error(`Expected NOT ${JSON.stringify(expected)}`); },
      toBeNull: () => { if (actual === null) throw new Error(`Expected non-null`); },
    },
    some: (pred: (x: any) => boolean) => {
      if (!Array.isArray(actual)) throw new Error(`Expected array`);
      if (!actual.some(pred)) throw new Error(`Expected some element to match predicate`);
    },
    toThrow: (partial?: string) => {
      if (typeof actual !== 'function') throw new Error('Expected a function');
      try { actual(); throw new Error('NO_THROW'); }
      catch (e: any) {
        if (e.message === 'NO_THROW') throw new Error('Expected function to throw');
        if (partial && !e.message?.includes(partial))
          throw new Error(`Expected throw containing "${partial}", got "${e.message}"`);
      }
    },
  };
}

// ─── Imports ─────────────────────────────────────────────────────────────────

import {
  computeYearEnd, processBatchYearEnd,
  getYearBoundaries, getYearLabel, getNewYear,
  isFreezeWindowActive, getFreezeWindowStatus,
  verifyLedgerConsistency, guardIdempotency, isAlreadyProcessed,
  generateReminderSchedule, buildAuditEvent,
  canSubmitLeaveRequest, bulkApproveRequests,
  diffSimulationVsActual, simpleLedgerHash,
  type LeaveYearConfig, type LeaveTypeConfig,
  type EmployeeLeaveSnapshot, type ProcessedLedger,
} from '../../leave/year-end/leave-year-end.engine';

import {
  buildSystemRoles, createCustomRole, cloneRole,
  canAccess, simulateRole, grantTemporaryElevation,
  isElevationActive, revokeElevation, getActiveElevations,
  maskRecord, getMaskedFields, isModuleAccessible,
  buildVisibleMenu, enforceAccess, buildPermissionAuditEvent,
  auditAccessDenied, auditRoleCreated, auditRoleCloned,
  auditElevationGranted, SENSITIVE_FIELDS,
  type RoleDefinition, type UserPermissionContext,
  type ElevationRequest, type MenuNode,
} from '../../security/role-permission.engine';

import {
  createEducationTenantConfig, verifyTenantIsolation,
  isModuleAllowedInEducationMode, buildEducationRoles,
  buildSchoolDashboard, validateEducationPayrollRun,
  initializeLeaveCloseWorkflow, advanceWorkflowStep,
  toggleEducationMode, DEFAULT_EDUCATION_TERMINOLOGY,
  DEFAULT_TEACHER_LEAVE_ENTITLEMENTS, EDUCATION_DISABLED_MODULES,
  getCurrentAcademicYear, buildAcademicYear,
  type EducationTenantConfig,
} from '../../settings/education-mode.engine';

// ─────────────────────────────────────────────────────────────────────────────
// FIXTURES
// ─────────────────────────────────────────────────────────────────────────────

const CORP_TENANT = 'tenant-corp-001';
const EDU_TENANT  = 'tenant-edu-001';

const FIN_CONFIG: LeaveYearConfig = {
  yearType: 'financial',
  closingYear: 2024,
  freezeWindowStart: '2025-03-28',
  freezeWindowEnd: '2025-04-02',
  encashmentRatePerDay: 1_500,
  currency: 'INR',
};

const ACAD_CONFIG: LeaveYearConfig = {
  yearType: 'academic',
  closingYear: 2024,
  freezeWindowStart: '2025-05-25',
  freezeWindowEnd: '2025-06-01',
  encashmentRatePerDay: 1_200,
  currency: 'INR',
};

const EL: LeaveTypeConfig = {
  id: 'lt-el',
  code: 'EL',
  name: 'Earned Leave',
  maxDaysPerYear: 21,
  carryForwardDays: 15,
  encashable: true,
  maxEncashableDays: null,
  paidLeave: true,
};

const CL: LeaveTypeConfig = {
  id: 'lt-cl',
  code: 'CL',
  name: 'Casual Leave',
  maxDaysPerYear: 12,
  carryForwardDays: 0,
  encashable: false,
  maxEncashableDays: null,
  paidLeave: true,
};

const ML: LeaveTypeConfig = {
  id: 'lt-ml',
  code: 'ML',
  name: 'Medical Leave',
  maxDaysPerYear: 10,
  carryForwardDays: 5,
  encashable: false,
  maxEncashableDays: null,
  paidLeave: true,
};

const LEAVE_TYPE_MAP = new Map<string, LeaveTypeConfig>([
  [EL.id, EL], [CL.id, CL], [ML.id, ML],
]);

/** 5 employees with 3 leave types each = 15 snapshots */
function make5EmployeeSnapshots(): EmployeeLeaveSnapshot[] {
  const employees = [
    { id: 'emp-001', name: 'Arjun Mehta' },
    { id: 'emp-002', name: 'Priya Sharma' },
    { id: 'emp-003', name: 'Rahul Nair' },
    { id: 'emp-004', name: 'Ananya Das' },
    { id: 'emp-005', name: 'Vikram Joshi' },
  ];

  const snapshots: EmployeeLeaveSnapshot[] = [];
  for (const emp of employees) {
    snapshots.push(
      { employeeId: emp.id, employeeName: emp.name, leaveTypeId: 'lt-el', year: 2024, allocated: 21, used: 8,  pending: 0, carryForward: 5 },
      { employeeId: emp.id, employeeName: emp.name, leaveTypeId: 'lt-cl', year: 2024, allocated: 12, used: 10, pending: 1, carryForward: 0 },
      { employeeId: emp.id, employeeName: emp.name, leaveTypeId: 'lt-ml', year: 2024, allocated: 10, used: 3,  pending: 0, carryForward: 0 },
    );
  }
  return snapshots;
}

// ─────────────────────────────────────────────────────────────────────────────
// SECTION A — LEAVE YEAR-END PROCESSING ENGINE
// ─────────────────────────────────────────────────────────────────────────────

console.log('\n══════════════════════════════════════════════════════════════');
console.log('  MASTER AUDIT — PART 3: Leave Year-End + Role Engine + Education');
console.log('══════════════════════════════════════════════════════════════');

describe('SECTION A — Leave Year-End: Year Config & Boundaries', () => {

  it('A.1 | Financial year: FY2024 bounds → 01-Apr-2024 to 31-Mar-2025', () => {
    const b = getYearBoundaries('financial', 2024);
    expect(b.start.toISOString().slice(0,10)).toBe('2024-04-01');
    expect(b.end.toISOString().slice(0,10)).toBe('2025-03-31');
  });

  it('A.2 | Academic year: AY2024 bounds → 01-Jun-2024 to 31-May-2025', () => {
    const b = getYearBoundaries('academic', 2024);
    expect(b.start.toISOString().slice(0,10)).toBe('2024-06-01');
    expect(b.end.toISOString().slice(0,10)).toBe('2025-05-31');
  });

  it('A.3 | Calendar year bounds → 01-Jan-2024 to 31-Dec-2024', () => {
    const b = getYearBoundaries('calendar', 2024);
    expect(b.start.toISOString().slice(0,10)).toBe('2024-01-01');
    expect(b.end.toISOString().slice(0,10)).toBe('2024-12-31');
  });

  it('A.4 | Year labels: calendar "2024", financial "FY2024-25", academic "AY2024-25"', () => {
    expect(getYearLabel('calendar', 2024)).toBe('2024');
    expect(getYearLabel('financial', 2024)).toBe('FY2024-25');
    expect(getYearLabel('academic', 2024)).toBe('AY2024-25');
  });

  it('A.5 | getNewYear: 2024 → 2025 for all year types', () => {
    expect(getNewYear('calendar', 2024)).toBe(2025);
    expect(getNewYear('financial', 2024)).toBe(2025);
    expect(getNewYear('academic', 2024)).toBe(2025);
  });
});

describe('SECTION A — Leave Year-End: Carry-Forward, Lapse & Encashment', () => {

  it('A.6 | EL: available=13, carryForward capped at 15 → carryForward=13 (full carry)', () => {
    const snap: EmployeeLeaveSnapshot = {
      employeeId: 'emp-001', employeeName: 'A', leaveTypeId: 'lt-el',
      year: 2024, allocated: 21, used: 8, pending: 0, carryForward: 5,
    };
    const r = computeYearEnd(snap, EL, FIN_CONFIG, true);
    expect(r.closingAvailable).toBe(13);     // 21 - 8 - 0
    expect(r.carryForwardDays).toBe(13);     // min(13, 15) → 13
    expect(r.lapsedDays).toBe(0);
    expect(r.encashedDays).toBe(0);          // nothing left after carry-forward
    expect(r.newYearAllocated).toBe(34);     // 21 + 13
  });

  it('A.7 | EL: available=20, carryForward cap=15 → carry=15, encash=5, lapse=0', () => {
    const snap: EmployeeLeaveSnapshot = {
      employeeId: 'emp-002', employeeName: 'B', leaveTypeId: 'lt-el',
      year: 2024, allocated: 21, used: 1, pending: 0, carryForward: 0,
    };
    const r = computeYearEnd(snap, EL, FIN_CONFIG, true);
    expect(r.closingAvailable).toBe(20);
    expect(r.carryForwardDays).toBe(15);
    expect(r.encashedDays).toBe(5);
    expect(r.lapsedDays).toBe(0);
    expect(r.encashmentAmount).toBe(5 * 1_500);   // ₹7,500
  });

  it('A.8 | CL: carryForward=0 → all unused lapses (CL never carries)', () => {
    const snap: EmployeeLeaveSnapshot = {
      employeeId: 'emp-001', employeeName: 'A', leaveTypeId: 'lt-cl',
      year: 2024, allocated: 12, used: 10, pending: 1, carryForward: 0,
    };
    const r = computeYearEnd(snap, CL, FIN_CONFIG, true);
    expect(r.closingAvailable).toBe(1);    // 12 - 10 - 1
    expect(r.carryForwardDays).toBe(0);   // CL has no carry
    expect(r.lapsedDays).toBe(1);
    expect(r.encashedDays).toBe(0);       // CL not encashable
  });

  it('A.9 | ML: available=7, carryForward=5 → carry=5, lapse=2', () => {
    const snap: EmployeeLeaveSnapshot = {
      employeeId: 'emp-003', employeeName: 'C', leaveTypeId: 'lt-ml',
      year: 2024, allocated: 10, used: 3, pending: 0, carryForward: 0,
    };
    const r = computeYearEnd(snap, ML, FIN_CONFIG, true);
    expect(r.closingAvailable).toBe(7);
    expect(r.carryForwardDays).toBe(5);
    expect(r.lapsedDays).toBe(2);
    expect(r.encashedDays).toBe(0);      // ML not encashable
  });

  it('A.10 | Zero available (fully used): carryForward=0, lapse=0, encash=0', () => {
    const snap: EmployeeLeaveSnapshot = {
      employeeId: 'emp-004', employeeName: 'D', leaveTypeId: 'lt-el',
      year: 2024, allocated: 21, used: 21, pending: 0, carryForward: 0,
    };
    const r = computeYearEnd(snap, EL, FIN_CONFIG, true);
    expect(r.closingAvailable).toBe(0);
    expect(r.carryForwardDays).toBe(0);
    expect(r.lapsedDays).toBe(0);
    expect(r.encashedDays).toBe(0);
  });

  it('A.11 | Pending leaves are NOT available: used+pending > allocated → available=0', () => {
    const snap: EmployeeLeaveSnapshot = {
      employeeId: 'emp-005', employeeName: 'E', leaveTypeId: 'lt-cl',
      year: 2024, allocated: 12, used: 11, pending: 3, carryForward: 0,
    };
    const r = computeYearEnd(snap, CL, FIN_CONFIG, true);
    // available = max(0, 12 - 11 - 3) = max(0, -2) = 0
    expect(r.closingAvailable).toBe(0);
    expect(r.lapsedDays).toBe(0);
  });

  it('A.12 | maxEncashableDays cap: ML with cap=3, available=10 → encash=3', () => {
    const mlCapped: LeaveTypeConfig = { ...EL, id: 'lt-elx', code: 'ELX', encashable: true, carryForwardDays: 0, maxEncashableDays: 3 };
    const snap: EmployeeLeaveSnapshot = {
      employeeId: 'e1', employeeName: 'X', leaveTypeId: 'lt-elx',
      year: 2024, allocated: 15, used: 5, pending: 0, carryForward: 0,
    };
    const r = computeYearEnd(snap, mlCapped, FIN_CONFIG, true);
    expect(r.encashedDays).toBe(3);
    expect(r.lapsedDays).toBe(7);    // 10 - 3
  });
});

describe('SECTION A — Leave Year-End: Batch + Ledger + Invariants', () => {

  it('A.13 | Batch: 5 employees × 3 leave types = 15 records', () => {
    const result = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    expect(result.totalRecords).toBe(15);
    expect(result.totalEmployees).toBe(5);
    expect(result.totalLeaveTypes).toBe(3);
  });

  it('A.14 | Batch: isSimulation=true → isLocked=false', () => {
    const result = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    expect(result.isSimulation).toBe(true);
    expect(result.isLocked).toBe(false);
  });

  it('A.15 | Batch: isSimulation=false → isLocked=true (real run)', () => {
    const result = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, false);
    expect(result.isSimulation).toBe(false);
    expect(result.isLocked).toBe(true);
  });

  it('A.16 | Ledger consistency: all 15 records pass invariant checks', () => {
    const result = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    const check = verifyLedgerConsistency(result.computed);
    expect(check.isConsistent).toBe(true);
    expect(check.violations).toHaveLength(0);
  });

  it('A.17 | Ledger invariant: carryForward + lapsed + encashed = closingAvailable', () => {
    const result = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    for (const c of result.computed) {
      const sum = c.carryForwardDays + c.lapsedDays + c.encashedDays;
      const diff = Math.abs(sum - c.closingAvailable);
      if (diff > 0.01) throw new Error(`Invariant violated for ${c.employeeId}:${c.leaveTypeCode}: sum=${sum} ≠ available=${c.closingAvailable}`);
    }
  });

  it('A.18 | No double processing: guardIdempotency blocks re-run on same year', () => {
    const existing: ProcessedLedger[] = [
      { tenantId: CORP_TENANT, closingYear: 2024, yearType: 'financial', processedAt: new Date(), ledgerHash: 'LH-ABCD1234' },
    ];
    const guard = guardIdempotency(existing, CORP_TENANT, 2024);
    expect(guard.safe).toBe(false);
    expect(guard.reason).toBeDefined();
  });

  it('A.19 | Idempotency: different year → safe to process', () => {
    const existing: ProcessedLedger[] = [
      { tenantId: CORP_TENANT, closingYear: 2023, yearType: 'financial', processedAt: new Date(), ledgerHash: 'LH-OLD' },
    ];
    const guard = guardIdempotency(existing, CORP_TENANT, 2024);
    expect(guard.safe).toBe(true);
  });

  it('A.20 | isAlreadyProcessed: finds processed year correctly', () => {
    const ledgers: ProcessedLedger[] = [
      { tenantId: CORP_TENANT, closingYear: 2024, yearType: 'financial', processedAt: new Date(), ledgerHash: 'X' },
    ];
    expect(isAlreadyProcessed(ledgers, CORP_TENANT, 2024)).toBe(true);
    expect(isAlreadyProcessed(ledgers, CORP_TENANT, 2023)).toBe(false);
    expect(isAlreadyProcessed(ledgers, 'other-tenant', 2024)).toBe(false);
  });
});

describe('SECTION A — Leave Year-End: Freeze, Reminders & Audit', () => {

  it('A.21 | Freeze window active when date is within window', () => {
    const inWindow = new Date('2025-03-30');
    expect(isFreezeWindowActive(FIN_CONFIG, inWindow)).toBe(true);
  });

  it('A.22 | Freeze window inactive before window opens', () => {
    const beforeWindow = new Date('2025-03-20');
    expect(isFreezeWindowActive(FIN_CONFIG, beforeWindow)).toBe(false);
  });

  it('A.23 | getFreezeWindowStatus: daysUntilFreeze is positive when not yet frozen', () => {
    const early = new Date('2025-03-01');
    const status = getFreezeWindowStatus(FIN_CONFIG, early);
    expect(status.isFrozen).toBe(false);
    expect(status.daysUntilFreeze).toBeGreaterThan(0);
  });

  it('A.24 | canSubmitLeaveRequest: blocked during freeze for closing year', () => {
    const duringFreeze = new Date('2025-03-30');
    const result = canSubmitLeaveRequest(FIN_CONFIG, '2024-12-15', duringFreeze);
    expect(result.allowed).toBe(false);
    expect(result.reason).toBeDefined();
  });

  it('A.25 | canSubmitLeaveRequest: allowed before freeze window', () => {
    const beforeFreeze = new Date('2025-03-01');
    const result = canSubmitLeaveRequest(FIN_CONFIG, '2025-01-10', beforeFreeze);
    expect(result.allowed).toBe(true);
  });

  it('A.26 | generateReminderSchedule: at least 4 reminders generated', () => {
    const reminders = generateReminderSchedule(FIN_CONFIG);
    expect(reminders.length).toBeGreaterThanOrEqual(4);
    const types = reminders.map(r => r.type);
    expect(types).some((t: string) => t === 'freeze_warning');
    expect(types).some((t: string) => t === 'processing_complete');
    // Encashment reminder because rate > 0
    expect(types).some((t: string) => t === 'encashment_pending');
  });

  it('A.27 | Audit event: simulation → eventType "year_end_simulated"', () => {
    const result = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    const event = buildAuditEvent(result, CORP_TENANT, 'hr-user-001');
    expect(event.eventType).toBe('year_end_simulated');
    expect(event.tenantId).toBe(CORP_TENANT);
    expect(event.affectedEmployees).toBe(5);
  });

  it('A.28 | Audit event: real run → eventType "year_end_processed"', () => {
    const result = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, false);
    const event = buildAuditEvent(result, CORP_TENANT, 'hr-user-001');
    expect(event.eventType).toBe('year_end_processed');
  });

  it('A.29 | Ledger hash changes when data changes', () => {
    const h1 = simpleLedgerHash({ tenantId: 'T1', year: 2024, totalCarryForward: 100 });
    const h2 = simpleLedgerHash({ tenantId: 'T1', year: 2024, totalCarryForward: 101 });
    expect(h1).not.toBe(h2);
    expect(h1).toContain('LH-');
  });

  it('A.30 | Simulation diff: detects changed carryForward between sim and actual', () => {
    const snapshots = make5EmployeeSnapshots();
    const sim = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, snapshots, LEAVE_TYPE_MAP, true);
    // Make a "different" actual — modify EL used days for emp-001
    const modSnaps = snapshots.map(s =>
      s.employeeId === 'emp-001' && s.leaveTypeId === 'lt-el'
        ? { ...s, used: 3 }   // was 8, now 3 → more carry-forward
        : s
    );
    const actual = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, modSnaps, LEAVE_TYPE_MAP, false);
    const diffs = diffSimulationVsActual(sim.computed, actual.computed);
    expect(diffs.length).toBeGreaterThan(0);
    const carryDiff = diffs.find(d => d.employeeId === 'emp-001' && d.field === 'carryForwardDays');
    expect(carryDiff).toBeDefined();
  });

  it('A.31 | Bulk approval: auto-approves requests ≤ maxDaysForAutoApprove', () => {
    const requests = [
      { requestId: 'r1', employeeId: 'e1', employeeName: 'A', leaveTypeCode: 'EL', startDate: '2024-10-01', endDate: '2024-10-02', days: 2, status: 'pending' as const },
      { requestId: 'r2', employeeId: 'e2', employeeName: 'B', leaveTypeCode: 'EL', startDate: '2024-10-01', endDate: '2024-10-10', days: 8, status: 'pending' as const },
    ];
    const result = bulkApproveRequests(requests, {
      autoApproveBeforeFreeze: true,
      maxDaysForAutoApprove: 5,
      requiresManagerApprovalAbove: 5,
    });
    expect(result.approved).toContain('r1');
    expect(result.skipped).toContain('r2');  // 8 days → manager review
  });

  it('A.32 | Academic year config: AY2024 closingYear + yearType = academic boundaries Jun-May', () => {
    const result = processBatchYearEnd(EDU_TENANT, ACAD_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    expect(result.yearType).toBe('academic');
    expect(result.closingYear).toBe(2024);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION B — ADVANCED ROLE & PERMISSION ENGINE
// ─────────────────────────────────────────────────────────────────────────────

/** Build the 5 system roles and HR/Finance/Manager/Employee contexts */
let systemRoles: RoleDefinition[];
const SYSTEM_TENANT = CORP_TENANT;

function makeCtx(roles: RoleDefinition[], overrides: Partial<UserPermissionContext> = {}): UserPermissionContext {
  return {
    userId: 'user-001',
    tenantId: SYSTEM_TENANT,
    roleIds: roles.map(r => r.id),
    roles,
    activeElevations: [],
    requestContext: { params: {}, body: {}, query: {} },
    ...overrides,
  };
}

const AUDIT_LOG: import('../../security/role-permission.engine').PermissionAuditEvent[] = [];

describe('SECTION B — Role Engine: System Roles & Custom Creation', () => {

  it('B.1 | buildSystemRoles returns at least 4 roles: hr-admin, finance, manager, employee', () => {
    systemRoles = buildSystemRoles(SYSTEM_TENANT, 'system');
    const names = systemRoles.map(r => r.name);
    expect(names).some((n: string) => n === 'hr-admin');
    expect(names).some((n: string) => n === 'finance');
    expect(names).some((n: string) => n === 'manager');
    expect(names).some((n: string) => n === 'employee');
    expect(systemRoles.length).toBeGreaterThanOrEqual(4);
  });

  it('B.2 | System roles are marked isSystem=true', () => {
    systemRoles.forEach(r => {
      if (['hr-admin', 'finance', 'manager', 'employee'].includes(r.name)) {
        expect(r.isSystem).toBe(true);
      }
    });
  });

  it('B.3 | createCustomRole: valid name + permissions → role object', () => {
    const custom = createCustomRole(
      SYSTEM_TENANT,
      {
        name: 'payroll-auditor',
        displayName: 'Payroll Auditor',
        description: 'Read-only access to payroll and TDS',
        allowedModules: ['payroll', 'payroll-tds'],
        permissions: [
          { resource: 'payroll:run', module: 'payroll', actions: ['read', 'export'] },
          { resource: 'payroll:tds', module: 'payroll-tds', actions: ['read'] },
        ],
        menuVisibility: { 'nav-payroll': true, 'nav-payroll-tds': true },
        globalMaskedFields: ['bankAccountNumber'],
      },
      'super-admin-001',
    );
    expect(custom.name).toBe('payroll-auditor');
    expect(custom.isSystem).toBe(false);
    expect(custom.tenantId).toBe(SYSTEM_TENANT);
    expect(custom.permissions.length).toBeGreaterThan(0);
  });

  it('B.4 | createCustomRole: invalid name (spaces) → throws', () => {
    expect(() => createCustomRole(SYSTEM_TENANT, {
      name: 'bad name!',
      displayName: 'Bad', description: '', modules: [],
      permissions: [], globalMaskedFields: [], createdBy: 'x',
    })).toThrow();
  });

  it('B.5 | cloneRole: copies permissions + marks parentRoleId not set (clone is independent)', () => {
    const hrRole = systemRoles.find(r => r.name === 'hr-admin')!;
    const clone = cloneRole(hrRole, { name: 'hr-junior', displayName: 'Junior HR' }, 'admin');
    expect(clone.name).toBe('hr-junior');
    expect(clone.isSystem).toBe(false);
    expect(clone.permissions.length).toBeGreaterThan(0);
    expect(clone.tenantId).toBe(hrRole.tenantId);
  });

  it('B.6 | cloneRole: can override permissions in clone', () => {
    const hrRole = systemRoles.find(r => r.name === 'hr-admin')!;
    const reducedPerms = hrRole.permissions.filter(p => p.actions.includes('read'));
    const clone = cloneRole(hrRole, {
      name: 'hr-readonly',
      displayName: 'HR Read-Only',
      permissions: reducedPerms,
    }, 'admin');
    expect(clone.permissions.length).toBeLessThanOrEqual(hrRole.permissions.length);
  });
});

describe('SECTION B — Role Engine: Module Access & Menu Visibility', () => {

  it('B.7 | HR-Admin: can access payroll module', () => {
    const hrRole = systemRoles.find(r => r.name === 'hr-admin')!;
    const ctx = makeCtx([hrRole]);
    expect(isModuleAccessible(ctx, 'payroll')).toBe(true);
  });

  it('B.8 | Employee role: cannot access payroll-tds module', () => {
    const empRole = systemRoles.find(r => r.name === 'employee')!;
    const ctx = makeCtx([empRole]);
    expect(isModuleAccessible(ctx, 'payroll-tds')).toBe(false);
  });

  it('B.9 | buildVisibleMenu: employee sees only menuVisibility=true items from their role', () => {
    const allMenuItems: MenuNode[] = [
      { id: 'nav-payroll', label: 'Payroll', icon: '💰', module: 'payroll', visible: true },
      { id: 'nav-leave', label: 'My Leave', icon: '🌴', module: 'leave', visible: true },
      { id: 'nav-settings', label: 'Settings', icon: '⚙️', module: 'settings', visible: true },
      { id: 'nav-roles', label: 'Role Management', icon: '🔐', module: 'roles', visible: true },
    ];
    const empRole = systemRoles.find(r => r.name === 'employee')!;
    const ctx = makeCtx([empRole]);
    const menu = buildVisibleMenu(ctx, allMenuItems);
    // Employee menuVisibility should NOT include roles (roles module is not in employee's allowedModules)
    const hasRoles = menu.some((m: MenuNode) => m.id === 'nav-roles');
    expect(hasRoles).toBe(false);
    // Menu must be filtered (≤ total items)
    expect(menu.length).toBeLessThanOrEqual(allMenuItems.length);
  });

  it('B.10 | canAccess: manager cannot read payroll (explicit deny or no permission)', () => {
    const managerRole = systemRoles.find(r => r.name === 'manager')!;
    const ctx = makeCtx([managerRole]);
    const result = canAccess(ctx, 'payroll', 'payroll:payslip', 'read');
    // Manager has explicit deny on payslip
    expect(result.allowed).toBe(false);
  });

  it('B.11 | canAccess: finance can read and export payroll', () => {
    const finRole = systemRoles.find(r => r.name === 'finance')!;
    const ctx = makeCtx([finRole]);
    const readResult = canAccess(ctx, 'payroll', 'payroll:payslip', 'read');
    const exportResult = canAccess(ctx, 'payroll', 'payroll:payslip', 'export');
    expect(readResult.allowed).toBe(true);
    expect(exportResult.allowed).toBe(true);
  });

  it('B.12 | canAccess: hr-admin can approve leave requests', () => {
    const hrRole = systemRoles.find(r => r.name === 'hr-admin')!;
    const ctx = makeCtx([hrRole]);
    const result = canAccess(ctx, 'leave', 'leave:request', 'approve');
    expect(result.allowed).toBe(true);
  });
});

describe('SECTION B — Role Engine: Field Masking', () => {

  it('B.13 | SENSITIVE_FIELDS includes salary and banking fields', () => {
    const salaryFields = ['salary', 'ctc', 'bankAccountNumber', 'ifscCode', 'panNumber'];
    salaryFields.forEach(f => {
      const found = SENSITIVE_FIELDS.some((sf: string) => sf === f);
      if (!found) throw new Error(`SENSITIVE_FIELDS missing "${f}"`);
    });
  });

  it('B.14 | maskRecord: masks fields declared in role globalMaskedFields or permission maskedFields', () => {
    const hodRole = buildEducationRoles(SYSTEM_TENANT, 'system').find(r => r.name === 'hod')!;
    const ctx = makeCtx([hodRole]);
    const record = { name: 'Arjun', salary: 80_000, ctc: 100_000, department: 'Eng' };
    const masked = maskRecord(record, ctx, 'employee');
    expect(masked.name).toBe('Arjun');
    expect(masked.department).toBe('Eng');
    // HOD has globalMaskedFields: ['salary', 'ctc', ...]
    expect(masked.salary).toBe('****');
    expect(masked.ctc).toBe('****');
  });

  it('B.15 | Finance role: no global masked fields (full salary visibility)', () => {
    const finRole = systemRoles.find(r => r.name === 'finance')!;
    const ctx = makeCtx([finRole]);
    const fields = getMaskedFields(ctx, 'payroll:payslip');
    // Finance should not mask salary fields globally
    const salaryMasked = fields.some((f: string) => f === 'salary' || f === 'ctc');
    expect(salaryMasked).toBe(false);
  });
});

describe('SECTION B — Role Engine: Temporary Elevation', () => {

  it('B.16 | grantTemporaryElevation: valid 8hr grant → isRevoked=false, correct expiry', () => {
    const finRole = systemRoles.find(r => r.name === 'finance')!;
    const req: ElevationRequest = {
      userId: 'user-temp-001',
      tenantId: SYSTEM_TENANT,
      targetRoleId: finRole.id,
      targetRoleName: finRole.name,
      reason: 'Q4 payroll run coverage',
      durationHours: 8,
      grantedBy: 'admin-001',
    };
    const elevation = grantTemporaryElevation(req);
    expect(elevation.isRevoked).toBe(false);
    const diffMs = elevation.expiresAt.getTime() - elevation.grantedAt.getTime();
    expect(diffMs).toBe(8 * 3_600_000);
  });

  it('B.17 | grantTemporaryElevation: duration > maxDurationHours (default 72) → throws', () => {
    const finRole = systemRoles.find(r => r.name === 'finance')!;
    expect(() => grantTemporaryElevation({
      userId: 'u1', tenantId: SYSTEM_TENANT,
      targetRoleId: finRole.id, targetRoleName: finRole.name,
      reason: 'test', grantedBy: 'admin', durationHours: 73,
    })).toThrow();
  });

  it('B.18 | isElevationActive: false when elevation.expiresAt is in the past', () => {
    const elevation = {
      id: 'e1', userId: 'u1', tenantId: SYSTEM_TENANT,
      grantedRoleId: 'r1', grantedRoleName: 'finance',
      reason: 'test', grantedBy: 'admin',
      grantedAt: new Date('2024-01-01'), expiresAt: new Date('2024-01-02'),
      isRevoked: false, auditToken: 'tok',
    };
    expect(isElevationActive(elevation)).toBe(false);
  });

  it('B.19 | revokeElevation: sets isRevoked=true', () => {
    const finRole = systemRoles.find(r => r.name === 'finance')!;
    const elevation = grantTemporaryElevation({
      userId: 'u1', tenantId: SYSTEM_TENANT,
      targetRoleId: finRole.id, targetRoleName: finRole.name,
      reason: 'test', grantedBy: 'admin', durationHours: 4,
    });
    const revoked = revokeElevation(elevation, 'admin-001');
    expect(revoked.isRevoked).toBe(true);
    expect(revoked.revokedBy).toBe('admin-001');
  });

  it('B.20 | getActiveElevations: returns only valid (unexpired, not revoked) elevations for userId', () => {
    const finRole = systemRoles.find(r => r.name === 'finance')!;
    const active = grantTemporaryElevation({
      userId: 'u1', tenantId: SYSTEM_TENANT,
      targetRoleId: finRole.id, targetRoleName: finRole.name,
      reason: 'live', grantedBy: 'admin', durationHours: 4,
    });
    const expired = { ...active, userId: 'u2', expiresAt: new Date('2024-01-01') };
    const result = getActiveElevations([active, expired], 'u1');
    expect(result).toHaveLength(1);
    expect(result[0]!.userId).toBe('u1');
  });
});

describe('SECTION B — Role Engine: Simulation & Restricted Calls', () => {

  it('B.21 | simulateRole: hr-admin simulation shows full leave access', () => {
    const hrRole = systemRoles.find(r => r.name === 'hr-admin')!;
    const sim = simulateRole(
      hrRole,
      { targetRoleId: hrRole.id, resource: 'leave:request', module: 'leave', action: 'approve' },
      [],
    );
    expect(sim.allowed).toBe(true);
    expect(sim.targetRole.name).toBe('hr-admin');
  });

  it('B.22 | simulateRole: employee cannot approve leave', () => {
    const empRole = systemRoles.find(r => r.name === 'employee')!;
    const sim = simulateRole(
      empRole,
      { targetRoleId: empRole.id, resource: 'leave:request', module: 'leave', action: 'approve' },
      [],
    );
    expect(sim.allowed).toBe(false);
  });

  it('B.23 | enforceAccess: restricted API call (employee → role:create) → denied, audit logged', () => {
    const empRole = systemRoles.find(r => r.name === 'employee')!;
    const ctx = makeCtx([empRole]);
    const log: import('../../security/role-permission.engine').PermissionAuditEvent[] = [];
    const result = enforceAccess(ctx, 'roles', 'role', 'create', log);
    expect(result.allowed).toBe(false);
    expect(log.length).toBeGreaterThan(0);
    expect(log[0]!.action).toBe('access_denied');
  });

  it('B.24 | enforceAccess: finance accessing payroll → allowed', () => {
    const finRole = systemRoles.find(r => r.name === 'finance')!;
    const ctx = makeCtx([finRole]);
    const log: import('../../security/role-permission.engine').PermissionAuditEvent[] = [];
    const result = enforceAccess(ctx, 'payroll', 'payroll:run', 'read', log);
    expect(result.allowed).toBe(true);
  });

  it('B.25 | auditAccessDenied: returns event with action=access_denied', () => {
    const empRole = systemRoles.find(r => r.name === 'employee')!;
    const ctx = makeCtx([empRole]);
    const event = auditAccessDenied(ctx, 'roles', 'role', 'create', 'No matching permission');
    expect(event.action).toBe('access_denied');
    expect(event.resourceType).toBe('role');
    expect(event.userId).toBe(ctx.userId);
  });

  it('B.26 | auditRoleCreated: records role creation event', () => {
    const custom = createCustomRole(
      SYSTEM_TENANT,
      { name: 'test-role', displayName: 'Test', description: 'x',
        allowedModules: ['leave'], permissions: [],
        menuVisibility: {}, globalMaskedFields: [] },
      'admin-001',
    );
    const event = auditRoleCreated(custom, 'admin-001');
    expect(event.action).toBe('role_created');
    expect(event.tenantId).toBe(SYSTEM_TENANT);
    expect(event.resourceType).toBe('role');
  });

  it('B.27 | auditElevationGranted: records elevation event', () => {
    const finRole = systemRoles.find(r => r.name === 'finance')!;
    const elevation = grantTemporaryElevation({
      userId: 'u1', tenantId: SYSTEM_TENANT,
      targetRoleId: finRole.id, targetRoleName: finRole.name,
      reason: 'audit test', grantedBy: 'admin', durationHours: 2,
    });
    const event = auditElevationGranted(elevation);
    expect(event.action).toBe('elevation_granted');
    expect(event.metadata['targetRole']).toBe(finRole.name);
  });

  it('B.28 | buildPermissionAuditEvent: generic event builder produces timestamped event', () => {
    const event = buildPermissionAuditEvent({
      tenantId: SYSTEM_TENANT,
      userId: 'u1',
      action: 'role_cloned',
      resourceType: 'role',
      resourceId: 'role-123',
      performedBy: 'u1',
      metadata: { sourceRoleName: 'hr-admin', cloneRoleName: 'hr-junior' },
    });
    expect(event.action).toBe('role_cloned');
    expect(event.id).toBeDefined();
    expect(event.performedAt).toBeDefined();
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// SECTION C — EDUCATION MODE
// ─────────────────────────────────────────────────────────────────────────────

let schoolConfig: EducationTenantConfig;
let schoolStaff: Array<{ id: string; name: string; roleType: 'teaching' | 'non-teaching'; departmentId: string }>;

describe('SECTION C — Education Mode: Config & Toggle', () => {

  it('C.1 | createEducationTenantConfig: produces valid education config', () => {
    schoolConfig = createEducationTenantConfig(EDU_TENANT, 'Sunrise Public School', {
      institutionType: 'school',
      boardAffiliation: 'CBSE',
      payCommission: '7th',
    });
    expect(schoolConfig.isEducationMode).toBe(true);
    expect(schoolConfig.institutionType).toBe('school');
    expect(schoolConfig.leaveYearType).toBe('academic');
    expect(schoolConfig.boardAffiliation).toBe('CBSE');
  });

  it('C.2 | Education terminology: "Employee" → "Staff", "Manager" → HOD label', () => {
    expect(schoolConfig.terminology.employee).toBe('Staff');
    expect(schoolConfig.terminology.employees).toBe('Staff Members');
    expect(schoolConfig.terminology.manager).toContain('HOD');
  });

  it('C.3 | toggleEducationMode enable: from corporate → education mode switch succeeds', () => {
    const result = toggleEducationMode(EDU_TENANT, { isEducationMode: false }, true, false);
    expect(result.success).toBe(true);
    expect(result.newMode).toBe('education');
    expect(result.previousMode).toBe('corporate');
  });

  it('C.4 | toggleEducationMode disable with payroll data: shows warning', () => {
    const result = toggleEducationMode(EDU_TENANT, { isEducationMode: true }, false, true);
    // Should warn that disabling with existing payroll data needs migration
    expect(result.warnings.length).toBeGreaterThan(0);
  });

  it('C.5 | leaveYearType is forced to "academic" in education mode', () => {
    expect(schoolConfig.leaveYearType).toBe('academic');
  });

  it('C.6 | Academic year start: month 6 (June)', () => {
    expect(schoolConfig.academicYearStartMonth).toBe(6);
    expect(schoolConfig.academicYearEndMonth).toBe(5);
  });
});

describe('SECTION C — Education Mode: Module Restrictions', () => {

  it('C.7 | Recruitment module disabled in education mode', () => {
    const result = isModuleAllowedInEducationMode(schoolConfig, 'recruitment');
    expect(result.allowed).toBe(false);
  });

  it('C.8 | Expense module disabled in education mode', () => {
    const result = isModuleAllowedInEducationMode(schoolConfig, 'expense');
    expect(result.allowed).toBe(false);
  });

  it('C.9 | Core payroll modules enabled in education mode', () => {
    const payroll = isModuleAllowedInEducationMode(schoolConfig, 'payroll');
    const tds     = isModuleAllowedInEducationMode(schoolConfig, 'payroll-tds');
    expect(payroll.allowed).toBe(true);
    expect(tds.allowed).toBe(true);
  });

  it('C.10 | EDUCATION_DISABLED_MODULES contains recruitment and expense', () => {
    expect(EDUCATION_DISABLED_MODULES).some((m: string) => m === 'recruitment');
    expect(EDUCATION_DISABLED_MODULES).some((m: string) => m === 'expense');
  });
});

describe('SECTION C — Education Mode: Roles & Staff', () => {

  it('C.11 | buildEducationRoles: returns at least 4 education roles', () => {
    const roles = buildEducationRoles(EDU_TENANT, 'system');
    const names = roles.map(r => r.name);
    expect(names).some((n: string) => n.includes('principal'));
    expect(names).some((n: string) => n.includes('teacher'));
    expect(names).some((n: string) => n.includes('hod'));
    expect(roles.length).toBeGreaterThanOrEqual(4);
  });

  it('C.12 | Teacher role: has leave module, NOT recruitment', () => {
    const roles = buildEducationRoles(EDU_TENANT, 'system');
    const teacher = roles.find(r => r.name.includes('teacher'));
    expect(teacher).toBeDefined();
    const hasLeave = teacher!.allowedModules.includes('leave');
    const hasRecruit = teacher!.allowedModules.includes('recruitment');
    expect(hasLeave).toBe(true);
    expect(hasRecruit).toBe(false);
  });

  it('C.13 | Principal role: has payroll module access and can approve leave:year-end', () => {
    const roles = buildEducationRoles(EDU_TENANT, 'system');
    const principal = roles.find(r => r.name === 'principal');
    expect(principal).toBeDefined();
    expect(principal!.allowedModules).some((m: string) => m === 'payroll');
    // Principal has leave:year-end approve permission
    const yearEndPerm = principal!.permissions.find(
      p => p.resource === 'leave:year-end' && p.actions.includes('approve')
    );
    expect(yearEndPerm).toBeDefined();
  });

  it('C.14 | Teacher leave entitlements: EL=30 days, CL=8 days (typical academic)', () => {
    const el = DEFAULT_TEACHER_LEAVE_ENTITLEMENTS.find(l => l.leaveTypeCode === 'EL');
    const cl = DEFAULT_TEACHER_LEAVE_ENTITLEMENTS.find(l => l.leaveTypeCode === 'CL');
    expect(el?.daysPerYear).toBeGreaterThanOrEqual(30);
    expect(cl).toBeDefined();
  });

  it('C.15 | Teacher leave: EL carry-forward is high (academic EL accumulates)', () => {
    const el = DEFAULT_TEACHER_LEAVE_ENTITLEMENTS.find(l => l.leaveTypeCode === 'EL');
    expect(el?.carryForwardDays).toBeGreaterThanOrEqual(100);  // Academic EL can accumulate
  });
});

describe('SECTION C — Education Mode: Dashboard & Academic Calendar', () => {

  it('C.16 | buildSchoolDashboard: returns school-specific dashboard data', () => {
    const staffRecords: import('../../settings/education-mode.engine').StaffRecord[] = [
      { employeeId: 's1', name: 'Mrs. Lakshmi', staffType: 'teaching', facultyId: 'dept-science', facultyName: 'Science', designation: 'PGT Chemistry', joinDate: '2020-06-01', isActive: true },
      { employeeId: 's2', name: 'Mr. Ravi',     staffType: 'teaching', facultyId: 'dept-maths', facultyName: 'Mathematics', designation: 'PGT Maths', joinDate: '2019-06-01', isActive: true },
      { employeeId: 's3', name: 'Mr. Suresh',   staffType: 'non-teaching', facultyId: 'dept-admin', facultyName: 'Administration', designation: 'Clerk', joinDate: '2021-01-01', isActive: true },
    ];
    schoolStaff = staffRecords as any;
    const leaveStats = { pendingApprovals: 5, averageEarnedLeaveBalance: 18, staffOnLeaveToday: 2 };
    const payrollStats = { lastPayrollRunDate: '2025-01-25', pendingApprovals: 0, payCommissionDistribution: { '7th': 3 } };
    const dashboard = buildSchoolDashboard(schoolConfig, staffRecords, leaveStats, payrollStats);

    expect(dashboard.tenantId).toBe(EDU_TENANT);
    expect(dashboard.totalStaff).toBe(3);
    expect(dashboard.teachingStaff).toBe(2);
    expect(dashboard.nonTeachingStaff).toBe(1);
    expect(dashboard.institutionType).toBe('school');
  });

  it('C.17 | School dashboard: academicYear label follows AY format', () => {
    const staffRecords: import('../../settings/education-mode.engine').StaffRecord[] = [
      { employeeId: 's1', name: 'Staff A', staffType: 'teaching', facultyId: 'f1', facultyName: 'Sci', designation: 'Teacher', joinDate: '2020-06-01', isActive: true },
    ];
    const leaveStats = { pendingApprovals: 2, averageEarnedLeaveBalance: 20, staffOnLeaveToday: 0 };
    const payrollStats = { lastPayrollRunDate: null, pendingApprovals: 0, payCommissionDistribution: {} };
    const dashboard = buildSchoolDashboard(schoolConfig, staffRecords, leaveStats, payrollStats);
    expect(dashboard.academicYearLabel).toMatch(/^AY \d{4}-\d{2}$/);  // "AY 2024-25"
  });

  it('C.18 | getCurrentAcademicYear: returns AcademicYear object with correct label', () => {
    const ay = getCurrentAcademicYear(schoolConfig);
    expect(ay.label).toMatch(/^AY \d{4}-\d{2}$/);
    expect(ay.startYear).toBeGreaterThan(2000);
    expect(ay.endYear).toBe(ay.startYear + 1);
  });

  it('C.19 | buildAcademicYear: correctly builds AY structure for given startYear', () => {
    const ay = buildAcademicYear(schoolConfig, 2024);
    expect(ay.startYear).toBe(2024);
    expect(ay.endYear).toBe(2025);
    expect(ay.label).toBe('AY 2024-25');
    expect(ay.startDate).toBeDefined();
    expect(ay.endDate).toBeDefined();
  });
});

describe('SECTION C — Education Mode: Payroll Run & Principal Workflow', () => {

  it('C.20 | validateEducationPayrollRun: valid run passes', () => {
    const result = validateEducationPayrollRun(schoolConfig, {
      month: 8, year: 2024, staffIds: ['s1', 's2', 's3'],
    });
    expect(result.isValid).toBe(true);
    expect(result.errors).toHaveLength(0);
    expect(result.payCommissionApplied).toBe('7th');
  });

  it('C.21 | validateEducationPayrollRun: April payroll → DA arrears warning', () => {
    const result = validateEducationPayrollRun(schoolConfig, {
      month: 4, year: 2024, staffIds: ['s1'],
    });
    expect(result.warnings.length).toBeGreaterThan(0);
    expect(result.warnings.some(w => w.toLowerCase().includes('da') || w.toLowerCase().includes('april'))).toBe(true);
  });

  it('C.22 | validateEducationPayrollRun: empty staffIds → error', () => {
    const result = validateEducationPayrollRun(schoolConfig, {
      month: 8, year: 2024, staffIds: [],
    });
    expect(result.isValid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
  });

  it('C.23 | initializeLeaveCloseWorkflow: creates multi-step workflow', () => {
    const workflow = initializeLeaveCloseWorkflow(schoolConfig, '2024-25');
    expect(workflow.status).toBe('pending');
    expect(workflow.steps.length).toBeGreaterThanOrEqual(3);
    expect(workflow.academicYear).toBe('2024-25');
  });

  it('C.24 | advanceWorkflowStep: progresses status correctly', () => {
    const workflow = initializeLeaveCloseWorkflow(schoolConfig, '2024-25');
    const step1 = workflow.steps[0];
    const advanced = advanceWorkflowStep(workflow, step1!.stepId, 'hod-user-001', 'HOD reviewed');
    expect(advanced.steps[0]!.isCompleted).toBe(true);
    expect(advanced.steps[0]!.completedBy).toBe('hod-user-001');
    expect(['in-progress', 'pending-principal', 'approved']).some((s: string) => s === advanced.status);
  });

  it('C.25 | Principal workflow: final step sets status to "approved"', () => {
    let workflow = initializeLeaveCloseWorkflow(schoolConfig, '2024-25');
    // Complete all steps
    for (const step of workflow.steps) {
      workflow = advanceWorkflowStep(workflow, step.stepId, `user-${step.stepId}`, 'approved');
    }
    expect(workflow.status).toBe('approved');
    expect(workflow.approvedBy).toBeDefined();
  });
});

describe('SECTION C — Education Mode: Tenant Isolation', () => {

  it('C.26 | verifyTenantIsolation: education ↔ education (same tenant) → isolated', () => {
    const result = verifyTenantIsolation(EDU_TENANT, { isEducationMode: true }, EDU_TENANT, { isEducationMode: true });
    expect(result.isolated).toBe(true);
    expect(result.violations).toHaveLength(0);
  });

  it('C.27 | verifyTenantIsolation: education → corporate cross-tenant → violation', () => {
    const result = verifyTenantIsolation(EDU_TENANT, { isEducationMode: true }, CORP_TENANT, { isEducationMode: false });
    expect(result.isolated).toBe(false);
    expect(result.violations.length).toBeGreaterThan(0);
  });

  it('C.28 | verifyTenantIsolation: corporate → corporate different tenant → violation', () => {
    const result = verifyTenantIsolation(CORP_TENANT, { isEducationMode: false }, 'tenant-corp-002', { isEducationMode: false });
    expect(result.isolated).toBe(false);
    expect(result.violations.length).toBeGreaterThan(0);
  });

  it('C.29 | Education roles do NOT appear in corporate tenant', () => {
    const eduRoles = buildEducationRoles(EDU_TENANT, 'system');
    const corpRoles = buildSystemRoles(CORP_TENANT, 'system');
    const corpNames = new Set(corpRoles.map(r => r.name));
    const eduOnlyRoles = eduRoles.filter(r => !corpNames.has(r.name));
    // There should be edu-specific roles (teacher, hod, etc.) absent from corp
    expect(eduOnlyRoles.length).toBeGreaterThan(0);
  });

  it('C.30 | Education mode: leave year type forced to academic — not financial', () => {
    const eduCfg = createEducationTenantConfig(EDU_TENANT, 'Test School', {});
    expect(eduCfg.leaveYearType).toBe('academic');
    expect(eduCfg.leaveYearType).not.toBe('financial');
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// INTEGRATION SCENARIOS
// ─────────────────────────────────────────────────────────────────────────────

describe('INTEGRATION — Leave Year-End × Role Engine', () => {

  it('INT.1 | Only hr-admin / finance can trigger year-end (not employee)', () => {
    const empRole = systemRoles.find(r => r.name === 'employee')!;
    const ctx = makeCtx([empRole]);
    const log: import('../../security/role-permission.engine').PermissionAuditEvent[] = [];
    const result = enforceAccess(ctx, 'leave', 'leave:year-end', 'create', log);
    expect(result.allowed).toBe(false);
    expect(log.length).toBeGreaterThan(0);
    expect(log[0]!.action).toBe('access_denied');
  });

  it('INT.2 | HR-admin can approve year-end leave encashment', () => {
    const hrRole = systemRoles.find(r => r.name === 'hr-admin')!;
    const ctx = makeCtx([hrRole]);
    const log: import('../../security/role-permission.engine').PermissionAuditEvent[] = [];
    const result = enforceAccess(ctx, 'leave', 'leave:year-end', 'approve', log);
    expect(result.allowed).toBe(true);
  });

  it('INT.3 | Year-end simulation does not affect real balances (isSimulation=true)', () => {
    const result = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    expect(result.isSimulation).toBe(true);
    expect(result.isLocked).toBe(false);
    // Verify invariants
    const check = verifyLedgerConsistency(result.computed);
    expect(check.isConsistent).toBe(true);
  });
});

describe('INTEGRATION — Education Mode × Leave Year-End', () => {

  it('INT.4 | Education tenant uses academic year for year-end', () => {
    const eduResult = processBatchYearEnd(EDU_TENANT, ACAD_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    expect(eduResult.yearType).toBe('academic');
    expect(eduResult.tenantId).toBe(EDU_TENANT);
  });

  it('INT.5 | Education × corporate tenant: different year-end configs are isolated', () => {
    const corpResult = processBatchYearEnd(CORP_TENANT, FIN_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    const eduResult  = processBatchYearEnd(EDU_TENANT, ACAD_CONFIG, make5EmployeeSnapshots(), LEAVE_TYPE_MAP, true);
    expect(corpResult.yearType).toBe('financial');
    expect(eduResult.yearType).toBe('academic');
    expect(corpResult.ledgerHash).not.toBe(eduResult.ledgerHash);
  });

  it('INT.6 | Academic leave close via Principal workflow must complete all steps', () => {
    let workflow = initializeLeaveCloseWorkflow(schoolConfig, '2024-25');
    const notComplete = workflow.steps.some(s => !s.isCompleted);
    expect(notComplete).toBe(true);  // Steps incomplete before advancing
  });

  it('INT.7 | Education tenant payroll uses 7th Pay Commission by default', () => {
    const result = validateEducationPayrollRun(schoolConfig, {
      month: 9, year: 2024, staffIds: ['s1', 's2'],
    });
    expect(result.payCommissionApplied).toBe('7th');
    expect(result.isValid).toBe(true);
  });
});

// ─── Final summary ─────────────────────────────────────────────────────────

console.log('\n══════════════════════════════════════════════════════════════');
console.log(`  RESULTS: ${_passed} passed, ${_failed} failed, ${_total} total`);
console.log('══════════════════════════════════════════════════════════════');

if (_failures.length > 0) {
  console.log('\n  FAILURES:');
  _failures.forEach(f => console.log(`\n  ${f}`));
}

if (_failed > 0) process.exit(1);
