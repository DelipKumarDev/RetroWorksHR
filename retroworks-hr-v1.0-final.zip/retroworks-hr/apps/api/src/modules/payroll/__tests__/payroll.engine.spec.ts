import { IndiaPayrollEngine, PF_WAGE_CEILING, ESI_WAGE_LIMIT } from '../payroll.engine';

const engine = new IndiaPayrollEngine();
const stdSalary = { basic: 50_000, hra: 20_000, specialAllowance: 15_000, lta: 5_000, medicalAllowance: 1_250, otherAllowances: 0 };

describe('IndiaPayrollEngine', () => {

  describe('Gross Pay', () => {
    it('sums all components correctly', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: stdSalary, stateCode: 'KA', pfOptIn: false, taxRegime: 'new' });
      expect(r.grossPay).toBe(91_250);
    });

    it('includes bonus in gross', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: { ...stdSalary, bonus: 10_000 }, stateCode: 'KA', pfOptIn: false, taxRegime: 'new' });
      expect(r.bonus).toBe(10_000);
      expect(r.grossPay).toBe(101_250);
    });
  });

  describe('Loss of Pay', () => {
    it('reduces pay proportionally', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: { basic: 52_000, hra: 0, specialAllowance: 0, lta: 0, medicalAllowance: 0, otherAllowances: 0 }, stateCode: 'KA', pfOptIn: false, taxRegime: 'new', lopDays: 2, workingDays: 26 });
      expect(r.lopDeduction).toBeCloseTo(4_000, 0);
    });

    it('zero deduction with no LOP', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: { basic: 50_000, hra: 0, specialAllowance: 0, lta: 0, medicalAllowance: 0, otherAllowances: 0 }, stateCode: 'KA', pfOptIn: false, taxRegime: 'new', lopDays: 0 });
      expect(r.lopDeduction).toBe(0);
    });
  });

  describe('Provident Fund', () => {
    it('caps PF wage at ₹15,000', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: stdSalary, stateCode: 'KA', pfOptIn: true, taxRegime: 'new' });
      expect(r.pfWage).toBe(PF_WAGE_CEILING);
      expect(r.pfEmployee).toBe(1_800);
    });

    it('uses actual basic when below ceiling', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: { ...stdSalary, basic: 12_000 }, stateCode: 'KA', pfOptIn: true, taxRegime: 'new' });
      expect(r.pfWage).toBe(12_000);
      expect(r.pfEmployee).toBe(1_440);
    });

    it('zero PF when opted out', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: stdSalary, stateCode: 'KA', pfOptIn: false, taxRegime: 'new' });
      expect(r.pfEmployee).toBe(0);
      expect(r.pfEmployer).toBe(0);
    });

    it('employer split sums to 12% of PF wage', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: stdSalary, stateCode: 'KA', pfOptIn: true, taxRegime: 'new' });
      expect(r.pfEmployer + r.pfEps).toBeCloseTo(PF_WAGE_CEILING * 0.12, 1);
    });
  });

  describe('ESI', () => {
    it('applies ESI for gross ≤ ₹21,000', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: { basic: 12_000, hra: 5_000, specialAllowance: 3_500, lta: 0, medicalAllowance: 0, otherAllowances: 0 }, stateCode: 'KA', pfOptIn: false, taxRegime: 'new' });
      expect(r.esiApplicable).toBe(true);
      expect(r.esiEmployee).toBeCloseTo(r.esiWage * 0.0075, 2);
    });

    it('no ESI for gross > ₹21,000', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: stdSalary, stateCode: 'KA', pfOptIn: false, taxRegime: 'new' });
      expect(r.esiApplicable).toBe(false);
      expect(r.esiEmployee).toBe(0);
    });
  });

  describe('Professional Tax', () => {
    it('KA PT = ₹200 above ₹15,000', () => { expect(engine.computePT(20_000, 'KA')).toBe(200); });
    it('KA PT = ₹0 at ₹14,999', () => { expect(engine.computePT(14_999, 'KA')).toBe(0); });
    it('MH PT slabs work', () => { expect(engine.computePT(7_000, 'MH')).toBe(0); expect(engine.computePT(9_000, 'MH')).toBe(175); });
    it('no PT for DL', () => { expect(engine.computePT(100_000, 'DL')).toBe(0); });
    it('no PT for GJ', () => { expect(engine.computePT(100_000, 'GJ')).toBe(0); });
    it('TN multi-slab', () => { expect(engine.computePT(20_000, 'TN')).toBe(0); expect(engine.computePT(25_000, 'TN')).toBe(135); });
  });

  describe('TDS – New Regime', () => {
    it('zero TDS with rebate for income ≤ ₹7L', () => {
      const r = engine.compute({ employeeId: 'e1', month: 4, year: 2024, salaryStructure: { basic: 30_000, hra: 10_000, specialAllowance: 5_000, lta: 0, medicalAllowance: 0, otherAllowances: 0 }, stateCode: 'KA', pfOptIn: false, taxRegime: 'new' });
      expect(r.tdsDeducted).toBe(0);
    });

    it('standard deduction ₹75,000 applied', () => {
      const r = engine.compute({ employeeId: 'e1', month: 4, year: 2024, salaryStructure: { basic: 80_000, hra: 0, specialAllowance: 0, lta: 0, medicalAllowance: 0, otherAllowances: 0 }, stateCode: 'KA', pfOptIn: false, taxRegime: 'new' });
      expect(r.annualGross - r.taxableIncome).toBe(75_000);
    });

    it('positive TDS for income above ₹7.5L', () => {
      const r = engine.compute({ employeeId: 'e1', month: 4, year: 2024, salaryStructure: { basic: 75_000, hra: 0, specialAllowance: 0, lta: 0, medicalAllowance: 0, otherAllowances: 0 }, stateCode: 'KA', pfOptIn: false, taxRegime: 'new' });
      expect(r.tdsDeducted).toBeGreaterThan(0);
    });
  });

  describe('TDS – Old Regime', () => {
    it('80C deduction capped at ₹1.5L', () => {
      const r200k = engine.compute({ employeeId: 'e1', month: 4, year: 2024, salaryStructure: { basic: 80_000, hra: 30_000, specialAllowance: 0, lta: 0, medicalAllowance: 0, otherAllowances: 0 }, stateCode: 'KA', pfOptIn: false, taxRegime: 'old', declarationsOld: { section80C: 200_000 } });
      const r150k = engine.compute({ employeeId: 'e1', month: 4, year: 2024, salaryStructure: { basic: 80_000, hra: 30_000, specialAllowance: 0, lta: 0, medicalAllowance: 0, otherAllowances: 0 }, stateCode: 'KA', pfOptIn: false, taxRegime: 'old', declarationsOld: { section80C: 150_000 } });
      expect(r200k.tdsDeducted).toBe(r150k.tdsDeducted);
    });
  });

  describe('Net Pay & CTC', () => {
    it('net = gross - deductions', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: stdSalary, stateCode: 'KA', pfOptIn: true, taxRegime: 'new' });
      expect(r.netPay).toBeCloseTo(r.grossPay - r.totalDeductions, 1);
    });

    it('CTC = gross + employer contributions', () => {
      const r = engine.compute({ employeeId: 'e1', month: 3, year: 2024, salaryStructure: stdSalary, stateCode: 'KA', pfOptIn: true, taxRegime: 'new' });
      const expectedCTC = r.grossPay + r.pfEmployer + r.pfEps + r.pfAdminCharge + r.esiEmployer;
      expect(r.ctcMonthly).toBeCloseTo(expectedCTC, 1);
    });
  });

  describe('Gratuity', () => {
    it('zero for < 5 years service', () => { expect(engine.computeGratuity(50_000, 4)).toBe(0); });
    it('formula = basic × 15/26 × years', () => { expect(engine.computeGratuity(50_000, 5)).toBeCloseTo(50_000 * 15 / 26 * 5, 0); });
    it('scales linearly', () => { expect(engine.computeGratuity(50_000, 10)).toBeCloseTo(engine.computeGratuity(50_000, 5) * 2, 1); });
  });

  describe('Full & Final', () => {
    it('includes gratuity and EL encashment', () => {
      const fnf = engine.computeFnF({ basic: 50_000, yearsOfService: 7, earnedLeaveBalance: 20 });
      expect(fnf.gratuity).toBeGreaterThan(0);
      expect(fnf.earnedLeaveEncashment).toBeGreaterThan(0);
    });

    it('deducts notice period shortfall', () => {
      const with_ = engine.computeFnF({ basic: 50_000, yearsOfService: 7, earnedLeaveBalance: 10, noticePeriodShortfall: 15 });
      const without = engine.computeFnF({ basic: 50_000, yearsOfService: 7, earnedLeaveBalance: 10 });
      expect(with_.totalPayable).toBeLessThan(without.totalPayable);
    });

    it('EL encashment capped at 30 days', () => {
      const r30 = engine.computeFnF({ basic: 30_000, yearsOfService: 6, earnedLeaveBalance: 30 });
      const r60 = engine.computeFnF({ basic: 30_000, yearsOfService: 6, earnedLeaveBalance: 60 });
      expect(r30.earnedLeaveEncashment).toBe(r60.earnedLeaveEncashment);
    });
  });
});
