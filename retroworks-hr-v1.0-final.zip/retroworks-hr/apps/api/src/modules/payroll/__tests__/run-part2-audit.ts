/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * MASTER AUDIT — PART 2
 * Statutory Payroll Stack: Functional Correctness
 * Self-contained ts-node runner (no jest required)
 * ═══════════════════════════════════════════════════════════════════════════════
 */

// ─── Minimal test harness ────────────────────────────────────────────────────
let _passed = 0, _failed = 0, _total = 0;
let _currentBlock = '';
const _failures: string[] = [];

function describe(label: string, fn: () => void) {
  _currentBlock = label;
  console.log(`\n  ${label}`);
  fn();
}

function it(label: string, fn: () => void) {
  _total++;
  try {
    fn();
    console.log(`    ✅  ${label}`);
    _passed++;
  } catch (e: any) {
    const msg = `    ❌  ${label}\n       ${e.message}`;
    console.log(msg);
    _failures.push(`[${_currentBlock}] ${label}\n       ${e.message}`);
    _failed++;
  }
}

function expect(actual: any) {
  return {
    toBe: (expected: any) => {
      if (actual !== expected)
        throw new Error(`Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
    },
    toBeCloseTo: (expected: number, decimals = 2) => {
      const factor = Math.pow(10, decimals);
      const diff = Math.abs(actual - expected);
      if (diff > (decimals === -2 ? 500 : decimals === 0 ? 0.5 : 1 / factor))
        throw new Error(`Expected ~${expected}, got ${actual} (diff ${diff.toFixed(4)})`);
    },
    toBeGreaterThan: (n: number) => { if (!(actual > n)) throw new Error(`Expected ${actual} > ${n}`); },
    toBeGreaterThanOrEqual: (n: number) => { if (!(actual >= n)) throw new Error(`Expected ${actual} >= ${n}`); },
    toBeLessThan: (n: number) => { if (!(actual < n)) throw new Error(`Expected ${actual} < ${n}`); },
    toBeLessThanOrEqual: (n: number) => { if (!(actual <= n)) throw new Error(`Expected ${actual} <= ${n}`); },
    toEqual: (expected: any) => {
      if (JSON.stringify(actual) !== JSON.stringify(expected))
        throw new Error(`Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
    },
    toHaveLength: (n: number) => {
      if (!actual || actual.length !== n)
        throw new Error(`Expected length ${n}, got ${actual?.length}`);
    },
    toBeDefined: () => { if (actual === undefined || actual === null) throw new Error(`Expected defined value, got ${actual}`); },
    not: {
      toBe: (expected: any) => {
        if (actual === expected) throw new Error(`Expected NOT ${JSON.stringify(expected)}`);
      },
      toBeUndefined: () => { if (actual === undefined) throw new Error(`Expected to be defined`); },
    },
    toMatch: (pattern: RegExp) => {
      if (!pattern.test(actual)) throw new Error(`"${actual}" does not match ${pattern}`);
    },
    toContain: (sub: string) => {
      if (!actual?.includes?.(sub)) throw new Error(`"${actual}" does not contain "${sub}"`);
    },
    toThrow: (partial?: string) => {
      if (typeof actual !== 'function') throw new Error(`Expected a function to call`);
      try { actual(); throw new Error('NO_THROW'); }
      catch (e: any) {
        if (e.message === 'NO_THROW') throw new Error(`Expected function to throw`);
        if (partial && !e.message?.includes(partial))
          throw new Error(`Expected throw containing "${partial}", got "${e.message}"`);
      }
    },
    toBeUndefined: () => {
      if (actual !== undefined) throw new Error(`Expected undefined, got ${JSON.stringify(actual)}`);
    },
    some: (pred: (x: any) => boolean) => {
      if (!Array.isArray(actual)) throw new Error(`Expected array, got ${typeof actual}`);
      if (!actual.some(pred)) throw new Error(`Expected some element to match predicate`);
      return true;
    },
    find: (pred: (x: any) => boolean) => {
      if (!Array.isArray(actual)) throw new Error(`Expected array`);
      return actual.find(pred);
    },
  };
}

// ─── Imports ─────────────────────────────────────────────────────────────────

import {
  computeSlabTax,
  computeSurcharge,
  computeHraExemption,
  computeDeductions,
  computeAnnualTax,
  projectTds,
  compareRegimes,
  calendarToFyMonth,
  DEFAULT_FY_CONFIG,
  r2,
  toRupee,
} from '../tds/tds.engine';

import {
  IndiaPayrollEngine,
  payrollEngine,
} from '../payroll.engine';

import {
  computeMonthlyPt,
  computeEsiContribution,
  computePfWages,
  computeEpfContributionEmployee,
  computeEpfContributionEmployer,
  computeEpsContribution,
  computeEdliContribution,
  computeAdminCharge,
  assembleEcr,
  assembleEsiContribution,
  getWageMonth,
  EPS_MAX_MONTHLY,
  type EmployerDetails,
  type MonthlyPayslipInput,
} from '../pf-esi/pf-esi.engine';

import {
  validateReturn,
  assembleAnnexureI,
  getQuarterForMonth,
  getAssessmentYear,
  getCIN,
  validateTAN,
  validatePAN,
  validateBSRCode,
  type ReturnValidationInput,
  type DeductorInfo,
  type ChallanRecord,
  type EmployeeDeducteeRecord,
} from '../tds-returns/return.engine';

import {
  assembleForm16,
  validateForm16Input,
  aggregateQuarterlyTds,
  getAssessmentYear as f16AY,
  fyToDateRange,
  computeChecksum,
  generateCertificateNumber,
  buildDashboardEntry,
  type Form16AssemblyInput,
  type MonthlyPayslipSummary,
} from '../form16/form16.engine';

import {
  computeRevisedTdsSchedule,
  processRevisionAndArrears,
  validateRevisionInput,
  HISTORICAL_FY_CONFIGS,
  type SalaryRevisionInput,
} from '../arrears/arrears.engine';

// ─── Fixtures ────────────────────────────────────────────────────────────────

const FY = '2024-25';

const EMPLOYER: EmployerDetails = {
  establishmentName: 'RetroWorks Technologies Pvt Ltd',
  pfRegistrationNumber: 'KA/BAN/001/0000001',
  esiRegistrationNumber: '5201234567890',
  tan: 'BANG12345C',
  pan: 'AABCR1234A',
  address: '100 Tech Park, Bangalore',
  state: 'KA',
};

const DEDUCTOR: DeductorInfo = {
  tan: 'BANG12345C',
  pan: 'AABCR1234A',
  name: 'RetroWorks Technologies Pvt Ltd',
  address: '100 Tech Park, Bangalore',
  city: 'Bangalore',
  state: 'KA',
  pincode: '560001',
  phone: '9876543210',
  email: 'payroll@retroworks.in',
  responsiblePersonName: 'Priya Nair',
  responsiblePersonPan: 'ABCPN5678R',
  responsiblePersonDesignation: 'CFO',
  deductorType: 'Company',
};

const BASE_PAYSLIP: MonthlyPayslipInput = {
  employeeId: 'emp-001',
  name: 'Arjun Mehta',
  uan: '101234567890',
  esiInsuranceNumber: '5201100001',
  basicWages: 30_000,
  grossWages: 90_000,
  ncpDays: 0,
  vpfContribution: 0,
  isEsiApplicable: false,
  daysWorked: 26,
  halfDayLeave: 0,
};

const makeSalaryInput = (overrides: Record<string, any> = {}) => ({
  employeeId: 'emp-001',
  month: 8,
  year: 2024,
  salaryStructure: {
    basic: 50_000,
    hra: 20_000,
    specialAllowance: 20_000,
    lta: 5_000,
    medicalAllowance: 0,
    otherAllowances: 0,
  },
  stateCode: 'KA',
  pfOptIn: true,
  taxRegime: 'new' as const,
  ...overrides,
});

const makeTdsInput = (overrides: Record<string, any> = {}) => ({
  employeeId: 'emp-001',
  financialYear: FY,
  currentMonth: 5,
  currentCalendarMonth: 8,
  currentYear: 2024,
  salaryComponents: {
    basic: 50_000,
    hra: 20_000,
    specialAllowance: 20_000,
    lta: 5_000,
    medicalAllowance: 0,
    otherAllowances: 0,
  },
  declaration: { regimeType: 'new' as const },
  pfEmployeeMonthly: 1_800,
  ytdGrossPaid: 380_000,
  ytdTdsDeducted: 12_000,
  ytdPfDeducted: 7_200,
  fyConfig: DEFAULT_FY_CONFIG,
  ...overrides,
});

const makeChallan = (overrides: Partial<ChallanRecord> = {}): ChallanRecord => ({
  id: 'chal-001',
  bsrCode: '1234567',
  challanSerialNumber: '00001',
  challanDate: '01/04/2024',
  totalAmountDeposited: 50_000,
  tdsAmount: 50_000,
  surchargeAmount: 0,
  educationCessAmount: 0,
  interestAmount: 0,
  penaltyAmount: 0,
  otherAmount: 0,
  bankName: 'SBI',
  section: '192',
  quarter: 'Q1' as const,
  financialYear: FY,
  isLinkedToReturn: true,
  ...overrides,
});

const makeDeductee = (overrides: Partial<EmployeeDeducteeRecord> = {}): EmployeeDeducteeRecord => ({
  employeeId: 'emp-001',
  name: 'Arjun Mehta',
  pan: 'ABCPM1234A',
  category: 'Resident' as const,
  grossSalary: 12_00_000,
  hraExemption: 0,
  ltaExemption: 0,
  otherSection10Exemptions: 0,
  standardDeduction: 75_000,
  professionalTax: 2_400,
  totalDeductionsChapterVIA: 1_50_000,
  taxableIncome: 9_72_600,
  taxOnIncome: 52_890,
  surcharge: 0,
  educationCess: 2_115,
  totalTaxLiability: 55_005,
  reliefUnder89: 0,
  netTaxPayable: 55_005,
  totalTdsDeducted: 50_000,
  tdsDeductedThisQuarter: 50_000,
  regimeType: 'new' as const,
  quarterlyGrossSalary: 3_00_000,
  quarterlyTds: 50_000,
  ...overrides,
});

const makeValidReturn = (overrides: Partial<ReturnValidationInput> = {}): ReturnValidationInput => ({
  deductor: DEDUCTOR,
  challans: [makeChallan()],
  deductees: [makeDeductee()],
  quarter: 'Q1' as const,
  financialYear: FY,
  ...overrides,
});

const makeRevisionInput = (overrides: Partial<SalaryRevisionInput> = {}): SalaryRevisionInput => ({
  employeeId: 'emp-001',
  employeeName: 'Arjun Mehta',
  pan: 'ABCPM1234A',
  regimeType: 'new',
  effectiveFrom: '2024-04-01',
  revisionAnnouncedDate: '2024-10-01',
  currentFinancialYear: '2024-25',
  oldMonthlyBasic: 50_000,
  oldMonthlyHRA: 20_000,
  oldMonthlySpecialAllowance: 20_000,
  oldMonthlyOtherAllowances: 5_000,
  oldMonthlyGross: 95_000,
  newMonthlyBasic: 60_000,
  newMonthlyHRA: 24_000,
  newMonthlySpecialAllowance: 24_000,
  newMonthlyOtherAllowances: 6_000,
  newMonthlyGross: 1_14_000,
  currentFyTaxableIncome: 9_00_000,
  currentFyTotalTaxPaid: 45_000,
  currentFyRemainingMonths: 6,
  priorFyIncomesAndTax: [],
  ...overrides,
});

const makeF16Input = (): Form16AssemblyInput => {
  const payslips: MonthlyPayslipSummary[] = [4,5,6,7,8,9,10,11,12,1,2,3].map(m => ({
    period: `${m >= 4 ? '2024' : '2025'}-${String(m).padStart(2,'0')}`,
    month: m,
    year: m >= 4 ? 2024 : 2025,
    grossPay: 95_000,
    tdsDeducted: 5_000,
    pfEmployee: 1_800,
    professionalTax: m === 4 ? 0 : 200,
  }));

  return {
    financialYear: FY,
    employer: {
      name: 'RetroWorks Technologies Pvt Ltd',
      tan: 'BANG12345C',
      pan: 'AABCR1234A',
      address: '100 Tech Park, Bangalore',
      city: 'Bangalore',
      pincode: '560001',
      state: 'KA',
      designation: 'CFO',
      signatoryName: 'Priya Nair',
    },
    employee: {
      id: 'emp-001',
      name: 'Arjun Mehta',
      pan: 'ABCPM1234A',
      address: '50 MG Road',
      city: 'Bangalore',
      pincode: '560001',
      state: 'KA',
      employeeCode: 'A001',
      designation: 'Senior Engineer',
      department: 'Engineering',
      dateOfJoining: '01/04/2024',
    },
    monthlyPayslips: payslips,
    tdsProjection: {
      regimeType: 'new',
      projectedAnnualIncome: 11_40_000,
      totalTaxLiability: 60_000,
      totalCess: 2_400,
      taxableIncome: 10_65_000,
      taxBeforeRebate: 57_750,
      rebate87A: 0,
      taxAfterRebate: 57_750,
      surcharge: 0,
      cess: 2_310,
      effectiveTaxRate: 5.43,
      slabWiseBreakdown: [],
    },
    declaration: null,
    professionalTaxPaid: 2_200,
    certificationNumber: 'F16-202425-A001-0001',
  };
};

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK 1 — TDS ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

console.log('\n══════════════════════════════════════════════════════════════');
console.log('  MASTER AUDIT — PART 2: Functional Correctness');
console.log('══════════════════════════════════════════════════════════════');

describe('BLOCK 1 — TDS Engine (tds.engine.ts)', () => {

  it('1.1 | New regime slab tax ₹10,00,000: slab-by-slab breakdown', () => {
    const { total, slabWise } = computeSlabTax(10_00_000, DEFAULT_FY_CONFIG.newRegimeSlabs);
    // 0–3L=₹0, 3L–6L=₹15K@5%, 6L–9L=₹30K@10%, 9L–10L=₹15K@15% → ₹60K
    expect(total).toBe(60_000);
    const s1 = slabWise.find((s: any) => s.slabFrom === 3_00_001);
    const s2 = slabWise.find((s: any) => s.slabFrom === 6_00_001);
    const s3 = slabWise.find((s: any) => s.slabFrom === 9_00_001);
    expect(s1?.taxInSlab).toBe(15_000);
    expect(s2?.taxInSlab).toBe(30_000);
    expect(s3?.taxInSlab).toBe(15_000);
  });

  it('1.2 | New regime 87A rebate: taxable income ≤ ₹7L → zero annual tax', () => {
    const r = computeAnnualTax({
      taxableIncome: 7_00_000,
      regimeType: 'new',
      grossForSurcharge: 7_00_000,
      fyConfig: DEFAULT_FY_CONFIG,
    });
    expect(r.taxBeforeRebate).toBe(25_000);
    expect(r.rebate87A).toBe(25_000);
    expect(r.totalAnnualTax).toBe(0);
  });

  it('1.3 | New regime: ₹7,00,001 → rebate exhausted, tax due', () => {
    const r = computeAnnualTax({
      taxableIncome: 7_00_001,
      regimeType: 'new',
      grossForSurcharge: 7_00_001,
      fyConfig: DEFAULT_FY_CONFIG,
    });
    expect(r.rebate87A).toBe(0);
    expect(r.totalAnnualTax).toBeGreaterThan(25_000);
  });

  it('1.4 | HRA exemption metro: min(HRA, rent−10%basic, 50%basic) = ₹1,80,000', () => {
    const h = computeHraExemption({
      monthlyBasic: 30_000,
      monthlyHra: 15_000,
      monthlyRentPaid: 20_000,
      cityType: 'metro',
      remainingMonths: 8,
      elapsedMonths: 4,
    });
    expect(h.limit1_actualHra).toBe(1_80_000);            // HRA received
    expect(h.limit3_percentOfBasic).toBe(1_80_000);       // 50% basic metro
    expect(h.exemptionAnnual).toBe(1_80_000);
    expect(h.taxableHraAnnual).toBe(0);
  });

  it('1.5 | HRA exemption non-metro: limit3 = 40% of basic (not 50%)', () => {
    const h = computeHraExemption({
      monthlyBasic: 40_000,
      monthlyHra: 25_000,
      monthlyRentPaid: 30_000,
      cityType: 'non-metro',
      remainingMonths: 8,
      elapsedMonths: 4,
    });
    // 40% × ₹4,80,000 annual basic = ₹1,92,000
    expect(h.limit3_percentOfBasic).toBe(1_92_000);
    expect(h.exemptionAnnual).toBe(1_92_000);
  });

  it('1.6 | Old regime deductions: caps enforced on 80C/80D/80CCD(1B)', () => {
    const d = computeDeductions({
      declaration: {
        regimeType: 'old',
        section80C: 2_00_000,              // declared ₹2L → capped at ₹1.5L
        section80D_self: 30_000,            // → capped at ₹25K
        section80D_parents: 60_000,         // senior → capped at ₹50K
        section80D_parentsIsSenior: true,
        section80CCD1B: 75_000,             // NPS → capped at ₹50K
      },
      pfEmployeeAnnual: 0,
      fyConfig: DEFAULT_FY_CONFIG,
      regimeType: 'old',
    });
    expect(d.section80C_allowed).toBe(1_50_000);
    expect(d.section80D_self).toBe(25_000);
    expect(d.section80D_parents).toBe(50_000);
    expect(d.section80CCD1B).toBe(50_000);
    expect(d.standardDeduction).toBe(50_000);
    expect(d.totalDeductions).toBe(50_000 + 1_50_000 + 25_000 + 50_000 + 50_000);
  });

  it('1.7 | Surcharge: income ₹55L → 10% surcharge', () => {
    const { surcharge, rate } = computeSurcharge(5_00_000, 55_00_000, DEFAULT_FY_CONFIG.surchargeSlabs);
    expect(rate).toBe(0.10);
    expect(surcharge).toBe(50_000);
  });

  it('1.8 | Surcharge: income ₹1.1Cr → 15% surcharge tier', () => {
    const { surcharge, rate } = computeSurcharge(30_00_000, 1_10_00_000, DEFAULT_FY_CONFIG.surchargeSlabs);
    expect(rate).toBe(0.15);
    expect(surcharge).toBe(4_50_000);
  });

  it('1.9 | 4% Cess on (tax + surcharge): ₹10L income → cess = ₹2,400', () => {
    const r = computeAnnualTax({
      taxableIncome: 10_00_000,
      regimeType: 'new',
      grossForSurcharge: 10_00_000,
      fyConfig: DEFAULT_FY_CONFIG,
    });
    expect(r.cess).toBe(r2(60_000 * 0.04));   // ₹2,400
    expect(r.totalAnnualTax).toBe(62_400);
  });

  it('1.10 | Monthly TDS equalization: remaining liability / remaining months', () => {
    const result = projectTds(makeTdsInput({
      currentMonth: 10,
      ytdTdsDeducted: 0,
      ytdGrossPaid: 9 * 95_000,
    }));
    expect(result.remainingMonths).toBe(3);
    const expectedMonthly = toRupee(result.remainingTaxLiability / 3);
    expect(result.monthlyTdsAmount).toBe(Math.max(0, expectedMonthly));
  });

  it('1.11 | Monthly TDS clamped to ≥ 0 when over-deducted', () => {
    const result = projectTds(makeTdsInput({
      currentMonth: 12,
      ytdTdsDeducted: 99_999_999,
    }));
    expect(result.monthlyTdsAmount).toBe(0);
    expect(result.remainingTaxLiability).toBe(0);
  });

  it('1.12 | Mid-year joiner: prev employer income increases taxable income', () => {
    const base = projectTds(makeTdsInput({ declaration: { regimeType: 'old' as const, section80C: 1_50_000 } }));
    const withPrev = projectTds(makeTdsInput({
      declaration: {
        regimeType: 'old' as const,
        section80C: 1_50_000,
        prevEmployerIncome: 5_00_000,
        prevEmployerTds: 20_000,
      },
    }));
    expect(withPrev.taxBreakdown.prevEmployerIncome).toBe(5_00_000);
    expect(withPrev.taxBreakdown.taxableIncome).toBeGreaterThan(base.taxBreakdown.taxableIncome);
  });

  it('1.13 | Regime comparison: high deductions (HRA metro + 80C + 80D) → old regime wins', () => {
    const c = compareRegimes({
      employeeId: 'e1',
      financialYear: FY,
      currentMonth: 1,
      currentCalendarMonth: 4,
      currentYear: 2024,
      salaryComponents: { basic: 80_000, hra: 40_000, specialAllowance: 30_000, lta: 5_000, medicalAllowance: 0, otherAllowances: 0 },
      pfEmployeeMonthly: 9_600,
      ytdGrossPaid: 0,
      ytdTdsDeducted: 0,
      ytdPfDeducted: 0,
      declarationBase: { section80C: 1_50_000, section80D_self: 25_000, hraRentPaid: 40_000, hraCityType: 'metro' },
      fyConfig: DEFAULT_FY_CONFIG,
    });
    expect(c.recommendedRegime).toBe('old');
    expect(c.oldRegime.annualTax).toBeLessThan(c.newRegime.annualTax);
  });

  it('1.14 | Regime comparison: nil deductions → new regime wins', () => {
    const c = compareRegimes({
      employeeId: 'e1',
      financialYear: FY,
      currentMonth: 1,
      currentCalendarMonth: 4,
      currentYear: 2024,
      salaryComponents: { basic: 80_000, hra: 40_000, specialAllowance: 30_000, lta: 0, medicalAllowance: 0, otherAllowances: 0 },
      pfEmployeeMonthly: 9_600,
      ytdGrossPaid: 0,
      ytdTdsDeducted: 0,
      ytdPfDeducted: 0,
      declarationBase: { section80C: 0, section80D_self: 0, hraRentPaid: 0 },
      fyConfig: DEFAULT_FY_CONFIG,
    });
    expect(c.recommendedRegime).toBe('new');
  });

  it('1.15 | calendarToFyMonth: April 2024 → FY month 1, "2024-25"', () => {
    const { fyMonth, financialYear } = calendarToFyMonth(4, 2024);
    expect(fyMonth).toBe(1);
    expect(financialYear).toBe('2024-25');
  });

  it('1.16 | calendarToFyMonth: March 2025 → FY month 12, "2024-25"', () => {
    const { fyMonth, financialYear } = calendarToFyMonth(3, 2025);
    expect(fyMonth).toBe(12);
    expect(financialYear).toBe('2024-25');
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK 2 — PAYROLL ENGINE
// ═══════════════════════════════════════════════════════════════════════════════

describe('BLOCK 2 — Payroll Engine (payroll.engine.ts)', () => {

  it('2.1 | PF wage ceiling: basic ₹30K → PF computed on ₹15K', () => {
    const r = payrollEngine.compute(makeSalaryInput({
      salaryStructure: { basic: 30_000, hra: 15_000, specialAllowance: 10_000, lta: 0, medicalAllowance: 0, otherAllowances: 0 },
    }));
    expect(r.pfWage).toBe(15_000);
    expect(r.pfEmployee).toBe(Math.round(15_000 * 0.12));
  });

  it('2.2 | pfOptIn=false → zero PF employee and employer', () => {
    const r = payrollEngine.compute(makeSalaryInput({ pfOptIn: false }));
    expect(r.pfEmployee).toBe(0);
    expect(r.pfEmployer).toBe(0);
    expect(r.pfEps).toBe(0);
  });

  it('2.3 | ESI applicable: gross ≤ ₹21K → employee 0.75%, employer 3.25%', () => {
    const r = payrollEngine.compute(makeSalaryInput({
      salaryStructure: { basic: 10_000, hra: 5_000, specialAllowance: 5_000, lta: 0, medicalAllowance: 0, otherAllowances: 0 },
    }));
    expect(r.esiApplicable).toBe(true);
    expect(r.esiEmployee).toBe(Math.round(r.esiWage * 0.0075));
    expect(r.esiEmployer).toBe(Math.round(r.esiWage * 0.0325));
  });

  it('2.4 | ESI not applicable: gross ₹95K → zero ESI', () => {
    const r = payrollEngine.compute(makeSalaryInput());
    expect(r.esiApplicable).toBe(false);
    expect(r.esiEmployee).toBe(0);
    expect(r.esiEmployer).toBe(0);
  });

  it('2.5 | ESI boundary: gross exactly ₹21,000 → applicable', () => {
    const r = payrollEngine.compute(makeSalaryInput({
      salaryStructure: { basic: 10_500, hra: 5_250, specialAllowance: 5_250, lta: 0, medicalAllowance: 0, otherAllowances: 0 },
    }));
    expect(r.grossPay).toBe(21_000);
    expect(r.esiApplicable).toBe(true);
  });

  it('2.6 | ESI boundary: gross ₹21,001 → NOT applicable', () => {
    const { isApplicable, esiEmployee, esiEmployer } = computeEsiContribution(21_001);
    expect(isApplicable).toBe(false);
    expect(esiEmployee).toBe(0);
    expect(esiEmployer).toBe(0);
  });

  it('2.7 | LOP 5/26 days → gross components prorated', () => {
    const r = payrollEngine.compute(makeSalaryInput({ lopDays: 5 }));
    const factor = (26 - 5) / 26;
    expect(r.basicPay).toBeCloseTo(50_000 * factor, 0);
    expect(r.lopDeduction).toBeGreaterThan(0);
  });

  it('2.8 | netPay = grossPay − totalDeductions', () => {
    const r = payrollEngine.compute(makeSalaryInput());
    expect(r.netPay).toBeCloseTo(r.grossPay - r.totalDeductions, 0);
    expect(r.netPay).toBeGreaterThan(0);
  });

  it('2.9 | Gratuity: < 5 years → ₹0; 5 years basic ₹30K → correct formula', () => {
    const e = new IndiaPayrollEngine();
    expect(e.computeGratuity(30_000, 4)).toBe(0);
    const expected = Math.round(30_000 * (15 / 26) * 5 * 100) / 100;
    expect(e.computeGratuity(30_000, 5)).toBeCloseTo(expected, 0);
  });

  it('2.10 | F&F leave encashment: 60 days capped at 30 → basic/30 × 30 = basic', () => {
    const e = new IndiaPayrollEngine();
    const ff60 = e.computeFnF({ basic: 60_000, yearsOfService: 6, earnedLeaveBalance: 60 });
    const ff20 = e.computeFnF({ basic: 60_000, yearsOfService: 6, earnedLeaveBalance: 20 });
    expect(ff60.earnedLeaveEncashment).toBe(60_000);
    expect(ff20.earnedLeaveEncashment).toBeCloseTo(40_000, 0);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK 3 — PT MULTI-STATE LOGIC
// ═══════════════════════════════════════════════════════════════════════════════

describe('BLOCK 3 — PT Multi-State Logic (pf-esi.engine.ts)', () => {

  it('3.1 | KA: gross ₹14,999 → ₹0 PT (below ₹15K threshold)', () => {
    expect(computeMonthlyPt(14_999, 'KA', 5)).toBe(0);
  });

  it('3.2 | KA: gross ₹20,000 → ₹200/month', () => {
    expect(computeMonthlyPt(20_000, 'KA', 5)).toBe(200);
  });

  it('3.3 | KA: any gross in April (month=4) → ₹0 (April exemption)', () => {
    expect(computeMonthlyPt(25_000, 'KA', 4)).toBe(0);
  });

  it('3.4 | MH: gross ₹8,000 → ₹175/month (₹7.5K–₹10K slab)', () => {
    expect(computeMonthlyPt(8_000, 'MH', 6)).toBe(175);
  });

  it('3.5 | MH: gross ₹12,000 → ₹200/month (above ₹10K slab)', () => {
    expect(computeMonthlyPt(12_000, 'MH', 6)).toBe(200);
  });

  it('3.6 | MH: gross ₹12,000 in February (month=2) → ₹300 (Feb special rule)', () => {
    expect(computeMonthlyPt(12_000, 'MH', 2)).toBe(300);
  });

  it('3.7 | WB: ₹12,000 → ₹110; ₹20,000 → ₹130 (progressive slabs)', () => {
    expect(computeMonthlyPt(12_000, 'WB', 5)).toBe(110);
    expect(computeMonthlyPt(20_000, 'WB', 5)).toBe(130);
  });

  it('3.8 | WB: gross ₹42,000 → ₹200/month (top slab above ₹40K)', () => {
    expect(computeMonthlyPt(42_000, 'WB', 5)).toBe(200);
  });

  it('3.9 | TN: ₹25,000 → ₹135; ₹35,000 → ₹315 (granular TN slabs)', () => {
    expect(computeMonthlyPt(25_000, 'TN', 5)).toBe(135);
    expect(computeMonthlyPt(35_000, 'TN', 5)).toBe(315);
  });

  it('3.10 | GJ: any gross → ₹0 (Gujarat has no PT)', () => {
    expect(computeMonthlyPt(1_00_000, 'GJ', 5)).toBe(0);
  });

  it('3.11 | DL: any gross → ₹0 (Delhi has no PT)', () => {
    expect(computeMonthlyPt(1_00_000, 'DL', 5)).toBe(0);
  });

  it('3.12 | Unknown state code → ₹0 (graceful fallback, no crash)', () => {
    expect(computeMonthlyPt(50_000, 'XX', 5)).toBe(0);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK 4 — PF ECR ASSEMBLY
// ═══════════════════════════════════════════════════════════════════════════════

describe('BLOCK 4 — PF ECR Assembly (pf-esi.engine.ts)', () => {

  it('4.1 | EPF employee: 12% of pfWages (no ceiling applied inside this fn)', () => {
    expect(computeEpfContributionEmployee(10_000)).toBe(1_200);
    expect(computeEpfContributionEmployee(15_000)).toBe(1_800);
  });

  it('4.2 | EPS employer: 8.33% of pfWages, max ₹1,250/month', () => {
    const eps10k = Math.min(Math.round(10_000 * 0.0833), EPS_MAX_MONTHLY);
    expect(computeEpsContribution(10_000)).toBe(eps10k);
    expect(computeEpsContribution(15_000)).toBe(EPS_MAX_MONTHLY);
  });

  it('4.3 | EPS cap: PF wages from ₹40K basic → ceiling applied, EPS = ₹1,250', () => {
    const pfWages = computePfWages(40_000); // = 15,000
    expect(pfWages).toBe(15_000);
    expect(computeEpsContribution(pfWages)).toBe(EPS_MAX_MONTHLY);
  });

  it('4.4 | EPF employer: 3.67% of pfWages', () => {
    expect(computeEpfContributionEmployer(15_000)).toBe(Math.round(15_000 * 0.0367));
  });

  it('4.5 | EDLI: 0.5% of min(edliWages, ₹15,000)', () => {
    expect(computeEdliContribution(15_000)).toBe(75);
    expect(computeEdliContribution(20_000)).toBe(75);  // ceiling
    expect(computeEdliContribution(10_000)).toBe(50);
  });

  it('4.6 | Admin charge: max(0.5% of total PF wages, ₹500 minimum)', () => {
    expect(computeAdminCharge(5_000, 1)).toBe(500);          // floor applied
    expect(computeAdminCharge(2_00_000, 10)).toBe(Math.round(2_00_000 * 0.005)); // = 1000
  });

  it('4.7 | ECR grandTotalPayable = sum of all contribution components', () => {
    const ecr = assembleEcr(EMPLOYER, 2024, 5, [BASE_PAYSLIP]);
    const m = ecr.members[0]!;
    const manual = r2(
      m.epfContributionEmployee + m.epfContributionEmployer +
      m.epsContribution + m.edliContribution +
      ecr.totals.totalAdminCharge + m.vpfContribution
    );
    expect(ecr.totals.grandTotalPayable).toBeCloseTo(manual, 1);
  });

  it('4.8 | VPF: captured in ECR totals and flagged on member', () => {
    const withVpf = { ...BASE_PAYSLIP, vpfContribution: 5_000 };
    const ecr = assembleEcr(EMPLOYER, 2024, 5, [withVpf]);
    expect(ecr.members[0]!.isVoluntaryHigherContribution).toBe(true);
    expect(ecr.members[0]!.vpfContribution).toBe(5_000);
    expect(ecr.totals.totalVpfContribution).toBe(5_000);
  });

  it('4.9 | ECR checksumHash changes when member data changes (below-ceiling change)', () => {
    // Both wages must be BELOW the ₹15K PF ceiling to get different contribution totals
    const low  = assembleEcr(EMPLOYER, 2024, 5, [{ ...BASE_PAYSLIP, basicWages: 8_000 }]);
    const high = assembleEcr(EMPLOYER, 2024, 5, [{ ...BASE_PAYSLIP, basicWages: 12_000 }]);
    expect(low.checksumHash).not.toBe(high.checksumHash);
  });

  it('4.10 | getWageMonth: month=5 year=2024 → "05/2024"', () => {
    expect(getWageMonth(2024, 5)).toBe('05/2024');
    expect(getWageMonth(2024, 12)).toBe('12/2024');
    expect(getWageMonth(2024, 1)).toBe('01/2024');
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK 5 — ESI COMPUTATION
// ═══════════════════════════════════════════════════════════════════════════════

describe('BLOCK 5 — ESI Computation (pf-esi.engine.ts)', () => {

  it('5.1 | ESI employee: 0.75% of gross wages (rounded to integer)', () => {
    const { esiEmployee } = computeEsiContribution(20_000);
    expect(esiEmployee).toBe(Math.round(20_000 * 0.0075));  // 150
  });

  it('5.2 | ESI employer: 3.25% of gross wages (rounded to integer)', () => {
    const { esiEmployer } = computeEsiContribution(20_000);
    expect(esiEmployer).toBe(Math.round(20_000 * 0.0325));  // 650
  });

  it('5.3 | ESI: gross exactly ₹21,000 → applicable', () => {
    const { isApplicable } = computeEsiContribution(21_000);
    expect(isApplicable).toBe(true);
  });

  it('5.4 | ESI: gross ₹21,001 → NOT applicable', () => {
    const { isApplicable, esiEmployee, esiEmployer } = computeEsiContribution(21_001);
    expect(isApplicable).toBe(false);
    expect(esiEmployee).toBe(0);
    expect(esiEmployer).toBe(0);
  });

  it('5.5 | ESI assembly: employees with gross > ₹21K excluded', () => {
    const emps: MonthlyPayslipInput[] = [
      { ...BASE_PAYSLIP, employeeId: 'e1', grossWages: 15_000, basicWages: 8_000, isEsiApplicable: true },
      { ...BASE_PAYSLIP, employeeId: 'e2', grossWages: 90_000, basicWages: 50_000, isEsiApplicable: false },
    ];
    const esiRec = assembleEsiContribution(EMPLOYER, 2024, 5, emps);
    expect(esiRec.members).toHaveLength(1);
    expect(esiRec.members[0]!.employeeId).toBe('e1');
  });

  it('5.6 | ESI totals: totalEsiPayable = employee + employer contributions', () => {
    const emps: MonthlyPayslipInput[] = [
      { ...BASE_PAYSLIP, employeeId: 'e1', grossWages: 18_000, basicWages: 9_000, isEsiApplicable: true },
    ];
    const esiRec = assembleEsiContribution(EMPLOYER, 2024, 5, emps);
    const m = esiRec.members[0]!;
    expect(esiRec.totals.totalEsiPayable).toBe(r2(m.esiEmployee + m.esiEmployer));
  });

  it('5.7 | ESI contribution period May 2024 → "April 2024 – September 2024"', () => {
    const r = assembleEsiContribution(EMPLOYER, 2024, 5, []);
    expect(r.contributionPeriod).toBe('April 2024 – September 2024');
  });

  it('5.8 | ESI contribution period Nov 2024 → "October 2024 – March 2025"', () => {
    const r = assembleEsiContribution(EMPLOYER, 2024, 11, []);
    expect(r.contributionPeriod).toBe('October 2024 – March 2025');
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK 6 — 24Q RETURN VALIDATION
// ═══════════════════════════════════════════════════════════════════════════════

describe('BLOCK 6 — 24Q Return Validation (return.engine.ts)', () => {

  it('6.1 | TAN validation: "BANG12345C" → valid', () => {
    expect(validateTAN('BANG12345C')).toBe(true);
  });

  it('6.2 | TAN validation: "1234ABCDE5" → invalid', () => {
    expect(validateTAN('1234ABCDE5')).toBe(false);
  });

  it('6.3 | PAN validation: "ABCPM1234A" → valid', () => {
    expect(validatePAN('ABCPM1234A')).toBe(true);
  });

  it('6.4 | PAN "APPLIED" → accepted (pending PAN)', () => {
    expect(validatePAN('APPLIED')).toBe(true);
    expect(validatePAN('PANNOTAVBL')).toBe(true);
  });

  it('6.5 | BSR code: 7 digits → valid; 6 or 8 → invalid', () => {
    expect(validateBSRCode('1234567')).toBe(true);
    expect(validateBSRCode('123456')).toBe(false);
    expect(validateBSRCode('12345678')).toBe(false);
    expect(validateBSRCode('ABCDEFG')).toBe(false);
  });

  it('6.6 | Challan-TDS variance ₹1 → warning only (not blocking)', () => {
    const { isValid, blockingErrors, warnings } = validateReturn(
      makeValidReturn({ challans: [makeChallan({ totalAmountDeposited: 50_001 })] })
    );
    expect(isValid).toBe(true);
    const hasBlockingMismatch = blockingErrors.some((e: any) => e.code === 'CHALLAN_TDS_MISMATCH');
    expect(hasBlockingMismatch).toBe(false);
    const hasWarnRounding = warnings.some((w: any) => w.code === 'CHALLAN_ROUNDING_DIFF');
    expect(hasWarnRounding).toBe(true);
  });

  it('6.7 | Challan-TDS variance > ₹1 → CHALLAN_TDS_MISMATCH blocking error', () => {
    const { isValid, blockingErrors } = validateReturn(
      makeValidReturn({ challans: [makeChallan({ totalAmountDeposited: 55_000 })] })
    );
    expect(isValid).toBe(false);
    const hasMismatch = blockingErrors.some((e: any) => e.code === 'CHALLAN_TDS_MISMATCH');
    expect(hasMismatch).toBe(true);
  });

  it('6.8 | No challans → NO_CHALLANS blocking error', () => {
    const { isValid, blockingErrors } = validateReturn(makeValidReturn({ challans: [] }));
    expect(isValid).toBe(false);
    const hasNoChallans = blockingErrors.some((e: any) => e.code === 'NO_CHALLANS');
    expect(hasNoChallans).toBe(true);
  });

  it('6.9 | Quarter month mapping: Apr→Q1, Jul→Q2, Oct→Q3, Jan→Q4', () => {
    expect(getQuarterForMonth(4)).toBe('Q1');
    expect(getQuarterForMonth(6)).toBe('Q1');
    expect(getQuarterForMonth(7)).toBe('Q2');
    expect(getQuarterForMonth(9)).toBe('Q2');
    expect(getQuarterForMonth(10)).toBe('Q3');
    expect(getQuarterForMonth(12)).toBe('Q3');
    expect(getQuarterForMonth(1)).toBe('Q4');
    expect(getQuarterForMonth(3)).toBe('Q4');
  });

  it('6.10 | CIN = BSR(7) + DDMMYYYY + Serial(5)', () => {
    const c = makeChallan({ bsrCode: '1234567', challanDate: '01/04/2024', challanSerialNumber: '1' });
    expect(getCIN(c)).toBe('12345670104202400001');
  });

  it('6.11 | Q4: employee TDS vs tax liability diff > ₹100 → warning', () => {
    const { warnings } = validateReturn(makeValidReturn({
      quarter: 'Q4' as const,
      deductees: [makeDeductee({ totalTdsDeducted: 40_000, netTaxPayable: 55_005 })],
      challans: [makeChallan({ totalAmountDeposited: 40_000, tdsAmount: 40_000, quarter: 'Q4' as const })],
    }));
    const hasMismatch = warnings.some((w: any) => w.code === 'EMP_TDS_TAX_MISMATCH');
    expect(hasMismatch).toBe(true);
  });

  it('6.12 | Assessment year: "2024-25" → "2025-26"', () => {
    expect(getAssessmentYear('2024-25')).toBe('2025-26');
    expect(getAssessmentYear('2023-24')).toBe('2024-25');
  });

  it('6.13 | assembleAnnexureI throws for Q4', () => {
    const fn = () => assembleAnnexureI({
      quarter: 'Q4' as any,
      financialYear: FY,
      deductor: DEDUCTOR,
      challans: [makeChallan()],
      deductees: [makeDeductee()],
    });
    expect(fn).toThrow();
  });

  it('6.14 | Employees with APPLIED PAN → warning, return still valid', () => {
    const { isValid, warnings } = validateReturn(
      makeValidReturn({ deductees: [makeDeductee({ pan: 'APPLIED' })] })
    );
    expect(isValid).toBe(true);
    const hasWarn = warnings.some((w: any) => w.code === 'EMPLOYEES_WITHOUT_PAN');
    expect(hasWarn).toBe(true);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK 7 — FORM 16 INTEGRITY
// ═══════════════════════════════════════════════════════════════════════════════

describe('BLOCK 7 — Form 16 Integrity (form16.engine.ts)', () => {

  it('7.1 | f16AY: "2024-25" → "2025-26"', () => {
    expect(f16AY('2024-25')).toBe('2025-26');
  });

  it('7.2 | fyToDateRange: "2024-25" → "01-Apr-2024" to "31-Mar-2025"', () => {
    const range = fyToDateRange('2024-25');
    // Engine returns "01-Apr-2024" format (not "01/04/2024")
    expect(range.from).toContain('2024');
    expect(range.to).toContain('2025');
  });

  it('7.3 | aggregateQuarterlyTds: 12 payslips → 4 quarters, Q1=₹15K TDS', () => {
    const payslips: MonthlyPayslipSummary[] = [4,5,6,7,8,9,10,11,12,1,2,3].map(m => ({
      period: `${m >= 4 ? '2024' : '2025'}-${String(m).padStart(2,'0')}`,
      month: m,
      year: m >= 4 ? 2024 : 2025,
      grossPay: 95_000,
      tdsDeducted: 5_000,
      pfEmployee: 1_800,
      professionalTax: 200,
    }));
    const quarters = aggregateQuarterlyTds(payslips);
    expect(quarters).toHaveLength(4);
    const q1 = quarters.find((q: any) => q.quarter === 'Q1');
    expect(q1?.tdsDeducted).toBe(15_000);  // Apr+May+Jun 3 × ₹5K
  });

  it('7.4 | validateForm16Input: invalid TAN → blocking INVALID_TAN error', () => {
    const input = makeF16Input();
    input.employer = { ...input.employer, tan: 'INVALID' };
    const r = validateForm16Input(input);
    expect(r.isValid).toBe(false);
    const hasTanErr = r.blockingErrors.some((e: any) => e.code === 'INVALID_TAN');
    expect(hasTanErr).toBe(true);
  });

  it('7.5 | validateForm16Input: missing employee PAN → blocking error', () => {
    const input = makeF16Input();
    input.employee = { ...input.employee, pan: '' };
    const r = validateForm16Input(input);
    expect(r.isValid).toBe(false);
    expect(r.blockingErrors.some((e: any) => e.code.includes('PAN'))).toBe(true);
  });

  it('7.6 | assembleForm16: Part A contains 4 quarterly entries with correct total TDS', () => {
    const f16 = assembleForm16(makeF16Input(), 'F16-202425-A001-0001');
    expect(f16.partA.quarterlyTds).toHaveLength(4);
    const total = f16.partA.quarterlyTds.reduce((s: number, q: any) => s + q.tdsDeducted, 0);
    expect(total).toBe(60_000);  // 12 months × ₹5K
  });

  it('7.7 | assembleForm16: Part B totalTaxableIncome derived from tdsProjection', () => {
    const f16 = assembleForm16(makeF16Input(), 'F16-202425-A001-0001');
    expect(f16.partB).toBeDefined();
    // TaxComputation uses totalTaxableIncome (not taxableIncome)
    // tdsProjection.taxableIncome = ₹10,65,000
    expect(f16.partB.taxComputation.totalTaxableIncome).toBeGreaterThan(0);
    expect(f16.partB.taxComputation.totalTaxableIncome).toBe(10_65_000);
  });

  it('7.8 | computeChecksum: different inputs produce different hashes', () => {
    const h1 = computeChecksum(JSON.stringify({ tax: 58_500 }));
    const h2 = computeChecksum(JSON.stringify({ tax: 58_501 }));
    expect(h1).not.toBe(h2);
  });

  it('7.9 | generateCertificateNumber produces recognizable format with FY embedded', () => {
    const cert = generateCertificateNumber('tenant-001', 'A001', FY, 1);
    expect(cert).toContain('202425');  // FY without dashes
    expect(cert).toContain('A001');
  });

  it('7.10 | buildDashboardEntry: isLocked=true → status "locked"', () => {
    const payslips: MonthlyPayslipSummary[] = [{ calendarMonth: 4, calendarYear: 2024, grossPay: 95_000, tdsDeducted: 5_000, pfEmployee: 1_800, esiEmployee: 0, professionalTax: 200, netPay: 88_000 }];
    const entry = buildDashboardEntry(
      'emp-001', 'Arjun Mehta', 'A001', 'ABCPM1234A',
      payslips,
      { totalTaxLiability: 60_000, regimeType: 'new' },
      { generatedAt: new Date(), isLocked: true }
    );
    expect(entry.status).toBe('locked');
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK 8 — PAYROLL LOCK LIFECYCLE (Computational invariants)
// ═══════════════════════════════════════════════════════════════════════════════

describe('BLOCK 8 — Payroll Lock Lifecycle (computational invariants)', () => {

  it('8.1 | Engine is deterministic: same input → identical output', () => {
    const i = makeSalaryInput();
    const r1 = payrollEngine.compute(i);
    const r2 = payrollEngine.compute(i);
    expect(r1.grossPay).toBe(r2.grossPay);
    expect(r1.netPay).toBe(r2.netPay);
    expect(r1.tdsDeducted).toBe(r2.tdsDeducted);
  });

  it('8.2 | CTC = gross + employer PF + EPS + EDLI admin + employer ESI', () => {
    const r = payrollEngine.compute(makeSalaryInput());
    const ctc = r.grossPay + r.pfEmployer + r.pfEps + r.pfAdminCharge + r.esiEmployer;
    expect(r.ctcMonthly).toBeCloseTo(ctc, 0);
  });

  it('8.3 | totalDeductions = pfEmployee + esiEmployee + PT + TDS', () => {
    const r = payrollEngine.compute(makeSalaryInput());
    const manual = r.pfEmployee + r.esiEmployee + r.professionalTax + r.tdsDeducted;
    expect(r.totalDeductions).toBeCloseTo(manual, 0);
  });

  it('8.4 | Zero LOP: grossPay = sum of salary components exactly', () => {
    const ss = makeSalaryInput().salaryStructure;
    const r = payrollEngine.compute(makeSalaryInput({ lopDays: 0 }));
    const expected = ss.basic + ss.hra + ss.specialAllowance + ss.lta + ss.medicalAllowance + ss.otherAllowances;
    expect(r.grossPay).toBeCloseTo(expected, 0);
  });

  it('8.5 | Component breakdown includes all statutory deductions (high-salary scenario)', () => {
    // Use a salary high enough to generate non-zero TDS even with a single-month projection
    const r = payrollEngine.compute({
      employeeId: 'e1', month: 1, year: 2025,  // April=1 → full-year projection
      salaryStructure: { basic: 1_50_000, hra: 60_000, specialAllowance: 60_000, lta: 0, medicalAllowance: 0, otherAllowances: 0 },
      stateCode: 'KA', pfOptIn: true, taxRegime: 'new',
    });
    const statutory = r.components.filter((c: any) => c.type === 'deduction' && c.isStatutory);
    const names = statutory.map((c: any) => c.name);
    expect(names.some((n: string) => n.includes('Provident Fund'))).toBe(true);
    expect(names.some((n: string) => n.includes('TDS'))).toBe(true);
    expect(names.some((n: string) => n.includes('Professional Tax'))).toBe(true);
  });

  it('8.6 | netPay > 0 for standard salary with no extreme LOP', () => {
    const r = payrollEngine.compute(makeSalaryInput());
    expect(r.netPay).toBeGreaterThan(0);
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK 9 — ARREARS / SECTION 89 RELIEF
// ═══════════════════════════════════════════════════════════════════════════════

describe('BLOCK 9 — Arrears & Section 89 Relief (arrears.engine.ts)', () => {

  it('9.1 | Month-wise arrear = (new gross − old gross) per back-dated month', () => {
    const r = processRevisionAndArrears(makeRevisionInput());
    // Monthly diff = ₹1,14,000 − ₹95,000 = ₹19,000
    // 6 months backdated (Apr–Sep, announced in Oct)
    expect(r.totalArrearAmount).toBeCloseTo(6 * 19_000, -2);
    r.monthwiseArrears.forEach((m: any) => {
      expect(m.arrearAmount).toBeCloseTo(19_000, 0);
    });
  });

  it('9.2 | arrearsPerFy: Record<fy, amount> with non-zero FY entries', () => {
    const r = processRevisionAndArrears(makeRevisionInput());
    const entries = Object.entries(r.arrearsPerFy);
    expect(entries.length).toBeGreaterThanOrEqual(1);
    const totalFromRecord = entries.reduce((s: number, [, v]) => s + (v as number), 0);
    expect(totalFromRecord).toBeCloseTo(r.totalArrearAmount, 0);
  });

  it('9.3 | Section 89 relief: defined even without prior FY data', () => {
    const r = processRevisionAndArrears(makeRevisionInput({ priorFyIncomesAndTax: [] }));
    // Engine must not throw; relief may be null or a Section89Relief object
    expect(r.totalArrearAmount).toBeGreaterThan(0);
  });

  it('9.4 | Section 89 with prior FY data: produces relief object', () => {
    const r = processRevisionAndArrears(makeRevisionInput({
      priorFyIncomesAndTax: [
        { financialYear: '2023-24', taxableIncome: 8_00_000, taxActuallyPaid: 40_000 },
      ],
    }));
    // When prior FY data is provided, section89Relief must be defined
    expect(r.section89Relief).not.toBe(undefined);
  });

  it('9.5 | computeRevisedTdsSchedule: revised monthly TDS = (liability − relief − paid) / months', () => {
    const s = computeRevisedTdsSchedule({
      employeeId: 'emp-001',
      financialYear: FY,
      totalAnnualTaxLiability: 60_000,
      section89ReliefAmount: 10_000,
      alreadyDeductedTds: 20_000,
      remainingMonths: 6,
      startMonth: 10,
      startYear: 2024,
    });
    // (60K − 10K − 20K) / 6 = 5,000
    expect(s.revisedMonthlyTds).toBeCloseTo(5_000, 0);
    expect(s.remainingMonths).toBe(6);
    expect(s.schedule).toHaveLength(6);   // engine uses .schedule (not .monthlySchedule)
  });

  it('9.6 | arrearsPerFy sum = totalArrearAmount', () => {
    const r = processRevisionAndArrears(makeRevisionInput());
    const sumFromRecord = Object.values(r.arrearsPerFy).reduce((s: number, v) => s + (v as number), 0);
    expect(sumFromRecord).toBeCloseTo(r.totalArrearAmount, 0);
  });

  it('9.7 | validateRevisionInput: newMonthlyGross < oldMonthlyGross → invalid or zero arrear', () => {
    const rev = makeRevisionInput({
      newMonthlyGross: 80_000,
      newMonthlyBasic: 40_000,
      newMonthlyHRA: 16_000,
      newMonthlySpecialAllowance: 18_000,
      newMonthlyOtherAllowances: 6_000,
    });
    const v = validateRevisionInput(rev);
    if (!v.isValid) {
      expect(v.blockingErrors.length).toBeGreaterThan(0);
    } else {
      const r = processRevisionAndArrears(rev);
      expect(r.totalArrearAmount).toBeLessThanOrEqual(0);
    }
  });

  it('9.8 | HISTORICAL_FY_CONFIGS has ≥ 3 prior FY configurations', () => {
    const keys = Object.keys(HISTORICAL_FY_CONFIGS);
    expect(keys.length).toBeGreaterThanOrEqual(3);
  });
});

// ─── Final summary ────────────────────────────────────────────────────────────

console.log('\n══════════════════════════════════════════════════════════════');
console.log(`  RESULTS: ${_passed} passed, ${_failed} failed, ${_total} total`);
console.log('══════════════════════════════════════════════════════════════');

if (_failures.length > 0) {
  console.log('\n  FAILURES:');
  _failures.forEach(f => console.log(`\n  ${f}`));
}

if (_failed > 0) process.exit(1);
