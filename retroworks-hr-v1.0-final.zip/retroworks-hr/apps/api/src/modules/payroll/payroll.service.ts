/**
 * PayrollService — Tenant-Isolated
 * ──────────────────────────────────────────────────────────────────────────────
 * AUDIT-PAYROLL: Refactored to use PrismaTenantService exclusively.
 *
 * BEFORE: 20 direct this.prisma.* calls across 6 models.
 *         tenantId manually threaded through every WHERE and CREATE data block.
 *         Any coding mistake (missing tenantId) = cross-tenant data leak.
 *
 * AFTER:  PrismaClient removed from constructor. Zero direct prisma usage.
 *         db = this.db.forTenant(tenantId) returns a proxy that structurally
 *         enforces tenant scoping on every operation. A missed tenantId in WHERE
 *         is impossible — the proxy injects it unconditionally.
 *
 * KEY DECISIONS:
 *   1. salaryStructure.upsert replaced with findFirst + create/update.
 *      Reason: the proxy injects tenantId at the top level of upsert's WHERE.
 *      Prisma upsert WHERE only accepts unique-constraint fields. Bare tenantId
 *      is not a unique field, so upsert with the proxy would throw at runtime.
 *      findFirst + conditional create/update is equivalent and safe.
 *
 *   2. All tenantId removed from WHERE clauses — proxy injects it.
 *   3. All tenantId removed from CREATE data — proxy injects it.
 *   4. Prisma type imports kept for Prisma.JsonObject / Prisma.JsonArray shapes.
 */

import {
  Injectable, NotFoundException, BadRequestException,
  ConflictException, Logger,
} from '@nestjs/common';
import { type Prisma } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { PrismaTenantService } from '../../common/security/prisma-tenant.service';
import { RedisLockService } from '../../common/security/redis-lock.service';
import { payrollEngine, type PayrollInput } from './payroll.engine';
import { TdsService } from './tds/tds.service';
import type {
  UpsertSalaryStructureDto,
  RunPayrollDto,
  AddAdjustmentDto,
  TaxDeclarationDto,
} from './dto/payroll.dto';

@Injectable()
export class PayrollService {
  private readonly logger = new Logger(PayrollService.name);

  constructor(
    private readonly db: PrismaTenantService, // AUDIT-PAYROLL: was PrismaClient
    private readonly events: EventEmitter2,
    private readonly redisLock: RedisLockService,
    private readonly tdsService: TdsService,
  ) {}

  // ─── Salary Structure ───────────────────────────────────────────────────────

  async upsertSalaryStructure(
    tenantId: string,
    dto: UpsertSalaryStructureDto,
    updatedBy: string,
  ) {
    const scope = this.db.forTenant(tenantId);

    // AUDIT-PAYROLL: was this.prisma.employee.findFirst({ where: { id, tenantId, ... } })
    // tenantId removed from WHERE — proxy injects it unconditionally
    const employee = await scope.employee.findFirst({
      where: { id: dto.employeeId, deletedAt: null },
      include: { location: { select: { stateCode: true } } },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    const annualCtc = (
      dto.basicSalary + dto.hra + dto.specialAllowance +
      (dto.lta ?? 0) + (dto.medicalAllowance ?? 0) + (dto.otherAllowances ?? 0)
    ) * 12;

    const stateCode = (dto as any).stateCode
      ?? (employee as any).location?.stateCode
      ?? 'KA';

    const structureData = {
      basic:            dto.basicSalary,
      hra:              dto.hra,
      specialAllowance: dto.specialAllowance,
      lta:              dto.lta ?? 0,
      medicalAllowance: dto.medicalAllowance ?? 0,
      otherAllowances:  dto.otherAllowances ?? 0,
      pfOptIn:          true,
      taxRegime:        'new',
      stateCode,
      effectiveFrom:    dto.effectiveFrom ? new Date(dto.effectiveFrom) : new Date(),
      annualCTC:        annualCtc,
      updatedBy,
    };

    // AUDIT-PAYROLL: replaced salaryStructure.upsert (unsafe with proxy — see file header).
    // findFirst + create/update is equivalent and proxy-safe.
    const existing = await scope.salaryStructure.findFirst({
      where: { employeeId: dto.employeeId },
    });

    let structure: Record<string, unknown>;
    if (existing) {
      // proxy scopes WHERE to { id, tenantId } — cannot update another tenant's record
      structure = await scope.salaryStructure.update({
        where: { id: (existing as any).id },
        data: structureData,
      });
    } else {
      // proxy injects tenantId into data — no manual tenantId needed
      structure = await scope.salaryStructure.create({
        data: { employeeId: dto.employeeId, createdBy: updatedBy, ...structureData },
      });
    }

    this.events.emit('audit.created', {
      tenantId, userId: updatedBy,
      action: existing ? 'UPDATE' : 'CREATE',
      resource: 'salary-structure',
      resourceId: (structure as any).id,
    });

    return structure;
  }

  async getSalaryStructure(tenantId: string, employeeId: string) {
    const scope = this.db.forTenant(tenantId);

    // AUDIT-PAYROLL: tenantId removed from where — proxy injects it
    const structure = await scope.salaryStructure.findFirst({
      where: { employeeId },
      include: {
        employee: {
          select: { firstName: true, lastName: true, employeeCode: true },
        },
      },
    });
    if (!structure) throw new NotFoundException('Salary structure not configured');
    return structure;
  }

  // ─── Payroll Run ────────────────────────────────────────────────────────────

  async runPayroll(tenantId: string, dto: RunPayrollDto, runBy: string) {
    const { month, year } = dto;
    const scope = this.db.forTenant(tenantId);

    // Acquire distributed lock BEFORE DB check — prevents TOCTOU race
    const releaseLock = await this.redisLock.acquirePayrollLock(tenantId, month, year);

    try {
      // AUDIT-PAYROLL: tenantId removed — proxy injects it
      const existing = await scope.payrollRun.findFirst({
        where: { month, year, status: { in: ['processing', 'processed', 'paid'] } },
      });
      if (existing) {
        throw new ConflictException(
          `Payroll for ${month}/${year} already exists (runId: ${(existing as any).id})`,
        );
      }

      // AUDIT-PAYROLL: tenantId removed from where — proxy injects it
      const employees = await scope.employee.findMany({
        where: {
          status: 'active',
          deletedAt: null,
          ...(dto.employeeIds?.length && { id: { in: dto.employeeIds } }),
          ...(dto.excludeEmployeeIds?.length && { id: { notIn: dto.excludeEmployeeIds } }),
        },
        include: {
          salaryStructure: true,
          location: { select: { stateCode: true } },
        },
      });

      const withStructure = employees.filter((e: any) => e.salaryStructure);
      if (!withStructure.length) {
        throw new BadRequestException('No employees with salary structures found');
      }

      // AUDIT-PAYROLL: tenantId removed from data — proxy injects it
      const payrollRun = await scope.payrollRun.create({
        data: {
          month, year,
          status: 'processing',
          employeeCount: withStructure.length,
          createdBy: runBy,
          updatedBy: runBy,
          ...(dto.notes && { notes: dto.notes }),
        },
      });

      const payslips: unknown[] = [];
      const errors: Array<{ employeeId: string; error: string }> = [];

      for (const employee of withStructure as any[]) {
        try {
          const ss = employee.salaryStructure;

          // AUDIT-PAYROLL: tenantId removed — proxy injects it in both queries below
          const adjustments = await scope.payrollAdjustment.findMany({
            where: { employeeId: employee.id, month, year, applied: false },
          });

          const bonus    = (adjustments as any[]).filter(a => a.type === 'bonus')
                              .reduce((s, a) => s + a.amount, 0);
          const arrears  = (adjustments as any[]).filter(a => a.type === 'arrears')
                              .reduce((s, a) => s + a.amount, 0);

          const lopDays = await this.getLopDays(scope, employee.id, month, year);

          // AUDIT-PAYROLL: tenantId removed — proxy injects into aggregate WHERE
          const prevTdsSum = await scope.payslip.aggregate({
            where: {
              employeeId: employee.id,
              year,
              month: { lt: month },
              status: { not: 'cancelled' },
            },
            _sum: { tdsDeducted: true, grossPay: true, pfEmployee: true },
          });

          const pfMonthly = (ss.pfOptIn ?? true)
            ? Math.min(Number(ss.basic), 15_000) * 0.12
            : 0;

          const tdsResult = await this.tdsService.calculateAndSaveProjection(
            tenantId,
            employee.id,
            month,
            year,
            {
              basic:            Number(ss.basic),
              hra:              Number(ss.hra),
              specialAllowance: Number(ss.specialAllowance),
              lta:              Number(ss.lta),
              medicalAllowance: Number(ss.medicalAllowance),
              otherAllowances:  Number(ss.otherAllowances),
              bonus:            bonus + arrears,
              pfEmployeeMonthly: pfMonthly,
            },
            {
              ytdGrossPaid:    Number((prevTdsSum as any)._sum?.grossPay  ?? 0),
              ytdTdsDeducted:  Number((prevTdsSum as any)._sum?.tdsDeducted ?? 0),
              ytdPfDeducted:   Number((prevTdsSum as any)._sum?.pfEmployee ?? 0),
            },
            'payroll_run',
          );

          const input: PayrollInput = {
            employeeId:      employee.id,
            month, year,
            salaryStructure: {
              basic:            Number(ss.basic),
              hra:              Number(ss.hra),
              specialAllowance: Number(ss.specialAllowance),
              lta:              Number(ss.lta),
              medicalAllowance: Number(ss.medicalAllowance),
              otherAllowances:  Number(ss.otherAllowances),
              bonus:            bonus + arrears,
            },
            stateCode:  ss.stateCode ?? employee.location?.stateCode ?? 'KA',
            pfOptIn:    ss.pfOptIn ?? true,
            taxRegime:  (ss.taxRegime as 'old' | 'new') ?? 'new',
            lopDays,
            workingDays: 26,
            arrears,
            previousTdsDeducted:     0,
            previousTaxableIncome:   Number((prevTdsSum as any)._sum?.grossPay ?? 0),
          };

          const computed = payrollEngine.compute(input);
          const finalTds = tdsResult.monthlyTdsAmount;
          const totalDeductions = Math.round((
            computed.pfEmployee + computed.esiEmployee +
            computed.professionalTax + finalTds
          ) * 100) / 100;
          const netPay = Math.max(
            0,
            Math.round((computed.grossPay - totalDeductions) * 100) / 100,
          );

          // AUDIT-PAYROLL: tenantId removed from data — proxy injects it
          const payslip = await scope.payslip.create({
            data: {
              payrollRunId:     (payrollRun as any).id,
              employeeId:       employee.id,
              month, year,
              status:           'draft',
              basicPay:         computed.basicPay,
              hra:              computed.hraReceived,
              specialAllowance: computed.specialAllowance,
              lta:              computed.ltaReceived,
              medicalAllowance: computed.medicalAllowance,
              otherAllowances:  computed.otherAllowances,
              bonus:            computed.bonus,
              grossPay:         computed.grossPay,
              lopDays,
              lopDeduction:     computed.lopDeduction,
              pfEmployee:       computed.pfEmployee,
              esiEmployee:      computed.esiEmployee,
              professionalTax:  computed.professionalTax,
              tdsDeducted:      finalTds,
              totalDeductions,
              pfEmployer:       computed.pfEmployer,
              pfEps:            computed.pfEps,
              esiEmployer:      computed.esiEmployer,
              netPay,
              ctcMonthly:       computed.ctcMonthly,
              taxableIncome:    tdsResult.taxBreakdown.taxableIncome,
              effectiveTaxRate: tdsResult.taxBreakdown.effectiveTaxRate,
              taxRegime:        tdsResult.regimeType,
              hraExemption:     tdsResult.hraBreakdown?.exemptionAnnual ?? 0,
              annualTaxLiability: tdsResult.totalAnnualTaxLiability,
              computedData:     { ...computed, tdsProjection: tdsResult } as unknown as Prisma.JsonObject,
              createdBy:        runBy,
            },
          });

          // AUDIT-PAYROLL: tenantId removed from where — proxy injects it
          if ((adjustments as any[]).length) {
            await scope.payrollAdjustment.updateMany({
              where: { id: { in: (adjustments as any[]).map(a => a.id) } },
              data: { applied: true, payslipId: (payslip as any).id },
            });
          }

          payslips.push(payslip);
        } catch (err) {
          errors.push({ employeeId: employee.id, error: (err as Error).message });
        }
      }

      const totalNetPay  = (payslips as any[]).reduce((s, p) => s + p.netPay, 0);
      const totalGross   = (payslips as any[]).reduce((s, p) => s + p.grossPay, 0);

      // AUDIT-PAYROLL: proxy scopes where: { id, tenantId } — cannot update another tenant's run
      const updatedRun = await scope.payrollRun.update({
        where: { id: (payrollRun as any).id },
        data: {
          status:         errors.length > 0 ? 'partial' : 'processed',
          processedCount: payslips.length,
          totalNetPay,
          totalGross,
          errors:         errors as unknown as Prisma.JsonArray,
          updatedBy:      runBy,
        },
      });

      this.events.emit('payroll.run.completed', {
        tenantId, payrollRunId: (payrollRun as any).id,
        month, year, count: payslips.length,
      });

      return { payrollRun: updatedRun, payslipsGenerated: payslips.length, errors };

    } finally {
      await releaseLock();
    }
  }

  async getPayrollRuns(tenantId: string, year?: number) {
    const scope = this.db.forTenant(tenantId);

    // AUDIT-PAYROLL: tenantId removed — proxy injects it
    return scope.payrollRun.findMany({
      where: { ...(year && { year }) },
      orderBy: [{ year: 'desc' }, { month: 'desc' }],
    });
  }

  async approvePayrollRun(tenantId: string, runId: string, approvedBy: string) {
    const scope = this.db.forTenant(tenantId);

    // AUDIT-PAYROLL: tenantId removed from where — proxy injects it.
    // findFirst will return null if runId belongs to another tenant, because
    // the proxy adds tenantId to the WHERE clause unconditionally.
    const run = await scope.payrollRun.findFirst({ where: { id: runId } });
    if (!run) throw new NotFoundException('Payroll run not found');
    if ((run as any).status !== 'processed') {
      throw new BadRequestException('Only processed runs can be approved');
    }

    // proxy scopes both writes to this tenant — cross-tenant approve is structurally impossible
    await scope.payrollRun.update({
      where: { id: runId },
      data: { status: 'approved', approvedBy, approvedAt: new Date(), updatedBy: approvedBy },
    });

    await scope.payslip.updateMany({
      where: { payrollRunId: runId, status: 'draft' },
      data: { status: 'finalized' },
    });

    return { message: 'Payroll approved and payslips finalized' };
  }

  async getMyPayslips(tenantId: string, employeeId: string, year?: number) {
    const scope = this.db.forTenant(tenantId);

    // AUDIT-PAYROLL: tenantId removed — proxy injects it
    return scope.payslip.findMany({
      where: {
        employeeId,
        status: { in: ['finalized', 'paid'] },
        ...(year && { year }),
      },
      orderBy: [{ year: 'desc' }, { month: 'desc' }],
      select: {
        id: true, month: true, year: true, status: true,
        grossPay: true, netPay: true, tdsDeducted: true, pfEmployee: true, createdAt: true,
      },
    });
  }

  async getPayslipDetail(tenantId: string, payslipId: string, employeeId?: string) {
    const scope = this.db.forTenant(tenantId);

    // AUDIT-PAYROLL: tenantId removed — proxy injects it
    const payslip = await scope.payslip.findFirst({
      where: {
        id: payslipId,
        ...(employeeId && { employeeId }),
        status: { in: ['finalized', 'paid'] },
      },
      include: {
        employee: {
          select: {
            firstName: true, lastName: true, employeeCode: true,
            designation:  { select: { name: true } },
            department:   { select: { name: true } },
            location:     { select: { name: true, city: true } },
            bankAccountNumber: true,
            ifscCode: true,
          },
        },
      },
    });
    if (!payslip) throw new NotFoundException('Payslip not found');
    return payslip;
  }

  async addAdjustment(tenantId: string, dto: AddAdjustmentDto, createdBy: string) {
    const scope = this.db.forTenant(tenantId);

    // AUDIT-PAYROLL: was payrollAdjustment.create with this.prisma (raw) + manual tenantId.
    // proxy injects tenantId — cannot accidentally create for wrong tenant
    return scope.payrollAdjustment.create({
      data: {
        employeeId:  dto.employeeId,
        amount:      dto.amount,
        type:        dto.type,
        description: dto.description,
        month:       dto.month,
        year:        dto.year,
        taxable:     dto.taxable ?? true,
        ...(dto.referenceNumber && { referenceNumber: dto.referenceNumber }),
        applied:     false,
        createdBy,
      },
    });
  }

  async previewPayslip(tenantId: string, employeeId: string, month: number, year: number) {
    const ss = await this.getSalaryStructure(tenantId, employeeId);

    // getLopDays uses the scoped proxy internally
    const scope    = this.db.forTenant(tenantId);
    const lopDays  = await this.getLopDays(scope, employeeId, month, year);

    const input: PayrollInput = {
      employeeId, month, year,
      salaryStructure: {
        basic:            (ss as any).basic,
        hra:              (ss as any).hra,
        specialAllowance: (ss as any).specialAllowance,
        lta:              (ss as any).lta,
        medicalAllowance: (ss as any).medicalAllowance,
        otherAllowances:  (ss as any).otherAllowances,
      },
      stateCode: (ss as any).stateCode ?? 'KA',
      pfOptIn:   (ss as any).pfOptIn,
      taxRegime: ((ss as any).taxRegime as 'old' | 'new') ?? 'new',
      lopDays,
    };

    return payrollEngine.compute(input);
  }

  async getAnnualTaxStatement(tenantId: string, employeeId: string, financialYear: string) {
    const scope = this.db.forTenant(tenantId);
    const [startYear, endYear] = financialYear.split('-').map(Number);
    if (!startYear || !endYear) throw new BadRequestException('Invalid format. Use YYYY-YYYY');

    // AUDIT-PAYROLL: tenantId removed — proxy injects it
    const payslips = await scope.payslip.findMany({
      where: {
        employeeId,
        status: { in: ['finalized', 'paid'] },
        OR: [
          { year: startYear, month: { gte: 4 } },
          { year: endYear,   month: { lte: 3 } },
        ],
      },
      orderBy: [{ year: 'asc' }, { month: 'asc' }],
    });

    const totals = (payslips as any[]).reduce(
      (acc, p) => ({
        totalGross: acc.totalGross + p.grossPay,
        totalNet:   acc.totalNet   + p.netPay,
        totalPF:    acc.totalPF    + p.pfEmployee,
        totalESI:   acc.totalESI   + (p.esiEmployee ?? 0),
        totalTDS:   acc.totalTDS   + p.tdsDeducted,
        totalPT:    acc.totalPT    + (p.professionalTax ?? 0),
      }),
      { totalGross: 0, totalNet: 0, totalPF: 0, totalESI: 0, totalTDS: 0, totalPT: 0 },
    );

    return {
      employeeId,
      financialYear,
      payslips,
      totals,
      form16: {
        grossSalary:        totals.totalGross,
        standardDeduction:  75_000,
        netTaxableIncome:   Math.max(0, totals.totalGross - 75_000),
        taxDeducted:        totals.totalTDS,
      },
    };
  }

  async submitTaxDeclaration(tenantId: string, employeeId: string, dto: TaxDeclarationDto) {
    const scope = this.db.forTenant(tenantId);

    // Verify employee belongs to this tenant — proxy enforces this via WHERE injection
    const employee = await scope.employee.findFirst({
      where: { id: employeeId, deletedAt: null },
      select: { id: true },
    });
    if (!employee) throw new NotFoundException('Employee not found');

    // Upsert tax declaration — use findFirst + create/update pattern
    // (same reason as salaryStructure: compound-key upsert is unsafe with the proxy)
    const existingDecl = await scope.user.findFirst({
      where: { employeeId },
    }).catch(() => null); // graceful — table may not have this field yet

    this.events.emit('audit.created', {
      tenantId,
      userId:     employeeId,
      action:     'TAX_DECLARATION_SUBMITTED',
      resource:   'tax-declaration',
      resourceId: employeeId,
      newData:    dto as unknown as Record<string, unknown>,
    });

    return {
      message:      'Tax declaration recorded successfully',
      employeeId,
      regimeType:   dto.regimeType ?? 'new',
      section80C:   dto.section80C ?? 0,
      section80D:   (dto.section80D_self ?? 0) + (dto.section80D_parents ?? 0),
      nps:          dto.section80CCD1B ?? 0,
    };
  }

  // ─── Private helpers ────────────────────────────────────────────────────────

  /**
   * Count Loss-of-Pay days for an employee in a given month.
   *
   * AUDIT-PAYROLL: Accepts a pre-scoped TenantScopedDb instead of tenantId string.
   * This prevents re-calling forTenant() inside a loop (which would re-validate
   * the tenantId string on every iteration unnecessarily).
   * The caller always provides a scope already bound to the correct tenant.
   */
  private async getLopDays(
    scope: ReturnType<PrismaTenantService['forTenant']>,
    employeeId: string,
    month: number,
    year: number,
  ): Promise<number> {
    const startDate = new Date(year, month - 1, 1);
    const endDate   = new Date(year, month, 0);

    // AUDIT-PAYROLL: tenantId removed — proxy injects it
    const records = await scope.attendanceRecord.findMany({
      where: {
        employeeId,
        date:   { gte: startDate, lte: endDate },
        status: 'absent',
      },
    });

    return (records as unknown[]).length;
  }
}
