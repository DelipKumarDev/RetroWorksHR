/**
 * Payroll Module — Wired & Hardened
 * AUDIT-04: Replaced all `dto: any` (3 occurrences) with typed validated DTOs
 * AUDIT-05: Wired sub-modules — Form16, TDS (TdsReturns, PfEsi, Arrears register own routes)
 */

import {
  Controller, Get, Post, Body, Param, Query,
  UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { PayrollService } from './payroll.service';
import { Form16Module } from './form16/form16.module';
import { TdsModule } from './tds/tds.module';
import { ExpressionEngineModule } from './expression-engine/expression-engine.module';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';
import {
  UpsertSalaryStructureDto,
  RunPayrollDto,
  AddAdjustmentDto,
  TaxDeclarationDto,
} from './dto/payroll.dto';

@ApiTags('payroll')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('payroll')
export class PayrollController {
  constructor(private readonly payrollService: PayrollService) {}

  @Post('salary-structures')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Create or update employee salary structure' })
  @HttpCode(HttpStatus.OK)
  // FIXED AUDIT-04: was `dto: any`
  upsertStructure(@Body() dto: UpsertSalaryStructureDto, @CurrentUser() u: JwtPayload) {
    return this.payrollService.upsertSalaryStructure(u.tid, dto, u.sub);
  }

  @Get('salary-structures/:employeeId')
  @Roles('hr-admin', 'super-admin')
  getStructure(@Param('employeeId') id: string, @CurrentUser() u: JwtPayload) {
    return this.payrollService.getSalaryStructure(u.tid, id);
  }

  @Post('runs')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Run payroll for a month/year — acquires distributed Redis lock' })
  @HttpCode(HttpStatus.CREATED)
  // FIXED AUDIT-04: was `dto: any`
  runPayroll(@Body() dto: RunPayrollDto, @CurrentUser() u: JwtPayload) {
    return this.payrollService.runPayroll(u.tid, dto, u.sub);
  }

  @Get('runs')
  @Roles('hr-admin', 'super-admin')
  listRuns(@Query('year') year: string | undefined, @CurrentUser() u: JwtPayload) {
    return this.payrollService.getPayrollRuns(u.tid, year ? parseInt(year) : undefined);
  }

  @Post('runs/:runId/approve')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.OK)
  approveRun(@Param('runId') runId: string, @CurrentUser() u: JwtPayload) {
    return this.payrollService.approvePayrollRun(u.tid, runId, u.sub);
  }

  @Get('payslips/me')
  myPayslips(@Query('year') year: string | undefined, @CurrentUser() u: JwtPayload) {
    return this.payrollService.getMyPayslips(u.tid, u.sub, year ? parseInt(year) : undefined);
  }

  @Get('payslips/me/:payslipId')
  myPayslipDetail(@Param('payslipId') id: string, @CurrentUser() u: JwtPayload) {
    return this.payrollService.getPayslipDetail(u.tid, id, u.sub);
  }

  @Get('payslips/:payslipId')
  @Roles('hr-admin', 'super-admin')
  payslipDetail(@Param('payslipId') id: string, @CurrentUser() u: JwtPayload) {
    return this.payrollService.getPayslipDetail(u.tid, id);
  }

  @Get('preview/:employeeId')
  @Roles('hr-admin', 'super-admin')
  preview(
    @Param('employeeId') id: string,
    @Query('month') m: string,
    @Query('year') y: string,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.payrollService.previewPayslip(u.tid, id, parseInt(m), parseInt(y));
  }

  @Post('adjustments')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.CREATED)
  // FIXED AUDIT-04: was `dto: any`
  addAdjustment(@Body() dto: AddAdjustmentDto, @CurrentUser() u: JwtPayload) {
    return this.payrollService.addAdjustment(u.tid, dto, u.sub);
  }

  @Get('tax-statement/:employeeId')
  taxStatement(
    @Param('employeeId') id: string,
    @Query('fy') fy: string,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.payrollService.getAnnualTaxStatement(u.tid, id === 'me' ? u.sub : id, fy);
  }

  @Post('tax-declarations')
  @ApiOperation({ summary: 'Submit investment declaration for TDS computation' })
  @HttpCode(HttpStatus.OK)
  submitTaxDeclaration(@Body() dto: TaxDeclarationDto, @CurrentUser() u: JwtPayload) {
    return this.payrollService.submitTaxDeclaration(u.tid, u.sub, dto);
  }
}

// AUDIT-05: Sub-modules now properly wired
@Module({
  imports: [
    Form16Module,          // /form16/* routes
    TdsModule,             // /tds/* routes — TdsReturns, PfEsi, Arrears controllers self-register
    ExpressionEngineModule, // /payroll/components/* — Phase 2B formula engine
  ],
  controllers: [PayrollController],
  providers: [PayrollService],
  exports: [PayrollService, ExpressionEngineModule],
})
export class PayrollModule {}
