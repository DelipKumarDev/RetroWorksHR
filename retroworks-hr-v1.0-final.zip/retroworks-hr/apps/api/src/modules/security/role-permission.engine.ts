/**
 * RetroWorks HR — Advanced Role & Menu Permission Engine
 * ═══════════════════════════════════════════════════════════════════════════════
 * Pure TypeScript — no framework dependencies — fully testable.
 *
 * Features:
 *   ▸ Custom role creation with granular permission matrix
 *   ▸ Role cloning (copy role with override)
 *   ▸ Module-level access gates (enable/disable entire modules)
 *   ▸ Menu visibility toggles (per-role menu tree)
 *   ▸ CRUD permissions (create/read/update/delete/export/import/approve)
 *   ▸ Action-level permissions (fine-grained per-action flags)
 *   ▸ Field-level masking (sensitive fields hidden per role)
 *   ▸ Backend enforcement (canAccess / canDoAction / maskFields)
 *   ▸ Role simulation (evaluate permissions as a specific role)
 *   ▸ Temporary elevation with expiry (time-boxed privilege escalation)
 *   ▸ Permission audit logging
 * ═══════════════════════════════════════════════════════════════════════════════
 */

// ─────────────────────────────────────────────────────────────────────────────
// RESOURCE & ACTION REGISTRY
// ─────────────────────────────────────────────────────────────────────────────

export type CrudAction = 'create' | 'read' | 'update' | 'delete' | 'export' | 'import' | 'approve';

export const ALL_MODULES = [
  'core-hr', 'leave', 'attendance', 'payroll', 'payroll-tds',
  'payroll-pf-esi', 'payroll-form16', 'recruitment', 'performance',
  'lnd', 'expense', 'helpdesk', 'reports', 'settings', 'roles',
  'education', 'analytics',
] as const;

export type Module = typeof ALL_MODULES[number];

export interface ResourcePermission {
  resource: string;           // e.g. 'leave:request', 'payroll:payslip'
  module: Module;
  actions: CrudAction[];
  /** ABAC conditions — evaluated at runtime */
  conditions?: PermissionCondition[];
  /** Fields that are masked (hidden/redacted) for this permission entry */
  maskedFields?: string[];
}

export interface PermissionCondition {
  field: string;              // e.g. 'user.departmentId', 'params.employeeId'
  operator: 'eq' | 'neq' | 'in' | 'not-in' | 'own-only';
  value?: unknown;
}

export interface MenuNode {
  id: string;
  label: string;
  icon?: string;
  path?: string;
  module: Module;
  children?: MenuNode[];
  /** If false, hidden from menu even if module is enabled */
  visible: boolean;
  /** Minimum action needed to see this node */
  requiredAction?: CrudAction;
}

// ─────────────────────────────────────────────────────────────────────────────
// ROLE DEFINITION
// ─────────────────────────────────────────────────────────────────────────────

export interface RoleDefinition {
  id: string;
  tenantId: string;
  name: string;
  displayName: string;
  description: string;
  isSystem: boolean;           // System roles cannot be deleted
  isActive: boolean;
  /** Modules this role can access (others are denied at the gate) */
  allowedModules: Module[];
  /** Fine-grained per-resource permissions */
  permissions: ResourcePermission[];
  /** Menu nodes visible to this role */
  menuVisibility: Record<string, boolean>;  // menuNodeId → visible
  /** Sensitive fields that are masked for users of this role */
  globalMaskedFields: string[];
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
}

export interface TemporaryElevation {
  id: string;
  userId: string;
  tenantId: string;
  grantedRoleId: string;
  grantedRoleName: string;
  reason: string;
  grantedBy: string;
  grantedAt: Date;
  expiresAt: Date;
  isRevoked: boolean;
  revokedAt?: Date;
  revokedBy?: string;
  auditToken: string;          // Signed token for tamper-evidence
}

// ─────────────────────────────────────────────────────────────────────────────
// PERMISSION EVALUATION CONTEXT
// ─────────────────────────────────────────────────────────────────────────────

export interface UserPermissionContext {
  userId: string;
  tenantId: string;
  roleIds: string[];
  /** Permanent assigned roles */
  roles: RoleDefinition[];
  /** Active temporary elevations (not expired, not revoked) */
  activeElevations: TemporaryElevation[];
  /**
   * All roles available for elevation lookup.
   * If omitted, falls back to ctx.roles.
   * Provide this when the elevated role is NOT a permanent assigned role.
   */
  allAvailableRoles?: RoleDefinition[];
  /** Runtime context for ABAC evaluation */
  requestContext: {
    params?: Record<string, string>;
    body?: Record<string, unknown>;
    query?: Record<string, string>;
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// PERMISSION AUDIT LOG
// ─────────────────────────────────────────────────────────────────────────────

export interface PermissionAuditEvent {
  id: string;
  tenantId: string;
  userId: string;
  action: 'role_created' | 'role_cloned' | 'role_updated' | 'role_deleted' |
          'permission_granted' | 'permission_revoked' | 'elevation_granted' |
          'elevation_expired' | 'elevation_revoked' | 'access_denied' | 'access_allowed' |
          'field_masked' | 'module_blocked';
  resourceType: string;
  resourceId?: string;
  performedBy: string;
  performedAt: Date;
  metadata: Record<string, unknown>;
  ipAddress?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// SYSTEM ROLE TEMPLATES
// ─────────────────────────────────────────────────────────────────────────────

export function buildSystemRoles(tenantId: string, performedBy: string): RoleDefinition[] {
  const now = new Date();
  const base = (id: string, name: string, displayName: string, desc: string): Omit<RoleDefinition, 'allowedModules' | 'permissions' | 'menuVisibility' | 'globalMaskedFields'> => ({
    id, tenantId, name, displayName, description: desc,
    isSystem: true, isActive: true, createdAt: now, updatedAt: now, createdBy: performedBy,
  });

  const hrRole: RoleDefinition = {
    ...base('sys-hr', 'hr-admin', 'HR Administrator', 'Full HR access including payroll, leave, employee management'),
    allowedModules: ['core-hr', 'leave', 'attendance', 'payroll', 'payroll-tds', 'payroll-pf-esi', 'payroll-form16', 'recruitment', 'lnd', 'reports', 'settings'],
    globalMaskedFields: [],
    permissions: [
      { resource: 'employee', module: 'core-hr', actions: ['create', 'read', 'update', 'delete', 'export', 'import'] },
      { resource: 'leave:request', module: 'leave', actions: ['create', 'read', 'update', 'delete', 'approve'] },
      { resource: 'leave:balance', module: 'leave', actions: ['read', 'update'] },
      { resource: 'leave:year-end', module: 'leave', actions: ['create', 'read', 'approve'] },
      { resource: 'payroll:run', module: 'payroll', actions: ['create', 'read', 'approve'] },
      { resource: 'payroll:payslip', module: 'payroll', actions: ['read', 'export'] },
      { resource: 'payroll:tds', module: 'payroll-tds', actions: ['read', 'update', 'approve'] },
      { resource: 'payroll:form16', module: 'payroll-form16', actions: ['create', 'read', 'approve', 'export'] },
      { resource: 'role', module: 'roles', actions: ['read'] },
    ],
    menuVisibility: {
      'nav-payroll': true, 'nav-payroll-tds': true, 'nav-payroll-pf': true,
      'nav-payroll-form16': true, 'nav-leave': true, 'nav-leave-year-end': true,
      'nav-employees': true, 'nav-reports': true, 'nav-settings': true,
    },
  };

  const financeRole: RoleDefinition = {
    ...base('sys-finance', 'finance', 'Finance Officer', 'Payroll processing and statutory compliance'),
    allowedModules: ['payroll', 'payroll-tds', 'payroll-pf-esi', 'payroll-form16', 'expense', 'reports'],
    globalMaskedFields: ['employee.bankAccountNumber', 'employee.panNumber'],  // masked AFTER own-employee
    permissions: [
      { resource: 'employee', module: 'core-hr', actions: ['read'], maskedFields: ['bankAccountNumber', 'panNumber'] },
      { resource: 'payroll:run', module: 'payroll', actions: ['create', 'read', 'update', 'approve', 'export'] },
      { resource: 'payroll:payslip', module: 'payroll', actions: ['read', 'export'] },
      { resource: 'payroll:tds', module: 'payroll-tds', actions: ['read', 'update', 'approve', 'export'] },
      { resource: 'payroll:pf-ecr', module: 'payroll-pf-esi', actions: ['read', 'export', 'approve'] },
      { resource: 'payroll:esi', module: 'payroll-pf-esi', actions: ['read', 'export', 'approve'] },
      { resource: 'payroll:form16', module: 'payroll-form16', actions: ['create', 'read', 'approve', 'export'] },
      { resource: 'expense:report', module: 'expense', actions: ['read', 'approve', 'export'] },
      { resource: 'report:financial', module: 'reports', actions: ['read', 'export'] },
    ],
    menuVisibility: {
      'nav-payroll': true, 'nav-payroll-tds': true, 'nav-payroll-pf': true,
      'nav-payroll-form16': true, 'nav-expense': true, 'nav-reports': true,
      'nav-leave': false, 'nav-employees': false, 'nav-settings': false,
    },
  };

  const managerRole: RoleDefinition = {
    ...base('sys-manager', 'manager', 'Team Manager', 'Manage own team: leave approvals, attendance, performance'),
    allowedModules: ['core-hr', 'leave', 'attendance', 'performance', 'lnd'],
    globalMaskedFields: ['employee.salary', 'employee.bankAccountNumber', 'employee.panNumber', 'employee.ctc'],
    permissions: [
      {
        resource: 'employee', module: 'core-hr', actions: ['read'],
        conditions: [{ field: 'employee.managerId', operator: 'eq', value: '{{userId}}' }],
        maskedFields: ['salary', 'bankAccountNumber', 'panNumber', 'ctc'],
      },
      {
        resource: 'leave:request', module: 'leave', actions: ['read', 'approve'],
        conditions: [{ field: 'employee.managerId', operator: 'eq', value: '{{userId}}' }],
      },
      {
        resource: 'attendance', module: 'attendance', actions: ['read'],
        conditions: [{ field: 'employee.managerId', operator: 'eq', value: '{{userId}}' }],
      },
      {
        resource: 'performance', module: 'performance', actions: ['read', 'create', 'update'],
        conditions: [{ field: 'employee.managerId', operator: 'eq', value: '{{userId}}' }],
      },
    ],
    menuVisibility: {
      'nav-leave': true, 'nav-attendance': true, 'nav-performance': true,
      'nav-employees': true, 'nav-payroll': false, 'nav-settings': false,
      'nav-reports': false, 'nav-payroll-tds': false,
    },
  };

  const employeeRole: RoleDefinition = {
    ...base('sys-employee', 'employee', 'Employee (Self-Service)', 'Access own data only'),
    allowedModules: ['leave', 'attendance', 'lnd'],
    globalMaskedFields: [],
    permissions: [
      {
        resource: 'employee', module: 'core-hr', actions: ['read'],
        conditions: [{ field: 'params.employeeId', operator: 'own-only' }],
      },
      {
        resource: 'leave:request', module: 'leave', actions: ['create', 'read'],
        conditions: [{ field: 'params.employeeId', operator: 'own-only' }],
      },
      {
        resource: 'payroll:payslip', module: 'payroll', actions: ['read'],
        conditions: [{ field: 'params.employeeId', operator: 'own-only' }],
      },
      {
        resource: 'attendance', module: 'attendance', actions: ['read', 'create'],
        conditions: [{ field: 'params.employeeId', operator: 'own-only' }],
      },
    ],
    menuVisibility: {
      'nav-leave': true, 'nav-attendance': true, 'nav-payroll': true,
      'nav-payroll-tds': false, 'nav-payroll-pf': false, 'nav-payroll-form16': true,
      'nav-employees': false, 'nav-reports': false, 'nav-settings': false,
    },
  };

  return [hrRole, financeRole, managerRole, employeeRole];
}

// ─────────────────────────────────────────────────────────────────────────────
// ROLE CREATION & CLONING
// ─────────────────────────────────────────────────────────────────────────────

export function createCustomRole(
  tenantId: string,
  input: {
    name: string;
    displayName: string;
    description: string;
    allowedModules: Module[];
    permissions: ResourcePermission[];
    menuVisibility: Record<string, boolean>;
    globalMaskedFields?: string[];
  },
  createdBy: string,
): RoleDefinition {
  // Validate: name must be kebab-case, no spaces
  if (!/^[a-z][a-z0-9-]*$/.test(input.name)) {
    throw new Error(`Role name "${input.name}" must be kebab-case (e.g. "senior-manager")`);
  }
  // Validate: permitted modules must be in ALL_MODULES
  const invalid = input.allowedModules.filter(m => !ALL_MODULES.includes(m));
  if (invalid.length) {
    throw new Error(`Unknown modules: ${invalid.join(', ')}`);
  }

  return {
    id: `custom-${tenantId}-${input.name}-${Date.now()}`,
    tenantId,
    name: input.name,
    displayName: input.displayName,
    description: input.description,
    isSystem: false,
    isActive: true,
    allowedModules: input.allowedModules,
    permissions: input.permissions,
    menuVisibility: input.menuVisibility,
    globalMaskedFields: input.globalMaskedFields ?? [],
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy,
  };
}

export function cloneRole(
  source: RoleDefinition,
  overrides: Partial<Pick<RoleDefinition, 'name' | 'displayName' | 'description' | 'allowedModules' | 'permissions' | 'menuVisibility' | 'globalMaskedFields'>>,
  clonedBy: string,
): RoleDefinition {
  const name = overrides.name ?? `${source.name}-clone`;
  if (!/^[a-z][a-z0-9-]*$/.test(name)) {
    throw new Error(`Cloned role name "${name}" must be kebab-case`);
  }
  return {
    ...source,
    id: `custom-${source.tenantId}-${name}-${Date.now()}`,
    name,
    displayName: overrides.displayName ?? `${source.displayName} (Clone)`,
    description: overrides.description ?? source.description,
    isSystem: false,    // Clones are never system roles
    allowedModules: overrides.allowedModules ?? [...source.allowedModules],
    permissions: overrides.permissions ?? source.permissions.map(p => ({ ...p })),
    menuVisibility: overrides.menuVisibility ?? { ...source.menuVisibility },
    globalMaskedFields: overrides.globalMaskedFields ?? [...source.globalMaskedFields],
    createdAt: new Date(),
    updatedAt: new Date(),
    createdBy: clonedBy,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// PERMISSION ENFORCEMENT
// ─────────────────────────────────────────────────────────────────────────────

export interface AccessResult {
  allowed: boolean;
  reason: string;
  matchedRole?: string;
  matchedPermission?: ResourcePermission;
  isElevated?: boolean;
}

export function canAccess(
  ctx: UserPermissionContext,
  module: Module,
  resource: string,
  action: CrudAction,
): AccessResult {
  // Collect all effective roles (permanent + active elevations)
  const effectiveRoles = [...ctx.roles];
  let isElevated = false;

  for (const elev of ctx.activeElevations) {
    if (elev.isRevoked || new Date() > elev.expiresAt) continue;
    // The elevated role is identified by id matching a system or custom role
    const roleLookup = ctx.allAvailableRoles ?? ctx.roles;
    const elevRole = roleLookup.find(r => r.id === elev.grantedRoleId);
    if (elevRole && !effectiveRoles.find(r => r.id === elevRole.id)) {
      effectiveRoles.push(elevRole);
      isElevated = true;
    }
  }

  for (const role of effectiveRoles) {
    if (!role.isActive) continue;

    // Module gate
    if (!role.allowedModules.includes(module)) continue;

    // Permission check
    const perm = role.permissions.find(
      p => p.resource === resource && p.module === module && p.actions.includes(action),
    );
    if (!perm) continue;

    // ABAC condition evaluation
    if (perm.conditions?.length) {
      const conditionsMet = evaluateConditions(perm.conditions, ctx);
      if (!conditionsMet) {
        return {
          allowed: false,
          reason: `Permission conditions not met for ${role.name}:${resource}:${action}`,
          matchedRole: role.name,
        };
      }
    }

    return {
      allowed: true,
      reason: `Granted by role: ${role.displayName}`,
      matchedRole: role.name,
      matchedPermission: perm,
      isElevated,
    };
  }

  return {
    allowed: false,
    reason: `No role grants ${module}:${resource}:${action}`,
  };
}

/** Substitute known template placeholders in permission condition values. */
function resolveConditionValue(value: unknown, ctx: UserPermissionContext): unknown {
  if (typeof value === 'string') {
    return value
      .replace('{{userId}}', ctx.userId)
      .replace('{{tenantId}}', ctx.tenantId);
  }
  return value;
}

export function evaluateConditions(
  conditions: PermissionCondition[],
  ctx: UserPermissionContext,
): boolean {
  for (const c of conditions) {
    if (c.operator === 'own-only') {
      // Checks if the resource belongs to the requesting user
      const targetId = ctx.requestContext.params?.['employeeId']
                     ?? ctx.requestContext.body?.['employeeId'];
      if (targetId && targetId !== ctx.userId) return false;
      continue;
    }

    const fieldValue = resolveField(c.field, ctx);
    const condValue  = resolveConditionValue(c.value, ctx);
    switch (c.operator) {
      case 'eq':     if (fieldValue !== condValue) return false; break;
      case 'neq':    if (fieldValue === condValue) return false; break;
      case 'in':     if (!Array.isArray(condValue) || !condValue.includes(fieldValue)) return false; break;
      case 'not-in': if (Array.isArray(condValue) && condValue.includes(fieldValue)) return false; break;
    }
  }
  return true;
}

function resolveField(field: string, ctx: UserPermissionContext): unknown {
  const parts = field.split('.');
  const [scope, key] = parts as [string, string];
  switch (scope) {
    case 'user':     return (ctx as Record<string, unknown>)[key ?? ''];
    case 'params':   return ctx.requestContext.params?.[key ?? ''];
    case 'body':     return ctx.requestContext.body?.[key ?? ''];
    case 'query':    return ctx.requestContext.query?.[key ?? ''];
    // Entity-scoped fields (e.g. 'employee.managerId') → resolve from params
    // This allows ABAC conditions to be satisfied via request context params
    default:         return ctx.requestContext.params?.[key ?? '']
                         ?? ctx.requestContext.body?.[key ?? ''];
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MODULE-LEVEL ACCESS GATE
// ─────────────────────────────────────────────────────────────────────────────

export function getAccessibleModules(ctx: UserPermissionContext): Module[] {
  const modules = new Set<Module>();
  for (const role of ctx.roles) {
    if (!role.isActive) continue;
    for (const m of role.allowedModules) modules.add(m);
  }
  // Add from active elevations
  for (const elev of ctx.activeElevations) {
    if (elev.isRevoked || new Date() > elev.expiresAt) continue;
    const elevRole = ctx.roles.find(r => r.id === elev.grantedRoleId);
    if (elevRole) for (const m of elevRole.allowedModules) modules.add(m);
  }
  return [...modules];
}

export function isModuleAccessible(ctx: UserPermissionContext, module: Module): boolean {
  return getAccessibleModules(ctx).includes(module);
}

// ─────────────────────────────────────────────────────────────────────────────
// MENU VISIBILITY
// ─────────────────────────────────────────────────────────────────────────────

export function buildVisibleMenu(
  ctx: UserPermissionContext,
  fullMenuTree: MenuNode[],
): MenuNode[] {
  const mergedVisibility: Record<string, boolean> = {};

  for (const role of ctx.roles) {
    if (!role.isActive) continue;
    for (const [nodeId, visible] of Object.entries(role.menuVisibility)) {
      // If ANY role shows it, it's visible (OR semantics)
      if (visible) mergedVisibility[nodeId] = true;
      else if (!(nodeId in mergedVisibility)) mergedVisibility[nodeId] = false;
    }
  }

  function filterNode(node: MenuNode): MenuNode | null {
    // Check module access
    if (!isModuleAccessible(ctx, node.module)) return null;
    // Check role-level visibility override
    if (node.id in mergedVisibility && !mergedVisibility[node.id]) return null;

    const children = node.children
      ?.map(filterNode)
      .filter((n): n is MenuNode => n !== null);

    return { ...node, visible: true, children };
  }

  return fullMenuTree.map(filterNode).filter((n): n is MenuNode => n !== null);
}

// ─────────────────────────────────────────────────────────────────────────────
// FIELD-LEVEL MASKING
// ─────────────────────────────────────────────────────────────────────────────

export const SENSITIVE_FIELDS = [
  'salary', 'ctc', 'bankAccountNumber', 'ifscCode', 'panNumber',
  'aadhaarNumber', 'passportNumber', 'dateOfBirth', 'personalEmail',
  'personalPhone', 'emergencyContact', 'medicalConditions',
] as const;

export type SensitiveField = typeof SENSITIVE_FIELDS[number];

export function maskRecord<T extends Record<string, unknown>>(
  record: T,
  ctx: UserPermissionContext,
  resource: string,
): T {
  const maskedFields = new Set<string>();

  for (const role of ctx.roles) {
    // Global masks
    for (const f of role.globalMaskedFields) maskedFields.add(f);
    // Permission-level masks
    const perm = role.permissions.find(p => p.resource === resource);
    if (perm?.maskedFields) {
      for (const f of perm.maskedFields) maskedFields.add(f);
    }
  }

  if (maskedFields.size === 0) return record;

  const result = { ...record };
  for (const field of maskedFields) {
    if (field in result) {
      (result as Record<string, unknown>)[field] = '****';
    }
  }
  return result;
}

export function getMaskedFields(
  ctx: UserPermissionContext,
  resource: string,
): string[] {
  const maskedFields = new Set<string>();
  for (const role of ctx.roles) {
    for (const f of role.globalMaskedFields) maskedFields.add(f);
    const perm = role.permissions.find(p => p.resource === resource);
    if (perm?.maskedFields) {
      for (const f of perm.maskedFields) maskedFields.add(f);
    }
  }
  return [...maskedFields];
}

// ─────────────────────────────────────────────────────────────────────────────
// ROLE SIMULATION
// ─────────────────────────────────────────────────────────────────────────────

export interface RoleSimulationInput {
  targetRoleId: string;
  resource: string;
  module: Module;
  action: CrudAction;
  simulatedContext?: Record<string, string>;
}

export interface RoleSimulationResult {
  targetRole: RoleDefinition;
  resource: string;
  action: CrudAction;
  allowed: boolean;
  reason: string;
  visibleModules: Module[];
  maskedFields: string[];
  visibleMenuCount: number;
}

export function simulateRole(
  role: RoleDefinition,
  input: RoleSimulationInput,
  fullMenuTree: MenuNode[],
): RoleSimulationResult {
  const simulatedCtx: UserPermissionContext = {
    userId: 'simulated-user',
    tenantId: role.tenantId,
    roleIds: [role.id],
    roles: [role],
    activeElevations: [],
    requestContext: {
      params: input.simulatedContext ?? {},
    },
  };

  const access = canAccess(simulatedCtx, input.module, input.resource, input.action);
  const visibleModules = getAccessibleModules(simulatedCtx);
  const maskedFields = getMaskedFields(simulatedCtx, input.resource);
  const visibleMenu = buildVisibleMenu(simulatedCtx, fullMenuTree);

  return {
    targetRole: role,
    resource: input.resource,
    action: input.action,
    allowed: access.allowed,
    reason: access.reason,
    visibleModules,
    maskedFields,
    visibleMenuCount: countMenuNodes(visibleMenu),
  };
}

function countMenuNodes(nodes: MenuNode[]): number {
  return nodes.reduce((sum, n) => sum + 1 + countMenuNodes(n.children ?? []), 0);
}

// ─────────────────────────────────────────────────────────────────────────────
// TEMPORARY ELEVATION
// ─────────────────────────────────────────────────────────────────────────────

export interface ElevationRequest {
  userId: string;
  tenantId: string;
  targetRoleId: string;
  targetRoleName: string;
  reason: string;
  durationHours: number;      // e.g. 4 = 4-hour window
  grantedBy: string;
}

export function grantTemporaryElevation(
  req: ElevationRequest,
  maxDurationHours = 72,
): TemporaryElevation {
  if (req.durationHours <= 0) {
    throw new Error('Elevation duration must be positive');
  }
  if (req.durationHours > maxDurationHours) {
    throw new Error(`Elevation cannot exceed ${maxDurationHours} hours`);
  }
  if (!req.reason?.trim()) {
    throw new Error('Elevation reason is required for audit trail');
  }

  const grantedAt = new Date();
  const expiresAt = new Date(grantedAt.getTime() + req.durationHours * 3_600_000);
  const auditToken = buildElevationToken(req.userId, req.targetRoleId, expiresAt);

  return {
    id: `elev-${Date.now()}`,
    userId: req.userId,
    tenantId: req.tenantId,
    grantedRoleId: req.targetRoleId,
    grantedRoleName: req.targetRoleName,
    reason: req.reason,
    grantedBy: req.grantedBy,
    grantedAt,
    expiresAt,
    isRevoked: false,
    auditToken,
  };
}

export function revokeElevation(
  elevation: TemporaryElevation,
  revokedBy: string,
): TemporaryElevation {
  if (elevation.isRevoked) {
    throw new Error('Elevation is already revoked');
  }
  return {
    ...elevation,
    isRevoked: true,
    revokedAt: new Date(),
    revokedBy,
  };
}

export function isElevationActive(elevation: TemporaryElevation, now = new Date()): boolean {
  return !elevation.isRevoked && now < elevation.expiresAt;
}

export function getActiveElevations(
  elevations: TemporaryElevation[],
  userId: string,
  now = new Date(),
): TemporaryElevation[] {
  return elevations.filter(
    e => e.userId === userId && isElevationActive(e, now),
  );
}

function buildElevationToken(userId: string, roleId: string, expiresAt: Date): string {
  const payload = `${userId}:${roleId}:${expiresAt.getTime()}`;
  let h = 5381;
  for (let i = 0; i < payload.length; i++) {
    h = ((h << 5) + h) + payload.charCodeAt(i); h |= 0;
  }
  return `elv-${Math.abs(h).toString(16).toUpperCase().padStart(8, '0')}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// PERMISSION AUDIT LOGGING
// ─────────────────────────────────────────────────────────────────────────────

let _auditSeq = 0;
export function buildPermissionAuditEvent(
  params: Omit<PermissionAuditEvent, 'id' | 'performedAt'>,
): PermissionAuditEvent {
  return {
    ...params,
    id: `perm-audit-${++_auditSeq}-${Date.now()}`,
    performedAt: new Date(),
  };
}

export function auditAccessDenied(
  ctx: UserPermissionContext,
  module: Module,
  resource: string,
  action: CrudAction,
  reason: string,
): PermissionAuditEvent {
  return buildPermissionAuditEvent({
    tenantId: ctx.tenantId,
    userId: ctx.userId,
    action: 'access_denied',
    resourceType: resource,
    performedBy: ctx.userId,
    metadata: { module, resource, action, reason, roles: ctx.roleIds },
  });
}

export function auditRoleCreated(
  role: RoleDefinition,
  performedBy: string,
): PermissionAuditEvent {
  return buildPermissionAuditEvent({
    tenantId: role.tenantId,
    userId: performedBy,
    action: 'role_created',
    resourceType: 'role',
    resourceId: role.id,
    performedBy,
    metadata: {
      roleName: role.name,
      allowedModules: role.allowedModules,
      permissionCount: role.permissions.length,
    },
  });
}

export function auditRoleCloned(
  source: RoleDefinition,
  clone: RoleDefinition,
  performedBy: string,
): PermissionAuditEvent {
  return buildPermissionAuditEvent({
    tenantId: source.tenantId,
    userId: performedBy,
    action: 'role_cloned',
    resourceType: 'role',
    resourceId: clone.id,
    performedBy,
    metadata: { sourceRoleName: source.name, cloneRoleName: clone.name },
  });
}

export function auditElevationGranted(
  elev: TemporaryElevation,
): PermissionAuditEvent {
  return buildPermissionAuditEvent({
    tenantId: elev.tenantId,
    userId: elev.userId,
    action: 'elevation_granted',
    resourceType: 'role',
    resourceId: elev.grantedRoleId,
    performedBy: elev.grantedBy,
    metadata: {
      targetRole: elev.grantedRoleName,
      reason: elev.reason,
      expiresAt: elev.expiresAt.toISOString(),
      auditToken: elev.auditToken,
    },
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// RESTRICTED CALL ENFORCEMENT
// ─────────────────────────────────────────────────────────────────────────────

export interface RestrictedCallAttempt {
  userId: string;
  roles: string[];
  module: Module;
  resource: string;
  action: CrudAction;
  result: AccessResult;
  timestamp: Date;
}

/**
 * Enforce access check and collect audit event on denial.
 * Returns the AccessResult — caller must check .allowed before proceeding.
 */
export function enforceAccess(
  ctx: UserPermissionContext,
  module: Module,
  resource: string,
  action: CrudAction,
  auditLog: PermissionAuditEvent[],
): AccessResult {
  const result = canAccess(ctx, module, resource, action);

  if (!result.allowed) {
    auditLog.push(auditAccessDenied(ctx, module, resource, action, result.reason));
  } else {
    auditLog.push(buildPermissionAuditEvent({
      tenantId: ctx.tenantId,
      userId: ctx.userId,
      action: 'access_allowed',
      resourceType: resource,
      performedBy: ctx.userId,
      metadata: { module, resource, action, role: result.matchedRole, elevated: result.isElevated },
    }));
  }

  return result;
}
