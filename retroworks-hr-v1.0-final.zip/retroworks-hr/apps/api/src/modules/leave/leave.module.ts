import {
  Controller, Get, Post, Patch, Body, Param, Query,
  UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { LeaveService } from './leave.service';
import type {
  CreateLeaveRequestDto, ApproveLeaveDto, RejectLeaveDto,
  UpdateLeaveBalanceDto, LeaveRequestQueryDto,
} from './dto/leave.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

@ApiTags('leave')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('leave')
export class LeaveController {
  constructor(private readonly leaveService: LeaveService) {}

  @Post('requests')
  @ApiOperation({ summary: 'Apply for leave' })
  apply(@Body() dto: CreateLeaveRequestDto, @CurrentUser() u: JwtPayload) {
    return this.leaveService.applyLeave(u.tid, dto, u.sub, u.roles);
  }

  @Get('requests')
  @ApiOperation({ summary: 'List leave requests' })
  listRequests(@Query() query: LeaveRequestQueryDto, @CurrentUser() u: JwtPayload) {
    return this.leaveService.listLeaveRequests(u.tid, query, u.sub, u.roles);
  }

  @Get('requests/:id')
  getRequest(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.leaveService.getLeaveRequest(u.tid, id);
  }

  @Post('requests/:id/approve')
  @Roles('manager', 'hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Approve a leave request' })
  approve(@Param('id') id: string, @Body() dto: ApproveLeaveDto, @CurrentUser() u: JwtPayload) {
    return this.leaveService.approveLeave(u.tid, id, dto, u.sub);
  }

  @Post('requests/:id/reject')
  @Roles('manager', 'hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Reject a leave request' })
  reject(@Param('id') id: string, @Body() dto: RejectLeaveDto, @CurrentUser() u: JwtPayload) {
    return this.leaveService.rejectLeave(u.tid, id, dto, u.sub);
  }

  @Post('requests/:id/cancel')
  @ApiOperation({ summary: 'Cancel a leave request' })
  cancel(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.leaveService.cancelLeave(u.tid, id, u.sub);
  }

  @Get('balances/me')
  @ApiOperation({ summary: 'Get my leave balances for all leave types' })
  myBalances(@CurrentUser() u: JwtPayload) {
    return this.leaveService.getMyBalances(u.tid, u.sub);
  }

  @Get('balances/:employeeId')
  @Roles('manager', 'hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Get leave balances for a specific employee' })
  employeeBalances(@Param('employeeId') id: string, @CurrentUser() u: JwtPayload) {
    return this.leaveService.getMyBalances(u.tid, id);
  }

  @Post('balances/adjust')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Manually adjust leave balance (HR admin)' })
  adjustBalance(@Body() dto: UpdateLeaveBalanceDto, @CurrentUser() u: JwtPayload) {
    return this.leaveService.manualAdjustBalance(u.tid, dto, u.sub);
  }

  @Get('types')
  @ApiOperation({ summary: 'Get all leave types configured for tenant' })
  leaveTypes(@CurrentUser() u: JwtPayload) {
    return this.leaveService.getLeaveTypes(u.tid);
  }

  @Get('calendar')
  @ApiOperation({ summary: 'Get leave calendar for a month' })
  calendar(
    @Query('month') month: string,
    @Query('year') year: string,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.leaveService.getLeaveCalendar(
      u.tid,
      parseInt(month || String(new Date().getMonth() + 1)),
      parseInt(year || String(new Date().getFullYear())),
    );
  }
}

@Module({
  controllers: [LeaveController],
  providers: [LeaveService],
  exports: [LeaveService],
})
export class LeaveModule {}
