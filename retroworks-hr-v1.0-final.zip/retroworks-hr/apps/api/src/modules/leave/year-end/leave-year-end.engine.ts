/**
 * RetroWorks HR — Leave Year-End Processing Engine
 * ═══════════════════════════════════════════════════════════════════════════════
 * Pure TypeScript functions for end-of-leave-year processing.
 *
 * Handles three year-end paradigms:
 *   ▸ calendar   — 1 Jan → 31 Dec
 *   ▸ financial  — 1 Apr → 31 Mar (India default)
 *   ▸ academic   — 1 Jun → 31 May (schools / education mode)
 *
 * Processing pipeline per employee per leave type:
 *   1. FREEZE    — block new leave requests during processing window
 *   2. SIMULATE  — dry-run to preview outcome (no DB writes)
 *   3. COMPUTE   — carry-forward, lapse, encashment, new balance
 *   4. LOCK      — ledger locked (idempotent guard prevents re-run)
 *   5. AUDIT     — immutable audit event written
 *
 * Invariants:
 *   ▸ carryForward ≤ leaveType.carryForwardDays (hard cap)
 *   ▸ lapsed + carryForward = max(0, (balance - used))  [never negative]
 *   ▸ encashmentDays ≤ encashable balance
 *   ▸ new year allocated = leaveType.maxDaysPerYear + carryForward
 *   ▸ Processing is idempotent — re-running same year is a no-op
 * ═══════════════════════════════════════════════════════════════════════════════
 */

// ─────────────────────────────────────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────────────────────────────────────

export type YearType = 'calendar' | 'financial' | 'academic';

export interface LeaveYearConfig {
  yearType: YearType;
  /** YYYY — the year being closed (start year for financial/academic) */
  closingYear: number;
  /**
   * Processing freeze window: during this period new leave requests are blocked.
   * e.g. { start: '2024-03-28', end: '2024-04-02' }
   */
  freezeWindowStart: string;   // ISO date
  freezeWindowEnd: string;     // ISO date
  /**
   * Encashment rate in currency per day.
   * If 0, no monetary payout — carried to next year or lapsed.
   */
  encashmentRatePerDay: number;
  currency: string;
}

export interface LeaveTypeConfig {
  id: string;
  code: string;
  name: string;
  maxDaysPerYear: number;
  /** Maximum days that can be carried to next year. 0 = no carry-forward. */
  carryForwardDays: number;
  /** Whether unused balance can be encashed (paid out). */
  encashable: boolean;
  /** Max days that can be encashed. Null = no cap (limited by available only). */
  maxEncashableDays: number | null;
  paidLeave: boolean;
}

export interface EmployeeLeaveSnapshot {
  employeeId: string;
  employeeName: string;
  leaveTypeId: string;
  year: number;
  /** Days allocated for the year (base + last-year carry-forward) */
  allocated: number;
  /** Days actually used (approved + attended) */
  used: number;
  /** Days in pending requests (not yet approved) */
  pending: number;
  /** Days carried forward from the previous year */
  carryForward: number;
}

// ─────────────────────────────────────────────────────────────────────────────
// COMPUTED OUTPUTS
// ─────────────────────────────────────────────────────────────────────────────

export interface YearEndComputed {
  employeeId: string;
  employeeName: string;
  leaveTypeId: string;
  leaveTypeCode: string;
  closingYear: number;
  newYear: number;

  // Closing year final balance
  closingAllocated: number;
  closingUsed: number;
  closingPending: number;
  closingAvailable: number;   // allocated − used − pending (floored at 0)

  // Year-end disposition
  carryForwardDays: number;   // ≤ leaveType.carryForwardDays
  lapsedDays: number;         // balance lost (not carried, not encashed)
  encashedDays: number;       // days converted to money
  encashmentAmount: number;   // encashedDays × rate

  // New year opening balance
  newYearAllocated: number;   // leaveType.maxDaysPerYear + carryForwardDays

  // Metadata
  processedAt: Date;
  isSimulation: boolean;      // true = dry-run, no DB write
  idempotencyKey: string;     // tenantId:employeeId:leaveTypeId:closingYear
}

export interface YearEndBatchResult {
  tenantId: string;
  closingYear: number;
  yearType: YearType;
  totalEmployees: number;
  totalLeaveTypes: number;
  totalRecords: number;
  computed: YearEndComputed[];

  // Aggregates
  totalCarryForwardDays: number;
  totalLapsedDays: number;
  totalEncashedDays: number;
  totalEncashmentAmount: number;

  // Flags
  isSimulation: boolean;
  isLocked: boolean;           // true after real processing (ledger locked)
  processedAt: Date;
  ledgerHash: string;          // Checksum for audit verification
}

export interface FreezeWindowStatus {
  isFrozen: boolean;
  freezeStart: Date;
  freezeEnd: Date;
  daysUntilFreeze: number;    // Negative if already frozen
  message: string;
}

export interface AuditEvent {
  eventType: 'year_end_simulated' | 'year_end_processed' | 'year_end_locked' | 'ledger_freeze_set' | 'encashment_approved';
  tenantId: string;
  performedBy: string;
  performedAt: Date;
  closingYear: number;
  yearType: YearType;
  affectedEmployees: number;
  totalEncashmentAmount: number;
  idempotencyKey: string;
  payload: Record<string, unknown>;
}

export interface ReminderSchedule {
  type: 'freeze_warning' | 'processing_started' | 'processing_complete' | 'encashment_pending';
  scheduledFor: Date;
  recipients: 'all_employees' | 'hr_admin' | 'managers';
  subject: string;
  body: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITY
// ─────────────────────────────────────────────────────────────────────────────

export function r2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function getNewYear(yearType: YearType, closingYear: number): number {
  // For all types: new year = closing year + 1
  // calendar: 2024 closes → 2025 opens
  // financial: FY2024-25 closes → FY2025-26 opens (we track by start year)
  // academic: AY2024-25 closes → AY2025-26 opens
  return closingYear + 1;
}

export function getYearLabel(yearType: YearType, year: number): string {
  switch (yearType) {
    case 'calendar':  return `${year}`;
    case 'financial': return `FY${year}-${String(year + 1).slice(2)}`;
    case 'academic':  return `AY${year}-${String(year + 1).slice(2)}`;
  }
}

export function getYearBoundaries(yearType: YearType, year: number): { start: Date; end: Date } {
  switch (yearType) {
    case 'calendar':
      return {
        start: new Date(`${year}-01-01`),
        end:   new Date(`${year}-12-31`),
      };
    case 'financial':
      return {
        start: new Date(`${year}-04-01`),
        end:   new Date(`${year + 1}-03-31`),
      };
    case 'academic':
      return {
        start: new Date(`${year}-06-01`),
        end:   new Date(`${year + 1}-05-31`),
      };
  }
}

export function isFreezeWindowActive(config: LeaveYearConfig, checkDate: Date = new Date()): boolean {
  const start = new Date(config.freezeWindowStart);
  const end   = new Date(config.freezeWindowEnd);
  return checkDate >= start && checkDate <= end;
}

export function getFreezeWindowStatus(config: LeaveYearConfig, now: Date = new Date()): FreezeWindowStatus {
  const start = new Date(config.freezeWindowStart);
  const end   = new Date(config.freezeWindowEnd);
  const isFrozen = now >= start && now <= end;
  const msPerDay = 86_400_000;
  const daysUntilFreeze = Math.round((start.getTime() - now.getTime()) / msPerDay);

  return {
    isFrozen,
    freezeStart: start,
    freezeEnd: end,
    daysUntilFreeze,
    message: isFrozen
      ? `Leave requests are frozen for year-end processing (until ${config.freezeWindowEnd}).`
      : daysUntilFreeze > 0
        ? `Year-end freeze starts in ${daysUntilFreeze} days (${config.freezeWindowStart}).`
        : `Freeze window has ended. Processing should be complete.`,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// CORE COMPUTATION — per employee per leave type
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute year-end outcomes for a single employee + leave type combination.
 *
 * Algorithm:
 *   available = max(0, allocated − used − pending)
 *   carryForward = min(available, leaveType.carryForwardDays)
 *   encashable_balance = available − carryForward  [if encashable]
 *   encashed = min(encashable_balance, maxEncashableDays ?? Infinity)
 *   lapsed = available − carryForward − encashed
 *   newYearAllocated = leaveType.maxDaysPerYear + carryForward
 */
export function computeYearEnd(
  snapshot: EmployeeLeaveSnapshot,
  leaveType: LeaveTypeConfig,
  config: LeaveYearConfig,
  isSimulation = true,
): YearEndComputed {
  const available = r2(Math.max(0, snapshot.allocated - snapshot.used - snapshot.pending));
  const carryForwardDays = r2(Math.min(available, leaveType.carryForwardDays));
  const balanceAfterCarry = r2(available - carryForwardDays);

  // Encashment: only if leave type is encashable and rate > 0
  let encashedDays = 0;
  let encashmentAmount = 0;
  if (leaveType.encashable && config.encashmentRatePerDay > 0 && balanceAfterCarry > 0) {
    const maxEncash = leaveType.maxEncashableDays !== null
      ? Math.min(balanceAfterCarry, leaveType.maxEncashableDays)
      : balanceAfterCarry;
    encashedDays = r2(Math.min(balanceAfterCarry, maxEncash));
    encashmentAmount = r2(encashedDays * config.encashmentRatePerDay);
  }

  const lapsedDays = r2(Math.max(0, balanceAfterCarry - encashedDays));
  const newYearAllocated = r2(leaveType.maxDaysPerYear + carryForwardDays);

  const idempotencyKey = `${snapshot.employeeId}:${leaveType.id}:${snapshot.year}`;

  return {
    employeeId: snapshot.employeeId,
    employeeName: snapshot.employeeName,
    leaveTypeId: leaveType.id,
    leaveTypeCode: leaveType.code,
    closingYear: snapshot.year,
    newYear: getNewYear(config.yearType, snapshot.year),

    closingAllocated: snapshot.allocated,
    closingUsed: snapshot.used,
    closingPending: snapshot.pending,
    closingAvailable: available,

    carryForwardDays,
    lapsedDays,
    encashedDays,
    encashmentAmount,

    newYearAllocated,

    processedAt: new Date(),
    isSimulation,
    idempotencyKey,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// BATCH PROCESSING — all employees × all leave types
// ─────────────────────────────────────────────────────────────────────────────

export function processBatchYearEnd(
  tenantId: string,
  config: LeaveYearConfig,
  snapshots: EmployeeLeaveSnapshot[],
  leaveTypes: Map<string, LeaveTypeConfig>,
  isSimulation = true,
): YearEndBatchResult {
  const computed: YearEndComputed[] = [];

  for (const snap of snapshots) {
    const lt = leaveTypes.get(snap.leaveTypeId);
    if (!lt) continue; // skip unknown leave types
    computed.push(computeYearEnd(snap, lt, config, isSimulation));
  }

  const totalCarryForward   = r2(computed.reduce((s, c) => s + c.carryForwardDays, 0));
  const totalLapsed         = r2(computed.reduce((s, c) => s + c.lapsedDays, 0));
  const totalEncashed       = r2(computed.reduce((s, c) => s + c.encashedDays, 0));
  const totalEncashAmount   = r2(computed.reduce((s, c) => s + c.encashmentAmount, 0));
  const uniqueEmployees     = new Set(computed.map(c => c.employeeId)).size;
  const uniqueLeaveTypes    = new Set(computed.map(c => c.leaveTypeId)).size;

  const ledgerHash = simpleLedgerHash({
    tenantId,
    year: config.closingYear,
    totalCarryForward,
    totalEncashAmount,
    records: computed.length,
  });

  return {
    tenantId,
    closingYear: config.closingYear,
    yearType: config.yearType,
    totalEmployees: uniqueEmployees,
    totalLeaveTypes: uniqueLeaveTypes,
    totalRecords: computed.length,
    computed,
    totalCarryForwardDays: totalCarryForward,
    totalLapsedDays: totalLapsed,
    totalEncashedDays: totalEncashed,
    totalEncashmentAmount: totalEncashAmount,
    isSimulation,
    isLocked: !isSimulation,
    processedAt: new Date(),
    ledgerHash,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// IDEMPOTENCY — detect re-runs
// ─────────────────────────────────────────────────────────────────────────────

export interface ProcessedLedger {
  tenantId: string;
  closingYear: number;
  yearType: YearType;
  processedAt: Date;
  ledgerHash: string;
}

export function isAlreadyProcessed(
  existing: ProcessedLedger[],
  tenantId: string,
  closingYear: number,
): boolean {
  return existing.some(l => l.tenantId === tenantId && l.closingYear === closingYear);
}

export function guardIdempotency(
  existing: ProcessedLedger[],
  tenantId: string,
  closingYear: number,
): { safe: boolean; reason?: string } {
  const found = existing.find(l => l.tenantId === tenantId && l.closingYear === closingYear);
  if (found) {
    return {
      safe: false,
      reason: `Year-end for ${closingYear} was already processed on ${found.processedAt.toISOString()} (hash: ${found.ledgerHash}). Re-run blocked.`,
    };
  }
  return { safe: true };
}

// ─────────────────────────────────────────────────────────────────────────────
// LEDGER CONSISTENCY CHECKS
// ─────────────────────────────────────────────────────────────────────────────

export interface LedgerConsistencyResult {
  isConsistent: boolean;
  violations: string[];
}

/**
 * Verify all computed records obey the fundamental invariants.
 * Run before committing to DB.
 */
export function verifyLedgerConsistency(computed: YearEndComputed[]): LedgerConsistencyResult {
  const violations: string[] = [];

  for (const c of computed) {
    const key = `${c.employeeId}:${c.leaveTypeCode}`;

    // Invariant 1: closing available = allocated − used − pending (≥ 0)
    const expectedAvailable = r2(Math.max(0, c.closingAllocated - c.closingUsed - c.closingPending));
    if (Math.abs(c.closingAvailable - expectedAvailable) > 0.01) {
      violations.push(`${key}: closingAvailable mismatch. Expected ${expectedAvailable}, got ${c.closingAvailable}`);
    }

    // Invariant 2: carryForward + lapsed + encashed = closingAvailable
    const sum = r2(c.carryForwardDays + c.lapsedDays + c.encashedDays);
    if (Math.abs(sum - c.closingAvailable) > 0.01) {
      violations.push(`${key}: carryForward(${c.carryForwardDays}) + lapsed(${c.lapsedDays}) + encashed(${c.encashedDays}) = ${sum} ≠ available(${c.closingAvailable})`);
    }

    // Invariant 3: no negative values
    if (c.carryForwardDays < 0) violations.push(`${key}: negative carryForwardDays`);
    if (c.lapsedDays < 0)      violations.push(`${key}: negative lapsedDays`);
    if (c.encashedDays < 0)    violations.push(`${key}: negative encashedDays`);
    if (c.closingAvailable < 0) violations.push(`${key}: negative closingAvailable`);

    // Invariant 4: encashmentAmount = encashedDays × rate (if encashed > 0)
    // (rate not available here — validated in computeYearEnd directly)
  }

  return { isConsistent: violations.length === 0, violations };
}

// ─────────────────────────────────────────────────────────────────────────────
// REMINDER AUTOMATION
// ─────────────────────────────────────────────────────────────────────────────

export function generateReminderSchedule(config: LeaveYearConfig): ReminderSchedule[] {
  const freezeStart = new Date(config.freezeWindowStart);
  const freezeEnd   = new Date(config.freezeWindowEnd);
  const msPerDay    = 86_400_000;

  return [
    {
      type: 'freeze_warning',
      scheduledFor: new Date(freezeStart.getTime() - 7 * msPerDay),
      recipients: 'all_employees',
      subject: `📅 Leave year-end freeze in 7 days`,
      body: `All pending leave requests must be submitted by ${config.freezeWindowStart}. The system will enter a processing freeze from that date.`,
    },
    {
      type: 'freeze_warning',
      scheduledFor: new Date(freezeStart.getTime() - 2 * msPerDay),
      recipients: 'all_employees',
      subject: `⚠️ Leave freeze starts in 2 days`,
      body: `Reminder: Leave requests will be frozen for year-end processing starting ${config.freezeWindowStart}.`,
    },
    {
      type: 'processing_started',
      scheduledFor: freezeStart,
      recipients: 'hr_admin',
      subject: `🔒 Leave year-end processing started`,
      body: `Year-end processing has begun. Leave requests are now frozen until ${config.freezeWindowEnd}.`,
    },
    {
      type: 'processing_complete',
      scheduledFor: new Date(freezeEnd.getTime() + msPerDay),
      recipients: 'managers',
      subject: `✅ Leave year-end complete — review your team balances`,
      body: `Year-end processing is complete. Please review your team's new leave balances for the upcoming year.`,
    },
    ...(config.encashmentRatePerDay > 0 ? [{
      type: 'encashment_pending' as const,
      scheduledFor: new Date(freezeEnd.getTime() + 2 * msPerDay),
      recipients: 'hr_admin' as const,
      subject: `💰 Leave encashment payouts pending approval`,
      body: `Encashment calculations are ready. Please review and approve encashment payouts before next payroll run.`,
    }] : []),
  ];
}

// ─────────────────────────────────────────────────────────────────────────────
// AUDIT EVENT FACTORY
// ─────────────────────────────────────────────────────────────────────────────

export function buildAuditEvent(
  batchResult: YearEndBatchResult,
  tenantId: string,
  performedBy: string,
): AuditEvent {
  return {
    eventType: batchResult.isSimulation ? 'year_end_simulated' : 'year_end_processed',
    tenantId,
    performedBy,
    performedAt: batchResult.processedAt,
    closingYear: batchResult.closingYear,
    yearType: batchResult.yearType,
    affectedEmployees: batchResult.totalEmployees,
    totalEncashmentAmount: batchResult.totalEncashmentAmount,
    idempotencyKey: `${tenantId}:${batchResult.closingYear}:${batchResult.yearType}`,
    payload: {
      ledgerHash: batchResult.ledgerHash,
      totalRecords: batchResult.totalRecords,
      totalCarryForwardDays: batchResult.totalCarryForwardDays,
      totalLapsedDays: batchResult.totalLapsedDays,
      totalEncashedDays: batchResult.totalEncashedDays,
    },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// LEAVE REQUEST FREEZE GUARD
// ─────────────────────────────────────────────────────────────────────────────

export interface FreezeGuardResult {
  allowed: boolean;
  reason?: string;
}

export function canSubmitLeaveRequest(
  config: LeaveYearConfig,
  requestedStartDate: string,  // ISO date
  now: Date = new Date(),
): FreezeGuardResult {
  if (!isFreezeWindowActive(config, now)) {
    return { allowed: true };
  }

  // During freeze: reject any requests for the closing year
  const closingYearBounds = getYearBoundaries(config.yearType, config.closingYear);
  const reqStart = new Date(requestedStartDate);

  if (reqStart >= closingYearBounds.start && reqStart <= closingYearBounds.end) {
    return {
      allowed: false,
      reason: `Leave requests are frozen for year-end processing until ${config.freezeWindowEnd}. Please contact HR for urgent requests.`,
    };
  }

  return { allowed: true };
}

// ─────────────────────────────────────────────────────────────────────────────
// BULK APPROVAL CONSOLE
// ─────────────────────────────────────────────────────────────────────────────

export interface BulkApprovalRequest {
  requestId: string;
  employeeId: string;
  employeeName: string;
  leaveTypeCode: string;
  startDate: string;
  endDate: string;
  days: number;
  status: 'pending';
}

export interface BulkApprovalResult {
  approved: string[];   // request IDs
  rejected: string[];
  skipped: string[];    // already approved/cancelled
  summary: string;
}

export function bulkApproveRequests(
  requests: BulkApprovalRequest[],
  approvalPolicy: {
    autoApproveBeforeFreeze: boolean;
    maxDaysForAutoApprove: number;
    requiresManagerApprovalAbove: number;
  },
): BulkApprovalResult {
  const approved: string[] = [];
  const rejected: string[] = [];
  const skipped: string[] = [];

  for (const req of requests) {
    if (req.days <= 0) { skipped.push(req.requestId); continue; }

    if (approvalPolicy.autoApproveBeforeFreeze &&
        req.days <= approvalPolicy.maxDaysForAutoApprove) {
      approved.push(req.requestId);
    } else if (req.days > approvalPolicy.requiresManagerApprovalAbove) {
      // Flag for manual review — not auto-approved
      skipped.push(req.requestId);
    } else {
      approved.push(req.requestId);
    }
  }

  return {
    approved,
    rejected,
    skipped,
    summary: `Bulk approval: ${approved.length} approved, ${rejected.length} rejected, ${skipped.length} pending manager review out of ${requests.length} requests.`,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// LEDGER HASH
// ─────────────────────────────────────────────────────────────────────────────

export function simpleLedgerHash(data: Record<string, unknown>): string {
  const str = JSON.stringify(data, Object.keys(data).sort());
  let h = 5381;
  for (let i = 0; i < str.length; i++) {
    h = ((h << 5) + h) + str.charCodeAt(i); h |= 0;
  }
  return `LH-${Math.abs(h).toString(16).toUpperCase().padStart(8, '0')}`;
}

// ─────────────────────────────────────────────────────────────────────────────
// SIMULATION DIFF — compare simulation vs last-run
// ─────────────────────────────────────────────────────────────────────────────

export interface SimulationDiff {
  employeeId: string;
  leaveTypeCode: string;
  field: string;
  simulationValue: number;
  actualValue: number;
  delta: number;
}

export function diffSimulationVsActual(
  simulation: YearEndComputed[],
  actual: YearEndComputed[],
): SimulationDiff[] {
  const diffs: SimulationDiff[] = [];
  const fields: Array<keyof YearEndComputed> = [
    'carryForwardDays', 'lapsedDays', 'encashedDays', 'encashmentAmount', 'newYearAllocated',
  ];

  for (const sim of simulation) {
    const act = actual.find(
      a => a.employeeId === sim.employeeId && a.leaveTypeId === sim.leaveTypeId
    );
    if (!act) continue;

    for (const field of fields) {
      const sv = sim[field] as number;
      const av = act[field] as number;
      if (Math.abs(sv - av) > 0.01) {
        diffs.push({
          employeeId: sim.employeeId,
          leaveTypeCode: sim.leaveTypeCode,
          field,
          simulationValue: sv,
          actualValue: av,
          delta: r2(sv - av),
        });
      }
    }
  }
  return diffs;
}
