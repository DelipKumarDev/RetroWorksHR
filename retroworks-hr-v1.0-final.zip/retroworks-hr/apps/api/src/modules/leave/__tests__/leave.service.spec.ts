import { Test, type TestingModule } from '@nestjs/testing';
import { BadRequestException, ConflictException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { LeaveService } from '../leave.service';

const TENANT_ID = 'tenant-123';
const EMP_ID = 'emp-001';

const mockLeaveType = {
  id: 'lt-cl',
  tenantId: TENANT_ID,
  name: 'Casual Leave',
  code: 'CL',
  paidLeave: true,
  requiresDocument: false,
  maxDaysPerYear: 12,
  isActive: true,
};

const mockBalance = {
  id: 'bal-001',
  tenantId: TENANT_ID,
  employeeId: EMP_ID,
  leaveTypeId: 'lt-cl',
  year: new Date().getFullYear(),
  entitled: 12,
  balance: 8,
  used: 4,
  pending: 0,
};

const mockPrisma = {
  leaveType: {
    findFirst: jest.fn(),
    findMany: jest.fn(),
    findUnique: jest.fn(),
  },
  leaveRequest: {
    findFirst: jest.fn(),
    findMany: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    count: jest.fn(),
  },
  leaveBalance: {
    findFirst: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    upsert: jest.fn(),
  },
  employee: {
    findFirst: jest.fn(),
    findMany: jest.fn(),
  },
};

const mockEvents = { emit: jest.fn() };

describe('LeaveService', () => {
  let service: LeaveService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        LeaveService,
        { provide: 'PrismaClient', useValue: mockPrisma },
        { provide: EventEmitter2, useValue: mockEvents },
      ],
    }).compile();

    service = module.get<LeaveService>(LeaveService);
    jest.clearAllMocks();

    // Default mocks
    mockPrisma.leaveType.findFirst.mockResolvedValue(mockLeaveType);
    mockPrisma.leaveBalance.findFirst.mockResolvedValue(mockBalance);
    mockPrisma.leaveRequest.findFirst.mockResolvedValue(null); // No overlap by default
    mockPrisma.employee.findFirst.mockResolvedValue({ managerId: null, firstName: 'Test', lastName: 'User' });
    mockPrisma.leaveRequest.create.mockResolvedValue({
      id: 'req-001', tenantId: TENANT_ID, employeeId: EMP_ID,
      leaveTypeId: 'lt-cl', startDate: new Date('2025-06-09'),
      endDate: new Date('2025-06-11'), days: 3, status: 'pending',
      employee: { id: EMP_ID, firstName: 'Test', lastName: 'User' },
      leaveType: { id: 'lt-cl', name: 'Casual Leave', code: 'CL', paidLeave: true },
    });
  });

  // ─────────────────────────────────────────────
  // Apply Leave
  // ─────────────────────────────────────────────

  describe('applyLeave', () => {
    const dto = {
      leaveTypeId: 'lt-cl',
      startDate: '2025-06-09',
      endDate: '2025-06-11',
    };

    it('creates leave request successfully', async () => {
      await service.applyLeave(TENANT_ID, dto, EMP_ID, ['employee']);

      expect(mockPrisma.leaveRequest.create).toHaveBeenCalled();
      expect(mockEvents.emit).toHaveBeenCalledWith('leave.submitted', expect.anything());
    });

    it('throws if end date before start date', async () => {
      await expect(
        service.applyLeave(TENANT_ID, { ...dto, startDate: '2025-06-15', endDate: '2025-06-10' }, EMP_ID, ['employee']),
      ).rejects.toThrow(BadRequestException);
    });

    it('throws ConflictException for overlapping dates', async () => {
      mockPrisma.leaveRequest.findFirst.mockResolvedValue({
        id: 'existing', startDate: new Date('2025-06-08'), endDate: new Date('2025-06-10'),
      });

      await expect(
        service.applyLeave(TENANT_ID, dto, EMP_ID, ['employee']),
      ).rejects.toThrow(ConflictException);
    });

    it('throws when document required but not provided', async () => {
      mockPrisma.leaveType.findFirst.mockResolvedValue({
        ...mockLeaveType,
        requiresDocument: true,
        name: 'Sick Leave',
      });

      await expect(
        service.applyLeave(TENANT_ID, { ...dto, documentUrl: undefined }, EMP_ID, ['employee']),
      ).rejects.toThrow(BadRequestException);
    });

    it('throws when insufficient balance', async () => {
      mockPrisma.leaveBalance.findFirst.mockResolvedValue({ ...mockBalance, balance: 1 });

      // Requesting 3 days with only 1 balance
      await expect(
        service.applyLeave(TENANT_ID, dto, EMP_ID, ['employee']),
      ).rejects.toThrow(BadRequestException);
    });
  });

  // ─────────────────────────────────────────────
  // Working Day Calculation
  // ─────────────────────────────────────────────

  describe('working day calculation (internal)', () => {
    it('excludes weekends correctly', async () => {
      // Monday to Friday = 5 working days
      const result = await service.applyLeave(
        TENANT_ID,
        { leaveTypeId: 'lt-cl', startDate: '2025-06-09', endDate: '2025-06-13' }, // Mon-Fri
        EMP_ID, ['employee'],
      );

      const createCall = mockPrisma.leaveRequest.create.mock.calls[0][0] as { data: { days: number } };
      expect(createCall.data.days).toBe(5);
    });

    it('counts 0.5 days for half-day leave', async () => {
      await service.applyLeave(
        TENANT_ID,
        { leaveTypeId: 'lt-cl', startDate: '2025-06-09', endDate: '2025-06-09', halfDay: 'morning' },
        EMP_ID, ['employee'],
      );

      const createCall = mockPrisma.leaveRequest.create.mock.calls[0][0] as { data: { days: number } };
      expect(createCall.data.days).toBe(0.5);
    });
  });

  // ─────────────────────────────────────────────
  // Approve / Reject
  // ─────────────────────────────────────────────

  describe('approveLeave', () => {
    beforeEach(() => {
      mockPrisma.leaveRequest.findFirst.mockResolvedValue({
        id: 'req-001', status: 'pending', employeeId: EMP_ID,
        leaveTypeId: 'lt-cl', days: 3,
        employee: { id: EMP_ID, firstName: 'Test', lastName: 'User' },
        leaveType: { id: 'lt-cl', name: 'Casual Leave', code: 'CL', paidLeave: true },
      });
      mockPrisma.leaveRequest.update.mockResolvedValue({
        id: 'req-001', status: 'approved',
        employee: { id: EMP_ID, firstName: 'Test', lastName: 'User' },
        leaveType: { id: 'lt-cl', name: 'Casual Leave', code: 'CL', paidLeave: true },
      });
      mockPrisma.leaveBalance.update.mockResolvedValue(mockBalance);
    });

    it('approves pending request and deducts balance', async () => {
      await service.approveLeave(TENANT_ID, 'req-001', {}, 'manager-001');

      expect(mockPrisma.leaveBalance.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ balance: { increment: -3 } }),
        }),
      );
      expect(mockEvents.emit).toHaveBeenCalledWith('leave.approved', expect.anything());
    });

    it('throws if request is not pending', async () => {
      mockPrisma.leaveRequest.findFirst.mockResolvedValue({
        id: 'req-001', status: 'approved', employeeId: EMP_ID,
        leaveTypeId: 'lt-cl', days: 3,
        employee: {}, leaveType: {},
      });

      await expect(
        service.approveLeave(TENANT_ID, 'req-001', {}, 'manager-001'),
      ).rejects.toThrow(BadRequestException);
    });
  });

  describe('cancelLeave', () => {
    it('cancels pending request without restoring balance', async () => {
      mockPrisma.leaveRequest.findFirst.mockResolvedValue({
        id: 'req-001', status: 'pending', employeeId: EMP_ID,
        leaveTypeId: 'lt-cl', days: 3, employee: {}, leaveType: {},
      });
      mockPrisma.leaveRequest.update.mockResolvedValue({ status: 'cancelled', employee: {}, leaveType: {} });

      await service.cancelLeave(TENANT_ID, 'req-001', EMP_ID);

      // Pending — no balance restoration needed
      expect(mockPrisma.leaveBalance.update).not.toHaveBeenCalled();
    });

    it('restores balance when cancelling approved leave', async () => {
      mockPrisma.leaveRequest.findFirst.mockResolvedValue({
        id: 'req-001', status: 'approved', employeeId: EMP_ID,
        leaveTypeId: 'lt-cl', days: 3, employee: {}, leaveType: {},
      });
      mockPrisma.leaveRequest.update.mockResolvedValue({ status: 'cancelled', employee: {}, leaveType: {} });
      mockPrisma.leaveBalance.update.mockResolvedValue(mockBalance);

      await service.cancelLeave(TENANT_ID, 'req-001', EMP_ID);

      expect(mockPrisma.leaveBalance.update).toHaveBeenCalledWith(
        expect.objectContaining({
          data: expect.objectContaining({ balance: { increment: 3 } }),
        }),
      );
    });
  });
});
