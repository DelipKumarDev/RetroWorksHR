import {
  Injectable, NotFoundException, BadRequestException,
  ConflictException, Logger,
} from '@nestjs/common';
import { PrismaClient, type Prisma } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import type {
  CreateLeaveRequestDto, ApproveLeaveDto, RejectLeaveDto,
  UpdateLeaveBalanceDto, LeaveRequestQueryDto,
} from './dto/leave.dto';

// India 2024 public holidays
const INDIA_PUBLIC_HOLIDAYS_2024 = [
  '2024-01-26', // Republic Day
  '2024-03-25', // Holi
  '2024-04-14', // Dr. Ambedkar Jayanti
  '2024-05-23', // Buddha Purnima
  '2024-08-15', // Independence Day
  '2024-10-02', // Gandhi Jayanti
  '2024-10-12', // Dussehra
  '2024-10-31', // Halloween (optional)
  '2024-11-01', // Diwali (Kannada Rajyotsava in KA)
  '2024-11-15', // Diwali Padwa
  '2024-12-25', // Christmas
  // Add more as needed
];

@Injectable()
export class LeaveService {
  private readonly logger = new Logger(LeaveService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ─────────────────────────────────────────────
  // APPLY FOR LEAVE
  // ─────────────────────────────────────────────

  async applyLeave(
    tenantId: string,
    dto: CreateLeaveRequestDto,
    requestedBy: string,
    requestingUserRoles: string[],
  ) {
    const employeeId = dto.employeeId ?? requestedBy;

    // HR can apply on behalf of employees
    if (dto.employeeId && dto.employeeId !== requestedBy) {
      const isHr = requestingUserRoles.some(r => ['hr-admin', 'super-admin'].includes(r));
      if (!isHr) throw new BadRequestException('Only HR can apply leave on behalf of others');
    }

    // Validate dates
    const startDate = new Date(dto.startDate);
    const endDate = new Date(dto.endDate);
    if (endDate < startDate) throw new BadRequestException('End date must be on or after start date');

    // Check if back-dated leave is allowed
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const backdatedDays = Math.floor((today.getTime() - startDate.getTime()) / 86_400_000);
    if (backdatedDays > 3) {
      throw new BadRequestException('Back-dated leave beyond 3 days is not allowed');
    }

    // Get leave type
    const leaveType = await this.prisma.leaveType.findFirst({
      where: { id: dto.leaveTypeId, tenantId, isActive: true },
    });
    if (!leaveType) throw new NotFoundException('Leave type not found');

    // Calculate working days
    const workingDays = this.calculateWorkingDays(startDate, endDate, dto.halfDay);

    if (workingDays <= 0) throw new BadRequestException('No working days in selected period');

    // Check document requirement
    if (leaveType.requiresDocument && !dto.documentUrl) {
      throw new BadRequestException(
        `${leaveType.name} requires a supporting document`,
      );
    }

    // Check existing leave (overlap)
    const overlap = await this.prisma.leaveRequest.findFirst({
      where: {
        tenantId,
        employeeId,
        status: { in: ['pending', 'approved', 'auto-approved'] },
        AND: [
          { startDate: { lte: endDate } },
          { endDate: { gte: startDate } },
        ],
      },
    });
    if (overlap) {
      throw new ConflictException(
        `Leave already exists for overlapping dates (${overlap.startDate.toISOString().slice(0, 10)} – ${overlap.endDate.toISOString().slice(0, 10)})`,
      );
    }

    // Check balance
    const balance = await this.getOrCreateBalance(tenantId, employeeId, dto.leaveTypeId);
    if (leaveType.paidLeave && balance.balance < workingDays) {
      throw new BadRequestException(
        `Insufficient leave balance. Available: ${balance.balance} days, Required: ${workingDays} days`,
      );
    }

    // Find approver (reporting manager)
    const employee = await this.prisma.employee.findFirst({
      where: { id: employeeId, tenantId },
      select: { managerId: true, firstName: true, lastName: true },
    });

    const request = await this.prisma.leaveRequest.create({
      data: {
        tenantId,
        employeeId,
        leaveTypeId: dto.leaveTypeId,
        startDate,
        endDate,
        halfDay: dto.halfDay,
        days: workingDays,
        reason: dto.reason,
        documentUrl: dto.documentUrl,
        status: 'pending',
        approverId: employee?.managerId,
        createdBy: requestedBy,
        updatedBy: requestedBy,
      },
      include: this.leaveRequestInclude(),
    });

    // Start approval workflow
    this.events.emit('leave.submitted', {
      tenantId,
      leaveRequest: request,
      employeeName: `${employee?.firstName} ${employee?.lastName}`,
      approverId: employee?.managerId,
    });

    return request;
  }

  // ─────────────────────────────────────────────
  // APPROVE / REJECT
  // ─────────────────────────────────────────────

  async approveLeave(
    tenantId: string,
    requestId: string,
    dto: ApproveLeaveDto,
    approvedBy: string,
  ) {
    const request = await this.getLeaveRequest(tenantId, requestId);
    if (request.status !== 'pending') {
      throw new BadRequestException('Only pending requests can be approved');
    }

    // Deduct from balance
    await this.adjustBalance(
      tenantId, request.employeeId, request.leaveTypeId,
      -request.days, `Approved leave ${request.id}`,
    );

    const approved = await this.prisma.leaveRequest.update({
      where: { id: requestId },
      data: {
        status: 'approved',
        approvedAt: new Date(),
        approvedBy,
        approverComments: dto.comments,
        updatedBy: approvedBy,
      },
      include: this.leaveRequestInclude(),
    });

    this.events.emit('leave.approved', {
      tenantId, leaveRequest: approved, approvedBy,
    });

    return approved;
  }

  async rejectLeave(
    tenantId: string,
    requestId: string,
    dto: RejectLeaveDto,
    rejectedBy: string,
  ) {
    const request = await this.getLeaveRequest(tenantId, requestId);
    if (request.status !== 'pending') {
      throw new BadRequestException('Only pending requests can be rejected');
    }

    const rejected = await this.prisma.leaveRequest.update({
      where: { id: requestId },
      data: {
        status: 'rejected',
        rejectionReason: dto.reason,
        updatedBy: rejectedBy,
      },
      include: this.leaveRequestInclude(),
    });

    this.events.emit('leave.rejected', { tenantId, leaveRequest: rejected, rejectedBy });

    return rejected;
  }

  async cancelLeave(tenantId: string, requestId: string, cancelledBy: string) {
    const request = await this.getLeaveRequest(tenantId, requestId);

    if (!['pending', 'approved', 'auto-approved'].includes(request.status)) {
      throw new BadRequestException('Cannot cancel a leave in its current state');
    }

    // If approved, restore balance
    if (['approved', 'auto-approved'].includes(request.status)) {
      await this.adjustBalance(
        tenantId, request.employeeId, request.leaveTypeId,
        +request.days, `Cancelled leave ${request.id}`,
      );
    }

    return this.prisma.leaveRequest.update({
      where: { id: requestId },
      data: { status: 'cancelled', updatedBy: cancelledBy },
      include: this.leaveRequestInclude(),
    });
  }

  // ─────────────────────────────────────────────
  // LIST
  // ─────────────────────────────────────────────

  async listLeaveRequests(
    tenantId: string,
    query: LeaveRequestQueryDto,
    userId: string,
    userRoles: string[],
  ) {
    const isHr = userRoles.some(r => ['hr-admin', 'super-admin'].includes(r));
    const limit = Math.min(query.limit ?? 25, 100);

    let where: Prisma.LeaveRequestWhereInput = {
      tenantId,
      ...(query.employeeId && { employeeId: query.employeeId }),
      ...(query.leaveTypeId && { leaveTypeId: query.leaveTypeId }),
      ...(query.status && { status: query.status }),
      ...(query.from && { startDate: { gte: new Date(query.from) } }),
      ...(query.to && { endDate: { lte: new Date(query.to) } }),
      ...(query.cursor && { id: { lt: query.cursor } }),
    };

    // Managers see their team; regular employees see own requests
    if (!isHr) {
      if (query.teamOnly) {
        // Get direct reports
        const directReports = await this.prisma.employee.findMany({
          where: { tenantId, managerId: userId },
          select: { id: true },
        });
        where.employeeId = { in: directReports.map(e => e.id) };
      } else {
        where.employeeId = userId;
      }
    }

    const requests = await this.prisma.leaveRequest.findMany({
      where,
      include: this.leaveRequestInclude(),
      orderBy: { createdAt: 'desc' },
      take: limit + 1,
    });

    const hasMore = requests.length > limit;
    const data = requests.slice(0, limit);

    return {
      data,
      hasMore,
      nextCursor: hasMore ? data[data.length - 1]?.id : undefined,
    };
  }

  // ─────────────────────────────────────────────
  // BALANCES
  // ─────────────────────────────────────────────

  async getMyBalances(tenantId: string, employeeId: string) {
    const leaveTypes = await this.prisma.leaveType.findMany({
      where: { tenantId, isActive: true },
    });

    const balances = await Promise.all(
      leaveTypes.map(lt => this.getOrCreateBalance(tenantId, employeeId, lt.id)),
    );

    return balances.map((balance, i) => ({
      leaveType: leaveTypes[i],
      balance: balance.balance,
      used: balance.used,
      pending: balance.pending,
      entitled: balance.entitled,
    }));
  }

  async manualAdjustBalance(
    tenantId: string,
    dto: UpdateLeaveBalanceDto,
    adjustedBy: string,
  ) {
    const balance = await this.getOrCreateBalance(
      tenantId, dto.employeeId, dto.leaveTypeId,
    );

    const updated = await this.prisma.leaveBalance.update({
      where: { id: balance.id },
      data: {
        balance: { increment: dto.adjustment },
        entitled: { increment: dto.adjustment > 0 ? dto.adjustment : 0 },
      },
    });

    this.events.emit('audit.created', {
      tenantId, userId: adjustedBy, action: 'UPDATE',
      resource: 'leave-balance', resourceId: balance.id,
      newData: { adjustment: dto.adjustment, reason: dto.reason },
    });

    return updated;
  }

  // ─────────────────────────────────────────────
  // LEAVE TYPES
  // ─────────────────────────────────────────────

  async getLeaveTypes(tenantId: string) {
    return this.prisma.leaveType.findMany({
      where: { tenantId, isActive: true },
      orderBy: { name: 'asc' },
    });
  }

  // ─────────────────────────────────────────────
  // CALENDAR / HOLIDAYS
  // ─────────────────────────────────────────────

  async getLeaveCalendar(tenantId: string, month: number, year: number) {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);

    const [approvedLeaves, holidays] = await Promise.all([
      this.prisma.leaveRequest.findMany({
        where: {
          tenantId,
          status: { in: ['approved', 'auto-approved'] },
          AND: [
            { startDate: { lte: endDate } },
            { endDate: { gte: startDate } },
          ],
        },
        include: {
          employee: { select: { firstName: true, lastName: true, avatarUrl: true, departmentId: true } },
          leaveType: { select: { name: true, code: true } },
        },
      }),
      // Filter holidays for this month
      INDIA_PUBLIC_HOLIDAYS_2024.filter(h => {
        const d = new Date(h);
        return d.getMonth() + 1 === month && d.getFullYear() === year;
      }),
    ]);

    return { approvedLeaves, holidays, month, year };
  }

  async getLeaveRequest(tenantId: string, requestId: string) {
    const request = await this.prisma.leaveRequest.findFirst({
      where: { id: requestId, tenantId },
      include: this.leaveRequestInclude(),
    });
    if (!request) throw new NotFoundException('Leave request not found');
    return request;
  }

  // ─────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────

  private calculateWorkingDays(
    start: Date, end: Date, halfDay?: 'morning' | 'afternoon',
  ): number {
    if (halfDay) return 0.5;

    let days = 0;
    const current = new Date(start);

    while (current <= end) {
      const dayOfWeek = current.getDay();
      const dateStr = current.toISOString().slice(0, 10);
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
      const isHoliday = INDIA_PUBLIC_HOLIDAYS_2024.includes(dateStr);

      if (!isWeekend && !isHoliday) days++;
      current.setDate(current.getDate() + 1);
    }

    return days;
  }

  private async getOrCreateBalance(tenantId: string, employeeId: string, leaveTypeId: string) {
    const year = new Date().getFullYear();

    const balance = await this.prisma.leaveBalance.findFirst({
      where: { tenantId, employeeId, leaveTypeId, year },
    });

    if (balance) return balance;

    const leaveType = await this.prisma.leaveType.findUnique({ where: { id: leaveTypeId } });
    const entitled = leaveType?.maxDaysPerYear ?? 0;

    return this.prisma.leaveBalance.create({
      data: {
        tenantId, employeeId, leaveTypeId,
        year, entitled, balance: entitled, used: 0, pending: 0,
      },
    });
  }

  private async adjustBalance(
    tenantId: string, employeeId: string, leaveTypeId: string,
    delta: number, _reason: string,
  ) {
    const balance = await this.getOrCreateBalance(tenantId, employeeId, leaveTypeId);
    await this.prisma.leaveBalance.update({
      where: { id: balance.id },
      data: {
        balance: { increment: delta },
        used: { increment: -delta },
      },
    });
  }

  private leaveRequestInclude() {
    return {
      employee: { select: { id: true, firstName: true, lastName: true, avatarUrl: true, employeeCode: true } },
      leaveType: { select: { id: true, name: true, code: true, paidLeave: true } },
    } as const;
  }
}
