import {
  IsString, IsOptional, IsEnum, IsDateString,
  IsInt, IsBoolean, IsNumber, Min, IsArray,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export enum LeaveUnit {
  DAYS = 'days',
  HOURS = 'hours',
}

export enum LeaveRequestStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
  CANCELLED = 'cancelled',
  AUTO_APPROVED = 'auto-approved',
}

export class CreateLeaveRequestDto {
  @ApiProperty()
  @IsString()
  leaveTypeId: string;

  @ApiProperty({ example: '2024-03-10' })
  @IsDateString()
  startDate: string;

  @ApiProperty({ example: '2024-03-14' })
  @IsDateString()
  endDate: string;

  @ApiPropertyOptional({ description: 'Half day options: morning, afternoon' })
  @IsOptional()
  @IsEnum(['morning', 'afternoon'])
  halfDay?: 'morning' | 'afternoon';

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  reason?: string;

  @ApiPropertyOptional({ description: 'Medical certificate URL if required' })
  @IsOptional()
  @IsString()
  documentUrl?: string;

  @ApiPropertyOptional({ description: 'Employee ID — HR applying on behalf' })
  @IsOptional()
  @IsString()
  employeeId?: string;
}

export class ApproveLeaveDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  comments?: string;
}

export class RejectLeaveDto {
  @ApiProperty({ description: 'Reason for rejection' })
  @IsString()
  reason: string;
}

export class UpdateLeaveBalanceDto {
  @ApiProperty()
  @IsString()
  employeeId: string;

  @ApiProperty()
  @IsString()
  leaveTypeId: string;

  @ApiProperty()
  @IsNumber()
  adjustment: number; // positive = credit, negative = debit

  @ApiProperty()
  @IsString()
  reason: string;
}

export class LeaveRequestQueryDto {
  @IsOptional()
  @IsString()
  employeeId?: string;

  @IsOptional()
  @IsString()
  leaveTypeId?: string;

  @IsOptional()
  @IsEnum(LeaveRequestStatus)
  status?: LeaveRequestStatus;

  @IsOptional()
  @IsDateString()
  from?: string;

  @IsOptional()
  @IsDateString()
  to?: string;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  limit?: number = 25;

  @IsOptional()
  @IsString()
  cursor?: string;

  @ApiPropertyOptional({ description: 'My team requests only' })
  @IsOptional()
  @IsBoolean()
  teamOnly?: boolean;
}
