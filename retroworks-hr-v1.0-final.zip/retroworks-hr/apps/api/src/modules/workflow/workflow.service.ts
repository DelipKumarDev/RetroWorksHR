import {
  Injectable, NotFoundException, ConflictException, BadRequestException, Logger,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import type { WorkflowDefinition, WorkflowNode, WorkflowTransition } from '@retroworks/types';

export interface CreateWorkflowDto {
  name: string;
  description?: string;
  module: string;
  entityType: string;
  nodes: WorkflowNode[];
  transitions: WorkflowTransition[];
  slaConfig?: Record<string, unknown>;
}

export interface StartWorkflowDto {
  definitionId: string;
  entityId: string;
  entityType: string;
  data?: Record<string, unknown>;
  startedBy: string;
}

@Injectable()
export class WorkflowService {
  private readonly logger = new Logger(WorkflowService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ─────────────────────────────────────────────
  // DEFINITION CRUD
  // ─────────────────────────────────────────────

  async createDefinition(tenantId: string, dto: CreateWorkflowDto, createdBy: string) {
    // Check name uniqueness
    const existing = await this.prisma.workflowDefinition.findFirst({
      where: { tenantId, name: dto.name, status: { not: 'archived' } },
    });
    if (existing) throw new ConflictException(`Workflow "${dto.name}" already exists`);

    // Validate DAG: no cycles
    this.validateDag(dto.nodes, dto.transitions);

    return this.prisma.workflowDefinition.create({
      data: {
        tenantId,
        name: dto.name,
        description: dto.description,
        module: dto.module,
        entityType: dto.entityType,
        version: 1,
        status: 'draft',
        nodes: dto.nodes as object[],
        transitions: dto.transitions as object[],
        slaConfig: dto.slaConfig as object | undefined,
        createdBy,
        updatedBy: createdBy,
      },
    });
  }

  async updateDefinition(
    tenantId: string,
    id: string,
    dto: Partial<CreateWorkflowDto>,
    updatedBy: string,
  ) {
    const def = await this.getDefinition(tenantId, id);
    if (def.status === 'active') {
      throw new BadRequestException('Cannot edit an active workflow — create a new version');
    }

    if (dto.nodes && dto.transitions) {
      this.validateDag(dto.nodes, dto.transitions);
    }

    return this.prisma.workflowDefinition.update({
      where: { id },
      data: {
        ...(dto.name && { name: dto.name }),
        ...(dto.description !== undefined && { description: dto.description }),
        ...(dto.nodes && { nodes: dto.nodes as object[] }),
        ...(dto.transitions && { transitions: dto.transitions as object[] }),
        ...(dto.slaConfig && { slaConfig: dto.slaConfig as object }),
        updatedBy,
        updatedAt: new Date(),
      },
    });
  }

  async publishDefinition(tenantId: string, id: string, publishedBy: string) {
    const def = await this.getDefinition(tenantId, id);
    if (def.status === 'active') throw new BadRequestException('Already published');

    // Archive old active version for same entityType
    await this.prisma.workflowDefinition.updateMany({
      where: { tenantId, entityType: def.entityType, status: 'active' },
      data: { status: 'archived', updatedBy: publishedBy },
    });

    return this.prisma.workflowDefinition.update({
      where: { id },
      data: { status: 'active', publishedAt: new Date(), updatedBy: publishedBy },
    });
  }

  async rollbackDefinition(tenantId: string, id: string, restoredBy: string) {
    // Create a new draft copy of the given version
    const def = await this.getDefinition(tenantId, id);
    const latest = await this.prisma.workflowDefinition.findFirst({
      where: { tenantId, name: def.name },
      orderBy: { version: 'desc' },
    });

    return this.prisma.workflowDefinition.create({
      data: {
        tenantId,
        name: def.name,
        description: def.description,
        module: def.module,
        entityType: def.entityType,
        version: (latest?.version ?? def.version) + 1,
        status: 'draft',
        nodes: def.nodes as object[],
        transitions: def.transitions as object[],
        slaConfig: def.slaConfig as object | undefined,
        createdBy: restoredBy,
        updatedBy: restoredBy,
      },
    });
  }

  async listDefinitions(tenantId: string, module?: string) {
    return this.prisma.workflowDefinition.findMany({
      where: { tenantId, deletedAt: null, ...(module && { module }) },
      orderBy: [{ name: 'asc' }, { version: 'desc' }],
      select: {
        id: true, name: true, description: true, module: true,
        entityType: true, version: true, status: true,
        publishedAt: true, createdAt: true,
        _count: { select: { instances: true } },
      },
    });
  }

  async getDefinition(tenantId: string, id: string) {
    const def = await this.prisma.workflowDefinition.findFirst({
      where: { id, tenantId, deletedAt: null },
    });
    if (!def) throw new NotFoundException(`Workflow definition ${id} not found`);
    return def;
  }

  // ─────────────────────────────────────────────
  // INSTANCE EXECUTION
  // ─────────────────────────────────────────────

  async startWorkflow(tenantId: string, dto: StartWorkflowDto) {
    const def = await this.getDefinition(tenantId, dto.definitionId);
    if (def.status !== 'active') {
      throw new BadRequestException('Workflow definition is not active');
    }

    const nodes = def.nodes as unknown as WorkflowNode[];
    const startNode = nodes.find(n => n.type === 'start');
    if (!startNode) throw new BadRequestException('Workflow has no start node');

    // Find first state after start
    const transitions = def.transitions as unknown as WorkflowTransition[];
    const firstTransition = transitions.find(t => t.fromNodeId === startNode.id);
    const firstNodeId = firstTransition?.toNodeId ?? startNode.id;

    const instance = await this.prisma.workflowInstance.create({
      data: {
        tenantId,
        definitionId: def.id,
        entityId: dto.entityId,
        entityType: dto.entityType,
        currentNodeId: firstNodeId,
        status: 'running',
        data: (dto.data ?? {}) as object,
        createdBy: dto.startedBy,
      },
    });

    // Create task for first node
    const firstNode = nodes.find(n => n.id === firstNodeId);
    if (firstNode) {
      await this.createTaskForNode(instance.id, firstNode, def.slaConfig as Record<string, unknown> | null);
    }

    this.events.emit('workflow.started', { tenantId, instance, definition: def });
    return instance;
  }

  async completeTask(
    tenantId: string,
    instanceId: string,
    taskId: string,
    action: 'approve' | 'reject' | 'complete',
    comment: string | undefined,
    completedBy: string,
  ) {
    const instance = await this.prisma.workflowInstance.findFirst({
      where: { id: instanceId, tenantId, status: 'running' },
      include: { definition: true },
    });
    if (!instance) throw new NotFoundException('Workflow instance not found or not running');

    const task = await this.prisma.workflowTask.findFirst({
      where: { id: taskId, instanceId, status: 'pending' },
    });
    if (!task) throw new NotFoundException('Task not found or already completed');

    // Complete the task
    await this.prisma.workflowTask.update({
      where: { id: taskId },
      data: { status: action === 'reject' ? 'rejected' : 'completed', action, comment, completedAt: new Date() },
    });

    const nodes = instance.definition.nodes as unknown as WorkflowNode[];
    const transitions = instance.definition.transitions as unknown as WorkflowTransition[];

    // Find next node based on action
    const nextTransition = transitions.find(t =>
      t.fromNodeId === instance.currentNodeId &&
      (t.label.toLowerCase() === action || !t.label),
    );

    if (!nextTransition) {
      // No more transitions — complete the workflow
      await this.prisma.workflowInstance.update({
        where: { id: instanceId },
        data: { status: action === 'reject' ? 'failed' : 'completed', completedAt: new Date() },
      });
      this.events.emit(`workflow.${action}d`, { tenantId, instance, action });
      return instance;
    }

    const nextNode = nodes.find(n => n.id === nextTransition.toNodeId);

    // Move to next node
    await this.prisma.workflowInstance.update({
      where: { id: instanceId },
      data: { currentNodeId: nextTransition.toNodeId },
    });

    if (nextNode?.type === 'end') {
      await this.prisma.workflowInstance.update({
        where: { id: instanceId },
        data: { status: 'completed', completedAt: new Date() },
      });
    } else if (nextNode) {
      await this.createTaskForNode(instanceId, nextNode, instance.definition.slaConfig as Record<string, unknown> | null);
    }

    this.events.emit(`workflow.task.${action}d`, { tenantId, instance, task, action });
    return instance;
  }

  async getMyTasks(tenantId: string, userId: string) {
    return this.prisma.workflowTask.findMany({
      where: {
        status: 'pending',
        OR: [{ assigneeId: userId }],
        instance: { tenantId, status: 'running' },
      },
      include: {
        instance: {
          select: {
            id: true, entityId: true, entityType: true, data: true, startedAt: true,
            definition: { select: { name: true, module: true } },
          },
        },
      },
      orderBy: [{ dueAt: 'asc' }, { createdAt: 'asc' }],
    });
  }

  // ─────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────

  private async createTaskForNode(
    instanceId: string,
    node: WorkflowNode,
    slaConfig: Record<string, unknown> | null,
  ) {
    const slaHours = node.config.slaHours ?? (slaConfig?.['warningHours'] as number | undefined);
    const dueAt = slaHours ? new Date(Date.now() + slaHours * 3_600_000) : undefined;

    await this.prisma.workflowTask.create({
      data: {
        instanceId,
        nodeId: node.id,
        assigneeRole: node.config.assigneeRoles?.[0],
        status: 'pending',
        dueAt,
      },
    });
  }

  private validateDag(nodes: WorkflowNode[], transitions: WorkflowTransition[]): void {
    // Basic cycle detection with DFS
    const adj = new Map<string, string[]>();
    for (const node of nodes) adj.set(node.id, []);
    for (const t of transitions) adj.get(t.fromNodeId)?.push(t.toNodeId);

    const visited = new Set<string>();
    const inStack = new Set<string>();

    const dfs = (nodeId: string): boolean => {
      visited.add(nodeId);
      inStack.add(nodeId);
      for (const neighbor of adj.get(nodeId) ?? []) {
        if (!visited.has(neighbor) && dfs(neighbor)) return true;
        if (inStack.has(neighbor)) return true;
      }
      inStack.delete(nodeId);
      return false;
    };

    for (const node of nodes) {
      if (!visited.has(node.id) && dfs(node.id)) {
        throw new BadRequestException('Workflow contains a cycle — invalid DAG');
      }
    }
  }
}
