import {
  Controller, Get, Post, Patch, Delete,
  Body, Param, Query, UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { WorkflowService, type CreateWorkflowDto } from './workflow.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

@ApiTags('admin')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('workflows')
export class WorkflowController {
  constructor(private readonly workflowService: WorkflowService) {}

  @Post()
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Create workflow definition' })
  create(@Body() dto: CreateWorkflowDto, @CurrentUser() user: JwtPayload) {
    return this.workflowService.createDefinition(user.tid, dto, user.sub);
  }

  @Get()
  @ApiOperation({ summary: 'List all workflow definitions' })
  list(@Query('module') module: string | undefined, @CurrentUser() user: JwtPayload) {
    return this.workflowService.listDefinitions(user.tid, module);
  }

  @Get('tasks/mine')
  @ApiOperation({ summary: 'Get pending tasks assigned to me' })
  myTasks(@CurrentUser() user: JwtPayload) {
    return this.workflowService.getMyTasks(user.tid, user.sub);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get workflow definition' })
  getOne(@Param('id') id: string, @CurrentUser() user: JwtPayload) {
    return this.workflowService.getDefinition(user.tid, id);
  }

  @Patch(':id')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Update draft workflow definition' })
  update(@Param('id') id: string, @Body() dto: Partial<CreateWorkflowDto>, @CurrentUser() user: JwtPayload) {
    return this.workflowService.updateDefinition(user.tid, id, dto, user.sub);
  }

  @Post(':id/publish')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Publish workflow (makes it active)' })
  publish(@Param('id') id: string, @CurrentUser() user: JwtPayload) {
    return this.workflowService.publishDefinition(user.tid, id, user.sub);
  }

  @Post(':id/rollback')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Create a new draft from an older version' })
  rollback(@Param('id') id: string, @CurrentUser() user: JwtPayload) {
    return this.workflowService.rollbackDefinition(user.tid, id, user.sub);
  }

  @Post('instances/:instanceId/tasks/:taskId/complete')
  @ApiOperation({ summary: 'Complete a workflow task (approve/reject/complete)' })
  completeTask(
    @Param('instanceId') instanceId: string,
    @Param('taskId') taskId: string,
    @Body() body: { action: 'approve' | 'reject' | 'complete'; comment?: string },
    @CurrentUser() user: JwtPayload,
  ) {
    return this.workflowService.completeTask(
      user.tid, instanceId, taskId, body.action, body.comment, user.sub,
    );
  }
}
