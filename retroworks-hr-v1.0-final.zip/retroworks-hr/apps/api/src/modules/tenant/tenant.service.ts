import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import type { HrModule, TenantSettings } from '@retroworks/types';

@Injectable()
export class TenantService {
  private readonly logger = new Logger(TenantService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  async findById(id: string) {
    const tenant = await this.prisma.tenant.findUnique({ where: { id } });
    if (!tenant) throw new NotFoundException('Tenant not found');
    return tenant;
  }

  async findBySlug(slug: string) {
    const tenant = await this.prisma.tenant.findUnique({ where: { slug } });
    if (!tenant) throw new NotFoundException(`Tenant '${slug}' not found`);
    return tenant;
  }

  async updateSettings(
    tenantId: string,
    settings: Partial<TenantSettings>,
    updatedBy: string,
  ) {
    const tenant = await this.findById(tenantId);
    const merged = { ...(tenant.settings as object), ...settings };

    const updated = await this.prisma.tenant.update({
      where: { id: tenantId },
      data: { settings: merged, updatedAt: new Date() },
    });

    this.events.emit('audit.created', {
      tenantId, userId: updatedBy, action: 'UPDATE',
      resource: 'tenant', resourceId: tenantId,
      oldData: tenant.settings as object,
      newData: merged,
    });

    return updated;
  }

  async toggleModule(
    tenantId: string,
    module: HrModule,
    enable: boolean,
    updatedBy: string,
  ) {
    const tenant = await this.findById(tenantId);
    let modules = [...tenant.enabledModules];

    if (enable && !modules.includes(module)) {
      modules.push(module);
    } else if (!enable) {
      modules = modules.filter(m => m !== module);
    }

    return this.prisma.tenant.update({
      where: { id: tenantId },
      data: { enabledModules: modules },
    });
  }

  async getFeatureFlags(tenantId: string): Promise<Record<string, boolean>> {
    const flags = await this.prisma.tenantFeatureFlag.findMany({
      where: { tenantId },
    });
    return Object.fromEntries(flags.map(f => [f.key, f.enabled]));
  }

  async setFeatureFlag(
    tenantId: string,
    key: string,
    enabled: boolean,
    updatedBy: string,
  ) {
    const flag = await this.prisma.tenantFeatureFlag.upsert({
      where: { tenantId_key: { tenantId, key } },
      update: { enabled },
      create: { tenantId, key, enabled },
    });

    this.events.emit('audit.created', {
      tenantId, userId: updatedBy, action: 'UPDATE',
      resource: 'feature-flag', resourceId: key,
      newData: { key, enabled },
    });

    return flag;
  }

  async getDepartments(tenantId: string) {
    return this.prisma.department.findMany({
      where: { tenantId, deletedAt: null, isActive: true },
      include: {
        parent: { select: { id: true, name: true } },
        _count: { select: { employees: true } },
      },
      orderBy: { name: 'asc' },
    });
  }

  async getDesignations(tenantId: string) {
    return this.prisma.designation.findMany({
      where: { tenantId, deletedAt: null, isActive: true },
      include: { grade: true, _count: { select: { employees: true } } },
      orderBy: { name: 'asc' },
    });
  }

  async getLocations(tenantId: string) {
    return this.prisma.location.findMany({
      where: { tenantId, deletedAt: null, isActive: true },
      include: { _count: { select: { employees: true } } },
      orderBy: { name: 'asc' },
    });
  }

  async getGrades(tenantId: string) {
    return this.prisma.grade.findMany({
      where: { tenantId },
      orderBy: { level: 'asc' },
    });
  }

  async getRoles(tenantId: string) {
    return this.prisma.role.findMany({
      where: { tenantId },
      include: { _count: { select: { users: true } } },
      orderBy: { name: 'asc' },
    });
  }
}
