import { Controller, Get, Patch, Post, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { TenantService } from './tenant.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

@ApiTags('admin')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('tenant')
export class TenantController {
  constructor(private readonly tenantService: TenantService) {}

  @Get('settings')
  @ApiOperation({ summary: 'Get tenant settings' })
  async getSettings(@CurrentUser() user: JwtPayload) {
    return this.tenantService.findById(user.tid);
  }

  @Patch('settings')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Update tenant settings' })
  async updateSettings(@Body() body: Record<string, unknown>, @CurrentUser() user: JwtPayload) {
    return this.tenantService.updateSettings(user.tid, body as never, user.sub);
  }

  @Get('feature-flags')
  @ApiOperation({ summary: 'Get feature flags for tenant' })
  async getFeatureFlags(@CurrentUser() user: JwtPayload) {
    return this.tenantService.getFeatureFlags(user.tid);
  }

  @Post('feature-flags/:key')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Toggle a feature flag' })
  async setFeatureFlag(
    @Param('key') key: string,
    @Body('enabled') enabled: boolean,
    @CurrentUser() user: JwtPayload,
  ) {
    return this.tenantService.setFeatureFlag(user.tid, key, enabled, user.sub);
  }

  @Get('departments')
  @ApiOperation({ summary: 'List departments' })
  async getDepartments(@CurrentUser() user: JwtPayload) {
    return this.tenantService.getDepartments(user.tid);
  }

  @Get('designations')
  @ApiOperation({ summary: 'List designations' })
  async getDesignations(@CurrentUser() user: JwtPayload) {
    return this.tenantService.getDesignations(user.tid);
  }

  @Get('locations')
  @ApiOperation({ summary: 'List locations' })
  async getLocations(@CurrentUser() user: JwtPayload) {
    return this.tenantService.getLocations(user.tid);
  }

  @Get('grades')
  @ApiOperation({ summary: 'List grade levels' })
  async getGrades(@CurrentUser() user: JwtPayload) {
    return this.tenantService.getGrades(user.tid);
  }

  @Get('roles')
  @ApiOperation({ summary: 'List roles and their permissions' })
  async getRoles(@CurrentUser() user: JwtPayload) {
    return this.tenantService.getRoles(user.tid);
  }
}
