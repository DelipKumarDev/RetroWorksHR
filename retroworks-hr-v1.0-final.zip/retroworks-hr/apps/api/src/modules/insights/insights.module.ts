import { Injectable, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { RedisLockService } from '../../common/security/redis-lock.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Cron } from '@nestjs/schedule';
import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

@Injectable()
export class InsightsService {
  private readonly logger = new Logger(InsightsService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
    private readonly redisLock: RedisLockService,
  ) {}

  async getAttritionRisk(tenantId: string, limit = 20) {
    const employees = await this.prisma.employee.findMany({
      where: { tenantId, status: 'active', deletedAt: null },
      include: {
        designation: { select: { name: true } },
        department: { select: { name: true } },
        performanceReviews: { orderBy: { createdAt: 'desc' }, take: 2, select: { managerRating: true } },
        leaveRequests: {
          where: { status: { in: ['approved', 'auto-approved'] }, startDate: { gte: new Date(new Date().getFullYear(), 0, 1) } },
          select: { startDate: true, totalDays: true },
        },
      },
    });

    return employees.map(emp => {
      let score = 0; const flags: string[] = [];
      if (emp.dateOfJoining) {
        const tenureMonths = (Date.now() - new Date(emp.dateOfJoining).getTime()) / (30 * 86_400_000);
        if (tenureMonths < 12) { score += 15; flags.push('New hire (<1yr)'); }
        if (tenureMonths < 6) { score += 10; flags.push('Very new (<6mo)'); }
      }
      if (emp.probationEndDate && new Date(emp.probationEndDate) > new Date()) { score += 10; flags.push('On probation'); }
      const ratings = (emp.performanceReviews as any[]).map((r: any) => r.managerRating).filter(Boolean);
      if (ratings.length >= 2 && ratings[0] < 3 && ratings[1] < 3) { score += 25; flags.push('Low perf (2 cycles)'); }
      else if (ratings.length >= 1 && ratings[0] < 2.5) { score += 15; flags.push('Low perf rating'); }
      const totalLeave = (emp.leaveRequests as any[]).reduce((s: number, lr: any) => s + (lr.totalDays ?? 0), 0);
      if (totalLeave > 20) { score += 15; flags.push(`High leave (${totalLeave}d)`); }
      const mfLeaves = (emp.leaveRequests as any[]).filter((lr: any) => { const d = new Date(lr.startDate).getDay(); return d === 1 || d === 5; }).length;
      if (emp.leaveRequests.length > 5 && mfLeaves / emp.leaveRequests.length > 0.6) { score += 10; flags.push('Mon/Fri pattern'); }
      return {
        employeeId: emp.id, name: `${emp.firstName} ${emp.lastName}`, employeeCode: emp.employeeCode,
        designation: (emp.designation as any)?.name, department: (emp.department as any)?.name,
        riskScore: Math.min(score, 100),
        riskLevel: score >= 60 ? 'high' : score >= 30 ? 'medium' : 'low' as any,
        flags,
      };
    }).filter(e => e.riskScore > 0).sort((a, b) => b.riskScore - a.riskScore).slice(0, limit);
  }

  async getPayrollAnomalies(tenantId: string, month: number, year: number) {
    const payslips = await this.prisma.payslip.findMany({
      where: { tenantId, month, year },
      include: { employee: { select: { firstName: true, lastName: true, employeeCode: true, department: { select: { name: true } } } } },
    });
    const prevSlips = await this.prisma.payslip.findMany({
      where: { tenantId, month: month === 1 ? 12 : month - 1, year: month === 1 ? year - 1 : year },
      select: { employeeId: true, grossPay: true, netPay: true },
    });
    const prevMap = new Map((prevSlips as any[]).map((p: any) => [p.employeeId, p]));

    const anomalies = payslips.map((ps: any) => {
      const issues: string[] = [];
      const prev: any = prevMap.get(ps.employeeId);
      if ((ps.netPay as number) <= 0) issues.push(`Zero/negative net: ₹${ps.netPay}`);
      if (prev) { const chg = Math.abs(((ps.grossPay as number) - prev.grossPay) / prev.grossPay) * 100; if (chg > 20) issues.push(`Gross variance ${chg.toFixed(1)}%`); }
      if ((ps.lopDays as number) > 5) issues.push(`High LOP: ${ps.lopDays} days`);
      if ((ps.tdsDeducted as number) < 0) issues.push(`Negative TDS: ₹${ps.tdsDeducted}`);
      return issues.length > 0 ? { employeeId: ps.employeeId, name: `${ps.employee.firstName} ${ps.employee.lastName}`, employeeCode: ps.employee.employeeCode, department: ps.employee.department?.name, grossPay: ps.grossPay, netPay: ps.netPay, lopDays: ps.lopDays, tds: ps.tdsDeducted, issues } : null;
    }).filter(Boolean);

    return { month, year, totalPayslips: payslips.length, anomalyCount: anomalies.length, anomalies };
  }

  async getLeaveInsights(tenantId: string) {
    const year = new Date().getFullYear();
    const today = new Date();
    const highUtil = await this.prisma.leaveRequest.groupBy({
      by: ['employeeId'], where: { tenantId, status: { in: ['approved', 'auto-approved'] }, startDate: { gte: new Date(`${year}-01-01`) } },
      _sum: { totalDays: true }, orderBy: { _sum: { totalDays: 'desc' } }, having: { totalDays: { _sum: { gt: 20 } } },
    });
    // H-10: Fixed N+1 — batch fetch all employees in one query
    const topHighUtil = highUtil.slice(0, 10);
    const empIds = topHighUtil.map((g: any) => g.employeeId);
    const empRecords = await this.prisma.employee.findMany({
      where: { id: { in: empIds } },
      select: { id: true, firstName: true, lastName: true, employeeCode: true, department: { select: { name: true } } },
    });
    const empMap = new Map(empRecords.map(e => [e.id, e]));
    const highUtilizers = topHighUtil.map((g: any) => {
      const emp = empMap.get(g.employeeId);
      return { ...emp, employeeId: g.employeeId, totalDays: g._sum.totalDays };
    });
    // H-10: Fixed N+1 — single groupBy query instead of 6 aggregate calls
    const sixMonthsAgo = new Date(today.getFullYear(), today.getMonth() - 5, 1);
    const leaveByMonth = await this.prisma.leaveRequest.groupBy({
      by: ['startDate'],
      where: {
        tenantId,
        status: { in: ['approved', 'auto-approved'] },
        startDate: { gte: sixMonthsAgo, lte: today },
      },
      _sum: { totalDays: true },
      _count: { id: true },
    });
    // Aggregate into months client-side (much cheaper than 6 DB round-trips)
    const monthBuckets = new Map<string, { totalDays: number; requests: number }>();
    for (const row of leaveByMonth) {
      const d = new Date(row.startDate);
      const key = d.toLocaleString('en-IN', { month: 'short', year: 'numeric' });
      const existing = monthBuckets.get(key) ?? { totalDays: 0, requests: 0 };
      monthBuckets.set(key, {
        totalDays: existing.totalDays + (row._sum.totalDays ?? 0),
        requests: existing.requests + row._count.id,
      });
    }
    const monthlyTrend = Array.from({ length: 6 }, (_, i) => {
      const d = new Date(today.getFullYear(), today.getMonth() - (5 - i), 1);
      const key = d.toLocaleString('en-IN', { month: 'short', year: 'numeric' });
      const data = monthBuckets.get(key) ?? { totalDays: 0, requests: 0 };
      return { month: key, ...data };
    });
    return { highUtilizers, monthlyTrend, summary: { flaggedEmployees: highUtil.length } };
  }

  async getHeadcountForecast(tenantId: string) {
    const today = new Date();
    const history = await Promise.all(Array.from({ length: 12 }, (_, i) => {
      const d = new Date(today.getFullYear(), today.getMonth() - (11 - i), 1);
      return this.prisma.employee.count({ where: { tenantId, status: 'active', dateOfJoining: { lte: new Date(d.getFullYear(), d.getMonth() + 1, 0) }, deletedAt: null } }).then(count => ({ month: d.toLocaleString('en-IN', { month: 'short', year: 'numeric' }), count }));
    }));
    const n = history.length;
    const ys = history.map(h => h.count);
    const xMean = (n - 1) / 2;
    const yMean = ys.reduce((s, y) => s + y, 0) / n;
    const slope = ys.reduce((s, y, i) => s + (i - xMean) * (y - yMean), 0) / ys.reduce((s, _, i) => s + (i - xMean) ** 2, 0);
    const intercept = yMean - slope * xMean;
    const forecast = Array.from({ length: 3 }, (_, i) => {
      const d = new Date(today.getFullYear(), today.getMonth() + i + 1, 1);
      return { month: d.toLocaleString('en-IN', { month: 'short', year: 'numeric' }), projected: Math.max(0, Math.round(intercept + slope * (n + i))), isForecast: true };
    });
    return { history, forecast, trend: slope > 0.5 ? 'growing' : slope < -0.5 ? 'declining' : 'stable', monthlyAddition: Math.round(slope) };
  }

  async getPayrollProjection(tenantId: string) {
    const today = new Date(); const year = today.getFullYear();
    const actuals = await Promise.all(Array.from({ length: 3 }, (_, i) => {
      const month = today.getMonth() - i; const m = month <= 0 ? month + 12 : month; const y = month <= 0 ? year - 1 : year;
      return this.prisma.payrollRun.aggregate({ where: { tenantId, month: m, year: y, status: { in: ['approved', 'processed'] } }, _sum: { totalGross: true, totalNet: true } }).then(r => ({ label: new Date(y, m - 1).toLocaleString('en-IN', { month: 'short', year: 'numeric' }), gross: r._sum.totalGross ?? 0, net: r._sum.totalNet ?? 0, isForecast: false }));
    }));
    const avgGross = actuals.reduce((s, a) => s + (a.gross as number), 0) / Math.max(actuals.length, 1);
    const forecast = Array.from({ length: 3 }, (_, i) => {
      const d = new Date(year, today.getMonth() + i + 1, 1);
      return { label: d.toLocaleString('en-IN', { month: 'short', year: 'numeric' }), gross: Math.round(avgGross * (1 + i * 0.005)), isForecast: true };
    });
    return { actuals: actuals.reverse(), forecast, averageMonthlyGross: Math.round(avgGross), annualProjection: Math.round(avgGross * 12) };
  }

  async getNineBoxData(tenantId: string, cycleId: string) {
    const reviews = await this.prisma.performanceReview.findMany({
      where: { tenantId, cycleId, managerRating: { not: null } },
      include: { employee: { select: { firstName: true, lastName: true, designation: { select: { name: true } } } }, goals: { select: { progress: true } } },
    });
    return (reviews as any[]).map((r: any) => {
      const avgGoal = r.goals.length > 0 ? r.goals.reduce((s: number, g: any) => s + (g.progress ?? 0), 0) / r.goals.length : 50;
      const perf = r.managerRating; const pot = Math.min(5, Math.max(1, avgGoal / 20));
      const pL = perf <= 2 ? 'low' : perf <= 3.5 ? 'mid' : 'high'; const ptL = pot <= 2 ? 'low' : pot <= 3.5 ? 'mid' : 'high';
      const box = ({ 'high-high': 'Star', 'high-mid': 'High Performer', 'high-low': 'Backbone', 'mid-high': 'High Potential', 'mid-mid': 'Core Player', 'mid-low': 'Effective', 'low-high': 'Enigma', 'low-mid': 'Inconsistent', 'low-low': 'At Risk' } as Record<string, string>)[`${pL}-${ptL}`] ?? 'Core Player';
      return { employeeId: r.employeeId, name: `${r.employee.firstName} ${r.employee.lastName}`, designation: r.employee.designation?.name, performance: perf, potential: pot, box };
    });
  }

  async getInsightsDashboard(tenantId: string) {
    const [risk, leave, hc] = await Promise.all([this.getAttritionRisk(tenantId, 10), this.getLeaveInsights(tenantId), this.getHeadcountForecast(tenantId)]);
    return { attritionRisk: { highRisk: risk.filter(e => e.riskLevel === 'high').length, mediumRisk: risk.filter(e => e.riskLevel === 'medium').length, topRisk: risk.slice(0, 5) }, leaveInsights: { flaggedEmployees: leave.summary.flaggedEmployees, monthlyTrend: leave.monthlyTrend }, headcount: { trend: hc.trend, monthlyAddition: hc.monthlyAddition } };
  }

  @Cron('0 6 * * 1', { name: 'weekly-insights', timeZone: 'Asia/Kolkata' })
  async runWeeklyInsights() {
    // M-06: Distributed lock — only ONE instance runs this cron even on multi-instance deploy
    const acquired = await this.redisLock.acquireCronLock('weekly-insights', 3600); // 1hr TTL
    if (!acquired) {
      this.logger.debug('Weekly insights already running on another instance — skipping');
      return;
    }
    try {
      const tenants = await this.prisma.tenant.findMany({ where: { status: 'active' }, select: { id: true } });
      for (const t of tenants) {
        const risk = await this.getAttritionRisk(t.id, 100);
        const high = risk.filter(e => e.riskLevel === 'high');
        if (high.length) this.events.emit('insights.attrition.alert', { tenantId: t.id, count: high.length, employees: high.slice(0, 3) });
      }
    } finally {
      await this.redisLock.releaseCronLock('weekly-insights');
    }
  }
}

@ApiTags('insights')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('hr-admin', 'super-admin')
@Controller('insights')
export class InsightsController {
  constructor(private readonly svc: InsightsService) {}
  @Get('dashboard') @ApiOperation({ summary: 'HR insights summary' }) dashboard(@CurrentUser() u: JwtPayload) { return this.svc.getInsightsDashboard(u.tid); }
  @Get('attrition-risk') @ApiOperation({ summary: 'Employee attrition risk scores' }) attritionRisk(@Query('limit') limit = 20, @CurrentUser() u: JwtPayload) { return this.svc.getAttritionRisk(u.tid, +limit); }
  @Get('payroll-anomalies') @ApiOperation({ summary: 'Payroll anomaly detection' }) payrollAnomalies(@Query('month') month: number, @Query('year') year: number, @CurrentUser() u: JwtPayload) { const now = new Date(); return this.svc.getPayrollAnomalies(u.tid, month ?? now.getMonth() + 1, year ?? now.getFullYear()); }
  @Get('leave') @ApiOperation({ summary: 'Leave utilization insights' }) leaveInsights(@CurrentUser() u: JwtPayload) { return this.svc.getLeaveInsights(u.tid); }
  @Get('headcount-forecast') @ApiOperation({ summary: 'Headcount forecast (linear regression)' }) hcForecast(@CurrentUser() u: JwtPayload) { return this.svc.getHeadcountForecast(u.tid); }
  @Get('payroll-projection') @ApiOperation({ summary: 'Monthly payroll cost projection' }) payrollProjection(@CurrentUser() u: JwtPayload) { return this.svc.getPayrollProjection(u.tid); }
  @Get('nine-box') @ApiOperation({ summary: '9-box performance grid' }) nineBox(@Query('cycleId') cycleId: string, @CurrentUser() u: JwtPayload) { return this.svc.getNineBoxData(u.tid, cycleId); }
}

@Module({ controllers: [InsightsController], providers: [InsightsService], exports: [InsightsService] })
export class InsightsModule {}
