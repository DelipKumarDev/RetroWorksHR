import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import { Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

const BUILTIN_TEMPLATES: Record<string, { name: string; body: string; description: string }> = {
  offer_letter: { name: 'Offer Letter', description: 'Standard offer letter for new hires', body: `Dear {{candidate.name}},\n\nWe are delighted to offer you the position of **{{designation}}** in the **{{department}}** department at **{{company.name}}**.\n\nAnnual CTC: Rs.{{ctc}}\nJoining Date: {{joiningDate}}\nReporting To: {{reportingManager}}\nProbation: {{probationMonths}} months\nNotice Period: {{noticePeriodDays}} days\n\nPlease sign and return by {{acceptanceDeadline}}.\n\n{{signatory.name}}\n{{signatory.designation}}\n{{company.name}}` },
  appointment_letter: { name: 'Appointment Letter', description: 'Formal appointment letter', body: `Dear {{employee.firstName}} {{employee.lastName}},\n\nThis confirms your appointment as **{{designation}}** in **{{department}}** at **{{company.name}}**, effective {{dateOfJoining}}.\n\nCTC: Rs.{{ctc}} per annum.\nNotice Period: {{noticePeriodDays}} days.\nPF, ESI, PT, and TDS applicable as per law.\n\n{{signatory.name}}\nHR Department` },
  experience_letter: { name: 'Experience Letter', description: 'Relieving and experience letter', body: `TO WHOM IT MAY CONCERN\n\nThis certifies that **{{employee.firstName}} {{employee.lastName}}** (ID: {{employee.employeeCode}}) was employed with **{{company.name}}** from {{dateOfJoining}} to {{lastWorkingDay}} as **{{designation}}** in **{{department}}**.\n\nWe wish them the best in their future endeavors.\n\nIssued: {{issueDate}}\n{{signatory.name}}\n{{company.name}}` },
  promotion_letter: { name: 'Promotion Letter', description: 'Promotion with revised CTC', body: `Dear {{employee.firstName}},\n\nCongratulations! You are promoted to **{{newDesignation}}** effective {{effectiveDate}}.\n\nNew CTC: Rs.{{newCTC}} ({{revisionPercent}}% revision from Rs.{{previousCTC}}).\n\n{{signatory.name}}\n{{company.name}}` },
  warning_letter: { name: 'Warning Letter', description: 'Formal disciplinary warning', body: `Dear {{employee.firstName}},\n\nThis is a formal **{{warningLevel}} Warning** regarding {{subject}}.\n\nIncident: {{incidentDescription}} on {{incidentDate}}.\n\nImmediate corrective action is expected. Further violations may lead to termination.\n\n{{signatory.name}}\nHR Department` },
  payslip_text: { name: 'Payslip (Text)', description: 'Plain-text payslip', body: `SALARY SLIP - {{month}} {{year}} | {{company.name}}\nEmployee: {{employee.firstName}} {{employee.lastName}} ({{employee.employeeCode}})\nDesignation: {{designation}} | Dept: {{department}}\n\nGROSS: Rs.{{grossPay}} | DEDUCTIONS: Rs.{{totalDeductions}} | NET: Rs.{{netPay}}\nPF: Rs.{{pfEmployee}} | TDS: Rs.{{tds}} | PT: Rs.{{professionalTax}}` },
};

@Injectable()
export class DocumentsService {
  private readonly logger = new Logger(DocumentsService.name);

  constructor(private readonly prisma: PrismaClient, private readonly events: EventEmitter2, private readonly config: ConfigService) {}

  async listTemplates(tenantId: string, type?: string) {
    const custom = await this.prisma.documentTemplate.findMany({ where: { tenantId, deletedAt: null, ...(type && { type }) }, orderBy: { createdAt: 'desc' }, select: { id: true, name: true, type: true, isBuiltin: true, version: true, createdAt: true } });
    const builtins = Object.entries(BUILTIN_TEMPLATES).map(([key, t]) => ({ id: key, name: t.name, type: key, isBuiltin: true, description: t.description }));
    return { builtins, custom };
  }

  async getTemplate(tenantId: string, templateId: string) {
    const custom = await this.prisma.documentTemplate.findFirst({ where: { id: templateId, tenantId, deletedAt: null } });
    if (custom) return custom;
    const builtin = BUILTIN_TEMPLATES[templateId];
    if (builtin) return { id: templateId, ...builtin, isBuiltin: true };
    throw new NotFoundException('Template not found');
  }

  async createTemplate(tenantId: string, dto: any, createdBy: string) {
    return this.prisma.documentTemplate.create({ data: { tenantId, name: dto.name, type: dto.type, body: dto.body, description: dto.description, isShared: dto.isShared ?? false, signatoryName: dto.signatoryName, signatoryDesignation: dto.signatoryDesignation, version: 1, isBuiltin: false, createdBy, updatedBy: createdBy } });
  }

  async updateTemplate(tenantId: string, id: string, dto: any, updatedBy: string) {
    const t = await this.prisma.documentTemplate.findFirst({ where: { id, tenantId } });
    if (!t) throw new NotFoundException('Template not found');
    if (t.isBuiltin) throw new BadRequestException('Cannot edit built-in templates — clone first');
    return this.prisma.documentTemplate.update({ where: { id }, data: { ...dto, version: { increment: 1 }, updatedBy } });
  }

  async cloneTemplate(tenantId: string, templateId: string, clonedBy: string) {
    const source = await this.getTemplate(tenantId, templateId);
    return this.createTemplate(tenantId, { name: `${source.name} (Custom)`, type: (source as any).type, body: (source as any).body, description: (source as any).description }, clonedBy);
  }

  async deleteTemplate(tenantId: string, id: string) {
    const t = await this.prisma.documentTemplate.findFirst({ where: { id, tenantId } });
    if (!t) throw new NotFoundException('Template not found');
    if (t.isBuiltin) throw new BadRequestException('Cannot delete built-in templates');
    return this.prisma.documentTemplate.update({ where: { id }, data: { deletedAt: new Date() } });
  }

  async generateDocument(tenantId: string, dto: { templateId: string; employeeId?: string; candidateId?: string; variables?: Record<string, unknown>; saveToVault?: boolean }, generatedBy: string) {
    const template = await this.getTemplate(tenantId, dto.templateId);
    const ctx = await this.buildContext(tenantId, dto);
    const content = this.interpolate((template as any).body, ctx);
    if (dto.saveToVault) {
      const doc = await this.prisma.generatedDocument.create({ data: { tenantId, templateId: dto.templateId, employeeId: dto.employeeId, content, format: 'html', variables: ctx as any, generatedBy, status: 'generated' } });
      this.events.emit('document.generated', { tenantId, documentId: doc.id, employeeId: dto.employeeId });
      return { id: doc.id, content, format: 'html' };
    }
    return { content, format: 'html' };
  }

  async listDocumentVault(tenantId: string, employeeId?: string) {
    return this.prisma.generatedDocument.findMany({ where: { tenantId, ...(employeeId && { employeeId }), deletedAt: null }, orderBy: { createdAt: 'desc' }, include: { employee: { select: { firstName: true, lastName: true, employeeCode: true } } } });
  }

  async getDocument(tenantId: string, docId: string) {
    const doc = await this.prisma.generatedDocument.findFirst({ where: { id: docId, tenantId, deletedAt: null } });
    if (!doc) throw new NotFoundException('Document not found');
    return doc;
  }

  private async buildContext(tenantId: string, dto: any): Promise<Record<string, unknown>> {
    const ctx: Record<string, unknown> = {};
    const tenant = await this.prisma.tenant.findFirst({ where: { id: tenantId } });
    const settings = await this.prisma.tenantSettings.findFirst({ where: { tenantId } });
    ctx.company = { name: tenant?.name, gstin: (settings as any)?.gstin };
    ctx.signatory = { name: (settings as any)?.signatoryName ?? 'HR Manager', designation: (settings as any)?.signatoryDesignation ?? 'Human Resources' };
    ctx.issueDate = new Date().toLocaleDateString('en-IN', { dateStyle: 'long' });
    if (dto.employeeId) {
      const emp = await this.prisma.employee.findFirst({ where: { id: dto.employeeId, tenantId }, include: { designation: true, department: true, location: true, manager: { select: { firstName: true, lastName: true } }, bankDetail: true } });
      if (emp) {
        ctx.employee = emp; ctx.designation = (emp.designation as any)?.name; ctx.department = (emp.department as any)?.name; ctx.location = (emp.location as any)?.name;
        ctx.dateOfJoining = emp.dateOfJoining ? new Date(emp.dateOfJoining).toLocaleDateString('en-IN') : '';
        ctx.reportingManager = (emp.manager as any) ? `${(emp.manager as any).firstName} ${(emp.manager as any).lastName}` : '';
        ctx.bankName = (emp.bankDetail as any)?.bankName; ctx.ifscCode = (emp.bankDetail as any)?.ifscCode;
        ctx.maskedAccount = (emp.bankDetail as any)?.accountNumber ? 'XXXX' + (emp.bankDetail as any).accountNumber.slice(-4) : '';
        if (emp.dateOfJoining) { const m = Math.floor((Date.now() - new Date(emp.dateOfJoining).getTime()) / (30*86400000)); ctx.tenure = m >= 12 ? `${Math.floor(m/12)} year(s) ${m%12} month(s)` : `${m} month(s)`; }
      }
    }
    if (dto.candidateId) { const c = await this.prisma.candidate.findFirst({ where: { id: dto.candidateId } }); if (c) ctx.candidate = c; }
    return { ...ctx, ...(dto.variables ?? {}) };
  }

  private interpolate(t: string, ctx: Record<string, unknown>): string {
    return t.replace(/\{\{(\w+(?:\.\w+)*)\}\}/g, (_, p) => { const v = p.split('.').reduce((o: any, k: string) => o?.[k], ctx); return v != null ? String(v) : ''; });
  }
}

@ApiTags('documents')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('documents')
export class DocumentsController {
  constructor(private readonly svc: DocumentsService) {}
  @Get('templates') listTemplates(@Query('type') t: string | undefined, @CurrentUser() u: JwtPayload) { return this.svc.listTemplates(u.tid, t); }
  @Get('templates/:id') getTemplate(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getTemplate(u.tid, id); }
  @Post('templates') @Roles('hr-admin','super-admin') createTemplate(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createTemplate(u.tid, dto, u.sub); }
  @Put('templates/:id') @Roles('hr-admin','super-admin') updateTemplate(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateTemplate(u.tid, id, dto, u.sub); }
  @Post('templates/:id/clone') @Roles('hr-admin','super-admin') cloneTemplate(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.cloneTemplate(u.tid, id, u.sub); }
  @Delete('templates/:id') @Roles('hr-admin','super-admin') deleteTemplate(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteTemplate(u.tid, id); }
  @Post('generate') @Roles('hr-admin','super-admin','manager') @ApiOperation({ summary: 'Generate document from template' }) generate(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.generateDocument(u.tid, dto, u.sub); }
  @Get('vault') listVault(@Query('employeeId') e: string | undefined, @CurrentUser() u: JwtPayload) { return this.svc.listDocumentVault(u.tid, e); }
  @Get('vault/me') myDocuments(@CurrentUser() u: JwtPayload) { return this.svc.listDocumentVault(u.tid, u.sub); }
  @Get('vault/:id') getDocument(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getDocument(u.tid, id); }
}

@Module({ controllers: [DocumentsController], providers: [DocumentsService], exports: [DocumentsService] })
export class DocumentsModule {}
