import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaClient, Prisma } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import { Cron } from '@nestjs/schedule';
import { Controller, Get, Post, Put, Delete, Patch, Body, Param, Query, UseGuards, Res } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import type { Response } from 'express';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── Field Catalogue (module → available fields) ──────────────────────

export const FIELD_CATALOGUE = {
  employees: [
    { key: 'employeeCode', label: 'Employee ID', type: 'string' },
    { key: 'firstName', label: 'First Name', type: 'string' },
    { key: 'lastName', label: 'Last Name', type: 'string' },
    { key: 'email', label: 'Email', type: 'string' },
    { key: 'designation.name', label: 'Designation', type: 'string' },
    { key: 'department.name', label: 'Department', type: 'string' },
    { key: 'location.name', label: 'Location', type: 'string' },
    { key: 'status', label: 'Status', type: 'enum', options: ['active', 'inactive', 'on-notice', 'absconding'] },
    { key: 'employmentType', label: 'Employment Type', type: 'enum', options: ['full-time', 'part-time', 'contract', 'intern'] },
    { key: 'dateOfJoining', label: 'Date of Joining', type: 'date' },
    { key: 'probationEndDate', label: 'Probation End', type: 'date' },
    { key: 'ctc', label: 'CTC (Annual)', type: 'number' },
    { key: 'gender', label: 'Gender', type: 'enum', options: ['male', 'female', 'other'] },
  ],
  leave: [
    { key: 'employee.firstName', label: 'Employee First Name', type: 'string' },
    { key: 'employee.lastName', label: 'Employee Last Name', type: 'string' },
    { key: 'leaveType.name', label: 'Leave Type', type: 'string' },
    { key: 'startDate', label: 'Start Date', type: 'date' },
    { key: 'endDate', label: 'End Date', type: 'date' },
    { key: 'totalDays', label: 'Total Days', type: 'number' },
    { key: 'status', label: 'Status', type: 'enum', options: ['pending', 'approved', 'rejected', 'cancelled'] },
    { key: 'reason', label: 'Reason', type: 'string' },
  ],
  payroll: [
    { key: 'employee.firstName', label: 'Employee First Name', type: 'string' },
    { key: 'employee.lastName', label: 'Employee Last Name', type: 'string' },
    { key: 'employee.department.name', label: 'Department', type: 'string' },
    { key: 'month', label: 'Month', type: 'number' },
    { key: 'year', label: 'Year', type: 'number' },
    { key: 'grossPay', label: 'Gross Pay', type: 'number' },
    { key: 'netPay', label: 'Net Pay', type: 'number' },
    { key: 'pfEmployee', label: 'PF (Employee)', type: 'number' },
    { key: 'esiEmployee', label: 'ESI (Employee)', type: 'number' },
    { key: 'tdsDeducted', label: 'TDS', type: 'number' },
    { key: 'professionalTax', label: 'Professional Tax', type: 'number' },
    { key: 'lopDays', label: 'LOP Days', type: 'number' },
    { key: 'workingDays', label: 'Working Days', type: 'number' },
  ],
  attendance: [
    { key: 'employee.firstName', label: 'Employee First Name', type: 'string' },
    { key: 'employee.lastName', label: 'Employee Last Name', type: 'string' },
    { key: 'date', label: 'Date', type: 'date' },
    { key: 'status', label: 'Status', type: 'enum', options: ['present', 'absent', 'half-day', 'holiday', 'weekend', 'on-leave'] },
    { key: 'checkIn', label: 'Check In', type: 'datetime' },
    { key: 'checkOut', label: 'Check Out', type: 'datetime' },
    { key: 'workingHours', label: 'Working Hours', type: 'number' },
    { key: 'isLate', label: 'Late', type: 'boolean' },
  ],
  performance: [
    { key: 'employee.firstName', label: 'Employee First Name', type: 'string' },
    { key: 'employee.lastName', label: 'Employee Last Name', type: 'string' },
    { key: 'cycle.name', label: 'Review Cycle', type: 'string' },
    { key: 'selfRating', label: 'Self Rating', type: 'number' },
    { key: 'managerRating', label: 'Manager Rating', type: 'number' },
    { key: 'finalRating', label: 'Final Rating', type: 'number' },
    { key: 'status', label: 'Status', type: 'enum', options: ['not-started', 'self-review', 'manager-review', 'completed'] },
  ],
};

export const AGGREGATIONS = ['COUNT', 'SUM', 'AVG', 'MIN', 'MAX'] as const;
type Aggregation = typeof AGGREGATIONS[number];

// ─── Prebuilt India Reports ───────────────────────────────────────────

export const PREBUILT_REPORTS = [
  { id: 'headcount', name: 'Headcount Report', description: 'Total active employees by department and location', category: 'Workforce' },
  { id: 'attrition', name: 'Attrition Report', description: 'Employees who left in a period with attrition rate %', category: 'Workforce' },
  { id: 'leave_balance', name: 'Leave Balance Report', description: 'Current leave balances for all employees', category: 'Leave' },
  { id: 'leave_utilization', name: 'Leave Utilization Report', description: 'Leave taken vs entitled days by employee', category: 'Leave' },
  { id: 'pf_summary', name: 'PF Summary', description: 'Monthly PF contribution (employer + employee)', category: 'Statutory' },
  { id: 'esi_summary', name: 'ESI Summary', description: 'Monthly ESI contribution by employee', category: 'Statutory' },
  { id: 'tds_summary', name: 'TDS Summary', description: 'Monthly TDS deductions with annualized income', category: 'Statutory' },
  { id: 'payroll_variance', name: 'Payroll Variance Report', description: 'Month-over-month payroll cost changes', category: 'Payroll' },
  { id: 'attendance_compliance', name: 'Attendance Compliance', description: 'Late arrivals, absenteeism by department', category: 'Attendance' },
  { id: 'performance_distribution', name: 'Performance Distribution', description: 'Rating bell curve and 9-box breakdown', category: 'Performance' },
  { id: 'new_joiners', name: 'New Joiners Report', description: 'Employees who joined in a given period', category: 'Workforce' },
  { id: 'cost_centre', name: 'Cost Centre Analysis', description: 'Total payroll cost by department', category: 'Payroll' },
];

// ─── Service ─────────────────────────────────────────────────────────

@Injectable()
export class ReportBuilderService {
  private readonly logger = new Logger(ReportBuilderService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
    private readonly config: ConfigService,
  ) {}

  // ─── Custom Report CRUD ───────────────────────────────────────────

  async listReports(tenantId: string, userId: string, includeShared = true) {
    return this.prisma.savedReport.findMany({
      where: {
        tenantId,
        deletedAt: null,
        ...(includeShared ? { OR: [{ createdBy: userId }, { isShared: true }] } : { createdBy: userId }),
      },
      orderBy: { updatedAt: 'desc' },
      select: { id: true, name: true, description: true, module: true, isShared: true, chartType: true, createdBy: true, updatedAt: true, scheduledDelivery: true },
    });
  }

  async getReport(tenantId: string, reportId: string) {
    const report = await this.prisma.savedReport.findFirst({ where: { id: reportId, tenantId, deletedAt: null } });
    if (!report) throw new NotFoundException('Report not found');
    return report;
  }

  async saveReport(tenantId: string, dto: {
    name: string; description?: string; module: string;
    fields: string[]; filters: any[]; groupBy?: string; aggregations?: any[];
    chartType?: string; isShared?: boolean;
    scheduledDelivery?: { frequency: string; emails: string[]; enabled: boolean };
  }, createdBy: string) {
    return this.prisma.savedReport.create({
      data: {
        tenantId, name: dto.name, description: dto.description,
        module: dto.module, fields: dto.fields as any,
        filters: dto.filters as any, groupBy: dto.groupBy,
        aggregations: dto.aggregations as any ?? [],
        chartType: dto.chartType ?? 'table',
        isShared: dto.isShared ?? false,
        scheduledDelivery: dto.scheduledDelivery as any ?? { enabled: false },
        createdBy, updatedBy: createdBy,
      },
    });
  }

  async updateReport(tenantId: string, reportId: string, dto: any, updatedBy: string) {
    const report = await this.prisma.savedReport.findFirst({ where: { id: reportId, tenantId } });
    if (!report) throw new NotFoundException('Report not found');
    return this.prisma.savedReport.update({ where: { id: reportId }, data: { ...dto, updatedBy } });
  }

  async deleteReport(tenantId: string, reportId: string) {
    return this.prisma.savedReport.update({ where: { id: reportId }, data: { deletedAt: new Date() } });
  }

  // ─── Query Engine ─────────────────────────────────────────────────

  async runReport(tenantId: string, config: {
    module: string; fields: string[]; filters?: any[];
    groupBy?: string; aggregations?: { field: string; fn: Aggregation }[];
    sortBy?: string; sortOrder?: 'asc' | 'desc'; limit?: number;
  }) {
    const limit = Math.min(config.limit ?? 1000, 10000);

    switch (config.module) {
      case 'employees': return this.queryEmployees(tenantId, config, limit);
      case 'leave': return this.queryLeave(tenantId, config, limit);
      case 'payroll': return this.queryPayroll(tenantId, config, limit);
      case 'attendance': return this.queryAttendance(tenantId, config, limit);
      case 'performance': return this.queryPerformance(tenantId, config, limit);
      default: throw new BadRequestException(`Unknown module: ${config.module}`);
    }
  }

  private async queryEmployees(tenantId: string, config: any, limit: number) {
    const where: any = { tenantId, deletedAt: null };
    for (const f of config.filters ?? []) {
      this.applyFilter(where, f);
    }
    const rows = await this.prisma.employee.findMany({
      where,
      include: { designation: { select: { name: true } }, department: { select: { name: true } }, location: { select: { name: true } } },
      take: limit,
      orderBy: config.sortBy ? { [config.sortBy]: config.sortOrder ?? 'asc' } : { firstName: 'asc' },
    });
    return { rows: rows.map(r => this.flatten(r)), total: rows.length, fields: config.fields };
  }

  private async queryLeave(tenantId: string, config: any, limit: number) {
    const where: any = { tenantId };
    for (const f of config.filters ?? []) this.applyFilter(where, f);
    const rows = await this.prisma.leaveRequest.findMany({
      where,
      include: { employee: { select: { firstName: true, lastName: true, employeeCode: true } }, leaveType: { select: { name: true, code: true } } },
      take: limit,
      orderBy: { startDate: 'desc' },
    });
    return { rows: rows.map(r => this.flatten(r)), total: rows.length, fields: config.fields };
  }

  private async queryPayroll(tenantId: string, config: any, limit: number) {
    const where: any = { tenantId };
    for (const f of config.filters ?? []) this.applyFilter(where, f);
    const rows = await this.prisma.payslip.findMany({
      where,
      include: { employee: { select: { firstName: true, lastName: true, employeeCode: true, department: { select: { name: true } } } } },
      take: limit,
      orderBy: [{ year: 'desc' }, { month: 'desc' }],
    });
    return { rows: rows.map(r => this.flatten(r)), total: rows.length, fields: config.fields };
  }

  private async queryAttendance(tenantId: string, config: any, limit: number) {
    const where: any = { tenantId };
    for (const f of config.filters ?? []) this.applyFilter(where, f);
    const rows = await this.prisma.attendance.findMany({
      where,
      include: { employee: { select: { firstName: true, lastName: true, employeeCode: true } } },
      take: limit,
      orderBy: { date: 'desc' },
    });
    return { rows: rows.map(r => this.flatten(r)), total: rows.length, fields: config.fields };
  }

  private async queryPerformance(tenantId: string, config: any, limit: number) {
    const where: any = { tenantId };
    for (const f of config.filters ?? []) this.applyFilter(where, f);
    const rows = await this.prisma.performanceReview.findMany({
      where,
      include: { employee: { select: { firstName: true, lastName: true, employeeCode: true } }, cycle: { select: { name: true } } },
      take: limit,
    });
    return { rows: rows.map(r => this.flatten(r)), total: rows.length, fields: config.fields };
  }

  // ─── Prebuilt India Reports ───────────────────────────────────────

  async runPrebuiltReport(tenantId: string, reportId: string, params: { month?: number; year?: number; startDate?: string; endDate?: string }) {
    const now = new Date();
    const month = params.month ?? now.getMonth() + 1;
    const year = params.year ?? now.getFullYear();
    const startDate = params.startDate ? new Date(params.startDate) : new Date(year, 0, 1);
    const endDate = params.endDate ? new Date(params.endDate) : new Date(year, 11, 31);

    switch (reportId) {
      case 'headcount': return this.reportHeadcount(tenantId);
      case 'attrition': return this.reportAttrition(tenantId, startDate, endDate);
      case 'leave_balance': return this.reportLeaveBalance(tenantId);
      case 'pf_summary': return this.reportPFSummary(tenantId, month, year);
      case 'esi_summary': return this.reportESISummary(tenantId, month, year);
      case 'tds_summary': return this.reportTDSSummary(tenantId, month, year);
      case 'payroll_variance': return this.reportPayrollVariance(tenantId, month, year);
      case 'attendance_compliance': return this.reportAttendanceCompliance(tenantId, month, year);
      case 'new_joiners': return this.reportNewJoiners(tenantId, startDate, endDate);
      case 'cost_centre': return this.reportCostCentre(tenantId, month, year);
      default: throw new BadRequestException(`Unknown prebuilt report: ${reportId}`);
    }
  }

  private async reportHeadcount(tenantId: string) {
    const byDept = await this.prisma.employee.groupBy({
      by: ['departmentId'],
      where: { tenantId, status: 'active', deletedAt: null },
      _count: { id: true },
    });
    const depts = await this.prisma.department.findMany({ where: { tenantId }, select: { id: true, name: true } });
    const deptMap = new Map(depts.map(d => [d.id, d.name]));
    const rows = byDept.map((g: any) => ({ department: deptMap.get(g.departmentId) ?? 'Unassigned', headcount: g._count.id }));
    const total = await this.prisma.employee.count({ where: { tenantId, status: 'active', deletedAt: null } });
    return { rows, total, summary: { totalActive: total } };
  }

  private async reportAttrition(tenantId: string, startDate: Date, endDate: Date) {
    const exited = await this.prisma.employee.findMany({
      where: { tenantId, status: { in: ['inactive', 'absconding'] }, updatedAt: { gte: startDate, lte: endDate }, deletedAt: null },
      select: { firstName: true, lastName: true, employeeCode: true, department: { select: { name: true } }, dateOfJoining: true, updatedAt: true },
    });
    const avgActive = await this.prisma.employee.count({ where: { tenantId, status: 'active' } });
    const rate = avgActive > 0 ? ((exited.length / avgActive) * 100).toFixed(2) : '0';
    return { rows: exited, total: exited.length, summary: { attritionRate: `${rate}%`, exited: exited.length, currentActive: avgActive } };
  }

  private async reportLeaveBalance(tenantId: string) {
    const balances = await this.prisma.leaveBalance.findMany({
      where: { tenantId, year: new Date().getFullYear() },
      include: { employee: { select: { firstName: true, lastName: true, employeeCode: true, department: { select: { name: true } } } }, leaveType: { select: { name: true, code: true } } },
      orderBy: [{ employee: { firstName: 'asc' } }],
    });
    return { rows: balances.map(b => this.flatten(b)), total: balances.length };
  }

  private async reportPFSummary(tenantId: string, month: number, year: number) {
    const payslips = await this.prisma.payslip.findMany({
      where: { tenantId, month, year },
      include: { employee: { select: { firstName: true, lastName: true, employeeCode: true, department: { select: { name: true } } } } },
    });
    const rows = (payslips as any[]).map(p => ({
      employeeCode: p.employee.employeeCode,
      name: `${p.employee.firstName} ${p.employee.lastName}`,
      department: p.employee.department?.name,
      grossPay: p.grossPay, pfEmployee: p.pfEmployee, pfEmployer: p.pfEmployer,
      totalPF: Number(p.pfEmployee ?? 0) + Number(p.pfEmployer ?? 0),
    }));
    const totals = rows.reduce((s, r) => ({ pfEmployee: s.pfEmployee + Number(r.pfEmployee ?? 0), pfEmployer: s.pfEmployer + Number(r.pfEmployer ?? 0), totalPF: s.totalPF + Number(r.totalPF) }), { pfEmployee: 0, pfEmployer: 0, totalPF: 0 });
    return { rows, total: rows.length, month, year, summary: totals };
  }

  private async reportESISummary(tenantId: string, month: number, year: number) {
    const payslips = await this.prisma.payslip.findMany({ where: { tenantId, month, year }, include: { employee: { select: { firstName: true, lastName: true, employeeCode: true } } } });
    const rows = (payslips as any[]).map(p => ({ employeeCode: p.employee.employeeCode, name: `${p.employee.firstName} ${p.employee.lastName}`, grossPay: p.grossPay, esiEmployee: p.esiEmployee, esiEmployer: p.esiEmployer, totalESI: Number(p.esiEmployee ?? 0) + Number(p.esiEmployer ?? 0) }));
    return { rows, total: rows.length, month, year, summary: { totalESI: rows.reduce((s, r) => s + r.totalESI, 0) } };
  }

  private async reportTDSSummary(tenantId: string, month: number, year: number) {
    const payslips = await this.prisma.payslip.findMany({ where: { tenantId, month, year }, include: { employee: { select: { firstName: true, lastName: true, employeeCode: true } } } });
    const rows = (payslips as any[]).map(p => ({ employeeCode: p.employee.employeeCode, name: `${p.employee.firstName} ${p.employee.lastName}`, grossPay: p.grossPay, tds: p.tdsDeducted, annualizedIncome: p.annualizedIncome, taxRegime: p.taxRegime }));
    return { rows, total: rows.length, month, year, summary: { totalTDS: rows.reduce((s, r) => s + Number(r.tds ?? 0), 0) } };
  }

  private async reportPayrollVariance(tenantId: string, month: number, year: number) {
    const curr = await this.prisma.payrollRun.findFirst({ where: { tenantId, month, year, status: { in: ['processed', 'approved'] } } });
    const prevM = month === 1 ? 12 : month - 1;
    const prevY = month === 1 ? year - 1 : year;
    const prev = await this.prisma.payrollRun.findFirst({ where: { tenantId, month: prevM, year: prevY, status: { in: ['processed', 'approved'] } } });
    return {
      current: { month, year, gross: curr?.totalGross, net: curr?.totalNet, headcount: curr?.processedCount },
      previous: { month: prevM, year: prevY, gross: prev?.totalGross, net: prev?.totalNet, headcount: prev?.processedCount },
      variance: curr && prev ? {
        grossChange: Number(curr.totalGross ?? 0) - Number(prev.totalGross ?? 0),
        grossChangePct: prev.totalGross ? (((Number(curr.totalGross ?? 0) - Number(prev.totalGross)) / Number(prev.totalGross)) * 100).toFixed(2) : '0',
      } : null,
    };
  }

  private async reportAttendanceCompliance(tenantId: string, month: number, year: number) {
    const start = new Date(year, month - 1, 1);
    const end = new Date(year, month, 0);
    const byEmployee = await this.prisma.attendance.groupBy({
      by: ['employeeId'],
      where: { tenantId, date: { gte: start, lte: end } },
      _count: { id: true },
      _sum: { workingHours: true },
    });
    const lates = await this.prisma.attendance.groupBy({ by: ['employeeId'], where: { tenantId, date: { gte: start, lte: end }, isLate: true }, _count: { id: true } });
    const lateMap = new Map((lates as any[]).map((l: any) => [l.employeeId, l._count.id]));
    const rows = await Promise.all((byEmployee as any[]).slice(0, 500).map(async (g: any) => {
      const emp = await this.prisma.employee.findFirst({ where: { id: g.employeeId }, select: { firstName: true, lastName: true, employeeCode: true, department: { select: { name: true } } } });
      return { ...emp, employeeId: g.employeeId, totalDays: g._count.id, lateCount: lateMap.get(g.employeeId) ?? 0, avgHours: g._sum.workingHours ? (Number(g._sum.workingHours) / g._count.id).toFixed(1) : '0' };
    }));
    return { rows, total: rows.length, month, year };
  }

  private async reportNewJoiners(tenantId: string, startDate: Date, endDate: Date) {
    const employees = await this.prisma.employee.findMany({
      where: { tenantId, dateOfJoining: { gte: startDate, lte: endDate }, deletedAt: null },
      include: { designation: { select: { name: true } }, department: { select: { name: true } } },
      orderBy: { dateOfJoining: 'asc' },
    });
    return { rows: employees.map(e => this.flatten(e)), total: employees.length };
  }

  private async reportCostCentre(tenantId: string, month: number, year: number) {
    const payslips = await this.prisma.payslip.findMany({ where: { tenantId, month, year }, include: { employee: { select: { department: { select: { id: true, name: true } } } } } });
    const byDept = new Map<string, { name: string; gross: number; net: number; employer: number; count: number }>();
    for (const p of payslips as any[]) {
      const dept = p.employee.department;
      if (!dept) continue;
      const prev = byDept.get(dept.id) ?? { name: dept.name, gross: 0, net: 0, employer: 0, count: 0 };
      byDept.set(dept.id, { name: dept.name, gross: prev.gross + Number(p.grossPay ?? 0), net: prev.net + Number(p.netPay ?? 0), employer: prev.employer + Number(p.pfEmployer ?? 0) + Number(p.esiEmployer ?? 0), count: prev.count + 1 });
    }
    const rows = Array.from(byDept.values()).map(d => ({ ...d, totalCost: d.gross + d.employer })).sort((a, b) => b.totalCost - a.totalCost);
    return { rows, total: rows.length, month, year, summary: { totalGross: rows.reduce((s, r) => s + r.gross, 0), totalCost: rows.reduce((s, r) => s + r.totalCost, 0) } };
  }

  // ─── Export Engine ────────────────────────────────────────────────

  async exportReport(tenantId: string, reportId: string, format: 'csv' | 'json', params: any = {}) {
    const report = await this.getReport(tenantId, reportId);
    const { rows, total } = await this.runReport(tenantId, {
      module: report.module,
      fields: report.fields as string[],
      filters: report.filters as any[],
      groupBy: report.groupBy ?? undefined,
    });

    if (format === 'csv') return this.toCSV(rows, report.fields as string[]);
    return { data: rows, total, exportedAt: new Date(), reportName: report.name };
  }

  private toCSV(rows: any[], fields: string[]): string {
    if (rows.length === 0) return '';
    const header = fields.join(',');
    const body = rows.map(row => fields.map(f => {
      const val = f.split('.').reduce((o: any, k) => o?.[k], row) ?? row[f] ?? '';
      const s = String(val).replace(/"/g, '""');
      return s.includes(',') ? `"${s}"` : s;
    }).join(',')).join('\n');
    return `${header}\n${body}`;
  }

  // ─── Scheduled Delivery ───────────────────────────────────────────

  @Cron('0 7 * * 1', { timeZone: 'Asia/Kolkata' }) // Monday 7am IST
  async runScheduledReports() {
    const reports = await this.prisma.savedReport.findMany({
      where: { deletedAt: null, scheduledDelivery: { path: ['enabled'], equals: true } },
    });
    for (const report of reports) {
      const schedule = report.scheduledDelivery as any;
      if (!schedule?.emails?.length) continue;
      try {
        const { rows } = await this.runReport(report.tenantId, { module: report.module, fields: report.fields as string[], filters: report.filters as any[] });
        const csv = this.toCSV(rows, report.fields as string[]);
        this.events.emit('report.scheduled.ready', { tenantId: report.tenantId, reportName: report.name, emails: schedule.emails, csv, rowCount: rows.length });
        this.logger.log(`Scheduled report "${report.name}" sent to ${schedule.emails.join(', ')}`);
      } catch (err) {
        this.logger.error(`Scheduled report "${report.name}" failed:`, err);
      }
    }
  }

  // ─── Helpers ─────────────────────────────────────────────────────

  getFieldCatalogue() { return FIELD_CATALOGUE; }
  getPrebuiltCatalogue() { return PREBUILT_REPORTS; }

  private applyFilter(where: any, filter: { field: string; operator: string; value: any }) {
    // Simple top-level filter application (nested fields handled via includes)
    const opMap: Record<string, string> = { eq: 'equals', neq: 'not', gt: 'gt', gte: 'gte', lt: 'lt', lte: 'lte', contains: 'contains' };
    const prismaOp = opMap[filter.operator] ?? 'equals';
    if (!filter.field.includes('.')) {
      where[filter.field] = { [prismaOp]: filter.value };
    }
  }

  private flatten(obj: any, prefix = ''): Record<string, unknown> {
    return Object.entries(obj ?? {}).reduce((acc: any, [k, v]) => {
      const key = prefix ? `${prefix}.${k}` : k;
      if (v && typeof v === 'object' && !Array.isArray(v) && !(v instanceof Date)) {
        Object.assign(acc, this.flatten(v, key));
      } else {
        acc[key] = v instanceof Date ? v.toISOString() : v;
      }
      return acc;
    }, {});
  }
}

// ─── Controller ──────────────────────────────────────────────────────

@ApiTags('report-builder')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('report-builder')
export class ReportBuilderController {
  constructor(private readonly svc: ReportBuilderService) {}

  @Get('catalogue/fields')
  @ApiOperation({ summary: 'Get available fields per module for drag-and-drop builder' })
  getFields() { return this.svc.getFieldCatalogue(); }

  @Get('catalogue/prebuilt')
  @ApiOperation({ summary: 'Get prebuilt India HR report catalogue' })
  getPrebuilt() { return this.svc.getPrebuiltCatalogue(); }

  @Get('reports')
  @ApiOperation({ summary: 'List saved reports (personal + shared)' })
  listReports(@Query('includeShared') shared = 'true', @CurrentUser() u: JwtPayload) {
    return this.svc.listReports(u.tid, u.sub, shared !== 'false');
  }

  @Get('reports/:id')
  getReport(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getReport(u.tid, id); }

  @Post('reports')
  @Roles('hr-admin', 'super-admin', 'manager')
  @ApiOperation({ summary: 'Save a custom report configuration' })
  saveReport(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.saveReport(u.tid, dto, u.sub); }

  @Put('reports/:id')
  @Roles('hr-admin', 'super-admin', 'manager')
  updateReport(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateReport(u.tid, id, dto, u.sub); }

  @Delete('reports/:id')
  @Roles('hr-admin', 'super-admin')
  deleteReport(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteReport(u.tid, id); }

  @Post('run')
  @Roles('hr-admin', 'super-admin', 'manager')
  @ApiOperation({ summary: 'Execute a report query and return rows — up to 10,000 rows' })
  runReport(@Body() config: any, @CurrentUser() u: JwtPayload) { return this.svc.runReport(u.tid, config); }

  @Get('prebuilt/:id')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Run a prebuilt India statutory/HR report' })
  runPrebuilt(@Param('id') id: string, @Query() params: any, @CurrentUser() u: JwtPayload) {
    return this.svc.runPrebuiltReport(u.tid, id, params);
  }

  @Get('reports/:id/export')
  @Roles('hr-admin', 'super-admin', 'manager')
  @ApiOperation({ summary: 'Export report as CSV or JSON' })
  async exportReport(@Param('id') id: string, @Query('format') format: 'csv' | 'json' = 'csv', @Res() res: Response, @CurrentUser() u: JwtPayload) {
    const result = await this.svc.exportReport(u.tid, id, format);
    if (format === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename=report-${id}.csv`);
      res.send(result);
    } else {
      res.json({ success: true, data: result });
    }
  }
}

@Module({
  controllers: [ReportBuilderController],
  providers: [ReportBuilderService],
  exports: [ReportBuilderService],
})
export class ReportBuilderModule {}
