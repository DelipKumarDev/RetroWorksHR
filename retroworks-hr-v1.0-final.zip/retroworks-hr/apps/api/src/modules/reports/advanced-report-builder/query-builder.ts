/**
 * Advanced Report Builder — Query Builder
 * ──────────────────────────────────────────────────────────────────────────────
 * Translates report config → safe Prisma queries.
 * No raw SQL. No full table scans. No cross-tenant access.
 *
 * Architecture:
 *   1. Validate every requested field against CATALOGUE_INDEX
 *   2. Block any field not in catalogue (security gate)
 *   3. Apply PII masking to results
 *   4. Cursor-based pagination (not offset — avoids full scan)
 *   5. Query timeout guard (5s hard limit)
 *   6. Row export cap (10,000 rows max)
 */

import type { PrismaClient } from '@prisma/client';
import {
  CATALOGUE_INDEX, FULL_CATALOGUE, SAFE_JOINS,
  shouldMaskField, type FieldDefinition,
} from './field-catalogue';

export type FilterOperator = 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains' | 'startsWith' | 'in' | 'notIn' | 'isNull' | 'isNotNull';
export type LogicalOp = 'AND' | 'OR';
export type SortOrder = 'asc' | 'desc';
export type AggregationFn = 'SUM' | 'COUNT' | 'AVG' | 'MIN' | 'MAX' | 'COUNT_DISTINCT';

export interface FilterCondition {
  field: string;
  operator: FilterOperator;
  value?: string | number | boolean | string[] | number[];
}

export interface FilterGroup {
  logic: LogicalOp;
  conditions: (FilterCondition | FilterGroup)[];
}

export interface AggregationSpec {
  field: string;
  fn: AggregationFn;
  alias: string;     // Column name in output
}

export interface CalculatedField {
  alias: string;
  formula: string;   // Expression Engine DSL
  type: 'number';
}

export interface ReportConfig {
  module: string;
  fields: string[];
  joinId?: string;               // Pre-defined safe join to activate
  filterGroup?: FilterGroup;
  groupBy?: string[];
  aggregations?: AggregationSpec[];
  calculatedFields?: CalculatedField[];
  sortBy?: string;
  sortOrder?: SortOrder;
  limit?: number;
  cursor?: string;               // Cursor for pagination
  userRoles: string[];           // For field masking
  tenantId: string;
}

export interface QueryResult {
  rows: Record<string, unknown>[];
  total: number;
  nextCursor?: string;
  hasMore: boolean;
  maskedFields: string[];        // Which fields were masked in this result
  executionMs: number;
  warnings: string[];
}

export class ReportQueryError extends Error {
  constructor(message: string, public code: string) {
    super(message);
    this.name = 'ReportQueryError';
  }
}

const QUERY_TIMEOUT_MS = 5_000;
const MAX_ROWS = 10_000;
const DEFAULT_LIMIT = 500;

// ─── Field validation ─────────────────────────────────────────────────────────

export function validateFields(fields: string[], module: string): { valid: string[]; blocked: string[] } {
  const moduleFields = new Set(
    (FULL_CATALOGUE[module] ?? []).map(f => f.key)
  );
  // Allow fields from joined modules (they include the module prefix)
  const allKnown = new Set([
    ...Array.from(CATALOGUE_INDEX.keys()),
    ...moduleFields,
  ]);

  const valid: string[] = [];
  const blocked: string[] = [];

  for (const f of fields) {
    if (allKnown.has(f) || allKnown.has(f.replace(/^[^.]+\./, ''))) {
      valid.push(f);
    } else {
      blocked.push(f);
    }
  }

  return { valid, blocked };
}

// ─── PII masking ──────────────────────────────────────────────────────────────

export function maskRow(
  row: Record<string, unknown>,
  requestedFields: string[],
  userRoles: string[],
): { masked: Record<string, unknown>; maskedKeys: string[] } {
  const masked = { ...row };
  const maskedKeys: string[] = [];

  for (const fieldKey of requestedFields) {
    const def = CATALOGUE_INDEX.get(fieldKey);
    if (!def) continue;
    if (shouldMaskField(def, userRoles)) {
      // Mask both the direct key and any dot-path variants
      const flatKey = fieldKey.replace(/\./g, '_');
      const maskValue = def.maskWith !== undefined ? def.maskWith : '***';
      if (fieldKey in masked) { masked[fieldKey] = maskValue; maskedKeys.push(fieldKey); }
      if (flatKey in masked) { masked[flatKey] = maskValue; maskedKeys.push(flatKey); }
      // Check nested path
      const parts = fieldKey.split('.');
      if (parts.length > 1) {
        const last = parts[parts.length - 1]!;
        if (last in masked) { masked[last] = maskValue; maskedKeys.push(last); }
      }
    }
  }

  return { masked, maskedKeys };
}

// ─── Filter → Prisma WHERE translation ────────────────────────────────────────

function buildWhereClause(group: FilterGroup): Record<string, unknown> {
  const conditions = group.conditions.map(c => {
    if ('logic' in c) return buildWhereClause(c as FilterGroup);
    return buildCondition(c as FilterCondition);
  });

  if (group.logic === 'OR') return { OR: conditions };
  return { AND: conditions };
}

function buildCondition(cond: FilterCondition): Record<string, unknown> {
  const { field, operator, value } = cond;

  // Security: block raw SQL injection via field path
  if (!/^[a-zA-Z0-9_.]+$/.test(field)) {
    throw new ReportQueryError(`Invalid field name: ${field}`, 'INVALID_FIELD');
  }

  const op = operator;
  const opMap: Partial<Record<FilterOperator, string>> = {
    eq: 'equals', neq: 'not', gt: 'gt', gte: 'gte',
    lt: 'lt', lte: 'lte', contains: 'contains', startsWith: 'startsWith',
    in: 'in', notIn: 'notIn',
  };

  if (op === 'isNull') return { [field]: null };
  if (op === 'isNotNull') return { [field]: { not: null } };

  const prismaOp = opMap[op];
  if (!prismaOp) throw new ReportQueryError(`Unknown filter operator: ${op}`, 'UNKNOWN_OP');

  // Handle dot-path fields (nested relations)
  if (field.includes('.')) {
    const parts = field.split('.');
    let nested: any = { [prismaOp]: value };
    for (let i = parts.length - 1; i >= 0; i--) {
      nested = { [parts[i]!]: nested };
    }
    return nested;
  }

  return { [field]: { [prismaOp]: value } };
}

// ─── Module-specific query executors ──────────────────────────────────────────

async function withTimeout<T>(promise: Promise<T>, ms: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new ReportQueryError('Query timeout exceeded', 'TIMEOUT')), ms)
    ),
  ]);
}

function buildOrderBy(sortBy?: string, sortOrder: SortOrder = 'asc'): Record<string, string> | undefined {
  if (!sortBy) return undefined;
  if (sortBy.includes('.')) {
    const parts = sortBy.split('.');
    let orderBy: any = sortOrder;
    for (let i = parts.length - 1; i >= 0; i--) orderBy = { [parts[i]!]: orderBy };
    return orderBy;
  }
  return { [sortBy]: sortOrder };
}

export async function executeQuery(
  prisma: PrismaClient,
  config: ReportConfig,
): Promise<QueryResult> {
  const startMs = Date.now();
  const warnings: string[] = [];
  const limit = Math.min(config.limit ?? DEFAULT_LIMIT, MAX_ROWS);

  // Validate all requested fields
  const { valid, blocked } = validateFields(config.fields, config.module);
  if (blocked.length > 0) {
    warnings.push(`Blocked unknown fields: ${blocked.join(', ')}`);
  }

  const baseWhere: any = { tenantId: config.tenantId };
  if (config.filterGroup?.conditions.length) {
    Object.assign(baseWhere, buildWhereClause(config.filterGroup));
  }

  // Cursor pagination
  const paginationArgs: any = config.cursor
    ? { cursor: { id: config.cursor }, skip: 1 }
    : {};

  let rows: any[];
  let totalCount = 0;

  const orderBy = buildOrderBy(config.sortBy, config.sortOrder);

  try {
    rows = await withTimeout(
      queryByModule(prisma, config, baseWhere, limit + 1, paginationArgs, orderBy),
      QUERY_TIMEOUT_MS,
    );
  } catch (e: any) {
    if (e.code === 'TIMEOUT') throw e;
    throw new ReportQueryError(`Query execution failed: ${e.message}`, 'QUERY_FAILED');
  }

  const hasMore = rows.length > limit;
  if (hasMore) rows.pop();

  const nextCursor = hasMore && rows.length > 0 ? rows[rows.length - 1]?.id : undefined;

  // Flatten + project fields
  const maskedFieldsSet = new Set<string>();
  const projectedRows = rows.map(row => {
    const flat = flatten(row);
    const projected = projectFields(flat, valid);
    const { masked, maskedKeys } = maskRow(projected, valid, config.userRoles);
    maskedKeys.forEach(k => maskedFieldsSet.add(k));
    return masked;
  });

  // Apply aggregations if groupBy is set
  const finalRows = config.groupBy?.length
    ? applyAggregations(projectedRows, config.groupBy, config.aggregations ?? [])
    : projectedRows;

  // Apply calculated fields
  if (config.calculatedFields?.length) {
    applyCalculatedFields(finalRows, config.calculatedFields);
  }

  return {
    rows: finalRows,
    total: finalRows.length,
    nextCursor: nextCursor as string | undefined,
    hasMore,
    maskedFields: Array.from(maskedFieldsSet),
    executionMs: Date.now() - startMs,
    warnings,
  };
}

// ─── Module-specific queries ───────────────────────────────────────────────────

async function queryByModule(
  prisma: PrismaClient,
  config: ReportConfig,
  where: any,
  take: number,
  paginationArgs: any,
  orderBy?: any,
): Promise<any[]> {
  const { module } = config;

  // Core includes based on requested fields (avoid N+1)
  const needsDepartment = config.fields.some(f => f.includes('department'));
  const needsDesignation = config.fields.some(f => f.includes('designation'));
  const needsLocation = config.fields.some(f => f.includes('location'));
  const needsEmployee = config.fields.some(f => f.startsWith('employee.'));

  switch (module) {
    case 'employees':
      return (prisma as any).employee.findMany({
        where: { ...where, deletedAt: null },
        include: {
          ...(needsDepartment ? { department: { select: { name: true, id: true } } } : {}),
          ...(needsDesignation ? { designation: { select: { name: true } } } : {}),
          ...(needsLocation ? { location: { select: { name: true, stateCode: true } } } : {}),
        },
        take,
        orderBy: orderBy ?? { firstName: 'asc' },
        ...paginationArgs,
      });

    case 'payroll':
      return (prisma as any).payslip.findMany({
        where: { ...where, status: { not: 'REVERSED' } },
        include: needsEmployee ? {
          employee: {
            select: {
              firstName: true, lastName: true, employeeCode: true,
              department: needsDepartment ? { select: { name: true } } : false,
              designation: needsDesignation ? { select: { name: true } } : false,
              location: needsLocation ? { select: { name: true, stateCode: true } } : false,
              employmentType: true, gender: true,
            },
          },
        } : {},
        take,
        orderBy: orderBy ?? [{ year: 'desc' }, { month: 'desc' }],
        ...paginationArgs,
      });

    case 'leave':
      return (prisma as any).leaveRequest.findMany({
        where,
        include: {
          leaveType: { select: { name: true, code: true } },
          employee: {
            select: {
              firstName: true, lastName: true, employeeCode: true,
              department: needsDepartment ? { select: { name: true } } : false,
              location: needsLocation ? { select: { name: true } } : false,
            },
          },
        },
        take,
        orderBy: orderBy ?? { startDate: 'desc' },
        ...paginationArgs,
      });

    case 'attendance':
      return (prisma as any).attendance.findMany({
        where,
        include: {
          employee: {
            select: {
              firstName: true, lastName: true, employeeCode: true,
              department: needsDepartment ? { select: { name: true } } : false,
              location: needsLocation ? { select: { name: true } } : false,
            },
          },
        },
        take,
        orderBy: orderBy ?? { date: 'desc' },
        ...paginationArgs,
      });

    case 'tds':
      return (prisma as any).tDSProjection.findMany({
        where,
        include: {
          employee: {
            select: {
              firstName: true, lastName: true, employeeCode: true,
              department: needsDepartment ? { select: { name: true } } : false,
            },
          },
        },
        take,
        orderBy: orderBy ?? { updatedAt: 'desc' },
        ...paginationArgs,
      });

    case 'audit':
      return (prisma as any).auditLog.findMany({
        where,
        take,
        orderBy: orderBy ?? { timestamp: 'desc' },
        ...paginationArgs,
      });

    case 'performance':
      return (prisma as any).performanceReview.findMany({
        where,
        include: {
          employee: {
            select: {
              firstName: true, lastName: true, employeeCode: true,
              department: needsDepartment ? { select: { name: true } } : false,
            },
          },
          cycle: { select: { name: true } },
        },
        take,
        orderBy: orderBy ?? { completedAt: 'desc' },
        ...paginationArgs,
      });

    default:
      throw new ReportQueryError(`Unknown module: ${module}`, 'UNKNOWN_MODULE');
  }
}

// ─── Utilities ─────────────────────────────────────────────────────────────────

function flatten(obj: any, prefix = ''): Record<string, unknown> {
  return Object.entries(obj ?? {}).reduce((acc: any, [k, v]) => {
    const key = prefix ? `${prefix}.${k}` : k;
    if (v && typeof v === 'object' && !Array.isArray(v) && !(v instanceof Date)) {
      Object.assign(acc, flatten(v, key));
    } else {
      acc[key] = v instanceof Date ? v.toISOString() : v;
    }
    return acc;
  }, {});
}

function projectFields(
  flat: Record<string, unknown>,
  requestedFields: string[],
): Record<string, unknown> {
  const projected: Record<string, unknown> = {};
  // Always include id for cursor pagination
  if ('id' in flat) projected['id'] = flat['id'];

  for (const field of requestedFields) {
    if (field in flat) {
      projected[field] = flat[field];
    } else {
      // Try dot-path lookup
      const val = field.split('.').reduce((o: any, k) => o?.[k], flat);
      if (val !== undefined) projected[field] = val;
    }
  }
  return projected;
}

function applyAggregations(
  rows: Record<string, unknown>[],
  groupBy: string[],
  aggregations: AggregationSpec[],
): Record<string, unknown>[] {
  const groups = new Map<string, Record<string, unknown>[]>();

  for (const row of rows) {
    const key = groupBy.map(g => String(row[g] ?? '')).join('|');
    const existing = groups.get(key) ?? [];
    existing.push(row);
    groups.set(key, existing);
  }

  return Array.from(groups.entries()).map(([, groupRows]) => {
    const result: Record<string, unknown> = {};
    // Group-by fields
    for (const g of groupBy) result[g] = groupRows[0]?.[g];

    // Aggregations
    for (const agg of aggregations) {
      const values = groupRows
        .map(r => r[agg.field])
        .filter(v => typeof v === 'number') as number[];

      switch (agg.fn) {
        case 'SUM': result[agg.alias] = values.reduce((s, v) => s + v, 0); break;
        case 'COUNT': result[agg.alias] = groupRows.length; break;
        case 'AVG': result[agg.alias] = values.length ? values.reduce((s, v) => s + v, 0) / values.length : 0; break;
        case 'MIN': result[agg.alias] = values.length ? Math.min(...values) : null; break;
        case 'MAX': result[agg.alias] = values.length ? Math.max(...values) : null; break;
        case 'COUNT_DISTINCT': result[agg.alias] = new Set(groupRows.map(r => r[agg.field])).size; break;
      }
    }

    return result;
  });
}

function applyCalculatedFields(
  rows: Record<string, unknown>[],
  calcFields: CalculatedField[],
): void {
  // Calculated fields use the Expression Engine DSL evaluated per-row
  // For simple arithmetic, we do a safe numeric eval
  for (const row of rows) {
    for (const cf of calcFields) {
      try {
        // Simple substitution of known field values (DSL-safe: no eval)
        let expr = cf.formula;
        for (const [key, val] of Object.entries(row)) {
          if (typeof val === 'number') {
            expr = expr.replace(new RegExp(`\\b${key.replace(/\./g, '_')}\\b`, 'g'), String(val));
          }
        }
        // Parse only safe arithmetic expressions (no dynamic code)
        const safeResult = evaluateSafeArithmetic(expr);
        row[cf.alias] = safeResult;
      } catch {
        row[cf.alias] = null;
      }
    }
  }
}

// Safe arithmetic evaluator for calculated fields (no eval(), no Function())
function evaluateSafeArithmetic(expr: string): number {
  // Import the Expression Engine parser/evaluator
  // For now: handle simple arithmetic tokens only
  const cleaned = expr.replace(/[^0-9\s\+\-\*\/\.\(\)]/g, '');
  if (!cleaned.trim()) return 0;

  // Use our Phase 2B parser/evaluator if available
  try {
    const { parse } = require('../../payroll/expression-engine/parser');
    const { evaluate } = require('../../payroll/expression-engine/evaluator');
    const ast = parse(cleaned);
    return evaluate(ast, {
      BASIC: 0, GROSS: 0, CTC: 0, WORKING_DAYS: 26, LOP_DAYS: 0,
      ATTENDANCE_DAYS: 26, YEARS_OF_SERVICE: 0,
      workerCategory: { code: '', applyPF: false, applyESI: false, isPayrollEligible: true, isContractWorker: false },
      legalEntity: { id: '', state: '', pfTrustExempt: false },
      components: {},
    }).value;
  } catch {
    return 0;
  }
}
