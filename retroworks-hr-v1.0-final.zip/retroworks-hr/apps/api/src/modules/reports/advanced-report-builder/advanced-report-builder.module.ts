/**
 * Advanced Report Builder — Controller + Module
 * ──────────────────────────────────────────────────────────────────────────────
 * REST endpoints for the enterprise report builder.
 * All endpoints: jwt + tenant guard. No raw SQL exposure.
 */

import {
  Controller, Get, Post, Put, Delete, Patch,
  Body, Param, Query, UseGuards, Res, HttpCode, HttpStatus, Module,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiQuery } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import type { Response } from 'express';
import { AdvancedReportBuilderService, type SaveReportDto } from './advanced-report-builder.service';
import { CurrentUser } from '../../../common/decorators/current-user.decorator';
import { Roles } from '../../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

const REPORT_ROLES = ['hr-admin', 'super-admin', 'manager', 'cfo', 'finance-controller', 'sys-finance'] as const;
const ADMIN_ROLES  = ['hr-admin', 'super-admin'] as const;

@ApiTags('reports/advanced')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('reports/advanced')
export class AdvancedReportBuilderController {
  constructor(private readonly svc: AdvancedReportBuilderService) {}

  // ── Catalogue ──────────────────────────────────────────────────────────────

  @Get('catalogue')
  @ApiOperation({ summary: 'Get full field catalogue for all modules — role-aware masking indicators' })
  @ApiQuery({ name: 'module', required: false })
  getCatalogue(
    @Query('module') module: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.svc.getFieldCatalogue(module, u.roles ?? []);
  }

  // ── Saved Reports CRUD ─────────────────────────────────────────────────────

  @Get('reports')
  @ApiOperation({ summary: 'List all accessible reports (own + shared + entity)' })
  listReports(@CurrentUser() u: JwtPayload) {
    return this.svc.listReports(u.tid, u.sub, u.roles ?? []);
  }

  @Get('reports/:id')
  @ApiOperation({ summary: 'Get a single saved report config' })
  getReport(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getReport(u.tid, id, u.sub, u.roles ?? []);
  }

  @Post('reports')
  @Roles(...REPORT_ROLES)
  @ApiOperation({ summary: 'Save a new report configuration' })
  saveReport(@Body() dto: SaveReportDto, @CurrentUser() u: JwtPayload) {
    return this.svc.saveReport(u.tid, dto, u.sub, u.roles ?? []);
  }

  @Put('reports/:id')
  @Roles(...REPORT_ROLES)
  @ApiOperation({ summary: 'Update a saved report — creates version snapshot' })
  updateReport(
    @Param('id') id: string,
    @Body() dto: Partial<SaveReportDto>,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.svc.updateReport(u.tid, id, dto, u.sub, u.roles ?? []);
  }

  @Delete('reports/:id')
  @Roles(...ADMIN_ROLES)
  @ApiOperation({ summary: 'Soft-delete a report' })
  deleteReport(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.svc.deleteReport(u.tid, id, u.sub);
  }

  @Post('reports/:id/duplicate')
  @Roles(...REPORT_ROLES)
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({ summary: 'Duplicate a report as private copy' })
  duplicateReport(
    @Param('id') id: string,
    @Body('name') name: string,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.svc.duplicateReport(u.tid, id, name ?? 'Copy', u.sub, u.roles ?? []);
  }

  @Get('reports/:id/versions')
  @ApiOperation({ summary: 'Version history for a saved report' })
  getVersionHistory(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getVersionHistory(u.tid, id);
  }

  @Post('reports/:id/rollback')
  @Roles(...ADMIN_ROLES)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Roll back a report to a previous version' })
  rollback(
    @Param('id') id: string,
    @Body('version') version: number,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.svc.rollbackVersion(u.tid, id, version, u.sub, u.roles ?? []);
  }

  // ── Execution ──────────────────────────────────────────────────────────────

  @Post('run')
  @Roles(...REPORT_ROLES)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Execute an ad-hoc report query — returns up to 10K rows' })
  runReport(@Body() config: any, @CurrentUser() u: JwtPayload) {
    const { tenantId, userRoles, ...rest } = config;
    return this.svc.runReport(u.tid, rest, u.sub, u.roles ?? []);
  }

  @Get('reports/:id/run')
  @Roles(...REPORT_ROLES)
  @ApiOperation({ summary: 'Execute a saved report (with optional cursor pagination)' })
  @ApiQuery({ name: 'cursor', required: false })
  @ApiQuery({ name: 'limit',  required: false, type: Number })
  runSavedReport(
    @Param('id') id: string,
    @Query('cursor') cursor: string | undefined,
    @Query('limit') limit: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.svc.runSavedReport(u.tid, id, u.sub, u.roles ?? [], {
      cursor,
      limit: limit ? parseInt(limit) : undefined,
    });
  }

  // ── Export ─────────────────────────────────────────────────────────────────

  @Get('reports/:id/export')
  @Roles(...REPORT_ROLES)
  @ApiOperation({ summary: 'Export report as CSV or JSON — PII masking always enforced' })
  @ApiQuery({ name: 'format', enum: ['csv', 'json'], required: false })
  async exportReport(
    @Param('id') id: string,
    @Query('format') format: 'csv' | 'json' = 'csv',
    @Res() res: Response,
    @CurrentUser() u: JwtPayload,
  ) {
    const { content, filename, contentType } = await this.svc.exportReport(
      u.tid, id, format, u.sub, u.roles ?? [],
    );
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(content);
  }
}

// ─── Module ────────────────────────────────────────────────────────────────────

@Module({
  controllers: [AdvancedReportBuilderController],
  providers: [
    AdvancedReportBuilderService,
    { provide: PrismaClient, useExisting: PrismaClient },
  ],
  exports: [AdvancedReportBuilderService],
})
export class AdvancedReportBuilderModule {}
