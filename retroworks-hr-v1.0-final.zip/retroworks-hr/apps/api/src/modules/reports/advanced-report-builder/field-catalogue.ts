/**
 * Advanced Report Builder — Field Catalogue
 * ──────────────────────────────────────────────────────────────────────────────
 * Single source of truth for every field available to the report builder.
 * Each field carries:
 *   - pii: true → masked unless user has unmask permission
 *   - sensitivePayroll: true → masked for manager/employee roles
 *   - maskWith: replacement value when masked
 *   - aggregatable: can be used in SUM/AVG/MIN/MAX
 *   - filterable: can be used in filter conditions
 *   - groupable: can be used in GROUP BY
 *   - module: owning module (for join validation)
 *
 * This catalogue is the ONLY authorised source of field keys.
 * Any field not in this catalogue is BLOCKED by the query builder.
 */

export type FieldType = 'string' | 'number' | 'date' | 'boolean' | 'enum';
export type AggregationFn = 'SUM' | 'COUNT' | 'AVG' | 'MIN' | 'MAX' | 'COUNT_DISTINCT';

export interface FieldDefinition {
  key: string;            // Dot-notation path: "employee.department.name"
  label: string;          // Display label in UI
  type: FieldType;
  module: string;         // Owning module
  pii?: boolean;          // Personally identifiable — mask by default
  sensitivePayroll?: boolean; // Salary/TDS data — mask for non-finance roles
  maskWith?: string | number; // Replacement when masked
  aggregatable?: boolean;
  filterable?: boolean;
  groupable?: boolean;
  sortable?: boolean;
  options?: string[];     // For enum fields
  dbPath?: string;        // Override DB field path if different from key
  description?: string;
}

// ─── MODULE: EMPLOYEES ────────────────────────────────────────────────────────

export const EMPLOYEE_FIELDS: FieldDefinition[] = [
  { key: 'employeeCode',           label: 'Employee ID',        type: 'string',  module: 'employees', filterable: true, sortable: true, groupable: false },
  { key: 'firstName',              label: 'First Name',         type: 'string',  module: 'employees', filterable: true, sortable: true },
  { key: 'lastName',               label: 'Last Name',          type: 'string',  module: 'employees', filterable: true, sortable: true },
  { key: 'email',                  label: 'Work Email',         type: 'string',  module: 'employees', pii: true, maskWith: '***@***.com', filterable: true },
  { key: 'personalEmail',          label: 'Personal Email',     type: 'string',  module: 'employees', pii: true, maskWith: '***@***.com' },
  { key: 'phone',                  label: 'Mobile',             type: 'string',  module: 'employees', pii: true, maskWith: '**-****-****' },
  { key: 'panNumber',              label: 'PAN',                type: 'string',  module: 'employees', pii: true, maskWith: '**XXXXX*X' },
  { key: 'aadhaarNumber',          label: 'Aadhaar',            type: 'string',  module: 'employees', pii: true, maskWith: '****-****-XXXX' },
  { key: 'department.name',        label: 'Department',         type: 'string',  module: 'employees', filterable: true, groupable: true, sortable: true },
  { key: 'designation.name',       label: 'Designation',        type: 'string',  module: 'employees', filterable: true, groupable: true, sortable: true },
  { key: 'location.name',          label: 'Location',           type: 'string',  module: 'employees', filterable: true, groupable: true },
  { key: 'location.stateCode',     label: 'State',              type: 'string',  module: 'employees', filterable: true, groupable: true },
  { key: 'status',                 label: 'Status',             type: 'enum',    module: 'employees', filterable: true, groupable: true, options: ['active', 'inactive', 'on-notice', 'absconding'] },
  { key: 'employmentType',         label: 'Employment Type',    type: 'enum',    module: 'employees', filterable: true, groupable: true, options: ['full-time', 'part-time', 'contract', 'intern'] },
  { key: 'gender',                 label: 'Gender',             type: 'enum',    module: 'employees', filterable: true, groupable: true, options: ['male', 'female', 'other', 'prefer_not_to_say'] },
  { key: 'dateOfJoining',          label: 'Date of Joining',    type: 'date',    module: 'employees', filterable: true, sortable: true },
  { key: 'dateOfBirth',            label: 'Date of Birth',      type: 'date',    module: 'employees', pii: true, maskWith: '****-**-**', filterable: true },
  { key: 'probationEndDate',       label: 'Probation End',      type: 'date',    module: 'employees', filterable: true },
  { key: 'ctc',                    label: 'CTC (Annual)',        type: 'number',  module: 'employees', sensitivePayroll: true, maskWith: 0, aggregatable: true, filterable: true, sortable: true },
  { key: 'managerId',              label: 'Manager',            type: 'string',  module: 'employees', filterable: true },
  { key: 'workLocation',           label: 'Work Mode',          type: 'enum',    module: 'employees', filterable: true, groupable: true, options: ['office', 'remote', 'hybrid'] },
  // Computed / virtual
  { key: '_count',                 label: 'Count',              type: 'number',  module: 'employees', aggregatable: true, description: 'Row count aggregate' },
];

// ─── MODULE: PAYROLL ──────────────────────────────────────────────────────────

export const PAYROLL_FIELDS: FieldDefinition[] = [
  { key: 'month',          label: 'Month',           type: 'number',  module: 'payroll', filterable: true, groupable: true, sortable: true },
  { key: 'year',           label: 'Year',            type: 'number',  module: 'payroll', filterable: true, groupable: true, sortable: true },
  { key: 'status',         label: 'Payslip Status',  type: 'enum',    module: 'payroll', filterable: true, groupable: true, options: ['DRAFT', 'PROCESSED', 'APPROVED', 'REVERSED'] },
  { key: 'grossPay',       label: 'Gross Pay',       type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true, filterable: true, sortable: true },
  { key: 'netPay',         label: 'Net Pay',         type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true, filterable: true },
  { key: 'basicSalary',    label: 'Basic Salary',    type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'hra',            label: 'HRA',             type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'specialAllowance', label: 'Special Allowance', type: 'number', module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'pfEmployee',     label: 'PF (Employee)',   type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'pfEmployer',     label: 'PF (Employer)',   type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'pfEps',          label: 'EPS',             type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'esiEmployee',    label: 'ESI (Employee)',  type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'esiEmployer',    label: 'ESI (Employer)',  type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'tdsDeducted',    label: 'TDS Deducted',   type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'professionalTax', label: 'Professional Tax', type: 'number', module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'lopDeduction',   label: 'LOP Deduction',  type: 'number',  module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'lopDays',        label: 'LOP Days',       type: 'number',  module: 'payroll', filterable: true, aggregatable: true },
  { key: 'taxRegime',      label: 'Tax Regime',     type: 'enum',    module: 'payroll', filterable: true, groupable: true, options: ['new', 'old'] },
  { key: 'totalEmployerCost', label: 'Total CTC (Monthly)', type: 'number', module: 'payroll', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'employee.department.name', label: 'Department', type: 'string', module: 'payroll', filterable: true, groupable: true },
  { key: 'employee.designation.name', label: 'Designation', type: 'string', module: 'payroll', filterable: true, groupable: true },
  { key: 'employee.location.stateCode', label: 'State', type: 'string', module: 'payroll', filterable: true, groupable: true },
  { key: 'employee.employmentType', label: 'Employment Type', type: 'string', module: 'payroll', filterable: true, groupable: true },
];

// ─── MODULE: LEAVE ────────────────────────────────────────────────────────────

export const LEAVE_FIELDS: FieldDefinition[] = [
  { key: 'startDate',              label: 'Start Date',      type: 'date',    module: 'leave', filterable: true, sortable: true },
  { key: 'endDate',                label: 'End Date',        type: 'date',    module: 'leave', filterable: true },
  { key: 'totalDays',              label: 'Total Days',      type: 'number',  module: 'leave', aggregatable: true, filterable: true, sortable: true },
  { key: 'status',                 label: 'Status',          type: 'enum',    module: 'leave', filterable: true, groupable: true, options: ['PENDING', 'APPROVED', 'REJECTED', 'CANCELLED'] },
  { key: 'leaveType.name',         label: 'Leave Type',      type: 'string',  module: 'leave', filterable: true, groupable: true },
  { key: 'leaveType.code',         label: 'Leave Code',      type: 'string',  module: 'leave', filterable: true, groupable: true },
  { key: 'employee.department.name', label: 'Department',    type: 'string',  module: 'leave', filterable: true, groupable: true },
  { key: 'reason',                 label: 'Reason',          type: 'string',  module: 'leave', filterable: false },
  { key: 'approvedBy',             label: 'Approved By',     type: 'string',  module: 'leave' },
  { key: 'createdAt',              label: 'Applied On',      type: 'date',    module: 'leave', filterable: true, sortable: true },
  // Leave balance sub-module
  { key: 'balance.allocated',      label: 'Allocated Days',  type: 'number',  module: 'leave', aggregatable: true },
  { key: 'balance.usedDays',       label: 'Used Days',       type: 'number',  module: 'leave', aggregatable: true },
  { key: 'balance.carryForward',   label: 'Carry Forward',   type: 'number',  module: 'leave', aggregatable: true },
  { key: 'balance.year',           label: 'Balance Year',    type: 'number',  module: 'leave', filterable: true, groupable: true },
];

// ─── MODULE: ATTENDANCE ───────────────────────────────────────────────────────

export const ATTENDANCE_FIELDS: FieldDefinition[] = [
  { key: 'date',            label: 'Date',            type: 'date',    module: 'attendance', filterable: true, sortable: true, groupable: true },
  { key: 'status',          label: 'Status',          type: 'enum',    module: 'attendance', filterable: true, groupable: true, options: ['PRESENT', 'ABSENT', 'HALF_DAY', 'LEAVE', 'HOLIDAY', 'WEEKEND'] },
  { key: 'checkIn',         label: 'Check In',        type: 'string',  module: 'attendance', filterable: false },
  { key: 'checkOut',        label: 'Check Out',       type: 'string',  module: 'attendance', filterable: false },
  { key: 'workingHours',    label: 'Working Hours',   type: 'number',  module: 'attendance', aggregatable: true, filterable: true },
  { key: 'isLate',          label: 'Late Entry',      type: 'boolean', module: 'attendance', filterable: true, groupable: true },
  { key: 'isEarlyExit',     label: 'Early Exit',      type: 'boolean', module: 'attendance', filterable: true },
  { key: 'overtimeHours',   label: 'Overtime Hours',  type: 'number',  module: 'attendance', aggregatable: true },
  { key: 'employee.department.name', label: 'Department', type: 'string', module: 'attendance', filterable: true, groupable: true },
  { key: 'employee.location.name',   label: 'Location',   type: 'string', module: 'attendance', filterable: true, groupable: true },
  { key: 'shiftName',       label: 'Shift',           type: 'string',  module: 'attendance', filterable: true, groupable: true },
];

// ─── MODULE: TDS ──────────────────────────────────────────────────────────────

export const TDS_FIELDS: FieldDefinition[] = [
  { key: 'financialYear',         label: 'Financial Year',     type: 'string',  module: 'tds', filterable: true, groupable: true },
  { key: 'quarter',               label: 'Quarter',            type: 'number',  module: 'tds', filterable: true, groupable: true },
  { key: 'grossSalary',           label: 'Gross Salary',       type: 'number',  module: 'tds', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'taxableIncome',         label: 'Taxable Income',     type: 'number',  module: 'tds', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'totalDeductions',       label: 'Total Deductions',   type: 'number',  module: 'tds', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'projectedAnnualTax',    label: 'Projected TDS',      type: 'number',  module: 'tds', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'tdsDeductedYtd',        label: 'TDS YTD',           type: 'number',  module: 'tds', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'regime',                label: 'Tax Regime',         type: 'enum',    module: 'tds', filterable: true, groupable: true, options: ['new', 'old'] },
  { key: 'section80C',            label: '80C Deductions',     type: 'number',  module: 'tds', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'hra',                   label: 'HRA Exemption',      type: 'number',  module: 'tds', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'rebate87A',             label: '87A Rebate',         type: 'number',  module: 'tds', sensitivePayroll: true, maskWith: 0, aggregatable: true },
  { key: 'surcharge',             label: 'Surcharge',          type: 'number',  module: 'tds', sensitivePayroll: true, maskWith: 0, aggregatable: true },
];

// ─── MODULE: AUDIT ────────────────────────────────────────────────────────────

export const AUDIT_FIELDS: FieldDefinition[] = [
  { key: 'action',         label: 'Action',          type: 'string',  module: 'audit', filterable: true, groupable: true },
  { key: 'resourceType',   label: 'Resource Type',   type: 'string',  module: 'audit', filterable: true, groupable: true },
  { key: 'resourceId',     label: 'Resource ID',     type: 'string',  module: 'audit', filterable: true },
  { key: 'performedBy',    label: 'Performed By',    type: 'string',  module: 'audit', filterable: true },
  { key: 'timestamp',      label: 'Timestamp',       type: 'date',    module: 'audit', filterable: true, sortable: true },
  { key: 'ipAddress',      label: 'IP Address',      type: 'string',  module: 'audit', pii: true, maskWith: '***.***.*.*' },
  { key: 'userAgent',      label: 'User Agent',      type: 'string',  module: 'audit', pii: true, maskWith: '***' },
  { key: 'metadata',       label: 'Metadata',        type: 'string',  module: 'audit' },
];

// ─── MODULE: PERFORMANCE ──────────────────────────────────────────────────────

export const PERFORMANCE_FIELDS: FieldDefinition[] = [
  { key: 'cycle.name',     label: 'Review Cycle',    type: 'string',  module: 'performance', filterable: true, groupable: true },
  { key: 'overallRating',  label: 'Rating',          type: 'number',  module: 'performance', aggregatable: true, filterable: true, sortable: true },
  { key: 'status',         label: 'Review Status',   type: 'enum',    module: 'performance', filterable: true, options: ['PENDING', 'SUBMITTED', 'CALIBRATED', 'COMPLETED'] },
  { key: 'selfRating',     label: 'Self Rating',     type: 'number',  module: 'performance', aggregatable: true },
  { key: 'managerRating',  label: 'Manager Rating',  type: 'number',  module: 'performance', aggregatable: true },
  { key: 'completedAt',    label: 'Completed At',    type: 'date',    module: 'performance', filterable: true },
  { key: 'employee.department.name', label: 'Department', type: 'string', module: 'performance', filterable: true, groupable: true },
];

// ─── COMPLETE CATALOGUE ────────────────────────────────────────────────────────

export const FULL_CATALOGUE: Record<string, FieldDefinition[]> = {
  employees:   EMPLOYEE_FIELDS,
  payroll:     PAYROLL_FIELDS,
  leave:       LEAVE_FIELDS,
  attendance:  ATTENDANCE_FIELDS,
  tds:         TDS_FIELDS,
  audit:       AUDIT_FIELDS,
  performance: PERFORMANCE_FIELDS,
};

// Flat lookup: key → FieldDefinition (across all modules)
export const CATALOGUE_INDEX = new Map<string, FieldDefinition>(
  Object.values(FULL_CATALOGUE)
    .flat()
    .map(f => [f.key, f]),
);

// ─── MASKING ROLES ────────────────────────────────────────────────────────────
// Roles that can see unmasked PII/payroll fields

export const PII_UNMASK_ROLES = new Set(['hr-admin', 'super-admin', 'sys-finance']);
export const PAYROLL_UNMASK_ROLES = new Set(['hr-admin', 'super-admin', 'sys-finance', 'cfo', 'finance-controller']);

export function canSeeField(field: FieldDefinition, userRoles: string[]): boolean {
  // PII fields: only HR admin and super-admin can see unmasked
  if (field.pii && !userRoles.some(r => PII_UNMASK_ROLES.has(r))) return false;
  return true;
}

export function shouldMaskField(field: FieldDefinition, userRoles: string[]): boolean {
  if (field.pii && !userRoles.some(r => PII_UNMASK_ROLES.has(r))) return true;
  if (field.sensitivePayroll && !userRoles.some(r => PAYROLL_UNMASK_ROLES.has(r))) return true;
  return false;
}

// ─── SAFE PRE-DEFINED JOINS ───────────────────────────────────────────────────

export interface JoinDefinition {
  id: string;
  label: string;
  primaryModule: string;
  joinedModule: string;
  description: string;
  // Fields available when this join is active (from the joined module)
  additionalFields: string[];
}

export const SAFE_JOINS: JoinDefinition[] = [
  {
    id: 'payroll_employees',
    label: 'Payroll + Employee Details',
    primaryModule: 'payroll',
    joinedModule: 'employees',
    description: 'Join payroll data with employee demographics and department',
    additionalFields: [
      'employees.department.name', 'employees.designation.name',
      'employees.location.name', 'employees.gender', 'employees.employmentType',
      'employees.dateOfJoining', 'employees.status',
    ],
  },
  {
    id: 'leave_employees',
    label: 'Leave + Employee Details',
    primaryModule: 'leave',
    joinedModule: 'employees',
    description: 'Join leave requests with employee info',
    additionalFields: [
      'employees.department.name', 'employees.designation.name',
      'employees.employmentType', 'employees.location.name',
    ],
  },
  {
    id: 'attendance_employees',
    label: 'Attendance + Employee Details',
    primaryModule: 'attendance',
    joinedModule: 'employees',
    description: 'Join attendance with employee and department info',
    additionalFields: [
      'employees.department.name', 'employees.location.name', 'employees.employmentType',
    ],
  },
  {
    id: 'payroll_leave',
    label: 'Payroll + Leave Summary',
    primaryModule: 'payroll',
    joinedModule: 'leave',
    description: 'Correlate payroll month with leave usage in same period',
    additionalFields: ['leave.totalDays', 'leave.leaveType.name'],
  },
  {
    id: 'employees_tds',
    label: 'Employee + TDS Projection',
    primaryModule: 'employees',
    joinedModule: 'tds',
    description: 'Employee headcount with TDS liability overview',
    additionalFields: [
      'tds.projectedAnnualTax', 'tds.tdsDeductedYtd',
      'tds.taxableIncome', 'tds.regime',
    ],
  },
  {
    id: 'payroll_attendance',
    label: 'Payroll + Attendance',
    primaryModule: 'payroll',
    joinedModule: 'attendance',
    description: 'LOP days correlated with attendance compliance',
    additionalFields: ['attendance.workingHours', 'attendance.isLate', 'attendance.overtimeHours'],
  },
];

export function getSafeJoin(joinId: string): JoinDefinition | undefined {
  return SAFE_JOINS.find(j => j.id === joinId);
}

export function getJoinsForModule(module: string): JoinDefinition[] {
  return SAFE_JOINS.filter(j => j.primaryModule === module || j.joinedModule === module);
}
