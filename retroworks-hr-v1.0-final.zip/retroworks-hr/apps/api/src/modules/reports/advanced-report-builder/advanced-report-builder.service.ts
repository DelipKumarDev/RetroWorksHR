/**
 * Advanced Report Builder Service — Enterprise Grade
 * ──────────────────────────────────────────────────────────────────────────────
 * Orchestrates: field validation → query execution → masking → export →
 *               saved report CRUD → scheduled delivery → audit trail.
 *
 * Security contract:
 *   - Every query is tenant-scoped (tenantId injected, never user-supplied)
 *   - PII masking applied before any row leaves this service
 *   - Audit log written on every report run and export
 *   - Scheduled delivery enforces same masking as live run
 *   - No raw SQL exposed at any layer
 *
 * Performance contract:
 *   - Cursor pagination — no OFFSET, no full-table scan
 *   - 5-second query timeout
 *   - 10,000 row max export cap
 *   - Aggregations done in-memory after bounded fetch
 */

import {
  Injectable, Logger, NotFoundException,
  BadRequestException, ForbiddenException,
} from '@nestjs/common';
import { Cron, CronExpression } from '@nestjs/schedule';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { PrismaClient } from '@prisma/client';
import * as crypto from 'crypto';
import {
  executeQuery, validateFields, ReportQueryError,
  type ReportConfig, type QueryResult, type FilterGroup,
  type AggregationSpec, type CalculatedField,
} from './query-builder';
import {
  FULL_CATALOGUE, SAFE_JOINS, getSafeJoin,
  PII_UNMASK_ROLES, PAYROLL_UNMASK_ROLES,
  type FieldDefinition,
} from './field-catalogue';

export type ChartType = 'table' | 'bar' | 'line' | 'pie' | 'kpi' | 'heatmap';
export type ScheduleFrequency = 'DAILY' | 'WEEKLY' | 'MONTHLY';
export type ExportFormat = 'csv' | 'json';
export type ReportVisibility = 'PRIVATE' | 'SHARED' | 'ENTITY';

export interface ScheduledDelivery {
  enabled: boolean;
  frequency: ScheduleFrequency;
  dayOfWeek?: number;   // 0–6 for WEEKLY
  dayOfMonth?: number;  // 1–31 for MONTHLY
  time?: string;        // HH:MM IST
  emails: string[];
  format: ExportFormat;
  lastSentAt?: string;
  lastStatus?: 'SUCCESS' | 'FAILED';
}

export interface SaveReportDto {
  name: string;
  description?: string;
  module: string;
  fields: string[];
  joinId?: string;
  filterGroup?: FilterGroup;
  groupBy?: string[];
  aggregations?: AggregationSpec[];
  calculatedFields?: CalculatedField[];
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  limit?: number;
  chartType?: ChartType;
  visibility?: ReportVisibility;
  entityId?: string;       // For entity-scoped reports
  allowedRoles?: string[]; // Roles that can access shared report
  scheduledDelivery?: ScheduledDelivery;
  tags?: string[];
}

@Injectable()
export class AdvancedReportBuilderService {
  private readonly logger = new Logger(AdvancedReportBuilderService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ─── FIELD CATALOGUE ───────────────────────────────────────────────────────

  getFieldCatalogue(module?: string, userRoles: string[] = []) {
    const isPrivileged = userRoles.some(r =>
      PII_UNMASK_ROLES.has(r) || PAYROLL_UNMASK_ROLES.has(r)
    );

    const catalogue = module
      ? { [module]: FULL_CATALOGUE[module] ?? [] }
      : FULL_CATALOGUE;

    // Filter out fields the user's role can never see (ultra-sensitive)
    const filtered: typeof FULL_CATALOGUE = {};
    for (const [mod, fields] of Object.entries(catalogue)) {
      filtered[mod] = fields.map(f => ({
        ...f,
        // Mark masked fields so UI can show the lock icon
        _masked: f.pii
          ? !userRoles.some(r => PII_UNMASK_ROLES.has(r))
          : f.sensitivePayroll
            ? !userRoles.some(r => PAYROLL_UNMASK_ROLES.has(r))
            : false,
      }));
    }

    return { modules: filtered, joins: SAFE_JOINS };
  }

  // ─── SAVED REPORT CRUD ─────────────────────────────────────────────────────

  async listReports(tenantId: string, userId: string, userRoles: string[]) {
    const isAdmin = userRoles.some(r => ['hr-admin', 'super-admin', 'cfo', 'finance-controller'].includes(r));

    const reports = await (this.prisma as any).savedReport.findMany({
      where: {
        tenantId,
        deletedAt: null,
        OR: [
          { createdBy: userId },                              // Own reports
          { visibility: 'SHARED' },                          // Shared with tenant
          ...(isAdmin ? [{ visibility: 'ENTITY' }] : []),   // Entity reports for admins
        ],
      },
      orderBy: { updatedAt: 'desc' },
      select: {
        id: true, name: true, description: true, module: true,
        chartType: true, visibility: true, tags: true,
        createdBy: true, updatedAt: true, createdAt: true,
        scheduledDelivery: true, fields: true,
        _count: { select: { reportVersions: true } },
      },
    });

    return reports;
  }

  async getReport(tenantId: string, reportId: string, userId: string, userRoles: string[]) {
    const report = await (this.prisma as any).savedReport.findFirst({
      where: { id: reportId, tenantId, deletedAt: null },
    });
    if (!report) throw new NotFoundException('Report not found');

    // Access check
    const isOwner = report.createdBy === userId;
    const isAdmin = userRoles.some(r => ['hr-admin', 'super-admin', 'cfo', 'finance-controller'].includes(r));
    if (!isOwner && report.visibility === 'PRIVATE' && !isAdmin) {
      throw new ForbiddenException('Access denied to this report');
    }
    if (report.allowedRoles?.length && !userRoles.some(r => report.allowedRoles.includes(r)) && !isAdmin) {
      throw new ForbiddenException('Your role does not have access to this report');
    }

    return report;
  }

  async saveReport(tenantId: string, dto: SaveReportDto, createdBy: string, userRoles: string[]) {
    // Validate all fields against catalogue
    const { blocked } = validateFields(dto.fields, dto.module);
    if (blocked.length > 0) {
      throw new BadRequestException(`Unknown fields: ${blocked.join(', ')}`);
    }

    // Validate join if specified
    if (dto.joinId && !getSafeJoin(dto.joinId)) {
      throw new BadRequestException(`Unknown join: ${dto.joinId}. Only pre-defined joins are allowed.`);
    }

    const configHash = crypto
      .createHash('sha256')
      .update(JSON.stringify({
        module: dto.module, fields: dto.fields,
        filterGroup: dto.filterGroup, groupBy: dto.groupBy,
        aggregations: dto.aggregations,
      }))
      .digest('hex')
      .slice(0, 12);

    const report = await (this.prisma as any).savedReport.create({
      data: {
        tenantId,
        name: dto.name,
        description: dto.description ?? null,
        module: dto.module,
        fields: dto.fields,
        joinId: dto.joinId ?? null,
        filterGroup: (dto.filterGroup ?? null) as any,
        groupBy: dto.groupBy ?? [],
        aggregations: (dto.aggregations ?? []) as any,
        calculatedFields: (dto.calculatedFields ?? []) as any,
        sortBy: dto.sortBy ?? null,
        sortOrder: dto.sortOrder ?? 'asc',
        limit: dto.limit ?? 500,
        chartType: dto.chartType ?? 'table',
        visibility: dto.visibility ?? 'PRIVATE',
        entityId: dto.entityId ?? null,
        allowedRoles: dto.allowedRoles ?? [],
        scheduledDelivery: (dto.scheduledDelivery ?? { enabled: false }) as any,
        tags: dto.tags ?? [],
        configHash,
        createdBy,
        updatedBy: createdBy,
        version: 1,
      },
    });

    // Create initial version snapshot
    await this.snapshotVersion(report.id, dto, 1, createdBy, 'Initial version');

    await this.auditLog(tenantId, createdBy, 'report_created', report.id, { name: dto.name });
    return report;
  }

  async updateReport(
    tenantId: string, reportId: string,
    dto: Partial<SaveReportDto>, updatedBy: string, userRoles: string[],
  ) {
    const report = await this.getReport(tenantId, reportId, updatedBy, userRoles);
    if (report.createdBy !== updatedBy && !userRoles.some(r => ['hr-admin', 'super-admin'].includes(r))) {
      throw new ForbiddenException('Only the report owner or admin can update this report');
    }

    const newVersion = (report.version ?? 1) + 1;
    await this.snapshotVersion(reportId, { ...report, ...dto } as SaveReportDto, newVersion, updatedBy);

    const updated = await (this.prisma as any).savedReport.update({
      where: { id: reportId },
      data: { ...dto, updatedBy, version: newVersion, updatedAt: new Date() },
    });

    await this.auditLog(tenantId, updatedBy, 'report_updated', reportId, { version: newVersion });
    return updated;
  }

  async deleteReport(tenantId: string, reportId: string, deletedBy: string) {
    await (this.prisma as any).savedReport.update({
      where: { id: reportId },
      data: { deletedAt: new Date() },
    });
    await this.auditLog(tenantId, deletedBy, 'report_deleted', reportId, {});
  }

  async duplicateReport(
    tenantId: string, reportId: string,
    newName: string, createdBy: string, userRoles: string[],
  ) {
    const report = await this.getReport(tenantId, reportId, createdBy, userRoles);
    const { id, createdAt, updatedAt, deletedAt, version, ...rest } = report as any;
    return this.saveReport(tenantId, { ...rest, name: newName, visibility: 'PRIVATE' }, createdBy, userRoles);
  }

  async getVersionHistory(tenantId: string, reportId: string) {
    return (this.prisma as any).reportVersion.findMany({
      where: { reportId, tenantId },
      orderBy: { version: 'desc' },
      select: { id: true, version: true, createdBy: true, note: true, createdAt: true, configHash: true },
    });
  }

  async rollbackVersion(
    tenantId: string, reportId: string,
    targetVersion: number, rolledBackBy: string, userRoles: string[],
  ) {
    const versionRecord = await (this.prisma as any).reportVersion.findFirst({
      where: { reportId, tenantId, version: targetVersion },
    });
    if (!versionRecord) throw new NotFoundException(`Version ${targetVersion} not found`);
    return this.updateReport(
      tenantId, reportId,
      JSON.parse(versionRecord.config),
      rolledBackBy, userRoles,
    );
  }

  // ─── REPORT EXECUTION ──────────────────────────────────────────────────────

  async runReport(
    tenantId: string,
    config: Omit<ReportConfig, 'tenantId' | 'userRoles'>,
    userId: string,
    userRoles: string[],
  ): Promise<QueryResult> {
    const result = await executeQuery(this.prisma as any, {
      ...config,
      tenantId,
      userRoles,
    });

    await this.auditLog(tenantId, userId, 'report_run', 'custom', {
      module: config.module,
      rowCount: result.total,
      executionMs: result.executionMs,
      maskedFields: result.maskedFields,
    });

    return result;
  }

  async runSavedReport(
    tenantId: string,
    reportId: string,
    userId: string,
    userRoles: string[],
    overrides: { cursor?: string; limit?: number } = {},
  ): Promise<QueryResult & { report: any }> {
    const report = await this.getReport(tenantId, reportId, userId, userRoles);

    const result = await executeQuery(this.prisma as any, {
      module: report.module,
      fields: report.fields as string[],
      joinId: report.joinId ?? undefined,
      filterGroup: report.filterGroup as FilterGroup ?? undefined,
      groupBy: report.groupBy as string[] ?? undefined,
      aggregations: report.aggregations as AggregationSpec[] ?? undefined,
      calculatedFields: report.calculatedFields as CalculatedField[] ?? undefined,
      sortBy: report.sortBy ?? undefined,
      sortOrder: (report.sortOrder as any) ?? 'asc',
      limit: overrides.limit ?? report.limit ?? 500,
      cursor: overrides.cursor,
      tenantId,
      userRoles,
    });

    await this.auditLog(tenantId, userId, 'saved_report_run', reportId, {
      rowCount: result.total,
      executionMs: result.executionMs,
    });

    return { ...result, report };
  }

  // ─── EXPORT ────────────────────────────────────────────────────────────────

  async exportReport(
    tenantId: string,
    reportId: string,
    format: ExportFormat,
    userId: string,
    userRoles: string[],
  ): Promise<{ content: string; filename: string; contentType: string }> {
    const result = await this.runSavedReport(tenantId, reportId, userId, userRoles, { limit: 10_000 });
    const filename = `${result.report.name.replace(/\s+/g, '-').toLowerCase()}-${Date.now()}`;

    await this.auditLog(tenantId, userId, 'report_exported', reportId, {
      format, rowCount: result.rows.length, maskedFields: result.maskedFields,
    });

    if (format === 'csv') {
      return {
        content: toCSV(result.rows, result.report.fields as string[]),
        filename: `${filename}.csv`,
        contentType: 'text/csv',
      };
    }

    return {
      content: JSON.stringify({ data: result.rows, total: result.total, exportedAt: new Date(), reportName: result.report.name }, null, 2),
      filename: `${filename}.json`,
      contentType: 'application/json',
    };
  }

  // ─── SCHEDULED DELIVERY ────────────────────────────────────────────────────

  @Cron('0 6 * * *', { timeZone: 'Asia/Kolkata' }) // 6am IST daily
  async runDailyScheduled() { await this.runScheduled('DAILY'); }

  @Cron('0 7 * * 1', { timeZone: 'Asia/Kolkata' }) // 7am IST Monday
  async runWeeklyScheduled() { await this.runScheduled('WEEKLY'); }

  @Cron('0 7 1 * *', { timeZone: 'Asia/Kolkata' }) // 7am IST 1st of month
  async runMonthlyScheduled() { await this.runScheduled('MONTHLY'); }

  private async runScheduled(frequency: ScheduleFrequency) {
    const reports = await (this.prisma as any).savedReport.findMany({
      where: {
        deletedAt: null,
        scheduledDelivery: {
          path: ['enabled'], equals: true,
        },
      },
    });

    const toRun = reports.filter((r: any) => {
      const sched = r.scheduledDelivery as ScheduledDelivery;
      return sched?.enabled && sched.frequency === frequency;
    });

    this.logger.log(`Running ${frequency} scheduled reports: ${toRun.length} reports`);

    for (const report of toRun) {
      const sched = report.scheduledDelivery as ScheduledDelivery;
      if (!sched.emails?.length) continue;

      try {
        // Use a system user role set for scheduled delivery
        // Always apply masking (never use privileged roles for scheduled delivery)
        const systemRoles: string[] = [];
        const result = await executeQuery(this.prisma as any, {
          module: report.module,
          fields: report.fields as string[],
          filterGroup: report.filterGroup as FilterGroup ?? undefined,
          groupBy: report.groupBy as string[] ?? undefined,
          aggregations: report.aggregations as AggregationSpec[] ?? undefined,
          limit: 10_000,
          tenantId: report.tenantId,
          userRoles: systemRoles, // No elevated roles = full masking
        });

        const content = sched.format === 'csv'
          ? toCSV(result.rows, report.fields as string[])
          : JSON.stringify(result.rows, null, 2);

        this.events.emit('report.scheduled.ready', {
          tenantId: report.tenantId,
          reportId: report.id,
          reportName: report.name,
          emails: sched.emails,
          format: sched.format,
          content,
          rowCount: result.rows.length,
          frequency,
          maskedFields: result.maskedFields,
        });

        // Update last sent
        await (this.prisma as any).savedReport.update({
          where: { id: report.id },
          data: {
            scheduledDelivery: {
              ...sched,
              lastSentAt: new Date().toISOString(),
              lastStatus: 'SUCCESS',
            },
          },
        });

        await this.auditLog(report.tenantId, 'scheduler', 'report_scheduled_sent', report.id, {
          frequency, emails: sched.emails, rowCount: result.rows.length,
        });

        this.logger.log(`Scheduled report "${report.name}" sent to ${sched.emails.join(', ')}`);
      } catch (err: any) {
        this.logger.error(`Scheduled report "${report.name}" failed: ${err.message}`);
        const sched = report.scheduledDelivery as ScheduledDelivery;
        await (this.prisma as any).savedReport.update({
          where: { id: report.id },
          data: {
            scheduledDelivery: { ...sched, lastStatus: 'FAILED', lastSentAt: new Date().toISOString() },
          },
        });
      }
    }
  }

  // ─── HELPERS ───────────────────────────────────────────────────────────────

  private async snapshotVersion(
    reportId: string,
    config: SaveReportDto,
    version: number,
    createdBy: string,
    note?: string,
  ) {
    const configHash = crypto
      .createHash('sha256')
      .update(JSON.stringify(config))
      .digest('hex')
      .slice(0, 12);

    await (this.prisma as any).reportVersion.create({
      data: {
        reportId,
        tenantId: (config as any).tenantId ?? '',
        version,
        config: JSON.stringify(config),
        configHash,
        createdBy,
        note: note ?? null,
      },
    }).catch(() => null); // Non-fatal — versioning is best-effort
  }

  private async auditLog(
    tenantId: string,
    performedBy: string,
    action: string,
    resourceId: string,
    metadata: Record<string, unknown>,
  ) {
    await (this.prisma as any).auditLog.create({
      data: {
        tenantId,
        action,
        resourceType: 'report',
        resourceId,
        performedBy,
        metadata: metadata as any,
        timestamp: new Date(),
      },
    }).catch(() => null); // Audit failure must not block the main flow
  }
}

// ─── CSV generator ─────────────────────────────────────────────────────────────

export function toCSV(rows: Record<string, unknown>[], fields: string[]): string {
  if (rows.length === 0) return fields.join(',') + '\n';

  // Header: use all keys from first row if fields aren't specific
  const headers = fields.length > 0 ? fields : Object.keys(rows[0]!).filter(k => k !== 'id');
  const headerLine = headers.map(h => `"${h}"`).join(',');

  const body = rows.map(row =>
    headers.map(h => {
      const val = row[h] ?? '';
      const s = String(val).replace(/"/g, '""');
      return `"${s}"`;
    }).join(',')
  ).join('\n');

  return `${headerLine}\n${body}`;
}
