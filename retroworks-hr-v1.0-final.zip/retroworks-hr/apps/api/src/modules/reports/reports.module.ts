import { AdvancedReportBuilderModule } from './advanced-report-builder/advanced-report-builder.module';
import { Injectable, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { Controller, Get, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

@Injectable()
export class ReportsService {
  private readonly logger = new Logger(ReportsService.name);
  constructor(private readonly prisma: PrismaClient) {}

  async getHeadcountReport(tenantId: string) {
    const [totalActive, byDepartment, byLocation, byEmploymentType, byGender, newJoiners, attrition] = await Promise.all([
      this.prisma.employee.count({ where: { tenantId, status: 'active', deletedAt: null } }),
      this.prisma.employee.groupBy({ by: ['departmentId'], where: { tenantId, status: 'active', deletedAt: null }, _count: { id: true } }),
      this.prisma.employee.groupBy({ by: ['locationId'], where: { tenantId, status: 'active', deletedAt: null }, _count: { id: true } }),
      this.prisma.employee.groupBy({ by: ['employmentType'], where: { tenantId, status: 'active', deletedAt: null }, _count: { id: true } }),
      this.prisma.employee.groupBy({ by: ['gender'], where: { tenantId, status: 'active', deletedAt: null }, _count: { id: true } }),
      this.prisma.employee.count({ where: { tenantId, status: 'active', deletedAt: null, dateOfJoining: { gte: new Date(Date.now() - 30 * 86_400_000) } } }),
      this.prisma.employee.count({ where: { tenantId, status: { in: ['inactive', 'terminated'] }, dateOfLeaving: { gte: new Date(Date.now() - 30 * 86_400_000) } } }),
    ]);

    const departments = await this.prisma.department.findMany({ where: { tenantId }, select: { id: true, name: true } });
    const deptMap = new Map(departments.map(d => [d.id, d.name]));
    const locations = await this.prisma.location.findMany({ where: { tenantId }, select: { id: true, name: true, city: true } });
    const locMap = new Map(locations.map(l => [l.id, `${l.name} (${l.city})`]));

    return {
      summary: { totalActive, newJoiners30Days: newJoiners, attrition30Days: attrition, attritionRate30Days: totalActive > 0 ? ((attrition / totalActive) * 100).toFixed(2) + '%' : '0%' },
      byDepartment: byDepartment.map(d => ({ department: deptMap.get(d.departmentId ?? '') ?? 'Unassigned', count: d._count.id, percentage: totalActive > 0 ? ((d._count.id / totalActive) * 100).toFixed(1) : '0' })).sort((a, b) => b.count - a.count),
      byLocation: byLocation.map(l => ({ location: locMap.get(l.locationId ?? '') ?? 'Unassigned', count: l._count.id })).sort((a, b) => b.count - a.count),
      byEmploymentType: byEmploymentType.map(t => ({ type: t.employmentType ?? 'Unknown', count: t._count.id })),
      byGender: byGender.map(g => ({ gender: g.gender ?? 'Undisclosed', count: g._count.id, percentage: totalActive > 0 ? ((g._count.id / totalActive) * 100).toFixed(1) : '0' })),
    };
  }

  async getAttritionTrend(tenantId: string, months = 12) {
    const result = [];
    const now = new Date();
    for (let i = months - 1; i >= 0; i--) {
      const monthStart = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthEnd = new Date(now.getFullYear(), now.getMonth() - i + 1, 0);
      const [joiners, leavers] = await Promise.all([
        this.prisma.employee.count({ where: { tenantId, dateOfJoining: { gte: monthStart, lte: monthEnd } } }),
        this.prisma.employee.count({ where: { tenantId, dateOfLeaving: { gte: monthStart, lte: monthEnd } } }),
      ]);
      result.push({ month: monthStart.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' }), joiners, leavers, netChange: joiners - leavers });
    }
    return result;
  }

  async getPayrollReport(tenantId: string, month: number, year: number) {
    const payslips = await this.prisma.payslip.findMany({
      where: { tenantId, month, year, status: { in: ['finalized', 'paid'] } },
      include: { employee: { select: { firstName: true, lastName: true, employeeCode: true, department: { select: { name: true } } } } },
      orderBy: { employee: { employeeCode: 'asc' } },
    });

    const totals = payslips.reduce((acc, p) => ({
      grossPay: acc.grossPay + p.grossPay, netPay: acc.netPay + p.netPay,
      pfEmployee: acc.pfEmployee + p.pfEmployee, pfEmployer: acc.pfEmployer + p.pfEmployer,
      esiEmployee: acc.esiEmployee + (p.esiEmployee ?? 0), esiEmployer: acc.esiEmployer + (p.esiEmployer ?? 0),
      tdsDeducted: acc.tdsDeducted + p.tdsDeducted, professionalTax: acc.professionalTax + (p.professionalTax ?? 0),
    }), { grossPay: 0, netPay: 0, pfEmployee: 0, pfEmployer: 0, esiEmployee: 0, esiEmployer: 0, tdsDeducted: 0, professionalTax: 0 });

    return { month, year, employeeCount: payslips.length, totals, payslips: payslips.map(p => ({ employeeCode: p.employee.employeeCode, name: `${p.employee.firstName} ${p.employee.lastName}`, department: p.employee.department?.name, grossPay: p.grossPay, netPay: p.netPay, pfEmployee: p.pfEmployee, tds: p.tdsDeducted })) };
  }

  async getLeaveReport(tenantId: string, year: number) {
    const [byType, byStatus] = await Promise.all([
      this.prisma.leaveRequest.groupBy({ by: ['leaveTypeId'], where: { tenantId, startDate: { gte: new Date(year, 0, 1), lt: new Date(year + 1, 0, 1) } }, _sum: { days: true }, _count: { id: true } }),
      this.prisma.leaveRequest.groupBy({ by: ['status'], where: { tenantId, startDate: { gte: new Date(year, 0, 1), lt: new Date(year + 1, 0, 1) } }, _count: { id: true } }),
    ]);
    return { year, byType, byStatus };
  }

  async getAttendanceReport(tenantId: string, month: number, year: number) {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    const [byStatus, avgHours, lateArrivals] = await Promise.all([
      this.prisma.attendanceRecord.groupBy({ by: ['status'], where: { tenantId, date: { gte: startDate, lte: endDate } }, _count: { id: true } }),
      this.prisma.attendanceRecord.aggregate({ where: { tenantId, date: { gte: startDate, lte: endDate }, status: 'present' }, _avg: { totalMinutes: true } }),
      this.prisma.attendanceRecord.count({ where: { tenantId, date: { gte: startDate, lte: endDate }, isLate: true } }),
    ]);
    return { month, year, byStatus: byStatus.map(s => ({ status: s.status, count: s._count.id })), avgWorkingHours: avgHours._avg.totalMinutes ? Math.round((avgHours._avg.totalMinutes / 60) * 10) / 10 : 0, lateArrivals };
  }
}

@ApiTags('reports')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('hr-admin', 'super-admin')
@Controller('reports')
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  @Get('headcount')
  @ApiOperation({ summary: 'Headcount by dept / location / gender' })
  headcount(@CurrentUser() u: JwtPayload) { return this.reportsService.getHeadcountReport(u.tid); }

  @Get('attrition-trend')
  attritionTrend(@Query('months') months: string | undefined, @CurrentUser() u: JwtPayload) { return this.reportsService.getAttritionTrend(u.tid, months ? parseInt(months) : 12); }

  @Get('payroll')
  payrollReport(@Query('month') month: string, @Query('year') year: string, @CurrentUser() u: JwtPayload) { return this.reportsService.getPayrollReport(u.tid, parseInt(month || String(new Date().getMonth() + 1)), parseInt(year || String(new Date().getFullYear()))); }

  @Get('leave')
  leaveReport(@Query('year') year: string | undefined, @CurrentUser() u: JwtPayload) { return this.reportsService.getLeaveReport(u.tid, parseInt(year ?? String(new Date().getFullYear()))); }

  @Get('attendance')
  attendanceReport(@Query('month') month: string | undefined, @Query('year') year: string | undefined, @CurrentUser() u: JwtPayload) { return this.reportsService.getAttendanceReport(u.tid, parseInt(month ?? String(new Date().getMonth() + 1)), parseInt(year ?? String(new Date().getFullYear()))); }
}

@Module({ controllers: [ReportsController], providers: [ReportsService], exports: [ReportsService] })
export class ReportsModule {}
