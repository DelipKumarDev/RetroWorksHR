/**
 * Config Validator + Health Score Engine
 * ──────────────────────────────────────────────────────────────────────────────
 * Runs 25 deterministic checks across: statutory, payroll, leave, roles,
 * bank details, security, data quality, and performance.
 *
 * Pure functions — no NestJS dependencies — so tests run standalone.
 * The service wrapper in setup-wizard.module.ts injects PrismaClient.
 */

import type {
  ConfigIssue, ValidationResult, TenantHealthScore,
  HealthDimension, HealthStatus, ValidationSeverity, ValidationCategory,
} from './types';

// ─── Check registry ───────────────────────────────────────────────────────────

export interface CheckContext {
  tenantId: string;
  tenant: any;                    // Tenant record
  legalEntities: any[];
  employees: any[];               // Active employees (basic fields)
  payrollComponents: any[];
  leaveTypes: any[];
  leavePolicies: any[];
  roles: any[];
  payrollRuns: any[];             // Last 3 runs
  workerCategories: any[];
  savedReports: any[];
  auditLogs: any[];               // Last 100 entries
  backupSummary: any;
}

export interface CheckResult {
  id: string;
  passed: boolean;
  issue?: Omit<ConfigIssue, 'detectedAt' | 'resolvedAt'>;
}

type CheckFn = (ctx: CheckContext) => CheckResult | CheckResult[];

// ─── Individual checks ────────────────────────────────────────────────────────

const checks: Array<{ fn: CheckFn; category: ValidationCategory }> = [

  // ── STATUTORY ─────────────────────────────────────────────────────────────

  {
    category: 'statutory',
    fn: (ctx) => {
      const pfEntities = ctx.legalEntities.filter(
        (e: any) => ctx.workerCategories.some((w: any) => w.applyPF) && !e.pfRegistrationNumber
      );
      return {
        id: 'STAT_001_PF_REG',
        passed: pfEntities.length === 0,
        issue: pfEntities.length > 0 ? {
          id: 'STAT_001_PF_REG',
          severity: 'CRITICAL',
          category: 'statutory',
          title: 'PF Registration Number Missing',
          description: `${pfEntities.length} legal entity(ies) have no PF registration number, but worker categories have applyPF=true. Payroll cannot be filed.`,
          recommendation: 'Add PF registration numbers for each legal entity under Settings → Legal Entities.',
          affectedModule: 'payroll',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/entities',
        } : undefined,
      };
    },
  },

  {
    category: 'statutory',
    fn: (ctx) => {
      const tdsEntities = ctx.legalEntities.filter((e: any) => !e.tan);
      const hasTdsRun = ctx.payrollRuns.length > 0;
      return {
        id: 'STAT_002_TAN',
        passed: !hasTdsRun || tdsEntities.length === 0,
        issue: hasTdsRun && tdsEntities.length > 0 ? {
          id: 'STAT_002_TAN',
          severity: 'CRITICAL',
          category: 'statutory',
          title: 'TAN Number Missing Before TDS Run',
          description: `${tdsEntities.length} entity(ies) have no TAN number. TDS deducted cannot be filed with TRACES.`,
          recommendation: 'Add TAN number under Settings → Legal Entities before running payroll.',
          affectedModule: 'payroll',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/entities',
        } : undefined,
      };
    },
  },

  {
    category: 'statutory',
    fn: (ctx) => {
      const esiEntities = ctx.legalEntities.filter(
        (e: any) => ctx.workerCategories.some((w: any) => w.applyESI) && !e.esiRegistrationNumber
      );
      return {
        id: 'STAT_003_ESI_REG',
        passed: esiEntities.length === 0,
        issue: esiEntities.length > 0 ? {
          id: 'STAT_003_ESI_REG',
          severity: 'HIGH',
          category: 'statutory',
          title: 'ESI Registration Missing',
          description: `${esiEntities.length} entity(ies) are missing ESI registration numbers.`,
          recommendation: 'Add ESIC registration number under Settings → Legal Entities.',
          affectedModule: 'payroll',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/entities',
        } : undefined,
      };
    },
  },

  {
    category: 'statutory',
    fn: (ctx) => {
      const companyPan = ctx.legalEntities.every((e: any) => e.pan && e.pan.length === 10);
      return {
        id: 'STAT_004_PAN',
        passed: companyPan && ctx.legalEntities.length > 0,
        issue: !companyPan ? {
          id: 'STAT_004_PAN',
          severity: 'HIGH',
          category: 'statutory',
          title: 'Company PAN Missing or Invalid',
          description: 'At least one legal entity is missing a valid 10-character PAN number.',
          recommendation: 'Add company PAN under Settings → Legal Entities.',
          affectedModule: 'payroll',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/entities',
        } : undefined,
      };
    },
  },

  // ── PAYROLL ───────────────────────────────────────────────────────────────

  {
    category: 'payroll',
    fn: (ctx) => {
      const earnings = ctx.payrollComponents.filter((c: any) => !c.isDeduction && c.isActive);
      const hasBasic = earnings.some((c: any) => c.code === 'BASIC');
      const hasGrossFormula = ctx.payrollComponents.some(
        (c: any) => c.code === 'SPECIAL' || (c.formula && c.formula.includes('GROSS'))
      );
      return {
        id: 'PAY_001_GROSS_IDENTITY',
        passed: hasBasic && hasGrossFormula,
        issue: !hasBasic || !hasGrossFormula ? {
          id: 'PAY_001_GROSS_IDENTITY',
          severity: 'CRITICAL',
          category: 'payroll',
          title: 'GROSS Identity Not Balanced',
          description: !hasBasic
            ? 'No BASIC component found. GROSS = sum of earnings requires BASIC as anchor.'
            : 'No component anchors to GROSS (e.g. SPECIAL = GROSS - BASIC - HRA). Payroll totals will not balance.',
          recommendation: 'Add a SPECIAL_ALLOWANCE component with formula: GROSS - BASIC - HRA (adjust as needed).',
          affectedModule: 'payroll',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/components',
        } : undefined,
      };
    },
  },

  {
    category: 'payroll',
    fn: (ctx) => {
      const hasPayroll = ctx.payrollComponents.filter((c: any) => c.isActive).length > 0;
      return {
        id: 'PAY_002_NO_COMPONENTS',
        passed: hasPayroll,
        issue: !hasPayroll ? {
          id: 'PAY_002_NO_COMPONENTS',
          severity: 'CRITICAL',
          category: 'payroll',
          title: 'No Active Payroll Components',
          description: 'Payroll has no active earnings or deduction components configured.',
          recommendation: 'Configure payroll components or apply an industry preset in Settings → Payroll Components.',
          affectedModule: 'payroll',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/components',
        } : undefined,
      };
    },
  },

  {
    category: 'payroll',
    fn: (ctx) => {
      const unlockedRuns = ctx.payrollRuns.filter(
        (r: any) => r.status === 'processed' && !r.approvedAt &&
          new Date(r.createdAt) < new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      );
      return {
        id: 'PAY_003_UNLOCKED_RUNS',
        passed: unlockedRuns.length === 0,
        issue: unlockedRuns.length > 0 ? {
          id: 'PAY_003_UNLOCKED_RUNS',
          severity: 'HIGH',
          category: 'payroll',
          title: `${unlockedRuns.length} Payroll Run(s) Awaiting Approval`,
          description: 'Processed payroll runs older than 7 days have not been approved. This blocks salary disbursement.',
          recommendation: 'Approve or reject pending payroll runs in the Payroll module.',
          affectedModule: 'payroll',
          canAutoFix: false,
          fixRoute: '/dashboard/payroll',
        } : undefined,
      };
    },
  },

  {
    category: 'payroll',
    fn: (ctx) => {
      const noCtc = ctx.employees.filter((e: any) => e.status === 'active' && (!e.ctc || e.ctc <= 0));
      return {
        id: 'PAY_004_MISSING_CTC',
        passed: noCtc.length === 0,
        issue: noCtc.length > 0 ? {
          id: 'PAY_004_MISSING_CTC',
          severity: 'HIGH',
          category: 'payroll',
          title: `${noCtc.length} Active Employee(s) Missing CTC`,
          description: 'Active employees without a CTC value cannot be processed in payroll.',
          recommendation: 'Update employee CTC in People → Employee → Compensation.',
          affectedModule: 'payroll',
          canAutoFix: false,
          fixRoute: '/dashboard/people',
        } : undefined,
      };
    },
  },

  // ── LEAVE ─────────────────────────────────────────────────────────────────

  {
    category: 'leave',
    fn: (ctx) => {
      const missing = ctx.leaveTypes.filter((lt: any) => {
        const policy = ctx.leavePolicies.find((p: any) =>
          p.entries?.some((e: any) => e.leaveTypeId === lt.id)
        );
        const entry = policy?.entries?.find((e: any) => e.leaveTypeId === lt.id);
        return !entry || entry.carryForward === undefined || entry.carryForward === null;
      });
      return {
        id: 'LEAVE_001_CARRY_FORWARD',
        passed: missing.length === 0,
        issue: missing.length > 0 ? {
          id: 'LEAVE_001_CARRY_FORWARD',
          severity: 'MEDIUM',
          category: 'leave',
          title: 'Leave Carry-Forward Rule Not Set',
          description: `${missing.length} leave type(s) have no carry-forward rule defined. Year-end accrual will fail.`,
          recommendation: 'Configure carry-forward rules in Leave → Leave Policies.',
          affectedModule: 'leave',
          canAutoFix: false,
          fixRoute: '/dashboard/leave',
        } : undefined,
      };
    },
  },

  {
    category: 'leave',
    fn: (ctx) => {
      const hasPolicy = ctx.leavePolicies.length > 0;
      return {
        id: 'LEAVE_002_NO_POLICY',
        passed: hasPolicy,
        issue: !hasPolicy ? {
          id: 'LEAVE_002_NO_POLICY',
          severity: 'HIGH',
          category: 'leave',
          title: 'No Leave Policy Configured',
          description: 'No leave policy exists. Employees cannot apply for leave.',
          recommendation: 'Create at least one leave policy in Leave → Policies.',
          affectedModule: 'leave',
          canAutoFix: false,
          fixRoute: '/dashboard/leave',
        } : undefined,
      };
    },
  },

  {
    category: 'leave',
    fn: (ctx) => {
      const hasEL = ctx.leaveTypes.some((lt: any) => lt.code === 'EL' || lt.isPaidLeave);
      return {
        id: 'LEAVE_003_EARNED_LEAVE',
        passed: hasEL,
        issue: !hasEL ? {
          id: 'LEAVE_003_EARNED_LEAVE',
          severity: 'MEDIUM',
          category: 'leave',
          title: 'No Earned/Paid Leave Type Found',
          description: 'Factories Act requires Earned Leave (minimum 1 day per 20 days worked). No paid leave type found.',
          recommendation: 'Add an Earned Leave type with at least 15 days per year.',
          affectedModule: 'leave',
          canAutoFix: false,
          fixRoute: '/dashboard/leave',
        } : undefined,
      };
    },
  },

  // ── ROLES ─────────────────────────────────────────────────────────────────

  {
    category: 'roles',
    fn: (ctx) => {
      const hasCfo = ctx.roles.some(
        (r: any) => ['cfo', 'finance-controller', 'hr-admin', 'super-admin'].includes(r.name?.toLowerCase())
          && r.userCount > 0
      );
      return {
        id: 'ROLE_001_NO_CFO',
        passed: hasCfo,
        issue: !hasCfo ? {
          id: 'ROLE_001_NO_CFO',
          severity: 'HIGH',
          category: 'roles',
          title: 'No Finance/CFO Role Assigned',
          description: 'No user is assigned a finance approval role. Payroll approvals will be blocked.',
          recommendation: 'Assign at least one user to CFO, Finance Controller, or HR Admin role.',
          affectedModule: 'roles',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/roles',
        } : undefined,
      };
    },
  },

  {
    category: 'roles',
    fn: (ctx) => {
      const hasAdmin = ctx.roles.some(
        (r: any) => ['hr-admin', 'super-admin'].includes(r.name?.toLowerCase()) && r.userCount > 0
      );
      return {
        id: 'ROLE_002_NO_ADMIN',
        passed: hasAdmin,
        issue: !hasAdmin ? {
          id: 'ROLE_002_NO_ADMIN',
          severity: 'CRITICAL',
          category: 'roles',
          title: 'No HR Admin Assigned',
          description: 'No user has HR Admin or Super Admin role. System cannot be managed.',
          recommendation: 'Assign at least one user the HR Admin role immediately.',
          affectedModule: 'roles',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/roles',
        } : undefined,
      };
    },
  },

  // ── BANK ──────────────────────────────────────────────────────────────────

  {
    category: 'bank',
    fn: (ctx) => {
      const noBank = ctx.employees.filter(
        (e: any) => e.status === 'active' && (!e.bankAccountNumber || !e.bankIfsc)
      );
      const pct = ctx.employees.filter((e: any) => e.status === 'active').length > 0
        ? noBank.length / ctx.employees.filter((e: any) => e.status === 'active').length
        : 0;
      return {
        id: 'BANK_001_MISSING_ACCOUNT',
        passed: pct < 0.1, // Allow up to 10% missing
        issue: pct >= 0.1 ? {
          id: 'BANK_001_MISSING_ACCOUNT',
          severity: 'HIGH',
          category: 'bank',
          title: `${noBank.length} Employee(s) Missing Bank Details`,
          description: `${Math.round(pct * 100)}% of active employees have no bank account or IFSC. Salary cannot be transferred.`,
          recommendation: 'Collect and update bank details for all employees before next payroll.',
          affectedModule: 'employees',
          canAutoFix: false,
          fixRoute: '/dashboard/people',
        } : undefined,
      };
    },
  },

  {
    category: 'bank',
    fn: (ctx) => {
      const noPan = ctx.employees.filter(
        (e: any) => e.status === 'active' && !e.panNumber
      );
      return {
        id: 'BANK_002_MISSING_PAN',
        passed: noPan.length === 0,
        issue: noPan.length > 0 ? {
          id: 'BANK_002_MISSING_PAN',
          severity: 'HIGH',
          category: 'bank',
          title: `${noPan.length} Employee(s) Missing PAN`,
          description: 'PAN is mandatory for TDS computation and Form 16 generation. Employees without PAN are taxed at 20%.',
          recommendation: 'Collect PAN details from all employees.',
          affectedModule: 'employees',
          canAutoFix: false,
          fixRoute: '/dashboard/people',
        } : undefined,
      };
    },
  },

  // ── SECURITY ──────────────────────────────────────────────────────────────

  {
    category: 'security',
    fn: (ctx) => {
      const recentAudit = ctx.auditLogs.filter(
        (l: any) => l.action === 'payroll_run_approved' &&
          new Date(l.timestamp) > new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
      );
      return {
        id: 'SEC_001_AUDIT_TRAIL',
        passed: recentAudit.length > 0 || ctx.payrollRuns.length === 0,
        issue: recentAudit.length === 0 && ctx.payrollRuns.length > 0 ? {
          id: 'SEC_001_AUDIT_TRAIL',
          severity: 'MEDIUM',
          category: 'security',
          title: 'No Payroll Approval Audit Trail (90 Days)',
          description: 'No payroll approval events found in audit log for last 90 days. Audit trail may be incomplete.',
          recommendation: 'Ensure audit logging is enabled in Settings → Security.',
          affectedModule: 'audit',
          canAutoFix: false,
          fixRoute: '/dashboard/audit',
        } : undefined,
      };
    },
  },

  {
    category: 'security',
    fn: (ctx) => {
      const hasBackup = ctx.backupSummary?.lastSuccessful &&
        new Date(ctx.backupSummary.lastSuccessful) > new Date(Date.now() - 2 * 24 * 60 * 60 * 1000);
      return {
        id: 'SEC_002_BACKUP',
        passed: !!hasBackup,
        issue: !hasBackup ? {
          id: 'SEC_002_BACKUP',
          severity: 'MEDIUM',
          category: 'security',
          title: 'No Recent Backup (48h)',
          description: 'Last successful backup is older than 48 hours or backup has never run.',
          recommendation: 'Configure automated daily backups in Settings → Backup.',
          affectedModule: 'backup',
          canAutoFix: false,
          fixRoute: '/dashboard/backup',
        } : undefined,
      };
    },
  },

  // ── DATA QUALITY ──────────────────────────────────────────────────────────

  {
    category: 'data_quality',
    fn: (ctx) => {
      const noDept = ctx.employees.filter(
        (e: any) => e.status === 'active' && !e.departmentId
      );
      return {
        id: 'DQ_001_NO_DEPT',
        passed: noDept.length === 0,
        issue: noDept.length > 0 ? {
          id: 'DQ_001_NO_DEPT',
          severity: 'MEDIUM',
          category: 'data_quality',
          title: `${noDept.length} Employee(s) Not Assigned to Department`,
          description: 'Employees without departments are excluded from department-level reports.',
          recommendation: 'Assign all employees to a department.',
          affectedModule: 'employees',
          canAutoFix: false,
          fixRoute: '/dashboard/people',
        } : undefined,
      };
    },
  },

  {
    category: 'data_quality',
    fn: (ctx) => {
      const hasDups = (() => {
        const codes = ctx.employees.map((e: any) => e.employeeCode);
        return codes.length !== new Set(codes).size;
      })();
      return {
        id: 'DQ_002_DUPLICATE_EMP_CODE',
        passed: !hasDups,
        issue: hasDups ? {
          id: 'DQ_002_DUPLICATE_EMP_CODE',
          severity: 'CRITICAL',
          category: 'data_quality',
          title: 'Duplicate Employee Codes Detected',
          description: 'Multiple employees share the same employee code. This causes data integrity issues across all modules.',
          recommendation: 'Audit and fix duplicate employee codes immediately in People → Employees.',
          affectedModule: 'employees',
          canAutoFix: false,
          fixRoute: '/dashboard/people',
        } : undefined,
      };
    },
  },

  {
    category: 'data_quality',
    fn: (ctx) => {
      const noDesig = ctx.employees.filter(
        (e: any) => e.status === 'active' && !e.designationId
      );
      return {
        id: 'DQ_003_NO_DESIGNATION',
        passed: noDesig.length === 0,
        issue: noDesig.length > 0 ? {
          id: 'DQ_003_NO_DESIGNATION',
          severity: 'LOW',
          category: 'data_quality',
          title: `${noDesig.length} Employee(s) Missing Designation`,
          description: 'Designation is used in payslips, Form 16, and reports. Missing values degrade document quality.',
          recommendation: 'Assign designations to all employees.',
          affectedModule: 'employees',
          canAutoFix: false,
          fixRoute: '/dashboard/people',
        } : undefined,
      };
    },
  },

  {
    category: 'data_quality',
    fn: (ctx) => {
      const noWorkerCat = ctx.employees.filter(
        (e: any) => e.status === 'active' && !e.workerCategoryId
      );
      return {
        id: 'DQ_004_NO_WORKER_CATEGORY',
        passed: noWorkerCat.length === 0,
        issue: noWorkerCat.length > 0 ? {
          id: 'DQ_004_NO_WORKER_CATEGORY',
          severity: 'HIGH',
          category: 'data_quality',
          title: `${noWorkerCat.length} Employee(s) Missing Worker Category`,
          description: 'Worker category controls PF, ESI applicability. Missing category means PF/ESI cannot be computed.',
          recommendation: 'Assign worker categories to all employees.',
          affectedModule: 'employees',
          canAutoFix: false,
          fixRoute: '/dashboard/people',
        } : undefined,
      };
    },
  },

  // ── PERFORMANCE ───────────────────────────────────────────────────────────

  {
    category: 'performance',
    fn: (ctx) => {
      const hasLegalEntity = ctx.legalEntities.length > 0;
      return {
        id: 'PERF_001_NO_ENTITY',
        passed: hasLegalEntity,
        issue: !hasLegalEntity ? {
          id: 'PERF_001_NO_ENTITY',
          severity: 'CRITICAL',
          category: 'performance',
          title: 'No Legal Entity Configured',
          description: 'At least one legal entity is required to run payroll, statutory filings, and generate documents.',
          recommendation: 'Add a legal entity under Settings → Legal Entities.',
          affectedModule: 'settings',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/entities',
        } : undefined,
      };
    },
  },

  {
    category: 'performance',
    fn: (ctx) => {
      const hasWorkerCategory = ctx.workerCategories.length > 0;
      return {
        id: 'PERF_002_NO_WORKER_CATEGORY',
        passed: hasWorkerCategory,
        issue: !hasWorkerCategory ? {
          id: 'PERF_002_NO_WORKER_CATEGORY',
          severity: 'HIGH',
          category: 'performance',
          title: 'No Worker Categories Defined',
          description: 'Worker categories are required for PF and ESI computation. No categories found.',
          recommendation: 'Add worker categories under Settings → Worker Categories.',
          affectedModule: 'settings',
          canAutoFix: false,
          fixRoute: '/dashboard/settings/worker-categories',
        } : undefined,
      };
    },
  },

];

// ─── Run all checks ────────────────────────────────────────────────────────────

export function runAllChecks(ctx: CheckContext): ValidationResult {
  const t0 = Date.now();
  const issues: ConfigIssue[] = [];

  for (const { fn } of checks) {
    try {
      const result = fn(ctx);
      const resultArr = Array.isArray(result) ? result : [result];
      for (const r of resultArr) {
        if (!r.passed && r.issue) {
          issues.push({ ...r.issue, detectedAt: new Date() });
        }
      }
    } catch {
      // Individual check failure must not stop the scan
    }
  }

  const bySev = (s: ValidationSeverity) => issues.filter(i => i.severity === s).length;

  return {
    tenantId: ctx.tenantId,
    issues,
    runAt: new Date(),
    durationMs: Date.now() - t0,
    checksRun: checks.length,
    critical: bySev('CRITICAL'),
    high: bySev('HIGH'),
    medium: bySev('MEDIUM'),
    low: bySev('LOW'),
  };
}

// ─── Health score computation ─────────────────────────────────────────────────

const STATUS = (score: number): HealthStatus =>
  score >= 85 ? 'HEALTHY' : score >= 60 ? 'ATTENTION' : 'ACTION_REQUIRED';

function dimensionScore(
  issues: ConfigIssue[],
  categories: ValidationCategory[],
): { score: number; issueLabels: string[] } {
  const relevant = issues.filter(i => categories.includes(i.category));
  const criticalCount = relevant.filter(i => i.severity === 'CRITICAL').length;
  const highCount = relevant.filter(i => i.severity === 'HIGH').length;
  const medCount = relevant.filter(i => i.severity === 'MEDIUM').length;
  const score = Math.max(0, 100 - criticalCount * 35 - highCount * 15 - medCount * 5);
  return { score, issueLabels: relevant.map(i => i.title) };
}

export function computeHealthScore(result: ValidationResult): TenantHealthScore {
  const { issues } = result;

  const cfg = dimensionScore(issues, ['payroll', 'leave', 'performance']);
  const pay = dimensionScore(issues, ['payroll', 'statutory']);
  const stat = dimensionScore(issues, ['statutory']);
  const risk = dimensionScore(issues, ['security', 'audit' as ValidationCategory]);
  const dq  = dimensionScore(issues, ['data_quality', 'bank', 'roles']);

  const dimensions = {
    configCompleteness: {
      id: 'configCompleteness', label: 'Config Completeness',
      score: cfg.score, weight: 0.25, status: STATUS(cfg.score), issues: cfg.issueLabels,
    } as HealthDimension,
    payrollCompliance: {
      id: 'payrollCompliance', label: 'Payroll Compliance',
      score: pay.score, weight: 0.3, status: STATUS(pay.score), issues: pay.issueLabels,
    } as HealthDimension,
    statutoryReadiness: {
      id: 'statutoryReadiness', label: 'Statutory Readiness',
      score: stat.score, weight: 0.25, status: STATUS(stat.score), issues: stat.issueLabels,
    } as HealthDimension,
    auditRisk: {
      id: 'auditRisk', label: 'Audit Risk',
      score: risk.score, weight: 0.1, status: STATUS(risk.score), issues: risk.issueLabels,
    } as HealthDimension,
    dataQuality: {
      id: 'dataQuality', label: 'Data Quality',
      score: dq.score, weight: 0.1, status: STATUS(dq.score), issues: dq.issueLabels,
    } as HealthDimension,
  };

  const overall = Math.round(
    Object.values(dimensions).reduce((s, d) => s + d.score * d.weight, 0)
  );

  return {
    tenantId: result.tenantId,
    overallScore: overall,
    status: STATUS(overall),
    dimensions,
    computedAt: new Date(),
  };
}
