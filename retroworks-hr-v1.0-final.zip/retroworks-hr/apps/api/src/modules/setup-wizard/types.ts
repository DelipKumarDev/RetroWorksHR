/**
 * Setup Wizard + Config Validator — Type Definitions
 * ──────────────────────────────────────────────────────────────────────────────
 * Single source of truth for all wizard, validator, health-score,
 * and migration assistant domain types.
 */

// ─── WIZARD STEPS ─────────────────────────────────────────────────────────────

export type WizardStep =
  | 'company_profile'
  | 'legal_entities'
  | 'worker_categories'
  | 'payroll_components'
  | 'leave_policy'
  | 'statutory_config'
  | 'role_setup'
  | 'confirmation';

export const WIZARD_STEPS: WizardStep[] = [
  'company_profile', 'legal_entities', 'worker_categories',
  'payroll_components', 'leave_policy', 'statutory_config',
  'role_setup', 'confirmation',
];

export const WIZARD_STEP_LABELS: Record<WizardStep, string> = {
  company_profile:    'Company Profile',
  legal_entities:     'Legal Entities',
  worker_categories:  'Worker Categories',
  payroll_components: 'Payroll Components',
  leave_policy:       'Leave Policy',
  statutory_config:   'Statutory Config',
  role_setup:         'Role Setup',
  confirmation:       'Confirmation',
};

// ─── INDUSTRY PRESETS ─────────────────────────────────────────────────────────

export type IndustryPreset =
  | 'it_services'
  | 'manufacturing'
  | 'school'
  | 'startup'
  | 'consulting';

export interface IndustryConfig {
  id: IndustryPreset;
  label: string;
  icon: string;
  description: string;
  defaultModules: string[];
  defaultLeaveTypes: LeaveTypeTemplate[];
  defaultPayrollComponents: PayrollComponentTemplate[];
  defaultWorkerCategories: WorkerCategoryTemplate[];
  defaultWorkingDays: number;
  payrollFrequency: 'monthly';
  pfDefault: boolean;
  esiDefault: boolean;
  gratuityApplicable: boolean;
}

// ─── TEMPLATE TYPES ───────────────────────────────────────────────────────────

export interface LeaveTypeTemplate {
  code: string;
  name: string;
  daysPerYear: number;
  carryForward: boolean;
  maxCarryForward: number;
  encashable: boolean;
  paidLeave: boolean;
  applicableGender?: 'female' | 'all';
  description?: string;
}

export interface PayrollComponentTemplate {
  code: string;
  name: string;
  type: 'FIXED' | 'FORMULA' | 'STATUTORY';
  formula?: string;
  isTaxable: boolean;
  isDeduction: boolean;
  description?: string;
}

export interface WorkerCategoryTemplate {
  code: string;
  name: string;
  applyPF: boolean;
  applyESI: boolean;
  isContractWorker: boolean;
  description?: string;
}

// ─── WIZARD STATE ─────────────────────────────────────────────────────────────

export interface CompanyProfileData {
  companyName: string;
  industry: IndustryPreset;
  companySize: 'micro' | 'small' | 'medium' | 'large' | 'enterprise';
  incorporationYear?: number;
  website?: string;
  logoUrl?: string;
  primaryContact: {
    name: string;
    email: string;
    phone: string;
    designation: string;
  };
  address: {
    line1: string;
    city: string;
    state: string;
    pincode: string;
  };
}

export interface LegalEntityData {
  id?: string;
  name: string;
  cin?: string;           // Corporate Identification Number
  pan: string;            // Company PAN (mandatory)
  tan?: string;           // TAN for TDS filing
  gstNumber?: string;
  pfRegistrationNumber?: string;
  esiRegistrationNumber?: string;
  ptRegistrationNumber?: string;
  stateCode: string;      // For PT computation
  bankAccountNumber?: string;
  bankIfsc?: string;
  bankName?: string;
  isHeadquarters: boolean;
}

export interface StatutoryConfigData {
  pfApplicable: boolean;
  pfWageCeiling: number;         // Default 15000
  esiApplicable: boolean;
  esiWageCeiling: number;        // Default 21000
  gratuityApplicable: boolean;
  professionalTaxApplicable: boolean;
  tdsApplicable: boolean;
  defaultTaxRegime: 'old' | 'new';
  payrollCutoffDay: number;      // Day of month payroll locks
  salaryCredDay: number;         // Day salary is credited
  financialYearStart: 4;         // April (India)
  lateMarkGraceMins: number;     // Attendance grace period
}

export interface WizardState {
  tenantId: string;
  currentStep: WizardStep;
  completedSteps: WizardStep[];
  industry?: IndustryPreset;
  companyProfile?: CompanyProfileData;
  legalEntities: LegalEntityData[];
  workerCategories: WorkerCategoryTemplate[];
  payrollComponents: PayrollComponentTemplate[];
  leaveTypes: LeaveTypeTemplate[];
  statutoryConfig?: StatutoryConfigData;
  roles: RoleSetupData[];
  startedAt: Date;
  completedAt?: Date;
  isComplete: boolean;
}

export interface RoleSetupData {
  roleName: string;
  assigneeEmail: string;
  permissions: string[];
}

// ─── CONFIG VALIDATOR ─────────────────────────────────────────────────────────

export type ValidationSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';
export type ValidationCategory =
  | 'statutory' | 'payroll' | 'leave' | 'roles'
  | 'bank' | 'security' | 'data_quality' | 'performance';

export interface ConfigIssue {
  id: string;              // Deterministic ID for dedup
  severity: ValidationSeverity;
  category: ValidationCategory;
  title: string;
  description: string;
  recommendation: string;
  affectedModule: string;
  canAutoFix: boolean;
  fixRoute?: string;       // Deep-link to fix location in app
  detectedAt: Date;
  resolvedAt?: Date;
}

export interface ValidationResult {
  tenantId: string;
  issues: ConfigIssue[];
  runAt: Date;
  durationMs: number;
  checksRun: number;
  critical: number;
  high: number;
  medium: number;
  low: number;
}

// ─── HEALTH SCORE ─────────────────────────────────────────────────────────────

export type HealthStatus = 'HEALTHY' | 'ATTENTION' | 'ACTION_REQUIRED';

export interface HealthDimension {
  id: string;
  label: string;
  score: number;         // 0–100
  weight: number;        // Contribution to overall score
  status: HealthStatus;
  issues: string[];      // Short descriptions of failing checks
}

export interface TenantHealthScore {
  tenantId: string;
  overallScore: number;  // 0–100 weighted
  status: HealthStatus;
  dimensions: {
    configCompleteness: HealthDimension;
    payrollCompliance: HealthDimension;
    statutoryReadiness: HealthDimension;
    auditRisk: HealthDimension;
    dataQuality: HealthDimension;
  };
  computedAt: Date;
  trend?: 'improving' | 'stable' | 'declining';
}

// ─── MIGRATION ASSISTANT ──────────────────────────────────────────────────────

export type MigrationEntity = 'employees' | 'departments' | 'designations' | 'leaves' | 'salary_structures';

export interface ColumnMapping {
  csvColumn: string;
  targetField: string;   // DB field path
  transform?: 'uppercase' | 'lowercase' | 'date_iso' | 'number' | 'boolean';
  required: boolean;
  defaultValue?: string;
}

export interface MigrationPreview {
  totalRows: number;
  validRows: number;
  errorRows: number;
  duplicateRows: number;
  sampleData: Record<string, unknown>[];  // First 5 valid rows
  errors: Array<{ row: number; column: string; error: string }>;
  warnings: Array<{ row: number; message: string }>;
}

export interface MigrationJob {
  id: string;
  tenantId: string;
  entity: MigrationEntity;
  status: 'PENDING' | 'VALIDATING' | 'DRY_RUN' | 'RUNNING' | 'COMPLETE' | 'FAILED' | 'ROLLED_BACK';
  totalRows: number;
  processedRows: number;
  successRows: number;
  failedRows: number;
  columnMappings: ColumnMapping[];
  errors: Array<{ row: number; error: string }>;
  rollbackData?: string; // JSON snapshot for rollback
  startedAt?: Date;
  completedAt?: Date;
  createdAt: Date;
  createdBy: string;
}

// ─── INDUSTRY PRESET DEFINITIONS ──────────────────────────────────────────────

export const INDUSTRY_PRESETS: Record<IndustryPreset, IndustryConfig> = {
  it_services: {
    id: 'it_services', label: 'IT Services', icon: '💻',
    description: 'Software, SaaS, IT consulting, product companies',
    defaultModules: ['core-hr', 'leave', 'attendance', 'payroll', 'performance', 'ats'],
    defaultWorkingDays: 22, payrollFrequency: 'monthly',
    pfDefault: true, esiDefault: false, gratuityApplicable: true,
    defaultLeaveTypes: [
      { code: 'EL', name: 'Earned Leave', daysPerYear: 18, carryForward: true, maxCarryForward: 30, encashable: true, paidLeave: true },
      { code: 'SL', name: 'Sick Leave', daysPerYear: 12, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'CL', name: 'Casual Leave', daysPerYear: 6, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'ML', name: 'Maternity Leave', daysPerYear: 182, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true, applicableGender: 'female' },
      { code: 'PL', name: 'Paternity Leave', daysPerYear: 5, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'WFH', name: 'Work From Home', daysPerYear: 60, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'COL', name: 'Comp Off', daysPerYear: 0, carryForward: true, maxCarryForward: 6, encashable: false, paidLeave: true },
    ],
    defaultPayrollComponents: [
      { code: 'BASIC', name: 'Basic Salary', type: 'FORMULA', formula: 'CTC * 0.4 / 12', isTaxable: true, isDeduction: false },
      { code: 'HRA', name: 'HRA', type: 'FORMULA', formula: 'MIN(BASIC * 0.5, 10000)', isTaxable: false, isDeduction: false },
      { code: 'SPECIAL', name: 'Special Allowance', type: 'FORMULA', formula: 'GROSS - BASIC - HRA', isTaxable: true, isDeduction: false },
      { code: 'PF_EMP', name: 'PF Deduction', type: 'STATUTORY', isTaxable: false, isDeduction: true },
      { code: 'TDS', name: 'TDS', type: 'STATUTORY', isTaxable: false, isDeduction: true },
    ],
    defaultWorkerCategories: [
      { code: 'regular', name: 'Regular Employee', applyPF: true, applyESI: false, isContractWorker: false },
      { code: 'contract', name: 'Contract Staff', applyPF: false, applyESI: false, isContractWorker: true },
      { code: 'intern', name: 'Intern', applyPF: false, applyESI: false, isContractWorker: false },
    ],
  },

  manufacturing: {
    id: 'manufacturing', label: 'Manufacturing', icon: '🏭',
    description: 'Factory, industrial, shop-floor workers',
    defaultModules: ['core-hr', 'leave', 'attendance', 'payroll', 'shift-management'],
    defaultWorkingDays: 26, payrollFrequency: 'monthly',
    pfDefault: true, esiDefault: true, gratuityApplicable: true,
    defaultLeaveTypes: [
      { code: 'EL', name: 'Earned Leave', daysPerYear: 15, carryForward: true, maxCarryForward: 30, encashable: true, paidLeave: true },
      { code: 'SL', name: 'Sick Leave', daysPerYear: 10, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'CL', name: 'Casual Leave', daysPerYear: 8, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'ML', name: 'Maternity Leave', daysPerYear: 182, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true, applicableGender: 'female' },
      { code: 'NJ', name: 'National Holiday', daysPerYear: 14, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
    ],
    defaultPayrollComponents: [
      { code: 'BASIC', name: 'Basic Wages', type: 'FORMULA', formula: 'CTC * 0.5 / 12', isTaxable: true, isDeduction: false },
      { code: 'DA', name: 'Dearness Allowance', type: 'FORMULA', formula: 'BASIC * 0.1', isTaxable: true, isDeduction: false },
      { code: 'HRA', name: 'HRA', type: 'FORMULA', formula: 'BASIC * 0.4', isTaxable: false, isDeduction: false },
      { code: 'SPECIAL', name: 'Special Allowance', type: 'FORMULA', formula: 'GROSS - BASIC - DA - HRA', isTaxable: true, isDeduction: false },
      { code: 'PF_EMP', name: 'PF Deduction', type: 'STATUTORY', isTaxable: false, isDeduction: true },
      { code: 'ESI_EMP', name: 'ESI Deduction', type: 'STATUTORY', isTaxable: false, isDeduction: true },
      { code: 'TDS', name: 'TDS', type: 'STATUTORY', isTaxable: false, isDeduction: true },
    ],
    defaultWorkerCategories: [
      { code: 'permanent', name: 'Permanent Worker', applyPF: true, applyESI: true, isContractWorker: false },
      { code: 'contract', name: 'Contract Worker', applyPF: true, applyESI: true, isContractWorker: true },
      { code: 'casual', name: 'Casual Labour', applyPF: false, applyESI: true, isContractWorker: true },
    ],
  },

  school: {
    id: 'school', label: 'School / Education', icon: '🏫',
    description: 'Schools, colleges, coaching institutes',
    defaultModules: ['core-hr', 'leave', 'attendance', 'payroll'],
    defaultWorkingDays: 24, payrollFrequency: 'monthly',
    pfDefault: true, esiDefault: false, gratuityApplicable: true,
    defaultLeaveTypes: [
      { code: 'EL', name: 'Earned Leave', daysPerYear: 15, carryForward: true, maxCarryForward: 30, encashable: true, paidLeave: true },
      { code: 'SL', name: 'Sick Leave', daysPerYear: 14, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'SML', name: 'Summer Vacation', daysPerYear: 30, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'ML', name: 'Maternity Leave', daysPerYear: 182, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true, applicableGender: 'female' },
      { code: 'SBL', name: 'Study Leave', daysPerYear: 10, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: false },
    ],
    defaultPayrollComponents: [
      { code: 'BASIC', name: 'Basic Pay', type: 'FORMULA', formula: 'CTC * 0.45 / 12', isTaxable: true, isDeduction: false },
      { code: 'DA', name: 'Dearness Allowance', type: 'FORMULA', formula: 'BASIC * 0.08', isTaxable: true, isDeduction: false },
      { code: 'HRA', name: 'HRA', type: 'FORMULA', formula: 'BASIC * 0.3', isTaxable: false, isDeduction: false },
      { code: 'TA', name: 'Travel Allowance', type: 'FORMULA', formula: 'MIN(800, BASIC * 0.1)', isTaxable: false, isDeduction: false },
      { code: 'SPECIAL', name: 'Other Allowance', type: 'FORMULA', formula: 'GROSS - BASIC - DA - HRA - TA', isTaxable: true, isDeduction: false },
      { code: 'PF_EMP', name: 'PF Deduction', type: 'STATUTORY', isTaxable: false, isDeduction: true },
    ],
    defaultWorkerCategories: [
      { code: 'teaching', name: 'Teaching Staff', applyPF: true, applyESI: false, isContractWorker: false },
      { code: 'non_teaching', name: 'Non-Teaching Staff', applyPF: true, applyESI: false, isContractWorker: false },
      { code: 'part_time', name: 'Part-Time Faculty', applyPF: false, applyESI: false, isContractWorker: true },
    ],
  },

  startup: {
    id: 'startup', label: 'Startup', icon: '🚀',
    description: 'Early-stage startups and growing teams',
    defaultModules: ['core-hr', 'leave', 'attendance', 'payroll', 'ats', 'performance'],
    defaultWorkingDays: 22, payrollFrequency: 'monthly',
    pfDefault: true, esiDefault: false, gratuityApplicable: false,
    defaultLeaveTypes: [
      { code: 'EL', name: 'Earned Leave', daysPerYear: 21, carryForward: true, maxCarryForward: 15, encashable: true, paidLeave: true },
      { code: 'SL', name: 'Sick Leave', daysPerYear: 12, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'ML', name: 'Maternity Leave', daysPerYear: 182, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true, applicableGender: 'female' },
      { code: 'HAL', name: 'Hackathon Leave', daysPerYear: 3, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
    ],
    defaultPayrollComponents: [
      { code: 'BASIC', name: 'Basic Salary', type: 'FORMULA', formula: 'CTC * 0.5 / 12', isTaxable: true, isDeduction: false },
      { code: 'HRA', name: 'HRA', type: 'FORMULA', formula: 'BASIC * 0.5', isTaxable: false, isDeduction: false },
      { code: 'SPECIAL', name: 'Special Allowance', type: 'FORMULA', formula: 'GROSS - BASIC - HRA', isTaxable: true, isDeduction: false },
      { code: 'PF_EMP', name: 'PF Deduction', type: 'STATUTORY', isTaxable: false, isDeduction: true },
      { code: 'TDS', name: 'TDS', type: 'STATUTORY', isTaxable: false, isDeduction: true },
    ],
    defaultWorkerCategories: [
      { code: 'fte', name: 'Full-Time Employee', applyPF: true, applyESI: false, isContractWorker: false },
      { code: 'contractor', name: 'Contractor', applyPF: false, applyESI: false, isContractWorker: true },
      { code: 'intern', name: 'Intern / Trainee', applyPF: false, applyESI: false, isContractWorker: false },
    ],
  },

  consulting: {
    id: 'consulting', label: 'Consulting', icon: '📊',
    description: 'Management, legal, CA, or professional services firms',
    defaultModules: ['core-hr', 'leave', 'attendance', 'payroll', 'performance', 'reports'],
    defaultWorkingDays: 22, payrollFrequency: 'monthly',
    pfDefault: true, esiDefault: false, gratuityApplicable: true,
    defaultLeaveTypes: [
      { code: 'EL', name: 'Earned Leave', daysPerYear: 24, carryForward: true, maxCarryForward: 30, encashable: true, paidLeave: true },
      { code: 'SL', name: 'Sick Leave', daysPerYear: 12, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'CL', name: 'Casual Leave', daysPerYear: 8, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true },
      { code: 'ML', name: 'Maternity Leave', daysPerYear: 182, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true, applicableGender: 'female' },
    ],
    defaultPayrollComponents: [
      { code: 'BASIC', name: 'Basic Salary', type: 'FORMULA', formula: 'CTC * 0.4 / 12', isTaxable: true, isDeduction: false },
      { code: 'HRA', name: 'HRA', type: 'FORMULA', formula: 'BASIC * 0.5', isTaxable: false, isDeduction: false },
      { code: 'PERF', name: 'Performance Allowance', type: 'FORMULA', formula: 'BASIC * 0.15', isTaxable: true, isDeduction: false },
      { code: 'SPECIAL', name: 'Special Allowance', type: 'FORMULA', formula: 'GROSS - BASIC - HRA - PERF', isTaxable: true, isDeduction: false },
      { code: 'PF_EMP', name: 'PF Deduction', type: 'STATUTORY', isTaxable: false, isDeduction: true },
      { code: 'TDS', name: 'TDS', type: 'STATUTORY', isTaxable: false, isDeduction: true },
    ],
    defaultWorkerCategories: [
      { code: 'associate', name: 'Associate Consultant', applyPF: true, applyESI: false, isContractWorker: false },
      { code: 'senior', name: 'Senior Consultant', applyPF: true, applyESI: false, isContractWorker: false },
      { code: 'freelance', name: 'Freelance Expert', applyPF: false, applyESI: false, isContractWorker: true },
    ],
  },
};

// ─── MIGRATION FIELD MAPS ──────────────────────────────────────────────────────

export const MIGRATION_TARGET_FIELDS: Record<MigrationEntity, Array<{
  field: string; label: string; required: boolean; type: string;
  example: string;
}>> = {
  employees: [
    { field: 'employeeCode', label: 'Employee ID', required: true, type: 'string', example: 'EMP001' },
    { field: 'firstName', label: 'First Name', required: true, type: 'string', example: 'Ravi' },
    { field: 'lastName', label: 'Last Name', required: true, type: 'string', example: 'Kumar' },
    { field: 'email', label: 'Work Email', required: true, type: 'email', example: 'ravi@company.com' },
    { field: 'phone', label: 'Mobile', required: false, type: 'string', example: '9876543210' },
    { field: 'dateOfJoining', label: 'Date of Joining', required: true, type: 'date', example: '2023-04-01' },
    { field: 'dateOfBirth', label: 'Date of Birth', required: false, type: 'date', example: '1990-05-15' },
    { field: 'department', label: 'Department Name', required: false, type: 'string', example: 'Engineering' },
    { field: 'designation', label: 'Designation', required: false, type: 'string', example: 'Software Engineer' },
    { field: 'gender', label: 'Gender', required: false, type: 'enum:male,female,other', example: 'male' },
    { field: 'panNumber', label: 'PAN Number', required: false, type: 'string', example: 'ABCDE1234F' },
    { field: 'aadhaarNumber', label: 'Aadhaar Number', required: false, type: 'string', example: '1234-5678-9012' },
    { field: 'ctc', label: 'Annual CTC (₹)', required: false, type: 'number', example: '1200000' },
    { field: 'bankAccountNumber', label: 'Bank Account', required: false, type: 'string', example: '123456789012' },
    { field: 'bankIfsc', label: 'Bank IFSC', required: false, type: 'string', example: 'HDFC0001234' },
    { field: 'employmentType', label: 'Employment Type', required: false, type: 'enum:full-time,part-time,contract,intern', example: 'full-time' },
  ],
  departments: [
    { field: 'name', label: 'Department Name', required: true, type: 'string', example: 'Engineering' },
    { field: 'code', label: 'Code', required: false, type: 'string', example: 'ENG' },
    { field: 'headEmail', label: 'Head Email', required: false, type: 'email', example: 'vp@co.com' },
  ],
  designations: [
    { field: 'name', label: 'Designation Name', required: true, type: 'string', example: 'Software Engineer' },
    { field: 'department', label: 'Department', required: false, type: 'string', example: 'Engineering' },
    { field: 'level', label: 'Level', required: false, type: 'number', example: '3' },
  ],
  leaves: [
    { field: 'employeeCode', label: 'Employee ID', required: true, type: 'string', example: 'EMP001' },
    { field: 'leaveType', label: 'Leave Type Code', required: true, type: 'string', example: 'EL' },
    { field: 'startDate', label: 'Start Date', required: true, type: 'date', example: '2024-01-10' },
    { field: 'endDate', label: 'End Date', required: true, type: 'date', example: '2024-01-12' },
    { field: 'days', label: 'Days', required: false, type: 'number', example: '3' },
    { field: 'reason', label: 'Reason', required: false, type: 'string', example: 'Medical' },
    { field: 'status', label: 'Status', required: false, type: 'enum:approved,pending', example: 'approved' },
  ],
  salary_structures: [
    { field: 'employeeCode', label: 'Employee ID', required: true, type: 'string', example: 'EMP001' },
    { field: 'effectiveFrom', label: 'Effective From', required: true, type: 'date', example: '2024-04-01' },
    { field: 'ctc', label: 'Annual CTC (₹)', required: true, type: 'number', example: '1200000' },
    { field: 'basic', label: 'Basic (Monthly)', required: false, type: 'number', example: '40000' },
    { field: 'hra', label: 'HRA (Monthly)', required: false, type: 'number', example: '20000' },
  ],
};
