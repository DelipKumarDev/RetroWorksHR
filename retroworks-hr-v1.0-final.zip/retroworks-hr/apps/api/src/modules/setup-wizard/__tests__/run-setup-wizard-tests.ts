/**
 * Setup Wizard + Config Validator — Test Suite
 * ──────────────────────────────────────────────────────────────────────────────
 * 65 tests across 8 suites:
 *
 *   A. Industry Presets (10)        — all 5 presets, required fields, PF/ESI flags
 *   B. Config Validator (20)        — all 25 checks, severity levels, issue IDs
 *   C. Health Score (8)             — scoring formula, dimension weights, status thresholds
 *   D. CSV Parser (8)               — quoting, empty rows, multi-line, encoding
 *   E. Auto Column Mapping (7)      — alias matching, partial match, no-match
 *   F. Value Transformer (6)        — dates, numbers, booleans, enums, PAN, IFSC
 *   G. Preview Builder (4)          — error counting, duplicate detection, sample data
 *   H. Migration Job State (2)      — job creation, initial status
 */

import {
  INDUSTRY_PRESETS, WIZARD_STEPS, MIGRATION_TARGET_FIELDS,
  type IndustryPreset,
} from '../types';

import {
  runAllChecks, computeHealthScore,
  type CheckContext,
} from '../config-validator';

import {
  parseCSV, autoMapColumns, transformValue,
  buildPreview, createMigrationJob,
} from '../migration-assistant';

// ── Scaffold ──────────────────────────────────────────────────────────────────

let _pass = 0, _fail = 0;
function suite(n: string) { console.log(`\n  ── ${n} ──`); }
function it(desc: string, fn: () => void) {
  try { fn(); _pass++; console.log(`    ✅  ${desc}`); }
  catch (e: any) { _fail++; console.log(`    ❌  ${desc}\n         ${e.message}`); }
}
function expect(val: unknown) {
  return {
    toBe:           (e: unknown) => { if (val !== e) throw new Error(`Expected ${JSON.stringify(e)}, got ${JSON.stringify(val)}`); },
    toEqual:        (e: unknown) => { if (JSON.stringify(val) !== JSON.stringify(e)) throw new Error(`Expected ${JSON.stringify(e)}, got ${JSON.stringify(val)}`); },
    toBeTruthy:     () => { if (!val) throw new Error(`Expected truthy, got ${JSON.stringify(val)}`); },
    toBeFalsy:      () => { if (val)  throw new Error(`Expected falsy, got ${JSON.stringify(val)}`); },
    toBeGreaterThan:(n: number) => { if ((val as number) <= n) throw new Error(`Expected > ${n}, got ${val}`); },
    toBeLessThan:   (n: number) => { if ((val as number) >= n) throw new Error(`Expected < ${n}, got ${val}`); },
    toContain:      (s: unknown) => { if (!(val as any[]).includes(s)) throw new Error(`Expected array to contain ${JSON.stringify(s)}`); },
    toHaveLength:   (n: number) => { if ((val as any[]).length !== n) throw new Error(`Expected length ${n}, got ${(val as any[]).length}`); },
    not: {
      toBe:     (e: unknown) => { if (val === e) throw new Error(`Expected NOT ${JSON.stringify(e)}`); },
      toBeFalsy:() => { if (!val) throw new Error(`Expected truthy`); },
    },
  };
}

// ── Helpers ────────────────────────────────────────────────────────────────────

function makeCtx(overrides: Partial<CheckContext> = {}): CheckContext {
  return {
    tenantId: 'tenant-test',
    tenant: { id: 'tenant-test', settings: {} },
    legalEntities: [{
      id: 'ent-1', name: 'Acme Pvt Ltd', pan: 'AABCA1234Z', tan: 'MUMA12345B',
      pfRegistrationNumber: 'MH/BOM/12345', esiRegistrationNumber: 'ESI/12345',
      stateCode: 'Maharashtra', bankAccountNumber: '123456789012', bankIfsc: 'HDFC0001234',
    }],
    employees: [
      { id: 'e1', status: 'active', employeeCode: 'EMP001', ctc: 1200000,
        departmentId: 'dept-1', designationId: 'des-1', workerCategoryId: 'wc-1',
        bankAccountNumber: '123456789', bankIfsc: 'HDFC0001', panNumber: 'ABCDE1234F' },
      { id: 'e2', status: 'active', employeeCode: 'EMP002', ctc: 800000,
        departmentId: 'dept-1', designationId: 'des-1', workerCategoryId: 'wc-1',
        bankAccountNumber: '987654321', bankIfsc: 'ICIC0002', panNumber: 'FGHIJ5678K' },
    ],
    payrollComponents: [
      { code: 'BASIC', name: 'Basic', isDeduction: false, isActive: true, formula: 'CTC*0.4/12' },
      { code: 'SPECIAL', name: 'Special', isDeduction: false, isActive: true, formula: 'GROSS-BASIC-HRA' },
      { code: 'PF_EMP', name: 'PF', isDeduction: true, isActive: true, type: 'STATUTORY' },
    ],
    leaveTypes: [
      { id: 'lt-1', code: 'EL', name: 'Earned Leave', isPaidLeave: true },
      { id: 'lt-2', code: 'SL', name: 'Sick Leave', isPaidLeave: true },
    ],
    leavePolicies: [{
      id: 'lp-1',
      entries: [
        { leaveTypeId: 'lt-1', carryForward: true, maxCarryForward: 30 },
        { leaveTypeId: 'lt-2', carryForward: false, maxCarryForward: 0 },
      ],
    }],
    roles: [
      { id: 'r1', name: 'hr-admin', userCount: 1 },
      { id: 'r2', name: 'cfo',      userCount: 1 },
    ],
    payrollRuns: [
      { id: 'pr-1', status: 'approved', approvedAt: new Date(), createdAt: new Date() },
    ],
    workerCategories: [
      { id: 'wc-1', code: 'regular', applyPF: true, applyESI: false },
    ],
    savedReports: [],
    auditLogs: [
      { action: 'payroll_run_approved', timestamp: new Date() },
    ],
    backupSummary: { lastSuccessful: new Date() },
    ...overrides,
  };
}

// ════════════════════════════════════════════════════════════════════════════════
suite('A — Industry Presets');
// ════════════════════════════════════════════════════════════════════════════════

it('A1 | All 5 presets defined', () => {
  const ids = Object.keys(INDUSTRY_PRESETS);
  ['it_services','manufacturing','school','startup','consulting'].forEach(id => {
    if (!ids.includes(id)) throw new Error(`Missing preset: ${id}`);
  });
});

it('A2 | Each preset has leave types', () => {
  for (const [id, p] of Object.entries(INDUSTRY_PRESETS)) {
    if (!p.defaultLeaveTypes.length) throw new Error(`${id} has no leave types`);
  }
});

it('A3 | Each preset has payroll components', () => {
  for (const [id, p] of Object.entries(INDUSTRY_PRESETS)) {
    if (!p.defaultPayrollComponents.length) throw new Error(`${id} has no payroll components`);
  }
});

it('A4 | Each preset has BASIC component', () => {
  for (const [id, p] of Object.entries(INDUSTRY_PRESETS)) {
    if (!p.defaultPayrollComponents.some(c => c.code === 'BASIC')) {
      throw new Error(`${id} missing BASIC component`);
    }
  }
});

it('A5 | IT Services: PF true, ESI false', () => {
  const p = INDUSTRY_PRESETS.it_services;
  expect(p.pfDefault).toBeTruthy();
  expect(p.esiDefault).toBeFalsy();
});

it('A6 | Manufacturing: PF true, ESI true', () => {
  const p = INDUSTRY_PRESETS.manufacturing;
  expect(p.pfDefault).toBeTruthy();
  expect(p.esiDefault).toBeTruthy();
});

it('A7 | Manufacturing has BASIC + DA + HRA', () => {
  const codes = INDUSTRY_PRESETS.manufacturing.defaultPayrollComponents.map(c => c.code);
  expect(codes).toContain('BASIC');
  expect(codes).toContain('DA');
  expect(codes).toContain('HRA');
});

it('A8 | School has Summer Vacation leave type', () => {
  const codes = INDUSTRY_PRESETS.school.defaultLeaveTypes.map(l => l.code);
  expect(codes).toContain('SML');
});

it('A9 | Each preset has at least one earned/paid leave type', () => {
  for (const [id, p] of Object.entries(INDUSTRY_PRESETS)) {
    if (!p.defaultLeaveTypes.some(l => l.paidLeave)) {
      throw new Error(`${id} has no paid leave type`);
    }
  }
});

it('A10 | WIZARD_STEPS has 8 steps in correct order', () => {
  expect(WIZARD_STEPS).toHaveLength(8);
  expect(WIZARD_STEPS[0]).toBe('company_profile');
  expect(WIZARD_STEPS[7]).toBe('confirmation');
});

// ════════════════════════════════════════════════════════════════════════════════
suite('B — Config Validator (25 checks)');
// ════════════════════════════════════════════════════════════════════════════════

it('B1 | Healthy tenant: zero issues', () => {
  const result = runAllChecks(makeCtx());
  expect(result.issues.length).toBe(0);
  expect(result.critical).toBe(0);
});

it('B2 | STAT_001: PF reg missing when applyPF=true → CRITICAL', () => {
  const ctx = makeCtx({
    legalEntities: [{ id: 'e1', name: 'Acme', pan: 'AABCA1234Z', pfRegistrationNumber: null, stateCode: 'MH' }],
    workerCategories: [{ applyPF: true }],
  });
  const result = runAllChecks(ctx);
  const issue = result.issues.find(i => i.id === 'STAT_001_PF_REG');
  expect(issue).toBeTruthy();
  expect(issue!.severity).toBe('CRITICAL');
});

it('B3 | STAT_001: PF reg present → no issue', () => {
  const result = runAllChecks(makeCtx());
  expect(result.issues.find(i => i.id === 'STAT_001_PF_REG')).toBeFalsy();
});

it('B4 | STAT_002: TAN missing with payroll runs → CRITICAL', () => {
  const ctx = makeCtx({
    legalEntities: [{ id: 'e1', name: 'Acme', pan: 'AABCA1234Z', tan: null, stateCode: 'MH', pfRegistrationNumber: 'PF123' }],
    payrollRuns: [{ id: 'pr-1', status: 'approved', approvedAt: new Date(), createdAt: new Date() }],
  });
  const result = runAllChecks(ctx);
  const issue = result.issues.find(i => i.id === 'STAT_002_TAN');
  expect(issue).toBeTruthy();
  expect(issue!.severity).toBe('CRITICAL');
});

it('B5 | STAT_002: No payroll runs yet → TAN issue not triggered', () => {
  const ctx = makeCtx({
    legalEntities: [{ id: 'e1', name: 'Acme', pan: 'AABCA1234Z', tan: null, stateCode: 'MH', pfRegistrationNumber: 'PF123' }],
    payrollRuns: [],
  });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'STAT_002_TAN')).toBeFalsy();
});

it('B6 | PAY_001: No BASIC component → CRITICAL', () => {
  const ctx = makeCtx({ payrollComponents: [{ code: 'HRA', isDeduction: false, isActive: true }] });
  const result = runAllChecks(ctx);
  const issue = result.issues.find(i => i.id === 'PAY_001_GROSS_IDENTITY');
  expect(issue).toBeTruthy();
  expect(issue!.severity).toBe('CRITICAL');
});

it('B7 | PAY_002: No active components → CRITICAL', () => {
  const ctx = makeCtx({ payrollComponents: [] });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'PAY_002_NO_COMPONENTS')).toBeTruthy();
});

it('B8 | PAY_003: Unlocked run older than 7 days → HIGH', () => {
  const oldDate = new Date(Date.now() - 10 * 24 * 60 * 60 * 1000);
  const ctx = makeCtx({
    payrollRuns: [{ id: 'pr-1', status: 'processed', approvedAt: null, createdAt: oldDate }],
  });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'PAY_003_UNLOCKED_RUNS')).toBeTruthy();
});

it('B9 | PAY_004: Active employee with no CTC → HIGH', () => {
  const ctx = makeCtx({
    employees: [
      { id: 'e1', status: 'active', employeeCode: 'EMP001', ctc: 0,
        departmentId: 'd1', designationId: 'd1', workerCategoryId: 'w1',
        bankAccountNumber: '123', bankIfsc: 'HDFC', panNumber: 'ABCDE1234F' },
    ],
  });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'PAY_004_MISSING_CTC')).toBeTruthy();
});

it('B10 | LEAVE_001: Leave type with no carry-forward rule → MEDIUM', () => {
  const ctx = makeCtx({
    leaveTypes: [{ id: 'lt-1', code: 'EL', name: 'Earned Leave', isPaidLeave: true }],
    leavePolicies: [{ id: 'lp-1', entries: [] }],
  });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'LEAVE_001_CARRY_FORWARD')).toBeTruthy();
});

it('B11 | LEAVE_002: No leave policy → HIGH', () => {
  const ctx = makeCtx({ leavePolicies: [] });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'LEAVE_002_NO_POLICY')).toBeTruthy();
});

it('B12 | LEAVE_003: No paid leave type → MEDIUM', () => {
  const ctx = makeCtx({
    leaveTypes: [{ id: 'lt-1', code: 'UNPAID', name: 'Unpaid', isPaidLeave: false }],
  });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'LEAVE_003_EARNED_LEAVE')).toBeTruthy();
});

it('B13 | ROLE_001: No CFO or finance role assigned → HIGH', () => {
  const ctx = makeCtx({
    roles: [{ id: 'r1', name: 'employee', userCount: 5 }],
  });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'ROLE_001_NO_CFO')).toBeTruthy();
});

it('B14 | ROLE_002: No admin role → CRITICAL', () => {
  const ctx = makeCtx({ roles: [] });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'ROLE_002_NO_ADMIN')).toBeTruthy();
});

it('B15 | BANK_001: >10% employees missing bank details → HIGH', () => {
  const ctx = makeCtx({
    employees: Array.from({ length: 10 }, (_, i) => ({
      id: `e${i}`, status: 'active', employeeCode: `EMP00${i}`, ctc: 1000000,
      departmentId: 'd1', designationId: 'd1', workerCategoryId: 'w1',
      bankAccountNumber: i < 2 ? '' : '123456789',  // 2/10 = 20% missing
      bankIfsc: i < 2 ? '' : 'HDFC0001', panNumber: 'ABCDE1234F',
    })),
  });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'BANK_001_MISSING_ACCOUNT')).toBeTruthy();
});

it('B16 | BANK_002: Employee missing PAN → HIGH', () => {
  const ctx = makeCtx({
    employees: [
      { id: 'e1', status: 'active', employeeCode: 'EMP001', ctc: 1200000,
        departmentId: 'd1', designationId: 'd1', workerCategoryId: 'w1',
        bankAccountNumber: '12345', bankIfsc: 'HDFC0001', panNumber: '' },
    ],
  });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'BANK_002_MISSING_PAN')).toBeTruthy();
});

it('B17 | DQ_002: Duplicate employee codes → CRITICAL', () => {
  const ctx = makeCtx({
    employees: [
      { id: 'e1', status: 'active', employeeCode: 'EMP001', ctc: 1200000, departmentId: 'd1', designationId: 'd1', workerCategoryId: 'w1', bankAccountNumber: '123', bankIfsc: 'HDFC', panNumber: 'ABCDE1234F' },
      { id: 'e2', status: 'active', employeeCode: 'EMP001', ctc: 800000, departmentId: 'd1', designationId: 'd1', workerCategoryId: 'w1', bankAccountNumber: '456', bankIfsc: 'ICIC', panNumber: 'FGHIJ5678K' },
    ],
  });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'DQ_002_DUPLICATE_EMP_CODE')).toBeTruthy();
});

it('B18 | PERF_001: No legal entity → CRITICAL', () => {
  const ctx = makeCtx({ legalEntities: [] });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'PERF_001_NO_ENTITY')).toBeTruthy();
});

it('B19 | PERF_002: No worker categories → HIGH', () => {
  const ctx = makeCtx({ workerCategories: [] });
  const result = runAllChecks(ctx);
  expect(result.issues.find(i => i.id === 'PERF_002_NO_WORKER_CATEGORY')).toBeTruthy();
});

it('B20 | Validation result has correct counts', () => {
  const ctx = makeCtx({ legalEntities: [], payrollComponents: [], roles: [] });
  const result = runAllChecks(ctx);
  expect(result.checksRun).toBe(23); // total registered checks
  expect(result.critical).toBeGreaterThan(0);
  expect(typeof result.durationMs).toBe('number');
  expect(result.tenantId).toBe('tenant-test');
});

// ════════════════════════════════════════════════════════════════════════════════
suite('C — Health Score');
// ════════════════════════════════════════════════════════════════════════════════

it('C1 | Healthy tenant → score >= 85 → HEALTHY status', () => {
  const result = runAllChecks(makeCtx());
  const score = computeHealthScore(result);
  expect(score.overallScore).toBeGreaterThan(84);
  expect(score.status).toBe('HEALTHY');
});

it('C2 | CRITICAL issues reduce score significantly', () => {
  const ctx = makeCtx({ legalEntities: [], payrollComponents: [], roles: [] });
  const result = runAllChecks(ctx);
  const score = computeHealthScore(result);
  expect(score.overallScore).toBeLessThan(60);
});

it('C3 | Health score has all 5 dimensions', () => {
  const result = runAllChecks(makeCtx());
  const score = computeHealthScore(result);
  const dimIds = Object.keys(score.dimensions);
  ['configCompleteness','payrollCompliance','statutoryReadiness','auditRisk','dataQuality']
    .forEach(d => { if (!dimIds.includes(d)) throw new Error(`Missing dimension: ${d}`); });
});

it('C4 | Each dimension has score 0–100', () => {
  const result = runAllChecks(makeCtx());
  const score = computeHealthScore(result);
  for (const dim of Object.values(score.dimensions)) {
    if (dim.score < 0 || dim.score > 100) throw new Error(`${dim.id} score out of range: ${dim.score}`);
  }
});

it('C5 | Dimension weights sum to 1.0', () => {
  const result = runAllChecks(makeCtx());
  const score = computeHealthScore(result);
  const weightSum = Object.values(score.dimensions).reduce((s, d) => s + d.weight, 0);
  if (Math.abs(weightSum - 1.0) > 0.001) throw new Error(`Weights sum to ${weightSum}, expected 1.0`);
});

it('C6 | ATTENTION status: score 60–84', () => {
  const ctx = makeCtx({
    roles: [{ id: 'r1', name: 'employee', userCount: 5 }], // No CFO/admin
  });
  const result = runAllChecks(ctx);
  const score = computeHealthScore(result);
  expect(score.overallScore).toBeLessThan(100);
});

it('C7 | tenantId passed through to health score', () => {
  const result = runAllChecks(makeCtx({ tenantId: 'specific-tenant' }));
  const score = computeHealthScore(result);
  expect(score.tenantId).toBe('specific-tenant');
});

it('C8 | computedAt is a Date', () => {
  const result = runAllChecks(makeCtx());
  const score = computeHealthScore(result);
  expect(score.computedAt instanceof Date).toBeTruthy();
});

// ════════════════════════════════════════════════════════════════════════════════
suite('D — CSV Parser');
// ════════════════════════════════════════════════════════════════════════════════

it('D1 | Basic CSV parses headers and rows', () => {
  const csv = 'Name,Email,Phone\nRavi,ravi@co.in,9876543210\nPriya,priya@co.in,9123456789';
  const { headers, rows } = parseCSV(csv);
  expect(headers).toHaveLength(3);
  expect(rows).toHaveLength(2);
  expect(rows[0]!['Name']).toBe('Ravi');
});

it('D2 | Quoted values with commas handled correctly', () => {
  const csv = 'Name,Address\n"Kumar, Ravi","Mumbai, Maharashtra"';
  const { rows } = parseCSV(csv);
  expect(rows[0]!['Name']).toBe('Kumar, Ravi');
  expect(rows[0]!['Address']).toBe('Mumbai, Maharashtra');
});

it('D3 | Escaped double-quotes inside quoted fields', () => {
  const csv = 'Note\n"He said ""hello"""';
  const { rows } = parseCSV(csv);
  expect(rows[0]!['Note']).toBe('He said "hello"');
});

it('D4 | Empty CSV returns empty arrays', () => {
  const { headers, rows } = parseCSV('');
  expect(headers).toHaveLength(0);
  expect(rows).toHaveLength(0);
});

it('D5 | Header-only CSV returns no rows', () => {
  const csv = 'Name,Email,Phone';
  const { rows } = parseCSV(csv);
  expect(rows).toHaveLength(0);
});

it('D6 | CRLF line endings normalised', () => {
  const csv = 'Name,Email\r\nRavi,ravi@co.in\r\nPriya,priya@co.in';
  const { rows } = parseCSV(csv);
  expect(rows).toHaveLength(2);
});

it('D7 | Missing value in row defaults to empty string', () => {
  const csv = 'A,B,C\n1,,3';
  const { rows } = parseCSV(csv);
  expect(rows[0]!['B']).toBe('');
});

it('D8 | Whitespace trimmed from headers and values', () => {
  const csv = ' Name , Email \n Ravi , ravi@co.in ';
  const { headers, rows } = parseCSV(csv);
  expect(headers[0]).toBe('Name');
  expect(rows[0]!['Name']).toBe('Ravi');
});

// ════════════════════════════════════════════════════════════════════════════════
suite('E — Auto Column Mapping');
// ════════════════════════════════════════════════════════════════════════════════

it('E1 | Exact header match: "email" → email field', () => {
  const mappings = autoMapColumns(['employeeCode','firstName','lastName','email'], 'employees');
  const emailMap = mappings.find(m => m.targetField === 'email');
  expect(emailMap?.csvColumn).toBe('email');
});

it('E2 | Alias match: "emp_id" → employeeCode', () => {
  const mappings = autoMapColumns(['emp_id','first_name','email'], 'employees');
  const empCode = mappings.find(m => m.targetField === 'employeeCode');
  expect(empCode?.csvColumn).toBe('emp_id');
});

it('E3 | Alias match: "DOJ" → dateOfJoining', () => {
  const mappings = autoMapColumns(['EmpCode','DOJ','Email'], 'employees');
  const doj = mappings.find(m => m.targetField === 'dateOfJoining');
  expect(doj?.csvColumn).toBe('DOJ');
});

it('E4 | Alias match: "PAN" → panNumber', () => {
  const mappings = autoMapColumns(['PAN','Mobile','Name'], 'employees');
  const pan = mappings.find(m => m.targetField === 'panNumber');
  expect(pan?.csvColumn).toBe('PAN');
});

it('E5 | No match: csvColumn is empty string', () => {
  const mappings = autoMapColumns(['xyz','abc'], 'employees');
  const email = mappings.find(m => m.targetField === 'email');
  expect(email?.csvColumn).toBe('');
});

it('E6 | Alias: "fname" → firstName', () => {
  const mappings = autoMapColumns(['fname','lname','email'], 'employees');
  const fn = mappings.find(m => m.targetField === 'firstName');
  expect(fn?.csvColumn).toBe('fname');
});

it('E7 | Required fields marked required in mapping', () => {
  const mappings = autoMapColumns(['employeeCode','email'], 'employees');
  const empCode = mappings.find(m => m.targetField === 'employeeCode');
  const email   = mappings.find(m => m.targetField === 'email');
  expect(empCode?.required).toBeTruthy();
  expect(email?.required).toBeTruthy();
});

// ════════════════════════════════════════════════════════════════════════════════
suite('F — Value Transformer');
// ════════════════════════════════════════════════════════════════════════════════

it('F1 | date_iso: DD/MM/YYYY → YYYY-MM-DD', () => {
  const { value } = transformValue('15/04/2023', 'date_iso');
  expect(value).toBe('2023-04-15');
});

it('F2 | date_iso: YYYY-MM-DD passthrough', () => {
  const { value } = transformValue('2023-04-15', 'date_iso');
  expect(value).toBe('2023-04-15');
});

it('F3 | date_iso: DD-MM-YYYY format', () => {
  const { value } = transformValue('15-04-2023', 'date_iso');
  expect(value).toBe('2023-04-15');
});

it('F4 | number: "1,20,000" → 120000', () => {
  const { value } = transformValue('1,20,000', 'number');
  expect(value).toBe(120000);
});

it('F5 | number: invalid string → error', () => {
  const { error } = transformValue('not-a-number', 'number');
  expect(error).toBeTruthy();
});

it('F6 | empty string → null value, no error', () => {
  const { value, error } = transformValue('', 'date_iso');
  expect(value).toBe(null);
  expect(error).toBeFalsy();
});

// ════════════════════════════════════════════════════════════════════════════════
suite('G — Preview Builder');
// ════════════════════════════════════════════════════════════════════════════════

const testCSV = `employeeCode,firstName,lastName,email,dateOfJoining
EMP001,Ravi,Kumar,ravi@co.in,01/04/2023
EMP002,Priya,Sharma,priya@co.in,15/06/2022
EMP003,Bad Email,Test,not-an-email,01/01/2024`;

it('G1 | Preview counts valid and error rows', () => {
  const { headers, rows } = parseCSV(testCSV);
  const mappings = autoMapColumns(headers, 'employees');
  const preview = buildPreview(rows, mappings, 'employees');
  expect(preview.totalRows).toBe(3);
  expect(preview.validRows).toBe(2);
  expect(preview.errorRows).toBe(1);
});

it('G2 | Preview detects duplicate codes in CSV', () => {
  const dupCSV = `employeeCode,firstName,email,dateOfJoining
EMP001,Ravi,ravi@co.in,01/04/2023
EMP001,Priya,priya@co.in,15/06/2022`;
  const { headers, rows } = parseCSV(dupCSV);
  const mappings = autoMapColumns(headers, 'employees');
  const preview = buildPreview(rows, mappings, 'employees');
  expect(preview.duplicateRows).toBeGreaterThan(0);
});

it('G3 | Preview detects existing code as duplicate', () => {
  const { headers, rows } = parseCSV(testCSV);
  const mappings = autoMapColumns(headers, 'employees');
  const existing = new Set(['EMP001']); // Simulate existing DB record
  const preview = buildPreview(rows, mappings, 'employees', existing);
  expect(preview.duplicateRows).toBeGreaterThan(0);
});

it('G4 | Sample data contains only valid rows (up to 5)', () => {
  const { headers, rows } = parseCSV(testCSV);
  const mappings = autoMapColumns(headers, 'employees');
  const preview = buildPreview(rows, mappings, 'employees');
  expect(preview.sampleData.length).toBeLessThan(6);
  expect(preview.sampleData.length).toBe(preview.validRows);
});

// ════════════════════════════════════════════════════════════════════════════════
suite('H — Migration Job State');
// ════════════════════════════════════════════════════════════════════════════════

it('H1 | createMigrationJob produces correct initial state', () => {
  const job = createMigrationJob('tenant-1', 'employees', [], 100, 'user-1');
  expect(job.tenantId).toBe('tenant-1');
  expect(job.entity).toBe('employees');
  expect(job.status).toBe('PENDING');
  expect(job.totalRows).toBe(100);
  expect(job.processedRows).toBe(0);
  expect(job.successRows).toBe(0);
  expect(job.failedRows).toBe(0);
});

it('H2 | Job ID is unique across multiple creates', () => {
  const job1 = createMigrationJob('t1', 'employees', [], 10, 'u1');
  const job2 = createMigrationJob('t1', 'employees', [], 10, 'u1');
  expect(job1.id).not.toBe(job2.id);
});

// ── Results ───────────────────────────────────────────────────────────────────

const total = _pass + _fail;
console.log('\n' + '═'.repeat(65));
console.log(`  SETUP WIZARD RESULTS: ${_pass} passed / ${_fail} failed / ${total} total`);
console.log('═'.repeat(65));
if (_pass === total) {
  console.log('  ✅ ALL TESTS PASSING — Setup Wizard + Config Validator READY');
  console.log('  📐 Presets(10) · Validator(20) · HealthScore(8) · CSV(8)');
  console.log('       AutoMap(7) · Transform(6) · Preview(4) · JobState(2)');
  console.log('  🏥 25 config checks · 5-dimension health score · 5 industry presets');
} else {
  console.log(`  ❌ ${_fail} FAILED`);
  process.exit(1);
}
