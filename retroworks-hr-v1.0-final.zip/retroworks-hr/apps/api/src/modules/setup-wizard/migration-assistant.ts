/**
 * Migration Assistant — pure CSV processing engine
 * ──────────────────────────────────────────────────────────────────────────────
 * No NestJS deps → runs standalone in tests.
 * Handles: parse → map → validate → preview → dry-run → commit → rollback
 */

import type {
  ColumnMapping, MigrationPreview, MigrationEntity,
  MigrationJob,
} from './types';
import { MIGRATION_TARGET_FIELDS } from './types';

// ─── CSV parser ───────────────────────────────────────────────────────────────

export function parseCSV(raw: string): { headers: string[]; rows: Record<string, string>[] } {
  const lines = raw.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n').filter(l => l.trim());
  if (lines.length === 0) return { headers: [], rows: [] };

  const parseRow = (line: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i]!;
      if (ch === '"') {
        if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
        else inQuotes = !inQuotes;
      } else if (ch === ',' && !inQuotes) {
        result.push(current.trim()); current = '';
      } else {
        current += ch;
      }
    }
    result.push(current.trim());
    return result;
  };

  const headers = parseRow(lines[0]!).map(h => h.trim());
  const rows = lines.slice(1).map(line => {
    const vals = parseRow(line);
    const row: Record<string, string> = {};
    headers.forEach((h, i) => { row[h] = (vals[i] ?? '').trim(); });
    return row;
  });

  return { headers, rows };
}

// ─── Auto-mapping heuristics ──────────────────────────────────────────────────

export function autoMapColumns(
  csvHeaders: string[],
  entity: MigrationEntity,
): ColumnMapping[] {
  const targets = MIGRATION_TARGET_FIELDS[entity] ?? [];

  const normalise = (s: string) =>
    s.toLowerCase().replace(/[\s_\-\.]/g, '');

  const aliases: Record<string, string[]> = {
    employeeCode: ['empcode', 'empid', 'employeeid', 'staffid', 'empno'],
    firstName:    ['firstname', 'fname', 'givenname'],
    lastName:     ['lastname', 'lname', 'surname', 'familyname'],
    email:        ['email', 'workemail', 'emailid', 'emailaddress'],
    phone:        ['phone', 'mobile', 'mobileno', 'contactno', 'phoneno'],
    dateOfJoining: ['doj', 'dateofjoining', 'joiningdate', 'startdate'],
    dateOfBirth:  ['dob', 'dateofbirth', 'birthdate'],
    department:   ['department', 'dept', 'division'],
    designation:  ['designation', 'title', 'jobtitle', 'position'],
    ctc:          ['ctc', 'annualctc', 'annualsalary', 'salary', 'grosssalary'],
    panNumber:    ['pan', 'pannumber', 'panno'],
    aadhaarNumber:['aadhaar', 'aadhaarnumber', 'uid', 'aadhaarno'],
    gender:       ['gender', 'sex'],
    bankAccountNumber: ['bankaccount', 'accountno', 'accountnumber', 'bankaccno'],
    bankIfsc:     ['ifsc', 'ifsccode', 'bankifsc'],
    employmentType: ['emptype', 'employmenttype', 'workertype'],
  };

  return targets.map(target => {
    const normTarget = normalise(target.field);
    const matchedHeader = csvHeaders.find(h => {
      const normH = normalise(h);
      if (normH === normTarget) return true;
      const alts = aliases[target.field] ?? [];
      return alts.includes(normH);
    });

    return {
      csvColumn: matchedHeader ?? '',
      targetField: target.field,
      required: target.required,
      defaultValue: '',
      transform: target.type === 'date' ? 'date_iso'
        : target.type === 'number' ? 'number'
        : undefined,
    };
  });
}

// ─── Value transformer ────────────────────────────────────────────────────────

export function transformValue(
  raw: string,
  transform?: string,
): { value: unknown; error?: string } {
  if (!raw || raw.trim() === '') return { value: null };

  switch (transform) {
    case 'uppercase': return { value: raw.toUpperCase().trim() };
    case 'lowercase': return { value: raw.toLowerCase().trim() };
    case 'number': {
      const n = parseFloat(raw.replace(/,/g, ''));
      if (isNaN(n)) return { value: null, error: `"${raw}" is not a valid number` };
      return { value: n };
    }
    case 'boolean': {
      const v = raw.toLowerCase().trim();
      if (['true', '1', 'yes', 'y'].includes(v)) return { value: true };
      if (['false', '0', 'no', 'n'].includes(v)) return { value: false };
      return { value: null, error: `"${raw}" is not a valid boolean` };
    }
    case 'date_iso': {
      // Accepts: DD/MM/YYYY, MM/DD/YYYY, YYYY-MM-DD, DD-MM-YYYY
      const cleaned = raw.trim();
      // YYYY-MM-DD
      if (/^\d{4}-\d{2}-\d{2}$/.test(cleaned)) {
        const d = new Date(cleaned);
        if (isNaN(d.getTime())) return { value: null, error: `Invalid date: ${raw}` };
        return { value: d.toISOString().slice(0, 10) };
      }
      // DD/MM/YYYY or DD-MM-YYYY
      const dmy = cleaned.match(/^(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})$/);
      if (dmy) {
        const d = new Date(`${dmy[3]}-${dmy[2]!.padStart(2,'0')}-${dmy[1]!.padStart(2,'0')}`);
        if (isNaN(d.getTime())) return { value: null, error: `Invalid date: ${raw}` };
        return { value: d.toISOString().slice(0, 10) };
      }
      return { value: null, error: `Unrecognised date format: ${raw}` };
    }
    default: return { value: raw.trim() };
  }
}

// ─── Row validator ────────────────────────────────────────────────────────────

export function validateRow(
  row: Record<string, string>,
  mappings: ColumnMapping[],
  entity: MigrationEntity,
  rowIndex: number,
): {
  transformed: Record<string, unknown>;
  errors: Array<{ row: number; column: string; error: string }>;
  warnings: Array<{ row: number; message: string }>;
} {
  const transformed: Record<string, unknown> = {};
  const errors: Array<{ row: number; column: string; error: string }> = [];
  const warnings: Array<{ row: number; message: string }> = [];
  const targets = MIGRATION_TARGET_FIELDS[entity] ?? [];

  for (const mapping of mappings) {
    const rawValue = mapping.csvColumn ? (row[mapping.csvColumn] ?? '') : '';
    const effectiveValue = rawValue || (mapping.defaultValue ?? '');

    if (!effectiveValue) {
      if (mapping.required) {
        errors.push({ row: rowIndex, column: mapping.targetField, error: `Required field "${mapping.targetField}" is empty` });
      }
      transformed[mapping.targetField] = null;
      continue;
    }

    const { value, error } = transformValue(effectiveValue, mapping.transform);
    if (error) {
      errors.push({ row: rowIndex, column: mapping.targetField, error });
    }

    // Enum validation
    const targetDef = targets.find(t => t.field === mapping.targetField);
    if (targetDef?.type?.startsWith('enum:') && value) {
      const allowedValues = targetDef.type.replace('enum:', '').split(',');
      if (!allowedValues.includes(String(value).toLowerCase())) {
        errors.push({
          row: rowIndex,
          column: mapping.targetField,
          error: `"${value}" is not valid. Allowed: ${allowedValues.join(', ')}`,
        });
      }
    }

    // PAN format validation
    if (mapping.targetField === 'panNumber' && value) {
      if (!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(String(value).toUpperCase())) {
        warnings.push({ row: rowIndex, message: `PAN "${value}" may be invalid (expected format: ABCDE1234F)` });
      }
    }

    // IFSC validation
    if (mapping.targetField === 'bankIfsc' && value) {
      if (!/^[A-Z]{4}0[A-Z0-9]{6}$/.test(String(value).toUpperCase())) {
        warnings.push({ row: rowIndex, message: `IFSC "${value}" may be invalid` });
      }
    }

    // Email validation
    if ((mapping.targetField === 'email') && value) {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value))) {
        errors.push({ row: rowIndex, column: mapping.targetField, error: `"${value}" is not a valid email` });
      }
    }

    transformed[mapping.targetField] = value;
  }

  return { transformed, errors, warnings };
}

// ─── Preview builder ──────────────────────────────────────────────────────────

export function buildPreview(
  rows: Record<string, string>[],
  mappings: ColumnMapping[],
  entity: MigrationEntity,
  existingCodes: Set<string> = new Set(),
): MigrationPreview {
  const allErrors: Array<{ row: number; column: string; error: string }> = [];
  const allWarnings: Array<{ row: number; message: string }> = [];
  const validTransformed: Record<string, unknown>[] = [];
  let errorRows = 0;
  let duplicateRows = 0;

  // Track duplicates within the CSV itself
  const seenCodes = new Set<string>();

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i]!;
    const { transformed, errors, warnings } = validateRow(row, mappings, entity, i + 2); // +2 = 1-indexed + header

    // Duplicate detection
    const codeMapping = mappings.find(m => m.targetField === 'employeeCode');
    if (codeMapping) {
      const code = row[codeMapping.csvColumn] ?? '';
      if (seenCodes.has(code) || existingCodes.has(code)) {
        allWarnings.push({ row: i + 2, message: `Duplicate employee code "${code}"` });
        duplicateRows++;
      }
      if (code) seenCodes.add(code);
    }

    allErrors.push(...errors);
    allWarnings.push(...warnings);

    if (errors.length > 0) {
      errorRows++;
    } else {
      validTransformed.push(transformed);
    }
  }

  return {
    totalRows: rows.length,
    validRows: validTransformed.length,
    errorRows,
    duplicateRows,
    sampleData: validTransformed.slice(0, 5),
    errors: allErrors,
    warnings: allWarnings,
  };
}

// ─── Migration job state machine ───────────────────────────────────────────────

export function createMigrationJob(
  tenantId: string,
  entity: MigrationEntity,
  mappings: ColumnMapping[],
  totalRows: number,
  createdBy: string,
): MigrationJob {
  return {
    id: `mig_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    tenantId,
    entity,
    status: 'PENDING',
    totalRows,
    processedRows: 0,
    successRows: 0,
    failedRows: 0,
    columnMappings: mappings,
    errors: [],
    createdAt: new Date(),
    createdBy,
  };
}

// ─── Field suggestions (for UI auto-complete) ─────────────────────────────────

export function getSuggestedMappings(entity: MigrationEntity) {
  return MIGRATION_TARGET_FIELDS[entity] ?? [];
}
