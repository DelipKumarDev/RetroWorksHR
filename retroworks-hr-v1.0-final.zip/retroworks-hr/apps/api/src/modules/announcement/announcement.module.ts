import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaClient, type Prisma } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import {
  IsString, IsOptional, IsEnum, IsDateString, IsArray, IsBoolean,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  Controller, Get, Post, Patch, Delete, Body, Param, Query,
  UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── DTOs ───────────────────────────────────────────────────

export class CreateAnnouncementDto {
  @ApiProperty()
  @IsString()
  title: string;

  @ApiProperty()
  @IsString()
  content: string;

  @ApiPropertyOptional({ enum: ['all', 'department', 'location', 'grade', 'custom'] })
  @IsOptional()
  @IsEnum(['all', 'department', 'location', 'grade', 'custom'])
  targetAudience?: string;

  @ApiPropertyOptional({ description: 'Target department IDs' })
  @IsOptional()
  @IsArray()
  targetDepartmentIds?: string[];

  @ApiPropertyOptional({ description: 'Target location IDs' })
  @IsOptional()
  @IsArray()
  targetLocationIds?: string[];

  @ApiPropertyOptional({ enum: ['info', 'warning', 'celebration', 'policy', 'event'] })
  @IsOptional()
  @IsEnum(['info', 'warning', 'celebration', 'policy', 'event'])
  type?: string;

  @ApiPropertyOptional({ description: 'Pinned to top of feed' })
  @IsOptional()
  @IsBoolean()
  pinned?: boolean;

  @ApiPropertyOptional({ description: 'Published date (future = scheduled)' })
  @IsOptional()
  @IsDateString()
  publishAt?: string;

  @ApiPropertyOptional({ description: 'Expires and disappears after this date' })
  @IsOptional()
  @IsDateString()
  expiresAt?: string;

  @ApiPropertyOptional({ description: 'Attachments / image URLs' })
  @IsOptional()
  @IsArray()
  attachments?: string[];

  @ApiPropertyOptional()
  @IsOptional()
  @IsBoolean()
  sendNotification?: boolean;
}

// ─── Service ───────────────────────────────────────────────

@Injectable()
export class AnnouncementService {
  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  async create(tenantId: string, dto: CreateAnnouncementDto, createdBy: string) {
    const announcement = await this.prisma.announcement.create({
      data: {
        tenantId,
        title: dto.title,
        content: dto.content,
        targetAudience: dto.targetAudience ?? 'all',
        targetDepartmentIds: dto.targetDepartmentIds ?? [],
        targetLocationIds: dto.targetLocationIds ?? [],
        type: dto.type ?? 'info',
        pinned: dto.pinned ?? false,
        publishAt: dto.publishAt ? new Date(dto.publishAt) : new Date(),
        expiresAt: dto.expiresAt ? new Date(dto.expiresAt) : undefined,
        attachments: dto.attachments ?? [],
        status: dto.publishAt && new Date(dto.publishAt) > new Date() ? 'scheduled' : 'published',
        createdBy,
        updatedBy: createdBy,
      },
    });

    if (dto.sendNotification && announcement.status === 'published') {
      this.events.emit('announcement.published', { tenantId, announcement });
    }

    return announcement;
  }

  async listForUser(
    tenantId: string,
    userId: string,
    departmentId?: string,
    locationId?: string,
    cursor?: string,
    limit = 20,
  ) {
    const now = new Date();
    const where: Prisma.AnnouncementWhereInput = {
      tenantId,
      status: 'published',
      publishAt: { lte: now },
      deletedAt: null,
      OR: [
        { expiresAt: null },
        { expiresAt: { gt: now } },
      ],
      AND: [
        {
          OR: [
            { targetAudience: 'all' },
            { targetAudience: 'department', targetDepartmentIds: { has: departmentId ?? '' } },
            { targetAudience: 'location', targetLocationIds: { has: locationId ?? '' } },
          ],
        },
      ],
    };

    const [pinned, regular] = await Promise.all([
      this.prisma.announcement.findMany({
        where: { ...where, pinned: true },
        orderBy: { publishAt: 'desc' },
        take: 3,
      }),
      this.prisma.announcement.findMany({
        where: { ...where, pinned: false, ...(cursor && { id: { lt: cursor } }) },
        orderBy: { publishAt: 'desc' },
        take: limit + 1,
        include: { _count: { select: { reactions: true } } },
      }),
    ]);

    const hasMore = regular.length > limit;
    return {
      pinned,
      announcements: regular.slice(0, limit),
      hasMore,
      nextCursor: hasMore ? regular[limit - 1]?.id : undefined,
    };
  }

  async listForAdmin(tenantId: string, status?: string) {
    return this.prisma.announcement.findMany({
      where: { tenantId, deletedAt: null, ...(status && { status }) },
      include: { _count: { select: { reactions: true } } },
      orderBy: [{ pinned: 'desc' }, { publishAt: 'desc' }],
    });
  }

  async getOne(tenantId: string, id: string) {
    const ann = await this.prisma.announcement.findFirst({
      where: { id, tenantId, deletedAt: null },
    });
    if (!ann) throw new NotFoundException('Announcement not found');
    return ann;
  }

  async update(tenantId: string, id: string, dto: Partial<CreateAnnouncementDto>, updatedBy: string) {
    await this.getOne(tenantId, id);
    return this.prisma.announcement.update({
      where: { id },
      data: {
        ...(dto.title && { title: dto.title }),
        ...(dto.content && { content: dto.content }),
        ...(dto.pinned !== undefined && { pinned: dto.pinned }),
        ...(dto.type && { type: dto.type }),
        ...(dto.expiresAt && { expiresAt: new Date(dto.expiresAt) }),
        updatedBy, updatedAt: new Date(),
      },
    });
  }

  async delete(tenantId: string, id: string, deletedBy: string) {
    await this.getOne(tenantId, id);
    await this.prisma.announcement.update({
      where: { id },
      data: { deletedAt: new Date(), updatedBy: deletedBy },
    });
  }

  async react(tenantId: string, id: string, emoji: string, userId: string) {
    // Toggle reaction
    const existing = await this.prisma.announcementReaction.findFirst({
      where: { announcementId: id, userId, emoji },
    });

    if (existing) {
      await this.prisma.announcementReaction.delete({ where: { id: existing.id } });
      return { reacted: false };
    }

    await this.prisma.announcementReaction.create({
      data: { announcementId: id, userId, tenantId, emoji },
    });
    return { reacted: true };
  }

  async getReactions(tenantId: string, id: string) {
    const reactions = await this.prisma.announcementReaction.groupBy({
      by: ['emoji'],
      where: { announcementId: id },
      _count: { emoji: true },
    });
    return reactions.map(r => ({ emoji: r.emoji, count: r._count.emoji }));
  }
}

// ─── Controller ───────────────────────────────────────────

@ApiTags('announcements')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('announcements')
export class AnnouncementController {
  constructor(private readonly announcementService: AnnouncementService) {}

  @Post()
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Create an announcement' })
  create(@Body() dto: CreateAnnouncementDto, @CurrentUser() u: JwtPayload) {
    return this.announcementService.create(u.tid, dto, u.sub);
  }

  @Get()
  @ApiOperation({ summary: 'Get announcements for the current user (feed)' })
  feed(
    @Query('cursor') cursor: string | undefined,
    @Query('departmentId') deptId: string | undefined,
    @Query('locationId') locId: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.announcementService.listForUser(u.tid, u.sub, deptId, locId, cursor);
  }

  @Get('admin/all')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Get all announcements for admin management' })
  adminList(@Query('status') status: string | undefined, @CurrentUser() u: JwtPayload) {
    return this.announcementService.listForAdmin(u.tid, status);
  }

  @Get(':id')
  getOne(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.announcementService.getOne(u.tid, id);
  }

  @Patch(':id')
  @Roles('hr-admin', 'super-admin')
  update(
    @Param('id') id: string,
    @Body() dto: Partial<CreateAnnouncementDto>,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.announcementService.update(u.tid, id, dto, u.sub);
  }

  @Delete(':id')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.NO_CONTENT)
  delete(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.announcementService.delete(u.tid, id, u.sub);
  }

  @Post(':id/react')
  @ApiOperation({ summary: 'Toggle emoji reaction on an announcement' })
  react(
    @Param('id') id: string,
    @Body('emoji') emoji: string,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.announcementService.react(u.tid, id, emoji, u.sub);
  }

  @Get(':id/reactions')
  reactions(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.announcementService.getReactions(u.tid, id);
  }
}

@Module({
  controllers: [AnnouncementController],
  providers: [AnnouncementService],
  exports: [AnnouncementService],
})
export class AnnouncementModule {}
