import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2, OnEvent } from '@nestjs/event-emitter';
import { Controller, Get, Post, Put, Delete, Patch, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

type TriggerType = 'leave.submitted' | 'leave.approved' | 'attendance.absent' | 'attendance.late'
  | 'employee.created' | 'employee.updated' | 'employee.probation_ending'
  | 'payroll.processed' | 'salary.changed' | 'review.self_submitted'
  | 'expense.submitted' | 'helpdesk.ticket.created' | 'helpdesk.sla.breaching';
type ConditionOperator = 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains' | 'in' | 'is_null';
type ActionType = 'notify_employee' | 'notify_manager' | 'notify_hr' | 'notify_custom'
  | 'send_slack' | 'assign_task' | 'create_ticket' | 'approve' | 'reject' | 'escalate' | 'set_field' | 'run_webhook';

interface Condition { field: string; operator: ConditionOperator; value: string | number | string[] }
interface Action { type: ActionType; params: Record<string, unknown> }
interface AutomationRule {
  id: string; tenantId: string; name: string; description?: string;
  trigger: TriggerType; conditions: Condition[]; conditionLogic: 'AND' | 'OR';
  actions: Action[]; isActive: boolean; runCount: number; lastRunAt?: Date;
}

export const TRIGGER_CATALOGUE = [
  { category: 'Leave', triggers: [
    { value: 'leave.submitted', label: 'Leave Request Submitted', fields: ['leave.type', 'leave.days', 'employee.department'] },
    { value: 'leave.approved', label: 'Leave Approved', fields: ['leave.type', 'leave.days'] },
  ]},
  { category: 'Attendance', triggers: [
    { value: 'attendance.absent', label: 'Employee Absent', fields: ['attendance.consecutiveDays', 'employee.department'] },
    { value: 'attendance.late', label: 'Employee Late', fields: ['attendance.lateMinutes'] },
  ]},
  { category: 'Employee', triggers: [
    { value: 'employee.created', label: 'New Employee Added', fields: ['employee.department', 'employee.location', 'employee.employmentType'] },
    { value: 'employee.probation_ending', label: 'Probation Ending Soon', fields: ['employee.daysLeft'] },
  ]},
  { category: 'Payroll', triggers: [
    { value: 'payroll.processed', label: 'Payroll Completed', fields: ['payroll.month', 'payroll.year'] },
    { value: 'salary.changed', label: 'Salary Revised', fields: ['salary.changePercent', 'salary.newCTC'] },
  ]},
  { category: 'Performance', triggers: [
    { value: 'review.self_submitted', label: 'Self Review Submitted', fields: ['review.cycleName', 'employee.department'] },
  ]},
  { category: 'Expense', triggers: [
    { value: 'expense.submitted', label: 'Expense Submitted', fields: ['expense.amount', 'expense.category'] },
  ]},
  { category: 'Helpdesk', triggers: [
    { value: 'helpdesk.ticket.created', label: 'Ticket Created', fields: ['ticket.priority', 'ticket.category'] },
    { value: 'helpdesk.sla.breaching', label: 'SLA Breaching', fields: ['ticket.priority', 'ticket.hoursLeft'] },
  ]},
];

export const ACTION_CATALOGUE = [
  { value: 'notify_employee', label: 'Notify Employee', params: ['message'] },
  { value: 'notify_manager', label: 'Notify Manager', params: ['message'] },
  { value: 'notify_hr', label: 'Notify HR Team', params: ['message'] },
  { value: 'notify_custom', label: 'Notify Custom Email', params: ['email', 'subject', 'message'] },
  { value: 'send_slack', label: 'Send Slack Message', params: ['channel', 'message'] },
  { value: 'assign_task', label: 'Assign Task', params: ['taskTitle', 'assignTo', 'dueInDays'] },
  { value: 'create_ticket', label: 'Create Helpdesk Ticket', params: ['title', 'priority', 'category'] },
  { value: 'escalate', label: 'Escalate to Role', params: ['escalateTo', 'message'] },
  { value: 'approve', label: 'Auto-Approve', params: [] },
  { value: 'reject', label: 'Auto-Reject', params: ['reason'] },
  { value: 'run_webhook', label: 'Call Webhook URL', params: ['url', 'method'] },
];

@Injectable()
export class AutomationEngine {
  evaluateCondition(condition: Condition, context: Record<string, unknown>): boolean {
    const actual = condition.field.split('.').reduce((o: any, k) => o?.[k], context);
    switch (condition.operator) {
      case 'eq': return String(actual) === String(condition.value);
      case 'neq': return String(actual) !== String(condition.value);
      case 'gt': return Number(actual) > Number(condition.value);
      case 'gte': return Number(actual) >= Number(condition.value);
      case 'lt': return Number(actual) < Number(condition.value);
      case 'lte': return Number(actual) <= Number(condition.value);
      case 'contains': return String(actual).toLowerCase().includes(String(condition.value).toLowerCase());
      case 'in': return Array.isArray(condition.value) && condition.value.map(String).includes(String(actual));
      case 'is_null': return actual === null || actual === undefined;
      default: return false;
    }
  }

  evaluateRule(rule: AutomationRule, context: Record<string, unknown>): boolean {
    if (!rule.isActive || rule.conditions.length === 0) return rule.isActive;
    const results = rule.conditions.map(c => this.evaluateCondition(c, context));
    return rule.conditionLogic === 'AND' ? results.every(Boolean) : results.some(Boolean);
  }
}

@Injectable()
export class AutomationService {
  private readonly logger = new Logger(AutomationService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
    private readonly engine: AutomationEngine,
  ) {}

  async listRules(tenantId: string) {
    return this.prisma.automationRule.findMany({
      where: { tenantId, deletedAt: null },
      orderBy: [{ isActive: 'desc' }, { createdAt: 'desc' }],
    });
  }

  async createRule(tenantId: string, dto: Partial<AutomationRule>, createdBy: string) {
    return this.prisma.automationRule.create({
      data: {
        tenantId, name: dto.name!, description: dto.description,
        trigger: dto.trigger!, conditions: dto.conditions as any ?? [],
        conditionLogic: dto.conditionLogic ?? 'AND',
        actions: dto.actions as any ?? [],
        isActive: true, runCount: 0, createdBy, updatedBy: createdBy,
      },
    });
  }

  async updateRule(tenantId: string, ruleId: string, dto: any, updatedBy: string) {
    const rule = await this.prisma.automationRule.findFirst({ where: { id: ruleId, tenantId } });
    if (!rule) throw new NotFoundException('Rule not found');
    return this.prisma.automationRule.update({ where: { id: ruleId }, data: { ...dto, updatedBy } });
  }

  async toggleRule(tenantId: string, ruleId: string, updatedBy: string) {
    const rule = await this.prisma.automationRule.findFirst({ where: { id: ruleId, tenantId } });
    if (!rule) throw new NotFoundException('Rule not found');
    return this.prisma.automationRule.update({ where: { id: ruleId }, data: { isActive: !rule.isActive, updatedBy } });
  }

  async deleteRule(tenantId: string, ruleId: string) {
    return this.prisma.automationRule.update({ where: { id: ruleId }, data: { deletedAt: new Date() } });
  }

  async getRuleLog(tenantId: string, ruleId: string) {
    return this.prisma.automationRuleLog.findMany({
      where: { ruleId, tenantId }, orderBy: { createdAt: 'desc' }, take: 50,
    });
  }

  getCatalogue() { return { triggers: TRIGGER_CATALOGUE, actions: ACTION_CATALOGUE }; }

  @OnEvent('**')
  async onAnyEvent(context: Record<string, unknown> & { event?: string }) {
    const tenantId = context?.tenantId as string;
    const event = context?.event as string;
    if (!tenantId || !event) return;

    const rules = await this.prisma.automationRule.findMany({
      where: { tenantId, trigger: event, isActive: true, deletedAt: null },
    }).catch(() => []);

    for (const rule of rules) {
      if (!this.engine.evaluateRule(rule as any, context)) continue;
      await this.executeActions(rule as any, context);
      await this.prisma.automationRule.update({
        where: { id: rule.id },
        data: { runCount: { increment: 1 }, lastRunAt: new Date() },
      }).catch(() => {});
      await this.prisma.automationRuleLog.create({
        data: { tenantId, ruleId: rule.id, event, context: context as any, actionsExecuted: (rule.actions as any[]).length, status: 'success' },
      }).catch(() => {});
      this.logger.log(`Rule "${rule.name}" executed for ${event}`);
    }
  }

  private async executeActions(rule: AutomationRule, ctx: Record<string, unknown>) {
    const interp = (t: string) => (t ?? '').replace(/\{\{(\w+(?:\.\w+)*)\}\}/g, (_, p) => {
      const v = p.split('.').reduce((o: any, k: string) => o?.[k], ctx);
      return v !== undefined ? String(v) : `{{${p}}}`;
    });

    for (const action of rule.actions) {
      switch (action.type) {
        case 'notify_employee':
          this.events.emit('automation.notification', { tenantId: rule.tenantId, recipientId: ctx.employeeId, title: rule.name, message: interp(action.params.message as string) });
          break;
        case 'notify_manager':
          if (ctx.managerId) this.events.emit('automation.notification', { tenantId: rule.tenantId, recipientId: ctx.managerId, title: rule.name, message: interp(action.params.message as string) });
          break;
        case 'notify_hr':
          this.events.emit('automation.notify_hr', { tenantId: rule.tenantId, ruleName: rule.name, message: interp(action.params.message as string) });
          break;
        case 'create_ticket':
          this.events.emit('automation.create_ticket', { tenantId: rule.tenantId, title: interp(action.params.title as string), priority: action.params.priority ?? 'p3', category: action.params.category ?? 'automation' });
          break;
        case 'run_webhook':
          await fetch(action.params.url as string, { method: (action.params.method as string) ?? 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ rule: rule.name, event: rule.trigger, context: ctx }) }).catch(() => {});
          break;
        case 'escalate':
          this.events.emit('automation.escalation', { tenantId: rule.tenantId, escalateTo: action.params.escalateTo, message: interp(action.params.message as string), context: ctx });
          break;
      }
    }
  }
}

@ApiTags('automation')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('hr-admin', 'super-admin')
@Controller('automation')
export class AutomationController {
  constructor(private readonly automationService: AutomationService) {}

  @Get('catalogue')
  getCatalogue() { return this.automationService.getCatalogue(); }

  @Get('rules')
  listRules(@CurrentUser() u: JwtPayload) { return this.automationService.listRules(u.tid); }

  @Post('rules')
  @ApiOperation({ summary: 'Create IF/THEN automation rule' })
  createRule(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.automationService.createRule(u.tid, dto, u.sub); }

  @Put('rules/:id')
  updateRule(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.automationService.updateRule(u.tid, id, dto, u.sub); }

  @Patch('rules/:id/toggle')
  toggleRule(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.automationService.toggleRule(u.tid, id, u.sub); }

  @Delete('rules/:id')
  deleteRule(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.automationService.deleteRule(u.tid, id); }

  @Get('rules/:id/log')
  getRuleLog(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.automationService.getRuleLog(u.tid, id); }
}

@Module({
  controllers: [AutomationController],
  providers: [AutomationService, AutomationEngine],
  exports: [AutomationService, AutomationEngine],
})
export class AutomationModule {}
