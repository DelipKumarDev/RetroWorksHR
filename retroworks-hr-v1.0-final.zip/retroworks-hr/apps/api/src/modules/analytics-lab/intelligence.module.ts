/**
 * Decision Assist Engine — AI-augmented decision intelligence
 * Employee Lifecycle Timeline — chronological story view
 * Ethics & Bias Detection — fairness monitor
 * People Analytics Lab — advanced correlations
 */

import { Injectable, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { Controller, Get, Post, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ═══════════════════════════════════════════════════════════════════════
// 1. DECISION ASSIST ENGINE
// ═══════════════════════════════════════════════════════════════════════

interface DecisionContext {
  action: 'approve_leave' | 'change_salary' | 'promote' | 'terminate' | 'reject_leave' | 'approve_expense';
  employeeId: string;
  params: Record<string, unknown>;
}

interface DecisionInsight {
  type: 'policy_warning' | 'cost_impact' | 'team_impact' | 'risk_score' | 'precedent' | 'compliance';
  severity: 'critical' | 'warning' | 'info';
  title: string;
  detail: string;
  value?: string;
}

@Injectable()
export class DecisionAssistService {
  private readonly logger = new Logger(DecisionAssistService.name);

  constructor(private readonly prisma: PrismaClient) {}

  async getDecisionInsights(tenantId: string, ctx: DecisionContext): Promise<{ proceed: boolean; insights: DecisionInsight[]; requiresConfirmation: boolean }> {
    const insights: DecisionInsight[] = [];
    let requiresConfirmation = false;

    switch (ctx.action) {
      case 'approve_leave': await this.analyzeLeaveApproval(tenantId, ctx, insights); break;
      case 'change_salary': await this.analyzeSalaryChange(tenantId, ctx, insights); break;
      case 'promote': await this.analyzePromotion(tenantId, ctx, insights); break;
      case 'approve_expense': await this.analyzeExpense(tenantId, ctx, insights); break;
      case 'terminate': await this.analyzeTermination(tenantId, ctx, insights); break;
    }

    requiresConfirmation = insights.some(i => i.severity === 'critical' || i.severity === 'warning');
    return { proceed: !insights.some(i => i.type === 'compliance' && i.severity === 'critical'), insights, requiresConfirmation };
  }

  private async analyzeLeaveApproval(tenantId: string, ctx: DecisionContext, insights: DecisionInsight[]) {
    const { employeeId } = ctx;
    const days = ctx.params.days as number;
    const startDate = ctx.params.startDate as string;

    const emp = await this.prisma.employee.findFirst({
      where: { id: employeeId, tenantId },
      include: { department: { select: { name: true } } },
    });

    // Check team coverage
    if (startDate) {
      const teamOnLeave = await this.prisma.leaveRequest.count({
        where: { tenantId, status: 'approved', employee: { departmentId: emp?.departmentId }, startDate: { lte: new Date(startDate) }, endDate: { gte: new Date(startDate) },
        },
      });
      if (teamOnLeave >= 2) {
        insights.push({ type: 'team_impact', severity: 'warning', title: 'Team Coverage Risk', detail: `${teamOnLeave} teammates already on leave during this period`, value: `${teamOnLeave} concurrent absences` });
      }
    }

    // Check balance
    if (days > 0) {
      const balance = await this.prisma.leaveBalance.findFirst({ where: { tenantId, employeeId, year: new Date().getFullYear() } });
      if (balance && days > (balance.balance as number)) {
        insights.push({ type: 'policy_warning', severity: 'critical', title: 'Insufficient Leave Balance', detail: `Employee has ${balance.balance} days available but requested ${days}`, value: `${days - (balance.balance as number)} days excess` });
      }
    }

    // Precedent check: same employee high leave usage
    const yearTotal = await this.prisma.leaveRequest.aggregate({
      where: { tenantId, employeeId, status: 'approved', startDate: { gte: new Date(`${new Date().getFullYear()}-01-01`) } },
      _sum: { totalDays: true },
    });
    const totalUsed = (yearTotal._sum.totalDays ?? 0) as number;
    if (totalUsed + days > 25) {
      insights.push({ type: 'risk_score', severity: 'warning', title: 'High Leave Utilization', detail: `Employee will have used ${totalUsed + days} days this year — above 25-day threshold`, value: `${totalUsed} used + ${days} requested` });
    }
  }

  private async analyzeSalaryChange(tenantId: string, ctx: DecisionContext, insights: DecisionInsight[]) {
    const { employeeId } = ctx;
    const newCTC = ctx.params.newCTC as number;

    const emp = await this.prisma.employee.findFirst({
      where: { id: employeeId, tenantId },
      include: {
        designation: true, department: { select: { name: true } },
        salaryRevisions: { orderBy: { effectiveDate: 'desc' }, take: 1 },
      },
    });

    if (!emp) return;
    const currentCTC = Number(emp.ctc);
    const changePct = ((newCTC - currentCTC) / currentCTC) * 100;

    // Change percent warning
    if (changePct > 30) insights.push({ type: 'policy_warning', severity: 'warning', title: 'Large Salary Revision', detail: `${changePct.toFixed(1)}% revision is unusually high (benchmark: 10-15%)`, value: `+${changePct.toFixed(1)}%` });
    if (changePct < 0) insights.push({ type: 'policy_warning', severity: 'critical', title: 'Salary Reduction', detail: 'Salary reductions are legally restricted in India and may trigger dispute', value: `${changePct.toFixed(1)}%` });

    // Cost impact
    const monthlyDelta = (newCTC - currentCTC) / 12;
    const pfDelta = Math.min(newCTC / 12 * 0.4, 15000) * 0.12 - Math.min(currentCTC / 12 * 0.4, 15000) * 0.12;
    insights.push({ type: 'cost_impact', severity: 'info', title: 'Monthly Cost Impact', detail: `Gross monthly increase: ₹${monthlyDelta.toLocaleString('en-IN')} | Additional PF employer: ₹${pfDelta.toFixed(0)}/month`, value: `₹${((monthlyDelta + pfDelta) * 12 / 100_000).toFixed(1)}L/year` });

    // Peer comparison
    const peerSalaries = await this.prisma.employee.aggregate({
      where: { tenantId, designationId: emp.designationId, status: 'active', deletedAt: null, id: { not: employeeId } },
      _avg: { ctc: true }, _max: { ctc: true }, _min: { ctc: true },
    });
    if (peerSalaries._avg.ctc) {
      const peerAvg = Number(peerSalaries._avg.ctc);
      const peerMax = Number(peerSalaries._max.ctc);
      if (newCTC > peerMax) insights.push({ type: 'risk_score', severity: 'warning', title: 'Above Role Maximum', detail: `New CTC ₹${(newCTC / 100_000).toFixed(1)}L exceeds peer max ₹${(peerMax / 100_000).toFixed(1)}L for ${(emp.designation as any)?.name}`, value: `${((newCTC - peerMax) / peerMax * 100).toFixed(1)}% above max` });
      else insights.push({ type: 'precedent', severity: 'info', title: 'Peer Salary Range', detail: `${(emp.designation as any)?.name} range: ₹${(Number(peerSalaries._min.ctc) / 100_000).toFixed(1)}L – ₹${(peerMax / 100_000).toFixed(1)}L (avg ₹${(peerAvg / 100_000).toFixed(1)}L)`, value: `Avg: ₹${(peerAvg / 100_000).toFixed(1)}L` });
    }
  }

  private async analyzePromotion(tenantId: string, ctx: DecisionContext, insights: DecisionInsight[]) {
    const { employeeId } = ctx;
    const emp = await this.prisma.employee.findFirst({
      where: { id: employeeId, tenantId },
      include: {
        performanceReviews: { orderBy: { createdAt: 'desc' }, take: 1, select: { managerRating: true } },
        salaryRevisions: { orderBy: { effectiveDate: 'desc' }, take: 1 },
      },
    });
    if (!emp) return;

    const lastRating = (emp.performanceReviews as any[])[0]?.managerRating;
    if (lastRating && lastRating < 3.5) insights.push({ type: 'policy_warning', severity: 'warning', title: 'Below Promotion Threshold', detail: `Latest performance rating ${lastRating}/5 is below recommended threshold of 3.5 for promotion`, value: `Rating: ${lastRating}/5` });
    else if (lastRating >= 4) insights.push({ type: 'precedent', severity: 'info', title: 'Strong Performance Signal', detail: `Rating ${lastRating}/5 supports promotion`, value: `Rating: ${lastRating}/5` });

    if (emp.dateOfJoining) {
      const tenureMonths = (Date.now() - new Date(emp.dateOfJoining).getTime()) / (30 * 86_400_000);
      if (tenureMonths < 18) insights.push({ type: 'risk_score', severity: 'info', title: 'Short Tenure', detail: `Employee has ${Math.round(tenureMonths)} months tenure. Typical minimum for promotion: 18-24 months`, value: `${Math.round(tenureMonths)} months` });
    }
  }

  private async analyzeExpense(tenantId: string, ctx: DecisionContext, insights: DecisionInsight[]) {
    const amount = ctx.params.amount as number;
    const category = ctx.params.category as string;
    if (amount > 50000) insights.push({ type: 'policy_warning', severity: 'warning', title: 'High-Value Expense', detail: `₹${amount.toLocaleString('en-IN')} exceeds standard approval threshold of ₹50,000`, value: `₹${(amount / 100_000).toFixed(1)}L` });
    insights.push({ type: 'compliance', severity: 'info', title: 'TDS Applicability', detail: amount > 30000 ? 'TDS @10% may apply (professional services >₹30,000 per year)' : 'Below TDS threshold', value: amount > 30000 ? 'TDS: 10%' : 'No TDS' });
  }

  private async analyzeTermination(tenantId: string, ctx: DecisionContext, insights: DecisionInsight[]) {
    const { employeeId } = ctx;
    const emp = await this.prisma.employee.findFirst({
      where: { id: employeeId, tenantId },
      include: { department: { select: { name: true } }, skills: { include: { skill: { select: { name: true, isCritical: true } } } } },
    });
    if (!emp) return;

    const criticalSkills = (emp.skills as any[]).filter((s: any) => s.skill?.isCritical).map((s: any) => s.skill.name);
    if (criticalSkills.length > 0) insights.push({ type: 'risk_score', severity: 'critical', title: 'Critical Skill Loss', detail: `Employee holds critical skills: ${criticalSkills.join(', ')}. Knowledge transfer plan required.`, value: `${criticalSkills.length} critical skills` });

    if (emp.dateOfJoining) {
      const years = (Date.now() - new Date(emp.dateOfJoining).getTime()) / (365 * 86_400_000);
      if (years >= 5) insights.push({ type: 'compliance', severity: 'warning', title: 'Gratuity Payable', detail: `Employee completed ${years.toFixed(1)} years — Gratuity payment required under Payment of Gratuity Act`, value: `₹${((Number(emp.ctc) / 12) * 0.4 * (15 / 26) * Math.floor(years) / 100_000).toFixed(2)}L` });
    }

    insights.push({ type: 'policy_warning', severity: 'info', title: 'Exit Checklist', detail: 'Ensure: last payslip generated, F&F settlement, Form 16 issued, PF withdrawal form, NOC letter' });
  }
}

// ═══════════════════════════════════════════════════════════════════════
// 2. EMPLOYEE LIFECYCLE TIMELINE
// ═══════════════════════════════════════════════════════════════════════

@Injectable()
export class TimelineService {
  constructor(private readonly prisma: PrismaClient) {}

  async getEmployeeTimeline(tenantId: string, employeeId: string) {
    const events: any[] = [];

    const [emp, salaryRevisions, leaveHistory, reviewHistory, promotions, auditLog, courses] = await Promise.all([
      this.prisma.employee.findFirst({ where: { id: employeeId, tenantId }, include: { designation: { select: { name: true } }, department: { select: { name: true } } } }),
      this.prisma.salaryRevision.findMany({ where: { employeeId, tenantId }, orderBy: { effectiveDate: 'desc' } }),
      this.prisma.leaveRequest.findMany({ where: { employeeId, tenantId, status: 'approved' }, orderBy: { startDate: 'desc' }, take: 20 }),
      this.prisma.performanceReview.findMany({ where: { employeeId, tenantId }, orderBy: { createdAt: 'desc' }, include: { cycle: { select: { name: true } } } }),
      this.prisma.auditLog.findMany({ where: { resourceId: employeeId, action: { in: ['employee.role_changed', 'employee.department_changed', 'employee.promoted', 'employee.confirmed'] } }, orderBy: { createdAt: 'desc' }, take: 20 }),
      this.prisma.policyAcknowledgment.findMany({ where: { employeeId, tenantId }, include: { policy: { select: { name: true } } }, orderBy: { acknowledgedAt: 'desc' } }),
      this.prisma.courseEnrollment.findMany({ where: { employeeId, tenantId }, include: { course: { select: { title: true } } }, orderBy: { enrolledAt: 'desc' }, take: 10 }),
    ]);

    if (!emp) return [];

    // Joining event
    if ((emp as any).dateOfJoining) events.push({ date: (emp as any).dateOfJoining, type: 'joined', icon: '🎉', title: 'Joined the company', detail: `${(emp.designation as any)?.name} • ${(emp.department as any)?.name}`, color: 'green' });

    // Confirmation
    if ((emp as any).probationEndDate) events.push({ date: (emp as any).probationEndDate, type: 'confirmed', icon: '✅', title: 'Confirmed Employee', detail: 'Probation period completed successfully', color: 'green' });

    // Salary revisions
    for (const rev of salaryRevisions as any[]) {
      const pct = rev.previousCTC ? ((rev.newCTC - rev.previousCTC) / rev.previousCTC * 100).toFixed(1) : null;
      events.push({ date: rev.effectiveDate, type: 'salary_change', icon: '💰', title: `Salary Revised ${pct ? `(+${pct}%)` : ''}`, detail: `₹${(rev.newCTC / 100_000).toFixed(1)}L CTC${rev.reason ? ` — ${rev.reason}` : ''}`, color: 'blue', meta: { from: rev.previousCTC, to: rev.newCTC } });
    }

    // Performance reviews
    for (const review of reviewHistory as any[]) {
      if (review.managerRating) events.push({ date: review.createdAt, type: 'performance', icon: '⭐', title: `Performance Review — ${review.cycle?.name ?? 'Annual'}`, detail: `Manager Rating: ${review.managerRating}/5${review.selfRating ? ` | Self: ${review.selfRating}/5` : ''}`, color: review.managerRating >= 4 ? 'gold' : review.managerRating >= 3 ? 'blue' : 'red', meta: { rating: review.managerRating } });
    }

    // Promotions / role changes
    for (const evt of auditLog as any[]) {
      events.push({ date: evt.createdAt, type: 'role_change', icon: '🚀', title: evt.action.replace('employee.', '').replace('_', ' ').replace(/\b\w/g, (c: string) => c.toUpperCase()), detail: JSON.stringify(evt.newData ?? {}).slice(0, 100), color: 'purple' });
    }

    // Policy acknowledgments
    for (const ack of (courses as any[]).slice(0, 5)) {
      events.push({ date: ack.completedAt ?? ack.enrolledAt, type: 'learning', icon: '📚', title: `Course ${ack.status === 'completed' ? 'Completed' : 'Enrolled'}: ${ack.course?.title}`, detail: ack.status, color: 'teal' });
    }

    // Leave snapshots (major leaves only — > 3 days)
    for (const leave of (leaveHistory as any[]).filter((l: any) => l.totalDays >= 3).slice(0, 10)) {
      events.push({ date: leave.startDate, type: 'leave', icon: '🌴', title: `${leave.totalDays}-day Leave`, detail: `${new Date(leave.startDate).toLocaleDateString('en-IN')} – ${new Date(leave.endDate).toLocaleDateString('en-IN')}`, color: 'orange' });
    }

    // Sort by date desc
    return events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }
}

// ═══════════════════════════════════════════════════════════════════════
// 3. ETHICS & BIAS DETECTION
// ═══════════════════════════════════════════════════════════════════════

@Injectable()
export class EthicsService {
  constructor(private readonly prisma: PrismaClient) {}

  async detectBias(tenantId: string): Promise<{ checks: BiasCheck[]; overallFairness: number }> {
    const [genderPayGap, promotionBias, ratingBias, hiringBias] = await Promise.all([
      this.checkGenderPayGap(tenantId),
      this.checkPromotionBias(tenantId),
      this.checkRatingBias(tenantId),
      this.checkHiringBias(tenantId),
    ]);

    const checks = [genderPayGap, promotionBias, ratingBias, hiringBias];
    const avgFairness = Math.round(checks.reduce((s, c) => s + c.fairnessScore, 0) / checks.length);

    return { checks, overallFairness: avgFairness };
  }

  private async checkGenderPayGap(tenantId: string): Promise<BiasCheck> {
    const byGender = await this.prisma.employee.groupBy({
      by: ['gender'], where: { tenantId, status: 'active', deletedAt: null, ctc: { gt: 0 } },
      _avg: { ctc: true }, _count: true,
    });

    const male = (byGender as any[]).find((g: any) => g.gender?.toLowerCase() === 'male');
    const female = (byGender as any[]).find((g: any) => g.gender?.toLowerCase() === 'female');

    let gap = 0; let detail = '';
    if (male?._avg.ctc && female?._avg.ctc) {
      gap = ((Number(male._avg.ctc) - Number(female._avg.ctc)) / Number(male._avg.ctc)) * 100;
      detail = `Male avg CTC: ₹${(Number(male._avg.ctc) / 100_000).toFixed(1)}L | Female avg CTC: ₹${(Number(female._avg.ctc) / 100_000).toFixed(1)}L | Gap: ${gap.toFixed(1)}%`;
    } else {
      detail = 'Insufficient gender data for analysis';
    }

    const fairnessScore = Math.max(0, 100 - Math.abs(gap) * 3);
    return { id: 'gender_pay_gap', name: 'Gender Pay Gap', severity: Math.abs(gap) > 15 ? 'high' : Math.abs(gap) > 8 ? 'medium' : 'low', fairnessScore: Math.round(fairnessScore), detail, recommendation: Math.abs(gap) > 8 ? 'Conduct role-normalized pay equity analysis and address disparities in next compensation cycle' : 'Pay equity within acceptable range' };
  }

  private async checkPromotionBias(tenantId: string): Promise<BiasCheck> {
    const promos = await this.prisma.salaryRevision.findMany({
      where: { tenantId, reason: { contains: 'promotion', mode: 'insensitive' }, createdAt: { gte: new Date(new Date().getFullYear(), 0, 1) } },
      include: { employee: { select: { gender: true, departmentId: true } } },
    });

    const malePromos = (promos as any[]).filter((p: any) => p.employee?.gender?.toLowerCase() === 'male').length;
    const femalePromos = (promos as any[]).filter((p: any) => p.employee?.gender?.toLowerCase() === 'female').length;
    const totalPromos = promos.length;

    const maleHeadcount = await this.prisma.employee.count({ where: { tenantId, status: 'active', gender: { equals: 'male', mode: 'insensitive' }, deletedAt: null } });
    const femaleHeadcount = await this.prisma.employee.count({ where: { tenantId, status: 'active', gender: { equals: 'female', mode: 'insensitive' }, deletedAt: null } });

    let fairnessScore = 100; let detail = `Total promotions YTD: ${totalPromos}. Male: ${malePromos}, Female: ${femalePromos}.`;
    if (maleHeadcount > 0 && femaleHeadcount > 0) {
      const maleRate = malePromos / maleHeadcount; const femaleRate = femalePromos / femaleHeadcount;
      const disparity = Math.abs(maleRate - femaleRate) / Math.max(maleRate, femaleRate) * 100;
      fairnessScore = Math.max(0, 100 - disparity);
      detail += ` Promotion rate — Male: ${(maleRate * 100).toFixed(1)}%, Female: ${(femaleRate * 100).toFixed(1)}%.`;
    }

    return { id: 'promotion_bias', name: 'Promotion Fairness', severity: fairnessScore < 70 ? 'high' : fairnessScore < 85 ? 'medium' : 'low', fairnessScore: Math.round(fairnessScore), detail, recommendation: fairnessScore < 85 ? 'Review promotion criteria — ensure objective, role-based evaluation criteria are applied equally' : 'Promotion distribution appears fair' };
  }

  private async checkRatingBias(tenantId: string): Promise<BiasCheck> {
    const avgByGender = await this.prisma.performanceReview.groupBy({
      by: ['tenantId'],
      where: { tenantId, managerRating: { not: null } },
      _avg: { managerRating: true },
    });

    // Also check same-manager rating variance
    const highVarianceManagers = await this.prisma.performanceReview.groupBy({
      by: ['reviewerId'],
      where: { tenantId, managerRating: { not: null }, createdAt: { gte: new Date(new Date().getFullYear(), 0, 1) } },
      _avg: { managerRating: true }, _count: true,
    });

    const avgAll = (avgByGender[0] as any)?._avg?.managerRating ?? 3;
    const outlierManagers = (highVarianceManagers as any[]).filter((m: any) => m._count >= 3 && (m._avg.managerRating > 4.5 || m._avg.managerRating < 2.5)).length;

    const fairnessScore = outlierManagers === 0 ? 100 : Math.max(60, 100 - outlierManagers * 10);

    return { id: 'rating_bias', name: 'Performance Rating Consistency', severity: outlierManagers >= 3 ? 'high' : outlierManagers >= 1 ? 'medium' : 'low', fairnessScore: Math.round(fairnessScore), detail: `Overall avg rating: ${avgAll.toFixed(2)}/5. Managers with extreme rating patterns (avg <2.5 or >4.5): ${outlierManagers}`, recommendation: outlierManagers > 0 ? 'Implement calibration sessions — review managers giving extreme ratings consistently' : 'Rating distribution is within normal variance' };
  }

  private async checkHiringBias(tenantId: string): Promise<BiasCheck> {
    const hiredThisYear = await this.prisma.employee.findMany({
      where: { tenantId, dateOfJoining: { gte: new Date(new Date().getFullYear(), 0, 1) }, deletedAt: null },
      select: { gender: true },
    });

    const total = hiredThisYear.length;
    if (total === 0) return { id: 'hiring_bias', name: 'Hiring Diversity', severity: 'low', fairnessScore: 100, detail: 'No hires this year yet', recommendation: '' };

    const femaleHired = (hiredThisYear as any[]).filter((e: any) => e.gender?.toLowerCase() === 'female').length;
    const femalePercent = (femaleHired / total) * 100;

    const fairnessScore = femalePercent >= 35 ? 100 : femalePercent >= 25 ? 80 : femalePercent >= 15 ? 60 : 40;

    return { id: 'hiring_bias', name: 'Hiring Diversity', severity: femalePercent < 25 ? 'high' : femalePercent < 35 ? 'medium' : 'low', fairnessScore, detail: `${total} hires YTD. Female: ${femaleHired} (${femalePercent.toFixed(1)}%) | Male: ${total - femaleHired} (${(100 - femalePercent).toFixed(1)}%)`, recommendation: femalePercent < 35 ? 'Set diversity hiring targets — consider blind screening for early-stage evaluation' : 'Hiring diversity within acceptable range' };
  }
}

interface BiasCheck { id: string; name: string; severity: 'high' | 'medium' | 'low'; fairnessScore: number; detail: string; recommendation: string }

// ═══════════════════════════════════════════════════════════════════════
// 4. PEOPLE ANALYTICS LAB
// ═══════════════════════════════════════════════════════════════════════

@Injectable()
export class PeopleAnalyticsService {
  constructor(private readonly prisma: PrismaClient) {}

  async getCorrelations(tenantId: string) {
    const [perfVsLeave, burnoutScore, managerEffectiveness] = await Promise.all([
      this.performanceVsLeave(tenantId),
      this.computeBurnoutScore(tenantId),
      this.managerEffectivenessScore(tenantId),
    ]);
    return { performanceVsLeave: perfVsLeave, burnout: burnoutScore, managerEffectiveness };
  }

  private async performanceVsLeave(tenantId: string) {
    const reviews = await this.prisma.performanceReview.findMany({
      where: { tenantId, managerRating: { not: null } },
      select: { employeeId: true, managerRating: true },
    });

    const leaveByEmp = await this.prisma.leaveRequest.groupBy({
      by: ['employeeId'], where: { tenantId, status: { in: ['approved', 'auto-approved'] }, startDate: { gte: new Date(new Date().getFullYear(), 0, 1) } },
      _sum: { totalDays: true },
    });
    const leaveMap = new Map((leaveByEmp as any[]).map((l: any) => [l.employeeId, l._sum.totalDays ?? 0]));

    const data = (reviews as any[]).map((r: any) => ({ rating: r.managerRating, leaveDays: leaveMap.get(r.employeeId) ?? 0 }));

    // Simple bucketing
    const low = data.filter(d => d.rating < 3); const med = data.filter(d => d.rating >= 3 && d.rating < 4); const high = data.filter(d => d.rating >= 4);
    const avgLeave = (arr: typeof data) => arr.length > 0 ? arr.reduce((s, d) => s + d.leaveDays, 0) / arr.length : 0;

    return { lowPerformers: { count: low.length, avgLeaveDays: Math.round(avgLeave(low)) }, medPerformers: { count: med.length, avgLeaveDays: Math.round(avgLeave(med)) }, highPerformers: { count: high.length, avgLeaveDays: Math.round(avgLeave(high)) }, insight: avgLeave(low) > avgLeave(high) ? 'Higher leave correlates with lower performance — may indicate disengagement' : 'No significant performance-leave correlation detected' };
  }

  private async computeBurnoutScore(tenantId: string) {
    const departments = await this.prisma.department.findMany({ where: { tenantId, deletedAt: null } });
    const results = [];

    for (const dept of departments as any[]) {
      const emps = await this.prisma.employee.count({ where: { tenantId, departmentId: dept.id, status: 'active', deletedAt: null } });
      if (emps === 0) continue;

      const avgOT = await this.prisma.attendance.aggregate({
        where: { tenantId, employee: { departmentId: dept.id }, date: { gte: new Date(Date.now() - 30 * 86_400_000) } },
        _avg: { overtimeHours: true },
      });

      const leaveRatio = await this.prisma.leaveRequest.count({
        where: { tenantId, employee: { departmentId: dept.id }, startDate: { gte: new Date(Date.now() - 30 * 86_400_000) } },
      });

      const otScore = Math.min(40, ((avgOT._avg.overtimeHours ?? 0) as number) * 5);
      const leaveScore = Math.min(30, (leaveRatio / emps) * 100);
      const burnout = Math.round(otScore + leaveScore);

      results.push({ departmentId: dept.id, departmentName: dept.name, burnoutScore: burnout, risk: burnout > 60 ? 'high' : burnout > 35 ? 'medium' : 'low', avgOvertimeHours: Math.round(((avgOT._avg.overtimeHours ?? 0) as number) * 10) / 10 });
    }

    return results.sort((a, b) => b.burnoutScore - a.burnoutScore);
  }

  private async managerEffectivenessScore(tenantId: string) {
    const managers = await this.prisma.employee.findMany({
      where: { tenantId, status: 'active', directReports: { some: {} }, deletedAt: null },
      include: {
        directReports: {
          where: { status: 'active', deletedAt: null },
          include: { performanceReviews: { orderBy: { createdAt: 'desc' }, take: 1, select: { managerRating: true } } },
        },
        designation: { select: { name: true } },
        department: { select: { name: true } },
      },
    });

    return (managers as any[]).map(mgr => {
      const reports = mgr.directReports;
      const avgRating = reports.length > 0 ? reports.reduce((s: number, r: any) => s + (r.performanceReviews[0]?.managerRating ?? 3), 0) / reports.length : 3;
      const teamSize = reports.length;
      const effectivenessScore = Math.round((avgRating / 5) * 70 + Math.min(30, teamSize * 3));
      return { managerId: mgr.id, managerName: `${mgr.firstName} ${mgr.lastName}`, designation: mgr.designation?.name, department: mgr.department?.name, teamSize, avgTeamRating: Math.round(avgRating * 10) / 10, effectivenessScore, level: effectivenessScore >= 80 ? 'high' : effectivenessScore >= 60 ? 'medium' : 'low' };
    }).sort((a, b) => b.effectivenessScore - a.effectivenessScore);
  }
}

// ─── Combined Controller ──────────────────────────────────────────────

@ApiTags('decision-assist')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('decision-assist')
export class DecisionAssistController {
  constructor(private readonly svc: DecisionAssistService) {}

  @Post('analyze')
  @ApiOperation({ summary: 'Pre-decision analysis — returns policy warnings, cost impact, risk score before action' })
  analyze(@Body() ctx: DecisionContext, @CurrentUser() u: JwtPayload) { return this.svc.getDecisionInsights(u.tid, ctx); }
}

@ApiTags('timeline')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('timeline')
export class TimelineController {
  constructor(private readonly svc: TimelineService) {}

  @Get('employees/:id')
  @ApiOperation({ summary: 'Employee story timeline — all changes chronologically' })
  getTimeline(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getEmployeeTimeline(u.tid, id); }

  @Get('employees/me')
  getMyTimeline(@CurrentUser() u: JwtPayload) { return this.svc.getEmployeeTimeline(u.tid, u.sub); }
}

@ApiTags('ethics')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('hr-admin', 'super-admin')
@Controller('ethics')
export class EthicsController {
  constructor(private readonly svc: EthicsService) {}

  @Get('bias-report')
  @ApiOperation({ summary: 'Bias detection across pay, promotions, ratings, and hiring' })
  getBiasReport(@CurrentUser() u: JwtPayload) { return this.svc.detectBias(u.tid); }
}

@ApiTags('analytics-lab')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('hr-admin', 'super-admin')
@Controller('analytics-lab')
export class AnalyticsLabController {
  constructor(private readonly svc: PeopleAnalyticsService) {}

  @Get('correlations')
  @ApiOperation({ summary: 'Performance vs leave, burnout scores, manager effectiveness' })
  correlations(@CurrentUser() u: JwtPayload) { return this.svc.getCorrelations(u.tid); }
}

@Module({
  controllers: [DecisionAssistController, TimelineController, EthicsController, AnalyticsLabController],
  providers: [DecisionAssistService, TimelineService, EthicsService, PeopleAnalyticsService],
  exports: [DecisionAssistService, TimelineService, EthicsService, PeopleAnalyticsService],
})
export class IntelligenceModule {}
