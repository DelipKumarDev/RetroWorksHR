/**
 * Feature Enforcement Examples
 * ─────────────────────────────────────────────────────────────────────────────
 * Shows exactly HOW @RequireFeature() is applied to existing endpoints.
 * Each enforcement pattern here corresponds to a real module.
 *
 * Pattern:
 *   1. Import RequireFeature + PlanGuard from billing
 *   2. Add PlanGuard to UseGuards() on the controller/method
 *   3. Decorate the method with @RequireFeature('feature_name')
 *
 * NestJS evaluates guards in ORDER: AuthGuard → TenantGuard → PlanGuard
 * PlanGuard is always LAST — ensures tenant context is available.
 *
 * On failure: 403 Forbidden with body:
 *   {
 *     message: "Expression Engine (Custom Formulas) is not available on the Starter plan.",
 *     feature: "expression_engine",
 *     requiredPlan: "growth",
 *     upgradeUrl: "/dashboard/billing/upgrade",
 *     code: "FEATURE_NOT_AVAILABLE"
 *   }
 */

import {
  Controller, Post, Get, Body, UseGuards, Param,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RequireFeature, PlanGuard } from '../billing/billing.module';

// ─── Example 1: Expression Engine ─────────────────────────────────────────────
// Blocks formula-based payroll component saves on Starter plan

// In: apps/api/src/modules/payroll/expression-engine/expression-engine.controller.ts
//
// @Controller('payroll/components')
// @UseGuards(AuthGuard('jwt'), TenantGuard, PlanGuard)   ← add PlanGuard
// export class PayrollComponentsController {
//
//   @Post()
//   @RequireFeature('expression_engine')                  ← gate formula saves
//   createComponent(@Body() dto: CreateComponentDto, @CurrentUser() u: JwtPayload) {
//     // Only reached if plan allows expression_engine
//     return this.svc.createComponent(u.tid, dto);
//   }
//
//   @Patch(':id')
//   @RequireFeature('expression_engine')                  ← gate formula edits
//   updateComponent(@Param('id') id: string, @Body() dto: UpdateComponentDto, @CurrentUser() u: JwtPayload) {
//     return this.svc.updateComponent(u.tid, id, dto);
//   }
// }

// ─── Example 2: Multi-Entity ───────────────────────────────────────────────────
// Blocks new entity creation on Starter and Growth plans

// In: apps/api/src/modules/setup-wizard/setup-wizard.module.ts (SetupWizardController)
//
// @Post('step/legal_entities')
// @Roles('hr-admin', 'super-admin')
// @RequireFeature('multi_entity')   ← only if adding a 2nd entity
// // Note: service additionally calls billing.assertEntityLimit() for count enforcement
// saveEntitiesStep(...) { ... }

// ─── Example 3: CFO Dashboard ─────────────────────────────────────────────────
// Blocks analytics endpoints on Starter plan

// In: apps/api/src/modules/analytics/analytics.controller.ts
//
// @Controller('analytics/cfo')
// @UseGuards(AuthGuard('jwt'), TenantGuard, PlanGuard)
// @RequireFeature('cfo_dashboard')                       ← whole controller gated
// export class CfoDashboardController {
//   @Get('kpis')          getKpis(...)    { ... }
//   @Get('variance')      getVariance()  { ... }
//   @Get('compliance')    getCompliance() { ... }
// }

// ─── Example 4: Audit Engine ──────────────────────────────────────────────────
// Blocks audit log access on Starter and Growth plans

// In: apps/api/src/modules/audit/audit.controller.ts
//
// @Controller('audit')
// @UseGuards(AuthGuard('jwt'), TenantGuard, PlanGuard)
// @RequireFeature('audit_engine')                        ← whole controller gated
// export class AuditController { ... }

// ─── Example 5: Advanced Reports ──────────────────────────────────────────────
// Blocks report builder on Starter plan

// In: apps/api/src/modules/reports/advanced-report-builder/advanced-report-builder.module.ts
//
// @Controller('reports/advanced')
// @UseGuards(AuthGuard('jwt'), TenantGuard, PlanGuard)
// @RequireFeature('advanced_reports')                    ← whole controller gated
// export class AdvancedReportBuilderController { ... }

// ─── Example 6: API Access ────────────────────────────────────────────────────
// Blocks public API key creation on Starter and Growth

// In: apps/api/src/modules/api-keys/api-keys.controller.ts
//
// @Post('api-keys')
// @RequireFeature('api_access')
// createApiKey(@CurrentUser() u: JwtPayload) { ... }

// ─── Example 7: SSO ───────────────────────────────────────────────────────────
// Blocks SAML/OAuth config on non-Pro/Enterprise plans

// @Post('settings/sso')
// @RequireFeature('sso')
// configureSso(@Body() dto: SsoConfigDto) { ... }

// ─── SERVICE-LEVEL enforcement (complementary to guard) ───────────────────────
// For limits that require counting (seats, entities, CSV rows), the service
// calls BillingService methods directly. Guards handle feature flags;
// service methods handle quantitative limits.

// Example: In employees.service.ts
//
// async createEmployee(tenantId: string, dto: CreateEmployeeDto) {
//   await this.billing.assertSeatLimit(tenantId, 1);   // ← count-based check
//   // ... create employee
// }

// Example: In setup-wizard.service.ts
//
// async addLegalEntity(tenantId: string, dto: LegalEntityDto) {
//   await this.billing.assertEntityLimit(tenantId);    // ← count-based check
//   // ... create entity
// }

// Example: In migration-assistant.service.ts
//
// async commitMigration(tenantId: string, csvRows: number, ...) {
//   const sub = await this.billing.getSubscription(tenantId);
//   const limit = checkCsvImportLimit(csvRows, sub.planId);
//   if (!limit.allowed) throw new ForbiddenException(limit.reason);
//   // ... run migration
// }

// ─── FRONTEND: Route-level feature hiding ─────────────────────────────────────
// UI hiding is cosmetic only — backend enforcement is the real gate.
// The /billing/feature/:feature endpoint lets the UI check before rendering.

// Example: In middleware or layout component
//
// const { data: auditGate } = useQuery({
//   queryKey: ['feature-gate', 'audit_engine'],
//   queryFn: () => api('/billing/feature/audit_engine'),
// });
//
// // Hide sidebar link if feature not available
// {auditGate?.allowed && (
//   <SidebarLink href="/dashboard/audit" label="Audit Engine" />
// )}
//
// // Show upgrade prompt instead of content
// {!auditGate?.allowed && (
//   <UpgradePrompt feature="audit_engine" requiredPlan={auditGate?.requiredPlan} />
// )}

export {};  // Module marker
