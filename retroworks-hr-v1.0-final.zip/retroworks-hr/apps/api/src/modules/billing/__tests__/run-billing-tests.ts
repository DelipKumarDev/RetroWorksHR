/**
 * Billing Engine — Test Suite
 * ─────────────────────────────────────────────────────────────────────────────
 * 70 tests across 9 suites:
 *
 *   A. Plan Definitions (8)       — all 4 plans, feature flags, limits
 *   B. Feature Gate — Allow (8)   — features unlocked correctly per plan
 *   C. Feature Gate — Block (10)  — features blocked + correct upgrade hint
 *   D. Seat Limits (8)            — seat gate, entity gate, CSV import limit
 *   E. Plan Change Preview (8)    — upgrade/downgrade prorated credit, lost features
 *   F. Invoice Calculation (10)   — amounts, CGST/SGST intra-state, IGST inter-state
 *   G. Grace Period & Trial (8)   — trial days, grace computation, suspension logic
 *   H. Invoice Numbering (4)      — format, sequence, uniqueness
 *   I. Enforcement Matrix (6)     — suspended/cancelled/grace blocks correct features
 */

import {
  PLANS, BILLING_POLICY, GST,
  type PlanId, type FeatureFlag,
} from '../billing.types';

import {
  checkFeature, checkSeatLimit, checkEntityLimit, checkCsvImportLimit,
  computeBillableSeats, previewPlanChange, calculateInvoiceAmount,
  computeGracePeriodEnd, isInGracePeriod, isInTrial, trialDaysRemaining,
  generateInvoiceNumber, getMinimumPlanForFeature, featureLabel, getAllPlans,
} from '../feature-gate';

// ─── Test harness ─────────────────────────────────────────────────────────────

let _pass = 0, _fail = 0;

function suite(name: string) { console.log(`\n  ── ${name} ──`); }

function it(desc: string, fn: () => void) {
  try { fn(); _pass++; console.log(`    ✅  ${desc}`); }
  catch (e: any) { _fail++; console.log(`    ❌  ${desc}\n         ${e.message}`); }
}

function expect(val: unknown) {
  return {
    toBe:           (e: unknown) => { if (val !== e) throw new Error(`Expected ${JSON.stringify(e)}, got ${JSON.stringify(val)}`); },
    toEqual:        (e: unknown) => { if (JSON.stringify(val) !== JSON.stringify(e)) throw new Error(`Expected ${JSON.stringify(e)}, got ${JSON.stringify(val)}`); },
    toBeTruthy:     () => { if (!val) throw new Error(`Expected truthy, got ${JSON.stringify(val)}`); },
    toBeFalsy:      () => { if (val) throw new Error(`Expected falsy, got ${JSON.stringify(val)}`); },
    toBeGreaterThan:(n: number) => { if ((val as number) <= n) throw new Error(`Expected > ${n}, got ${val}`); },
    toBeLessThan:   (n: number) => { if ((val as number) >= n) throw new Error(`Expected < ${n}, got ${val}`); },
    toBeGreaterThanOrEqual: (n: number) => { if ((val as number) < n) throw new Error(`Expected >= ${n}, got ${val}`); },
    toHaveLength:   (n: number) => { if ((val as any[]).length !== n) throw new Error(`Expected length ${n}, got ${(val as any[]).length}`); },
    toContain:      (s: unknown) => { if (!(val as string).includes(s as string)) throw new Error(`Expected to contain ${JSON.stringify(s)}, got ${JSON.stringify(val)}`); },
    toMatch:        (re: RegExp) => { if (!re.test(String(val))) throw new Error(`Expected ${val} to match ${re}`); },
    not: {
      toBe:     (e: unknown) => { if (val === e) throw new Error(`Expected NOT ${JSON.stringify(e)}`); },
      toBeFalsy:() => { if (!val) throw new Error(`Expected truthy`); },
      toContain:(s: unknown) => { if ((val as string).includes(s as string)) throw new Error(`Expected NOT to contain ${JSON.stringify(s)}`); },
    },
  };
}

// ════════════════════════════════════════════════════════════════════════════════
suite('A — Plan Definitions');
// ════════════════════════════════════════════════════════════════════════════════

it('A1 | All 4 plans defined', () => {
  expect(Object.keys(PLANS)).toHaveLength(4);
  (['starter','growth','pro','enterprise'] as PlanId[]).forEach(p => {
    if (!PLANS[p]) throw new Error(`Missing plan: ${p}`);
  });
});

it('A2 | Starter: maxSeats=25, no multi_entity, no expression_engine', () => {
  const p = PLANS.starter;
  expect(p.maxSeats).toBe(25);
  expect(p.features.multi_entity).toBeFalsy();
  expect(p.features.expression_engine).toBeFalsy();
});

it('A3 | Growth: has expression_engine and cfo_dashboard, no multi_entity', () => {
  const p = PLANS.growth;
  expect(p.features.expression_engine).toBeTruthy();
  expect(p.features.cfo_dashboard).toBeTruthy();
  expect(p.features.multi_entity).toBeFalsy();
});

it('A4 | Pro: has multi_entity, expression_engine, audit_engine, api_access', () => {
  const p = PLANS.pro;
  expect(p.features.multi_entity).toBeTruthy();
  expect(p.features.expression_engine).toBeTruthy();
  expect(p.features.audit_engine).toBeTruthy();
  expect(p.features.api_access).toBeTruthy();
});

it('A5 | Enterprise: all features enabled, unlimited seats', () => {
  const p = PLANS.enterprise;
  for (const [key, val] of Object.entries(p.features)) {
    if (!val) throw new Error(`Enterprise missing feature: ${key}`);
  }
  expect(p.maxSeats).toBe(null);
});

it('A6 | Annual price always less than monthly × 12 (discount applied)', () => {
  for (const [id, plan] of Object.entries(PLANS)) {
    if (plan.priceMonthly === 0) continue; // Enterprise custom
    if (plan.priceAnnual >= plan.priceMonthly * 12) {
      throw new Error(`${id}: annual price not discounted vs monthly`);
    }
  }
});

it('A7 | Enterprise has unlimited legal entities', () => {
  expect(PLANS.enterprise.limits.maxLegalEntities).toBe(null);
});

it('A8 | getAllPlans() returns 4 plans', () => {
  expect(getAllPlans()).toHaveLength(4);
});

// ════════════════════════════════════════════════════════════════════════════════
suite('B — Feature Gate: Allow');
// ════════════════════════════════════════════════════════════════════════════════

it('B1 | Growth: expression_engine allowed → allowed=true', () => {
  const r = checkFeature('expression_engine', 'growth', 'active');
  expect(r.allowed).toBeTruthy();
  expect(r.feature).toBe('expression_engine');
});

it('B2 | Pro: multi_entity allowed → allowed=true', () => {
  const r = checkFeature('multi_entity', 'pro', 'active');
  expect(r.allowed).toBeTruthy();
});

it('B3 | Enterprise: every feature allowed', () => {
  const features: FeatureFlag[] = [
    'multi_entity','expression_engine','cfo_dashboard','audit_engine',
    'advanced_reports','api_access','ai_assistant','sso','white_label',
  ];
  for (const f of features) {
    const r = checkFeature(f, 'enterprise', 'active');
    if (!r.allowed) throw new Error(`Enterprise should allow ${f}`);
  }
});

it('B4 | setup_wizard allowed on all plans', () => {
  for (const planId of ['starter','growth','pro','enterprise'] as PlanId[]) {
    const r = checkFeature('setup_wizard', planId, 'active');
    if (!r.allowed) throw new Error(`setup_wizard should be allowed on ${planId}`);
  }
});

it('B5 | Trialing tenant: feature allowed if in plan', () => {
  const r = checkFeature('expression_engine', 'growth', 'trialing');
  expect(r.allowed).toBeTruthy();
});

it('B6 | Grace period tenant: existing plan feature still allowed', () => {
  // Growth plan has expression_engine — allowed even in grace
  const r = checkFeature('expression_engine', 'growth', 'grace_period');
  expect(r.allowed).toBeTruthy();
});

it('B7 | Pro: audit_engine allowed', () => {
  const r = checkFeature('audit_engine', 'pro', 'active');
  expect(r.allowed).toBeTruthy();
  expect(r.planId).toBe('pro');
});

it('B8 | Pro: advanced_reports allowed', () => {
  const r = checkFeature('advanced_reports', 'pro', 'active');
  expect(r.allowed).toBeTruthy();
});

// ════════════════════════════════════════════════════════════════════════════════
suite('C — Feature Gate: Block');
// ════════════════════════════════════════════════════════════════════════════════

it('C1 | Starter: expression_engine blocked', () => {
  const r = checkFeature('expression_engine', 'starter', 'active');
  expect(r.allowed).toBeFalsy();
  expect(r.reason).toBeTruthy();
});

it('C2 | Starter: multi_entity blocked', () => {
  const r = checkFeature('multi_entity', 'starter', 'active');
  expect(r.allowed).toBeFalsy();
  expect(r.upgradeUrl).toBeTruthy();
});

it('C3 | Growth: multi_entity blocked with upgrade hint', () => {
  const r = checkFeature('multi_entity', 'growth', 'active');
  expect(r.allowed).toBeFalsy();
  expect(r.requiredPlan).toBe('pro');
});

it('C4 | Growth: audit_engine blocked', () => {
  const r = checkFeature('audit_engine', 'growth', 'active');
  expect(r.allowed).toBeFalsy();
  expect(r.requiredPlan).toBe('pro');
});

it('C5 | Growth: api_access blocked', () => {
  const r = checkFeature('api_access', 'growth', 'active');
  expect(r.allowed).toBeFalsy();
});

it('C6 | Pro: ai_assistant blocked (enterprise only)', () => {
  const r = checkFeature('ai_assistant', 'pro', 'active');
  expect(r.allowed).toBeFalsy();
  expect(r.requiredPlan).toBe('enterprise');
});

it('C7 | Suspended tenant: blocks feature even if in plan', () => {
  const r = checkFeature('expression_engine', 'growth', 'suspended');
  expect(r.allowed).toBeFalsy();
  expect(r.reason).toContain('suspended');
});

it('C8 | Cancelled tenant: blocks all features', () => {
  const r = checkFeature('multi_entity', 'pro', 'cancelled');
  expect(r.allowed).toBeFalsy();
  expect(r.reason).toContain('cancelled');
});

it('C9 | Expired tenant: blocks all features', () => {
  const r = checkFeature('cfo_dashboard', 'pro', 'expired');
  expect(r.allowed).toBeFalsy();
});

it('C10 | getMinimumPlanForFeature: multi_entity requires pro', () => {
  expect(getMinimumPlanForFeature('multi_entity')).toBe('pro');
});

// ════════════════════════════════════════════════════════════════════════════════
suite('D — Seat Limits');
// ════════════════════════════════════════════════════════════════════════════════

it('D1 | Starter: adding 1 seat when at limit (25) → blocked', () => {
  const r = checkSeatLimit(25, 'starter', 1);
  expect(r.allowed).toBeFalsy();
  expect(r.reason).toBeTruthy();
  expect(r.maxSeats).toBe(25);
});

it('D2 | Starter: at 24 seats, adding 1 → allowed', () => {
  const r = checkSeatLimit(24, 'starter', 1);
  expect(r.allowed).toBeTruthy();
});

it('D3 | Enterprise: no seat limit → always allowed', () => {
  const r = checkSeatLimit(9999, 'enterprise', 1000);
  expect(r.allowed).toBeTruthy();
  expect(r.maxSeats).toBe(null);
});

it('D4 | Growth: at 199 seats, adding 2 → blocked (max 200)', () => {
  const r = checkSeatLimit(199, 'growth', 2);
  expect(r.allowed).toBeFalsy();
});

it('D5 | Growth: at 199 seats, adding 1 → allowed', () => {
  const r = checkSeatLimit(199, 'growth', 1);
  expect(r.allowed).toBeTruthy();
});

it('D6 | Entity limit: starter at 1 entity → blocked', () => {
  const r = checkEntityLimit(1, 'starter');
  expect(r.allowed).toBeFalsy();
  expect(r.reason).toBeTruthy();
});

it('D7 | Entity limit: pro at 9 entities → allowed', () => {
  const r = checkEntityLimit(9, 'pro');
  expect(r.allowed).toBeTruthy();
});

it('D8 | CSV import: starter limit 500 rows — 600 rows → blocked', () => {
  const r = checkCsvImportLimit(600, 'starter');
  expect(r.allowed).toBeFalsy();
  expect(r.reason).toBeTruthy();
});

// ════════════════════════════════════════════════════════════════════════════════
suite('E — Plan Change Preview');
// ════════════════════════════════════════════════════════════════════════════════

it('E1 | Upgrade starter→pro: isUpgrade=true, effectiveDate=today', () => {
  const p = previewPlanChange('starter','pro','monthly','monthly',10, 15, 30);
  expect(p.isUpgrade).toBeTruthy();
  expect(p.isDowngrade).toBeFalsy();
  expect(p.effectiveDate).toBeTruthy();
});

it('E2 | Downgrade pro→growth: isDowngrade=true, lostFeatures includes multi_entity', () => {
  const p = previewPlanChange('pro','growth','monthly','monthly',50, 15, 30);
  expect(p.isDowngrade).toBeTruthy();
  expect(p.lostFeatures).toContain('multi_entity');
  expect(p.lostFeatures).toContain('audit_engine');
});

it('E3 | Downgrade mid-cycle: prorated credit > 0', () => {
  const p = previewPlanChange('pro','growth','monthly','monthly',50, 15, 30);
  expect(p.proratedCredit).toBeGreaterThan(0);
});

it('E4 | Upgrade: no prorated credit', () => {
  const p = previewPlanChange('starter','growth','monthly','monthly',10, 15, 30);
  expect(p.proratedCredit).toBe(0);
});

it('E5 | Same plan: isUpgrade=false, isDowngrade=false', () => {
  const p = previewPlanChange('pro','pro','monthly','monthly',50, 15, 30);
  expect(p.isUpgrade).toBeFalsy();
  expect(p.isDowngrade).toBeFalsy();
});

it('E6 | Monthly→Annual cycle change counted as upgrade', () => {
  const p = previewPlanChange('growth','growth','monthly','annual',50, 15, 30);
  // Same plan, different cycle — not up/downgrade by plan rank
  expect(p.currentCycle).toBe('monthly');
  expect(p.targetCycle).toBe('annual');
});

it('E7 | New monthly cost = targetPlan.priceMonthly × seats', () => {
  const p = previewPlanChange('starter','growth','monthly','monthly',10, 15, 30);
  const expected = PLANS.growth.priceMonthly * 10;
  expect(p.newMonthlyCost).toBe(expected);
});

it('E8 | Downgrade with seats exceeding new plan max → requiredSeatAdjustment', () => {
  // Starter max is 25, current seats 30 → need to reduce by 5
  const p = previewPlanChange('growth','starter','monthly','monthly',30, 15, 30);
  expect(p.requiredSeatAdjustment).toBe(5);
});

// ════════════════════════════════════════════════════════════════════════════════
suite('F — Invoice Calculation');
// ════════════════════════════════════════════════════════════════════════════════

it('F1 | Intra-state (MH→MH): CGST 9% + SGST 9%, IGST 0', () => {
  const r = calculateInvoiceAmount(10, 'growth', 'monthly', 'MH', 'MH');
  expect(r.cgstRate).toBe(9);
  expect(r.sgstRate).toBe(9);
  expect(r.igstRate).toBe(0);
  expect(r.igstAmount).toBe(0);
  expect(r.isInterState).toBeFalsy();
});

it('F2 | Inter-state (MH→KA): IGST 18%, CGST and SGST 0', () => {
  const r = calculateInvoiceAmount(10, 'growth', 'monthly', 'MH', 'KA');
  expect(r.igstRate).toBe(18);
  expect(r.cgstAmount).toBe(0);
  expect(r.sgstAmount).toBe(0);
  expect(r.isInterState).toBeTruthy();
});

it('F3 | Subtotal = seats × priceMonthly', () => {
  const r = calculateInvoiceAmount(5, 'growth', 'monthly', 'MH', 'MH');
  expect(r.subtotal).toBe(5 * PLANS.growth.priceMonthly);
});

it('F4 | Annual billing: subtotal = seats × priceAnnual', () => {
  const r = calculateInvoiceAmount(5, 'pro', 'annual', 'MH', 'MH');
  expect(r.subtotal).toBe(5 * PLANS.pro.priceAnnual);
});

it('F5 | Total = subtotal + totalTax', () => {
  const r = calculateInvoiceAmount(10, 'pro', 'monthly', 'MH', 'MH');
  expect(r.totalAmount).toBe(r.subtotal + r.totalTax);
});

it('F6 | Intra-state: CGST + SGST = 18% of subtotal', () => {
  const r = calculateInvoiceAmount(10, 'growth', 'monthly', 'MH', 'MH');
  const expectedTax = Math.round(r.subtotal * 0.18);
  expect(r.totalTax).toBe(expectedTax);
});

it('F7 | Inter-state: IGST = 18% of subtotal', () => {
  const r = calculateInvoiceAmount(10, 'growth', 'monthly', 'MH', 'DL');
  const expectedIgst = Math.round(r.subtotal * 0.18);
  expect(r.igstAmount).toBe(expectedIgst);
  expect(r.totalTax).toBe(expectedIgst);
});

it('F8 | Custom price per seat overrides plan price', () => {
  const r = calculateInvoiceAmount(10, 'enterprise', 'monthly', 'MH', 'MH', 999);
  expect(r.subtotal).toBe(10 * 999);
});

it('F9 | Zero seats: subtotal=0, tax=0', () => {
  const r = calculateInvoiceAmount(0, 'growth', 'monthly', 'MH', 'MH');
  expect(r.subtotal).toBe(0);
  expect(r.totalTax).toBe(0);
  expect(r.totalAmount).toBe(0);
});

it('F10 | Tax amounts are integers (no fractional paise)', () => {
  const r = calculateInvoiceAmount(7, 'growth', 'monthly', 'MH', 'MH');
  expect(Number.isInteger(r.cgstAmount)).toBeTruthy();
  expect(Number.isInteger(r.sgstAmount)).toBeTruthy();
});

// ════════════════════════════════════════════════════════════════════════════════
suite('G — Grace Period & Trial');
// ════════════════════════════════════════════════════════════════════════════════

it('G1 | computeGracePeriodEnd: 7 days from payment failure', () => {
  const failedAt = new Date('2024-06-01T00:00:00Z');
  const graceEnd = computeGracePeriodEnd(failedAt);
  const diffDays = Math.round((graceEnd.getTime() - failedAt.getTime()) / 86400_000);
  expect(diffDays).toBe(BILLING_POLICY.GRACE_PERIOD_DAYS);
});

it('G2 | isInGracePeriod: future date → true', () => {
  const future = new Date(Date.now() + 3 * 86400_000);
  expect(isInGracePeriod(future)).toBeTruthy();
});

it('G3 | isInGracePeriod: past date → false', () => {
  const past = new Date(Date.now() - 86400_000);
  expect(isInGracePeriod(past)).toBeFalsy();
});

it('G4 | isInGracePeriod: null → false', () => {
  expect(isInGracePeriod(null)).toBeFalsy();
});

it('G5 | isInTrial: future trial end → true', () => {
  const future = new Date(Date.now() + 5 * 86400_000);
  expect(isInTrial(future)).toBeTruthy();
});

it('G6 | isInTrial: expired trial → false', () => {
  const past = new Date(Date.now() - 86400_000);
  expect(isInTrial(past)).toBeFalsy();
});

it('G7 | trialDaysRemaining: 5 days left', () => {
  const trialEnd = new Date(Date.now() + 5 * 86400_000);
  const days = trialDaysRemaining(trialEnd);
  // ceil means result is 5 when exactly at boundary
  expect(days).toBeGreaterThanOrEqual(4);
  expect(days).toBeLessThan(7);
});

it('G8 | trialDaysRemaining: expired → 0 (not negative)', () => {
  const past = new Date(Date.now() - 86400_000);
  expect(trialDaysRemaining(past)).toBe(0);
});

// ════════════════════════════════════════════════════════════════════════════════
suite('H — Invoice Numbering');
// ════════════════════════════════════════════════════════════════════════════════

it('H1 | Format: INV-YYYY-MM-NNNN', () => {
  const n = generateInvoiceNumber(2024, 6, 1);
  expect(n).toMatch(/^INV-\d{4}-\d{2}-\d{4}$/);
  expect(n).toBe('INV-2024-06-0001');
});

it('H2 | Month padded to 2 digits', () => {
  const n = generateInvoiceNumber(2024, 1, 1);
  expect(n).toBe('INV-2024-01-0001');
});

it('H3 | Sequence padded to 4 digits', () => {
  const n = generateInvoiceNumber(2024, 12, 42);
  expect(n).toBe('INV-2024-12-0042');
});

it('H4 | Different months produce different invoice numbers', () => {
  const n1 = generateInvoiceNumber(2024, 6, 1);
  const n2 = generateInvoiceNumber(2024, 7, 1);
  expect(n1).not.toBe(n2);
});

// ════════════════════════════════════════════════════════════════════════════════
suite('I — Enforcement Matrix');
// ════════════════════════════════════════════════════════════════════════════════

it('I1 | Suspended pro tenant: audit_engine blocked despite plan', () => {
  const r = checkFeature('audit_engine', 'pro', 'suspended');
  expect(r.allowed).toBeFalsy();
  expect(r.upgradeUrl).toContain('billing');
});

it('I2 | Cancelled growth tenant: expression_engine blocked', () => {
  const r = checkFeature('expression_engine', 'growth', 'cancelled');
  expect(r.allowed).toBeFalsy();
});

it('I3 | Grace period growth: feature NOT in plan is still blocked', () => {
  // multi_entity is NOT in growth plan
  const r = checkFeature('multi_entity', 'growth', 'grace_period');
  expect(r.allowed).toBeFalsy();
});

it('I4 | featureLabel returns human-readable string', () => {
  expect(featureLabel('expression_engine')).toBe('Expression Engine (Custom Formulas)');
  expect(featureLabel('multi_entity')).toBe('Multi-Entity Support');
  expect(featureLabel('cfo_dashboard')).toBe('CFO Analytics Dashboard');
});

it('I5 | computeBillableSeats: only payrollEmployees are billed', () => {
  const breakdown = {
    tenantId: 't1',
    payrollEmployees: 42,
    nonPayrollEmployees: 10,
    contractorCount: 5,
    totalHeadcount: 57,
    byEntity: [],
    billableSeats: 42,
    computedAt: new Date(),
  };
  expect(computeBillableSeats(breakdown)).toBe(42);
});

it('I6 | GST constants are correct for India', () => {
  expect(GST.CGST_RATE).toBe(9);
  expect(GST.SGST_RATE).toBe(9);
  expect(GST.IGST_RATE).toBe(18);
  expect(GST.SAC_CODE).toBe('998313');
  expect(GST.CGST_RATE + GST.SGST_RATE).toBe(GST.IGST_RATE);
});

// ─── Results ──────────────────────────────────────────────────────────────────

const total = _pass + _fail;
console.log('\n' + '═'.repeat(65));
console.log(`  BILLING ENGINE RESULTS: ${_pass} passed / ${_fail} failed / ${total} total`);
console.log('═'.repeat(65));
if (_pass === total) {
  console.log('  ✅ ALL TESTS PASSING — Billing Engine PRODUCTION READY');
  console.log('  📐 Plans(8) · Allow(8) · Block(10) · Seats(8) · Preview(8)');
  console.log('       Invoice(10) · Grace(8) · Numbers(4) · Enforcement(6)');
  console.log('  💳 4 plans · 17 feature flags · GST-compliant · Razorpay/Stripe');
} else {
  console.log(`  ❌ ${_fail} FAILED`);
  process.exit(1);
}
