/**
 * Billing Engine — Type Definitions
 * ─────────────────────────────────────────────────────────────────────────────
 * Single source of truth for all plan, feature gate, seat count,
 * invoice, and payment domain types.
 */

// ─── PLAN DEFINITIONS ─────────────────────────────────────────────────────────

export type PlanId = 'starter' | 'growth' | 'pro' | 'enterprise';
export type BillingCycle = 'monthly' | 'annual';
export type SubscriptionStatus =
  | 'trialing'
  | 'active'
  | 'past_due'
  | 'grace_period'
  | 'suspended'
  | 'cancelled'
  | 'expired';

// Every feature that can be gated
export type FeatureFlag =
  | 'multi_entity'          // Multiple legal entities
  | 'expression_engine'     // Formula-based payroll components
  | 'cfo_dashboard'         // CFO analytics dashboard
  | 'audit_engine'          // Audit mode + compliance reports
  | 'advanced_reports'      // Drag-drop report builder
  | 'education_mode'        // School/education specific features
  | 'api_access'            // REST API + webhook access
  | 'setup_wizard'          // Onboarding wizard
  | 'ats_module'            // Applicant tracking
  | 'performance_module'    // Performance reviews
  | 'case_engine'           // HR helpdesk / case management
  | 'backup_module'         // Automated backups
  | 'ai_assistant'          // AI-powered features
  | 'custom_roles'          // Custom RBAC roles
  | 'sso'                   // SAML/OAuth SSO
  | 'dedicated_support'     // Priority support SLA
  | 'white_label';          // White-label / custom branding

export interface PlanConfig {
  id: PlanId;
  name: string;
  tagline: string;
  color: string;            // Tailwind color for UI
  priceMonthly: number;     // ₹ per payroll-employee per month
  priceAnnual: number;      // ₹ per payroll-employee per year (discounted)
  minSeats: number;
  maxSeats: number | null;  // null = unlimited
  trialDays: number;
  features: Record<FeatureFlag, boolean>;
  limits: PlanLimits;
  popular?: boolean;
}

export interface PlanLimits {
  maxLegalEntities: number | null;
  maxPayrollComponents: number;
  maxLeaveTypes: number;
  maxCustomRoles: number;
  maxApiCalls: number | null;   // per month, null = unlimited
  maxCsvImportRows: number;
  dataRetentionMonths: number;
  supportSla: 'community' | '48h' | '24h' | '4h' | 'dedicated';
}

// ─── ALL PLANS ────────────────────────────────────────────────────────────────

export const PLANS: Record<PlanId, PlanConfig> = {

  starter: {
    id: 'starter',
    name: 'Starter',
    tagline: 'For small teams getting started',
    color: 'slate',
    priceMonthly: 149,    // ₹149/employee/month
    priceAnnual: 1190,    // ₹1190/employee/year (save 33%)
    minSeats: 1,
    maxSeats: 25,
    trialDays: 14,
    features: {
      multi_entity:       false,
      expression_engine:  false,
      cfo_dashboard:      false,
      audit_engine:       false,
      advanced_reports:   false,
      education_mode:     false,
      api_access:         false,
      setup_wizard:       true,
      ats_module:         false,
      performance_module: false,
      case_engine:        false,
      backup_module:      false,
      ai_assistant:       false,
      custom_roles:       false,
      sso:                false,
      dedicated_support:  false,
      white_label:        false,
    },
    limits: {
      maxLegalEntities:   1,
      maxPayrollComponents: 10,
      maxLeaveTypes:      8,
      maxCustomRoles:     0,
      maxApiCalls:        null,
      maxCsvImportRows:   500,
      dataRetentionMonths: 12,
      supportSla:         'community',
    },
  },

  growth: {
    id: 'growth',
    name: 'Growth',
    tagline: 'For growing companies with payroll complexity',
    color: 'blue',
    priceMonthly: 249,
    priceAnnual: 1990,
    minSeats: 10,
    maxSeats: 200,
    trialDays: 14,
    popular: true,
    features: {
      multi_entity:       false,
      expression_engine:  true,
      cfo_dashboard:      true,
      audit_engine:       false,
      advanced_reports:   true,
      education_mode:     true,
      api_access:         false,
      setup_wizard:       true,
      ats_module:         true,
      performance_module: true,
      case_engine:        false,
      backup_module:      true,
      ai_assistant:       false,
      custom_roles:       true,
      sso:                false,
      dedicated_support:  false,
      white_label:        false,
    },
    limits: {
      maxLegalEntities:   1,
      maxPayrollComponents: 30,
      maxLeaveTypes:      20,
      maxCustomRoles:     5,
      maxApiCalls:        10_000,
      maxCsvImportRows:   5_000,
      dataRetentionMonths: 36,
      supportSla:         '48h',
    },
  },

  pro: {
    id: 'pro',
    name: 'Pro',
    tagline: 'For multi-entity organisations with compliance needs',
    color: 'violet',
    priceMonthly: 399,
    priceAnnual: 3190,
    minSeats: 25,
    maxSeats: 1000,
    trialDays: 14,
    features: {
      multi_entity:       true,
      expression_engine:  true,
      cfo_dashboard:      true,
      audit_engine:       true,
      advanced_reports:   true,
      education_mode:     true,
      api_access:         true,
      setup_wizard:       true,
      ats_module:         true,
      performance_module: true,
      case_engine:        true,
      backup_module:      true,
      ai_assistant:       false,
      custom_roles:       true,
      sso:                true,
      dedicated_support:  false,
      white_label:        false,
    },
    limits: {
      maxLegalEntities:   10,
      maxPayrollComponents: 100,
      maxLeaveTypes:      50,
      maxCustomRoles:     20,
      maxApiCalls:        100_000,
      maxCsvImportRows:   50_000,
      dataRetentionMonths: 84,     // 7 years
      supportSla:         '24h',
    },
  },

  enterprise: {
    id: 'enterprise',
    name: 'Enterprise',
    tagline: 'Unlimited scale, dedicated support, white-label',
    color: 'amber',
    priceMonthly: 0,   // Custom pricing
    priceAnnual: 0,
    minSeats: 100,
    maxSeats: null,
    trialDays: 30,
    features: {
      multi_entity:       true,
      expression_engine:  true,
      cfo_dashboard:      true,
      audit_engine:       true,
      advanced_reports:   true,
      education_mode:     true,
      api_access:         true,
      setup_wizard:       true,
      ats_module:         true,
      performance_module: true,
      case_engine:        true,
      backup_module:      true,
      ai_assistant:       true,
      custom_roles:       true,
      sso:                true,
      dedicated_support:  true,
      white_label:        true,
    },
    limits: {
      maxLegalEntities:   null,
      maxPayrollComponents: 500,
      maxLeaveTypes:      200,
      maxCustomRoles:     100,
      maxApiCalls:        null,
      maxCsvImportRows:   500_000,
      dataRetentionMonths: 120,    // 10 years
      supportSla:         'dedicated',
    },
  },
};

// ─── SUBSCRIPTION ─────────────────────────────────────────────────────────────

export interface Subscription {
  id: string;
  tenantId: string;
  planId: PlanId;
  status: SubscriptionStatus;
  cycle: BillingCycle;
  payrollSeats: number;       // Billed seats (active payroll employees)
  currentPeriodStart: Date;
  currentPeriodEnd: Date;
  trialStart?: Date;
  trialEnd?: Date;
  gracePeriodEnd?: Date;      // 7-day grace after payment failure
  cancelledAt?: Date;
  cancelAtPeriodEnd: boolean;
  // Payment gateway
  gateway: 'razorpay' | 'stripe' | 'manual';
  gatewaySubscriptionId?: string;
  gatewayCustomerId?: string;
  // Overrides (enterprise custom)
  customPricePerSeat?: number;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

// ─── SEAT COUNTS ──────────────────────────────────────────────────────────────

export interface SeatBreakdown {
  tenantId: string;
  // Billable
  payrollEmployees: number;      // Active employees in payroll groups → BILLED
  // Non-billable (tracked, not billed)
  nonPayrollEmployees: number;   // Active employees NOT in payroll (e.g. interns, volunteers)
  contractorCount: number;       // Workers with employmentType = 'contract'
  // Multi-entity
  totalHeadcount: number;        // Sum across all entities
  byEntity: Array<{ entityId: string; entityName: string; count: number }>;
  // Computed
  billableSeats: number;         // = payrollEmployees (what invoice is based on)
  computedAt: Date;
}

// ─── INVOICE ──────────────────────────────────────────────────────────────────

export type InvoiceStatus = 'draft' | 'open' | 'paid' | 'void' | 'uncollectible';

export interface InvoiceLineItem {
  description: string;
  quantity: number;
  unitPrice: number;    // ₹ paise → stored as integer, displayed as ₹ x.xx
  amount: number;       // quantity * unitPrice
  taxRate?: number;     // GST %
  taxAmount?: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;    // Format: INV-YYYY-MM-NNNN
  tenantId: string;
  subscriptionId: string;
  status: InvoiceStatus;
  // Billing period
  periodStart: Date;
  periodEnd: Date;
  // Amounts (all in ₹ paise / smallest unit)
  subtotal: number;
  discountAmount: number;
  taxableAmount: number;
  cgstRate: number;         // 9% (intra-state)
  sgstRate: number;         // 9% (intra-state)
  igstRate: number;         // 18% (inter-state)
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  totalTax: number;
  totalAmount: number;
  amountDue: number;        // After any credits
  amountPaid: number;
  // GST compliance fields
  supplierGstin?: string;
  customerGstin?: string;
  placeOfSupply: string;    // State code
  isInterState: boolean;
  // Payment
  lineItems: InvoiceLineItem[];
  dueDate: Date;
  paidAt?: Date;
  gatewayPaymentId?: string;
  // Meta
  notes?: string;
  createdAt: Date;
}

// ─── PAYMENT EVENTS ───────────────────────────────────────────────────────────

export type PaymentEventType =
  | 'payment.success'
  | 'payment.failed'
  | 'subscription.created'
  | 'subscription.updated'
  | 'subscription.cancelled'
  | 'subscription.renewed'
  | 'trial.started'
  | 'trial.ending'         // 3-day warning
  | 'trial.ended'
  | 'grace.started'
  | 'grace.ending'         // 1-day warning
  | 'grace.ended'          // → suspend features
  | 'invoice.created'
  | 'invoice.paid'
  | 'invoice.overdue';

export interface PaymentEvent {
  id: string;
  tenantId: string;
  subscriptionId: string;
  type: PaymentEventType;
  gateway: string;
  gatewayEventId?: string;
  amount?: number;
  currency?: string;
  metadata?: Record<string, unknown>;
  processedAt: Date;
  createdAt: Date;
}

// ─── FEATURE GATE RESULT ──────────────────────────────────────────────────────

export interface FeatureGateResult {
  allowed: boolean;
  feature: FeatureFlag;
  planId: PlanId;
  reason?: string;
  upgradeUrl?: string;
  requiredPlan?: PlanId;
}

// ─── UPGRADE / DOWNGRADE ──────────────────────────────────────────────────────

export interface PlanChangePreview {
  currentPlan: PlanId;
  targetPlan: PlanId;
  currentCycle: BillingCycle;
  targetCycle: BillingCycle;
  effectiveDate: Date;
  isUpgrade: boolean;
  isDowngrade: boolean;
  proratedCredit: number;     // ₹ credited if downgrading mid-cycle
  newMonthlyCost: number;
  lostFeatures: FeatureFlag[];
  requiredSeatAdjustment?: number;  // If downgrading and current seats > new plan max
}

// ─── GST CONSTANTS ────────────────────────────────────────────────────────────

export const GST = {
  CGST_RATE: 9,    // %
  SGST_RATE: 9,    // % (same state)
  IGST_RATE: 18,   // % (different state / union territory)
  SUPPLIER_STATE: 'MH',   // Retroworks registered in Maharashtra
  SAC_CODE: '998313',     // Software as a Service
} as const;

// ─── GRACE PERIOD ─────────────────────────────────────────────────────────────

export const BILLING_POLICY = {
  GRACE_PERIOD_DAYS:    7,     // Days after payment failure before suspension
  TRIAL_REMINDER_DAYS:  3,     // Send reminder when trial has N days left
  GRACE_REMINDER_DAYS:  1,     // Send reminder when grace has N day left
  SEAT_BUFFER_PCT:      0,     // % over-seat allowed (0 = hard limit)
  INVOICE_DUE_DAYS:     15,    // Payment due N days after invoice date
  ANNUAL_DISCOUNT_PCT:  20,    // % discount for annual billing vs monthly * 12
} as const;
