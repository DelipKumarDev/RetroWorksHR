/**
 * Feature Gate Engine
 * ─────────────────────────────────────────────────────────────────────────────
 * Pure functions — no NestJS deps — usable in guards, services, and tests.
 *
 * Enforcement model:
 *   1. Load subscription from DB (service layer)
 *   2. Call checkFeature() → FeatureGateResult
 *   3. If !allowed → throw ForbiddenException with upgrade URL
 *
 * Every feature check is enforced server-side. UI hiding is cosmetic only.
 */

import {
  PLANS, BILLING_POLICY,
  type PlanId, type FeatureFlag, type FeatureGateResult,
  type PlanConfig, type Subscription, type SeatBreakdown,
  type PlanChangePreview, type BillingCycle,
} from './billing.types';

// ─── Core gate check ──────────────────────────────────────────────────────────

export function checkFeature(
  feature: FeatureFlag,
  planId: PlanId,
  status: string,
): FeatureGateResult {
  const plan = PLANS[planId];

  // Suspended / cancelled tenants → block all gated features
  if (status === 'suspended' || status === 'cancelled' || status === 'expired') {
    return {
      allowed: false,
      feature,
      planId,
      reason: `Subscription is ${status}. Please renew to access this feature.`,
      upgradeUrl: '/dashboard/billing',
    };
  }

  // Grace period → allow existing features, block new upgrades
  if (status === 'grace_period') {
    const isBasicFeature = !plan.features[feature]; // If not even in current plan, definitely blocked
    if (isBasicFeature) {
      return {
        allowed: false,
        feature,
        planId,
        reason: 'Payment required. Account in grace period — please update payment details.',
        upgradeUrl: '/dashboard/billing',
      };
    }
    // If already on plan — let them continue during grace
  }

  const allowed = plan.features[feature] === true;

  if (!allowed) {
    const requiredPlan = getMinimumPlanForFeature(feature);
    return {
      allowed: false,
      feature,
      planId,
      reason: `${featureLabel(feature)} is not available on the ${plan.name} plan.`,
      upgradeUrl: '/dashboard/billing/upgrade',
      requiredPlan,
    };
  }

  return { allowed: true, feature, planId };
}

// ─── Seat gate ────────────────────────────────────────────────────────────────

export function checkSeatLimit(
  currentSeats: number,
  planId: PlanId,
  pendingAdditions: number = 1,
): { allowed: boolean; reason?: string; maxSeats: number | null } {
  const plan = PLANS[planId];
  const maxSeats = plan.maxSeats;                    // top-level field, not limits.maxSeats
  if (maxSeats === null) return { allowed: true, maxSeats: null };

  const projectedSeats = currentSeats + pendingAdditions;
  if (projectedSeats > maxSeats) {
    return {
      allowed: false,
      maxSeats,
      reason: `This action would exceed your plan's seat limit of ${maxSeats}. Please upgrade to add more employees.`,
    };
  }
  return { allowed: true, maxSeats };
}

export function checkEntityLimit(
  currentEntities: number,
  planId: PlanId,
): { allowed: boolean; reason?: string } {
  const plan = PLANS[planId];
  const max = plan.limits.maxLegalEntities;
  if (max === null) return { allowed: true };
  if (currentEntities >= max) {
    return {
      allowed: false,
      reason: `Your plan allows a maximum of ${max} legal entity(ies). Upgrade to Pro or Enterprise for multi-entity support.`,
    };
  }
  return { allowed: true };
}

export function checkCsvImportLimit(
  rowCount: number,
  planId: PlanId,
): { allowed: boolean; reason?: string } {
  const plan = PLANS[planId];
  const max = plan.limits.maxCsvImportRows;
  if (rowCount > max) {
    return {
      allowed: false,
      reason: `Import contains ${rowCount.toLocaleString()} rows. Your plan allows ${max.toLocaleString()} rows per import.`,
    };
  }
  return { allowed: true };
}

// ─── Plan lookup ──────────────────────────────────────────────────────────────

export function getMinimumPlanForFeature(feature: FeatureFlag): PlanId {
  const order: PlanId[] = ['starter', 'growth', 'pro', 'enterprise'];
  for (const planId of order) {
    if (PLANS[planId].features[feature]) return planId;
  }
  return 'enterprise';
}

export function getPlanConfig(planId: PlanId): PlanConfig {
  return PLANS[planId];
}

export function getAllPlans(): PlanConfig[] {
  return Object.values(PLANS);
}

// ─── Seat counting ────────────────────────────────────────────────────────────

export function computeBillableSeats(breakdown: SeatBreakdown): number {
  // Only payroll employees are billed.
  // Contractors, non-payroll staff, interns → tracked but not billed.
  return breakdown.payrollEmployees;
}

// ─── Plan change preview ──────────────────────────────────────────────────────

export function previewPlanChange(
  currentPlanId: PlanId,
  targetPlanId: PlanId,
  currentCycle: BillingCycle,
  targetCycle: BillingCycle,
  currentSeats: number,
  daysRemainingInCycle: number,
  totalDaysInCycle: number,
): PlanChangePreview {
  const currentPlan = PLANS[currentPlanId];
  const targetPlan = PLANS[targetPlanId];

  const planOrder: PlanId[] = ['starter', 'growth', 'pro', 'enterprise'];
  const currentRank = planOrder.indexOf(currentPlanId);
  const targetRank  = planOrder.indexOf(targetPlanId);

  const isUpgrade   = targetRank > currentRank;
  const isDowngrade = targetRank < currentRank;

  // Prorated credit on downgrade
  let proratedCredit = 0;
  if (isDowngrade && daysRemainingInCycle > 0 && totalDaysInCycle > 0) {
    const dailyRate = (currentCycle === 'annual' ? currentPlan.priceAnnual : currentPlan.priceMonthly * 12) / 365;
    proratedCredit = Math.round(dailyRate * currentSeats * daysRemainingInCycle);
  }

  // Lost features on downgrade
  const lostFeatures: FeatureFlag[] = [];
  if (isDowngrade) {
    for (const [feat, enabled] of Object.entries(currentPlan.features)) {
      if (enabled && !targetPlan.features[feat as FeatureFlag]) {
        lostFeatures.push(feat as FeatureFlag);
      }
    }
  }

  const targetPrice = targetCycle === 'annual' ? targetPlan.priceAnnual / 12 : targetPlan.priceMonthly;
  const newMonthlyCost = targetPrice * currentSeats;

  // Seat adjustment needed if current seats exceed new plan max
  const requiredSeatAdjustment =
    targetPlan.maxSeats !== null && currentSeats > targetPlan.maxSeats
      ? currentSeats - targetPlan.maxSeats
      : undefined;

  return {
    currentPlan: currentPlanId,
    targetPlan: targetPlanId,
    currentCycle,
    targetCycle,
    effectiveDate: isUpgrade ? new Date() : new Date(Date.now() + daysRemainingInCycle * 86400_000),
    isUpgrade,
    isDowngrade,
    proratedCredit,
    newMonthlyCost,
    lostFeatures,
    requiredSeatAdjustment,
  };
}

// ─── Invoice amount calculation ────────────────────────────────────────────────

export function calculateInvoiceAmount(
  seats: number,
  planId: PlanId,
  cycle: BillingCycle,
  supplierState: string,
  customerState: string,
  customPricePerSeat?: number,
): {
  subtotal: number;
  isInterState: boolean;
  cgstRate: number; cgstAmount: number;
  sgstRate: number; sgstAmount: number;
  igstRate: number; igstAmount: number;
  totalTax: number;
  totalAmount: number;
} {
  const plan = PLANS[planId];
  const pricePerSeat = customPricePerSeat
    ?? (cycle === 'annual' ? plan.priceAnnual : plan.priceMonthly);

  const subtotal = seats * pricePerSeat;
  const isInterState = supplierState.toUpperCase() !== customerState.toUpperCase();

  let cgstRate = 0, sgstRate = 0, igstRate = 0;
  let cgstAmount = 0, sgstAmount = 0, igstAmount = 0;

  if (isInterState) {
    igstRate = 18;
    igstAmount = Math.round(subtotal * igstRate / 100);
  } else {
    cgstRate = 9;
    sgstRate = 9;
    cgstAmount = Math.round(subtotal * cgstRate / 100);
    sgstAmount = Math.round(subtotal * sgstRate / 100);
  }

  const totalTax = cgstAmount + sgstAmount + igstAmount;
  const totalAmount = subtotal + totalTax;

  return {
    subtotal, isInterState,
    cgstRate, cgstAmount,
    sgstRate, sgstAmount,
    igstRate, igstAmount,
    totalTax, totalAmount,
  };
}

// ─── Grace period ─────────────────────────────────────────────────────────────

export function isInGracePeriod(gracePeriodEnd: Date | null | undefined): boolean {
  if (!gracePeriodEnd) return false;
  return new Date() <= gracePeriodEnd;
}

export function computeGracePeriodEnd(paymentFailedAt: Date): Date {
  const end = new Date(paymentFailedAt);
  end.setDate(end.getDate() + BILLING_POLICY.GRACE_PERIOD_DAYS);
  return end;
}

// ─── Trial ────────────────────────────────────────────────────────────────────

export function isInTrial(trialEnd: Date | null | undefined): boolean {
  if (!trialEnd) return false;
  return new Date() <= trialEnd;
}

export function trialDaysRemaining(trialEnd: Date): number {
  return Math.max(0, Math.ceil((trialEnd.getTime() - Date.now()) / 86400_000));
}

// ─── Invoice number generator ─────────────────────────────────────────────────

export function generateInvoiceNumber(year: number, month: number, seq: number): string {
  const mm = String(month).padStart(2, '0');
  const seqStr = String(seq).padStart(4, '0');
  return `INV-${year}-${mm}-${seqStr}`;
}

// ─── Human-readable feature labels ────────────────────────────────────────────

export function featureLabel(feature: FeatureFlag): string {
  const labels: Record<FeatureFlag, string> = {
    multi_entity:       'Multi-Entity Support',
    expression_engine:  'Expression Engine (Custom Formulas)',
    cfo_dashboard:      'CFO Analytics Dashboard',
    audit_engine:       'Audit Engine & Compliance Reports',
    advanced_reports:   'Advanced Report Builder',
    education_mode:     'Education Mode',
    api_access:         'API & Webhook Access',
    setup_wizard:       'Setup Wizard',
    ats_module:         'Applicant Tracking (ATS)',
    performance_module: 'Performance Management',
    case_engine:        'HR Case Engine',
    backup_module:      'Automated Backups',
    ai_assistant:       'AI Assistant',
    custom_roles:       'Custom RBAC Roles',
    sso:                'Single Sign-On (SSO)',
    dedicated_support:  'Dedicated Support',
    white_label:        'White-Label Branding',
  };
  return labels[feature] ?? feature;
}

export function planLabel(planId: PlanId): string {
  return PLANS[planId].name;
}
