/**
 * Billing Engine — NestJS Service + Feature Guard + Controller + Module
 * ─────────────────────────────────────────────────────────────────────────────
 * Covers:
 *   BillingService        — seat counting, subscription management, invoicing
 *   PlanGuard             — @RequireFeature() decorator + guard
 *   BillingController     — REST endpoints for billing UI
 *   BillingModule         — wires everything together
 */

import {
  Injectable, Logger, ForbiddenException, BadRequestException,
  NotFoundException, Module, Controller, Get, Post, Patch,
  Body, Param, Query, UseGuards, HttpCode, HttpStatus,
  CanActivate, ExecutionContext, SetMetadata,
  createParamDecorator,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthGuard } from '@nestjs/passport';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { PrismaClient } from '@prisma/client';
import { Cron } from '@nestjs/schedule';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

import {
  PLANS, GST, BILLING_POLICY,
  type PlanId, type FeatureFlag, type BillingCycle,
  type Subscription, type SeatBreakdown, type Invoice,
  type SubscriptionStatus,
} from './billing.types';

import {
  checkFeature, checkSeatLimit, checkEntityLimit, checkCsvImportLimit,
  computeBillableSeats, previewPlanChange, calculateInvoiceAmount,
  computeGracePeriodEnd, isInGracePeriod, trialDaysRemaining,
  generateInvoiceNumber, featureLabel, getAllPlans,
} from './feature-gate';

// ─── Feature Guard Infrastructure ────────────────────────────────────────────

export const FEATURE_KEY = 'required_feature';
export const RequireFeature = (feature: FeatureFlag) =>
  SetMetadata(FEATURE_KEY, feature);

@Injectable()
export class PlanGuard implements CanActivate {
  private readonly logger = new Logger(PlanGuard.name);

  constructor(
    private readonly reflector: Reflector,
    private readonly billing: BillingService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const feature = this.reflector.getAllAndOverride<FeatureFlag>(
      FEATURE_KEY,
      [context.getHandler(), context.getClass()],
    );

    // No feature requirement — always allow
    if (!feature) return true;

    const request = context.switchToHttp().getRequest<{ user: JwtPayload }>();
    const tenantId = request.user?.tid;
    if (!tenantId) throw new ForbiddenException('No tenant context');

    const result = await this.billing.checkFeatureForTenant(tenantId, feature);

    if (!result.allowed) {
      throw new ForbiddenException({
        message: result.reason,
        feature,
        upgradeUrl: result.upgradeUrl,
        requiredPlan: result.requiredPlan,
        code: 'FEATURE_NOT_AVAILABLE',
      });
    }

    return true;
  }
}

// ─── Billing Service ──────────────────────────────────────────────────────────

@Injectable()
export class BillingService {
  private readonly logger = new Logger(BillingService.name);
  private subCache = new Map<string, { sub: any; expiresAt: number }>();

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ── Subscription retrieval ─────────────────────────────────────────────────

  async getSubscription(tenantId: string): Promise<any> {
    const cached = this.subCache.get(tenantId);
    if (cached && cached.expiresAt > Date.now()) return cached.sub;

    const sub = await (this.prisma as any).subscription?.findFirst({
      where: { tenantId, status: { not: 'cancelled' } },
      orderBy: { createdAt: 'desc' },
    }).catch(() => null);

    if (!sub) {
      // Fallback to tenant.subscriptionTier field
      const tenant = await (this.prisma as any).tenant.findFirst({
        where: { id: tenantId },
        select: { subscriptionTier: true, settings: true },
      });
      const fallback = {
        planId: (tenant?.subscriptionTier ?? 'starter') as PlanId,
        status: 'active',
        tenantId,
      };
      this.subCache.set(tenantId, { sub: fallback, expiresAt: Date.now() + 60_000 });
      return fallback;
    }

    this.subCache.set(tenantId, { sub, expiresAt: Date.now() + 60_000 });
    return sub;
  }

  invalidateCache(tenantId: string) {
    this.subCache.delete(tenantId);
  }

  // ── Feature checking ───────────────────────────────────────────────────────

  async checkFeatureForTenant(tenantId: string, feature: FeatureFlag) {
    const sub = await this.getSubscription(tenantId);
    return checkFeature(feature, sub.planId as PlanId, sub.status);
  }

  async assertFeature(tenantId: string, feature: FeatureFlag): Promise<void> {
    const result = await this.checkFeatureForTenant(tenantId, feature);
    if (!result.allowed) {
      throw new ForbiddenException({
        message: result.reason,
        code: 'FEATURE_NOT_AVAILABLE',
        feature,
        requiredPlan: result.requiredPlan,
        upgradeUrl: result.upgradeUrl,
      });
    }
  }

  async assertSeatLimit(tenantId: string, adding = 1): Promise<void> {
    const [sub, seats] = await Promise.all([
      this.getSubscription(tenantId),
      this.getSeatBreakdown(tenantId),
    ]);
    const result = checkSeatLimit(seats.billableSeats, sub.planId, adding);
    if (!result.allowed) {
      throw new ForbiddenException({
        message: result.reason,
        code: 'SEAT_LIMIT_EXCEEDED',
        upgradeUrl: '/dashboard/billing/upgrade',
      });
    }
  }

  async assertEntityLimit(tenantId: string): Promise<void> {
    const [sub, entityCount] = await Promise.all([
      this.getSubscription(tenantId),
      (this.prisma as any).legalEntity?.count({ where: { tenantId, isActive: true } }).catch(() => 1) ?? 1,
    ]);
    const result = checkEntityLimit(entityCount, sub.planId);
    if (!result.allowed) {
      throw new ForbiddenException({
        message: result.reason ?? 'Entity limit exceeded',
        code: 'ENTITY_LIMIT_EXCEEDED',
        upgradeUrl: '/dashboard/billing/upgrade',
      });
    }
  }

  // ── Seat counting ──────────────────────────────────────────────────────────

  async getSeatBreakdown(tenantId: string): Promise<SeatBreakdown> {
    const [payrollEmployees, allEmployees, contractors, entityBreakdown] = await Promise.all([
      // Payroll employees: active, in a payroll group, and part of last run
      (this.prisma as any).employee.count({
        where: {
          tenantId,
          status: 'active',
          deletedAt: null,
          payrollGroupId: { not: null },
          employmentType: { not: 'contract' },
        },
      }).catch(() => 0),

      // All active employees
      (this.prisma as any).employee.count({
        where: { tenantId, status: 'active', deletedAt: null },
      }).catch(() => 0),

      // Contractors
      (this.prisma as any).employee.count({
        where: { tenantId, status: 'active', deletedAt: null, employmentType: 'contract' },
      }).catch(() => 0),

      // Per-entity headcount (for multi-entity tenants)
      (this.prisma as any).legalEntity?.findMany({
        where: { tenantId, isActive: true, deletedAt: null },
        select: { id: true, name: true },
      }).then(async (entities: any[]) => {
        return Promise.all(entities.map(async (e: any) => ({
          entityId: e.id,
          entityName: e.name,
          count: await (this.prisma as any).employee.count({
            where: { tenantId, legalEntityId: e.id, status: 'active', deletedAt: null },
          }).catch(() => 0),
        })));
      }).catch(() => [] as any[]) ?? [],
    ]);

    const nonPayrollEmployees = allEmployees - payrollEmployees - contractors;

    return {
      tenantId,
      payrollEmployees,
      nonPayrollEmployees: Math.max(0, nonPayrollEmployees),
      contractorCount: contractors,
      totalHeadcount: allEmployees,
      byEntity: entityBreakdown,
      billableSeats: payrollEmployees,
      computedAt: new Date(),
    };
  }

  // ── Invoice generation ─────────────────────────────────────────────────────

  async generateInvoice(
    tenantId: string,
    subscriptionId: string,
    periodStart: Date,
    periodEnd: Date,
    seats: number,
  ): Promise<Invoice> {
    const sub = await this.getSubscription(tenantId);
    const plan = PLANS[sub.planId as PlanId];
    const tenant = await (this.prisma as any).tenant.findFirst({
      where: { id: tenantId }, select: { name: true, settings: true },
    });

    const settings = (tenant?.settings ?? {}) as any;
    const customerState = settings.statutory?.legalState ?? settings.state ?? 'MH';
    const supplierState = GST.SUPPLIER_STATE;

    const amounts = calculateInvoiceAmount(
      seats,
      sub.planId,
      sub.cycle ?? 'monthly',
      supplierState,
      customerState,
      sub.customPricePerSeat,
    );

    // Get next invoice sequence
    const seq = await (this.prisma as any).invoice?.count({
      where: { tenantId },
    }).then((n: number) => n + 1).catch(() => 1);

    const now = new Date();
    const invoiceNumber = generateInvoiceNumber(now.getFullYear(), now.getMonth() + 1, seq);
    const dueDate = new Date(now);
    dueDate.setDate(dueDate.getDate() + BILLING_POLICY.INVOICE_DUE_DAYS);

    const lineItems = [
      {
        description: `${plan.name} Plan — ${seats} payroll employee(s) × ${sub.cycle === 'annual' ? '12 months' : '1 month'}`,
        quantity: seats,
        unitPrice: sub.cycle === 'annual' ? plan.priceAnnual : plan.priceMonthly,
        amount: amounts.subtotal,
        taxRate: amounts.isInterState ? GST.IGST_RATE : GST.CGST_RATE + GST.SGST_RATE,
        taxAmount: amounts.totalTax,
      },
    ];

    const invoice: Invoice = {
      id: `inv_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      invoiceNumber,
      tenantId,
      subscriptionId,
      status: 'open',
      periodStart,
      periodEnd,
      subtotal: amounts.subtotal,
      discountAmount: 0,
      taxableAmount: amounts.subtotal,
      cgstRate: amounts.cgstRate,
      sgstRate: amounts.sgstRate,
      igstRate: amounts.igstRate,
      cgstAmount: amounts.cgstAmount,
      sgstAmount: amounts.sgstAmount,
      igstAmount: amounts.igstAmount,
      totalTax: amounts.totalTax,
      totalAmount: amounts.totalAmount,
      amountDue: amounts.totalAmount,
      amountPaid: 0,
      supplierGstin: settings.supplierGstin,
      customerGstin: settings.gstNumber,
      placeOfSupply: customerState,
      isInterState: amounts.isInterState,
      lineItems,
      dueDate,
      notes: `SAC Code: ${GST.SAC_CODE}`,
      createdAt: now,
    };

    // Persist invoice
    await (this.prisma as any).invoice?.create({ data: { ...invoice, lineItems: lineItems as any } }).catch(() => null);

    this.events.emit('invoice.created', { tenantId, invoice });
    return invoice;
  }

  // ── Payment gateway integration ────────────────────────────────────────────

  async createRazorpaySubscription(
    tenantId: string,
    planId: PlanId,
    cycle: BillingCycle,
    seats: number,
  ) {
    const plan = PLANS[planId];
    const pricePerSeat = cycle === 'annual' ? plan.priceAnnual : plan.priceMonthly;

    // Razorpay subscription via REST (no SDK required)
    const payload = {
      plan_id: `plan_retroworks_${planId}_${cycle}`,   // Pre-configured in Razorpay dashboard
      total_count: cycle === 'annual' ? 1 : 12,
      quantity: seats,
      notes: { tenantId, planId, cycle, seats: String(seats) },
    };

    try {
      const response = await fetch('https://api.razorpay.com/v1/subscriptions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Basic ${Buffer.from(
            `${process.env.RAZORPAY_KEY_ID}:${process.env.RAZORPAY_KEY_SECRET}`
          ).toString('base64')}`,
        },
        body: JSON.stringify(payload),
      });
      return response.json();
    } catch (e: any) {
      this.logger.error(`Razorpay subscription creation failed: ${e.message}`);
      throw new BadRequestException('Payment gateway unavailable. Please try again.');
    }
  }

  async handleRazorpayWebhook(event: any, signature: string): Promise<void> {
    // Verify signature
    const crypto = await import('crypto');
    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET ?? '';
    const expectedSig = crypto
      .createHmac('sha256', webhookSecret)
      .update(JSON.stringify(event))
      .digest('hex');

    if (signature !== expectedSig) {
      this.logger.warn('Razorpay webhook signature mismatch');
      return;
    }

    const { event: eventType, payload } = event;
    const tenantId = payload?.subscription?.entity?.notes?.tenantId;
    if (!tenantId) return;

    this.logger.log(`Razorpay webhook: ${eventType} for tenant ${tenantId}`);

    switch (eventType) {
      case 'subscription.activated':
        await this.activateSubscription(tenantId, payload);
        break;
      case 'subscription.charged':
        await this.markInvoicePaid(tenantId, payload);
        break;
      case 'subscription.halted':
        await this.startGracePeriod(tenantId);
        break;
      case 'subscription.cancelled':
        await this.cancelSubscription(tenantId);
        break;
    }

    this.invalidateCache(tenantId);
  }

  private async activateSubscription(tenantId: string, payload: any): Promise<void> {
    const notes = payload?.subscription?.entity?.notes ?? {};
    await (this.prisma as any).subscription?.upsert({
      where: { tenantId },
      create: {
        tenantId,
        planId: notes.planId ?? 'starter',
        status: 'active',
        cycle: notes.cycle ?? 'monthly',
        payrollSeats: parseInt(notes.seats ?? '0'),
        gateway: 'razorpay',
        gatewaySubscriptionId: payload?.subscription?.entity?.id,
        currentPeriodStart: new Date(),
        currentPeriodEnd: new Date(Date.now() + 30 * 86400_000),
        cancelAtPeriodEnd: false,
      },
      update: { status: 'active' },
    }).catch(() => null);

    await (this.prisma as any).tenant.update({
      where: { id: tenantId },
      data: { subscriptionTier: notes.planId ?? 'starter', isActive: true },
    }).catch(() => null);

    this.events.emit('subscription.activated', { tenantId, planId: notes.planId });
  }

  private async markInvoicePaid(tenantId: string, payload: any): Promise<void> {
    const paymentId = payload?.payment?.entity?.id;
    await (this.prisma as any).invoice?.updateMany({
      where: { tenantId, status: 'open' },
      data: { status: 'paid', amountPaid: payload?.payment?.entity?.amount, paidAt: new Date(), gatewayPaymentId: paymentId },
    }).catch(() => null);
    this.events.emit('invoice.paid', { tenantId, paymentId });
  }

  private async startGracePeriod(tenantId: string): Promise<void> {
    const gracePeriodEnd = computeGracePeriodEnd(new Date());
    await (this.prisma as any).subscription?.updateMany({
      where: { tenantId },
      data: { status: 'grace_period', gracePeriodEnd },
    }).catch(() => null);
    this.events.emit('grace.started', { tenantId, gracePeriodEnd });
    this.logger.warn(`Grace period started for tenant ${tenantId}, ends ${gracePeriodEnd.toISOString()}`);
  }

  private async cancelSubscription(tenantId: string): Promise<void> {
    await (this.prisma as any).subscription?.updateMany({
      where: { tenantId },
      data: { status: 'cancelled', cancelledAt: new Date() },
    }).catch(() => null);
    await (this.prisma as any).tenant.update({
      where: { id: tenantId },
      data: { subscriptionTier: 'free' },
    }).catch(() => null);
    this.events.emit('subscription.cancelled', { tenantId });
  }

  // ── Plan management ────────────────────────────────────────────────────────

  async getUpgradePreview(tenantId: string, targetPlanId: PlanId, targetCycle: BillingCycle) {
    const [sub, seats] = await Promise.all([
      this.getSubscription(tenantId),
      this.getSeatBreakdown(tenantId),
    ]);

    const now = new Date();
    const periodEnd = new Date(sub.currentPeriodEnd ?? Date.now() + 30 * 86400_000);
    const daysRemaining = Math.max(0, Math.ceil((periodEnd.getTime() - now.getTime()) / 86400_000));
    const totalDays = 30; // Simplified

    return previewPlanChange(
      sub.planId, targetPlanId,
      sub.cycle ?? 'monthly', targetCycle,
      seats.billableSeats,
      daysRemaining, totalDays,
    );
  }

  async changePlan(tenantId: string, targetPlanId: PlanId, targetCycle: BillingCycle, userId: string) {
    const preview = await this.getUpgradePreview(tenantId, targetPlanId, targetCycle);

    if (preview.requiredSeatAdjustment) {
      throw new BadRequestException(
        `Reduce seat count by ${preview.requiredSeatAdjustment} before downgrading to ${targetPlanId}.`
      );
    }

    // For upgrades — apply immediately
    // For downgrades — schedule at period end
    if (preview.isUpgrade) {
      await (this.prisma as any).subscription?.updateMany({
        where: { tenantId },
        data: { planId: targetPlanId, cycle: targetCycle, status: 'active' },
      }).catch(() => null);
      await (this.prisma as any).tenant.update({
        where: { id: tenantId },
        data: { subscriptionTier: targetPlanId },
      }).catch(() => null);
    } else {
      await (this.prisma as any).subscription?.updateMany({
        where: { tenantId },
        data: { cancelAtPeriodEnd: true, notes: JSON.stringify({ pendingDowngrade: targetPlanId }) },
      }).catch(() => null);
    }

    this.invalidateCache(tenantId);
    this.events.emit('subscription.changed', { tenantId, from: preview.currentPlan, to: targetPlanId, userId });
    return preview;
  }

  // ── Billing history ────────────────────────────────────────────────────────

  async getBillingHistory(tenantId: string, page = 1, limit = 20) {
    const skip = (page - 1) * limit;
    const [invoices, total] = await Promise.all([
      (this.prisma as any).invoice?.findMany({
        where: { tenantId },
        orderBy: { createdAt: 'desc' },
        skip, take: limit,
      }).catch(() => []) ?? [],
      (this.prisma as any).invoice?.count({ where: { tenantId } }).catch(() => 0) ?? 0,
    ]);
    return { invoices, total, page, limit, pages: Math.ceil(total / limit) };
  }

  async getInvoicePdf(tenantId: string, invoiceId: string): Promise<Invoice | null> {
    return (this.prisma as any).invoice?.findFirst({
      where: { id: invoiceId, tenantId },
    }).catch(() => null) ?? null;
  }

  // ── Nightly jobs ───────────────────────────────────────────────────────────

  /** Suspend features for tenants whose grace period has ended */
  @Cron('0 3 * * *', { timeZone: 'Asia/Kolkata' })
  async runGracePeriodEnforcement() {
    const expired = await (this.prisma as any).subscription?.findMany({
      where: { status: 'grace_period', gracePeriodEnd: { lt: new Date() } },
      select: { tenantId: true },
    }).catch(() => []) ?? [];

    for (const { tenantId } of expired) {
      await (this.prisma as any).subscription?.updateMany({
        where: { tenantId, status: 'grace_period' },
        data: { status: 'suspended' },
      }).catch(() => null);
      await (this.prisma as any).tenant.update({
        where: { id: tenantId },
        data: { isActive: false },
      }).catch(() => null);
      this.invalidateCache(tenantId);
      this.events.emit('grace.ended', { tenantId });
      this.logger.warn(`Tenant ${tenantId} suspended — grace period expired`);
    }
  }

  /** Generate monthly invoices for all active subscriptions */
  @Cron('0 6 1 * *', { timeZone: 'Asia/Kolkata' })
  async runMonthlyInvoicing() {
    const subs = await (this.prisma as any).subscription?.findMany({
      where: { status: 'active', cycle: 'monthly' },
    }).catch(() => []) ?? [];

    this.logger.log(`Generating monthly invoices for ${subs.length} subscriptions`);

    for (const sub of subs) {
      try {
        const seats = await this.getSeatBreakdown(sub.tenantId);
        const now = new Date();
        const periodStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        const periodEnd = new Date(now.getFullYear(), now.getMonth(), 0);
        await this.generateInvoice(sub.tenantId, sub.id, periodStart, periodEnd, seats.billableSeats);
      } catch (e: any) {
        this.logger.error(`Invoice generation failed for ${sub.tenantId}: ${e.message}`);
      }
    }
  }

  /** Update seat counts on subscriptions nightly */
  @Cron('0 1 * * *', { timeZone: 'Asia/Kolkata' })
  async syncSeatCounts() {
    const subs = await (this.prisma as any).subscription?.findMany({
      where: { status: { in: ['active', 'grace_period', 'trialing'] } },
      select: { tenantId: true, id: true },
    }).catch(() => []) ?? [];

    for (const sub of subs) {
      const seats = await this.getSeatBreakdown(sub.tenantId).catch(() => null);
      if (!seats) continue;
      await (this.prisma as any).subscription?.update({
        where: { id: sub.id },
        data: { payrollSeats: seats.billableSeats },
      }).catch(() => null);
    }
  }

  /** Start trials for new tenants */
  async startTrial(tenantId: string, planId: PlanId = 'growth'): Promise<void> {
    const plan = PLANS[planId];
    const trialEnd = new Date();
    trialEnd.setDate(trialEnd.getDate() + plan.trialDays);

    await (this.prisma as any).subscription?.upsert({
      where: { tenantId },
      create: {
        tenantId,
        planId,
        status: 'trialing',
        cycle: 'monthly',
        payrollSeats: 0,
        gateway: 'manual',
        trialStart: new Date(),
        trialEnd,
        currentPeriodStart: new Date(),
        currentPeriodEnd: trialEnd,
        cancelAtPeriodEnd: false,
      },
      update: { planId, status: 'trialing', trialEnd },
    }).catch(() => null);

    await (this.prisma as any).tenant.update({
      where: { id: tenantId },
      data: { subscriptionTier: planId },
    }).catch(() => null);

    this.invalidateCache(tenantId);
    this.events.emit('trial.started', { tenantId, planId, trialEnd });
  }

  // ── Full billing overview ──────────────────────────────────────────────────

  async getBillingOverview(tenantId: string) {
    const [sub, seats, recentInvoices] = await Promise.all([
      this.getSubscription(tenantId),
      this.getSeatBreakdown(tenantId),
      (this.prisma as any).invoice?.findMany({
        where: { tenantId }, orderBy: { createdAt: 'desc' }, take: 5,
      }).catch(() => []) ?? [],
    ]);

    const plan = PLANS[(sub?.planId ?? 'starter') as PlanId];
    const isTrialing = sub?.status === 'trialing';
    const trialDays = isTrialing && sub?.trialEnd ? trialDaysRemaining(new Date(sub.trialEnd)) : 0;
    const inGrace = sub?.gracePeriodEnd ? isInGracePeriod(new Date(sub.gracePeriodEnd)) : false;

    return {
      subscription: sub,
      plan: {
        id: plan.id,
        name: plan.name,
        features: plan.features,
        limits: plan.limits,
        priceMonthly: plan.priceMonthly,
        priceAnnual: plan.priceAnnual,
      },
      seats,
      billing: {
        status: sub?.status ?? 'active',
        isTrialing,
        trialDaysRemaining: trialDays,
        inGracePeriod: inGrace,
        gracePeriodEnd: sub?.gracePeriodEnd,
        nextBillingDate: sub?.currentPeriodEnd,
        estimatedNextBill: plan.priceMonthly * seats.billableSeats,
      },
      recentInvoices,
      availableUpgrades: getAllPlans()
        .filter(p => {
          const order = ['starter','growth','pro','enterprise'];
          return order.indexOf(p.id) > order.indexOf(sub?.planId ?? 'starter');
        })
        .map(p => ({ id: p.id, name: p.name, priceMonthly: p.priceMonthly })),
    };
  }
}

// ─── Controller ────────────────────────────────────────────────────────────────

@ApiTags('billing')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('billing')
export class BillingController {
  constructor(private readonly svc: BillingService) {}

  @Get('overview')
  @ApiOperation({ summary: 'Billing overview — plan, seats, invoices, status' })
  getOverview(@CurrentUser() u: JwtPayload) {
    return this.svc.getBillingOverview(u.tid);
  }

  @Get('plans')
  @ApiOperation({ summary: 'All available plans with features and pricing' })
  getPlans() { return getAllPlans(); }

  @Get('seats')
  @ApiOperation({ summary: 'Current seat breakdown — payroll, non-payroll, contractors' })
  getSeats(@CurrentUser() u: JwtPayload) {
    return this.svc.getSeatBreakdown(u.tid);
  }

  @Get('invoices')
  @ApiOperation({ summary: 'Billing history — paginated invoices' })
  getInvoices(
    @CurrentUser() u: JwtPayload,
    @Query('page') page?: string,
    @Query('limit') limit?: string,
  ) {
    return this.svc.getBillingHistory(u.tid, parseInt(page ?? '1'), parseInt(limit ?? '20'));
  }

  @Get('invoices/:id')
  @ApiOperation({ summary: 'Get single invoice (for PDF download)' })
  async getInvoice(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    const inv = await this.svc.getInvoicePdf(u.tid, id);
    if (!inv) throw new NotFoundException('Invoice not found');
    return inv;
  }

  @Get('upgrade-preview')
  @ApiOperation({ summary: 'Preview plan change — prorated credit, lost features' })
  upgradePreview(
    @Query('plan') plan: PlanId,
    @Query('cycle') cycle: BillingCycle,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.svc.getUpgradePreview(u.tid, plan, cycle ?? 'monthly');
  }

  @Post('upgrade')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Change plan (upgrade or downgrade)' })
  changePlan(
    @Body('planId') planId: PlanId,
    @Body('cycle') cycle: BillingCycle,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.svc.changePlan(u.tid, planId, cycle ?? 'monthly', u.sub);
  }

  @Post('checkout')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Create Razorpay subscription for checkout' })
  checkout(
    @Body('planId') planId: PlanId,
    @Body('cycle') cycle: BillingCycle,
    @Body('seats') seats: number,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.svc.createRazorpaySubscription(u.tid, planId, cycle, seats);
  }

  @Post('trial/start')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Start free trial for tenant' })
  startTrial(
    @Body('planId') planId: PlanId,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.svc.startTrial(u.tid, planId ?? 'growth');
  }

  // Razorpay webhook — no auth, verified by HMAC signature
  @Post('webhooks/razorpay')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Razorpay payment webhook' })
  razorpayWebhook(
    @Body() event: any,
    @Query('signature') signature: string,
  ) {
    return this.svc.handleRazorpayWebhook(event, signature);
  }

  @Get('feature/:feature')
  @ApiOperation({ summary: 'Check if feature is available for current plan' })
  checkFeature(@Param('feature') feature: FeatureFlag, @CurrentUser() u: JwtPayload) {
    return this.svc.checkFeatureForTenant(u.tid, feature);
  }
}

// ─── Module ───────────────────────────────────────────────────────────────────

@Module({
  controllers: [BillingController],
  providers: [
    BillingService,
    PlanGuard,
    { provide: PrismaClient, useExisting: PrismaClient },
  ],
  exports: [BillingService, PlanGuard],
})
export class BillingModule {}
