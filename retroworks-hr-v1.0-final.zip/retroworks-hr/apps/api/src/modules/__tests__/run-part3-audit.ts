/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * MASTER AUDIT — PART 3
 * Leave Year-End + Role Engine + Education Mode
 * Self-contained ts-node runner (no jest required)
 * ═══════════════════════════════════════════════════════════════════════════════
 */

// ─── Minimal test harness ────────────────────────────────────────────────────
let _passed = 0, _failed = 0, _total = 0;
let _currentBlock = '';
const _failures: string[] = [];

function describe(label: string, fn: () => void) {
  _currentBlock = label;
  console.log(`\n  ${label}`);
  fn();
}

function it(label: string, fn: () => void) {
  _total++;
  try {
    fn();
    console.log(`    ✅  ${label}`);
    _passed++;
  } catch (e: any) {
    const msg = `    ❌  ${label}\n       ${e.message}`;
    console.log(msg);
    _failures.push(`[${_currentBlock}] ${label}\n       ${e.message}`);
    _failed++;
  }
}

function expect(actual: any) {
  return {
    toBe: (exp: any) => { if (actual !== exp) throw new Error(`Expected ${JSON.stringify(exp)}, got ${JSON.stringify(actual)}`); },
    toEqual: (exp: any) => { if (JSON.stringify(actual) !== JSON.stringify(exp)) throw new Error(`Expected ${JSON.stringify(exp)}, got ${JSON.stringify(actual)}`); },
    toBeCloseTo: (exp: number, d = 2) => { if (Math.abs(actual - exp) > (d === 0 ? 0.5 : 1 / Math.pow(10, d))) throw new Error(`Expected ~${exp}, got ${actual}`); },
    toBeGreaterThan: (n: number) => { if (!(actual > n)) throw new Error(`Expected ${actual} > ${n}`); },
    toBeGreaterThanOrEqual: (n: number) => { if (!(actual >= n)) throw new Error(`Expected ${actual} >= ${n}`); },
    toBeLessThan: (n: number) => { if (!(actual < n)) throw new Error(`Expected ${actual} < ${n}`); },
    toBeLessThanOrEqual: (n: number) => { if (!(actual <= n)) throw new Error(`Expected ${actual} <= ${n}`); },
    toBeDefined: () => { if (actual == null) throw new Error(`Expected defined, got ${actual}`); },
    toBeUndefined: () => { if (actual !== undefined) throw new Error(`Expected undefined, got ${JSON.stringify(actual)}`); },
    toBeNull: () => { if (actual !== null) throw new Error(`Expected null, got ${JSON.stringify(actual)}`); },
    toBeTruthy: () => { if (!actual) throw new Error(`Expected truthy, got ${actual}`); },
    toBeFalsy: () => { if (actual) throw new Error(`Expected falsy, got ${actual}`); },
    toHaveLength: (n: number) => { if (!actual || actual.length !== n) throw new Error(`Expected length ${n}, got ${actual?.length}`); },
    toContain: (s: string) => { if (!actual?.includes?.(s)) throw new Error(`"${actual}" does not contain "${s}"`); },
    toMatch: (r: RegExp) => { if (!r.test(String(actual))) throw new Error(`"${actual}" does not match ${r}`); },
    not: {
      toBe: (exp: any) => { if (actual === exp) throw new Error(`Expected NOT ${JSON.stringify(exp)}`); },
      toContain: (s: string) => { if (actual?.includes?.(s)) throw new Error(`Expected "${actual}" not to contain "${s}"`); },
      toBeTruthy: () => { if (actual) throw new Error(`Expected falsy, got ${actual}`); },
    },
  };
}

// ─── Imports ─────────────────────────────────────────────────────────────────

import {
  computeYearEnd, processBatchYearEnd, getFreezeWindowStatus, isFreezeWindowActive,
  canSubmitLeaveRequest, verifyLedgerConsistency, isAlreadyProcessed, guardIdempotency,
  generateReminderSchedule, buildAuditEvent, bulkApproveRequests, diffSimulationVsActual,
  getYearLabel, getYearBoundaries, getNewYear, simpleLedgerHash,
  type LeaveYearConfig, type LeaveTypeConfig, type EmployeeLeaveSnapshot,
  type YearEndComputed, type ProcessedLedger,
} from '../leave/year-end/leave-year-end.engine';

import {
  buildSystemRoles, createCustomRole, cloneRole, canAccess, enforceAccess,
  buildVisibleMenu, maskRecord, getMaskedFields, simulateRole,
  grantTemporaryElevation, revokeElevation, isElevationActive, getActiveElevations,
  auditRoleCreated, auditRoleCloned, auditElevationGranted,
  isModuleAccessible, getAccessibleModules,
  type RoleDefinition, type UserPermissionContext, type MenuNode, type TemporaryElevation,
} from '../security/role-permission.engine';

import {
  createEducationTenantConfig, buildEducationRoles, getTerm,
  getCurrentAcademicYear, getAcademicYearForDate, buildAcademicYear,
  verifyTenantIsolation, isModuleAllowedInEducationMode,
  buildSchoolDashboard, validateEducationPayrollRun,
  initializeLeaveCloseWorkflow, advanceWorkflowStep, toggleEducationMode,
  validateStaffOnboarding,
  type StaffRecord, type EducationTenantConfig,
} from '../settings/education-mode.engine';

// ─────────────────────────────────────────────────────────────────────────────
// SHARED FIXTURES
// ─────────────────────────────────────────────────────────────────────────────

const TENANT_ID = 'tenant-corp-001';
const EDU_TENANT_ID = 'tenant-school-001';

const FIN_YEAR_CONFIG: LeaveYearConfig = {
  yearType: 'financial',
  closingYear: 2024,
  freezeWindowStart: '2025-03-25',
  freezeWindowEnd: '2025-04-02',
  encashmentRatePerDay: 2_500,   // ₹2,500/day encashment
  currency: 'INR',
};

const EL_TYPE: LeaveTypeConfig = {
  id: 'lt-el', code: 'EL', name: 'Earned Leave',
  maxDaysPerYear: 30, carryForwardDays: 15, encashable: true, maxEncashableDays: 10, paidLeave: true,
};
const CL_TYPE: LeaveTypeConfig = {
  id: 'lt-cl', code: 'CL', name: 'Casual Leave',
  maxDaysPerYear: 8, carryForwardDays: 0, encashable: false, maxEncashableDays: null, paidLeave: true,
};
const ML_TYPE: LeaveTypeConfig = {
  id: 'lt-ml', code: 'ML', name: 'Medical Leave',
  maxDaysPerYear: 12, carryForwardDays: 6, encashable: false, maxEncashableDays: null, paidLeave: true,
};

const LEAVE_TYPES = new Map<string, LeaveTypeConfig>([
  ['lt-el', EL_TYPE], ['lt-cl', CL_TYPE], ['lt-ml', ML_TYPE],
]);

/** 5 employees × 3 leave types = 15 snapshots */
const makeSnapshot = (
  empId: string, name: string, typeId: string,
  allocated: number, used: number, pending = 0, carryForward = 0,
): EmployeeLeaveSnapshot => ({ employeeId: empId, employeeName: name, leaveTypeId: typeId, year: 2024, allocated, used, pending, carryForward });

const SNAPSHOTS: EmployeeLeaveSnapshot[] = [
  // Arjun — heavy EL user, some CL, no ML use
  makeSnapshot('emp-1', 'Arjun Mehta',   'lt-el', 30, 12, 0, 5),  // available=18 → CF=15, enc=3
  makeSnapshot('emp-1', 'Arjun Mehta',   'lt-cl',  8,  6, 0, 0),  // available=2  → lapse=2 (no CF)
  makeSnapshot('emp-1', 'Arjun Mehta',   'lt-ml', 12,  0, 0, 0),  // available=12 → CF=6, lapse=6

  // Priya — fully used EL, no balance
  makeSnapshot('emp-2', 'Priya Nair',    'lt-el', 30, 30, 0, 0),  // available=0 → all zero
  makeSnapshot('emp-2', 'Priya Nair',    'lt-cl',  8,  2, 2, 0),  // available=4 → lapse=4
  makeSnapshot('emp-2', 'Priya Nair',    'lt-ml', 12,  6, 0, 0),  // available=6 → CF=6

  // Ravi — over-encashment cap scenario
  makeSnapshot('emp-3', 'Ravi Kumar',    'lt-el', 30,  5, 0, 0),  // available=25 → CF=15,enc=10,lapse=0
  makeSnapshot('emp-3', 'Ravi Kumar',    'lt-cl',  8,  0, 0, 0),  // available=8  → lapse=8 (no CF)
  makeSnapshot('emp-3', 'Ravi Kumar',    'lt-ml', 12,  0, 0, 0),  // available=12 → CF=6, lapse=6

  // Sneha — pending leave in-flight
  makeSnapshot('emp-4', 'Sneha Iyer',    'lt-el', 30, 10, 5, 0),  // available=15 → CF=15
  makeSnapshot('emp-4', 'Sneha Iyer',    'lt-cl',  8,  1, 3, 0),  // available=4  → lapse=4
  makeSnapshot('emp-4', 'Sneha Iyer',    'lt-ml', 12,  2, 0, 0),  // available=10 → CF=6, lapse=4

  // Dev — zero balances, all leave types at minimum
  makeSnapshot('emp-5', 'Dev Sharma',    'lt-el', 30, 29, 0, 0),  // available=1  → CF=1
  makeSnapshot('emp-5', 'Dev Sharma',    'lt-cl',  8,  8, 0, 0),  // available=0  → all zero
  makeSnapshot('emp-5', 'Dev Sharma',    'lt-ml', 12, 12, 0, 0),  // available=0  → all zero
];

const SYSTEM_ROLES = buildSystemRoles(TENANT_ID, 'system');
const [HR_ROLE, FINANCE_ROLE, MANAGER_ROLE, EMPLOYEE_ROLE] = SYSTEM_ROLES;

const MENU_TREE: MenuNode[] = [
  { id: 'nav-employees', label: 'Employees', module: 'core-hr', visible: true },
  { id: 'nav-leave', label: 'Leave', module: 'leave', visible: true, children: [
    { id: 'nav-leave-year-end', label: 'Year-End Processing', module: 'leave', visible: true },
  ]},
  { id: 'nav-attendance', label: 'Attendance', module: 'attendance', visible: true },
  { id: 'nav-payroll', label: 'Payroll', module: 'payroll', visible: true, children: [
    { id: 'nav-payroll-tds', label: 'TDS', module: 'payroll-tds', visible: true },
    { id: 'nav-payroll-pf', label: 'PF / ESI', module: 'payroll-pf-esi', visible: true },
    { id: 'nav-payroll-form16', label: 'Form 16', module: 'payroll-form16', visible: true },
  ]},
  { id: 'nav-performance', label: 'Performance', module: 'performance', visible: true },
  { id: 'nav-expense', label: 'Expense', module: 'expense', visible: true },
  { id: 'nav-reports', label: 'Reports', module: 'reports', visible: true },
  { id: 'nav-settings', label: 'Settings', module: 'settings', visible: true },
  { id: 'nav-lnd', label: 'L&D', module: 'lnd', visible: true },
];

function makeCtx(roles: RoleDefinition[], elevations: TemporaryElevation[] = [], params: Record<string, string> = {}): UserPermissionContext {
  return {
    userId: 'user-001',
    tenantId: TENANT_ID,
    roleIds: roles.map(r => r.id),
    roles,
    activeElevations: elevations,
    requestContext: { params },
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// ═══ SECTION A — LEAVE YEAR-END ═══
// ─────────────────────────────────────────────────────────────────────────────

console.log('\n══════════════════════════════════════════════════════════════');
console.log('  MASTER AUDIT — PART 3: Leave Year-End + Role Engine + Education Mode');
console.log('══════════════════════════════════════════════════════════════');

describe('SECTION A — Leave Year-End Engine', () => {

  describe('A1 — Year config & boundaries', () => {

    it('A1.1 | financial year label: year=2024 → "FY2024-25"', () => {
      expect(getYearLabel('financial', 2024)).toBe('FY2024-25');
    });

    it('A1.2 | academic year label: year=2024 → "AY2024-25"', () => {
      expect(getYearLabel('academic', 2024)).toBe('AY2024-25');
    });

    it('A1.3 | calendar year boundaries: 2024 → Jan 1 to Dec 31', () => {
      const b = getYearBoundaries('calendar', 2024);
      expect(b.start.getMonth()).toBe(0);   // January = 0
      expect(b.end.getMonth()).toBe(11);    // December = 11
    });

    it('A1.4 | financial year boundaries: 2024 → Apr 1 to Mar 31 2025', () => {
      const b = getYearBoundaries('financial', 2024);
      expect(b.start.getMonth()).toBe(3);   // April = 3
      expect(b.end.getFullYear()).toBe(2025);
    });

    it('A1.5 | academic year boundaries: 2024 → Jun 1 to May 31 2025', () => {
      const b = getYearBoundaries('academic', 2024);
      expect(b.start.getMonth()).toBe(5);   // June = 5
      expect(b.end.getFullYear()).toBe(2025);
      expect(b.end.getMonth()).toBe(4);     // May = 4
    });

    it('A1.6 | getNewYear: all year types → closing + 1', () => {
      expect(getNewYear('calendar', 2024)).toBe(2025);
      expect(getNewYear('financial', 2024)).toBe(2025);
      expect(getNewYear('academic', 2024)).toBe(2025);
    });

  });

  describe('A2 — Freeze window', () => {

    it('A2.1 | freeze not active before window', () => {
      const active = isFreezeWindowActive(FIN_YEAR_CONFIG, new Date('2025-03-20'));
      expect(active).toBe(false);
    });

    it('A2.2 | freeze active inside window', () => {
      const active = isFreezeWindowActive(FIN_YEAR_CONFIG, new Date('2025-03-28'));
      expect(active).toBe(true);
    });

    it('A2.3 | freeze status: days until freeze > 0 when before window', () => {
      const status = getFreezeWindowStatus(FIN_YEAR_CONFIG, new Date('2025-03-01'));
      expect(status.isFrozen).toBe(false);
      expect(status.daysUntilFreeze).toBeGreaterThan(0);
      expect(status.message).toContain('freeze starts in');
    });

    it('A2.4 | freeze guard: reject leave for closing year during freeze', () => {
      const result = canSubmitLeaveRequest(FIN_YEAR_CONFIG, '2025-02-10', new Date('2025-03-28'));
      expect(result.allowed).toBe(false);
      expect(result.reason).toContain('frozen');
    });

    it('A2.5 | freeze guard: allow next-year leave during freeze', () => {
      // Requesting leave for next FY (Apr 2025 onwards) — allowed even during freeze
      const result = canSubmitLeaveRequest(FIN_YEAR_CONFIG, '2025-07-15', new Date('2025-03-28'));
      expect(result.allowed).toBe(true);
    });

  });

  describe('A3 — Core year-end computation', () => {

    it('A3.1 | EL: available=18 → CF=15 (capped), enc=3 (remaining), lapse=0', () => {
      const r = computeYearEnd(SNAPSHOTS[0]!, EL_TYPE, FIN_YEAR_CONFIG);
      // allocated=30, used=12, pending=0, carryForward(prev)=5 (ignored in computation)
      // available = 30-12 = 18; CF = min(18, 15) = 15; balance = 3; enc = min(3, 10) = 3; lapse = 0
      expect(r.closingAvailable).toBe(18);
      expect(r.carryForwardDays).toBe(15);
      expect(r.encashedDays).toBe(3);
      expect(r.lapsedDays).toBe(0);
      expect(r.encashmentAmount).toBe(3 * 2_500);
      expect(r.newYearAllocated).toBe(30 + 15);  // 45
    });

    it('A3.2 | CL: no carry-forward, no encashment → all lapse', () => {
      const r = computeYearEnd(SNAPSHOTS[1]!, CL_TYPE, FIN_YEAR_CONFIG);
      // available = 8-6 = 2; CF=0 (CL no carry); enc=0 (not encashable); lapse=2
      expect(r.closingAvailable).toBe(2);
      expect(r.carryForwardDays).toBe(0);
      expect(r.encashedDays).toBe(0);
      expect(r.lapsedDays).toBe(2);
    });

    it('A3.3 | ML: partial balance → CF=6 (capped at type limit), lapse=6', () => {
      const r = computeYearEnd(SNAPSHOTS[2]!, ML_TYPE, FIN_YEAR_CONFIG);
      // available=12; CF=min(12,6)=6; enc=0 (not encashable); lapse=6
      expect(r.carryForwardDays).toBe(6);
      expect(r.lapsedDays).toBe(6);
      expect(r.encashedDays).toBe(0);
    });

    it('A3.4 | Fully-used EL → all zeros, new year = base only', () => {
      const r = computeYearEnd(SNAPSHOTS[3]!, EL_TYPE, FIN_YEAR_CONFIG);
      expect(r.closingAvailable).toBe(0);
      expect(r.carryForwardDays).toBe(0);
      expect(r.encashedDays).toBe(0);
      expect(r.lapsedDays).toBe(0);
      expect(r.newYearAllocated).toBe(30);  // Base only
    });

    it('A3.5 | Ravi EL: available=25 → CF=15, enc=10 (maxEncashable cap), lapse=0', () => {
      const r = computeYearEnd(SNAPSHOTS[6]!, EL_TYPE, FIN_YEAR_CONFIG);
      expect(r.closingAvailable).toBe(25);
      expect(r.carryForwardDays).toBe(15);
      expect(r.encashedDays).toBe(10);    // Capped at maxEncashableDays=10
      expect(r.lapsedDays).toBe(0);
      expect(r.encashmentAmount).toBe(10 * 2_500);
      expect(r.newYearAllocated).toBe(30 + 15);
    });

    it('A3.6 | Pending leave reduces available balance', () => {
      // Sneha: EL allocated=30, used=10, pending=5 → available=15
      const r = computeYearEnd(SNAPSHOTS[9]!, EL_TYPE, FIN_YEAR_CONFIG);
      expect(r.closingAvailable).toBe(15);
      expect(r.carryForwardDays).toBe(15);
    });

    it('A3.7 | isSimulation=true → processedAt present but idempotencyKey set', () => {
      const r = computeYearEnd(SNAPSHOTS[0]!, EL_TYPE, FIN_YEAR_CONFIG, true);
      expect(r.isSimulation).toBe(true);
      expect(r.idempotencyKey).toContain('emp-1');
      expect(r.idempotencyKey).toContain('lt-el');
    });

  });

  describe('A4 — Batch processing', () => {

    it('A4.1 | Batch simulation: 5 employees × 3 types = 15 records', () => {
      const result = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true);
      expect(result.totalRecords).toBe(15);
      expect(result.totalEmployees).toBe(5);
      expect(result.totalLeaveTypes).toBe(3);
      expect(result.isSimulation).toBe(true);
      expect(result.isLocked).toBe(false);
    });

    it('A4.2 | Batch: total encashment = sum of all encashed amounts', () => {
      const result = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true);
      const manual = result.computed.reduce((s, c) => s + c.encashmentAmount, 0);
      expect(result.totalEncashmentAmount).toBeCloseTo(manual, 1);
      expect(result.totalEncashmentAmount).toBeGreaterThan(0);
    });

    it('A4.3 | Batch: ledgerHash present and deterministic', () => {
      const r1 = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true);
      const r2 = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true);
      expect(r1.ledgerHash).toMatch(/^LH-[0-9A-F]{8}$/);
      expect(r1.ledgerHash).toBe(r2.ledgerHash);  // Deterministic
    });

    it('A4.4 | Batch: ledgerHash differs when data changes', () => {
      const r1 = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true);
      const modifiedSnaps = SNAPSHOTS.map((s, i) => i === 0 ? { ...s, used: s.used + 1 } : s);
      const r2 = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, modifiedSnaps, LEAVE_TYPES, true);
      expect(r1.ledgerHash).not.toBe(r2.ledgerHash);
    });

    it('A4.5 | Batch real processing: isLocked=true', () => {
      const result = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, false);
      expect(result.isLocked).toBe(true);
      expect(result.isSimulation).toBe(false);
    });

  });

  describe('A5 — Ledger consistency', () => {

    it('A5.1 | All computed records pass consistency check', () => {
      const result = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true);
      const check = verifyLedgerConsistency(result.computed);
      expect(check.isConsistent).toBe(true);
      expect(check.violations).toHaveLength(0);
    });

    it('A5.2 | Deliberately corrupt record → fails consistency check', () => {
      const result = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true);
      const corrupted: typeof result.computed = result.computed.map((c, i) =>
        i === 0 ? { ...c, carryForwardDays: c.carryForwardDays + 999 } : c
      );
      const check = verifyLedgerConsistency(corrupted);
      expect(check.isConsistent).toBe(false);
      expect(check.violations.length).toBeGreaterThan(0);
    });

    it('A5.3 | closingAvailable never negative even with over-used leave', () => {
      const overUsed = makeSnapshot('emp-X', 'Test', 'lt-el', 10, 15, 0, 0);  // Used > allocated
      const r = computeYearEnd(overUsed, EL_TYPE, FIN_YEAR_CONFIG);
      expect(r.closingAvailable).toBe(0);
      expect(r.lapsedDays).toBe(0);
      expect(r.carryForwardDays).toBe(0);
    });

  });

  describe('A6 — Idempotency guard', () => {

    it('A6.1 | isAlreadyProcessed: no prior records → false', () => {
      expect(isAlreadyProcessed([], TENANT_ID, 2024)).toBe(false);
    });

    it('A6.2 | isAlreadyProcessed: same tenant+year → true', () => {
      const ledgers: ProcessedLedger[] = [{
        tenantId: TENANT_ID, closingYear: 2024, yearType: 'financial',
        processedAt: new Date(), ledgerHash: 'LH-ABCD1234',
      }];
      expect(isAlreadyProcessed(ledgers, TENANT_ID, 2024)).toBe(true);
    });

    it('A6.3 | guardIdempotency: different year → safe', () => {
      const ledgers: ProcessedLedger[] = [{
        tenantId: TENANT_ID, closingYear: 2023, yearType: 'financial',
        processedAt: new Date(), ledgerHash: 'LH-ABCD1234',
      }];
      const r = guardIdempotency(ledgers, TENANT_ID, 2024);
      expect(r.safe).toBe(true);
    });

    it('A6.4 | guardIdempotency: same year → safe=false, reason explains', () => {
      const ledgers: ProcessedLedger[] = [{
        tenantId: TENANT_ID, closingYear: 2024, yearType: 'financial',
        processedAt: new Date('2025-04-01'), ledgerHash: 'LH-ABCD1234',
      }];
      const r = guardIdempotency(ledgers, TENANT_ID, 2024);
      expect(r.safe).toBe(false);
      expect(r.reason).toContain('2024');
      expect(r.reason).toContain('Re-run blocked');
    });

    it('A6.5 | Different tenant same year → still safe (own tenant check)', () => {
      const ledgers: ProcessedLedger[] = [{
        tenantId: 'other-tenant', closingYear: 2024, yearType: 'financial',
        processedAt: new Date(), ledgerHash: 'LH-OTHER',
      }];
      const r = guardIdempotency(ledgers, TENANT_ID, 2024);
      expect(r.safe).toBe(true);
    });

  });

  describe('A7 — Reminder automation & audit', () => {

    it('A7.1 | Reminder schedule contains at least 4 reminders', () => {
      const reminders = generateReminderSchedule(FIN_YEAR_CONFIG);
      expect(reminders.length).toBeGreaterThanOrEqual(4);
    });

    it('A7.2 | Includes encashment_pending reminder when rate > 0', () => {
      const reminders = generateReminderSchedule(FIN_YEAR_CONFIG);
      const enc = reminders.find(r => r.type === 'encashment_pending');
      expect(enc).toBeDefined();
    });

    it('A7.3 | No encashment reminder when rate = 0', () => {
      const zeroRateConfig = { ...FIN_YEAR_CONFIG, encashmentRatePerDay: 0 };
      const reminders = generateReminderSchedule(zeroRateConfig);
      const enc = reminders.find(r => r.type === 'encashment_pending');
      expect(enc).toBeUndefined();
    });

    it('A7.4 | Audit event type = year_end_simulated for simulation', () => {
      const batch = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true);
      const event = buildAuditEvent(batch, TENANT_ID, 'hr-user-1');
      expect(event.eventType).toBe('year_end_simulated');
      expect(event.affectedEmployees).toBe(5);
    });

    it('A7.5 | Audit event type = year_end_processed for real run', () => {
      const batch = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, false);
      const event = buildAuditEvent(batch, TENANT_ID, 'hr-user-1');
      expect(event.eventType).toBe('year_end_processed');
      expect(event.payload['ledgerHash']).toBeDefined();
    });

  });

  describe('A8 — Bulk approval & simulation diff', () => {

    it('A8.1 | Bulk approve: short requests auto-approved', () => {
      const requests = [
        { requestId: 'r1', employeeId: 'emp-1', employeeName: 'A', leaveTypeCode: 'EL', startDate: '2025-03-01', endDate: '2025-03-02', days: 2, status: 'pending' as const },
        { requestId: 'r2', employeeId: 'emp-2', employeeName: 'B', leaveTypeCode: 'CL', startDate: '2025-03-05', endDate: '2025-03-05', days: 1, status: 'pending' as const },
      ];
      const result = bulkApproveRequests(requests, { autoApproveBeforeFreeze: true, maxDaysForAutoApprove: 3, requiresManagerApprovalAbove: 5 });
      expect(result.approved).toContain('r1');
      expect(result.approved).toContain('r2');
    });

    it('A8.2 | Bulk approve: long requests go to manager queue', () => {
      const requests = [
        { requestId: 'r3', employeeId: 'emp-3', employeeName: 'C', leaveTypeCode: 'EL', startDate: '2025-02-01', endDate: '2025-02-10', days: 10, status: 'pending' as const },
      ];
      const result = bulkApproveRequests(requests, { autoApproveBeforeFreeze: true, maxDaysForAutoApprove: 3, requiresManagerApprovalAbove: 5 });
      expect(result.skipped).toContain('r3');
      expect(result.approved).not.toContain('r3');
    });

    it('A8.3 | Simulation diff: identical → no diffs', () => {
      const sim = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true).computed;
      const diffs = diffSimulationVsActual(sim, sim);
      expect(diffs).toHaveLength(0);
    });

    it('A8.4 | Simulation diff: changed used days → detected diff', () => {
      const sim = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, SNAPSHOTS, LEAVE_TYPES, true).computed;
      const modified = SNAPSHOTS.map((s, i) => i === 0 ? { ...s, used: s.used + 5 } : s);
      const actual = processBatchYearEnd(TENANT_ID, FIN_YEAR_CONFIG, modified, LEAVE_TYPES, false).computed;
      const diffs = diffSimulationVsActual(sim, actual);
      expect(diffs.length).toBeGreaterThan(0);
    });

  });

});

// ─────────────────────────────────────────────────────────────────────────────
// ═══ SECTION B — ROLE & PERMISSION ENGINE ═══
// ─────────────────────────────────────────────────────────────────────────────

describe('SECTION B — Role & Permission Engine', () => {

  describe('B1 — System roles', () => {

    it('B1.1 | buildSystemRoles returns 4 system roles', () => {
      expect(SYSTEM_ROLES).toHaveLength(4);
    });

    it('B1.2 | All system roles have isSystem=true', () => {
      expect(SYSTEM_ROLES.every(r => r.isSystem)).toBe(true);
    });

    it('B1.3 | HR role has payroll module access', () => {
      expect(HR_ROLE!.allowedModules).toContain('payroll');
      expect(HR_ROLE!.allowedModules).toContain('leave');
    });

    it('B1.4 | Finance role does NOT have core-hr module', () => {
      expect(FINANCE_ROLE!.allowedModules).not.toContain('core-hr');
    });

    it('B1.5 | Employee role: own-only condition on leave:request', () => {
      const perm = EMPLOYEE_ROLE!.permissions.find(p => p.resource === 'leave:request');
      expect(perm).toBeDefined();
      const ownOnly = perm!.conditions?.some(c => c.operator === 'own-only');
      expect(ownOnly).toBe(true);
    });

  });

  describe('B2 — Custom role creation', () => {

    it('B2.1 | Creates valid custom role', () => {
      const role = createCustomRole(TENANT_ID, {
        name: 'senior-manager',
        displayName: 'Senior Manager',
        description: 'Manages cross-department teams',
        allowedModules: ['core-hr', 'leave', 'attendance', 'performance'],
        permissions: [{ resource: 'employee', module: 'core-hr', actions: ['read'] }],
        menuVisibility: { 'nav-employees': true },
      }, 'admin-user');
      expect(role.name).toBe('senior-manager');
      expect(role.isSystem).toBe(false);
      expect(role.tenantId).toBe(TENANT_ID);
    });

    it('B2.2 | Rejects invalid role name (spaces)', () => {
      let threw = false;
      try {
        createCustomRole(TENANT_ID, {
          name: 'Senior Manager',  // has space — invalid
          displayName: 'x', description: 'x',
          allowedModules: ['leave'], permissions: [], menuVisibility: {},
        }, 'admin');
      } catch { threw = true; }
      expect(threw).toBe(true);
    });

    it('B2.3 | Rejects unknown module', () => {
      let threw = false;
      try {
        createCustomRole(TENANT_ID, {
          name: 'custom',
          displayName: 'x', description: 'x',
          allowedModules: ['non-existent-module' as any],
          permissions: [], menuVisibility: {},
        }, 'admin');
      } catch { threw = true; }
      expect(threw).toBe(true);
    });

  });

  describe('B3 — Role cloning', () => {

    it('B3.1 | Clone inherits permissions and modules from source', () => {
      const clone = cloneRole(MANAGER_ROLE!, { name: 'senior-manager-clone' }, 'admin');
      expect(clone.allowedModules).toEqual(MANAGER_ROLE!.allowedModules);
      expect(clone.permissions.length).toBe(MANAGER_ROLE!.permissions.length);
      expect(clone.isSystem).toBe(false);  // Clone is never system
    });

    it('B3.2 | Clone with override changes specified fields only', () => {
      const clone = cloneRole(MANAGER_ROLE!, {
        name: 'restricted-manager',
        allowedModules: ['leave'],
      }, 'admin');
      expect(clone.allowedModules).toEqual(['leave']);
      expect(clone.description).toBe(MANAGER_ROLE!.description);
    });

    it('B3.3 | Clone gets a different ID than source', () => {
      const clone = cloneRole(HR_ROLE!, { name: 'hr-lite' }, 'admin');
      expect(clone.id).not.toBe(HR_ROLE!.id);
    });

    it('B3.4 | Cloning with invalid name throws', () => {
      let threw = false;
      try { cloneRole(HR_ROLE!, { name: 'HR Lite' }, 'admin'); }
      catch { threw = true; }
      expect(threw).toBe(true);
    });

  });

  describe('B4 — Permission enforcement', () => {

    it('B4.1 | HR role can read employees', () => {
      const r = canAccess(makeCtx([HR_ROLE!]), 'core-hr', 'employee', 'read');
      expect(r.allowed).toBe(true);
    });

    it('B4.2 | Finance role CANNOT access core-hr/employee (module gate)', () => {
      const r = canAccess(makeCtx([FINANCE_ROLE!]), 'core-hr', 'employee', 'read');
      expect(r.allowed).toBe(false);
    });

    it('B4.3 | Finance role CAN approve payroll runs', () => {
      const r = canAccess(makeCtx([FINANCE_ROLE!]), 'payroll', 'payroll:run', 'approve');
      expect(r.allowed).toBe(true);
    });

    it('B4.4 | Manager role CANNOT delete employees', () => {
      const r = canAccess(makeCtx([MANAGER_ROLE!]), 'core-hr', 'employee', 'delete');
      expect(r.allowed).toBe(false);
    });

    it('B4.5 | Employee role CANNOT access payroll (module blocked)', () => {
      const r = canAccess(makeCtx([EMPLOYEE_ROLE!]), 'payroll', 'payroll:run', 'read');
      expect(r.allowed).toBe(false);
    });

    it('B4.6 | Employee own-only: access own record → allowed', () => {
      const ctx = makeCtx([EMPLOYEE_ROLE!], [], { employeeId: 'user-001' });
      ctx.userId = 'user-001';
      const r = canAccess(ctx, 'leave', 'leave:request', 'create');
      expect(r.allowed).toBe(true);
    });

    it('B4.7 | Employee own-only: access other employee record → denied', () => {
      const ctx = makeCtx([EMPLOYEE_ROLE!], [], { employeeId: 'user-999' });
      ctx.userId = 'user-001';
      const r = canAccess(ctx, 'leave', 'leave:request', 'read');
      expect(r.allowed).toBe(false);
    });

    it('B4.8 | enforceAccess: denied call is added to audit log', () => {
      const auditLog: any[] = [];
      const r = enforceAccess(makeCtx([EMPLOYEE_ROLE!]), 'payroll', 'payroll:run', 'approve', auditLog);
      expect(r.allowed).toBe(false);
      expect(auditLog.length).toBe(1);
      expect(auditLog[0].action).toBe('access_denied');
    });

  });

  describe('B5 — Module access & menu visibility', () => {

    it('B5.1 | HR role modules include leave and payroll-tds', () => {
      const modules = getAccessibleModules(makeCtx([HR_ROLE!]));
      expect(modules).toContain('leave');
      expect(modules).toContain('payroll-tds');
    });

    it('B5.2 | Employee role: payroll module not accessible', () => {
      expect(isModuleAccessible(makeCtx([EMPLOYEE_ROLE!]), 'payroll')).toBe(false);
    });

    it('B5.3 | HR menu: payroll and leave nodes visible', () => {
      const menu = buildVisibleMenu(makeCtx([HR_ROLE!]), MENU_TREE);
      const ids = menu.map(n => n.id);
      expect(ids).toContain('nav-payroll');
      expect(ids).toContain('nav-leave');
    });

    it('B5.4 | Finance menu: leave node NOT visible', () => {
      const menu = buildVisibleMenu(makeCtx([FINANCE_ROLE!]), MENU_TREE);
      const ids = menu.map(n => n.id);
      expect(ids).not.toContain('nav-leave');
    });

    it('B5.5 | Employee menu: settings node not visible', () => {
      const menu = buildVisibleMenu(makeCtx([EMPLOYEE_ROLE!]), MENU_TREE);
      const ids = menu.map(n => n.id);
      expect(ids).not.toContain('nav-settings');
    });

  });

  describe('B6 — Field-level masking', () => {

    it('B6.1 | Manager role masks salary for employee read', () => {
      const record = { name: 'Arjun', salary: 100_000, designation: 'SWE' };
      const masked = maskRecord(record, makeCtx([MANAGER_ROLE!]), 'employee');
      expect(masked.salary).toBe('****');
      expect(masked.name).toBe('Arjun');
    });

    it('B6.2 | HR role: no global masks — full record visible', () => {
      const record = { name: 'Arjun', salary: 100_000, panNumber: 'ABCPM1234A' };
      const masked = maskRecord(record, makeCtx([HR_ROLE!]), 'employee');
      expect(masked.salary).toBe(100_000);
      expect(masked.panNumber).toBe('ABCPM1234A');
    });

    it('B6.3 | Finance role: per-permission maskedFields applied', () => {
      const masked = getMaskedFields(makeCtx([FINANCE_ROLE!]), 'employee');
      expect(masked).toContain('bankAccountNumber');
      expect(masked).toContain('panNumber');
    });

    it('B6.4 | Employee role: no masked fields (sees own record fully)', () => {
      const masked = getMaskedFields(makeCtx([EMPLOYEE_ROLE!]), 'employee');
      expect(masked).not.toContain('salary');
    });

  });

  describe('B7 — Role simulation', () => {

    it('B7.1 | simulateRole: manager read performance → allowed ({{userId}} substitution)', () => {
      // The manager role's performance permission has condition: employee.managerId eq {{userId}}
      // The simulatedCtx.userId = 'simulated-user'; we provide managerId matching it
      // {{userId}} substitution in evaluateConditions makes this pass
      const result = simulateRole(MANAGER_ROLE!, {
        targetRoleId: MANAGER_ROLE!.id,
        resource: 'performance',
        module: 'performance',
        action: 'read',
        simulatedContext: { managerId: 'simulated-user' },  // satisfies {{userId}} condition
      }, MENU_TREE);
      expect(result.allowed).toBe(true);
      // salary is globally masked for manager role
      expect(result.maskedFields).toContain('salary');
    });

    it('B7.2 | simulateRole: finance approve leave → denied (wrong module)', () => {
      const result = simulateRole(FINANCE_ROLE!, {
        targetRoleId: FINANCE_ROLE!.id,
        resource: 'leave:request',
        module: 'leave',
        action: 'approve',
      }, MENU_TREE);
      expect(result.allowed).toBe(false);
    });

    it('B7.3 | simulateRole: visible menu count non-zero for HR', () => {
      const result = simulateRole(HR_ROLE!, {
        targetRoleId: HR_ROLE!.id,
        resource: 'employee',
        module: 'core-hr',
        action: 'read',
      }, MENU_TREE);
      expect(result.visibleMenuCount).toBeGreaterThan(0);
    });

  });

  describe('B8 — Temporary elevation', () => {

    it('B8.1 | Grant elevation: produces valid elevation with expiry', () => {
      const elev = grantTemporaryElevation({
        userId: 'user-emp-1',
        tenantId: TENANT_ID,
        targetRoleId: HR_ROLE!.id,
        targetRoleName: 'hr-admin',
        reason: 'Coverage for HR manager on leave — 4-hour window',
        durationHours: 4,
        grantedBy: 'admin-001',
      });
      expect(elev.isRevoked).toBe(false);
      expect(elev.expiresAt.getTime()).toBeGreaterThan(Date.now());
      expect(elev.auditToken).toMatch(/^elv-/);
    });

    it('B8.2 | Elevation too long → throws', () => {
      let threw = false;
      try {
        grantTemporaryElevation({
          userId: 'u1', tenantId: TENANT_ID,
          targetRoleId: HR_ROLE!.id, targetRoleName: 'hr-admin',
          reason: 'reason', durationHours: 999, grantedBy: 'admin',
        });
      } catch { threw = true; }
      expect(threw).toBe(true);
    });

    it('B8.3 | Elevation without reason → throws', () => {
      let threw = false;
      try {
        grantTemporaryElevation({
          userId: 'u1', tenantId: TENANT_ID,
          targetRoleId: HR_ROLE!.id, targetRoleName: 'hr-admin',
          reason: '   ', durationHours: 2, grantedBy: 'admin',
        });
      } catch { threw = true; }
      expect(threw).toBe(true);
    });

    it('B8.4 | isElevationActive: active elevation → true', () => {
      const elev = grantTemporaryElevation({
        userId: 'u1', tenantId: TENANT_ID, targetRoleId: 'r1', targetRoleName: 'hr',
        reason: 'test', durationHours: 2, grantedBy: 'admin',
      });
      expect(isElevationActive(elev)).toBe(true);
    });

    it('B8.5 | isElevationActive: expired elevation → false', () => {
      const elev = grantTemporaryElevation({
        userId: 'u1', tenantId: TENANT_ID, targetRoleId: 'r1', targetRoleName: 'hr',
        reason: 'test', durationHours: 1, grantedBy: 'admin',
      });
      const futureDate = new Date(elev.expiresAt.getTime() + 1000);
      expect(isElevationActive(elev, futureDate)).toBe(false);
    });

    it('B8.6 | revokeElevation: sets isRevoked=true', () => {
      const elev = grantTemporaryElevation({
        userId: 'u1', tenantId: TENANT_ID, targetRoleId: 'r1', targetRoleName: 'hr',
        reason: 'test', durationHours: 2, grantedBy: 'admin',
      });
      const revoked = revokeElevation(elev, 'admin-001');
      expect(revoked.isRevoked).toBe(true);
      expect(revoked.revokedBy).toBe('admin-001');
      expect(isElevationActive(revoked)).toBe(false);
    });

    it('B8.7 | Revoking already-revoked elevation → throws', () => {
      let threw = false;
      try {
        const elev = grantTemporaryElevation({
          userId: 'u1', tenantId: TENANT_ID, targetRoleId: 'r1', targetRoleName: 'hr',
          reason: 'test', durationHours: 2, grantedBy: 'admin',
        });
        const rev = revokeElevation(elev, 'admin');
        revokeElevation(rev, 'admin');  // Double-revoke
      } catch { threw = true; }
      expect(threw).toBe(true);
    });

    it('B8.8 | Temporary elevation grants access to elevated resource', () => {
      // Employee role + HR elevation → can approve leave year-end
      const elev = grantTemporaryElevation({
        userId: 'u1', tenantId: TENANT_ID,
        targetRoleId: HR_ROLE!.id, targetRoleName: 'hr-admin',
        reason: 'Coverage for HR manager on leave', durationHours: 4, grantedBy: 'admin',
      });
      const ctx: UserPermissionContext = {
        userId: 'u1', tenantId: TENANT_ID,
        roleIds: [EMPLOYEE_ROLE!.id],
        roles: [EMPLOYEE_ROLE!],          // Employee is the only PERMANENT role
        allAvailableRoles: [EMPLOYEE_ROLE!, HR_ROLE!],  // HR_ROLE available for elevation lookup
        activeElevations: [elev],
        requestContext: {},
      };
      const r = canAccess(ctx, 'leave', 'leave:year-end', 'approve');
      expect(r.allowed).toBe(true);
      expect(r.isElevated).toBe(true);  // Granted via elevation, not permanent role
    });

  });

  describe('B9 — Audit logging', () => {

    it('B9.1 | auditRoleCreated: event type and metadata correct', () => {
      const role = createCustomRole(TENANT_ID, {
        name: 'audit-test', displayName: 'Audit Test', description: 'test',
        allowedModules: ['leave'], permissions: [], menuVisibility: {},
      }, 'admin');
      const event = auditRoleCreated(role, 'admin');
      expect(event.action).toBe('role_created');
      expect(event.metadata['roleName']).toBe('audit-test');
    });

    it('B9.2 | auditRoleCloned: records source and clone names', () => {
      const clone = cloneRole(HR_ROLE!, { name: 'hr-lite' }, 'admin');
      const event = auditRoleCloned(HR_ROLE!, clone, 'admin');
      expect(event.action).toBe('role_cloned');
      expect(event.metadata['sourceRoleName']).toBe(HR_ROLE!.name);
    });

    it('B9.3 | auditElevationGranted: includes expiry and audit token', () => {
      const elev = grantTemporaryElevation({
        userId: 'u1', tenantId: TENANT_ID, targetRoleId: HR_ROLE!.id, targetRoleName: 'hr-admin',
        reason: 'audit test', durationHours: 2, grantedBy: 'admin',
      });
      const event = auditElevationGranted(elev);
      expect(event.action).toBe('elevation_granted');
      expect(event.metadata['auditToken']).toBeDefined();
      expect(event.metadata['expiresAt']).toBeDefined();
    });

    it('B9.4 | enforceAccess builds audit trail for allowed access', () => {
      const log: any[] = [];
      enforceAccess(makeCtx([HR_ROLE!]), 'leave', 'leave:request', 'approve', log);
      expect(log.length).toBe(1);
      expect(log[0].action).toBe('access_allowed');
    });

  });

});

// ─────────────────────────────────────────────────────────────────────────────
// ═══ SECTION C — EDUCATION MODE ═══
// ─────────────────────────────────────────────────────────────────────────────

const EDU_CONFIG = createEducationTenantConfig(EDU_TENANT_ID, 'Sunrise International School', {
  institutionType: 'school',
  boardAffiliation: 'CBSE',
  payCommission: '7th',
});

const EDU_ROLES = buildEducationRoles(EDU_TENANT_ID, 'principal-001');
const [TEACHER_ROLE, HOD_ROLE, PRINCIPAL_ROLE, BURSAR_ROLE] = EDU_ROLES;

const SCHOOL_STAFF: StaffRecord[] = [
  ...Array.from({ length: 6 }, (_, i) => ({
    employeeId: `t-0${i + 1}`,
    name: `Teacher ${i + 1}`,
    staffType: 'teaching' as const,
    facultyId: i < 3 ? 'fac-science' : 'fac-arts',
    facultyName: i < 3 ? 'Science Faculty' : 'Arts Faculty',
    designation: 'PGT',
    joinDate: '2024-06-01',
    isActive: true,
  })),
  ...Array.from({ length: 3 }, (_, i) => ({
    employeeId: `nt-0${i + 1}`,
    name: `Non-Teaching ${i + 1}`,
    staffType: 'non-teaching' as const,
    facultyId: 'fac-admin',
    facultyName: 'Administration',
    designation: 'Office Assistant',
    joinDate: '2024-06-01',
    isActive: true,
  })),
  {
    employeeId: 'admin-001',
    name: 'Principal Staff',
    staffType: 'admin' as const,
    facultyId: 'fac-admin',
    facultyName: 'Administration',
    designation: 'Administrative Officer',
    joinDate: '2024-06-01',
    isActive: true,
  },
];

describe('SECTION C — Education Mode', () => {

  describe('C1 — Config & terminology', () => {

    it('C1.1 | Education mode enabled in config', () => {
      expect(EDU_CONFIG.isEducationMode).toBe(true);
    });

    it('C1.2 | Terminology: "employee" → "Staff"', () => {
      expect(getTerm(EDU_CONFIG, 'employee')).toBe('Staff');
    });

    it('C1.3 | Terminology: "employees" → "Staff Members"', () => {
      expect(getTerm(EDU_CONFIG, 'employees')).toBe('Staff Members');
    });

    it('C1.4 | Terminology: "department" → "Faculty"', () => {
      expect(getTerm(EDU_CONFIG, 'department')).toBe('Faculty');
    });

    it('C1.5 | Terminology: "manager" → Head of Department (HOD)', () => {
      expect(getTerm(EDU_CONFIG, 'manager')).toContain('HOD');
    });

    it('C1.6 | Corporate mode returns corporate terminology', () => {
      const corpConfig = { ...EDU_CONFIG, isEducationMode: false };
      expect(getTerm(corpConfig, 'employee')).toBe('Employee');
      expect(getTerm(corpConfig, 'department')).toBe('Department');
    });

    it('C1.7 | Leave year type is "academic"', () => {
      expect(EDU_CONFIG.leaveYearType).toBe('academic');
    });

    it('C1.8 | Academic year start = June (month 6)', () => {
      expect(EDU_CONFIG.academicYearStartMonth).toBe(6);
      expect(EDU_CONFIG.academicYearEndMonth).toBe(5);
    });

  });

  describe('C2 — Academic year utilities', () => {

    it('C2.1 | AY 2024-25: starts Jun 2024, ends May 2025', () => {
      const ay = buildAcademicYear(EDU_CONFIG, 2024);
      expect(ay.startDate.getMonth()).toBe(5);    // June
      expect(ay.endDate.getFullYear()).toBe(2025);
      expect(ay.endDate.getMonth()).toBe(4);      // May
      expect(ay.label).toBe('AY 2024-25');
    });

    it('C2.2 | Date in March 2025 → AY 2024-25', () => {
      const ay = getAcademicYearForDate(EDU_CONFIG, new Date('2025-03-15'));
      expect(ay.startYear).toBe(2024);
      expect(ay.label).toBe('AY 2024-25');
    });

    it('C2.3 | Date in July 2025 → AY 2025-26', () => {
      const ay = getAcademicYearForDate(EDU_CONFIG, new Date('2025-07-01'));
      expect(ay.startYear).toBe(2025);
    });

    it('C2.4 | getCurrentAcademicYear returns valid AY object', () => {
      const ay = getCurrentAcademicYear(EDU_CONFIG, new Date('2025-01-01'));
      expect(ay.label).toBeDefined();
      expect(ay.startDate).toBeDefined();
    });

  });

  describe('C3 — Education roles', () => {

    it('C3.1 | buildEducationRoles returns 4 roles', () => {
      expect(EDU_ROLES).toHaveLength(4);
    });

    it('C3.2 | Teacher role: only leaf modules (leave, attendance, lnd, education)', () => {
      expect(TEACHER_ROLE!.allowedModules).toContain('leave');
      expect(TEACHER_ROLE!.allowedModules).toContain('attendance');
      expect(TEACHER_ROLE!.allowedModules).not.toContain('payroll');
    });

    it('C3.3 | Principal role: can approve payroll runs', () => {
      const perm = PRINCIPAL_ROLE!.permissions.find(p => p.resource === 'payroll:run');
      expect(perm?.actions).toContain('approve');
    });

    it('C3.4 | HOD role: salary masked for department employees', () => {
      expect(HOD_ROLE!.globalMaskedFields).toContain('salary');
    });

    it('C3.5 | Bursar role: manages full payroll lifecycle', () => {
      const payrollPerm = BURSAR_ROLE!.permissions.find(p => p.resource === 'payroll:run');
      expect(payrollPerm?.actions).toContain('create');
      expect(payrollPerm?.actions).toContain('approve');
    });

    it('C3.6 | Teacher role: own-only condition on leave requests', () => {
      const perm = TEACHER_ROLE!.permissions.find(p => p.resource === 'leave:request');
      const ownOnly = perm?.conditions?.some(c => c.operator === 'own-only');
      expect(ownOnly).toBe(true);
    });

  });

  describe('C4 — Module restrictions', () => {

    it('C4.1 | Recruitment module disabled in education mode', () => {
      const r = isModuleAllowedInEducationMode(EDU_CONFIG, 'recruitment');
      expect(r.allowed).toBe(false);
      expect(r.reason).toContain('recruitment');
    });

    it('C4.2 | Expense module disabled in education mode', () => {
      const r = isModuleAllowedInEducationMode(EDU_CONFIG, 'expense');
      expect(r.allowed).toBe(false);
    });

    it('C4.3 | Payroll module enabled in education mode', () => {
      const r = isModuleAllowedInEducationMode(EDU_CONFIG, 'payroll');
      expect(r.allowed).toBe(true);
    });

    it('C4.4 | Leave module enabled in education mode', () => {
      const r = isModuleAllowedInEducationMode(EDU_CONFIG, 'leave');
      expect(r.allowed).toBe(true);
    });

    it('C4.5 | Education mode toggle: enable records required actions', () => {
      const corpConfig = { isEducationMode: false };
      const result = toggleEducationMode(EDU_TENANT_ID, corpConfig, true, false);
      expect(result.success).toBe(true);
      expect(result.newMode).toBe('education');
      expect(result.requiredActions.length).toBeGreaterThan(0);
      expect(result.requiredActions.some(a => a.includes('academic year'))).toBe(true);
    });

    it('C4.6 | Toggle to same state: success=false, no change', () => {
      const result = toggleEducationMode(EDU_TENANT_ID, { isEducationMode: true }, true, false);
      expect(result.success).toBe(false);
    });

  });

  describe('C5 — Tenant isolation', () => {

    it('C5.1 | Same tenant, same mode → isolated=true', () => {
      const r = verifyTenantIsolation(EDU_TENANT_ID, { isEducationMode: true }, EDU_TENANT_ID, { isEducationMode: true });
      expect(r.isolated).toBe(true);
    });

    it('C5.2 | Cross-tenant access → isolated=false (violation)', () => {
      const r = verifyTenantIsolation('corp-tenant', { isEducationMode: false }, EDU_TENANT_ID, { isEducationMode: true });
      expect(r.isolated).toBe(false);
      expect(r.violations.some(v => v.includes('Cross-tenant'))).toBe(true);
    });

    it('C5.3 | Education tenant requesting corporate tenant → mode mismatch', () => {
      const r = verifyTenantIsolation(EDU_TENANT_ID, { isEducationMode: true }, 'corp-tenant', { isEducationMode: false });
      expect(r.isolated).toBe(false);
      expect(r.violations.some(v => v.includes('Mode mismatch'))).toBe(true);
    });

    it('C5.4 | buildSchoolDashboard throws for non-education config', () => {
      const corpConfig = { ...EDU_CONFIG, isEducationMode: false };
      let threw = false;
      try { buildSchoolDashboard(corpConfig, SCHOOL_STAFF, { pendingApprovals: 0, averageEarnedLeaveBalance: 10, staffOnLeaveToday: 0 }, { lastPayrollRunDate: null, pendingApprovals: 0, payCommissionDistribution: {} }); }
      catch { threw = true; }
      expect(threw).toBe(true);
    });

  });

  describe('C6 — School dashboard', () => {

    const leaveStats = { pendingApprovals: 3, averageEarnedLeaveBalance: 22, staffOnLeaveToday: 1 };
    const payrollStats = { lastPayrollRunDate: '2025-01-31', pendingApprovals: 0, payCommissionDistribution: { 'Level 10': 4, 'Level 11': 3 } };

    it('C6.1 | Dashboard: correct total staff count (10)', () => {
      const dash = buildSchoolDashboard(EDU_CONFIG, SCHOOL_STAFF, leaveStats, payrollStats);
      expect(dash.totalStaff).toBe(10);
    });

    it('C6.2 | Dashboard: teaching vs non-teaching breakdown', () => {
      const dash = buildSchoolDashboard(EDU_CONFIG, SCHOOL_STAFF, leaveStats, payrollStats);
      expect(dash.teachingStaff).toBe(6);
      expect(dash.nonTeachingStaff).toBe(3);
      expect(dash.adminStaff).toBe(1);
    });

    it('C6.3 | Dashboard: faculty grouping (Science + Arts + Admin)', () => {
      const dash = buildSchoolDashboard(EDU_CONFIG, SCHOOL_STAFF, leaveStats, payrollStats);
      expect(dash.byFaculty.length).toBe(3);
      const science = dash.byFaculty.find(f => f.facultyId === 'fac-science');
      expect(science?.teachingCount).toBe(3);
    });

    it('C6.4 | Dashboard: academic year label present', () => {
      const dash = buildSchoolDashboard(EDU_CONFIG, SCHOOL_STAFF, leaveStats, payrollStats);
      expect(dash.academicYearLabel).toMatch(/^AY \d{4}-\d{2}$/);
    });

    it('C6.5 | Dashboard: institution type correct', () => {
      const dash = buildSchoolDashboard(EDU_CONFIG, SCHOOL_STAFF, leaveStats, payrollStats);
      expect(dash.institutionType).toBe('school');
    });

  });

  describe('C7 — Payroll run validation (education)', () => {

    it('C7.1 | Valid payroll run passes', () => {
      const r = validateEducationPayrollRun(EDU_CONFIG, { month: 1, year: 2025, staffIds: ['t-01', 't-02'] });
      expect(r.isValid).toBe(true);
      expect(r.payCommissionApplied).toBe('7th');
    });

    it('C7.2 | Empty staffIds → invalid', () => {
      const r = validateEducationPayrollRun(EDU_CONFIG, { month: 1, year: 2025, staffIds: [] });
      expect(r.isValid).toBe(false);
    });

    it('C7.3 | April payroll → DA arrears warning', () => {
      const r = validateEducationPayrollRun(EDU_CONFIG, { month: 4, year: 2025, staffIds: ['t-01'] });
      expect(r.warnings.some(w => w.includes('DA hike'))).toBe(true);
    });

    it('C7.4 | May/June payroll → VL warning for teaching staff', () => {
      const r = validateEducationPayrollRun(EDU_CONFIG, { month: 5, year: 2025, staffIds: ['t-01'] });
      expect(r.warnings.some(w => w.includes('Vacation Leave'))).toBe(true);
    });

    it('C7.5 | Non-education config → no education-specific warnings', () => {
      const corp = { ...EDU_CONFIG, isEducationMode: false };
      const r = validateEducationPayrollRun(corp, { month: 4, year: 2025, staffIds: ['emp-1'] });
      expect(r.isValid).toBe(true);
      expect(r.warnings).toHaveLength(0);
    });

  });

  describe('C8 — Principal workflow (academic leave close)', () => {

    it('C8.1 | Workflow initializes with 5 steps, status=pending', () => {
      const wf = initializeLeaveCloseWorkflow(EDU_CONFIG, 'AY 2024-25');
      expect(wf.steps).toHaveLength(5);
      expect(wf.status).toBe('pending');
    });

    it('C8.2 | Completing step 1 → status in-progress', () => {
      const wf = initializeLeaveCloseWorkflow(EDU_CONFIG, 'AY 2024-25');
      const updated = advanceWorkflowStep(wf, 'step-1-verify', 'hr-user-1', 'All records verified');
      expect(updated.status).toBe('in-progress');
      expect(updated.steps.find(s => s.stepId === 'step-1-verify')?.isCompleted).toBe(true);
    });

    it('C8.3 | Steps 1-3 complete → status=pending-principal', () => {
      let wf = initializeLeaveCloseWorkflow(EDU_CONFIG, 'AY 2024-25');
      wf = advanceWorkflowStep(wf, 'step-1-verify', 'hr-1');
      wf = advanceWorkflowStep(wf, 'step-2-simulate', 'hr-1');
      wf = advanceWorkflowStep(wf, 'step-3-bursar', 'bursar-1');
      expect(wf.status).toBe('pending-principal');
    });

    it('C8.4 | All steps complete → status=approved, approvedAt set', () => {
      let wf = initializeLeaveCloseWorkflow(EDU_CONFIG, 'AY 2024-25');
      for (const step of wf.steps) {
        wf = advanceWorkflowStep(wf, step.stepId, `user-${step.stepId}`);
      }
      expect(wf.status).toBe('approved');
      expect(wf.approvedAt).toBeDefined();
    });

    it('C8.5 | Workflow ID includes tenant and academic year', () => {
      const wf = initializeLeaveCloseWorkflow(EDU_CONFIG, 'AY 2024-25');
      expect(wf.workflowId).toContain(EDU_TENANT_ID);
    });

  });

  describe('C9 — Academic leave year-end integration', () => {

    it('C9.1 | Academic year config for education leave year-end', () => {
      const eduLeaveConfig: LeaveYearConfig = {
        yearType: 'academic',
        closingYear: 2024,
        freezeWindowStart: '2025-05-20',
        freezeWindowEnd: '2025-06-05',
        encashmentRatePerDay: 2_000,
        currency: 'INR',
      };
      // 10 teachers, EL leave type
      const eduSnapshots: EmployeeLeaveSnapshot[] = SCHOOL_STAFF
        .filter(s => s.staffType === 'teaching')
        .map(s => makeSnapshot(s.employeeId, s.name, 'lt-el', 30, 15, 0, 0));

      const result = processBatchYearEnd(EDU_TENANT_ID, eduLeaveConfig, eduSnapshots, LEAVE_TYPES, true);
      expect(result.totalEmployees).toBe(6);
      expect(result.yearType).toBe('academic');
      expect(result.closingYear).toBe(2024);
    });

    it('C9.2 | Ledger consistency holds for academic year-end', () => {
      const eduLeaveConfig: LeaveYearConfig = {
        yearType: 'academic',
        closingYear: 2024,
        freezeWindowStart: '2025-05-20',
        freezeWindowEnd: '2025-06-05',
        encashmentRatePerDay: 2_000,
        currency: 'INR',
      };
      const snapshots = SCHOOL_STAFF
        .filter(s => s.staffType === 'teaching')
        .map(s => makeSnapshot(s.employeeId, s.name, 'lt-el', 30, 10, 0, 0));
      const result = processBatchYearEnd(EDU_TENANT_ID, eduLeaveConfig, snapshots, LEAVE_TYPES, true);
      const check = verifyLedgerConsistency(result.computed);
      expect(check.isConsistent).toBe(true);
    });

    it('C9.3 | Staff onboarding: teaching staff with no qualifications → warning', () => {
      const r = validateStaffOnboarding(EDU_CONFIG, {
        name: 'New Teacher', staffType: 'teaching',
        designation: 'PGT', qualifications: [], joinDate: '2024-06-01',
      });
      expect(r.isValid).toBe(true);  // warnings don't fail validation
      expect(r.warnings.some(w => w.includes('qualifications'))).toBe(true);
    });

    it('C9.4 | Staff onboarding: missing name → error', () => {
      const r = validateStaffOnboarding(EDU_CONFIG, {
        name: '', staffType: 'non-teaching', designation: 'Clerk', joinDate: '2024-06-01',
      });
      expect(r.isValid).toBe(false);
      expect(r.errors.some(e => e.includes('name'))).toBe(true);
    });

    it('C9.5 | Teacher leave entitlements: VL only for teaching staff', () => {
      const vl = EDU_CONFIG.teacherLeaveEntitlements.find(e => e.leaveTypeCode === 'VL');
      expect(vl?.applicableStaffTypes).toContain('teaching');
      expect(vl?.applicableStaffTypes).not.toContain('non-teaching');
    });

    it('C9.6 | Teacher EL entitlement: 30 days/year with 300-day carry-forward cap', () => {
      const el = EDU_CONFIG.teacherLeaveEntitlements.find(e => e.leaveTypeCode === 'EL');
      expect(el?.daysPerYear).toBe(30);
      expect(el?.carryForwardDays).toBe(300);    // Government service: large EL accumulation
      expect(el?.encashable).toBe(true);
    });

  });

});

// ─────────────────────────────────────────────────────────────────────────────
// FINAL SUMMARY
// ─────────────────────────────────────────────────────────────────────────────

console.log('\n══════════════════════════════════════════════════════════════');
console.log(`  RESULTS: ${_passed} passed, ${_failed} failed, ${_total} total`);
console.log('══════════════════════════════════════════════════════════════');

const sectionA = _total > 0 ? `Section A (Leave Year-End): ~35 tests` : '';
const sectionB = `Section B (Role Engine): ~30 tests`;
const sectionC = `Section C (Education Mode): ~30 tests`;

if (_failures.length > 0) {
  console.log('\n  FAILURES:');
  _failures.forEach(f => console.log(`\n  ${f}`));
  process.exit(1);
}
