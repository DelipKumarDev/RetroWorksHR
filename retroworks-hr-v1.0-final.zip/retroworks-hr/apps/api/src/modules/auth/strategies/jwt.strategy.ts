/**
 * SECURITY AUDIT-01: JWT Strategy — Hardened
 * ────────────────────────────────────────────────────────────────────────────
 * FIXED C-01a: Removed `?? 'fallback-secret'`. App crashes on boot if
 *              JWT_SECRET is absent or weak. env-validator.ts + this = dual safety.
 *
 * FIXED C-01b: Session revocation is now ACTIVE (was commented out).
 *              Logout, role change, account suspension, password reset all
 *              immediately invalidate session. JWT within TTL is rejected.
 */

import { Injectable, UnauthorizedException, Logger } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { PrismaClient } from '@prisma/client';
import type { JwtPayload } from '@retroworks/types';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
  private readonly logger = new Logger(JwtStrategy.name);

  constructor(
    private readonly config: ConfigService,
    private readonly prisma: PrismaClient,
  ) {
    const jwtSecret = config.get<string>('app.jwt.secret');

    // FIXED: No fallback. Missing secret = hard crash at boot.
    if (!jwtSecret || jwtSecret.length < 64) {
      throw new Error(
        '[SECURITY] JWT_SECRET missing or too short. ' +
        'Generate: node -e "console.log(require(\'crypto\').randomBytes(64).toString(\'hex\'))"',
      );
    }

    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: jwtSecret, // FIXED: no ?? fallback
    });
  }

  async validate(payload: JwtPayload): Promise<JwtPayload> {
    // FIXED: Session revocation — ACTIVE (was commented out before this audit)
    const session = await this.prisma.session.findFirst({
      where: {
        userId: payload.sub,
        expiresAt: { gt: new Date() },
        revokedAt: null,
      },
      select: { id: true },
    });

    if (!session) {
      this.logger.warn(
        `[SECURITY] JWT rejected — no active session: user=${payload.sub} tid=${payload.tid}`,
      );
      throw new UnauthorizedException('Session expired or revoked. Please log in again.');
    }

    const user = await this.prisma.user.findFirst({
      where: { id: payload.sub, tenantId: payload.tid, isActive: true, deletedAt: null },
      select: { id: true, isActive: true, lockedUntil: true },
    });

    if (!user || !user.isActive) {
      this.logger.warn(`[SECURITY] JWT rejected — account inactive: ${payload.sub}`);
      throw new UnauthorizedException('Account is inactive or not found');
    }

    if (user.lockedUntil && user.lockedUntil > new Date()) {
      throw new UnauthorizedException('Account is temporarily locked');
    }

    return payload;
  }
}
