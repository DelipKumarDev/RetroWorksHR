import { Test, type TestingModule } from '@nestjs/testing';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { UnauthorizedException, BadRequestException } from '@nestjs/common';
import { AuthService } from '../auth.service';

// ─────────────────────────────────────────────
// Mocks
// ─────────────────────────────────────────────

const mockUser = {
  id: 'user-123',
  tenantId: 'tenant-123',
  email: 'test@acme.com',
  name: 'Test User',
  passwordHash: '$2a$12$mockhashedpassword',
  isActive: true,
  mfaEnabled: false,
  lockedUntil: null,
  failedLoginCount: 0,
  avatarUrl: null,
  employeeId: null,
  tenant: { id: 'tenant-123', name: 'Acme', slug: 'acme', isActive: true },
  roles: [{ role: { name: 'employee', permissions: [] } }],
};

const mockPrisma = {
  user: {
    findFirst: jest.fn(),
    findUnique: jest.fn(),
    update: jest.fn(),
    create: jest.fn(),
  },
  session: {
    create: jest.fn(),
    findFirst: jest.fn(),
    deleteMany: jest.fn(),
    delete: jest.fn(),
  },
  magicLink: {
    create: jest.fn(),
    findUnique: jest.fn(),
    update: jest.fn(),
    deleteMany: jest.fn(),
  },
};

const mockJwtService = {
  sign: jest.fn().mockReturnValue('mock-access-token'),
  verify: jest.fn(),
};

const mockConfigService = {
  get: jest.fn((key: string) => {
    const config: Record<string, string> = {
      'app.jwt.secret': 'test-secret',
      'app.jwt.expiresIn': '15m',
      'app.jwt.refreshSecret': 'test-refresh-secret',
      'app.jwt.refreshExpiresIn': '7d',
      'app.frontendUrl': 'http://localhost:3000',
      'app.magicLink.expiresInMinutes': '15',
      'app.encryption.key': '',
    };
    return config[key];
  }),
};

const mockEventEmitter = { emit: jest.fn() };

// ─────────────────────────────────────────────
// Tests
// ─────────────────────────────────────────────

describe('AuthService', () => {
  let service: AuthService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: 'PrismaClient', useValue: mockPrisma },
        { provide: JwtService, useValue: mockJwtService },
        { provide: ConfigService, useValue: mockConfigService },
        { provide: EventEmitter2, useValue: mockEventEmitter },
      ],
    }).compile();

    service = module.get<AuthService>(AuthService);
    jest.clearAllMocks();
  });

  // ─────────────────────────────────────────────
  // Login
  // ─────────────────────────────────────────────

  describe('login', () => {
    it('throws UnauthorizedException for unknown email', async () => {
      mockPrisma.user.findFirst.mockResolvedValue(null);

      await expect(
        service.login({ email: 'unknown@test.com', password: 'password' }),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('throws UnauthorizedException for wrong password', async () => {
      mockPrisma.user.findFirst.mockResolvedValue({
        ...mockUser,
        passwordHash: '$2a$12$wronghash..................................',
      });

      await expect(
        service.login({ email: 'test@acme.com', password: 'wrongpassword' }),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('returns MFA challenge when MFA is enabled', async () => {
      mockPrisma.user.findFirst.mockResolvedValue({ ...mockUser, mfaEnabled: true });
      mockPrisma.user.update.mockResolvedValue(mockUser);
      // Mock bcrypt comparison to succeed
      jest.spyOn(require('bcryptjs') as typeof import('bcryptjs'), 'compare').mockResolvedValueOnce(true);

      const result = await service.login({ email: 'test@acme.com', password: 'Admin@123!' });
      expect(result).toHaveProperty('mfaRequired', true);
      expect(result).toHaveProperty('mfaToken');
    });

    it('throws UnauthorizedException for locked account', async () => {
      mockPrisma.user.findFirst.mockResolvedValue({
        ...mockUser,
        lockedUntil: new Date(Date.now() + 10 * 60 * 1000), // Locked for 10 more minutes
      });

      await expect(
        service.login({ email: 'test@acme.com', password: 'any' }),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('throws UnauthorizedException for inactive tenant', async () => {
      mockPrisma.user.findFirst.mockResolvedValue({
        ...mockUser,
        tenant: { ...mockUser.tenant, isActive: false },
      });

      await expect(
        service.login({ email: 'test@acme.com', password: 'any' }),
      ).rejects.toThrow(UnauthorizedException);
    });
  });

  // ─────────────────────────────────────────────
  // Magic Link
  // ─────────────────────────────────────────────

  describe('requestMagicLink', () => {
    it('silently returns for unknown email (no enumeration)', async () => {
      mockPrisma.user.findFirst.mockResolvedValue(null);

      // Should not throw
      await expect(
        service.requestMagicLink({ email: 'unknown@test.com' }),
      ).resolves.toBeUndefined();

      // Should NOT emit event (would reveal email existence)
      expect(mockEventEmitter.emit).not.toHaveBeenCalledWith(
        'auth.magic-link.requested',
        expect.anything(),
      );
    });

    it('creates magic link for valid user', async () => {
      mockPrisma.user.findFirst.mockResolvedValue(mockUser);
      mockPrisma.magicLink.deleteMany.mockResolvedValue({ count: 0 });
      mockPrisma.magicLink.create.mockResolvedValue({ id: 'link-1', token: 'test-token' });

      await service.requestMagicLink({ email: 'test@acme.com' });

      expect(mockPrisma.magicLink.create).toHaveBeenCalled();
      expect(mockEventEmitter.emit).toHaveBeenCalledWith(
        'auth.magic-link.requested',
        expect.objectContaining({ userId: mockUser.id, email: mockUser.email }),
      );
    });
  });

  describe('verifyMagicLink', () => {
    it('throws for invalid token', async () => {
      mockPrisma.magicLink.findUnique.mockResolvedValue(null);

      await expect(
        service.verifyMagicLink({ token: 'invalid-token' }),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('throws for expired magic link', async () => {
      mockPrisma.magicLink.findUnique.mockResolvedValue({
        id: 'link-1',
        token: 'test-token',
        usedAt: null,
        expiresAt: new Date(Date.now() - 1000), // Expired
        user: { ...mockUser },
      });

      await expect(
        service.verifyMagicLink({ token: 'test-token' }),
      ).rejects.toThrow(UnauthorizedException);
    });

    it('throws for already used magic link', async () => {
      mockPrisma.magicLink.findUnique.mockResolvedValue({
        id: 'link-1',
        token: 'test-token',
        usedAt: new Date(), // Already used
        expiresAt: new Date(Date.now() + 60_000),
        user: { ...mockUser },
      });

      await expect(
        service.verifyMagicLink({ token: 'test-token' }),
      ).rejects.toThrow(UnauthorizedException);
    });
  });

  // ─────────────────────────────────────────────
  // Logout
  // ─────────────────────────────────────────────

  describe('logout', () => {
    it('deletes specific session', async () => {
      mockPrisma.session.deleteMany.mockResolvedValue({ count: 1 });

      await service.logout('user-123', 'session-token');

      expect(mockPrisma.session.deleteMany).toHaveBeenCalledWith({
        where: { userId: 'user-123', token: 'session-token' },
      });
    });

    it('deletes all sessions when no token provided', async () => {
      mockPrisma.session.deleteMany.mockResolvedValue({ count: 3 });

      await service.logout('user-123');

      expect(mockPrisma.session.deleteMany).toHaveBeenCalledWith({
        where: { userId: 'user-123' },
      });
    });
  });
});
