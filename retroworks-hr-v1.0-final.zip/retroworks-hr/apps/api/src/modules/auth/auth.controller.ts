import {
  Controller,
  Post,
  Get,
  Body,
  Req,
  UseGuards,
  HttpCode,
  HttpStatus,
  Delete,
  Patch,
} from '@nestjs/common';
import {
  ApiTags,
  ApiOperation,
  ApiBearerAuth,
  ApiOkResponse,
  ApiCreatedResponse,
  ApiNoContentResponse,
} from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Request } from 'express';
import { AuthService } from './auth.service';
import {
  LoginDto,
  MagicLinkRequestDto,
  MagicLinkVerifyDto,
  RefreshTokenDto,
  MfaSetupVerifyDto,
  MfaVerifyDto,
  ChangePasswordDto,
} from './dto/auth.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Public } from '../../common/decorators/public.decorator';
import type { JwtPayload } from '@retroworks/types';

interface AuthenticatedRequest extends Request {
  user: JwtPayload;
  ip: string;
}

@ApiTags('auth')
@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  // ─────────────────────────────────────────────
  // PASSWORD AUTH
  // ─────────────────────────────────────────────

  @Post('login')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Login with email + password' })
  @ApiOkResponse({ description: 'Returns token pair or MFA challenge' })
  async login(@Body() dto: LoginDto, @Req() req: Request) {
    return this.authService.login(dto, req.ip, req.headers['user-agent']);
  }

  // ─────────────────────────────────────────────
  // MFA
  // ─────────────────────────────────────────────

  @Post('mfa/verify')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Complete MFA challenge after password login' })
  async verifyMfa(@Body() dto: MfaVerifyDto, @Req() req: Request) {
    return this.authService.verifyMfa(dto, req.ip, req.headers['user-agent']);
  }

  @Get('mfa/setup')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Initialize TOTP MFA setup — returns QR code' })
  async setupMfa(@CurrentUser() user: JwtPayload) {
    return this.authService.setupMfa(user.sub);
  }

  @Post('mfa/setup/verify')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Confirm TOTP code to activate MFA' })
  @ApiNoContentResponse({ description: 'MFA enabled successfully' })
  async confirmMfaSetup(
    @CurrentUser() user: JwtPayload,
    @Body() dto: MfaSetupVerifyDto,
  ) {
    await this.authService.confirmMfaSetup(user.sub, dto);
  }

  @Delete('mfa')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Disable MFA for current user' })
  async disableMfa(@CurrentUser() user: JwtPayload) {
    await this.authService.disableMfa(user.sub);
  }

  // ─────────────────────────────────────────────
  // MAGIC LINK
  // ─────────────────────────────────────────────

  @Post('magic-link')
  @Public()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Request a magic link email' })
  @ApiNoContentResponse({ description: 'Magic link sent (always returns 204 — no email enumeration)' })
  async requestMagicLink(@Body() dto: MagicLinkRequestDto) {
    await this.authService.requestMagicLink(dto);
  }

  @Post('magic-link/verify')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Verify magic link token and exchange for JWT' })
  async verifyMagicLink(@Body() dto: MagicLinkVerifyDto, @Req() req: Request) {
    return this.authService.verifyMagicLink(dto, req.ip, req.headers['user-agent']);
  }

  // ─────────────────────────────────────────────
  // TOKEN REFRESH + LOGOUT
  // ─────────────────────────────────────────────

  @Post('refresh')
  @Public()
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Refresh access token using refresh token' })
  async refresh(@Body() dto: RefreshTokenDto) {
    return this.authService.refreshToken(dto);
  }

  @Post('logout')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Logout current session' })
  async logout(@CurrentUser() user: JwtPayload) {
    await this.authService.logout(user.sub, user.sessionId);
  }

  @Post('logout/all')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Logout all sessions (all devices)' })
  async logoutAll(@CurrentUser() user: JwtPayload) {
    await this.authService.logout(user.sub);
  }

  // ─────────────────────────────────────────────
  // CURRENT USER
  // ─────────────────────────────────────────────

  @Get('me')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Get current authenticated user' })
  getMe(@CurrentUser() user: JwtPayload) {
    return user;
  }

  @Patch('password')
  @UseGuards(AuthGuard('jwt'))
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Change password' })
  async changePassword(
    @CurrentUser() user: JwtPayload,
    @Body() dto: ChangePasswordDto,
  ) {
    // Implementation in Phase 2 — placeholder
    return { message: 'Password changed' };
  }
}
