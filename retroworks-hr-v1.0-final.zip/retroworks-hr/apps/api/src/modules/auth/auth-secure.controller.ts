/**
 * SECURITY FIX H-09 — Secure Auth Controller
 * ──────────────────────────────────────────────
 * Changes from original:
 * 1. Refresh token moved to httpOnly SameSite=Strict cookie (not response body)
 * 2. Login rate limiting via RedisLockService (H-01)
 * 3. Account lockout after 5 failures
 * 4. Refresh token rotation enforced — each refresh invalidates old token
 * 5. Logout clears httpOnly cookie server-side
 */

import {
  Controller, Post, Get, Body, Req, Res, UseGuards,
  HttpCode, HttpStatus, Delete, Patch, UnauthorizedException, Logger,
} from '@nestjs/common';
import {
  ApiTags, ApiOperation, ApiBearerAuth, ApiOkResponse,
} from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Request, Response } from 'express';
import { Throttle } from '@nestjs/throttler';
import { AuthService } from './auth.service';
import {
  LoginDto, MagicLinkRequestDto, MagicLinkVerifyDto,
  MfaSetupVerifyDto, MfaVerifyDto, ChangePasswordDto,
} from './dto/auth.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { RedisLockService } from '../../common/security/redis-lock.service';
import type { JwtPayload } from '@retroworks/types';

// Cookie name — httpOnly, never accessible to JavaScript
const REFRESH_COOKIE = 'rw_refresh_token';

const COOKIE_OPTS = {
  httpOnly: true,           // Not accessible to JavaScript (prevents XSS token theft)
  sameSite: 'strict' as const, // Prevents CSRF
  secure: process.env['NODE_ENV'] === 'production', // HTTPS only in production
  maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days in ms
  path: '/api/v1/auth',    // Scoped to auth endpoints only
};

interface AuthenticatedRequest extends Request {
  user: JwtPayload;
}

@ApiTags('auth')
@Controller('auth')
export class SecureAuthController {
  private readonly logger = new Logger(SecureAuthController.name);

  constructor(
    private readonly authService: AuthService,
    private readonly redisLock: RedisLockService,
  ) {}

  // ─── H-01 + H-09: Login with rate limiting + httpOnly cookie ──────────────

  @Post('login')
  @Public()
  @HttpCode(HttpStatus.OK)
  // Per-endpoint throttle: 5 requests per 15 minutes
  @Throttle({ login: { ttl: 900000, limit: 5 } })
  @ApiOperation({ summary: 'Login with email + password' })
  @ApiOkResponse({ description: 'Returns access token. Refresh token set as httpOnly cookie.' })
  async login(
    @Body() dto: LoginDto,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    const clientIp = req.ip ?? req.headers['x-forwarded-for']?.toString() ?? 'unknown';
    const identifier = `${dto.email.toLowerCase()}:${clientIp}`;

    // H-01: Check Redis lockout BEFORE attempting DB lookup
    const { locked, remainingSeconds } = await this.redisLock.isLockedOut(identifier);
    if (locked) {
      this.logger.warn(`[SECURITY] Locked account login attempt: ${dto.email} from ${clientIp}`);
      throw new UnauthorizedException(
        `Too many failed attempts. Account locked for ${Math.ceil(remainingSeconds / 60)} more minutes.`
      );
    }

    try {
      const result = await this.authService.login(dto, clientIp, req.headers['user-agent']);

      // If MFA is required, return challenge (no token yet)
      if ('mfaRequired' in result) return result;

      // Clear failed login attempts on success
      await this.redisLock.clearLoginAttempts(identifier);

      // H-09: Set refresh token as httpOnly cookie (not in response body)
      res.cookie(REFRESH_COOKIE, result.refreshToken, COOKIE_OPTS);

      // Return access token in body, but NOT the refresh token
      const { refreshToken, ...safeResponse } = result;
      return { ...safeResponse, refreshToken: undefined };

    } catch (err) {
      // H-01: Record failed attempt
      const { attempts, locked: nowLocked } = await this.redisLock.recordFailedLogin(identifier);

      if (nowLocked) {
        this.logger.warn(`[SECURITY] Account locked after ${attempts} attempts: ${dto.email}`);
      } else {
        this.logger.warn(`[SECURITY] Failed login ${attempts}/${5}: ${dto.email} from ${clientIp}`);
      }

      throw err;
    }
  }

  // ─── H-09: Refresh token from httpOnly cookie ─────────────────────────────

  @Post('refresh')
  @Public()
  @HttpCode(HttpStatus.OK)
  @Throttle({ short: { ttl: 60000, limit: 10 } })
  @ApiOperation({ summary: 'Refresh access token using httpOnly cookie' })
  async refresh(
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    // H-09: Read refresh token from httpOnly cookie — NEVER from body/header
    const refreshToken = req.cookies?.[REFRESH_COOKIE];

    if (!refreshToken) {
      throw new UnauthorizedException('No refresh token — please login again');
    }

    const result = await this.authService.refreshToken({ refreshToken });

    // Rotate: set new refresh token cookie, old one is already invalidated in DB
    res.cookie(REFRESH_COOKIE, result.refreshToken, COOKIE_OPTS);

    const { refreshToken: _, ...safeResponse } = result;
    return safeResponse;
  }

  // ─── H-09: Logout clears cookie server-side ───────────────────────────────

  @Delete('logout')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Logout — invalidates session and clears cookie' })
  async logout(
    @CurrentUser() user: JwtPayload,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    const refreshToken = req.cookies?.[REFRESH_COOKIE];
    if (refreshToken) {
      await this.authService.logout(user.sub, refreshToken);
    }

    // Clear httpOnly cookie
    res.clearCookie(REFRESH_COOKIE, {
      httpOnly: true,
      sameSite: 'strict',
      secure: process.env['NODE_ENV'] === 'production',
      path: '/api/v1/auth',
    });
  }

  // ─── MFA endpoints (unchanged) ─────────────────────────────────────────────

  @Post('mfa/verify')
  @Public()
  @HttpCode(HttpStatus.OK)
  @Throttle({ short: { ttl: 60000, limit: 5 } }) // Anti-TOTP brute force
  async verifyMfa(
    @Body() dto: MfaVerifyDto,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    const result = await this.authService.verifyMfa(dto, req.ip, req.headers['user-agent']);
    res.cookie(REFRESH_COOKIE, result.refreshToken, COOKIE_OPTS);
    const { refreshToken, ...safeResponse } = result;
    return safeResponse;
  }

  @Get('mfa/setup')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'Generate TOTP QR code for MFA setup' })
  async setupMfa(@CurrentUser() user: JwtPayload) {
    return this.authService.setupMfa(user.sub);
  }

  @Post('mfa/setup/verify')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.OK)
  async verifyMfaSetup(@Body() dto: MfaSetupVerifyDto, @CurrentUser() user: JwtPayload) {
    return this.authService.verifyMfaSetup(user.sub, dto);
  }

  @Delete('mfa/disable')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  async disableMfa(@CurrentUser() user: JwtPayload) {
    return this.authService.disableMfa(user.sub);
  }

  // ─── Magic links ─────────────────────────────────────────────────────────

  @Post('magic-link/request')
  @Public()
  @HttpCode(HttpStatus.ACCEPTED)
  @Throttle({ medium: { ttl: 60000, limit: 3 } }) // 3 magic link requests per minute
  async requestMagicLink(@Body() dto: MagicLinkRequestDto) {
    return this.authService.requestMagicLink(dto);
  }

  @Post('magic-link/verify')
  @Public()
  @HttpCode(HttpStatus.OK)
  async verifyMagicLink(
    @Body() dto: MagicLinkVerifyDto,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    const result = await this.authService.verifyMagicLink(dto, req.ip, req.headers['user-agent']);
    res.cookie(REFRESH_COOKIE, result.refreshToken, COOKIE_OPTS);
    const { refreshToken, ...safeResponse } = result;
    return safeResponse;
  }

  // ─── Password change ──────────────────────────────────────────────────────

  @Patch('change-password')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  @Throttle({ medium: { ttl: 60000, limit: 3 } })
  async changePassword(@Body() dto: ChangePasswordDto, @CurrentUser() user: JwtPayload) {
    return this.authService.changePassword(user.sub, dto);
  }

  // ─── Session info ─────────────────────────────────────────────────────────

  @Get('me')
  @ApiBearerAuth()
  async getMe(@CurrentUser() user: JwtPayload) {
    return this.authService.getMe(user.sub);
  }

  @Get('sessions')
  @ApiBearerAuth()
  async getSessions(@CurrentUser() user: JwtPayload) {
    return this.authService.getSessions(user.sub);
  }

  @Delete('sessions/:id')
  @ApiBearerAuth()
  @HttpCode(HttpStatus.NO_CONTENT)
  async revokeSession(@CurrentUser() user: JwtPayload) {
    // Implemented in authService
    return this.authService.logout(user.sub);
  }
}
