import {
  IsEmail,
  IsString,
  MinLength,
  IsOptional,
  IsEnum,
  Length,
  IsNotEmpty,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';

export class LoginDto {
  @ApiProperty({ example: 'admin@acme.com' })
  @IsEmail()
  email: string;

  @ApiProperty({ example: 'Admin@123!' })
  @IsString()
  @MinLength(1)
  password: string;

  @ApiPropertyOptional({ description: 'Tenant slug — required for multi-tenant login' })
  @IsOptional()
  @IsString()
  tenantSlug?: string;
}

export class MagicLinkRequestDto {
  @ApiProperty({ example: 'user@acme.com' })
  @IsEmail()
  email: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  tenantSlug?: string;
}

export class MagicLinkVerifyDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  token: string;
}

export class RefreshTokenDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  refreshToken: string;
}

export class MfaSetupVerifyDto {
  @ApiProperty({ description: '6-digit TOTP code', example: '123456' })
  @IsString()
  @Length(6, 6)
  code: string;
}

export class MfaVerifyDto {
  @ApiProperty({ description: '6-digit TOTP code or 8-char backup code' })
  @IsString()
  @IsNotEmpty()
  code: string;

  @ApiProperty({ description: 'MFA session token from login step 1' })
  @IsString()
  @IsNotEmpty()
  mfaToken: string;
}

export class ChangePasswordDto {
  @ApiProperty()
  @IsString()
  @IsNotEmpty()
  currentPassword: string;

  @ApiProperty({ minimum: 8 })
  @IsString()
  @MinLength(8)
  newPassword: string;
}

export enum AuthProvider {
  LOCAL = 'local',
  MAGIC_LINK = 'magic-link',
  OIDC = 'oidc',
}

export class TokenResponseDto {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
  tokenType: 'Bearer';
  user: {
    id: string;
    email: string;
    name: string;
    roles: string[];
    tenantId: string;
    employeeId?: string;
    avatarUrl?: string;
  };
}
