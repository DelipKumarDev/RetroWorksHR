import {
  Injectable,
  UnauthorizedException,
  BadRequestException,
  NotFoundException,
  Logger,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import * as speakeasy from 'speakeasy';
import * as QRCode from 'qrcode';
import { nanoid } from 'nanoid';
import type { JwtPayload } from '@retroworks/types';
import type {
  LoginDto,
  MagicLinkRequestDto,
  MagicLinkVerifyDto,
  RefreshTokenDto,
  MfaSetupVerifyDto,
  MfaVerifyDto,
  TokenResponseDto,
} from './dto/auth.dto';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);
  private readonly MAX_FAILED_ATTEMPTS = 5;
  private readonly LOCKOUT_MINUTES = 15;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly events: EventEmitter2,
  ) {}

  // ─────────────────────────────────────────────
  // PASSWORD LOGIN
  // ─────────────────────────────────────────────

  async login(
    dto: LoginDto,
    ip?: string,
    userAgent?: string,
  ): Promise<TokenResponseDto | { mfaRequired: true; mfaToken: string }> {
    // Find tenant
    const tenant = dto.tenantSlug
      ? await this.prisma.tenant.findFirst({ where: { slug: dto.tenantSlug, isActive: true } })
      : null;

    // Find user
    const user = await this.prisma.user.findFirst({
      where: {
        email: dto.email.toLowerCase().trim(),
        ...(tenant ? { tenantId: tenant.id } : {}),
        deletedAt: null,
      },
      include: {
        tenant: { select: { id: true, name: true, slug: true, isActive: true } },
        roles: { include: { role: { select: { name: true, permissions: true } } } },
      },
    });

    if (!user || !user.passwordHash) {
      // Constant-time comparison to prevent timing attacks
      await bcrypt.compare('dummy', '$2a$12$dummyhashforsecurity');
      throw new UnauthorizedException('Invalid credentials');
    }

    // Check lockout
    if (user.lockedUntil && user.lockedUntil > new Date()) {
      const minutesLeft = Math.ceil((user.lockedUntil.getTime() - Date.now()) / 60000);
      throw new UnauthorizedException(
        `Account locked. Try again in ${minutesLeft} minutes.`,
      );
    }

    // Check tenant active
    if (!user.tenant.isActive) {
      throw new UnauthorizedException('Tenant account is inactive');
    }

    // Verify password
    const passwordValid = await bcrypt.compare(dto.password, user.passwordHash);
    if (!passwordValid) {
      await this.recordFailedLogin(user.id);
      throw new UnauthorizedException('Invalid credentials');
    }

    // Reset failed attempts on success
    await this.prisma.user.update({
      where: { id: user.id },
      data: { failedLoginCount: 0, lockedUntil: null },
    });

    // MFA check
    if (user.mfaEnabled) {
      const mfaToken = await this.issueMfaToken(user.id);
      return { mfaRequired: true, mfaToken };
    }

    // Issue tokens
    return this.issueTokens(user, ip, userAgent);
  }

  // ─────────────────────────────────────────────
  // MFA VERIFICATION
  // ─────────────────────────────────────────────

  async verifyMfa(dto: MfaVerifyDto, ip?: string, userAgent?: string): Promise<TokenResponseDto> {
    // Decode mfa token
    let mfaPayload: { sub: string; purpose: string };
    try {
      mfaPayload = this.jwt.verify(dto.mfaToken, {
        secret: this.config.get<string>('app.jwt.secret'),
      }) as typeof mfaPayload;
    } catch {
      throw new UnauthorizedException('Invalid or expired MFA token');
    }

    if (mfaPayload.purpose !== 'mfa-challenge') {
      throw new UnauthorizedException('Invalid MFA token');
    }

    const user = await this.prisma.user.findFirst({
      where: { id: mfaPayload.sub, isActive: true, deletedAt: null },
      include: {
        tenant: { select: { id: true, name: true, slug: true } },
        roles: { include: { role: { select: { name: true, permissions: true } } } },
      },
    });

    if (!user || !user.mfaSecret) {
      throw new UnauthorizedException('MFA not configured');
    }

    // Decrypt secret (stored encrypted)
    const secret = await this.decryptField(user.mfaSecret);

    // Check TOTP code
    const isValid = speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token: dto.code,
      window: 2, // Allow ±2 intervals for clock drift
    });

    // Check backup codes if TOTP fails
    if (!isValid) {
      const backupValid = await this.verifyBackupCode(user.id, dto.code);
      if (!backupValid) {
        throw new UnauthorizedException('Invalid MFA code');
      }
    }

    return this.issueTokens(user, ip, userAgent);
  }

  // ─────────────────────────────────────────────
  // MFA SETUP
  // ─────────────────────────────────────────────

  async setupMfa(userId: string): Promise<{ qrCode: string; secret: string; backupCodes: string[] }> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');

    const secret = speakeasy.generateSecret({
      name: `RetroWorks HR (${user.email})`,
      issuer: 'RetroWorks HR',
      length: 20,
    });

    // Generate backup codes
    const backupCodes = Array.from({ length: 10 }, () => nanoid(8).toUpperCase());
    const hashedBackups = await Promise.all(backupCodes.map(c => bcrypt.hash(c, 10)));

    // Store temporarily — confirmed only after verify step
    const encryptedSecret = await this.encryptField(secret.base32);
    await this.prisma.user.update({
      where: { id: userId },
      data: {
        mfaSecret: encryptedSecret,
        mfaBackupCodes: hashedBackups,
        mfaEnabled: false, // Enable after verification
      },
    });

    const qrCode = await QRCode.toDataURL(secret.otpauth_url ?? '');

    return { qrCode, secret: secret.base32, backupCodes };
  }

  async confirmMfaSetup(userId: string, dto: MfaSetupVerifyDto): Promise<void> {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user?.mfaSecret) throw new BadRequestException('MFA not initialized');

    const secret = await this.decryptField(user.mfaSecret);
    const isValid = speakeasy.totp.verify({
      secret,
      encoding: 'base32',
      token: dto.code,
      window: 1,
    });

    if (!isValid) throw new BadRequestException('Invalid verification code');

    await this.prisma.user.update({
      where: { id: userId },
      data: { mfaEnabled: true },
    });
  }

  async disableMfa(userId: string): Promise<void> {
    await this.prisma.user.update({
      where: { id: userId },
      data: { mfaEnabled: false, mfaSecret: null, mfaBackupCodes: [] },
    });
  }

  // ─────────────────────────────────────────────
  // MAGIC LINK
  // ─────────────────────────────────────────────

  async requestMagicLink(dto: MagicLinkRequestDto): Promise<void> {
    const user = await this.prisma.user.findFirst({
      where: {
        email: dto.email.toLowerCase().trim(),
        isActive: true,
        deletedAt: null,
      },
    });

    // Silent failure — don't reveal if email exists
    if (!user) {
      this.logger.warn(`Magic link requested for unknown email: ${dto.email}`);
      return;
    }

    // Invalidate old links
    await this.prisma.magicLink.deleteMany({
      where: { userId: user.id, usedAt: null },
    });

    const token = nanoid(48);
    const expiresAt = new Date(
      Date.now() + (this.config.get<number>('app.magicLink.expiresInMinutes') ?? 15) * 60_000,
    );

    await this.prisma.magicLink.create({
      data: { userId: user.id, token, expiresAt },
    });

    // Emit event for notification service
    this.events.emit('auth.magic-link.requested', {
      userId: user.id,
      email: user.email,
      name: user.name,
      token,
      expiresAt,
      magicUrl: `${this.config.get<string>('app.frontendUrl')}/auth/magic?token=${token}`,
    });
  }

  async verifyMagicLink(
    dto: MagicLinkVerifyDto,
    ip?: string,
    userAgent?: string,
  ): Promise<TokenResponseDto> {
    const link = await this.prisma.magicLink.findUnique({
      where: { token: dto.token },
      include: {
        user: {
          include: {
            tenant: { select: { id: true, name: true, slug: true } },
            roles: { include: { role: { select: { name: true, permissions: true } } } },
          },
        },
      },
    });

    if (!link) throw new UnauthorizedException('Invalid magic link');
    if (link.usedAt) throw new UnauthorizedException('Magic link already used');
    if (link.expiresAt < new Date()) throw new UnauthorizedException('Magic link expired');
    if (!link.user.isActive) throw new UnauthorizedException('Account is inactive');

    // Mark as used
    await this.prisma.magicLink.update({
      where: { id: link.id },
      data: { usedAt: new Date() },
    });

    return this.issueTokens(link.user, ip, userAgent);
  }

  // ─────────────────────────────────────────────
  // TOKEN REFRESH
  // ─────────────────────────────────────────────

  async refreshToken(dto: RefreshTokenDto): Promise<TokenResponseDto> {
    let payload: JwtPayload;
    try {
      payload = this.jwt.verify(dto.refreshToken, {
        secret: this.config.get<string>('app.jwt.refreshSecret'),
      }) as JwtPayload;
    } catch {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }

    // Verify session still exists
    const session = await this.prisma.session.findFirst({
      where: { refreshToken: dto.refreshToken, expiresAt: { gt: new Date() } },
      include: {
        user: {
          include: {
            tenant: { select: { id: true, name: true, slug: true } },
            roles: { include: { role: { select: { name: true, permissions: true } } } },
          },
        },
      },
    });

    if (!session || !session.user.isActive) {
      throw new UnauthorizedException('Session expired');
    }

    // Rotate refresh token
    await this.prisma.session.delete({ where: { id: session.id } });

    return this.issueTokens(session.user, session.ip ?? undefined, session.userAgent ?? undefined);
  }

  // ─────────────────────────────────────────────
  // LOGOUT
  // ─────────────────────────────────────────────

  async logout(userId: string, sessionToken?: string): Promise<void> {
    if (sessionToken) {
      await this.prisma.session.deleteMany({ where: { userId, token: sessionToken } });
    } else {
      // Logout all sessions
      await this.prisma.session.deleteMany({ where: { userId } });
    }
  }

  // ─────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────

  private async issueTokens(
    user: {
      id: string;
      email: string;
      name: string;
      tenantId: string;
      avatarUrl?: string | null;
      employeeId?: string | null;
      tenant: { id: string };
      roles: Array<{ role: { name: string; permissions: unknown } }>;
    },
    ip?: string,
    userAgent?: string,
  ): Promise<TokenResponseDto> {
    const roles = user.roles.map(r => r.role.name);
    const sessionId = nanoid();

    const payload: Omit<JwtPayload, 'iat' | 'exp'> = {
      sub: user.id,
      tid: user.tenantId,
      email: user.email,
      roles,
      sessionId,
    };

    const accessToken = this.jwt.sign(payload, {
      secret: this.config.get<string>('app.jwt.secret'),
      expiresIn: this.config.get<string>('app.jwt.expiresIn') ?? '15m',
    });

    const refreshToken = this.jwt.sign(payload, {
      secret: this.config.get<string>('app.jwt.refreshSecret'),
      expiresIn: this.config.get<string>('app.jwt.refreshExpiresIn') ?? '7d',
    });

    // Persist session
    const sessionExpiry = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await this.prisma.session.create({
      data: {
        userId: user.id,
        token: sessionId,
        refreshToken,
        expiresAt: sessionExpiry,
        ip,
        userAgent,
      },
    });

    // Update last login
    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date(), failedLoginCount: 0 },
    });

    // Audit
    this.events.emit('audit.created', {
      tenantId: user.tenantId,
      userId: user.id,
      action: 'LOGIN',
      resource: 'user',
      resourceId: user.id,
      ip,
      userAgent,
    });

    return {
      accessToken,
      refreshToken,
      expiresIn: 900, // 15 minutes in seconds
      tokenType: 'Bearer',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        roles,
        tenantId: user.tenantId,
        employeeId: user.employeeId ?? undefined,
        avatarUrl: user.avatarUrl ?? undefined,
      },
    };
  }

  private async issueMfaToken(userId: string): Promise<string> {
    return this.jwt.sign(
      { sub: userId, purpose: 'mfa-challenge' },
      {
        secret: this.config.get<string>('app.jwt.secret'),
        expiresIn: '5m',
      },
    );
  }

  private async recordFailedLogin(userId: string): Promise<void> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { failedLoginCount: true },
    });

    const newCount = (user?.failedLoginCount ?? 0) + 1;
    const shouldLock = newCount >= this.MAX_FAILED_ATTEMPTS;

    await this.prisma.user.update({
      where: { id: userId },
      data: {
        failedLoginCount: newCount,
        lockedUntil: shouldLock
          ? new Date(Date.now() + this.LOCKOUT_MINUTES * 60_000)
          : null,
      },
    });
  }

  private async verifyBackupCode(userId: string, code: string): Promise<boolean> {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      select: { mfaBackupCodes: true },
    });

    if (!user?.mfaBackupCodes.length) return false;

    for (let i = 0; i < user.mfaBackupCodes.length; i++) {
      const hash = user.mfaBackupCodes[i];
      if (!hash) continue;
      const match = await bcrypt.compare(code, hash);
      if (match) {
        // Consume the backup code
        const updated = [...user.mfaBackupCodes];
        updated.splice(i, 1);
        await this.prisma.user.update({
          where: { id: userId },
          data: { mfaBackupCodes: updated },
        });
        return true;
      }
    }
    return false;
  }

  // Simple field encryption using AES — in production uses KMS
  private async encryptField(value: string): Promise<string> {
    const key = this.config.get<string>('app.encryption.key') ?? '';
    if (!key || key.length < 64) return `plain:${value}`; // dev fallback
    // Production: use crypto.createCipheriv with AES-256-GCM
    // For scaffold, base64 encode with marker
    return `enc:${Buffer.from(value).toString('base64')}`;
  }

  private async decryptField(value: string): Promise<string> {
    if (value.startsWith('plain:')) return value.slice(6);
    if (value.startsWith('enc:')) return Buffer.from(value.slice(4), 'base64').toString('utf-8');
    return value;
  }
}
