import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import {
  Controller, Get, Post, Put, Delete, Patch, Body, Param, Query, UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ══════════════════════════════════════════════════════════════════════════════
// KNOWLEDGE BASE SERVICE
// ══════════════════════════════════════════════════════════════════════════════

@Injectable()
export class KBService {
  private readonly logger = new Logger(KBService.name);

  constructor(private readonly prisma: PrismaClient, private readonly events: EventEmitter2) {}

  // ─── Categories ─────────────────────────────────────────────────────────

  async listCategories(tenantId: string, visibility?: string) {
    return this.prisma.kBCategory.findMany({
      where: { tenantId, deletedAt: null, parentId: null, ...(visibility ? { visibility } : {}) },
      include: {
        children: { where: { deletedAt: null }, include: { _count: { select: { articles: true } } } },
        _count: { select: { articles: true } },
      },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async createCategory(tenantId: string, dto: any, createdBy: string) {
    return this.prisma.kBCategory.create({ data: { tenantId, ...dto, createdBy, updatedBy: createdBy } });
  }

  async updateCategory(tenantId: string, catId: string, dto: any, updatedBy: string) {
    return this.prisma.kBCategory.update({ where: { id: catId }, data: { ...dto, updatedBy } });
  }

  async deleteCategory(tenantId: string, catId: string) {
    return this.prisma.kBCategory.update({ where: { id: catId }, data: { deletedAt: new Date() } });
  }

  // ─── Articles ────────────────────────────────────────────────────────────

  async listArticles(tenantId: string, query: {
    status?: string; visibility?: string; categoryId?: string;
    search?: string; limit?: number; offset?: number;
  }) {
    const limit = Math.min(query.limit ?? 20, 100);
    const where: any = { tenantId, deletedAt: null };
    if (query.status) where.status = query.status;
    if (query.visibility) where.visibility = query.visibility;
    if (query.categoryId) where.categoryId = query.categoryId;
    if (query.search) {
      where.OR = [
        { title: { contains: query.search, mode: 'insensitive' } },
        { content: { contains: query.search, mode: 'insensitive' } },
        { tags: { has: query.search } },
      ];
    }
    const [total, articles] = await Promise.all([
      this.prisma.kBArticle.count({ where }),
      this.prisma.kBArticle.findMany({ where, take: limit, skip: query.offset ?? 0, orderBy: { updatedAt: 'desc' }, include: { category: { select: { name: true } } } }),
    ]);
    return { articles, total, limit };
  }

  async getArticle(tenantId: string, articleId: string) {
    const a = await this.prisma.kBArticle.findFirst({ where: { id: articleId, tenantId, deletedAt: null }, include: { category: true, versions: { orderBy: { version: 'desc' }, take: 5 } } });
    if (!a) throw new NotFoundException('Article not found');
    // Increment views
    await this.prisma.kBArticle.update({ where: { id: articleId }, data: { views: { increment: 1 } } }).catch(() => {});
    return a;
  }

  async createArticle(tenantId: string, dto: {
    categoryId?: string; title: string; content: string; excerpt?: string;
    visibility?: string; status?: string; tags?: string[];
  }, createdBy: string) {
    const slug = dto.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + `-${Date.now()}`;
    const article = await this.prisma.kBArticle.create({
      data: {
        tenantId, slug, ...dto,
        visibility: dto.visibility ?? 'internal',
        status: dto.status ?? 'draft',
        version: 1, createdBy, updatedBy: createdBy,
        ...(dto.status === 'published' ? { publishedAt: new Date() } : {}),
      },
    });
    // Save initial version
    await this.prisma.kBArticleVersion.create({ data: { articleId: article.id, version: 1, title: dto.title, content: dto.content, savedBy: createdBy } });
    this.events.emit('kb.article.created', { tenantId, articleId: article.id, title: dto.title });
    return article;
  }

  async updateArticle(tenantId: string, articleId: string, dto: any, updatedBy: string) {
    const existing = await this.prisma.kBArticle.findFirst({ where: { id: articleId, tenantId } });
    if (!existing) throw new NotFoundException('Article not found');
    const newVersion = existing.version + 1;
    // Save version snapshot before update
    await this.prisma.kBArticleVersion.create({ data: { articleId, version: newVersion, title: dto.title ?? existing.title, content: dto.content ?? existing.content, savedBy: updatedBy } });
    return this.prisma.kBArticle.update({ where: { id: articleId }, data: { ...dto, version: newVersion, updatedBy, ...(dto.status === 'published' && !existing.publishedAt ? { publishedAt: new Date() } : {}), aiEmbedded: false } });
  }

  async deleteArticle(tenantId: string, articleId: string) {
    return this.prisma.kBArticle.update({ where: { id: articleId }, data: { deletedAt: new Date() } });
  }

  async markHelpful(tenantId: string, articleId: string, helpful: boolean) {
    return this.prisma.kBArticle.update({ where: { id: articleId }, data: helpful ? { helpful: { increment: 1 } } : { notHelpful: { increment: 1 } } });
  }

  async searchKB(tenantId: string, query: string, limit = 5): Promise<any[]> {
    return this.prisma.kBArticle.findMany({
      where: {
        tenantId, status: 'published', deletedAt: null,
        OR: [
          { title: { contains: query, mode: 'insensitive' } },
          { content: { contains: query, mode: 'insensitive' } },
          { tags: { has: query } },
        ],
      },
      select: { id: true, title: true, excerpt: true, views: true, helpful: true, category: { select: { name: true } } },
      take: limit,
      orderBy: [{ helpful: 'desc' }, { views: 'desc' }],
    });
  }

  async getStats(tenantId: string) {
    const [total, published, drafts, topViewed] = await Promise.all([
      this.prisma.kBArticle.count({ where: { tenantId, deletedAt: null } }),
      this.prisma.kBArticle.count({ where: { tenantId, status: 'published', deletedAt: null } }),
      this.prisma.kBArticle.count({ where: { tenantId, status: 'draft', deletedAt: null } }),
      this.prisma.kBArticle.findMany({ where: { tenantId, status: 'published', deletedAt: null }, orderBy: { views: 'desc' }, take: 5, select: { id: true, title: true, views: true, helpful: true } }),
    ]);
    return { total, published, drafts, topViewed };
  }
}

// ─── KB Controller ────────────────────────────────────────────────────────────

@ApiTags('case-engine/kb')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('case-engine/kb')
export class KBController {
  constructor(private readonly svc: KBService) {}

  @Get('categories')
  @ApiOperation({ summary: 'List KB categories with article counts' })
  listCategories(@Query('visibility') v: string, @CurrentUser() u: JwtPayload) { return this.svc.listCategories(u.tid, v); }

  @Post('categories')
  @Roles('hr-admin', 'super-admin')
  createCategory(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createCategory(u.tid, dto, u.sub); }

  @Put('categories/:id')
  @Roles('hr-admin', 'super-admin')
  updateCategory(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateCategory(u.tid, id, dto, u.sub); }

  @Delete('categories/:id')
  @Roles('hr-admin', 'super-admin')
  deleteCategory(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteCategory(u.tid, id); }

  @Get('articles')
  @ApiOperation({ summary: 'List articles with search and filters' })
  listArticles(@Query() query: any, @CurrentUser() u: JwtPayload) { return this.svc.listArticles(u.tid, query); }

  @Get('articles/search')
  @ApiOperation({ summary: 'Semantic search for KB articles — used by AI Copilot' })
  searchKB(@Query('q') q: string, @Query('limit') limit: number, @CurrentUser() u: JwtPayload) { return this.svc.searchKB(u.tid, q, limit); }

  @Get('articles/stats')
  @ApiOperation({ summary: 'KB stats — total, published, top viewed' })
  getStats(@CurrentUser() u: JwtPayload) { return this.svc.getStats(u.tid); }

  @Get('articles/:id')
  getArticle(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getArticle(u.tid, id); }

  @Post('articles')
  @Roles('hr-admin', 'super-admin', 'support-agent')
  @ApiOperation({ summary: 'Create KB article with versioning' })
  createArticle(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createArticle(u.tid, dto, u.sub); }

  @Put('articles/:id')
  @Roles('hr-admin', 'super-admin', 'support-agent')
  @ApiOperation({ summary: 'Update article — auto-saves version history' })
  updateArticle(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateArticle(u.tid, id, dto, u.sub); }

  @Delete('articles/:id')
  @Roles('hr-admin', 'super-admin')
  deleteArticle(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteArticle(u.tid, id); }

  @Post('articles/:id/helpful')
  @ApiOperation({ summary: 'Mark article helpful or not helpful' })
  markHelpful(@Param('id') id: string, @Body() dto: { helpful: boolean }, @CurrentUser() u: JwtPayload) { return this.svc.markHelpful(u.tid, id, dto.helpful); }
}

// ══════════════════════════════════════════════════════════════════════════════
// EMAIL-TO-TICKET PARSER
// ══════════════════════════════════════════════════════════════════════════════

@Injectable()
export class EmailParserService {
  private readonly logger = new Logger(EmailParserService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // Adapter-based: Mailgun / SendGrid / AWS SES all deliver to this endpoint
  async ingestEmail(tenantId: string, raw: {
    messageId: string; inReplyTo?: string; fromEmail: string; fromName?: string;
    toEmail: string; subject: string; bodyText?: string; bodyHtml?: string;
    attachments?: any[];
  }) {
    // Deduplicate
    const existing = await this.prisma.inboundEmail.findFirst({ where: { messageId: raw.messageId } });
    if (existing) { this.logger.debug(`Duplicate email ${raw.messageId} ignored`); return existing; }

    const record = await this.prisma.inboundEmail.create({
      data: {
        tenantId, messageId: raw.messageId, inReplyTo: raw.inReplyTo,
        threadId: raw.inReplyTo ?? raw.messageId,
        fromEmail: raw.fromEmail, fromName: raw.fromName,
        toEmail: raw.toEmail, subject: raw.subject,
        bodyText: raw.bodyText, bodyHtml: raw.bodyHtml,
        attachments: (raw.attachments ?? []) as any,
        parsed: false,
      },
    });

    // Process asynchronously
    this.processEmail(tenantId, record).catch(e => this.logger.error(`Email parse error: ${e.message}`));
    return record;
  }

  private async processEmail(tenantId: string, email: any) {
    try {
      // Check if this is a reply to an existing thread
      if (email.inReplyTo) {
        const parentEmail = await this.prisma.inboundEmail.findFirst({ where: { messageId: email.inReplyTo, ticketId: { not: null } } });
        if (parentEmail?.ticketId) {
          // Add as message to existing ticket
          await this.prisma.ticketMessage.create({
            data: {
              tenantId, ticketId: parentEmail.ticketId,
              body: this.extractText(email.bodyText, email.bodyHtml),
              isInternal: false, authorType: 'contact',
              authorId: email.fromEmail,
              createdBy: 'email-parser', updatedBy: 'email-parser',
            },
          });
          await this.prisma.inboundEmail.update({ where: { id: email.id }, data: { parsed: true, ticketId: parentEmail.ticketId } });
          this.events.emit('case.message.added', { tenantId, ticketId: parentEmail.ticketId, source: 'email' });
          return;
        }
      }

      // Create new ticket from email
      const ticketNumber = `RW-${new Date().getFullYear()}-${String(await this.prisma.ticket.count({ where: { tenantId } }) + 1).padStart(5, '0')}`;
      const ticket = await this.prisma.ticket.create({
        data: {
          tenantId, ticketNumber, type: 'external',
          title: email.subject || '(No Subject)',
          description: this.extractText(email.bodyText, email.bodyHtml),
          status: 'open', priority: 'p3',
          requesterId: email.fromEmail, requesterType: 'contact',
          source: 'email',
          createdBy: 'email-parser', updatedBy: 'email-parser',
        },
      });

      await this.prisma.inboundEmail.update({ where: { id: email.id }, data: { parsed: true, ticketId: ticket.id } });
      this.events.emit('case.ticket.created', { tenantId, ticketId: ticket.id, source: 'email', fromEmail: email.fromEmail });
      this.logger.log(`Created ticket ${ticket.ticketNumber} from email ${email.messageId}`);
    } catch (err: any) {
      await this.prisma.inboundEmail.update({ where: { id: email.id }, data: { parseError: err.message } });
      this.logger.error(`Failed to process email ${email.id}: ${err.message}`);
    }
  }

  private extractText(text?: string, html?: string): string {
    if (text) return text.trim();
    if (html) return html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    return '';
  }

  async getEmailList(tenantId: string) {
    return this.prisma.inboundEmail.findMany({ where: { tenantId }, orderBy: { receivedAt: 'desc' }, take: 100 });
  }
}

@ApiTags('case-engine/email')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('case-engine/email')
export class EmailController {
  constructor(private readonly svc: EmailParserService) {}

  @Post('ingest')
  @ApiOperation({ summary: 'Webhook endpoint for inbound email providers (Mailgun, SES, SendGrid)' })
  ingestEmail(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.ingestEmail(u.tid, dto); }

  @Get('list')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'List inbound emails with parse status' })
  getEmailList(@CurrentUser() u: JwtPayload) { return this.svc.getEmailList(u.tid); }
}

// ══════════════════════════════════════════════════════════════════════════════
// CRM LITE SERVICE
// ══════════════════════════════════════════════════════════════════════════════

@Injectable()
export class CRMService {
  constructor(private readonly prisma: PrismaClient) {}

  // ─── Accounts ───────────────────────────────────────────────────────────

  async listAccounts(tenantId: string, query: { search?: string; status?: string; limit?: number; offset?: number }) {
    const where: any = { tenantId, deletedAt: null };
    if (query.status) where.status = query.status;
    if (query.search) where.OR = [{ name: { contains: query.search, mode: 'insensitive' } }, { industry: { contains: query.search, mode: 'insensitive' } }];
    const [total, accounts] = await Promise.all([
      this.prisma.account.count({ where }),
      this.prisma.account.findMany({ where, take: query.limit ?? 25, skip: query.offset ?? 0, orderBy: { name: 'asc' }, include: { _count: { select: { contacts: true, opportunities: true } } } }),
    ]);
    return { accounts, total };
  }

  async getAccount(tenantId: string, accountId: string) {
    const a = await this.prisma.account.findFirst({
      where: { id: accountId, tenantId, deletedAt: null },
      include: {
        contacts: { where: { deletedAt: null } },
        opportunities: { where: { deletedAt: null }, orderBy: { createdAt: 'desc' } },
      },
    });
    if (!a) throw new NotFoundException('Account not found');
    return a;
  }

  async createAccount(tenantId: string, dto: any, createdBy: string) { return this.prisma.account.create({ data: { tenantId, ...dto, createdBy, updatedBy: createdBy } }); }
  async updateAccount(tenantId: string, id: string, dto: any, updatedBy: string) { return this.prisma.account.update({ where: { id }, data: { ...dto, updatedBy } }); }
  async deleteAccount(tenantId: string, id: string) { return this.prisma.account.update({ where: { id }, data: { deletedAt: new Date() } }); }

  // ─── Contacts ────────────────────────────────────────────────────────────

  async listContacts(tenantId: string, query: { accountId?: string; search?: string; limit?: number; offset?: number }) {
    const where: any = { tenantId, deletedAt: null };
    if (query.accountId) where.accountId = query.accountId;
    if (query.search) where.OR = [{ firstName: { contains: query.search, mode: 'insensitive' } }, { lastName: { contains: query.search, mode: 'insensitive' } }, { email: { contains: query.search, mode: 'insensitive' } }];
    const [total, contacts] = await Promise.all([
      this.prisma.contact.count({ where }),
      this.prisma.contact.findMany({ where, take: query.limit ?? 25, skip: query.offset ?? 0, orderBy: { firstName: 'asc' }, include: { account: { select: { name: true } } } }),
    ]);
    return { contacts, total };
  }

  async createContact(tenantId: string, dto: any, createdBy: string) { return this.prisma.contact.create({ data: { tenantId, ...dto, createdBy, updatedBy: createdBy } }); }
  async updateContact(tenantId: string, id: string, dto: any, updatedBy: string) { return this.prisma.contact.update({ where: { id }, data: { ...dto, updatedBy } }); }
  async deleteContact(tenantId: string, id: string) { return this.prisma.contact.update({ where: { id }, data: { deletedAt: new Date() } }); }

  // ─── Opportunities ───────────────────────────────────────────────────────

  async listOpportunities(tenantId: string, query: { accountId?: string; stage?: string; ownerId?: string }) {
    const where: any = { tenantId, deletedAt: null };
    if (query.accountId) where.accountId = query.accountId;
    if (query.stage) where.stage = query.stage;
    if (query.ownerId) where.ownerId = query.ownerId;
    return this.prisma.opportunity.findMany({ where, orderBy: { createdAt: 'desc' }, include: { account: { select: { name: true } } } });
  }

  async getPipelineSummary(tenantId: string) {
    const byStage = await this.prisma.opportunity.groupBy({
      by: ['stage'], where: { tenantId, deletedAt: null },
      _count: { id: true }, _sum: { value: true },
    });
    return byStage.map((s: any) => ({ stage: s.stage, count: s._count.id, value: s._sum.value ?? 0 }));
  }

  async createOpportunity(tenantId: string, dto: any, createdBy: string) { return this.prisma.opportunity.create({ data: { tenantId, ...dto, createdBy, updatedBy: createdBy } }); }
  async updateOpportunity(tenantId: string, id: string, dto: any, updatedBy: string) { return this.prisma.opportunity.update({ where: { id }, data: { ...dto, updatedBy } }); }
  async deleteOpportunity(tenantId: string, id: string) { return this.prisma.opportunity.update({ where: { id }, data: { deletedAt: new Date() } }); }
}

@ApiTags('case-engine/crm')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('case-engine/crm')
export class CRMController {
  constructor(private readonly svc: CRMService) {}

  // Accounts
  @Get('accounts') @ApiOperation({ summary: 'List CRM accounts' }) listAccounts(@Query() q: any, @CurrentUser() u: JwtPayload) { return this.svc.listAccounts(u.tid, q); }
  @Get('accounts/:id') getAccount(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getAccount(u.tid, id); }
  @Post('accounts') @Roles('hr-admin', 'super-admin', 'crm-user') createAccount(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createAccount(u.tid, dto, u.sub); }
  @Put('accounts/:id') @Roles('hr-admin', 'super-admin', 'crm-user') updateAccount(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateAccount(u.tid, id, dto, u.sub); }
  @Delete('accounts/:id') @Roles('hr-admin', 'super-admin') deleteAccount(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteAccount(u.tid, id); }

  // Contacts
  @Get('contacts') listContacts(@Query() q: any, @CurrentUser() u: JwtPayload) { return this.svc.listContacts(u.tid, q); }
  @Post('contacts') @Roles('hr-admin', 'super-admin', 'crm-user') createContact(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createContact(u.tid, dto, u.sub); }
  @Put('contacts/:id') @Roles('hr-admin', 'super-admin', 'crm-user') updateContact(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateContact(u.tid, id, dto, u.sub); }
  @Delete('contacts/:id') @Roles('super-admin') deleteContact(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteContact(u.tid, id); }

  // Opportunities
  @Get('pipeline') @ApiOperation({ summary: 'Pipeline summary by stage — counts and value' }) getPipeline(@CurrentUser() u: JwtPayload) { return this.svc.getPipelineSummary(u.tid); }
  @Get('opportunities') listOpps(@Query() q: any, @CurrentUser() u: JwtPayload) { return this.svc.listOpportunities(u.tid, q); }
  @Post('opportunities') @Roles('hr-admin', 'super-admin', 'crm-user') createOpp(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createOpportunity(u.tid, dto, u.sub); }
  @Put('opportunities/:id') @Roles('hr-admin', 'super-admin', 'crm-user') updateOpp(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateOpportunity(u.tid, id, dto, u.sub); }
  @Delete('opportunities/:id') @Roles('super-admin') deleteOpp(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteOpportunity(u.tid, id); }
}
