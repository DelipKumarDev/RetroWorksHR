import { Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import {
  Controller, Get, Query, UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Roles } from '../../common/decorators/permissions.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { JwtPayload } from '@retroworks/types';

@Injectable()
export class CaseAnalyticsService {
  constructor(private readonly prisma: PrismaClient) {}

  // ─── Overview Dashboard ───────────────────────────────────────────────────

  async getDashboard(tenantId: string) {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfLastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const endOfLastMonth = new Date(now.getFullYear(), now.getMonth(), 0);

    const [
      openCount, inProgressCount, resolvedThisMonth, breachedCount,
      avgResolutionMs, ticketsByType, ticketsByPriority,
      lastMonthResolved, newThisMonth, newLastMonth,
    ] = await Promise.all([
      this.prisma.ticket.count({ where: { tenantId, status: 'open', deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, status: 'in-progress', deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, status: 'resolved', resolvedAt: { gte: startOfMonth }, deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, slaBreached: true, status: { notIn: ['closed'] }, deletedAt: null } }),
      this.prisma.ticket.aggregate({ where: { tenantId, resolvedAt: { not: null }, deletedAt: null }, _avg: { id: true } }), // placeholder
      this.prisma.ticket.groupBy({ by: ['type'], where: { tenantId, deletedAt: null }, _count: { id: true } }),
      this.prisma.ticket.groupBy({ by: ['priority'], where: { tenantId, deletedAt: null }, _count: { id: true } }),
      this.prisma.ticket.count({ where: { tenantId, status: 'resolved', resolvedAt: { gte: startOfLastMonth, lte: endOfLastMonth }, deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, createdAt: { gte: startOfMonth }, deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, createdAt: { gte: startOfLastMonth, lte: endOfLastMonth }, deletedAt: null } }),
    ]);

    const resolutionTrend = lastMonthResolved > 0 ? (((resolvedThisMonth - lastMonthResolved) / lastMonthResolved) * 100).toFixed(1) : '0';
    const volumeTrend = newLastMonth > 0 ? (((newThisMonth - newLastMonth) / newLastMonth) * 100).toFixed(1) : '0';

    return {
      summary: {
        open: openCount,
        inProgress: inProgressCount,
        resolvedThisMonth,
        slaBreached: breachedCount,
        newThisMonth,
        resolutionTrend: `${resolutionTrend}%`,
        volumeTrend: `${volumeTrend}%`,
      },
      byType: ticketsByType.map((t: any) => ({ type: t.type, count: t._count.id })),
      byPriority: ticketsByPriority.map((p: any) => ({ priority: p.priority, count: p._count.id })),
    };
  }

  // ─── Volume Trends (12 months) ────────────────────────────────────────────

  async getVolumeTrend(tenantId: string) {
    const months = Array.from({ length: 12 }, (_, i) => {
      const d = new Date();
      d.setMonth(d.getMonth() - (11 - i));
      return { year: d.getFullYear(), month: d.getMonth() + 1, label: d.toLocaleString('en-IN', { month: 'short', year: '2-digit' }) };
    });

    const trend = await Promise.all(months.map(async (m) => {
      const start = new Date(m.year, m.month - 1, 1);
      const end = new Date(m.year, m.month, 0, 23, 59, 59);
      const [created, resolved, breached] = await Promise.all([
        this.prisma.ticket.count({ where: { tenantId, createdAt: { gte: start, lte: end }, deletedAt: null } }),
        this.prisma.ticket.count({ where: { tenantId, resolvedAt: { gte: start, lte: end }, deletedAt: null } }),
        this.prisma.ticket.count({ where: { tenantId, slaBreached: true, createdAt: { gte: start, lte: end }, deletedAt: null } }),
      ]);
      return { ...m, created, resolved, breached };
    }));

    return trend;
  }

  // ─── SLA Breach Report ────────────────────────────────────────────────────

  async getSLAReport(tenantId: string) {
    const [totalActive, breached, byCategory, bySla] = await Promise.all([
      this.prisma.ticket.count({ where: { tenantId, status: { notIn: ['closed', 'resolved'] }, deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, slaBreached: true, status: { notIn: ['closed'] }, deletedAt: null } }),
      this.prisma.ticket.groupBy({
        by: ['categoryId'],
        where: { tenantId, slaBreached: true, deletedAt: null },
        _count: { id: true },
        orderBy: { _count: { id: 'desc' } },
        take: 10,
      }),
      this.prisma.ticket.groupBy({
        by: ['slaId'],
        where: { tenantId, deletedAt: null },
        _count: { id: true },
      }),
    ]);

    const breachRate = totalActive > 0 ? ((breached / totalActive) * 100).toFixed(1) : '0';

    // Resolve category names
    const categoryIds = (byCategory as any[]).map((c: any) => c.categoryId).filter(Boolean);
    const categories = await this.prisma.ticketCategory.findMany({ where: { id: { in: categoryIds } }, select: { id: true, name: true } });
    const catMap = new Map(categories.map(c => [c.id, c.name]));

    return {
      totalActive, breached, breachRate: `${breachRate}%`,
      byCategory: (byCategory as any[]).map((c: any) => ({ category: catMap.get(c.categoryId) ?? 'Unknown', count: c._count.id })),
    };
  }

  // ─── Agent Performance ────────────────────────────────────────────────────

  async getAgentPerformance(tenantId: string, month?: number, year?: number) {
    const now = new Date();
    const m = month ?? now.getMonth() + 1;
    const y = year ?? now.getFullYear();
    const start = new Date(y, m - 1, 1);
    const end = new Date(y, m, 0, 23, 59, 59);

    const assigned = await this.prisma.ticket.groupBy({
      by: ['assigneeId'],
      where: { tenantId, assigneeId: { not: null }, createdAt: { gte: start, lte: end }, deletedAt: null },
      _count: { id: true },
    });

    const resolved = await this.prisma.ticket.groupBy({
      by: ['assigneeId'],
      where: { tenantId, assigneeId: { not: null }, resolvedAt: { gte: start, lte: end }, deletedAt: null },
      _count: { id: true },
    });

    const breached = await this.prisma.ticket.groupBy({
      by: ['assigneeId'],
      where: { tenantId, assigneeId: { not: null }, slaBreached: true, createdAt: { gte: start, lte: end }, deletedAt: null },
      _count: { id: true },
    });

    const resolvedMap = new Map((resolved as any[]).map((r: any) => [r.assigneeId, r._count.id]));
    const breachedMap = new Map((breached as any[]).map((r: any) => [r.assigneeId, r._count.id]));

    const agentIds = [...new Set((assigned as any[]).map((a: any) => a.assigneeId))].filter(Boolean);
    const agents = await this.prisma.employee.findMany({
      where: { id: { in: agentIds as string[] } },
      select: { id: true, firstName: true, lastName: true, designation: { select: { name: true } } },
    });
    const agentMap = new Map(agents.map(a => [a.id, a]));

    return (assigned as any[]).map((a: any) => {
      const agent = agentMap.get(a.assigneeId);
      const total = a._count.id;
      const res = resolvedMap.get(a.assigneeId) ?? 0;
      const br = breachedMap.get(a.assigneeId) ?? 0;
      return {
        agentId: a.assigneeId,
        name: agent ? `${agent.firstName} ${agent.lastName}` : 'Unknown',
        designation: agent?.designation?.name,
        assigned: total,
        resolved: res,
        slaBreached: br,
        resolutionRate: total > 0 ? ((res / total) * 100).toFixed(1) + '%' : '0%',
        slaBreachRate: total > 0 ? ((br / total) * 100).toFixed(1) + '%' : '0%',
      };
    }).sort((a, b) => b.resolved - a.resolved);
  }

  // ─── Cross-Domain: Ticket ↔ Headcount Correlation ─────────────────────────

  async getTicketHeadcountCorrelation(tenantId: string) {
    const months = Array.from({ length: 6 }, (_, i) => {
      const d = new Date();
      d.setMonth(d.getMonth() - (5 - i));
      return { year: d.getFullYear(), month: d.getMonth() + 1, label: d.toLocaleString('en-IN', { month: 'short', year: '2-digit' }) };
    });

    return Promise.all(months.map(async (m) => {
      const start = new Date(m.year, m.month - 1, 1);
      const end = new Date(m.year, m.month, 0, 23, 59, 59);
      const [ticketCount, headcount] = await Promise.all([
        this.prisma.ticket.count({ where: { tenantId, createdAt: { gte: start, lte: end }, deletedAt: null } }),
        this.prisma.employee.count({ where: { tenantId, status: 'active', createdAt: { lte: end }, deletedAt: null } }),
      ]);
      const ratio = headcount > 0 ? (ticketCount / headcount).toFixed(2) : '0';
      return { ...m, ticketCount, headcount, ticketsPerEmployee: parseFloat(ratio) };
    }));
  }

  // ─── Category Breakdown ───────────────────────────────────────────────────

  async getCategoryBreakdown(tenantId: string) {
    const grouped = await this.prisma.ticket.groupBy({
      by: ['categoryId', 'status'],
      where: { tenantId, deletedAt: null },
      _count: { id: true },
    });

    const categoryIds = [...new Set((grouped as any[]).map((g: any) => g.categoryId).filter(Boolean))];
    const categories = await this.prisma.ticketCategory.findMany({ where: { id: { in: categoryIds } }, select: { id: true, name: true, type: true } });
    const catMap = new Map(categories.map(c => [c.id, c]));

    const map = new Map<string, { name: string; type: string; total: number; open: number; resolved: number; breached: number }>();
    for (const g of grouped as any[]) {
      const cat = catMap.get(g.categoryId) ?? { name: 'Uncategorized', type: 'custom' };
      const key = g.categoryId ?? 'none';
      const prev = map.get(key) ?? { name: cat.name, type: cat.type, total: 0, open: 0, resolved: 0, breached: 0 };
      prev.total += g._count.id;
      if (g.status === 'open' || g.status === 'in-progress') prev.open += g._count.id;
      if (g.status === 'resolved' || g.status === 'closed') prev.resolved += g._count.id;
      map.set(key, prev);
    }

    return Array.from(map.values()).sort((a, b) => b.total - a.total);
  }

  // ─── Leave Query Trend Analysis ───────────────────────────────────────────

  async getLeaveQueryTrend(tenantId: string) {
    const last6months = Array.from({ length: 6 }, (_, i) => {
      const d = new Date(); d.setMonth(d.getMonth() - (5 - i));
      return { year: d.getFullYear(), month: d.getMonth() + 1, label: d.toLocaleString('en-IN', { month: 'short' }) };
    });

    return Promise.all(last6months.map(async (m) => {
      const start = new Date(m.year, m.month - 1, 1);
      const end = new Date(m.year, m.month, 0, 23, 59, 59);
      const [leaveTickets, payrollTickets, itTickets, totalTickets] = await Promise.all([
        this.prisma.ticket.count({ where: { tenantId, type: { in: ['internal'] }, title: { contains: 'leave', mode: 'insensitive' }, createdAt: { gte: start, lte: end }, deletedAt: null } }),
        this.prisma.ticket.count({ where: { tenantId, type: 'payroll', createdAt: { gte: start, lte: end }, deletedAt: null } }),
        this.prisma.ticket.count({ where: { tenantId, type: 'IT', createdAt: { gte: start, lte: end }, deletedAt: null } }),
        this.prisma.ticket.count({ where: { tenantId, createdAt: { gte: start, lte: end }, deletedAt: null } }),
      ]);
      return { ...m, leaveTickets, payrollTickets, itTickets, totalTickets };
    }));
  }
}

// ─── Controller ───────────────────────────────────────────────────────────────

@ApiTags('case-engine/analytics')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('hr-admin', 'super-admin', 'manager')
@Controller('case-engine/analytics')
export class CaseAnalyticsController {
  constructor(private readonly svc: CaseAnalyticsService) {}

  @Get('dashboard')
  @ApiOperation({ summary: 'Case engine dashboard summary — open, SLA breached, resolution rate' })
  getDashboard(@CurrentUser() u: JwtPayload) { return this.svc.getDashboard(u.tid); }

  @Get('volume-trend')
  @ApiOperation({ summary: '12-month ticket volume trend' })
  getVolumeTrend(@CurrentUser() u: JwtPayload) { return this.svc.getVolumeTrend(u.tid); }

  @Get('sla-report')
  @ApiOperation({ summary: 'SLA breach rate, by category, by policy' })
  getSLAReport(@CurrentUser() u: JwtPayload) { return this.svc.getSLAReport(u.tid); }

  @Get('agent-performance')
  @ApiOperation({ summary: 'Agent performance — assigned, resolved, SLA breach rate' })
  getAgentPerformance(@Query('month') month?: string, @Query('year') year?: string, @CurrentUser() u: JwtPayload = {} as any) {
    return this.svc.getAgentPerformance(u.tid, month ? +month : undefined, year ? +year : undefined);
  }

  @Get('headcount-correlation')
  @ApiOperation({ summary: 'Cross-domain: ticket volume vs employee headcount' })
  getHeadcountCorrelation(@CurrentUser() u: JwtPayload) { return this.svc.getTicketHeadcountCorrelation(u.tid); }

  @Get('category-breakdown')
  getCategories(@CurrentUser() u: JwtPayload) { return this.svc.getCategoryBreakdown(u.tid); }

  @Get('leave-query-trend')
  @ApiOperation({ summary: 'Leave/payroll/IT query trends — for automation recommendation' })
  getLeaveQueryTrend(@CurrentUser() u: JwtPayload) { return this.svc.getLeaveQueryTrend(u.tid); }
}

@Module({
  controllers: [CaseAnalyticsController],
  providers: [CaseAnalyticsService],
  exports: [CaseAnalyticsService],
})
export class CaseAnalyticsModule {}
