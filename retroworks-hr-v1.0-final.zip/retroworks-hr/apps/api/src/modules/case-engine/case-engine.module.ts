import { Module } from '@nestjs/common';
import { TicketService, TicketController } from './ticket.service';
import { SLAService, SLAController } from './sla.service';
import { KBService, KBController, CRMService, CRMController, EmailSettingsController } from './kb-crm-email.service';
import { CaseAIService, CaseAIController } from './case-ai.service';
import { AssignmentRulesService, AssignmentRulesController } from './assignment-rules.service';
import { EmailIngestService, EmailIngestController } from './email-ingest.service';
import { CaseAnalyticsService, CaseAnalyticsController } from './case-analytics.service';

@Module({
  controllers: [
    TicketController, SLAController, KBController, CRMController, EmailSettingsController,
    CaseAIController, AssignmentRulesController, EmailIngestController, CaseAnalyticsController,
  ],
  providers: [
    TicketService, SLAService, KBService, CRMService, CaseAIService,
    AssignmentRulesService, EmailIngestService, CaseAnalyticsService,
  ],
  exports: [TicketService, SLAService, KBService, CRMService, AssignmentRulesService, CaseAnalyticsService],
})
export class CaseEngineModule {}
