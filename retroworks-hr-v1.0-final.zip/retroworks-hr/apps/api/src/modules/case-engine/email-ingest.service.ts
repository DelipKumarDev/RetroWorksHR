import { Injectable, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import {
  Controller, Post, Headers, Body, Get, Param, Query, UseGuards, RawBodyRequest, Req,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import * as crypto from 'crypto';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Roles } from '../../common/decorators/permissions.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import type { JwtPayload } from '@retroworks/types';

// ─── Email Provider Adapters ──────────────────────────────────────────────────

interface ParsedEmail {
  messageId: string;
  inReplyTo?: string;
  threadId?: string;
  fromEmail: string;
  fromName?: string;
  toEmail: string;
  subject: string;
  bodyText?: string;
  bodyHtml?: string;
  attachments?: { filename: string; contentType: string; size: number; content?: string }[];
  rawHeaders?: Record<string, string>;
}

class SESAdapter {
  parse(body: any): ParsedEmail | null {
    try {
      const msg = typeof body.Message === 'string' ? JSON.parse(body.Message) : body;
      const mail = msg.mail;
      const content = msg.content ?? '';
      return {
        messageId: mail.messageId,
        fromEmail: mail.source,
        fromName: mail.commonHeaders?.from?.[0] ?? mail.source,
        toEmail: mail.destination?.[0] ?? '',
        subject: mail.commonHeaders?.subject ?? '(no subject)',
        bodyText: content,
        rawHeaders: mail.headers?.reduce((acc: any, h: any) => ({ ...acc, [h.name]: h.value }), {}),
      };
    } catch { return null; }
  }
  validateSignature(_headers: Record<string, string>, _body: string, _secret: string): boolean { return true; } // SES uses SNS signature
}

class MailgunAdapter {
  parse(body: any): ParsedEmail | null {
    try {
      return {
        messageId: body['Message-Id'] ?? body['message-id'],
        inReplyTo: body['In-Reply-To'],
        fromEmail: body.sender ?? body.from,
        fromName: body.from?.replace(/<.*>/, '').trim(),
        toEmail: body.recipient ?? body.To,
        subject: body.subject,
        bodyText: body['body-plain'],
        bodyHtml: body['body-html'],
        attachments: [],
      };
    } catch { return null; }
  }
  validateSignature(headers: Record<string, string>, body: string, secret: string): boolean {
    const timestamp = headers['timestamp'] ?? '';
    const token = headers['token'] ?? '';
    const signature = headers['signature'] ?? '';
    const expected = crypto.createHmac('sha256', secret).update(`${timestamp}${token}`).digest('hex');
    return expected === signature;
  }
}

class GenericWebhookAdapter {
  parse(body: any): ParsedEmail | null {
    if (!body.from || !body.subject) return null;
    return {
      messageId: body.messageId ?? body.message_id ?? `gen_${Date.now()}`,
      inReplyTo: body.inReplyTo ?? body.in_reply_to,
      fromEmail: body.from,
      fromName: body.fromName ?? body.from_name,
      toEmail: body.to,
      subject: body.subject,
      bodyText: body.text ?? body.body ?? body.bodyText,
      bodyHtml: body.html ?? body.bodyHtml,
    };
  }
  validateSignature(_h: any, _b: string, _s: string): boolean { return true; }
}

// ─── Service ─────────────────────────────────────────────────────────────────

@Injectable()
export class EmailIngestService {
  private readonly logger = new Logger(EmailIngestService.name);
  private readonly adapters = {
    ses: new SESAdapter(),
    mailgun: new MailgunAdapter(),
    generic: new GenericWebhookAdapter(),
  };

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
    private readonly config: ConfigService,
  ) {}

  // ─── Inbound Webhook (called by email provider) ───────────────────────────

  async ingestEmail(provider: 'ses' | 'mailgun' | 'generic', tenantId: string, rawBody: any, headers: Record<string, string> = {}) {
    const adapter = this.adapters[provider] ?? this.adapters.generic;
    const parsed = adapter.parse(rawBody);
    if (!parsed) { this.logger.warn(`Email parse failed for provider ${provider}`); return { parsed: false }; }

    // Dedup by messageId
    const existing = await this.prisma.inboundEmail.findFirst({ where: { messageId: parsed.messageId } });
    if (existing) return { parsed: true, duplicate: true, id: existing.id };

    const record = await this.prisma.inboundEmail.create({
      data: {
        tenantId, messageId: parsed.messageId, inReplyTo: parsed.inReplyTo,
        fromEmail: parsed.fromEmail, fromName: parsed.fromName,
        toEmail: parsed.toEmail, subject: parsed.subject,
        bodyText: parsed.bodyText, bodyHtml: parsed.bodyHtml,
        attachments: parsed.attachments as any,
        rawHeaders: parsed.rawHeaders as any,
        parsed: false, receivedAt: new Date(),
      },
    });

    // Process asynchronously
    this.processInboundEmail(record.id, tenantId).catch(e => this.logger.error(`Email processing error: ${e.message}`));
    return { parsed: true, emailId: record.id };
  }

  private async processInboundEmail(emailId: string, tenantId: string) {
    const email = await this.prisma.inboundEmail.findFirst({ where: { id: emailId } });
    if (!email) return;

    try {
      // Check if this is a reply to an existing thread
      if (email.inReplyTo || email.threadId) {
        const parentEmail = await this.prisma.inboundEmail.findFirst({
          where: { tenantId, messageId: email.inReplyTo ?? '' },
          select: { ticketId: true },
        });
        if (parentEmail?.ticketId) {
          // Add as reply to existing ticket
          await this.prisma.ticketMessage.create({
            data: {
              tenantId, ticketId: parentEmail.ticketId,
              authorId: email.fromEmail, authorType: 'contact',
              body: email.bodyText ?? email.bodyHtml ?? '',
              isInternal: false,
              metadata: { emailId: email.id, fromEmail: email.fromEmail } as any,
              createdBy: 'system', updatedBy: 'system',
            },
          });
          await this.prisma.inboundEmail.update({ where: { id: emailId }, data: { parsed: true, ticketId: parentEmail.ticketId } });
          this.events.emit('case.ticket.email_reply', { tenantId, ticketId: parentEmail.ticketId, fromEmail: email.fromEmail });
          return;
        }
      }

      // New ticket from email
      const ticketNumber = `RW-${new Date().getFullYear()}-${String(Date.now()).slice(-5)}`;
      const defaultCategory = await this.prisma.ticketCategory.findFirst({ where: { tenantId, type: 'external' } });
      const defaultSla = await this.prisma.sLAPolicy.findFirst({ where: { tenantId, isDefault: true } });

      const ticket = await this.prisma.ticket.create({
        data: {
          tenantId, ticketNumber, type: 'external',
          title: email.subject ?? '(no subject)',
          description: email.bodyText ?? '',
          status: 'open', priority: 'p3',
          source: 'email',
          categoryId: defaultCategory?.id,
          slaId: defaultSla?.id,
          requesterId: email.fromEmail, requesterType: 'contact',
          createdBy: 'system', updatedBy: 'system',
        },
      });

      // Send auto-reply
      this.events.emit('case.email.auto_reply', {
        tenantId,
        to: email.fromEmail,
        ticketNumber: ticket.ticketNumber,
        subject: `Re: ${email.subject} [${ticket.ticketNumber}]`,
        templateId: 'ticket_created',
      });

      await this.prisma.inboundEmail.update({ where: { id: emailId }, data: { parsed: true, ticketId: ticket.id } });
      this.events.emit('case.ticket.created', { tenantId, ticketId: ticket.id, source: 'email' });
      this.logger.log(`Created ticket ${ticket.ticketNumber} from email ${email.fromEmail}`);
    } catch (err: any) {
      await this.prisma.inboundEmail.update({ where: { id: emailId }, data: { parseError: err.message } });
    }
  }

  // ─── Email Log Endpoints ──────────────────────────────────────────────────

  async listInboundEmails(tenantId: string, limit = 50, offset = 0) {
    const [items, total] = await Promise.all([
      this.prisma.inboundEmail.findMany({ where: { tenantId }, orderBy: { receivedAt: 'desc' }, take: limit, skip: offset }),
      this.prisma.inboundEmail.count({ where: { tenantId } }),
    ]);
    return { items, total, limit, offset };
  }

  async retryParsing(tenantId: string, emailId: string) {
    const email = await this.prisma.inboundEmail.findFirst({ where: { id: emailId, tenantId } });
    if (!email) return { error: 'Email not found' };
    await this.prisma.inboundEmail.update({ where: { id: emailId }, data: { parsed: false, parseError: null, ticketId: null } });
    await this.processInboundEmail(emailId, tenantId);
    return { retrying: true };
  }

  async getEmailStats(tenantId: string) {
    const [total, parsed, failed, unlinked] = await Promise.all([
      this.prisma.inboundEmail.count({ where: { tenantId } }),
      this.prisma.inboundEmail.count({ where: { tenantId, parsed: true } }),
      this.prisma.inboundEmail.count({ where: { tenantId, parseError: { not: null } } }),
      this.prisma.inboundEmail.count({ where: { tenantId, parsed: true, ticketId: null } }),
    ]);
    return { total, parsed, failed, unlinked, successRate: total > 0 ? ((parsed / total) * 100).toFixed(1) + '%' : '0%' };
  }
}

// ─── Controller ───────────────────────────────────────────────────────────────

@ApiTags('case-engine/email')
@Controller('case-engine/email')
export class EmailIngestController {
  constructor(private readonly svc: EmailIngestService) {}

  @Post('inbound/:provider/:tenantId')
  @ApiOperation({ summary: 'Inbound email webhook — called by SES/Mailgun/SMTP provider' })
  async ingest(
    @Param('provider') provider: 'ses' | 'mailgun' | 'generic',
    @Param('tenantId') tenantId: string,
    @Body() body: any,
    @Headers() headers: Record<string, string>,
  ) {
    return this.svc.ingestEmail(provider, tenantId, body, headers);
  }

  @Get('log')
  @UseGuards(AuthGuard('jwt'), TenantGuard)
  @Roles('hr-admin', 'super-admin')
  @ApiBearerAuth()
  @ApiOperation({ summary: 'List inbound email log' })
  listEmails(@Query('limit') limit = 50, @Query('offset') offset = 0, @CurrentUser() u: JwtPayload) {
    return this.svc.listInboundEmails(u.tid, +limit, +offset);
  }

  @Get('stats')
  @UseGuards(AuthGuard('jwt'), TenantGuard)
  @Roles('hr-admin', 'super-admin')
  @ApiBearerAuth()
  getStats(@CurrentUser() u: JwtPayload) { return this.svc.getEmailStats(u.tid); }

  @Post('log/:id/retry')
  @UseGuards(AuthGuard('jwt'), TenantGuard)
  @Roles('hr-admin', 'super-admin')
  @ApiBearerAuth()
  retry(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.retryParsing(u.tid, id); }
}

@Module({
  controllers: [EmailIngestController],
  providers: [EmailIngestService],
  exports: [EmailIngestService],
})
export class EmailIngestModule {}
