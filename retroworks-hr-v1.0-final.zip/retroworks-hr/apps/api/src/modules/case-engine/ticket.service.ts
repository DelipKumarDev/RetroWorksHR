import {
  Injectable, Logger, NotFoundException, BadRequestException, ForbiddenException,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2, OnEvent } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import {
  Controller, Get, Post, Put, Delete, Patch, Body, Param, Query, UseGuards, Request as Req,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import type { JwtPayload } from '@retroworks/types';

// ─── Ticket Number Generator ─────────────────────────────────────────────────

async function generateTicketNumber(prisma: PrismaClient, tenantId: string): Promise<string> {
  const year = new Date().getFullYear();
  const count = await prisma.ticket.count({ where: { tenantId, ticketNumber: { startsWith: `RW-${year}` } } });
  return `RW-${year}-${String(count + 1).padStart(5, '0')}`;
}

// ─── SLA Deadline Calculator ──────────────────────────────────────────────────

function calcSlaDue(sla: any, priority: string, fromDate: Date): { response: Date; resolution: Date } {
  const responseMin = (sla as Record<string, number>)[`${priority}ResponseMinutes`] ?? 480;
  const resolutionMin = (sla as Record<string, number>)[`${priority}ResolutionMinutes`] ?? 2880;
  // Simplified: add minutes directly. Business-hours-aware version runs in SLA engine.
  return {
    response: new Date(fromDate.getTime() + responseMin * 60_000),
    resolution: new Date(fromDate.getTime() + resolutionMin * 60_000),
  };
}

// ─── Service ─────────────────────────────────────────────────────────────────

@Injectable()
export class TicketService {
  readonly logger = new Logger(TicketService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
    private readonly config: ConfigService,
  ) {}

  // ─── CRUD ────────────────────────────────────────────────────────────────

  async createTicket(tenantId: string, dto: {
    type: string; title: string; description?: string; priority?: string;
    categoryId?: string; subcategoryId?: string;
    linkedEntityType?: string; linkedEntityId?: string;
    requesterId?: string; requesterType?: string;
    tags?: string[]; customFields?: Record<string, unknown>;
    source?: string;
  }, createdBy: string) {
    const ticketNumber = await generateTicketNumber(this.prisma, tenantId);
    const priority = dto.priority ?? 'p3';

    // Resolve category → default SLA
    let slaId: string | undefined;
    let category;
    if (dto.categoryId) {
      category = await this.prisma.ticketCategory.findFirst({ where: { id: dto.categoryId, tenantId } });
      if (category?.defaultSlaId) slaId = category.defaultSlaId;
    }
    if (!slaId) {
      const defaultSla = await this.prisma.sLAPolicy.findFirst({ where: { tenantId, isDefault: true } });
      slaId = defaultSla?.id;
    }

    // Calculate SLA deadlines
    let slaResponseDue: Date | undefined;
    let slaResolutionDue: Date | undefined;
    if (slaId) {
      const sla = await this.prisma.sLAPolicy.findFirst({ where: { id: slaId } });
      if (sla) {
        const deadlines = calcSlaDue(sla, priority, new Date());
        slaResponseDue = deadlines.response;
        slaResolutionDue = deadlines.resolution;
      }
    }

    const ticket = await this.prisma.ticket.create({
      data: {
        tenantId, ticketNumber, type: dto.type, title: dto.title,
        description: dto.description, priority, status: 'open',
        categoryId: dto.categoryId, subcategoryId: dto.subcategoryId,
        slaId, slaResponseDue, slaResolutionDue,
        requesterId: dto.requesterId ?? createdBy,
        requesterType: dto.requesterType ?? 'employee',
        linkedEntityType: dto.linkedEntityType,
        linkedEntityId: dto.linkedEntityId,
        tags: dto.tags ?? [],
        customFields: dto.customFields as any,
        source: dto.source ?? 'web',
        createdBy, updatedBy: createdBy,
      },
    });

    // Activity log
    await this.logActivity(tenantId, ticket.id, createdBy, 'created', undefined, ticket.status);

    // Apply assignment rules
    await this.applyAssignmentRules(tenantId, ticket);

    // Emit domain event
    this.events.emit('case.ticket.created', {
      tenantId, ticketId: ticket.id, ticketNumber, type: dto.type,
      priority, categoryId: dto.categoryId, linkedEntityType: dto.linkedEntityType,
      linkedEntityId: dto.linkedEntityId, createdBy,
    });

    return ticket;
  }

  async listTickets(tenantId: string, query: {
    status?: string; priority?: string; type?: string; assigneeId?: string;
    categoryId?: string; requesterId?: string; slaBreached?: string;
    linkedEntityType?: string; linkedEntityId?: string;
    search?: string; limit?: number; offset?: number; sortBy?: string; sortOrder?: string;
  }) {
    const limit = Math.min(query.limit ?? 25, 200);
    const offset = query.offset ?? 0;
    const where: any = { tenantId, deletedAt: null };

    if (query.status) where.status = query.status;
    if (query.priority) where.priority = query.priority;
    if (query.type) where.type = query.type;
    if (query.assigneeId) where.assigneeId = query.assigneeId;
    if (query.categoryId) where.categoryId = query.categoryId;
    if (query.requesterId) where.requesterId = query.requesterId;
    if (query.slaBreached === 'true') where.slaBreached = true;
    if (query.linkedEntityType) where.linkedEntityType = query.linkedEntityType;
    if (query.linkedEntityId) where.linkedEntityId = query.linkedEntityId;
    if (query.search) {
      where.OR = [
        { title: { contains: query.search, mode: 'insensitive' } },
        { ticketNumber: { contains: query.search, mode: 'insensitive' } },
        { description: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    const [total, tickets] = await Promise.all([
      this.prisma.ticket.count({ where }),
      this.prisma.ticket.findMany({
        where, take: limit, skip: offset,
        orderBy: { [query.sortBy ?? 'createdAt']: query.sortOrder ?? 'desc' },
        include: {
          category: { select: { name: true, color: true, icon: true } },
          assignee: { select: { firstName: true, lastName: true, employeeCode: true } },
          sla: { select: { name: true } },
          _count: { select: { messages: true, attachments: true } },
        },
      }),
    ]);

    return { tickets, total, limit, offset };
  }

  async getTicket(tenantId: string, ticketId: string) {
    const ticket = await this.prisma.ticket.findFirst({
      where: { id: ticketId, tenantId, deletedAt: null },
      include: {
        category: true, sla: true,
        assignee: { select: { firstName: true, lastName: true, employeeCode: true, designation: { select: { name: true } } } },
        messages: {
          where: { deletedAt: null },
          orderBy: { createdAt: 'asc' },
          include: { attachments: true },
        },
        activities: { orderBy: { createdAt: 'asc' } },
        attachments: true,
        followers: true,
        slaEvents: { orderBy: { triggeredAt: 'desc' }, take: 10 },
        tagLinks: { include: { tag: true } },
      },
    });
    if (!ticket) throw new NotFoundException('Ticket not found');
    return ticket;
  }

  async updateTicket(tenantId: string, ticketId: string, dto: any, updatedBy: string) {
    const existing = await this.prisma.ticket.findFirst({ where: { id: ticketId, tenantId, deletedAt: null } });
    if (!existing) throw new NotFoundException('Ticket not found');

    const updates: any = { ...dto, updatedBy };
    const ticket = await this.prisma.ticket.update({ where: { id: ticketId }, data: updates });

    // Activity logs for key changes
    if (dto.status && dto.status !== existing.status) {
      await this.logActivity(tenantId, ticketId, updatedBy, 'status_changed', existing.status, dto.status);
      if (dto.status === 'resolved') {
        await this.prisma.ticket.update({ where: { id: ticketId }, data: { resolvedAt: new Date() } });
        this.events.emit('case.ticket.resolved', { tenantId, ticketId, ticketNumber: ticket.ticketNumber, resolvedBy: updatedBy });
      }
      if (dto.status === 'closed') {
        await this.prisma.ticket.update({ where: { id: ticketId }, data: { closedAt: new Date() } });
        this.events.emit('case.ticket.closed', { tenantId, ticketId, ticketNumber: ticket.ticketNumber });
      }
    }
    if (dto.assigneeId && dto.assigneeId !== existing.assigneeId) {
      await this.logActivity(tenantId, ticketId, updatedBy, 'assigned', existing.assigneeId ?? undefined, dto.assigneeId);
      this.events.emit('case.ticket.assigned', { tenantId, ticketId, assigneeId: dto.assigneeId, updatedBy });
    }
    if (dto.priority && dto.priority !== existing.priority) {
      await this.logActivity(tenantId, ticketId, updatedBy, 'priority_changed', existing.priority, dto.priority);
    }

    return ticket;
  }

  async deleteTicket(tenantId: string, ticketId: string) {
    return this.prisma.ticket.update({ where: { id: ticketId }, data: { deletedAt: new Date() } });
  }

  // ─── Messaging ──────────────────────────────────────────────────────────

  async addMessage(tenantId: string, ticketId: string, dto: {
    body: string; isInternal?: boolean; authorId?: string; authorType?: string; isAiDraft?: boolean;
  }, authorId: string) {
    const ticket = await this.prisma.ticket.findFirst({ where: { id: ticketId, tenantId, deletedAt: null } });
    if (!ticket) throw new NotFoundException('Ticket not found');

    const message = await this.prisma.ticketMessage.create({
      data: {
        tenantId, ticketId, body: dto.body,
        isInternal: dto.isInternal ?? false,
        isAiDraft: dto.isAiDraft ?? false,
        authorId: dto.authorId ?? authorId,
        authorType: dto.authorType ?? 'employee',
        createdBy: authorId, updatedBy: authorId,
      },
    });

    // Mark first response SLA
    if (!ticket.firstResponseAt && !dto.isInternal) {
      await this.prisma.ticket.update({ where: { id: ticketId }, data: { firstResponseAt: new Date() } });
    }

    await this.logActivity(tenantId, ticketId, authorId, dto.isInternal ? 'internal_note_added' : 'reply_sent');

    this.events.emit('case.message.added', {
      tenantId, ticketId, messageId: message.id,
      isInternal: dto.isInternal, authorId,
      requesterId: ticket.requesterId,
    });

    return message;
  }

  async listMessages(tenantId: string, ticketId: string) {
    return this.prisma.ticketMessage.findMany({
      where: { ticketId, tenantId, deletedAt: null },
      orderBy: { createdAt: 'asc' },
      include: { attachments: true },
    });
  }

  // ─── Tags ───────────────────────────────────────────────────────────────

  async addTag(tenantId: string, ticketId: string, tagName: string, userId: string) {
    let tag = await this.prisma.ticketTag.findFirst({ where: { tenantId, name: tagName } });
    if (!tag) tag = await this.prisma.ticketTag.create({ data: { tenantId, name: tagName, createdBy: userId } });
    await this.prisma.ticketTagLink.upsert({ where: { ticketId_tagId: { ticketId, tagId: tag.id } }, create: { ticketId, tagId: tag.id }, update: {} }).catch(() => {});
    await this.logActivity(tenantId, ticketId, userId, 'tag_added', undefined, tagName);
    return tag;
  }

  async listTags(tenantId: string) {
    return this.prisma.ticketTag.findMany({ where: { tenantId }, orderBy: { name: 'asc' } });
  }

  // ─── Followers ──────────────────────────────────────────────────────────

  async addFollower(tenantId: string, ticketId: string, userId: string) {
    return this.prisma.ticketFollower.upsert({
      where: { ticketId_userId: { ticketId, userId } },
      create: { tenantId, ticketId, userId },
      update: {},
    });
  }

  async removeFollower(tenantId: string, ticketId: string, userId: string) {
    return this.prisma.ticketFollower.deleteMany({ where: { ticketId, userId } });
  }

  // ─── Categories ─────────────────────────────────────────────────────────

  async listCategories(tenantId: string, type?: string) {
    return this.prisma.ticketCategory.findMany({
      where: { tenantId, deletedAt: null, parentId: null, ...(type ? { type } : {}) },
      include: { children: { where: { deletedAt: null }, orderBy: { sortOrder: 'asc' } } },
      orderBy: { sortOrder: 'asc' },
    });
  }

  async createCategory(tenantId: string, dto: any, createdBy: string) {
    return this.prisma.ticketCategory.create({ data: { tenantId, ...dto, createdBy, updatedBy: createdBy } });
  }

  async updateCategory(tenantId: string, catId: string, dto: any, updatedBy: string) {
    return this.prisma.ticketCategory.update({ where: { id: catId }, data: { ...dto, updatedBy } });
  }

  async deleteCategory(tenantId: string, catId: string) {
    return this.prisma.ticketCategory.update({ where: { id: catId }, data: { deletedAt: new Date() } });
  }

  // ─── Assignment Rules ────────────────────────────────────────────────────

  async applyAssignmentRules(tenantId: string, ticket: any) {
    const rules = await this.prisma.assignmentRule.findMany({
      where: { tenantId, isActive: true, deletedAt: null },
      orderBy: { priority: 'desc' },
    });

    for (const rule of rules) {
      const conditions = rule.conditions as any[];
      const logic = rule.conditionLogic;
      const matches = conditions.map(c => this.evalCondition(c, ticket));
      const isMatch = logic === 'OR' ? matches.some(Boolean) : matches.every(Boolean);
      if (!isMatch) continue;

      const actions = rule.actions as any[];
      for (const action of actions) {
        await this.applyRuleAction(tenantId, ticket.id, action);
      }
      await this.prisma.assignmentRule.update({ where: { id: rule.id }, data: { runCount: { increment: 1 }, lastRunAt: new Date() } });
      break; // First matching rule wins
    }
  }

  private evalCondition(c: { field: string; operator: string; value: any }, ticket: any): boolean {
    const v = ticket[c.field];
    switch (c.operator) {
      case 'eq': return v === c.value;
      case 'neq': return v !== c.value;
      case 'in': return Array.isArray(c.value) && c.value.includes(v);
      case 'contains': return String(v ?? '').toLowerCase().includes(String(c.value).toLowerCase());
      default: return false;
    }
  }

  private async applyRuleAction(tenantId: string, ticketId: string, action: { type: string; value: any }) {
    switch (action.type) {
      case 'assign_to_agent':
        await this.prisma.ticket.update({ where: { id: ticketId }, data: { assigneeId: action.value, updatedBy: 'system' } });
        break;
      case 'assign_to_group':
        await this.prisma.ticket.update({ where: { id: ticketId }, data: { assignedGroupId: action.value, updatedBy: 'system' } });
        break;
      case 'set_sla':
        await this.prisma.ticket.update({ where: { id: ticketId }, data: { slaId: action.value, updatedBy: 'system' } });
        break;
      case 'set_priority':
        await this.prisma.ticket.update({ where: { id: ticketId }, data: { priority: action.value, updatedBy: 'system' } });
        break;
    }
  }

  async listAssignmentRules(tenantId: string) {
    return this.prisma.assignmentRule.findMany({ where: { tenantId, deletedAt: null }, orderBy: { priority: 'desc' } });
  }

  async createAssignmentRule(tenantId: string, dto: any, createdBy: string) {
    return this.prisma.assignmentRule.create({ data: { tenantId, ...dto, createdBy, updatedBy: createdBy } });
  }

  async updateAssignmentRule(tenantId: string, ruleId: string, dto: any, updatedBy: string) {
    return this.prisma.assignmentRule.update({ where: { id: ruleId }, data: { ...dto, updatedBy } });
  }

  async deleteAssignmentRule(tenantId: string, ruleId: string) {
    return this.prisma.assignmentRule.update({ where: { id: ruleId }, data: { deletedAt: new Date() } });
  }

  // ─── Stats & Dashboard ──────────────────────────────────────────────────

  async getDashboardStats(tenantId: string) {
    const [open, inProgress, pending, resolved, breached, myTickets, todayCreated] = await Promise.all([
      this.prisma.ticket.count({ where: { tenantId, status: 'open', deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, status: 'in-progress', deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, status: 'pending', deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, status: 'resolved', deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, slaBreached: true, status: { notIn: ['resolved', 'closed'] }, deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, status: { notIn: ['resolved', 'closed'] }, deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) }, deletedAt: null } }),
    ]);

    // Volume by type
    const byType = await this.prisma.ticket.groupBy({
      by: ['type'], where: { tenantId, deletedAt: null },
      _count: { id: true },
    });

    // Volume by priority
    const byPriority = await this.prisma.ticket.groupBy({
      by: ['priority'], where: { tenantId, status: { notIn: ['resolved', 'closed'] }, deletedAt: null },
      _count: { id: true },
    });

    // 7-day trend
    const trend = await Promise.all(Array.from({ length: 7 }, (_, i) => {
      const d = new Date(); d.setDate(d.getDate() - (6 - i)); d.setHours(0, 0, 0, 0);
      const next = new Date(d); next.setDate(d.getDate() + 1);
      return this.prisma.ticket.count({ where: { tenantId, createdAt: { gte: d, lt: next }, deletedAt: null } })
        .then(count => ({ date: d.toISOString().slice(0, 10), count }));
    }));

    return {
      open, inProgress, pending, resolved, breached,
      total: myTickets, todayCreated,
      byType: byType.map((g: any) => ({ type: g.type, count: g._count.id })),
      byPriority: byPriority.map((g: any) => ({ priority: g.priority, count: g._count.id })),
      trend,
    };
  }

  async getKanbanData(tenantId: string, userId?: string) {
    const where: any = { tenantId, deletedAt: null, status: { notIn: ['closed'] } };
    if (userId) where.assigneeId = userId;

    const tickets = await this.prisma.ticket.findMany({
      where,
      orderBy: [{ priority: 'asc' }, { createdAt: 'asc' }],
      include: {
        category: { select: { name: true, color: true } },
        assignee: { select: { firstName: true, lastName: true } },
        tagLinks: { include: { tag: { select: { name: true, color: true } } } },
      },
      take: 500,
    });

    const columns: Record<string, any[]> = { 'open': [], 'in-progress': [], 'pending': [], 'resolved': [] };
    for (const t of tickets) {
      const col = columns[t.status] ?? columns['open'];
      col.push(t);
    }
    return { columns, total: tickets.length };
  }

  // ─── Cross-Domain Event Listeners ────────────────────────────────────────

  @OnEvent('hr.employee.created')
  async onEmployeeCreated(payload: { tenantId: string; employeeId: string; employeeName: string; createdBy: string }) {
    await this.createTicket(payload.tenantId, {
      type: 'IT',
      title: `IT Asset Setup — ${payload.employeeName}`,
      description: 'Auto-created: New employee onboarding. Please provision laptop, access cards, and software licenses.',
      priority: 'p2',
      linkedEntityType: 'employee',
      linkedEntityId: payload.employeeId,
      source: 'hr-automation',
      tags: ['onboarding', 'it-setup'],
    }, 'system').catch(e => this.logger.warn(`Failed to create onboarding IT ticket: ${e.message}`));
  }

  @OnEvent('hr.employee.exit')
  async onEmployeeExit(payload: { tenantId: string; employeeId: string; employeeName: string }) {
    await this.createTicket(payload.tenantId, {
      type: 'admin',
      title: `Exit Clearance — ${payload.employeeName}`,
      description: 'Auto-created: Employee exit initiated. Complete asset return, access revocation, and settlement.',
      priority: 'p1',
      linkedEntityType: 'employee',
      linkedEntityId: payload.employeeId,
      source: 'hr-automation',
      tags: ['exit', 'clearance'],
    }, 'system').catch(e => this.logger.warn(`Failed to create exit clearance ticket: ${e.message}`));
  }

  @OnEvent('payroll.anomaly.detected')
  async onPayrollAnomaly(payload: { tenantId: string; employeeId: string; employeeName: string; issues: string[] }) {
    await this.createTicket(payload.tenantId, {
      type: 'payroll',
      title: `Payroll Anomaly — ${payload.employeeName}`,
      description: `Auto-detected payroll anomaly:\n${payload.issues.join('\n')}`,
      priority: 'p1',
      linkedEntityType: 'employee',
      linkedEntityId: payload.employeeId,
      source: 'hr-automation',
      tags: ['payroll', 'anomaly'],
    }, 'system').catch(e => this.logger.warn(`Failed to create payroll anomaly ticket: ${e.message}`));
  }

  // ─── Activity Helper ────────────────────────────────────────────────────

  private async logActivity(tenantId: string, ticketId: string, actorId: string, event: string, oldValue?: string, newValue?: string) {
    return this.prisma.ticketActivity.create({
      data: { tenantId, ticketId, actorId, actorType: actorId === 'system' ? 'system' : 'employee', event, oldValue, newValue },
    }).catch(() => {});
  }
}

// ─── Controller ───────────────────────────────────────────────────────────────

@ApiTags('case-engine/tickets')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('case-engine/tickets')
export class TicketController {
  constructor(private readonly svc: TicketService) {}

  @Get('dashboard')
  @ApiOperation({ summary: 'Ticket dashboard stats — volumes, SLA breach count, 7-day trend' })
  getDashboard(@CurrentUser() u: JwtPayload) { return this.svc.getDashboardStats(u.tid); }

  @Get('kanban')
  @ApiOperation({ summary: 'Kanban board data — tickets grouped by status column' })
  getKanban(@Query('assigneeId') aid: string, @CurrentUser() u: JwtPayload) { return this.svc.getKanbanData(u.tid, aid); }

  @Get()
  @ApiOperation({ summary: 'List tickets with filters, search, pagination' })
  listTickets(@Query() query: any, @CurrentUser() u: JwtPayload) { return this.svc.listTickets(u.tid, query); }

  @Get(':id')
  getTicket(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getTicket(u.tid, id); }

  @Post()
  @ApiOperation({ summary: 'Create a new ticket (entity-agnostic)' })
  createTicket(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createTicket(u.tid, dto, u.sub); }

  @Put(':id')
  updateTicket(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateTicket(u.tid, id, dto, u.sub); }

  @Patch(':id/status')
  @ApiOperation({ summary: 'Update ticket status — triggers SLA and activity logging' })
  updateStatus(@Param('id') id: string, @Body() dto: { status: string }, @CurrentUser() u: JwtPayload) { return this.svc.updateTicket(u.tid, id, dto, u.sub); }

  @Patch(':id/assign')
  @ApiOperation({ summary: 'Assign ticket to agent or group' })
  assignTicket(@Param('id') id: string, @Body() dto: { assigneeId?: string; assignedGroupId?: string }, @CurrentUser() u: JwtPayload) { return this.svc.updateTicket(u.tid, id, dto, u.sub); }

  @Delete(':id')
  @Roles('hr-admin', 'super-admin')
  deleteTicket(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteTicket(u.tid, id); }

  // Messages
  @Get(':id/messages')
  @ApiOperation({ summary: 'Get ticket thread — public replies and internal notes' })
  listMessages(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.listMessages(u.tid, id); }

  @Post(':id/messages')
  @ApiOperation({ summary: 'Add reply or internal note to ticket' })
  addMessage(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.addMessage(u.tid, id, dto, u.sub); }

  // Tags
  @Post(':id/tags')
  addTag(@Param('id') id: string, @Body() dto: { name: string }, @CurrentUser() u: JwtPayload) { return this.svc.addTag(u.tid, id, dto.name, u.sub); }

  @Get('tags/list')
  listTags(@CurrentUser() u: JwtPayload) { return this.svc.listTags(u.tid); }

  // Followers
  @Post(':id/followers')
  addFollower(@Param('id') id: string, @Body() dto: { userId: string }, @CurrentUser() u: JwtPayload) { return this.svc.addFollower(u.tid, id, dto.userId); }

  @Delete(':id/followers/:userId')
  removeFollower(@Param('id') id: string, @Param('userId') userId: string, @CurrentUser() u: JwtPayload) { return this.svc.removeFollower(u.tid, id, userId); }

  // Categories
  @Get('categories/list')
  @ApiOperation({ summary: 'List ticket categories with subcategories' })
  listCategories(@Query('type') type: string, @CurrentUser() u: JwtPayload) { return this.svc.listCategories(u.tid, type); }

  @Post('categories')
  @Roles('hr-admin', 'super-admin')
  createCategory(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createCategory(u.tid, dto, u.sub); }

  @Put('categories/:id')
  @Roles('hr-admin', 'super-admin')
  updateCategory(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateCategory(u.tid, id, dto, u.sub); }

  @Delete('categories/:id')
  @Roles('hr-admin', 'super-admin')
  deleteCategory(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteCategory(u.tid, id); }

  // Assignment rules
  @Get('assignment-rules/list')
  @Roles('hr-admin', 'super-admin')
  listRules(@CurrentUser() u: JwtPayload) { return this.svc.listAssignmentRules(u.tid); }

  @Post('assignment-rules')
  @Roles('hr-admin', 'super-admin')
  createRule(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createAssignmentRule(u.tid, dto, u.sub); }

  @Put('assignment-rules/:id')
  @Roles('hr-admin', 'super-admin')
  updateRule(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateAssignmentRule(u.tid, id, dto, u.sub); }

  @Delete('assignment-rules/:id')
  @Roles('hr-admin', 'super-admin')
  deleteRule(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteAssignmentRule(u.tid, id); }
}
