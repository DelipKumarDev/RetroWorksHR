import { Injectable, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { RedisLockService } from '../../common/security/redis-lock.service';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Cron } from '@nestjs/schedule';
import {
  Controller, Get, Post, Put, Delete, Body, Param, UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── Business Hours Calculator ────────────────────────────────────────────────

export function calcBusinessMinutes(sla: any, fromDate: Date, toDate: Date): number {
  const workdays: number[] = sla.workdays ?? [1, 2, 3, 4, 5];
  const [startH, startM] = (sla.workdayStart ?? '09:00').split(':').map(Number);
  const [endH, endM] = (sla.workdayEnd ?? '18:00').split(':').map(Number);
  const dayMinutes = (endH * 60 + endM) - (startH * 60 + startM);

  let minutes = 0;
  const cursor = new Date(fromDate);

  while (cursor < toDate) {
    const dow = cursor.getDay();
    if (workdays.includes(dow)) {
      const dayStart = new Date(cursor);
      dayStart.setHours(startH, startM, 0, 0);
      const dayEnd = new Date(cursor);
      dayEnd.setHours(endH, endM, 0, 0);
      const segStart = cursor > dayStart ? cursor : dayStart;
      const segEnd = toDate < dayEnd ? toDate : dayEnd;
      if (segStart < segEnd) minutes += (segEnd.getTime() - segStart.getTime()) / 60_000;
    }
    // Advance to next day
    cursor.setDate(cursor.getDate() + 1);
    cursor.setHours(startH, startM, 0, 0);
  }
  return Math.round(minutes);
}

export function calcSlaDueDate(sla: any, priority: string, fromDate: Date): { responseDue: Date; resolutionDue: Date } {
  const responseMin: number = (sla as any)[`${priority}ResponseMinutes`] ?? 480;
  const resolutionMin: number = (sla as any)[`${priority}ResolutionMinutes`] ?? 2880;

  if (!sla.businessHoursOnly) {
    return {
      responseDue: new Date(fromDate.getTime() + responseMin * 60_000),
      resolutionDue: new Date(fromDate.getTime() + resolutionMin * 60_000),
    };
  }

  // Business-hours-aware: add workable minutes
  const workdays: number[] = sla.workdays ?? [1, 2, 3, 4, 5];
  const [startH, startM] = (sla.workdayStart ?? '09:00').split(':').map(Number);
  const [endH, endM] = (sla.workdayEnd ?? '18:00').split(':').map(Number);

  const addBizMinutes = (from: Date, mins: number): Date => {
    const cursor = new Date(from);
    let remaining = mins;
    while (remaining > 0) {
      const dow = cursor.getDay();
      if (workdays.includes(dow)) {
        const dayEnd = new Date(cursor);
        dayEnd.setHours(endH, endM, 0, 0);
        const available = Math.max(0, (dayEnd.getTime() - cursor.getTime()) / 60_000);
        if (available >= remaining) { cursor.setTime(cursor.getTime() + remaining * 60_000); remaining = 0; }
        else { remaining -= available; cursor.setHours(endH, endM, 0, 0); }
      }
      if (remaining > 0) {
        cursor.setDate(cursor.getDate() + 1);
        cursor.setHours(startH, startM, 0, 0);
      }
    }
    return cursor;
  };

  return {
    responseDue: addBizMinutes(fromDate, responseMin),
    resolutionDue: addBizMinutes(fromDate, resolutionMin),
  };
}

// ─── SLA Service ──────────────────────────────────────────────────────────────

@Injectable()
export class SLAService {
  private readonly logger = new Logger(SLAService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2
    private readonly redisLock: RedisLockService,
  ) {}

  // ─── SLA Policy CRUD ─────────────────────────────────────────────────────

  async listSLAs(tenantId: string) {
    return this.prisma.sLAPolicy.findMany({ where: { tenantId, deletedAt: null }, orderBy: { isDefault: 'desc' } });
  }

  async getSLA(tenantId: string, slaId: string) {
    return this.prisma.sLAPolicy.findFirst({ where: { id: slaId, tenantId, deletedAt: null } });
  }

  async createSLA(tenantId: string, dto: any, createdBy: string) {
    if (dto.isDefault) {
      await this.prisma.sLAPolicy.updateMany({ where: { tenantId }, data: { isDefault: false } });
    }
    return this.prisma.sLAPolicy.create({ data: { tenantId, ...dto, createdBy, updatedBy: createdBy } });
  }

  async updateSLA(tenantId: string, slaId: string, dto: any, updatedBy: string) {
    if (dto.isDefault) {
      await this.prisma.sLAPolicy.updateMany({ where: { tenantId, id: { not: slaId } }, data: { isDefault: false } });
    }
    return this.prisma.sLAPolicy.update({ where: { id: slaId }, data: { ...dto, updatedBy } });
  }

  async deleteSLA(tenantId: string, slaId: string) {
    return this.prisma.sLAPolicy.update({ where: { id: slaId }, data: { deletedAt: new Date() } });
  }

  // ─── Apply SLA to Ticket ──────────────────────────────────────────────────

  async applySLAToTicket(tenantId: string, ticketId: string, slaId: string, priority: string) {
    const sla = await this.prisma.sLAPolicy.findFirst({ where: { id: slaId, tenantId } });
    if (!sla) return;
    const { responseDue, resolutionDue } = calcSlaDueDate(sla, priority, new Date());
    await this.prisma.ticket.update({ where: { id: ticketId }, data: { slaResponseDue: responseDue, slaResolutionDue: resolutionDue, updatedBy: 'system' } });
    await this.prisma.sLAEvent.create({ data: { tenantId, ticketId, slaId, eventType: 'sla_applied', priority, dueAt: resolutionDue } });
    this.logger.debug(`SLA applied to ${ticketId} — response due ${responseDue.toISOString()}`);
  }

  // ─── SLA Monitor Cron ─────────────────────────────────────────────────────

  @Cron('*/5 * * * *', { name: 'sla-monitor' }) // Every 5 minutes
  async monitorSLABreaches() {
    // M-06: Distributed lock prevents duplicate execution on multi-instance deployments
    const acquired = await this.redisLock.acquireCronLock('sla-monitor', 270); // 4.5 min TTL
    if (!acquired) {
      this.logger.debug('SLA monitor already running on another instance — skipping');
      return;
    }

    try {
      await this.runSLAMonitorBatch();
    } finally {
      await this.redisLock.releaseCronLock('sla-monitor');
    }
  }

  private async runSLAMonitorBatch() {
    const now = new Date();
    const BATCH_SIZE = 100; // H-07: Process in batches, not full table scan

    // H-07: Cursor-based batch processing for response SLA breaches
    let cursor: string | undefined;
    let totalResponseFixed = 0;
    do {
      const responseBreached = await this.prisma.ticket.findMany({
        where: {
          deletedAt: null,
          status: { notIn: ['resolved', 'closed'] },
          firstResponseAt: null,
          slaResponseDue: { lt: now },
          slaBreached: false,
          ...(cursor ? { id: { gt: cursor } } : {}),
        },
        select: { id: true, tenantId: true, ticketNumber: true, slaId: true, priority: true, assigneeId: true },
        orderBy: { id: 'asc' },
        take: BATCH_SIZE,
      });

      for (const t of responseBreached) {
        await this.prisma.ticket.update({ where: { id: t.id }, data: { slaBreached: true, updatedBy: 'system' } });
        await this.prisma.sLAEvent.create({ data: { tenantId: t.tenantId, ticketId: t.id, slaId: t.slaId ?? '', eventType: 'response_breached', priority: t.priority, triggeredAt: now } });
        this.events.emit('case.sla.breached', { tenantId: t.tenantId, ticketId: t.id, ticketNumber: t.ticketNumber, type: 'response', assigneeId: t.assigneeId });
      }
      totalResponseFixed += responseBreached.length;
      cursor = responseBreached.length === BATCH_SIZE ? responseBreached[responseBreached.length - 1]!.id : undefined;
    } while (cursor);

    if (totalResponseFixed > 0) {
      this.logger.log(`SLA monitor: ${totalResponseFixed} response breaches processed`);
    }

    // H-07: Cursor-based resolution SLA breach processing
    cursor = undefined;
    let totalResolutionFixed = 0;
    do {
      const resolutionBreached = await this.prisma.ticket.findMany({
        where: {
          deletedAt: null,
          status: { notIn: ['resolved', 'closed'] },
          slaResolutionDue: { lt: now },
          slaBreached: false,
          ...(cursor ? { id: { gt: cursor } } : {}),
        },
        select: { id: true, tenantId: true, ticketNumber: true, slaId: true, priority: true, assigneeId: true },
        orderBy: { id: 'asc' },
        take: BATCH_SIZE,
      });

      for (const t of resolutionBreached) {
        await this.prisma.ticket.update({ where: { id: t.id }, data: { slaBreached: true, updatedBy: 'system' } });
        await this.prisma.sLAEvent.create({ data: { tenantId: t.tenantId, ticketId: t.id, slaId: t.slaId ?? '', eventType: 'resolution_breached', priority: t.priority, triggeredAt: now } });
        this.events.emit('case.sla.breached', { tenantId: t.tenantId, ticketId: t.id, ticketNumber: t.ticketNumber, type: 'resolution', assigneeId: t.assigneeId });
        this.events.emit('case.ticket.escalated', { tenantId: t.tenantId, ticketId: t.id, reason: 'sla_breach' });
      }
      totalResolutionFixed += resolutionBreached.length;
      cursor = resolutionBreached.length === BATCH_SIZE ? resolutionBreached[resolutionBreached.length - 1]!.id : undefined;
    } while (cursor);

    if (totalResolutionFixed > 0) {
      this.logger.log(`SLA monitor: ${totalResolutionFixed} resolution breaches processed`);
    }

    // Warning at 75% — upcoming breaches
    const warnThreshold = new Date(now.getTime() + 60 * 60_000); // 1 hour ahead
    const upcoming = await this.prisma.ticket.findMany({
      where: {
        deletedAt: null,
        status: { notIn: ['resolved', 'closed'] },
        slaResolutionDue: { gte: now, lte: warnThreshold },
        slaBreached: false,
      },
      select: { id: true, tenantId: true, ticketNumber: true, assigneeId: true, slaResolutionDue: true },
      take: 100,
    });

    for (const t of upcoming) {
      this.events.emit('case.sla.warning', { tenantId: t.tenantId, ticketId: t.id, ticketNumber: t.ticketNumber, dueAt: t.slaResolutionDue, assigneeId: t.assigneeId });
    }

    if (responseBreached.length + resolutionBreached.length > 0) {
      this.logger.warn(`SLA monitor: ${responseBreached.length} response + ${resolutionBreached.length} resolution breaches`);
    }
  }

  // ─── SLA Analytics ────────────────────────────────────────────────────────

  async getSLAAnalytics(tenantId: string, startDate?: Date, endDate?: Date) {
    const from = startDate ?? new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const to = endDate ?? new Date();

    const [total, breached, byPriority] = await Promise.all([
      this.prisma.ticket.count({ where: { tenantId, createdAt: { gte: from, lte: to }, deletedAt: null } }),
      this.prisma.ticket.count({ where: { tenantId, slaBreached: true, createdAt: { gte: from, lte: to }, deletedAt: null } }),
      this.prisma.ticket.groupBy({
        by: ['priority'],
        where: { tenantId, createdAt: { gte: from, lte: to }, deletedAt: null },
        _count: { id: true },
        _sum: { slaBreached: true } as any,
      }),
    ]);

    // Avg resolution time for resolved tickets
    const resolved = await this.prisma.ticket.findMany({
      where: { tenantId, status: { in: ['resolved', 'closed'] }, resolvedAt: { not: null }, createdAt: { gte: from, lte: to } },
      select: { createdAt: true, resolvedAt: true, priority: true },
    });

    const avgResolutionByPriority = resolved.reduce((acc: Record<string, { sum: number; count: number }>, t) => {
      const mins = t.resolvedAt ? (t.resolvedAt.getTime() - t.createdAt.getTime()) / 60_000 : 0;
      if (!acc[t.priority]) acc[t.priority] = { sum: 0, count: 0 };
      acc[t.priority].sum += mins; acc[t.priority].count++;
      return acc;
    }, {});

    return {
      period: { from: from.toISOString(), to: to.toISOString() },
      total, breached, breachRate: total ? ((breached / total) * 100).toFixed(1) : '0',
      byPriority: byPriority.map((g: any) => ({ priority: g.priority, total: g._count.id })),
      avgResolutionMinutes: Object.entries(avgResolutionByPriority).map(([p, v]) => ({
        priority: p, avgMinutes: Math.round(v.sum / v.count),
      })),
    };
  }
}

// ─── SLA Controller ───────────────────────────────────────────────────────────

@ApiTags('case-engine/sla')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('case-engine/sla')
export class SLAController {
  constructor(private readonly svc: SLAService) {}

  @Get()
  @ApiOperation({ summary: 'List SLA policies' })
  listSLAs(@CurrentUser() u: JwtPayload) { return this.svc.listSLAs(u.tid); }

  @Get('analytics')
  @ApiOperation({ summary: 'SLA breach analytics — rates, avg resolution by priority' })
  getAnalytics(@CurrentUser() u: JwtPayload) { return this.svc.getSLAAnalytics(u.tid); }

  @Get(':id')
  getSLA(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getSLA(u.tid, id); }

  @Post()
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Create SLA policy' })
  createSLA(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createSLA(u.tid, dto, u.sub); }

  @Put(':id')
  @Roles('hr-admin', 'super-admin')
  updateSLA(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateSLA(u.tid, id, dto, u.sub); }

  @Delete(':id')
  @Roles('super-admin')
  deleteSLA(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteSLA(u.tid, id); }
}
