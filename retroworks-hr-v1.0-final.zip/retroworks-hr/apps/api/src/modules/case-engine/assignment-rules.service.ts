import { Injectable, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2, OnEvent } from '@nestjs/event-emitter';
import { Cron } from '@nestjs/schedule';
import {
  Controller, Get, Post, Put, Delete, Patch, Body, Param, Query, UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── Rule Evaluator ───────────────────────────────────────────────────────────

function evalCondition(field: string, operator: string, ruleValue: unknown, ticket: Record<string, unknown>): boolean {
  const actual = field.split('.').reduce((o: any, k) => o?.[k], ticket);
  switch (operator) {
    case 'eq': return String(actual) === String(ruleValue);
    case 'neq': return String(actual) !== String(ruleValue);
    case 'contains': return String(actual ?? '').toLowerCase().includes(String(ruleValue).toLowerCase());
    case 'in': return Array.isArray(ruleValue) ? ruleValue.includes(actual) : false;
    case 'gt': return Number(actual) > Number(ruleValue);
    case 'gte': return Number(actual) >= Number(ruleValue);
    case 'lt': return Number(actual) < Number(ruleValue);
    case 'lte': return Number(actual) <= Number(ruleValue);
    case 'is_null': return actual == null;
    case 'is_not_null': return actual != null;
    default: return false;
  }
}

function evalRule(conditions: any[], logic: string, ticket: Record<string, unknown>): boolean {
  if (!conditions.length) return true;
  const results = conditions.map((c: any) => evalCondition(c.field, c.operator, c.value, ticket));
  return logic === 'OR' ? results.some(Boolean) : results.every(Boolean);
}

// ─── Service ─────────────────────────────────────────────────────────────────

@Injectable()
export class AssignmentRulesService {
  private readonly logger = new Logger(AssignmentRulesService.name);

  constructor(private readonly prisma: PrismaClient, private readonly events: EventEmitter2) {}

  // ─── CRUD ─────────────────────────────────────────────────────────────────

  async listRules(tenantId: string) {
    return this.prisma.assignmentRule.findMany({
      where: { tenantId, deletedAt: null },
      orderBy: [{ priority: 'desc' }, { createdAt: 'desc' }],
    });
  }

  async createRule(tenantId: string, dto: {
    name: string; description?: string; priority?: number;
    conditions: any[]; conditionLogic?: string; actions: any[];
  }, createdBy: string) {
    return this.prisma.assignmentRule.create({
      data: {
        tenantId, name: dto.name, description: dto.description,
        priority: dto.priority ?? 0,
        conditions: dto.conditions as any,
        conditionLogic: dto.conditionLogic ?? 'AND',
        actions: dto.actions as any,
        createdBy, updatedBy: createdBy,
      },
    });
  }

  async updateRule(tenantId: string, ruleId: string, dto: any, updatedBy: string) {
    return this.prisma.assignmentRule.update({ where: { id: ruleId }, data: { ...dto, updatedBy } });
  }

  async toggleRule(tenantId: string, ruleId: string) {
    const rule = await this.prisma.assignmentRule.findFirst({ where: { id: ruleId, tenantId } });
    if (!rule) return null;
    return this.prisma.assignmentRule.update({ where: { id: ruleId }, data: { isActive: !rule.isActive } });
  }

  async deleteRule(tenantId: string, ruleId: string) {
    return this.prisma.assignmentRule.update({ where: { id: ruleId }, data: { deletedAt: new Date() } });
  }

  // ─── Rule Execution ───────────────────────────────────────────────────────

  async applyRulesToTicket(tenantId: string, ticketId: string): Promise<void> {
    const ticket = await this.prisma.ticket.findFirst({
      where: { id: ticketId, tenantId },
      include: { category: true, subcategory: true, sla: true },
    });
    if (!ticket) return;

    const rules = await this.prisma.assignmentRule.findMany({
      where: { tenantId, isActive: true, deletedAt: null },
      orderBy: [{ priority: 'desc' }],
    });

    const ticketContext = {
      type: ticket.type,
      priority: ticket.priority,
      status: ticket.status,
      category: ticket.category?.name,
      'category.type': ticket.category?.type,
      subcategory: ticket.subcategory?.name,
      linkedEntityType: ticket.linkedEntityType,
      source: ticket.source,
    };

    for (const rule of rules) {
      const conditions = rule.conditions as any[];
      const matched = evalRule(conditions, rule.conditionLogic, ticketContext);
      if (!matched) continue;

      // Apply actions
      const actions = rule.actions as any[];
      const updates: Partial<any> = {};
      let notifyUserId: string | undefined;

      for (const action of actions) {
        switch (action.type) {
          case 'assign_to_agent': updates.assigneeId = action.value; notifyUserId = action.value; break;
          case 'assign_to_group': updates.assignedGroupId = action.value; break;
          case 'set_priority': updates.priority = action.value; break;
          case 'set_sla': updates.slaId = action.value; break;
          case 'add_tag':
            await this.prisma.ticketTagLink.upsert({
              where: { ticketId_tagId: { ticketId, tagId: action.value } },
              create: { ticketId, tagId: action.value }, update: {},
            }).catch(() => {});
            break;
        }
      }

      if (Object.keys(updates).length > 0) {
        await this.prisma.ticket.update({ where: { id: ticketId }, data: updates });
        await this.prisma.ticketActivity.create({
          data: { tenantId, ticketId, actorId: 'system', actorType: 'system', event: 'assignment_rule_applied', newValue: rule.name, metadata: { ruleId: rule.id, actions } as any },
        });
        if (notifyUserId) this.events.emit('case.ticket.assigned', { tenantId, ticketId, assigneeId: notifyUserId });
      }

      await this.prisma.assignmentRule.update({ where: { id: rule.id }, data: { runCount: { increment: 1 }, lastRunAt: new Date() } });
      break; // First matching rule wins (priority order)
    }
  }

  // ─── Cross-Domain: HR → Case Engine ──────────────────────────────────────

  @OnEvent('hr.employee.created')
  async onEmployeeCreated(payload: { tenantId: string; employeeId: string; name: string }) {
    // Auto-create IT onboarding ticket
    const category = await this.prisma.ticketCategory.findFirst({ where: { tenantId: payload.tenantId, type: 'IT', name: { contains: 'Onboarding' } } });
    if (!category) return;
    this.events.emit('case.auto.create', {
      tenantId: payload.tenantId,
      type: 'IT',
      title: `IT Setup — ${payload.name}`,
      description: 'New employee IT onboarding: laptop provisioning, email setup, software access, VPN credentials.',
      priority: 'p2',
      categoryId: category.id,
      linkedEntityType: 'employee',
      linkedEntityId: payload.employeeId,
      source: 'hr-automation',
      createdBy: 'system',
    });
    this.logger.log(`Auto-created IT onboarding ticket for employee ${payload.employeeId}`);
  }

  @OnEvent('hr.employee.exit.initiated')
  async onEmployeeExitInitiated(payload: { tenantId: string; employeeId: string; name: string; lastDay: string }) {
    const category = await this.prisma.ticketCategory.findFirst({ where: { tenantId: payload.tenantId, name: { contains: 'Clearance' } } });
    this.events.emit('case.auto.create', {
      tenantId: payload.tenantId,
      type: 'admin',
      title: `Exit Clearance — ${payload.name}`,
      description: `Employee exit clearance required. Last working day: ${payload.lastDay}. Action items: asset return, access revocation, F&F settlement, experience letter.`,
      priority: 'p2',
      categoryId: category?.id,
      linkedEntityType: 'employee',
      linkedEntityId: payload.employeeId,
      source: 'hr-automation',
      createdBy: 'system',
    });
  }

  @OnEvent('payroll.anomaly.detected')
  async onPayrollAnomaly(payload: { tenantId: string; employeeId: string; anomaly: string; runId: string }) {
    const category = await this.prisma.ticketCategory.findFirst({ where: { tenantId: payload.tenantId, type: 'payroll' } });
    this.events.emit('case.auto.create', {
      tenantId: payload.tenantId,
      type: 'payroll',
      title: `Payroll Anomaly — ${payload.anomaly}`,
      description: `Automated payroll anomaly detected for payroll run ${payload.runId}. Review required before disbursement.`,
      priority: 'p1',
      categoryId: category?.id,
      linkedEntityType: 'payroll_run',
      linkedEntityId: payload.runId,
      source: 'system',
      createdBy: 'system',
    });
  }

  @OnEvent('case.auto.create')
  async onAutoCaseCreate(payload: any) {
    const { tenantId, createdBy, ...dto } = payload;
    try {
      const ticketNumber = `RW-${new Date().getFullYear()}-${String(Date.now()).slice(-5)}`;
      await this.prisma.ticket.create({
        data: { tenantId, ticketNumber, ...dto, status: 'open', createdBy, updatedBy: createdBy },
      });
    } catch (e: any) {
      this.logger.error(`Auto case create failed: ${e.message}`);
    }
  }

  // ─── Cross-Domain: Case → HR Events ──────────────────────────────────────

  @OnEvent('case.ticket.resolved')
  async onTicketResolved(payload: { tenantId: string; ticketId: string; linkedEntityType?: string; linkedEntityId?: string }) {
    if (payload.linkedEntityType === 'employee') {
      this.events.emit('case.resolved.for.employee', payload);
    }
  }

  // ─── Field Catalogue for Rule Builder ─────────────────────────────────────

  getFieldCatalogue() {
    return [
      { key: 'type', label: 'Ticket Type', type: 'enum', options: ['internal', 'external', 'payroll', 'IT', 'admin', 'vendor', 'custom'] },
      { key: 'priority', label: 'Priority', type: 'enum', options: ['p1', 'p2', 'p3', 'p4'] },
      { key: 'status', label: 'Status', type: 'enum', options: ['open', 'in-progress', 'pending', 'waiting', 'resolved', 'closed'] },
      { key: 'category', label: 'Category Name', type: 'string' },
      { key: 'category.type', label: 'Category Type', type: 'string' },
      { key: 'subcategory', label: 'Subcategory Name', type: 'string' },
      { key: 'linkedEntityType', label: 'Linked Entity Type', type: 'enum', options: ['employee', 'department', 'payroll_run', 'asset', 'account', 'vendor'] },
      { key: 'source', label: 'Source', type: 'enum', options: ['web', 'email', 'api', 'hr-automation', 'system'] },
    ];
  }

  getActionCatalogue() {
    return [
      { type: 'assign_to_agent', label: 'Assign to Agent', paramLabel: 'Agent ID', paramType: 'employee_select' },
      { type: 'assign_to_group', label: 'Assign to Group', paramLabel: 'Group Name', paramType: 'string' },
      { type: 'set_priority', label: 'Set Priority', paramLabel: 'Priority', paramType: 'enum', options: ['p1', 'p2', 'p3', 'p4'] },
      { type: 'set_sla', label: 'Apply SLA Policy', paramLabel: 'SLA Policy ID', paramType: 'sla_select' },
      { type: 'add_tag', label: 'Add Tag', paramLabel: 'Tag ID', paramType: 'tag_select' },
    ];
  }
}

// ─── Controller ───────────────────────────────────────────────────────────────

@ApiTags('case-engine/assignment-rules')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('case-engine/assignment-rules')
export class AssignmentRulesController {
  constructor(private readonly svc: AssignmentRulesService) {}

  @Get('catalogue')
  @ApiOperation({ summary: 'Field + action catalogue for visual rule builder' })
  getCatalogue() { return { fields: this.svc.getFieldCatalogue(), actions: this.svc.getActionCatalogue() }; }

  @Get()
  listRules(@CurrentUser() u: JwtPayload) { return this.svc.listRules(u.tid); }

  @Post()
  @Roles('hr-admin', 'super-admin')
  createRule(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createRule(u.tid, dto, u.sub); }

  @Put(':id')
  @Roles('hr-admin', 'super-admin')
  updateRule(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateRule(u.tid, id, dto, u.sub); }

  @Patch(':id/toggle')
  @Roles('hr-admin', 'super-admin')
  toggleRule(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.toggleRule(u.tid, id); }

  @Delete(':id')
  @Roles('hr-admin', 'super-admin')
  deleteRule(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteRule(u.tid, id); }

  @Post(':id/apply/:ticketId')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Manually apply assignment rules to a ticket' })
  applyToTicket(@Param('ticketId') ticketId: string, @CurrentUser() u: JwtPayload) { return this.svc.applyRulesToTicket(u.tid, ticketId); }
}

@Module({
  controllers: [AssignmentRulesController],
  providers: [AssignmentRulesService],
  exports: [AssignmentRulesService],
})
export class AssignmentRulesModule {}
