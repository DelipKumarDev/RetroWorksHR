import { Injectable, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import {
  Controller, Get, Post, Body, Param, Query, UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';
import { KBService } from './kb-crm-email.service';

// ─── Sentiment Analyzer (rule-based, no external API required) ───────────────

const NEGATIVE_SIGNALS = ['urgent', 'immediately', 'not working', 'broken', 'failed', 'impossible', 'ridiculous', 'unacceptable', 'escalate', 'complaint', 'wrong', 'error', 'disaster', 'terrible', 'horrible'];
const POSITIVE_SIGNALS = ['thank', 'great', 'excellent', 'perfect', 'resolved', 'appreciate', 'helpful'];
const CRITICAL_SIGNALS = ['legal', 'lawsuit', 'lawyer', 'audit', 'compliance', 'gdpr', 'data breach', 'fraud', 'terminate'];

function analyzeSentiment(text: string): 'positive' | 'neutral' | 'negative' | 'critical' {
  const lower = text.toLowerCase();
  if (CRITICAL_SIGNALS.some(s => lower.includes(s))) return 'critical';
  const neg = NEGATIVE_SIGNALS.filter(s => lower.includes(s)).length;
  const pos = POSITIVE_SIGNALS.filter(s => lower.includes(s)).length;
  if (neg >= 3) return 'negative';
  if (neg > pos) return 'negative';
  if (pos > neg) return 'positive';
  return 'neutral';
}

// ─── Case AI Service ─────────────────────────────────────────────────────────

@Injectable()
export class CaseAIService {
  private readonly logger = new Logger(CaseAIService.name);
  private readonly anthropicApiKey: string;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
    private readonly config: ConfigService,
    private readonly kbService: KBService,
  ) {
    this.anthropicApiKey = config.get('ANTHROPIC_API_KEY') ?? '';
  }

  // ─── KB Article Suggestions ───────────────────────────────────────────────

  async suggestKBArticles(tenantId: string, context: { title: string; description?: string; messages?: string[] }) {
    const query = [context.title, context.description, ...(context.messages ?? [])].join(' ').slice(0, 500);
    const articles = await this.kbService.searchKB(tenantId, query, 5);
    return { suggested: articles, query };
  }

  // ─── Response Drafting ────────────────────────────────────────────────────

  async draftResponse(tenantId: string, ticketId: string, options: { tone?: string; length?: string; kbArticleIds?: string[] }) {
    const ticket = await this.prisma.ticket.findFirst({
      where: { id: ticketId, tenantId },
      include: {
        messages: { where: { deletedAt: null, isInternal: false }, orderBy: { createdAt: 'desc' }, take: 5 },
        category: { select: { name: true } },
      },
    });
    if (!ticket) return { draft: '' };

    // Build context
    const lastMsg = ticket.messages[0]?.body ?? ticket.description ?? '';
    const kbContent = options.kbArticleIds?.length
      ? (await this.prisma.kBArticle.findMany({ where: { id: { in: options.kbArticleIds } } })).map(a => a.content).join('\n\n')
      : '';

    const systemPrompt = `You are a professional HR support agent for RetroWorks. Draft a ${options.tone ?? 'professional'}, ${options.length ?? 'concise'} response to the following ticket. Use a helpful, empathetic tone. If KB articles are provided, reference them. Keep the response human and natural — never robotic.`;
    const userPrompt = `Ticket: "${ticket.title}"\nCategory: ${ticket.category?.name ?? ticket.type}\nCustomer message: "${lastMsg}"\n${kbContent ? `\nRelevant KB:\n${kbContent}` : ''}\n\nDraft a response:`;

    if (!this.anthropicApiKey) {
      return {
        draft: `Thank you for reaching out about "${ticket.title}". We have received your request and will address it promptly.\n\nWe will get back to you within the SLA window. If this is urgent, please mark the ticket priority accordingly.\n\nBest regards,\nSupport Team`,
        isAiGenerated: false,
      };
    }

    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': this.anthropicApiKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: 'claude-haiku-4-5-20251001', max_tokens: 500, system: systemPrompt, messages: [{ role: 'user', content: userPrompt }] }),
      });
      const data = await res.json() as any;
      const draft = data.content?.[0]?.text ?? '';
      return { draft, isAiGenerated: true };
    } catch (e: any) {
      this.logger.warn(`AI draft failed: ${e.message}`);
      return { draft: '', error: e.message };
    }
  }

  // ─── Sentiment Analysis ───────────────────────────────────────────────────

  async analyzeTicketSentiment(tenantId: string, ticketId: string) {
    const messages = await this.prisma.ticketMessage.findMany({
      where: { ticketId, tenantId, isInternal: false, deletedAt: null },
      select: { body: true }, orderBy: { createdAt: 'desc' }, take: 5,
    });
    const ticket = await this.prisma.ticket.findFirst({ where: { id: ticketId }, select: { title: true, description: true } });
    const fullText = [ticket?.title, ticket?.description, ...messages.map(m => m.body)].filter(Boolean).join(' ');
    const sentiment = analyzeSentiment(fullText);

    // Update ticket sentiment
    await this.prisma.ticket.update({ where: { id: ticketId }, data: { sentiment, updatedBy: 'ai' } });

    if (sentiment === 'critical') {
      this.events.emit('case.sentiment.critical', { tenantId, ticketId, sentiment });
    }
    return { ticketId, sentiment, analyzed: true };
  }

  // ─── Pattern Detection ────────────────────────────────────────────────────

  async detectRecurringPatterns(tenantId: string) {
    const thirtyDaysAgo = new Date(Date.now() - 30 * 86_400_000);
    const tickets = await this.prisma.ticket.findMany({
      where: { tenantId, createdAt: { gte: thirtyDaysAgo }, deletedAt: null },
      select: { title: true, type: true, categoryId: true, category: { select: { name: true } } },
    });

    // Simple frequency analysis
    const categoryFreq: Record<string, number> = {};
    const typeFreq: Record<string, number> = {};
    const keywordFreq: Record<string, number> = {};

    const STOP_WORDS = new Set(['the', 'a', 'an', 'is', 'are', 'was', 'were', 'i', 'my', 'and', 'or', 'for', 'to', 'in', 'on', 'at', 'with', 'this', 'that', 'please', 'help']);

    for (const t of tickets) {
      const cat = t.category?.name ?? 'uncategorized';
      categoryFreq[cat] = (categoryFreq[cat] ?? 0) + 1;
      typeFreq[t.type] = (typeFreq[t.type] ?? 0) + 1;
      t.title.toLowerCase().split(/\s+/).filter(w => w.length > 3 && !STOP_WORDS.has(w))
        .forEach(w => { keywordFreq[w] = (keywordFreq[w] ?? 0) + 1; });
    }

    const topCategories = Object.entries(categoryFreq).sort(([, a], [, b]) => b - a).slice(0, 5).map(([cat, count]) => ({ category: cat, count, pct: ((count / tickets.length) * 100).toFixed(1) }));
    const topKeywords = Object.entries(keywordFreq).sort(([, a], [, b]) => b - a).slice(0, 10).map(([kw, count]) => ({ keyword: kw, count })).filter(k => k.count >= 2);

    const recommendations: string[] = [];
    if (topCategories[0]?.pct && parseFloat(topCategories[0].pct) > 30) {
      recommendations.push(`Consider creating KB articles for frequent "${topCategories[0].category}" issues (${topCategories[0].pct}% of tickets)`);
    }
    if (topKeywords.length > 5) {
      recommendations.push(`Automation rule opportunity: topics "${topKeywords.slice(0, 3).map(k => k.keyword).join(', ')}" appear frequently`);
    }

    return {
      period: '30 days',
      total: tickets.length,
      topCategories,
      topKeywords,
      recommendations,
    };
  }

  // ─── Agent Performance Analytics ─────────────────────────────────────────

  async getAgentPerformance(tenantId: string, startDate?: Date, endDate?: Date) {
    const from = startDate ?? new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const to = endDate ?? new Date();

    const resolved = await this.prisma.ticket.findMany({
      where: { tenantId, status: { in: ['resolved', 'closed'] }, resolvedAt: { not: null, gte: from, lte: to }, assigneeId: { not: null }, deletedAt: null },
      select: { assigneeId: true, assignee: { select: { firstName: true, lastName: true } }, createdAt: true, resolvedAt: true, slaBreached: true, satisfactionScore: true },
    });

    const agentMap: Record<string, { name: string; resolved: number; breached: number; totalMinutes: number; satisfaction: number; satCount: number }> = {};
    for (const t of resolved) {
      if (!t.assigneeId) continue;
      const mins = t.resolvedAt ? (t.resolvedAt.getTime() - t.createdAt.getTime()) / 60_000 : 0;
      if (!agentMap[t.assigneeId]) agentMap[t.assigneeId] = { name: `${t.assignee?.firstName} ${t.assignee?.lastName}`, resolved: 0, breached: 0, totalMinutes: 0, satisfaction: 0, satCount: 0 };
      agentMap[t.assigneeId].resolved++;
      agentMap[t.assigneeId].totalMinutes += mins;
      if (t.slaBreached) agentMap[t.assigneeId].breached++;
      if (t.satisfactionScore) { agentMap[t.assigneeId].satisfaction += t.satisfactionScore; agentMap[t.assigneeId].satCount++; }
    }

    return Object.entries(agentMap).map(([id, a]) => ({
      agentId: id, name: a.name, resolved: a.resolved,
      slaBreached: a.breached,
      breachRate: a.resolved ? ((a.breached / a.resolved) * 100).toFixed(1) : '0',
      avgResolutionMins: a.resolved ? Math.round(a.totalMinutes / a.resolved) : 0,
      avgSatisfaction: a.satCount ? (a.satisfaction / a.satCount).toFixed(1) : null,
    })).sort((a, b) => b.resolved - a.resolved);
  }
}

// ─── Case AI Controller ───────────────────────────────────────────────────────

@ApiTags('case-engine/ai')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('case-engine/ai')
export class CaseAIController {
  constructor(private readonly svc: CaseAIService) {}

  @Post('suggest-kb')
  @ApiOperation({ summary: 'Suggest KB articles based on ticket context' })
  suggestKB(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.suggestKBArticles(u.tid, dto); }

  @Post('draft-response/:ticketId')
  @ApiOperation({ summary: 'AI-draft a response to a ticket thread' })
  draftResponse(@Param('ticketId') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.draftResponse(u.tid, id, dto); }

  @Post('analyze-sentiment/:ticketId')
  @ApiOperation({ summary: 'Run sentiment analysis on ticket messages — flags critical risk' })
  analyzeSentiment(@Param('ticketId') id: string, @CurrentUser() u: JwtPayload) { return this.svc.analyzeTicketSentiment(u.tid, id); }

  @Get('patterns')
  @ApiOperation({ summary: 'Detect recurring issue patterns and recommend automation rules' })
  detectPatterns(@CurrentUser() u: JwtPayload) { return this.svc.detectRecurringPatterns(u.tid); }

  @Get('agent-performance')
  @ApiOperation({ summary: 'Agent performance dashboard — resolution rate, SLA, CSAT' })
  agentPerformance(@CurrentUser() u: JwtPayload) { return this.svc.getAgentPerformance(u.tid); }
}
