import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Cron } from '@nestjs/schedule';
import { Controller, Get, Post, Put, Patch, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── India Compliance Rules ────────────────────────────────────────

const INDIA_COMPLIANCE_RULES = {
  PF: { description: 'Employee Provident Fund', rate: 12, wageLimit: 15000, applicableAbove: 20, filingDue: '15th of following month' },
  ESI: { description: 'Employee State Insurance', employeeRate: 0.75, employerRate: 3.25, wageLimit: 21000, applicableAbove: 10, filingDue: '15th of following month' },
  GRATUITY: { description: 'Payment of Gratuity Act', eligibilityYears: 5, rate: 15, applicableAbove: 10 },
  OVERTIME: { description: 'Factories Act / Shops Act', maxOTHoursPerWeek: 12, otMultiplier: 2 },
  MINIMUM_WAGE: { description: 'State-wise minimum wage', checkRequired: true },
  PROFESSIONAL_TAX: { description: 'State-wise professional tax', states: { MH: { above300000: 2500 }, KA: { above300000: 2400 }, TN: { above300000: 2400 }, DL: { above300000: 0 } } },
  MATERNITY_BENEFIT: { description: 'Maternity Benefit Act', weeksPerChild: 26, applicableAbove: 10 },
  POSH: { description: 'Prevention of Sexual Harassment', committeeRequired: 10 },
  BONUS: { description: 'Payment of Bonus Act', minBonusPercent: 8.33, maxBonusPercent: 20, wageLimit: 21000, applicableAbove: 20 },
};

const MINIMUM_WAGES_2025: Record<string, number> = {
  MH: 17000, KA: 16000, TN: 15000, DL: 17494, UP: 12000, WB: 13000,
  GJ: 14000, RJ: 12500, AP: 13000, TS: 14500, MP: 11500, HR: 15000,
};

// ─── Policy Engine Service ────────────────────────────────────────────

@Injectable()
export class PolicyEngineService {
  private readonly logger = new Logger(PolicyEngineService.name);

  constructor(private readonly prisma: PrismaClient, private readonly events: EventEmitter2) {}

  // ─── Policy CRUD with versioning ──────────────────────────────────

  async listPolicies(tenantId: string, category?: string) {
    return this.prisma.hrPolicy.findMany({
      where: { tenantId, deletedAt: null, ...(category && { category }) },
      include: { _count: { select: { versions: true, acknowledgments: true } } },
      orderBy: [{ category: 'asc' }, { name: 'asc' }],
    });
  }

  async getPolicy(tenantId: string, policyId: string) {
    const policy = await this.prisma.hrPolicy.findFirst({
      where: { id: policyId, tenantId, deletedAt: null },
      include: { versions: { orderBy: { version: 'desc' }, take: 5 }, acknowledgments: { select: { employeeId: true, acknowledgedAt: true } } },
    });
    if (!policy) throw new NotFoundException('Policy not found');
    return policy;
  }

  async createPolicy(tenantId: string, dto: {
    name: string; category: string; content: string;
    effectiveDate: string; requiresAcknowledgment?: boolean;
    acknowledgmentDeadlineDays?: number;
  }, createdBy: string) {
    return this.prisma.$transaction(async tx => {
      const policy = await tx.hrPolicy.create({
        data: {
          tenantId, name: dto.name, category: dto.category,
          currentVersion: 1, requiresAcknowledgment: dto.requiresAcknowledgment ?? false,
          acknowledgmentDeadlineDays: dto.acknowledgmentDeadlineDays ?? 14,
          status: 'active', createdBy,
        },
      });
      await tx.hrPolicyVersion.create({
        data: {
          policyId: policy.id, tenantId, version: 1, content: dto.content,
          effectiveDate: new Date(dto.effectiveDate), createdBy,
          changeLog: 'Initial version',
        },
      });
      if (dto.requiresAcknowledgment) {
        this.events.emit('policy.published', { tenantId, policyId: policy.id, policyName: dto.name, deadline: dto.acknowledgmentDeadlineDays });
      }
      return policy;
    });
  }

  async publishNewVersion(tenantId: string, policyId: string, dto: {
    content: string; effectiveDate: string; changeLog: string; retroactive?: boolean;
  }, createdBy: string) {
    const policy = await this.prisma.hrPolicy.findFirst({ where: { id: policyId, tenantId } });
    if (!policy) throw new NotFoundException('Policy not found');

    const newVersion = (policy.currentVersion as number) + 1;

    return this.prisma.$transaction(async tx => {
      await tx.hrPolicyVersion.create({
        data: {
          policyId, tenantId, version: newVersion, content: dto.content,
          effectiveDate: new Date(dto.effectiveDate), createdBy,
          changeLog: dto.changeLog, isRetroactive: dto.retroactive ?? false,
        },
      });
      await tx.hrPolicy.update({
        where: { id: policyId }, data: { currentVersion: newVersion, lastPublishedAt: new Date() },
      });

      // Trigger re-acknowledgment if required
      if (policy.requiresAcknowledgment) {
        // Delete old acknowledgments so employees must re-ack
        await tx.hrPolicyAcknowledgment.deleteMany({ where: { policyId, tenantId } });
        this.events.emit('policy.updated', { tenantId, policyId, version: newVersion, retroactive: dto.retroactive });
      }

      // Retroactive recalculation
      if (dto.retroactive) {
        this.events.emit('policy.retroactive', { tenantId, policyId, effectiveDate: dto.effectiveDate });
        this.logger.warn(`Policy ${policyId} v${newVersion} is retroactive — recalculation triggered from ${dto.effectiveDate}`);
      }

      return { policyId, newVersion };
    });
  }

  async getPolicyVersionHistory(tenantId: string, policyId: string) {
    return this.prisma.hrPolicyVersion.findMany({ where: { policyId, tenantId }, orderBy: { version: 'desc' } });
  }

  async getActiveVersion(tenantId: string, policyId: string) {
    const policy = await this.prisma.hrPolicy.findFirst({ where: { id: policyId, tenantId } });
    if (!policy) throw new NotFoundException();
    return this.prisma.hrPolicyVersion.findFirst({
      where: { policyId, tenantId, version: policy.currentVersion as number },
    });
  }

  async acknowledgePolicy(tenantId: string, policyId: string, employeeId: string, ip: string) {
    return this.prisma.hrPolicyAcknowledgment.upsert({
      where: { employeeId_policyId: { employeeId, policyId } },
      create: { tenantId, policyId, employeeId, acknowledgedAt: new Date(), ipAddress: ip },
      update: { acknowledgedAt: new Date(), ipAddress: ip },
    });
  }

  async getPolicyAcknowledgmentStatus(tenantId: string, policyId: string) {
    const [totalEmployees, acked] = await Promise.all([
      this.prisma.employee.count({ where: { tenantId, status: 'active', deletedAt: null } }),
      this.prisma.hrPolicyAcknowledgment.count({ where: { policyId, tenantId } }),
    ]);
    const pending = await this.prisma.employee.findMany({
      where: { tenantId, status: 'active', deletedAt: null, NOT: { policyAcknowledgments: { some: { policyId } } } },
      select: { id: true, firstName: true, lastName: true, employeeCode: true, department: { select: { name: true } } },
    });
    return { total: totalEmployees, acknowledged: acked, pending: totalEmployees - acked, pendingEmployees: pending };
  }

  async detectPolicyConflicts(tenantId: string, policyId: string) {
    // Simple conflict detection: same category, overlapping effective dates
    const policy = await this.prisma.hrPolicy.findFirst({ where: { id: policyId, tenantId }, include: { versions: { orderBy: { version: 'desc' }, take: 1 } } });
    if (!policy) throw new NotFoundException();
    const conflicts = await this.prisma.hrPolicy.findMany({
      where: { tenantId, category: policy.category, status: 'active', id: { not: policyId }, deletedAt: null },
    });
    return { conflicts: conflicts.map((c: any) => ({ policyId: c.id, name: c.name, category: c.category, note: 'Same category — verify no rule overlap' })) };
  }
}

// ─── Compliance Monitor Service ───────────────────────────────────────

@Injectable()
export class ComplianceMonitorService {
  private readonly logger = new Logger(ComplianceMonitorService.name);

  constructor(private readonly prisma: PrismaClient, private readonly events: EventEmitter2) {}

  async getComplianceScore(tenantId: string): Promise<{
    overallScore: number;
    grade: string;
    checks: ComplianceCheck[];
    lastUpdated: Date;
  }> {
    const checks = await this.runAllChecks(tenantId);
    const passed = checks.filter(c => c.status === 'compliant').length;
    const score = Math.round((passed / checks.length) * 100);
    const grade = score >= 90 ? 'A' : score >= 75 ? 'B' : score >= 60 ? 'C' : score >= 40 ? 'D' : 'F';
    return { overallScore: score, grade, checks, lastUpdated: new Date() };
  }

  private async runAllChecks(tenantId: string): Promise<ComplianceCheck[]> {
    const [pfCheck, esiCheck, leaveCheck, otCheck, minWageCheck, pfFilingCheck, bonusCheck] = await Promise.all([
      this.checkPF(tenantId),
      this.checkESI(tenantId),
      this.checkLeaveCompliance(tenantId),
      this.checkOvertime(tenantId),
      this.checkMinimumWage(tenantId),
      this.checkPFFilingStatus(tenantId),
      this.checkBonusCompliance(tenantId),
    ]);
    return [pfCheck, esiCheck, leaveCheck, otCheck, minWageCheck, pfFilingCheck, bonusCheck];
  }

  private async checkPF(tenantId: string): Promise<ComplianceCheck> {
    const eligible = await this.prisma.employee.count({ where: { tenantId, status: 'active', pfOptIn: true, deletedAt: null } });
    const totalActive = await this.prisma.employee.count({ where: { tenantId, status: 'active', deletedAt: null } });
    // Check last payroll has PF deductions
    const lastPayroll = await this.prisma.payrollRun.findFirst({ where: { tenantId, status: { in: ['processed', 'approved'] } }, orderBy: { createdAt: 'desc' } });
    const status = lastPayroll ? 'compliant' : 'warning';
    return { id: 'pf', name: 'Provident Fund (EPF)', category: 'statutory', status, score: status === 'compliant' ? 100 : 60, details: `${eligible}/${totalActive} employees enrolled. PF @ 12% employer + 12% employee on wage ≤ ₹15,000.`, dueDate: '15th of following month', filedDate: (lastPayroll as any)?.createdAt };
  }

  private async checkESI(tenantId: string): Promise<ComplianceCheck> {
    const eligibleESI = await this.prisma.employee.count({ where: { tenantId, status: 'active', ctc: { lte: INDIA_COMPLIANCE_RULES.ESI.wageLimit * 12 }, deletedAt: null } });
    const lastPayroll = await this.prisma.payrollRun.findFirst({ where: { tenantId, status: { in: ['processed', 'approved'] } }, orderBy: { createdAt: 'desc' } });
    const totalActive = await this.prisma.employee.count({ where: { tenantId, status: 'active', deletedAt: null } });
    if (totalActive < 10) return { id: 'esi', name: 'Employee State Insurance (ESI)', category: 'statutory', status: 'not_applicable', score: 100, details: 'ESI not applicable — headcount below 10.', dueDate: '', filedDate: undefined };
    return { id: 'esi', name: 'ESI', category: 'statutory', status: lastPayroll ? 'compliant' : 'warning', score: lastPayroll ? 100 : 50, details: `${eligibleESI} employees eligible (wages ≤ ₹21,000). Rate: 0.75% employee + 3.25% employer.`, dueDate: '15th of following month', filedDate: (lastPayroll as any)?.createdAt };
  }

  private async checkLeaveCompliance(tenantId: string): Promise<ComplianceCheck> {
    const leaveTypes = await this.prisma.leaveType.findMany({ where: { tenantId, deletedAt: null } });
    const hasEL = leaveTypes.some((l: any) => l.code === 'EL' || l.name.toLowerCase().includes('earned'));
    const hasSL = leaveTypes.some((l: any) => l.code === 'SL' || l.name.toLowerCase().includes('sick'));
    const compliant = hasEL && hasSL;
    return { id: 'leave', name: 'Leave Law Compliance', category: 'leave', status: compliant ? 'compliant' : 'non_compliant', score: compliant ? 100 : 40, details: `EL (Earned Leave): ${hasEL ? '✓' : '✗ MISSING — min 15 days/year required'}. SL (Sick Leave): ${hasSL ? '✓' : '✗ MISSING — min 7 days/year required'}.`, dueDate: '', filedDate: undefined };
  }

  private async checkOvertime(tenantId: string): Promise<ComplianceCheck> {
    const lastMonth = new Date(); lastMonth.setMonth(lastMonth.getMonth() - 1);
    const otViolations = await this.prisma.attendance.count({
      where: { tenantId, date: { gte: lastMonth }, overtimeHours: { gt: INDIA_COMPLIANCE_RULES.OVERTIME.maxOTHoursPerWeek } },
    });
    return { id: 'overtime', name: 'Overtime Compliance', category: 'labor', status: otViolations === 0 ? 'compliant' : 'warning', score: otViolations === 0 ? 100 : 70, details: `${otViolations} overtime violations last month (>12 hrs/week limit per Factories Act). OT rate should be 2x basic wage.`, dueDate: '', filedDate: undefined };
  }

  private async checkMinimumWage(tenantId: string): Promise<ComplianceCheck> {
    const settings = await this.prisma.tenantSettings.findFirst({ where: { tenantId } });
    const stateCode = (settings as any)?.stateCode ?? 'KA';
    const minWage = MINIMUM_WAGES_2025[stateCode] ?? 15000;
    const violations = await this.prisma.employee.count({ where: { tenantId, status: 'active', ctc: { lt: minWage * 12 }, deletedAt: null } });
    return { id: 'min_wage', name: `Minimum Wage (${stateCode})`, category: 'labor', status: violations === 0 ? 'compliant' : 'non_compliant', score: violations === 0 ? 100 : 0, details: `Minimum wage: ₹${minWage.toLocaleString('en-IN')}/month for ${stateCode}. ${violations} employees below minimum wage.`, dueDate: '', filedDate: undefined };
  }

  private async checkPFFilingStatus(tenantId: string): Promise<ComplianceCheck> {
    const now = new Date();
    const currentMonth = now.getMonth() + 1; const currentYear = now.getFullYear();
    const lastPayrollMonth = currentMonth === 1 ? 12 : currentMonth - 1;
    const lastPayrollYear = currentMonth === 1 ? currentYear - 1 : currentYear;
    const payroll = await this.prisma.payrollRun.findFirst({ where: { tenantId, month: lastPayrollMonth, year: lastPayrollYear, status: { in: ['processed', 'approved'] } } });
    const dueDateDay = 15; const dueDatePassed = now.getDate() > dueDateDay;
    const status = payroll ? 'compliant' : dueDatePassed ? 'non_compliant' : 'pending';
    return { id: 'pf_filing', name: 'PF Monthly Filing', category: 'filing', status, score: status === 'compliant' ? 100 : status === 'pending' ? 80 : 0, details: `PF challan for ${lastPayrollMonth}/${lastPayrollYear}: ${payroll ? 'Filed ✓' : dueDatePassed ? 'OVERDUE — 15th deadline passed' : 'Pending (due 15th)'}`, dueDate: `15/${currentMonth}/${currentYear}`, filedDate: (payroll as any)?.createdAt };
  }

  private async checkBonusCompliance(tenantId: string): Promise<ComplianceCheck> {
    const totalActive = await this.prisma.employee.count({ where: { tenantId, status: 'active', deletedAt: null } });
    if (totalActive < 20) return { id: 'bonus', name: 'Payment of Bonus Act', category: 'statutory', status: 'not_applicable', score: 100, details: 'Not applicable — headcount below 20.', dueDate: '', filedDate: undefined };
    const currentMonth = new Date().getMonth() + 1;
    const bonusDue = currentMonth >= 10 && currentMonth <= 11; // Oct-Nov is typical bonus payout period
    return { id: 'bonus', name: 'Bonus Act Compliance', category: 'statutory', status: bonusDue ? 'warning' : 'compliant', score: bonusDue ? 70 : 100, details: `Min bonus: 8.33% | Max: 20% of annual wages (≤ ₹21,000 ceiling). ${bonusDue ? 'Q4 bonus period — verify payout compliance' : 'No immediate action needed'}.`, dueDate: 'December 31', filedDate: undefined };
  }

  async getStateWiseCompliance(tenantId: string) {
    const locations = await this.prisma.location.findMany({ where: { tenantId }, select: { id: true, name: true, stateCode: true } });
    return locations.map((loc: any) => ({
      locationId: loc.id, locationName: loc.name, stateCode: loc.stateCode,
      minimumWage: MINIMUM_WAGES_2025[loc.stateCode] ?? 'Unknown',
      ptApplicable: !!((INDIA_COMPLIANCE_RULES.PROFESSIONAL_TAX.states as any)[loc.stateCode]),
      ptAnnual: ((INDIA_COMPLIANCE_RULES.PROFESSIONAL_TAX.states as any)[loc.stateCode]?.above300000) ?? 0,
    }));
  }

  @Cron('0 9 16 * *', { name: 'compliance-check', timeZone: 'Asia/Kolkata' }) // 16th of each month
  async runMonthlyComplianceCheck() {
    const tenants = await this.prisma.tenant.findMany({ where: { status: 'active' }, select: { id: true } });
    for (const t of tenants) {
      const score = await this.getComplianceScore(t.id);
      if (score.overallScore < 80) {
        this.events.emit('compliance.alert', { tenantId: t.id, score: score.overallScore, grade: score.grade, failedChecks: score.checks.filter(c => c.status === 'non_compliant').length });
        this.logger.warn(`Tenant ${t.id} compliance score: ${score.overallScore}% (${score.grade})`);
      }
    }
  }
}

interface ComplianceCheck {
  id: string; name: string; category: string;
  status: 'compliant' | 'non_compliant' | 'warning' | 'pending' | 'not_applicable';
  score: number; details: string; dueDate: string; filedDate?: Date;
}

// ─── Controllers ──────────────────────────────────────────────────────

@ApiTags('policy-engine')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('policies')
export class PolicyController {
  constructor(private readonly svc: PolicyEngineService) {}

  @Get()
  list(@Query('category') cat: string | undefined, @CurrentUser() u: JwtPayload) { return this.svc.listPolicies(u.tid, cat); }

  @Get(':id')
  get(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getPolicy(u.tid, id); }

  @Post()
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Create versioned HR policy (leave, salary, code of conduct, etc.)' })
  create(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createPolicy(u.tid, dto, u.sub); }

  @Post(':id/versions')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Publish new version — supports retroactive flag for recalculation' })
  publishVersion(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.publishNewVersion(u.tid, id, dto, u.sub); }

  @Get(':id/versions')
  getVersions(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getPolicyVersionHistory(u.tid, id); }

  @Get(':id/active-version')
  getActiveVersion(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getActiveVersion(u.tid, id); }

  @Post(':id/acknowledge')
  @ApiOperation({ summary: 'Employee acknowledges policy (logged with IP, timestamp)' })
  acknowledge(@Param('id') id: string, @Body() _: any, @CurrentUser() u: JwtPayload) { return this.svc.acknowledgePolicy(u.tid, id, u.sub, ''); }

  @Get(':id/acknowledgments')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Who has / has not acknowledged a policy' })
  acknowledgmentStatus(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.getPolicyAcknowledgmentStatus(u.tid, id); }

  @Get(':id/conflicts')
  @Roles('hr-admin', 'super-admin')
  conflicts(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.detectPolicyConflicts(u.tid, id); }
}

@ApiTags('compliance')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('hr-admin', 'super-admin')
@Controller('compliance')
export class ComplianceController {
  constructor(private readonly svc: ComplianceMonitorService) {}

  @Get('score')
  @ApiOperation({ summary: 'Real-time India compliance score across PF/ESI/Leave/OT/MinWage/Filing' })
  score(@CurrentUser() u: JwtPayload) { return this.svc.getComplianceScore(u.tid); }

  @Get('state-wise')
  @ApiOperation({ summary: 'State-wise compliance (PT, min wages per location)' })
  stateWise(@CurrentUser() u: JwtPayload) { return this.svc.getStateWiseCompliance(u.tid); }
}

@Module({
  controllers: [PolicyController, ComplianceController],
  providers: [PolicyEngineService, ComplianceMonitorService],
  exports: [PolicyEngineService, ComplianceMonitorService],
})
export class PolicyComplianceModule {}
