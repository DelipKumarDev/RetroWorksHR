import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Controller, Get, Post, Delete, Patch, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import * as crypto from 'crypto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { FieldEncryptionService, PLUGIN_SECRET_FIELDS } from '../../common/security/field-encryption.service';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

export const PLUGIN_CATALOGUE = [
  { id: 'payroll_bank_file', category: 'Payroll', name: 'Bank File Generator', description: 'NEFT/RTGS bank payment files — HDFC, ICICI, SBI, AXIS', version: '1.2.0', isBuiltin: false, configSchema: [{ key: 'bankFormat', label: 'Bank Format', type: 'select', options: ['HDFC','ICICI','SBI','AXIS'] }] },
  { id: 'compliance_form16', category: 'Compliance', name: 'Form 16 Generator', description: 'Auto-generate Form 16 Part-A and Part-B', version: '2.0.0', isBuiltin: false, configSchema: [] },
  { id: 'compliance_pf_challan', category: 'Compliance', name: 'PF/ESI Challan Generator', description: 'Monthly PF ECR and ESI challan for EPFO/ESIC', version: '1.5.0', isBuiltin: false, configSchema: [] },
  { id: 'attendance_biometric', category: 'Attendance', name: 'Biometric Integration', description: 'ZKTeco / eSSL biometric device sync', version: '1.5.0', isBuiltin: false, configSchema: [{ key: 'deviceIp', label: 'Device IP', type: 'string' }, { key: 'devicePort', label: 'Port', type: 'string' }] },
  { id: 'attendance_gps', category: 'Attendance', name: 'GPS-Based Attendance', description: 'Field staff geofenced clock in/out', version: '1.0.0', isBuiltin: false, configSchema: [{ key: 'radiusMeters', label: 'Geofence Radius (m)', type: 'number' }] },
  { id: 'benefits_flexi', category: 'Benefits', name: 'Flexi Benefits', description: 'Employee flexi basket — Sodexo, Zeta, Zaggle', version: '1.0.0', isBuiltin: false, configSchema: [{ key: 'provider', label: 'Provider', type: 'select', options: ['Sodexo','Zeta','Zaggle'] }] },
  { id: 'benefits_nps', category: 'Benefits', name: 'NPS Contribution', description: 'National Pension System tier-1 deduction', version: '1.0.0', isBuiltin: false, configSchema: [] },
  { id: 'benefits_insurance', category: 'Benefits', name: 'Group Health Insurance', description: 'Enrollment and claims tracking', version: '1.0.0', isBuiltin: false, configSchema: [{ key: 'insurerName', label: 'Insurer', type: 'string' }, { key: 'policyNumber', label: 'Policy No.', type: 'string' }] },
  { id: 'integration_gsuite', category: 'Integration', name: 'Google Workspace', description: 'Auto-create Google accounts on employee join', version: '1.0.0', isBuiltin: false, configSchema: [{ key: 'domain', label: 'Google Domain', type: 'string' }, { key: 'adminEmail', label: 'Admin Email', type: 'string' }] },
  { id: 'integration_jira', category: 'Integration', name: 'Jira / Confluence', description: 'Create Jira accounts on onboarding', version: '1.0.0', isBuiltin: false, configSchema: [{ key: 'jiraUrl', label: 'Jira URL', type: 'string' }, { key: 'apiToken', label: 'API Token', type: 'secret' }] },
  { id: 'integration_accounting', category: 'Integration', name: 'QuickBooks / Tally', description: 'Export payroll journal entries to accounting software', version: '1.0.0', isBuiltin: false, configSchema: [{ key: 'software', label: 'Software', type: 'select', options: ['QuickBooks','Tally','SAP'] }] },
];

export const WEBHOOK_EVENTS = ['employee.created','employee.updated','employee.deactivated','leave.submitted','leave.approved','leave.rejected','payroll.processed','payroll.run.completed','review.completed','expense.approved','helpdesk.ticket.resolved','onboarding.completed'];

@Injectable()
export class PluginsService {
  private readonly logger = new Logger(PluginsService.name);
  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
    private readonly fieldEncryption: FieldEncryptionService,
  ) {}

  async listPlugins(tenantId: string) {
    const enabled = await this.prisma.tenantPlugin.findMany({ where: { tenantId }, select: { pluginId: true, config: true, enabledAt: true } });
    const em = new Map(enabled.map(e => [e.pluginId, e]));
    return PLUGIN_CATALOGUE.map(p => {
      const stored = em.get(p.id);
      let config: Record<string, unknown> = (stored?.config as Record<string, unknown>) ?? {};
      // C-03: Decrypt secret fields for in-memory use (never returned to frontend as-is)
      const secretFields = PLUGIN_SECRET_FIELDS[p.id] ?? [];
      if (secretFields.length > 0 && stored) {
        config = this.fieldEncryption.decryptConfig(config, secretFields);
        // Mask secrets from API response — only show encrypted placeholder
        for (const key of secretFields) {
          if (config[key]) config[key] = this.fieldEncryption.mask(config[key] as string);
        }
      }
      return { ...p, enabled: em.has(p.id), config, enabledAt: stored?.enabledAt };
    });
  }

  async enablePlugin(tenantId: string, pluginId: string, config: any, enabledBy: string) {
    const p = PLUGIN_CATALOGUE.find(x => x.id === pluginId);
    if (!p) throw new NotFoundException(`Plugin ${pluginId} not found`);
    // C-03: Encrypt secret fields before storing in DB
    const secretFields = PLUGIN_SECRET_FIELDS[pluginId] ?? [];
    const encryptedConfig = secretFields.length > 0
      ? this.fieldEncryption.encryptConfig(config as Record<string, unknown>, secretFields)
      : config;
    await this.prisma.tenantPlugin.upsert({
      where: { tenantId_pluginId: { tenantId, pluginId } },
      create: { tenantId, pluginId, config: encryptedConfig, enabledAt: new Date(), enabledBy },
      update: { config: encryptedConfig, enabledAt: new Date(), enabledBy },
    });
    this.events.emit('plugin.enabled', { tenantId, pluginId, pluginName: p.name });
    return { pluginId, enabled: true };
  }

  async disablePlugin(tenantId: string, pluginId: string) {
    const p = PLUGIN_CATALOGUE.find(x => x.id === pluginId);
    if (!p) throw new NotFoundException(`Plugin ${pluginId} not found`);
    if (p.isBuiltin) throw new Error('Cannot disable built-in plugins');
    await this.prisma.tenantPlugin.deleteMany({ where: { tenantId, pluginId } });
    return { pluginId, enabled: false };
  }

  async updatePluginConfig(tenantId: string, pluginId: string, config: any, updatedBy: string) {
    // C-03: Encrypt secret fields before update
    const secretFields = PLUGIN_SECRET_FIELDS[pluginId] ?? [];
    const encryptedConfig = secretFields.length > 0
      ? this.fieldEncryption.encryptConfig(config as Record<string, unknown>, secretFields)
      : config;
    return this.prisma.tenantPlugin.update({
      where: { tenantId_pluginId: { tenantId, pluginId } },
      data: { config: encryptedConfig, updatedBy },
    });
  }

  async listApiKeys(tenantId: string) {
    return this.prisma.apiKey.findMany({ where: { tenantId, revokedAt: null }, select: { id: true, name: true, prefix: true, scopes: true, lastUsedAt: true, expiresAt: true, createdAt: true }, orderBy: { createdAt: 'desc' } });
  }

  async createApiKey(tenantId: string, dto: { name: string; scopes: string[]; expiresInDays?: number }, createdBy: string) {
    const secret = crypto.randomBytes(32).toString('hex');
    const prefix = `rw_${secret.substring(0, 8)}`;
    const hash = crypto.createHash('sha256').update(`${prefix}_${secret}`).digest('hex');
    const expiresAt = dto.expiresInDays ? new Date(Date.now() + dto.expiresInDays * 86_400_000) : null;
    const key = await this.prisma.apiKey.create({ data: { tenantId, name: dto.name, prefix, keyHash: hash, scopes: dto.scopes as any, expiresAt, createdBy } });
    return { id: key.id, name: key.name, prefix, key: `${prefix}_${secret}`, scopes: dto.scopes, expiresAt, warning: 'Copy this key now — it will not be shown again.' };
  }

  async revokeApiKey(tenantId: string, keyId: string) {
    const key = await this.prisma.apiKey.findFirst({ where: { id: keyId, tenantId } });
    if (!key) throw new NotFoundException('API key not found');
    return this.prisma.apiKey.update({ where: { id: keyId }, data: { revokedAt: new Date() } });
  }

  async listWebhooks(tenantId: string) {
    return this.prisma.webhookEndpoint.findMany({ where: { tenantId, deletedAt: null }, orderBy: { createdAt: 'desc' } });
  }

  async createWebhook(tenantId: string, dto: { url: string; events: string[]; name?: string }, createdBy: string) {
    const secret = crypto.randomBytes(20).toString('hex');
    return this.prisma.webhookEndpoint.create({ data: { tenantId, url: dto.url, events: dto.events as any, name: dto.name ?? dto.url, secret, isActive: true, createdBy } });
  }

  async deleteWebhook(tenantId: string, webhookId: string) {
    return this.prisma.webhookEndpoint.update({ where: { id: webhookId }, data: { deletedAt: new Date() } });
  }

  async deliverWebhook(tenantId: string, event: string, payload: any) {
    const webhooks = await this.prisma.webhookEndpoint.findMany({ where: { tenantId, isActive: true, deletedAt: null } });
    for (const wh of webhooks) {
      const evts = wh.events as string[];
      if (!evts.includes(event) && !evts.includes('*')) continue;
      const body = JSON.stringify({ event, payload, timestamp: new Date().toISOString() });
      const sig = crypto.createHmac('sha256', wh.secret ?? '').update(body).digest('hex');
      fetch(wh.url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-RetroWorks-Event': event, 'X-RetroWorks-Signature': `sha256=${sig}` }, body, signal: AbortSignal.timeout(10000) })
        .then(r => this.prisma.webhookDelivery.create({ data: { tenantId, webhookId: wh.id, event, statusCode: r.status, success: r.ok, payload } }).catch(() => {}))
        .catch(e => this.prisma.webhookDelivery.create({ data: { tenantId, webhookId: wh.id, event, statusCode: 0, success: false, error: e.message, payload } }).catch(() => {}));
    }
  }

  getWebhookEvents() { return WEBHOOK_EVENTS; }
}

@ApiTags('plugins')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('plugins')
export class PluginsController {
  constructor(private readonly svc: PluginsService) {}
  @Get() listPlugins(@CurrentUser() u: JwtPayload) { return this.svc.listPlugins(u.tid); }
  @Post(':id/enable') @Roles('super-admin') enablePlugin(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.enablePlugin(u.tid, id, dto.config ?? {}, u.sub); }
  @Delete(':id/disable') @Roles('super-admin') disablePlugin(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.disablePlugin(u.tid, id); }
  @Patch(':id/config') @Roles('super-admin') updateConfig(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updatePluginConfig(u.tid, id, dto, u.sub); }
  @Get('api-keys') @Roles('super-admin') listKeys(@CurrentUser() u: JwtPayload) { return this.svc.listApiKeys(u.tid); }
  @Post('api-keys') @Roles('super-admin') @ApiOperation({ summary: 'Create API key — shown ONCE' }) createKey(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createApiKey(u.tid, dto, u.sub); }
  @Delete('api-keys/:id') @Roles('super-admin') revokeKey(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.revokeApiKey(u.tid, id); }
  @Get('webhooks') @Roles('hr-admin','super-admin') listWebhooks(@CurrentUser() u: JwtPayload) { return this.svc.listWebhooks(u.tid); }
  @Post('webhooks') @Roles('hr-admin','super-admin') createWebhook(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createWebhook(u.tid, dto, u.sub); }
  @Delete('webhooks/:id') @Roles('hr-admin','super-admin') deleteWebhook(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.deleteWebhook(u.tid, id); }
  @Get('webhook-events') getWebhookEvents() { return this.svc.getWebhookEvents(); }
}

@Module({ controllers: [PluginsController], providers: [PluginsService], exports: [PluginsService] })
export class PluginsModule {}
