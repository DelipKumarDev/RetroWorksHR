import { IsString, IsNumber, IsOptional, Min, Max, IsEnum } from 'class-validator';

// ─── Requests ────────────────────────────────────────────────────────────────

export class RevisionSimulatorDto {
  @IsString()
  departmentId!: string;

  @IsNumber()
  @Min(0.1)
  @Max(100)
  incrementPercent!: number;

  @IsString()
  @IsOptional()
  financialYear?: string; // "2024-25", defaults to current FY
}

export class CostTrendQueryDto {
  @IsNumber()
  @IsOptional()
  @Min(1)
  @Max(24)
  months?: number; // Default 12
}

// ─── Responses ───────────────────────────────────────────────────────────────

export interface PayrollCostSummary {
  month: number;
  year: number;
  totalGross: number;
  totalNet: number;
  employerPf: number;
  employerEsi: number;
  professionalTax: number;
  totalCostToCompany: number;
  employeeCount: number;
  previousMonth: {
    totalGross: number;
    totalCostToCompany: number;
    employeeCount: number;
  } | null;
  grossChangePercent: number | null;
  ctcChangePercent: number | null;
  headcountChangePercent: number | null;
}

export interface DepartmentCostItem {
  departmentId: string;
  departmentName: string;
  headcount: number;
  totalGross: number;
  totalNet: number;
  totalCostToCompany: number;
  avgCtc: number;
}

export interface CostTrendPoint {
  month: number;
  year: number;
  label: string; // "Apr 2024"
  totalGross: number;
  totalCostToCompany: number;
  employeeCount: number;
  newJoiners: number;
  exits: number;
}

export interface StatutoryForecast {
  financialYear: string;
  tds: {
    projectedAnnualLiability: number;
    paidYtd: number;
    remainingLiability: number;
    monthlyAvg: number;
    nextMonthDue: number;
  };
  pf: {
    currentMonthEmployer: number;
    currentMonthEmployee: number;
    ytdEmployer: number;
    nextDueDate: string; // "15th of following month"
  };
  esi: {
    currentMonthEmployer: number;
    currentMonthEmployee: number;
    ytdEmployer: number;
    nextDueDate: string;
  };
  complianceCalendar: ComplianceEvent[];
}

export interface ComplianceEvent {
  type: 'TDS_DEPOSIT' | 'PF_ECR' | 'ESI_RETURN' | '24Q_QUARTERLY' | 'FORM16_ISSUE';
  label: string;
  dueDate: string; // ISO date
  isOverdue: boolean;
  estimatedAmount?: number;
}

export interface LeaveLiabilityReport {
  totalUnusedDays: number;
  encashableUnusedDays: number;
  monetaryValueAtRisk: number;
  departmentBreakdown: {
    departmentId: string;
    departmentName: string;
    totalUnusedDays: number;
    encashableValue: number;
    headcount: number;
  }[];
}

export interface RevisionSimulatorResult {
  departmentId: string;
  departmentName: string;
  incrementPercent: number;
  currentHeadcount: number;
  currentAnnualGross: number;
  projectedAnnualGross: number;
  annualGrossIncrease: number;
  monthlyGrossIncrease: number;
  // Statutory impact
  additionalEmployerPfAnnual: number;
  additionalEmployerEsiAnnual: number;
  additionalTotalCtcAnnual: number;
  additionalTotalCtcMonthly: number;
  // Simulation metadata
  simulatedAt: string;
  note: string;
}
