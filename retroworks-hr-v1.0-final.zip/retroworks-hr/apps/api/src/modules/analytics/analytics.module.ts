/**
 * Analytics Module — CFO Dashboard + Payroll Audit
 * ──────────────────────────────────────────────────────────────────────────────
 * Phase 2: read-only intelligence layer.
 * All endpoints require jwt + tenant guard + cfo/finance/hr-admin role.
 * Audit endpoints additionally require 'finance-controller' or 'hr-admin'.
 */

import {
  Controller, Get, Post, Query, Body, Param,
  UseGuards, HttpCode, HttpStatus, Logger,
  Res, StreamableFile,
} from '@nestjs/common';
import { Module } from '@nestjs/common';
import {
  ApiTags, ApiBearerAuth, ApiOperation,
  ApiQuery, ApiOkResponse,
} from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Response } from 'express';
import { CfoDashboardService } from './cfo-dashboard/cfo-dashboard.service';
import { PayrollAuditService } from './payroll-audit/payroll-audit.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RevisionSimulatorDto } from './cfo-dashboard/dto/cfo-dashboard.dto';
import type { JwtPayload } from '@retroworks/types';

// CFO-level roles that can read analytics
const CFO_ROLES = ['cfo', 'finance-controller', 'finance', 'hr-admin', 'super-admin'] as const;
// Roles that can run audit reports
const AUDIT_ROLES = ['cfo', 'finance-controller', 'hr-admin', 'super-admin'] as const;

// ─── CFO DASHBOARD CONTROLLER ─────────────────────────────────────────────────

@ApiTags('analytics/cfo')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('analytics/cfo')
export class CfoDashboardController {
  private readonly logger = new Logger(CfoDashboardController.name);

  constructor(private readonly cfo: CfoDashboardService) {}

  @Get('cost-summary')
  @Roles(...CFO_ROLES)
  @ApiOperation({ summary: 'Current month payroll cost summary with MoM comparison' })
  @ApiQuery({ name: 'month', required: false, type: Number })
  @ApiQuery({ name: 'year',  required: false, type: Number })
  getCostSummary(
    @Query('month') month: string | undefined,
    @Query('year')  year: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    const now = new Date();
    return this.cfo.getPayrollCostSummary(
      u.tid,
      month ? parseInt(month) : now.getMonth() + 1,
      year  ? parseInt(year)  : now.getFullYear(),
    );
  }

  @Get('department-breakdown')
  @Roles(...CFO_ROLES)
  @ApiOperation({ summary: 'Department-wise payroll cost breakdown' })
  @ApiQuery({ name: 'month', required: false, type: Number })
  @ApiQuery({ name: 'year',  required: false, type: Number })
  getDeptBreakdown(
    @Query('month') month: string | undefined,
    @Query('year')  year: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    const now = new Date();
    return this.cfo.getDepartmentCostBreakdown(
      u.tid,
      month ? parseInt(month) : now.getMonth() + 1,
      year  ? parseInt(year)  : now.getFullYear(),
    );
  }

  @Get('cost-trend')
  @Roles(...CFO_ROLES)
  @ApiOperation({ summary: '12-month rolling payroll cost trend' })
  @ApiQuery({ name: 'months', required: false, type: Number, description: '1–24, default 12' })
  getCostTrend(
    @Query('months') months: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.cfo.getCostTrend(u.tid, months ? Math.min(24, parseInt(months)) : 12);
  }

  @Get('statutory-forecast')
  @Roles(...CFO_ROLES)
  @ApiOperation({ summary: 'TDS, PF, ESI liability forecast + compliance calendar' })
  @ApiQuery({ name: 'fy', required: false, description: 'e.g. 2024-25' })
  getStatutoryForecast(
    @Query('fy') fy: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    const now = new Date();
    const defaultFy = now.getMonth() >= 3
      ? `${now.getFullYear()}-${(now.getFullYear() + 1).toString().slice(2)}`
      : `${now.getFullYear() - 1}-${now.getFullYear().toString().slice(2)}`;
    return this.cfo.getStatutoryForecast(u.tid, fy ?? defaultFy);
  }

  @Get('leave-liability')
  @Roles(...CFO_ROLES)
  @ApiOperation({ summary: 'Leave encashment risk — monetary value at risk' })
  getLeaveLiability(@CurrentUser() u: JwtPayload) {
    return this.cfo.getLeaveLiabilityReport(u.tid);
  }

  @Post('simulate-revision')
  @Roles(...CFO_ROLES)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Simulate salary revision impact — READ-ONLY, no payroll changed' })
  simulateRevision(
    @Body() dto: RevisionSimulatorDto,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.cfo.simulateRevision(u.tid, dto);
  }

  @Get('export/cost-report')
  @Roles(...CFO_ROLES)
  @ApiOperation({ summary: 'Export CFO cost report as CSV' })
  async exportCostReport(
    @Query('month') month: string | undefined,
    @Query('year')  year: string | undefined,
    @CurrentUser() u: JwtPayload,
    @Res({ passthrough: true }) res: Response,
  ) {
    const now = new Date();
    const m = month ? parseInt(month) : now.getMonth() + 1;
    const y = year  ? parseInt(year)  : now.getFullYear();

    const [summary, depts] = await Promise.all([
      this.cfo.getPayrollCostSummary(u.tid, m, y),
      this.cfo.getDepartmentCostBreakdown(u.tid, m, y),
    ]);

    const lines: string[] = [
      'RetroWorks HR — CFO Cost Report',
      `Generated: ${new Date().toISOString()}`,
      `Period: ${m}/${y}`,
      '',
      'SUMMARY',
      `Total Gross,₹${summary.totalGross.toLocaleString('en-IN')}`,
      `Employer PF,₹${summary.employerPf.toLocaleString('en-IN')}`,
      `Employer ESI,₹${summary.employerEsi.toLocaleString('en-IN')}`,
      `Total CTC,₹${summary.totalCostToCompany.toLocaleString('en-IN')}`,
      `Headcount,${summary.employeeCount}`,
      '',
      'DEPARTMENT BREAKDOWN',
      'Department,Headcount,Total Gross,Avg CTC,Total CTC',
      ...depts.map(d =>
        `"${d.departmentName}",${d.headcount},${d.totalGross},${d.avgCtc},${d.totalCostToCompany}`
      ),
    ];

    const csv = lines.join('\n');
    res.set({
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename="cfo-report-${y}-${m}.csv"`,
    });
    return new StreamableFile(Buffer.from(csv, 'utf-8'));
  }
}

// ─── PAYROLL AUDIT CONTROLLER ─────────────────────────────────────────────────

@ApiTags('analytics/audit')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('analytics/audit')
export class PayrollAuditController {
  constructor(private readonly audit: PayrollAuditService) {}

  @Post('run')
  @Roles(...AUDIT_ROLES)
  @HttpCode(HttpStatus.OK)
  @ApiOperation({ summary: 'Run full payroll audit for a month — detects all anomalies' })
  @ApiQuery({ name: 'month', required: false, type: Number })
  @ApiQuery({ name: 'year',  required: false, type: Number })
  runAudit(
    @Query('month') month: string | undefined,
    @Query('year')  year: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    const now = new Date();
    return this.audit.runAudit(
      u.tid,
      month ? parseInt(month) : now.getMonth() + 1,
      year  ? parseInt(year)  : now.getFullYear(),
      u.sub,
    );
  }

  @Get('history')
  @Roles(...AUDIT_ROLES)
  @ApiOperation({ summary: 'Recent audit history (last 6 runs)' })
  getHistory(@CurrentUser() u: JwtPayload) {
    return this.audit.getAuditHistory(u.tid);
  }

  @Get('export/summary')
  @Roles(...AUDIT_ROLES)
  @ApiOperation({ summary: 'Export audit summary as CSV' })
  async exportSummary(
    @Query('month') month: string | undefined,
    @Query('year')  year: string | undefined,
    @CurrentUser() u: JwtPayload,
    @Res({ passthrough: true }) res: Response,
  ) {
    const now = new Date();
    const report = await this.audit.runAudit(
      u.tid,
      month ? parseInt(month) : now.getMonth() + 1,
      year  ? parseInt(year)  : now.getFullYear(),
      u.sub,
    );

    const lines: string[] = [
      'RetroWorks HR — Payroll Audit Report',
      `Generated: ${report.generatedAt.toISOString()}`,
      `Period: ${report.month}/${report.year}`,
      `Risk Level: ${report.riskLevel}`,
      `Risk Score: ${report.riskScore}/100`,
      `Total Findings: ${report.totalFindingsCount}`,
      `Critical: ${report.criticalCount} | High: ${report.highCount} | Medium: ${report.mediumCount} | Low: ${report.lowCount}`,
      '',
      'FINDINGS',
      'Severity,Category,Code,Employee,Message,Recommendation',
      ...report.findings.map(f =>
        `${f.severity},${f.category},${f.code},"${f.employeeName ?? ''}","${f.message}","${f.recommendation}"`
      ),
    ];

    const csv = lines.join('\n');
    res.set({
      'Content-Type': 'text/csv',
      'Content-Disposition': `attachment; filename="audit-${report.year}-${report.month}.csv"`,
    });
    return new StreamableFile(Buffer.from(csv, 'utf-8'));
  }
}

// ─── ANALYTICS MODULE ─────────────────────────────────────────────────────────

@Module({
  controllers: [CfoDashboardController, PayrollAuditController],
  providers: [CfoDashboardService, PayrollAuditService],
  exports: [CfoDashboardService, PayrollAuditService],
})
export class AnalyticsModule {}
