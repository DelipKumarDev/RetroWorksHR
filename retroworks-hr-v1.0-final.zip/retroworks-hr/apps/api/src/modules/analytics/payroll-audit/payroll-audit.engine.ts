/**
 * Payroll Audit Engine — Phase 2
 * ──────────────────────────────────────────────────────────────────────────────
 * Pure functions. No DB. No side effects. Fully testable.
 *
 * Design principles:
 *   - Each check returns AuditFinding[] (empty = clean)
 *   - Severity: CRITICAL | HIGH | MEDIUM | LOW
 *   - Never throws — wraps errors in findings
 *   - Tenant-neutral: all scoping handled by the service
 *
 * Rules encoded (from master prompt):
 *   1. TDS: spike >30%, negative attempt, missing declaration, 87A misapplication
 *   2. PF: EPS >₹1,250 cap, employee≠employer mismatch, PF not deducted
 *   3. ESI: gross >₹21K but deducted, gross ≤₹21K but missing
 *   4. PT: state mismatch, mandatory state with zero PT
 *   5. Duplicate payroll runs same month
 *   6. Salary outlier >40% from historical average
 *   7. Leave ledger: closing inconsistency, carry-forward cap breach, encashment sans audit
 */

export type AuditSeverity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
export type AuditCategory =
  | 'TDS_ANOMALY'
  | 'PF_COMPLIANCE'
  | 'ESI_THRESHOLD'
  | 'PT_MISMATCH'
  | 'DUPLICATE_RUN'
  | 'SALARY_OUTLIER'
  | 'LEAVE_LEDGER';

export interface AuditFinding {
  id: string;              // deterministic: `${category}:${employeeId || runId}:${code}`
  category: AuditCategory;
  severity: AuditSeverity;
  code: string;            // machine-readable code e.g. "TDS_SPIKE_30PCT"
  message: string;         // human-readable
  employeeId?: string;
  employeeName?: string;
  runId?: string;
  month?: number;
  year?: number;
  actual?: number;
  expected?: number;
  deviation?: number;      // absolute
  deviationPercent?: number;
  recommendation: string;
}

export interface PayslipSnapshot {
  id: string;
  employeeId: string;
  employeeName: string;
  month: number;
  year: number;
  grossPay: number;
  netPay: number;
  basicSalary: number;
  tdsDeducted: number;
  pfEmployee: number;          // Employee PF contribution
  pfEmployer: number;          // Employer PF contribution (EPS + EPF)
  pfEps: number;               // EPS portion of employer
  pfEpf: number;               // EPF portion of employer
  esiEmployee: number;
  esiEmployer: number;
  professionalTax: number;
  stateCode: string;           // For PT slab check
  hasDeclaration: boolean;     // Has Form 12BB / IT declaration
  regime: 'old' | 'new';
  annualIncomeProjection?: number;
  section87ARebateApplied?: number;
}

export interface PayrollRunSnapshot {
  id: string;
  payrollGroupId: string;
  period: string;  // "2024-05"
  month: number;
  year: number;
  status: string;
  createdAt: Date;
}

export interface LeaveBalanceSnapshot {
  employeeId: string;
  employeeName: string;
  leaveTypeId: string;
  leaveTypeCode: string;
  year: number;
  allocated: number;
  used: number;
  pending: number;
  carryForward: number;
  encashedDays?: number;
  carryForwardCap: number;
  encashable: boolean;
  hasAuditEntry: boolean;  // whether ledger entry exists for encashment
}

// ─── PT MANDATORY STATES (2024-25 India) ─────────────────────────────────────
const PT_MANDATORY_STATES = new Set([
  'KA', 'MH', 'WB', 'TN', 'AP', 'TS', 'MP', 'OR', 'AS', 'MZ',
  'ME', 'TR', 'NL', 'MN', 'SK', 'GA',
]);

// ─── ANOMALY THRESHOLDS ───────────────────────────────────────────────────────
const TDS_SPIKE_THRESHOLD_PCT   = 30;
const SALARY_OUTLIER_THRESHOLD  = 0.40;  // 40% deviation
const ESI_WAGE_CEILING          = 21_000;
const PF_WAGE_CEILING           = 15_000;
const EPS_MAX_AMOUNT            = 1_250;  // 8.33% of ₹15,000
const EPS_RATE                  = 0.0833;
const EPF_EMPLOYER_RATE         = 0.0367;
const TDS_REBATE_87A_THRESHOLD_NEW = 700_000;  // ₹7L new regime
const TDS_REBATE_87A_MAX_NEW       = 25_000;

function findingId(category: AuditCategory, key: string, code: string): string {
  return `${category}:${key}:${code}`;
}

// ─── 1. TDS ANOMALY DETECTION ─────────────────────────────────────────────────

export function checkTdsAnomalies(
  current: PayslipSnapshot[],
  previous: PayslipSnapshot[],
): AuditFinding[] {
  const findings: AuditFinding[] = [];
  const prevMap = new Map(previous.map(p => [p.employeeId, p]));

  for (const ps of current) {
    // 1a. Negative TDS attempt
    if (ps.tdsDeducted < 0) {
      findings.push({
        id: findingId('TDS_ANOMALY', ps.employeeId, 'TDS_NEGATIVE'),
        category: 'TDS_ANOMALY',
        severity: 'CRITICAL',
        code: 'TDS_NEGATIVE',
        message: `Employee ${ps.employeeName}: negative TDS of ₹${ps.tdsDeducted} detected`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: ps.tdsDeducted, expected: 0,
        recommendation: 'TDS cannot be negative. Review reversal logic and re-run payroll.',
      });
    }

    // 1b. Month-on-month spike >30%
    const prev = prevMap.get(ps.employeeId);
    if (prev && prev.tdsDeducted > 0 && ps.tdsDeducted > 0) {
      const changePct = ((ps.tdsDeducted - prev.tdsDeducted) / prev.tdsDeducted) * 100;
      if (Math.abs(changePct) > TDS_SPIKE_THRESHOLD_PCT) {
        findings.push({
          id: findingId('TDS_ANOMALY', ps.employeeId, 'TDS_SPIKE'),
          category: 'TDS_ANOMALY',
          severity: 'HIGH',
          code: 'TDS_SPIKE',
          message: `Employee ${ps.employeeName}: TDS changed ${changePct.toFixed(1)}% (₹${prev.tdsDeducted} → ₹${ps.tdsDeducted})`,
          employeeId: ps.employeeId,
          employeeName: ps.employeeName,
          month: ps.month, year: ps.year,
          actual: ps.tdsDeducted,
          expected: prev.tdsDeducted,
          deviationPercent: Math.abs(changePct),
          recommendation: 'Verify: salary revision, arrears payout, or declaration change. If legitimate, document reason.',
        });
      }
    }

    // 1c. High income but zero TDS (potential under-deduction)
    const projectedIncome = ps.annualIncomeProjection ?? ps.grossPay * 12;
    if (projectedIncome > 700_000 && ps.tdsDeducted === 0 && ps.regime === 'new') {
      findings.push({
        id: findingId('TDS_ANOMALY', ps.employeeId, 'TDS_MISSING_HIGH_INCOME'),
        category: 'TDS_ANOMALY',
        severity: 'HIGH',
        code: 'TDS_MISSING_HIGH_INCOME',
        message: `Employee ${ps.employeeName}: projected income ₹${projectedIncome.toLocaleString('en-IN')} but zero TDS deducted`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: ps.tdsDeducted, expected: undefined,
        recommendation: 'Check TDS projection. Employee income exceeds ₹7L threshold (new regime); TDS should be non-zero.',
      });
    }

    // 1d. No declaration but anomalously low TDS for high income
    if (!ps.hasDeclaration && projectedIncome > 500_000 && ps.tdsDeducted < 100) {
      findings.push({
        id: findingId('TDS_ANOMALY', ps.employeeId, 'TDS_LOW_NO_DECLARATION'),
        category: 'TDS_ANOMALY',
        severity: 'MEDIUM',
        code: 'TDS_LOW_NO_DECLARATION',
        message: `Employee ${ps.employeeName}: no declaration submitted, income ₹${projectedIncome.toLocaleString('en-IN')}, TDS only ₹${ps.tdsDeducted}`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: ps.tdsDeducted,
        recommendation: 'Request Form 12BB from employee. Without declaration, default to new regime maximum liability.',
      });
    }

    // 1e. 87A rebate applied but income exceeds threshold (new regime)
    if (
      ps.regime === 'new' &&
      ps.section87ARebateApplied &&
      ps.section87ARebateApplied > 0 &&
      projectedIncome > TDS_REBATE_87A_THRESHOLD_NEW
    ) {
      findings.push({
        id: findingId('TDS_ANOMALY', ps.employeeId, 'TDS_87A_OVER_THRESHOLD'),
        category: 'TDS_ANOMALY',
        severity: 'CRITICAL',
        code: 'TDS_87A_OVER_THRESHOLD',
        message: `Employee ${ps.employeeName}: 87A rebate ₹${ps.section87ARebateApplied} applied but projected income ₹${projectedIncome.toLocaleString('en-IN')} > ₹7L`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: ps.section87ARebateApplied,
        expected: 0,
        recommendation: 'Remove 87A rebate. Under new regime, rebate applies only if total income ≤ ₹7L.',
      });
    }
  }

  return findings;
}

// ─── 2. PF COMPLIANCE CHECKS ──────────────────────────────────────────────────

export function checkPfCompliance(payslips: PayslipSnapshot[]): AuditFinding[] {
  const findings: AuditFinding[] = [];

  for (const ps of payslips) {
    const pfBasis = Math.min(ps.basicSalary, PF_WAGE_CEILING);
    const expectedPfEmployee = Math.round(pfBasis * 0.12);
    const expectedEps = Math.min(Math.round(pfBasis * EPS_RATE), EPS_MAX_AMOUNT);
    const expectedEpf = Math.round(pfBasis * EPF_EMPLOYER_RATE);

    // 2a. EPS > ₹1,250 cap
    if (ps.pfEps > EPS_MAX_AMOUNT + 1) {  // ₹1 rounding tolerance
      findings.push({
        id: findingId('PF_COMPLIANCE', ps.employeeId, 'PF_EPS_CAP_BREACH'),
        category: 'PF_COMPLIANCE',
        severity: 'CRITICAL',
        code: 'PF_EPS_CAP_BREACH',
        message: `Employee ${ps.employeeName}: EPS ₹${ps.pfEps} exceeds statutory cap of ₹1,250`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: ps.pfEps, expected: expectedEps,
        deviation: ps.pfEps - EPS_MAX_AMOUNT,
        recommendation: 'EPS is capped at ₹1,250/month (8.33% of ₹15,000). Fix salary structure configuration.',
      });
    }

    // 2b. PF mismatch: employee ≠ EPS + EPF employer (within ₹1)
    if (ps.pfEmployer > 0) {
      const employerTotal = ps.pfEps + ps.pfEpf;
      const diff = Math.abs(ps.pfEmployer - employerTotal);
      if (diff > 1) {
        findings.push({
          id: findingId('PF_COMPLIANCE', ps.employeeId, 'PF_EMPLOYER_SPLIT_MISMATCH'),
          category: 'PF_COMPLIANCE',
          severity: 'HIGH',
          code: 'PF_EMPLOYER_SPLIT_MISMATCH',
          message: `Employee ${ps.employeeName}: Employer PF ₹${ps.pfEmployer} ≠ EPS(₹${ps.pfEps}) + EPF(₹${ps.pfEpf}) = ₹${employerTotal}`,
          employeeId: ps.employeeId,
          employeeName: ps.employeeName,
          month: ps.month, year: ps.year,
          actual: ps.pfEmployer,
          expected: employerTotal,
          deviation: diff,
          recommendation: 'EPS + EPF portions must sum to total employer contribution. Recheck split calculation.',
        });
      }
    }

    // 2c. PF not deducted for eligible employee (basic ≤ ₹15K mandatory)
    if (ps.pfEmployee === 0 && ps.basicSalary <= PF_WAGE_CEILING && ps.grossPay > 0) {
      findings.push({
        id: findingId('PF_COMPLIANCE', ps.employeeId, 'PF_MISSING_ELIGIBLE'),
        category: 'PF_COMPLIANCE',
        severity: 'HIGH',
        code: 'PF_MISSING_ELIGIBLE',
        message: `Employee ${ps.employeeName}: basic ₹${ps.basicSalary} ≤ ₹15,000 but zero PF deducted`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: 0,
        expected: expectedPfEmployee,
        recommendation: 'Employees with basic ≤ ₹15,000 are mandatorily PF-eligible. Enable PF for this employee.',
      });
    }
  }

  return findings;
}

// ─── 3. ESI THRESHOLD CHECKS ─────────────────────────────────────────────────

export function checkEsiThreshold(payslips: PayslipSnapshot[]): AuditFinding[] {
  const findings: AuditFinding[] = [];

  for (const ps of payslips) {
    // 3a. Gross > ₹21K but ESI deducted
    if (ps.grossPay > ESI_WAGE_CEILING && ps.esiEmployee > 0) {
      findings.push({
        id: findingId('ESI_THRESHOLD', ps.employeeId, 'ESI_ABOVE_CEILING'),
        category: 'ESI_THRESHOLD',
        severity: 'HIGH',
        code: 'ESI_ABOVE_CEILING',
        message: `Employee ${ps.employeeName}: gross ₹${ps.grossPay} > ₹21,000 but ESI ₹${ps.esiEmployee} deducted`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: ps.esiEmployee, expected: 0,
        recommendation: 'ESI deductions must stop once employee gross exceeds ₹21,000/month. Mark employee as ESI-exempt.',
      });
    }

    // 3b. Gross ≤ ₹21K but no ESI (and not explicitly exempt)
    if (ps.grossPay <= ESI_WAGE_CEILING && ps.esiEmployee === 0 && ps.grossPay > 0) {
      findings.push({
        id: findingId('ESI_THRESHOLD', ps.employeeId, 'ESI_MISSING_ELIGIBLE'),
        category: 'ESI_THRESHOLD',
        severity: 'MEDIUM',
        code: 'ESI_MISSING_ELIGIBLE',
        message: `Employee ${ps.employeeName}: gross ₹${ps.grossPay} ≤ ₹21,000 but zero ESI deducted`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: 0,
        expected: Math.round(ps.grossPay * 0.0075),
        recommendation: 'Check if employee is genuinely ESI-exempt (e.g., disabled employee exemption). If not, enable ESI.',
      });
    }
  }

  return findings;
}

// ─── 4. PT STATE MISMATCH ─────────────────────────────────────────────────────

export function checkPtMismatch(payslips: PayslipSnapshot[]): AuditFinding[] {
  const findings: AuditFinding[] = [];

  for (const ps of payslips) {
    const isMandatory = PT_MANDATORY_STATES.has(ps.stateCode);

    // 4a. In mandatory PT state but zero PT
    if (isMandatory && ps.professionalTax === 0 && ps.grossPay > 0) {
      findings.push({
        id: findingId('PT_MISMATCH', ps.employeeId, 'PT_MISSING_MANDATORY_STATE'),
        category: 'PT_MISMATCH',
        severity: 'HIGH',
        code: 'PT_MISSING_MANDATORY_STATE',
        message: `Employee ${ps.employeeName}: state ${ps.stateCode} requires PT but ₹0 deducted`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: 0,
        recommendation: `Configure PT slab for ${ps.stateCode}. Professional Tax is mandatory in this state.`,
      });
    }

    // 4b. PT deducted in non-PT state
    if (!isMandatory && ps.professionalTax > 0) {
      findings.push({
        id: findingId('PT_MISMATCH', ps.employeeId, 'PT_NON_MANDATORY_STATE'),
        category: 'PT_MISMATCH',
        severity: 'MEDIUM',
        code: 'PT_NON_MANDATORY_STATE',
        message: `Employee ${ps.employeeName}: PT ₹${ps.professionalTax} deducted but state ${ps.stateCode} has no PT`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: ps.professionalTax, expected: 0,
        recommendation: `Review employee location. ${ps.stateCode} does not have PT. Remove PT config for this employee.`,
      });
    }
  }

  return findings;
}

// ─── 5. DUPLICATE PAYROLL DETECTION ──────────────────────────────────────────

export function checkDuplicateRuns(runs: PayrollRunSnapshot[]): AuditFinding[] {
  const findings: AuditFinding[] = [];
  const periodMap = new Map<string, PayrollRunSnapshot[]>();

  for (const run of runs) {
    const key = `${run.payrollGroupId}:${run.period}`;
    const existing = periodMap.get(key) ?? [];
    existing.push(run);
    periodMap.set(key, existing);
  }

  for (const [key, group] of periodMap.entries()) {
    if (group.length > 1) {
      const [groupId, period] = key.split(':');
      findings.push({
        id: findingId('DUPLICATE_RUN', groupId!, `${period}`),
        category: 'DUPLICATE_RUN',
        severity: 'CRITICAL',
        code: 'DUPLICATE_PAYROLL_RUN',
        message: `${group.length} payroll runs detected for period ${period} (group: ${groupId})`,
        runId: group.map(r => r.id).join(','),
        month: group[0]!.month,
        year: group[0]!.year,
        actual: group.length,
        expected: 1,
        recommendation: 'Investigate duplicate runs. Only one active run per payroll group per period is allowed. Reverse duplicates.',
      });
    }
  }

  return findings;
}

// ─── 6. SALARY OUTLIER DETECTION ─────────────────────────────────────────────

export interface SalaryHistoryItem {
  employeeId: string;
  employeeName: string;
  historicalAvgNet: number;
  historicalAvgGross: number;
  sampleMonths: number;
}

export function checkSalaryOutliers(
  current: PayslipSnapshot[],
  history: SalaryHistoryItem[],
): AuditFinding[] {
  const findings: AuditFinding[] = [];
  const histMap = new Map(history.map(h => [h.employeeId, h]));

  for (const ps of current) {
    const hist = histMap.get(ps.employeeId);
    if (!hist || hist.sampleMonths < 2) continue; // not enough history

    const grossDev = Math.abs(ps.grossPay - hist.historicalAvgGross) / hist.historicalAvgGross;
    const netDev   = Math.abs(ps.netPay - hist.historicalAvgNet) / hist.historicalAvgNet;

    if (grossDev > SALARY_OUTLIER_THRESHOLD) {
      findings.push({
        id: findingId('SALARY_OUTLIER', ps.employeeId, 'GROSS_OUTLIER'),
        category: 'SALARY_OUTLIER',
        severity: grossDev > 0.75 ? 'HIGH' : 'MEDIUM',
        code: 'GROSS_SALARY_OUTLIER',
        message: `Employee ${ps.employeeName}: gross ₹${ps.grossPay} deviates ${(grossDev*100).toFixed(1)}% from ${hist.sampleMonths}-month avg ₹${Math.round(hist.historicalAvgGross)}`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: ps.grossPay,
        expected: Math.round(hist.historicalAvgGross),
        deviationPercent: grossDev * 100,
        recommendation: 'Verify: increment, bonus, LWP correction, or arrears. If legitimate, document salary revision.',
      });
    }

    // Net pay outlier (separate check — high deductions can cause net to drop even if gross is same)
    if (netDev > SALARY_OUTLIER_THRESHOLD && grossDev <= SALARY_OUTLIER_THRESHOLD) {
      findings.push({
        id: findingId('SALARY_OUTLIER', ps.employeeId, 'NET_OUTLIER'),
        category: 'SALARY_OUTLIER',
        severity: 'MEDIUM',
        code: 'NET_PAY_OUTLIER',
        message: `Employee ${ps.employeeName}: net ₹${ps.netPay} deviates ${(netDev*100).toFixed(1)}% from avg ₹${Math.round(hist.historicalAvgNet)} (gross unchanged)`,
        employeeId: ps.employeeId,
        employeeName: ps.employeeName,
        month: ps.month, year: ps.year,
        actual: ps.netPay,
        expected: Math.round(hist.historicalAvgNet),
        deviationPercent: netDev * 100,
        recommendation: 'Gross normal but net changed significantly — check for unexpected deduction increase (advance, loan, or manual adjustment).',
      });
    }
  }

  return findings;
}

// ─── 7. LEAVE LEDGER CORRUPTION CHECK ────────────────────────────────────────

export function checkLeaveLedger(balances: LeaveBalanceSnapshot[]): AuditFinding[] {
  const findings: AuditFinding[] = [];

  for (const b of balances) {
    const closingAvailable = b.allocated - b.used - b.pending;

    // 7a. Negative available balance
    if (closingAvailable < -0.5) {  // 0.5 tolerance for half-day rounding
      findings.push({
        id: findingId('LEAVE_LEDGER', `${b.employeeId}:${b.leaveTypeId}`, 'NEGATIVE_BALANCE'),
        category: 'LEAVE_LEDGER',
        severity: 'HIGH',
        code: 'LEAVE_NEGATIVE_BALANCE',
        message: `Employee ${b.employeeId} [${b.leaveTypeCode}]: closing balance ${closingAvailable.toFixed(1)} days is negative`,
        employeeId: b.employeeId,
        actual: closingAvailable,
        expected: 0,
        recommendation: 'Employee has used more leave than allocated. Review leave records and adjust balance or add LWP.',
      });
    }

    // 7b. Carry-forward exceeds cap
    if (b.carryForward > b.carryForwardCap + 0.5) {
      findings.push({
        id: findingId('LEAVE_LEDGER', `${b.employeeId}:${b.leaveTypeId}`, 'CARRY_FORWARD_CAP'),
        category: 'LEAVE_LEDGER',
        severity: 'MEDIUM',
        code: 'LEAVE_CARRY_FORWARD_CAP_BREACH',
        message: `Employee ${b.employeeId} [${b.leaveTypeCode}]: carry-forward ${b.carryForward} exceeds cap of ${b.carryForwardCap}`,
        employeeId: b.employeeId,
        actual: b.carryForward,
        expected: b.carryForwardCap,
        deviation: b.carryForward - b.carryForwardCap,
        recommendation: 'Carry-forward exceeds policy limit. Run year-end close to lapse excess days.',
      });
    }

    // 7c. Encashment without audit ledger entry
    if (b.encashable && (b.encashedDays ?? 0) > 0 && !b.hasAuditEntry) {
      findings.push({
        id: findingId('LEAVE_LEDGER', `${b.employeeId}:${b.leaveTypeId}`, 'ENCASHMENT_NO_AUDIT'),
        category: 'LEAVE_LEDGER',
        severity: 'HIGH',
        code: 'LEAVE_ENCASHMENT_NO_AUDIT',
        message: `Employee ${b.employeeId} [${b.leaveTypeCode}]: ${b.encashedDays} days encashed but no ledger audit entry found`,
        employeeId: b.employeeId,
        actual: b.encashedDays,
        expected: 0,
        recommendation: 'Encashment must have a corresponding leave_year_end_entries record. Run year-end close to generate proper audit trail.',
      });
    }
  }

  return findings;
}

// ─── AGGREGATE ALL CHECKS ─────────────────────────────────────────────────────

export interface AuditReport {
  tenantId: string;
  month: number;
  year: number;
  totalPayslipsScanned: number;
  totalRunsScanned: number;
  totalFindingsCount: number;
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  riskScore: number;       // 0–100: 0 = clean, 100 = severely non-compliant
  riskLevel: 'CLEAN' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  findings: AuditFinding[];
  generatedAt: Date;
}

export function buildAuditReport(
  tenantId: string,
  month: number,
  year: number,
  allFindings: AuditFinding[],
  payslipCount: number,
  runCount: number,
): AuditReport {
  const critical = allFindings.filter(f => f.severity === 'CRITICAL').length;
  const high     = allFindings.filter(f => f.severity === 'HIGH').length;
  const medium   = allFindings.filter(f => f.severity === 'MEDIUM').length;
  const low      = allFindings.filter(f => f.severity === 'LOW').length;

  // Risk score: weighted sum capped at 100
  const rawScore = critical * 25 + high * 10 + medium * 4 + low * 1;
  const riskScore = Math.min(100, rawScore);

  const riskLevel =
    critical > 0  ? 'CRITICAL' :
    riskScore >= 50 ? 'HIGH'    :
    riskScore >= 20 ? 'MEDIUM'  :
    riskScore > 0  ? 'LOW'      : 'CLEAN';

  return {
    tenantId, month, year,
    totalPayslipsScanned: payslipCount,
    totalRunsScanned: runCount,
    totalFindingsCount: allFindings.length,
    criticalCount: critical,
    highCount: high,
    mediumCount: medium,
    lowCount: low,
    riskScore,
    riskLevel,
    findings: allFindings.sort((a, b) => {
      const order = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
      return order[a.severity] - order[b.severity];
    }),
    generatedAt: new Date(),
  };
}
