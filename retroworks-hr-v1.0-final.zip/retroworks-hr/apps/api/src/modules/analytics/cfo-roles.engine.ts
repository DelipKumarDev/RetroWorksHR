/**
 * CFO & Finance-Controller Role Definitions — Phase 2 Extension
 * ──────────────────────────────────────────────────────────────────────────────
 * Extends role-permission.engine.ts with two new predefined roles.
 * Import and call buildCfoRoles() alongside buildSystemRoles() in your tenant setup.
 *
 * CFO:
 *   - Read-only payroll, TDS, PF, ESI, Form 16, 24Q
 *   - Full access to analytics/cfo and analytics/audit dashboards
 *   - Cannot run, approve, or modify payroll
 *   - Cannot modify leave or employee data
 *   - Salary & bank details visible (CFO needs full financial picture)
 *
 * Finance Controller:
 *   - Same as CFO + can export reports
 *   - Still read-only on payroll execution
 */

export interface CfoRoleDefinition {
  id: string;
  name: string;
  displayName: string;
  description: string;
  tenantId: string;
  allowedModules: string[];
  permissions: {
    resource: string;
    module: string;
    actions: string[];
  }[];
  globalMaskedFields: string[];
  isSystem: true;
}

export function buildCfoRoles(tenantId: string, createdBy: string): CfoRoleDefinition[] {
  const base = (id: string, name: string, display: string, desc: string): CfoRoleDefinition => ({
    id: `sys-${id}`,
    name,
    displayName: display,
    description: desc,
    tenantId,
    allowedModules: [],
    permissions: [],
    globalMaskedFields: [],
    isSystem: true,
  });

  const cfoRole: CfoRoleDefinition = {
    ...base('cfo', 'cfo', 'Chief Financial Officer', 'Read-only financial intelligence + audit access'),
    allowedModules: [
      'analytics-cfo',         // CFO dashboard
      'analytics-audit',       // Payroll audit mode
      'payroll',               // Read-only payslip/run access
      'payroll-tds',           // TDS reports
      'payroll-pf-esi',        // PF/ESI reports
      'payroll-form16',        // Form 16
      'reports',               // Standard reports
      'leave',                 // Leave liability view (read-only)
    ],
    permissions: [
      // Payroll — read + export only, NO create/approve/modify
      { resource: 'payroll:run',        module: 'payroll',          actions: ['read', 'export'] },
      { resource: 'payroll:payslip',    module: 'payroll',          actions: ['read', 'export'] },
      { resource: 'payroll:structure',  module: 'payroll',          actions: ['read'] },
      { resource: 'tds:projection',     module: 'payroll-tds',      actions: ['read', 'export'] },
      { resource: 'tds:return',         module: 'payroll-tds',      actions: ['read', 'export'] },
      { resource: 'pf:ecr',            module: 'payroll-pf-esi',   actions: ['read', 'export'] },
      { resource: 'esi:return',         module: 'payroll-pf-esi',   actions: ['read', 'export'] },
      { resource: 'form16:record',      module: 'payroll-form16',   actions: ['read', 'export'] },
      // Analytics — full read
      { resource: 'analytics:cfo',      module: 'analytics-cfo',    actions: ['read', 'export', 'simulate'] },
      { resource: 'analytics:audit',    module: 'analytics-audit',  actions: ['read', 'run', 'export'] },
      // Leave — read-only for liability view
      { resource: 'leave:balance',      module: 'leave',            actions: ['read'] },
      // Employee — read-only (no PII masking for CFO — needs full financial picture)
      { resource: 'employee',           module: 'core-hr',          actions: ['read'] },
      // Reports
      { resource: 'report',             module: 'reports',          actions: ['read', 'export'] },
    ],
    globalMaskedFields: [
      // CFO sees salary; masks only non-financial PII
      'employee.aadhaarNumber',
      'employee.passportNumber',
    ],
  };

  const financeControllerRole: CfoRoleDefinition = {
    ...base('finance-controller', 'finance-controller', 'Finance Controller', 'Senior finance read-only + audit authority'),
    allowedModules: [...cfoRole.allowedModules],
    permissions: [
      ...cfoRole.permissions,
      // Finance controller can also export bulk reports
      { resource: 'analytics:audit',    module: 'analytics-audit',  actions: ['read', 'run', 'export', 'bulk-export'] },
      { resource: 'report',             module: 'reports',          actions: ['read', 'export', 'schedule'] },
    ],
    globalMaskedFields: [...cfoRole.globalMaskedFields],
  };

  return [cfoRole, financeControllerRole];
}

// ── Permission check helpers ───────────────────────────────────────────────────

export function isCfoRole(roleName: string): boolean {
  return ['cfo', 'finance-controller'].includes(roleName);
}

export function canAccessCfoDashboard(roles: string[]): boolean {
  const allowed = ['cfo', 'finance-controller', 'finance', 'hr-admin', 'super-admin'];
  return roles.some(r => allowed.includes(r));
}

export function canRunAudit(roles: string[]): boolean {
  const allowed = ['cfo', 'finance-controller', 'hr-admin', 'super-admin'];
  return roles.some(r => allowed.includes(r));
}

export function canSimulateRevision(roles: string[]): boolean {
  // Only CFO-level roles can simulate (read-only but sensitive)
  return canAccessCfoDashboard(roles);
}
