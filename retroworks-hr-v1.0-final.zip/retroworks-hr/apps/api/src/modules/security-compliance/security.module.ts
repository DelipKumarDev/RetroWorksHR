/**
 * Security & Compliance — NestJS Service + Controller + Module
 * RetroWorks HR v1.0
 */

import {
  Injectable, Logger, ForbiddenException, NotFoundException,
  BadRequestException, UnauthorizedException,
  Module, Controller, Get, Post, Put, Patch, Delete, Body,
  Param, Query, UseGuards, HttpCode, HttpStatus, Headers, Ip,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { PrismaClient } from '@prisma/client';
import { Cron } from '@nestjs/schedule';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';
import { createHash, randomBytes } from 'crypto';

import {
  checkIpAllowlist, checkMfaRequirement, evaluateFeatureFlag,
  parseUserAgent, computeDpdpaSlaDeadline, isDpdpaOverdue,
  generateDownloadToken, computeOverallHealth, isPrivateIp,
  DPDPA_DOWNLOAD_EXPIRY_HOURS, DPDPA_MAX_DOWNLOADS, DPDPA_RESPONSE_SLA_DAYS,
  type MfaPolicy, type IpAllowlistEntry, type HealthStatus,
  type ServiceHealth, type SystemHealthSnapshot, type FeatureFlag,
} from './security.types';

// ─── Security Service ──────────────────────────────────────────────────────────

@Injectable()
export class SecurityService {
  private readonly logger = new Logger(SecurityService.name);

  // In-memory health cache (refreshed every 30s by cron)
  private healthCache: SystemHealthSnapshot | null = null;
  private healthCacheAt = 0;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ── MFA Enforcement ────────────────────────────────────────────────────────

  async getMfaPolicy(tenantId: string): Promise<MfaPolicy> {
    const settings = await (this.prisma as any).tenantSecuritySettings?.findFirst({
      where: { tenantId },
    }).catch(() => null);

    return {
      tenantId,
      enforceForRoles: settings?.mfaEnforceForRoles ?? ['payroll-admin', 'super-admin'],
      gracePeriodHours: settings?.mfaGracePeriodHours ?? 24,
      allowedMethods: ['totp', 'backup_codes'],
    };
  }

  async updateMfaPolicy(tenantId: string, dto: Partial<MfaPolicy>, updatedBy: string) {
    return (this.prisma as any).tenantSecuritySettings?.upsert({
      where: { tenantId },
      create: {
        tenantId,
        mfaEnforceForRoles: dto.enforceForRoles ?? ['payroll-admin', 'super-admin'],
        mfaGracePeriodHours: dto.gracePeriodHours ?? 24,
        updatedBy,
      },
      update: {
        mfaEnforceForRoles: dto.enforceForRoles,
        mfaGracePeriodHours: dto.gracePeriodHours,
        updatedBy,
      },
    }) ?? dto;
  }

  async checkMfaGate(userId: string, tenantId: string): Promise<void> {
    const [user, policy] = await Promise.all([
      this.prisma.user.findFirst({
        where: { id: userId },
        include: { roles: { include: { role: true } } },
      }),
      this.getMfaPolicy(tenantId),
    ]);
    if (!user) throw new NotFoundException('User not found');

    const userRoles = user.roles.map((ur: any) => ur.role.name);
    const result = checkMfaRequirement(userRoles, policy, user.mfaEnabled, user.createdAt);

    if (result.required && !result.enrolled) {
      const msg = 'enrolled' in result && !result.enrolled
        ? `MFA required for your role. ${result.gracePeriodRemaining ? `${result.gracePeriodRemaining}h grace period remaining.` : 'Please enrol now.'}`
        : 'MFA verification required';
      throw new ForbiddenException({ code: 'MFA_REQUIRED', message: msg });
    }
  }

  // ── IP Allowlist ───────────────────────────────────────────────────────────

  async getIpAllowlist(tenantId: string): Promise<IpAllowlistEntry[]> {
    const rules = await (this.prisma as any).ipAllowlistRule?.findMany({
      where: { tenantId, deletedAt: null },
      orderBy: { createdAt: 'desc' },
    }) ?? [];
    return rules;
  }

  async addIpRule(tenantId: string, cidr: string, label: string, addedBy: string, expiresAt?: Date) {
    // Basic CIDR validation
    if (!cidr.match(/^[\d.]+\/\d+$/) && !cidr.match(/^[\d.]+$/)) {
      throw new BadRequestException(`Invalid CIDR format: ${cidr}`);
    }
    return (this.prisma as any).ipAllowlistRule?.create({
      data: { tenantId, cidr, label, addedBy, expiresAt },
    });
  }

  async removeIpRule(tenantId: string, ruleId: string) {
    return (this.prisma as any).ipAllowlistRule?.update({
      where: { id: ruleId },
      data: { deletedAt: new Date() },
    });
  }

  async checkIp(tenantId: string, ip: string) {
    // Private IPs always allowed (internal traffic)
    if (isPrivateIp(ip)) return { allowed: true, reason: 'Private/loopback IP' };
    const rules = await this.getIpAllowlist(tenantId);
    return checkIpAllowlist(ip, rules);
  }

  // ── Session Management ─────────────────────────────────────────────────────

  async getSessionActivity(tenantId: string, userId: string, currentToken: string) {
    const sessions = await (this.prisma as any).session.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 20,
    });

    const currentHash = createHash('sha256').update(currentToken).digest('hex');

    return sessions.map((s: any) => {
      const parsed = parseUserAgent(s.userAgent ?? '');
      const tokenHash = createHash('sha256').update(s.token).digest('hex');
      return {
        id: s.id,
        ip: s.ip ?? 'Unknown',
        userAgent: s.userAgent,
        deviceName: parsed.deviceName,
        browser: parsed.browser,
        os: parsed.os,
        isCurrentSession: tokenHash === currentHash,
        isActive: !s.revokedAt && s.expiresAt > new Date(),
        revokedAt: s.revokedAt,
        lastActiveAt: s.lastActiveAt ?? s.createdAt,
        createdAt: s.createdAt,
        expiresAt: s.expiresAt,
      };
    });
  }

  async revokeSession(sessionId: string, requesterId: string, tenantId: string) {
    const session = await (this.prisma as any).session.findFirst({
      where: { id: sessionId },
      include: { user: true },
    });
    if (!session) throw new NotFoundException('Session not found');
    if (session.user.tenantId !== tenantId) throw new ForbiddenException();

    await (this.prisma as any).session.update({
      where: { id: sessionId },
      data: { revokedAt: new Date(), revokedBy: requesterId },
    });

    this.events.emit('session.revoked', { sessionId, requesterId, userId: session.userId });
    return { revoked: true };
  }

  async revokeAllSessions(userId: string, exceptToken?: string) {
    const where: any = { userId, revokedAt: null };
    if (exceptToken) {
      const currentSession = await (this.prisma as any).session.findFirst({ where: { token: exceptToken } });
      if (currentSession) where.id = { not: currentSession.id };
    }
    const result = await (this.prisma as any).session.updateMany({
      where,
      data: { revokedAt: new Date(), revokedBy: userId },
    });
    return { revokedCount: result.count };
  }

  async getLoginHistory(tenantId: string, userId: string, limit = 50) {
    return (this.prisma as any).loginHistory?.findMany({
      where: { tenantId, userId },
      orderBy: { createdAt: 'desc' },
      take: limit,
    }) ?? [];
  }

  async recordLoginAttempt(data: {
    userId?: string; tenantId: string; ip: string; userAgent: string;
    success: boolean; failureReason?: string; mfaUsed?: boolean;
  }) {
    const parsed = parseUserAgent(data.userAgent);
    return (this.prisma as any).loginHistory?.create({
      data: {
        ...data,
        deviceName: parsed.deviceName,
        mfaUsed: data.mfaUsed ?? false,
      },
    }).catch(() => null); // non-fatal
  }

  // ── DPDPA Workflow ─────────────────────────────────────────────────────────

  async submitDpdpaRequest(
    tenantId: string,
    requesterId: string,
    requestType: 'export' | 'deletion' | 'correction',
    reason?: string,
  ) {
    // Check for existing pending request
    const existing = await (this.prisma as any).dpdpaRequest?.findFirst({
      where: { tenantId, requesterId, requestType, status: { in: ['pending', 'under_review'] } },
    });
    if (existing) throw new BadRequestException('A request of this type is already pending.');

    const request = await (this.prisma as any).dpdpaRequest?.create({
      data: {
        tenantId, requesterId, requestType,
        status: 'pending',
        reason,
        isLegalHold: false,
        downloadCount: 0,
        maxDownloads: DPDPA_MAX_DOWNLOADS,
        slaDeadline: computeDpdpaSlaDeadline(new Date()),
      },
    });

    this.events.emit('dpdpa.request.submitted', { tenantId, requestId: request?.id, requestType });
    return request;
  }

  async listDpdpaRequests(tenantId: string, status?: string) {
    return (this.prisma as any).dpdpaRequest?.findMany({
      where: { tenantId, ...(status ? { status } : {}) },
      include: {
        requester: { select: { id: true, firstName: true, lastName: true, employeeCode: true } },
      },
      orderBy: { createdAt: 'desc' },
    }) ?? [];
  }

  async approveDpdpaRequest(
    requestId: string,
    tenantId: string,
    adminId: string,
    notes?: string,
  ) {
    const req = await (this.prisma as any).dpdpaRequest?.findFirst({
      where: { id: requestId, tenantId },
    });
    if (!req) throw new NotFoundException('Request not found');
    if (req.isLegalHold) throw new ForbiddenException('Cannot process request — legal hold active');

    const downloadToken = req.requestType === 'export' ? generateDownloadToken() : undefined;
    const downloadExpiresAt = downloadToken
      ? new Date(Date.now() + DPDPA_DOWNLOAD_EXPIRY_HOURS * 3_600_000)
      : undefined;

    const updated = await (this.prisma as any).dpdpaRequest?.update({
      where: { id: requestId },
      data: {
        status: req.requestType === 'export' ? 'completed' : 'approved',
        reviewedBy: adminId,
        reviewedAt: new Date(),
        adminNotes: notes,
        downloadToken,
        downloadExpiresAt,
        completedAt: req.requestType === 'export' ? new Date() : undefined,
      },
    });

    if (req.requestType === 'export' && downloadToken) {
      // In production: trigger async data export job
      this.events.emit('dpdpa.export.requested', { requestId, tenantId, requesterId: req.requesterId, downloadToken });
    }
    if (req.requestType === 'deletion') {
      this.events.emit('dpdpa.deletion.approved', { requestId, tenantId, requesterId: req.requesterId });
    }

    return updated;
  }

  async rejectDpdpaRequest(requestId: string, tenantId: string, adminId: string, reason: string) {
    return (this.prisma as any).dpdpaRequest?.update({
      where: { id: requestId },
      data: { status: 'rejected', reviewedBy: adminId, reviewedAt: new Date(), adminNotes: reason },
    });
  }

  async setLegalHold(requestId: string, tenantId: string, adminId: string, reason: string, hold: boolean) {
    return (this.prisma as any).dpdpaRequest?.update({
      where: { id: requestId },
      data: {
        isLegalHold: hold,
        legalHoldReason: hold ? reason : null,
        legalHoldBy: hold ? adminId : null,
        legalHoldAt: hold ? new Date() : null,
      },
    });
  }

  async getConsentHistory(tenantId: string, employeeId: string) {
    return (this.prisma as any).consentRecord?.findMany({
      where: { tenantId, employeeId },
      orderBy: { givenAt: 'desc' },
    }) ?? [];
  }

  async recordConsent(tenantId: string, employeeId: string, consentType: string, version: string, ip?: string) {
    // Withdraw any existing active consent of same type
    await (this.prisma as any).consentRecord?.updateMany({
      where: { tenantId, employeeId, consentType, isActive: true },
      data: { withdrawnAt: new Date(), withdrawnReason: 'Superseded by new consent', isActive: false },
    }).catch(() => null);

    return (this.prisma as any).consentRecord?.create({
      data: { tenantId, employeeId, consentType, consentVersion: version, givenAt: new Date(), ipAddress: ip, isActive: true },
    });
  }

  async validateDownloadToken(token: string, tenantId: string) {
    const req = await (this.prisma as any).dpdpaRequest?.findFirst({
      where: { downloadToken: token, tenantId },
    });
    if (!req) throw new NotFoundException('Invalid or expired download link');
    if (req.downloadExpiresAt && req.downloadExpiresAt < new Date()) {
      throw new ForbiddenException('Download link has expired');
    }
    if (req.downloadCount >= req.maxDownloads) {
      throw new ForbiddenException('Download limit reached');
    }
    // Increment download counter
    await (this.prisma as any).dpdpaRequest?.update({
      where: { id: req.id },
      data: { downloadCount: { increment: 1 } },
    });
    return req;
  }

  // ── System Health ──────────────────────────────────────────────────────────

  async getSystemHealth(): Promise<SystemHealthSnapshot> {
    // Use cache if < 30s old
    if (this.healthCache && Date.now() - this.healthCacheAt < 30_000) {
      return this.healthCache;
    }

    const start = Date.now();
    const checks = await Promise.allSettled([
      this.checkDatabase(),
      this.checkRedis(),
      this.checkStorage(),
    ]);

    const [dbResult, redisResult, storageResult] = checks;
    const dbHealth = dbResult.status === 'fulfilled' ? dbResult.value : { name: 'database', status: 'down' as HealthStatus, message: String((dbResult as any).reason), lastChecked: new Date() };
    const redisHealth = redisResult.status === 'fulfilled' ? redisResult.value : { name: 'redis', status: 'down' as HealthStatus, message: String((redisResult as any).reason), lastChecked: new Date() };
    const storageHealth = storageResult.status === 'fulfilled' ? storageResult.value : { name: 'storage', status: 'degraded' as HealthStatus, message: 'Check failed', lastChecked: new Date() };

    const [queueStats, cronLogs, lastBackup, failedJobs, aiUsage] = await Promise.all([
      this.getQueueStats(),
      this.getCronLogs(),
      this.getLastBackupInfo(),
      this.getFailedJobCount24h(),
      this.getAiUsageStats(),
    ]);

    const snapshot: SystemHealthSnapshot = {
      timestamp: new Date(),
      overall: computeOverallHealth([dbHealth, redisHealth]),
      services: { database: dbHealth, redis: redisHealth, storage: storageHealth },
      queues: queueStats,
      crons: cronLogs,
      lastBackup,
      failedJobs24h: failedJobs,
      aiUsage,
      appVersion: process.env.APP_VERSION ?? '1.0.0',
      nodeVersion: process.version,
      uptimeSeconds: Math.floor(process.uptime()),
    };

    this.healthCache = snapshot;
    this.healthCacheAt = Date.now();
    return snapshot;
  }

  private async checkDatabase(): Promise<ServiceHealth> {
    const t = Date.now();
    try {
      await this.prisma.$queryRaw`SELECT 1`;
      return { name: 'database', status: 'healthy', latencyMs: Date.now() - t, lastChecked: new Date() };
    } catch (e: any) {
      return { name: 'database', status: 'down', message: e.message, lastChecked: new Date() };
    }
  }

  private async checkRedis(): Promise<ServiceHealth> {
    const t = Date.now();
    try {
      // Try to reach Redis via a simple ping
      const redis = (global as any).__redisClient;
      if (redis) {
        await redis.ping();
        return { name: 'redis', status: 'healthy', latencyMs: Date.now() - t, lastChecked: new Date() };
      }
      // If no Redis client, check via a queue health endpoint
      return { name: 'redis', status: 'degraded', message: 'Redis client not configured', latencyMs: Date.now() - t, lastChecked: new Date() };
    } catch (e: any) {
      return { name: 'redis', status: 'down', message: e.message, lastChecked: new Date() };
    }
  }

  private async checkStorage(): Promise<ServiceHealth> {
    const t = Date.now();
    try {
      // Check S3/local storage availability
      return { name: 'storage', status: 'healthy', latencyMs: Date.now() - t, lastChecked: new Date() };
    } catch (e: any) {
      return { name: 'storage', status: 'degraded', message: e.message, lastChecked: new Date() };
    }
  }

  private async getQueueStats() {
    try {
      const jobs = await (this.prisma as any).jobQueue?.groupBy({
        by: ['queueName', 'status'],
        _count: { id: true },
      }) ?? [];

      const queues: Record<string, any> = {};
      for (const row of jobs) {
        if (!queues[row.queueName]) queues[row.queueName] = { name: row.queueName, waiting: 0, active: 0, completed: 0, failed: 0, delayed: 0, isPaused: false };
        queues[row.queueName][row.status] = row._count.id;
      }
      return Object.values(queues);
    } catch { return []; }
  }

  private async getCronLogs() {
    try {
      return await (this.prisma as any).cronExecutionLog?.findMany({
        orderBy: { lastRun: 'desc' },
        take: 20,
      }) ?? this.getDefaultCronLogs();
    } catch { return this.getDefaultCronLogs(); }
  }

  private getDefaultCronLogs() {
    // Well-known crons from phases 1-6
    return [
      { jobName: 'grace-period-enforcement', lastStatus: 'never', runCount24h: 0 },
      { jobName: 'monthly-invoicing', lastStatus: 'never', runCount24h: 0 },
      { jobName: 'seat-count-sync', lastStatus: 'never', runCount24h: 0 },
      { jobName: 'tds-monthly-compute', lastStatus: 'never', runCount24h: 0 },
      { jobName: 'leave-accrual', lastStatus: 'never', runCount24h: 0 },
      { jobName: 'dpdpa-sla-check', lastStatus: 'never', runCount24h: 0 },
    ];
  }

  private async getLastBackupInfo() {
    try {
      const backup = await (this.prisma as any).backupLog?.findFirst({
        orderBy: { startedAt: 'desc' },
      });
      if (!backup) return undefined;
      return {
        at: backup.completedAt,
        sizeGb: backup.sizeBytes ? Number((backup.sizeBytes / 1_073_741_824).toFixed(2)) : 0,
        status: backup.status as 'success' | 'failure',
        location: backup.storageLocation ?? 's3',
      };
    } catch { return undefined; }
  }

  private async getFailedJobCount24h() {
    try {
      return await (this.prisma as any).jobQueue?.count({
        where: { status: 'failed', createdAt: { gte: new Date(Date.now() - 86_400_000) } },
      }) ?? 0;
    } catch { return 0; }
  }

  private async getAiUsageStats() {
    try {
      const period = new Date().toISOString().slice(0, 7);
      const usage = await (this.prisma as any).aiUsageLog?.aggregate({
        where: { createdAt: { gte: new Date(new Date().setDate(1)) } },
        _sum: { tokensIn: true, tokensOut: true },
        _count: { id: true },
      });
      if (!usage) return undefined;
      return {
        tenantId: 'all',
        period,
        totalRequests: usage._count?.id ?? 0,
        totalTokensIn: usage._sum?.tokensIn ?? 0,
        totalTokensOut: usage._sum?.tokensOut ?? 0,
        estimatedCostUsd: ((usage._sum?.tokensIn ?? 0) * 0.000003 + (usage._sum?.tokensOut ?? 0) * 0.000015),
        byFeature: {},
      };
    } catch { return undefined; }
  }

  // ── Feature Flags ──────────────────────────────────────────────────────────

  async listFeatureFlags() {
    return (this.prisma as any).featureFlag?.findMany({
      orderBy: [{ category: 'asc' }, { key: 'asc' }],
    }) ?? this.getBuiltinFlags();
  }

  async getFlag(key: string): Promise<FeatureFlag | null> {
    return (this.prisma as any).featureFlag?.findFirst({ where: { key } }) ?? null;
  }

  async updateFlag(key: string, data: Partial<FeatureFlag>, updatedBy: string) {
    return (this.prisma as any).featureFlag?.upsert({
      where: { key },
      create: { ...data, key, createdAt: new Date(), updatedAt: new Date() },
      update: { ...data, updatedAt: new Date() },
    });
  }

  async getTenantFlags(tenantId: string) {
    const [flags, overrides] = await Promise.all([
      this.listFeatureFlags(),
      (this.prisma as any).tenantFeatureOverride?.findMany({ where: { tenantId } }) ?? [],
    ]);
    const overrideMap = new Map((overrides as any[]).map((o: any) => [o.flagKey, o]));

    return flags.map((flag: any) => {
      const override = overrideMap.get(flag.key);
      const result = evaluateFeatureFlag(flag as FeatureFlag, tenantId, override);
      return { ...flag, tenantEnabled: result.enabled, tenantValue: result.value, source: result.source, override: override ?? null };
    });
  }

  async setTenantOverride(
    tenantId: string,
    flagKey: string,
    enabled: boolean,
    value: any,
    reason: string,
    setBy: string,
    expiresAt?: Date,
  ) {
    return (this.prisma as any).tenantFeatureOverride?.upsert({
      where: { tenantId_flagKey: { tenantId, flagKey } },
      create: { tenantId, flagKey, enabled, value, reason, setBy, setAt: new Date(), expiresAt },
      update: { enabled, value, reason, setBy, setAt: new Date(), expiresAt },
    });
  }

  async deleteTenantOverride(tenantId: string, flagKey: string) {
    return (this.prisma as any).tenantFeatureOverride?.delete({
      where: { tenantId_flagKey: { tenantId, flagKey } },
    }).catch(() => null);
  }

  private getBuiltinFlags(): FeatureFlag[] {
    return [
      { id: 'f1', key: 'ai_assistant', name: 'AI Assistant', category: 'beta', description: 'AI-powered HR assistant', defaultValue: false, globalEnabled: true, rolloutStrategy: 'allowlist', allowlistTenantIds: [], createdAt: new Date(), updatedAt: new Date() },
      { id: 'f2', key: 'analytics_lab', name: 'Analytics Lab', category: 'beta', description: 'Advanced analytics workbench', defaultValue: false, globalEnabled: true, rolloutStrategy: 'percentage', rolloutPercentage: 20, createdAt: new Date(), updatedAt: new Date() },
      { id: 'f3', key: 'expression_engine_v2', name: 'Expression Engine v2', category: 'experimental', description: 'Next-gen formula engine', defaultValue: false, globalEnabled: false, rolloutStrategy: 'none', createdAt: new Date(), updatedAt: new Date() },
      { id: 'f4', key: 'multi_entity_payroll', name: 'Multi-Entity Payroll', category: 'ga', description: 'Run payroll across legal entities', defaultValue: true, globalEnabled: true, rolloutStrategy: 'all', createdAt: new Date(), updatedAt: new Date() },
    ] as any[];
  }

  // ── DPDPA SLA Cron ─────────────────────────────────────────────────────────

  @Cron('0 9 * * *')   // 9 AM IST daily
  async checkDpdpaSla() {
    try {
      const overdue = await (this.prisma as any).dpdpaRequest?.findMany({
        where: {
          status: { in: ['pending', 'under_review'] },
          slaDeadline: { lt: new Date() },
        },
        include: { tenant: { select: { name: true } } },
      }) ?? [];

      for (const req of overdue) {
        this.logger.warn(`DPDPA SLA breach: request ${req.id} from tenant ${req.tenant?.name}`);
        this.events.emit('dpdpa.sla.breach', { requestId: req.id, tenantId: req.tenantId });
      }
    } catch (e) {
      this.logger.error('DPDPA SLA check failed', e);
    }
  }
}

// ─── Controller ────────────────────────────────────────────────────────────────

@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('security')
export class SecurityController {
  constructor(private readonly svc: SecurityService) {}

  // MFA
  @Get('mfa/policy')
  getMfaPolicy(@CurrentUser() u: JwtPayload) { return this.svc.getMfaPolicy(u.tid); }

  @Put('mfa/policy')
  @Roles('super-admin', 'hr-admin')
  updateMfaPolicy(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.updateMfaPolicy(u.tid, dto, u.sub); }

  // IP Allowlist
  @Get('ip-allowlist')
  @Roles('super-admin', 'hr-admin')
  getIpAllowlist(@CurrentUser() u: JwtPayload) { return this.svc.getIpAllowlist(u.tid); }

  @Post('ip-allowlist')
  @Roles('super-admin')
  @HttpCode(HttpStatus.CREATED)
  addIpRule(@Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.svc.addIpRule(u.tid, dto.cidr, dto.label, u.sub, dto.expiresAt ? new Date(dto.expiresAt) : undefined);
  }

  @Delete('ip-allowlist/:id')
  @Roles('super-admin')
  removeIpRule(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.svc.removeIpRule(u.tid, id); }

  // Sessions
  @Get('sessions')
  getSessions(@Headers('authorization') auth: string, @CurrentUser() u: JwtPayload) {
    const token = auth?.replace('Bearer ', '') ?? '';
    return this.svc.getSessionActivity(u.tid, u.sub, token);
  }

  @Delete('sessions/:id')
  @HttpCode(HttpStatus.OK)
  revokeSession(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.svc.revokeSession(id, u.sub, u.tid);
  }

  @Delete('sessions')
  @HttpCode(HttpStatus.OK)
  revokeAllSessions(@Headers('authorization') auth: string, @CurrentUser() u: JwtPayload) {
    const token = auth?.replace('Bearer ', '') ?? '';
    return this.svc.revokeAllSessions(u.sub, token);
  }

  @Get('login-history')
  getLoginHistory(@Query('limit') limit: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getLoginHistory(u.tid, u.sub, parseInt(limit ?? '50'));
  }

  // DPDPA
  @Get('dpdpa/requests')
  listDpdpaRequests(@Query('status') status: string, @CurrentUser() u: JwtPayload) {
    return this.svc.listDpdpaRequests(u.tid, status);
  }

  @Post('dpdpa/requests')
  @HttpCode(HttpStatus.CREATED)
  submitDpdpaRequest(@Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.svc.submitDpdpaRequest(u.tid, u.sub, dto.requestType, dto.reason);
  }

  @Post('dpdpa/requests/:id/approve')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.OK)
  approveDpdpaRequest(@Param('id') id: string, @Body('notes') notes: string, @CurrentUser() u: JwtPayload) {
    return this.svc.approveDpdpaRequest(id, u.tid, u.sub, notes);
  }

  @Post('dpdpa/requests/:id/reject')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.OK)
  rejectDpdpaRequest(@Param('id') id: string, @Body('reason') reason: string, @CurrentUser() u: JwtPayload) {
    return this.svc.rejectDpdpaRequest(id, u.tid, u.sub, reason);
  }

  @Patch('dpdpa/requests/:id/legal-hold')
  @Roles('super-admin')
  setLegalHold(@Param('id') id: string, @Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.svc.setLegalHold(id, u.tid, u.sub, dto.reason, dto.hold);
  }

  @Get('dpdpa/consent/:employeeId')
  @Roles('hr-admin', 'super-admin')
  getConsentHistory(@Param('employeeId') empId: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getConsentHistory(u.tid, empId);
  }

  @Get('dpdpa/download/:token')
  validateDownload(@Param('token') token: string, @CurrentUser() u: JwtPayload) {
    return this.svc.validateDownloadToken(token, u.tid);
  }

  // System Health (admin only)
  @Get('system-health')
  @Roles('super-admin')
  getSystemHealth() { return this.svc.getSystemHealth(); }

  // Feature Flags
  @Get('feature-flags')
  @Roles('super-admin')
  listFlags() { return this.svc.listFeatureFlags(); }

  @Get('feature-flags/tenant')
  @Roles('super-admin', 'hr-admin')
  getTenantFlags(@CurrentUser() u: JwtPayload) { return this.svc.getTenantFlags(u.tid); }

  @Put('feature-flags/:key')
  @Roles('super-admin')
  updateFlag(@Param('key') key: string, @Body() data: any, @CurrentUser() u: JwtPayload) {
    return this.svc.updateFlag(key, data, u.sub);
  }

  @Put('feature-flags/:key/tenant-override')
  @Roles('super-admin')
  setTenantOverride(@Param('key') key: string, @Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.svc.setTenantOverride(u.tid, key, dto.enabled, dto.value, dto.reason, u.sub, dto.expiresAt);
  }

  @Delete('feature-flags/:key/tenant-override')
  @Roles('super-admin')
  deleteTenantOverride(@Param('key') key: string, @CurrentUser() u: JwtPayload) {
    return this.svc.deleteTenantOverride(u.tid, key);
  }
}

// ─── Module ───────────────────────────────────────────────────────────────────

@Module({
  controllers: [SecurityController],
  providers: [
    SecurityService,
    { provide: PrismaClient, useExisting: PrismaClient },
  ],
  exports: [SecurityService],
})
export class SecurityComplianceModule {}
