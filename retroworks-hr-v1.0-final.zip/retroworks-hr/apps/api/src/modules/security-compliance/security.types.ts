/**
 * Security & Compliance Types
 * RetroWorks HR v1.0 — Enterprise Security Pack
 */

// ─── MFA ──────────────────────────────────────────────────────────────────────

export type MfaEnforcementLevel = 'none' | 'optional' | 'required';

export interface MfaPolicy {
  tenantId: string;
  enforceForRoles: string[];   // e.g. ['payroll-admin', 'super-admin', 'hr-admin']
  gracePeriodHours: number;    // time after creation before MFA is mandatory
  allowedMethods: ('totp' | 'backup_codes')[];
}

// MFA enforcement outcomes
export type MfaCheckResult =
  | { required: false }
  | { required: true; enrolled: true }
  | { required: true; enrolled: false; gracePeriodRemaining?: number };

// ─── IP ALLOWLIST ─────────────────────────────────────────────────────────────

export interface IpAllowlistEntry {
  id: string;
  tenantId: string;
  cidr: string;          // e.g. "203.0.113.0/24" or "198.51.100.42/32"
  label: string;
  addedBy: string;
  createdAt: Date;
  expiresAt?: Date;
}

export interface IpCheckResult {
  allowed: boolean;
  matchedRule?: IpAllowlistEntry;
  reason: string;
}

// ─── SESSIONS ─────────────────────────────────────────────────────────────────

export interface SessionActivity {
  id: string;
  userId: string;
  tenantId: string;
  ip: string;
  userAgent: string;
  deviceFingerprint?: string;
  deviceName?: string;        // parsed from UA
  os?: string;
  browser?: string;
  country?: string;
  city?: string;
  isCurrentSession: boolean;
  isActive: boolean;
  revokedAt?: Date;
  revokedBy?: string;
  lastActiveAt: Date;
  createdAt: Date;
  expiresAt: Date;
}

export interface LoginHistoryEntry {
  id: string;
  userId: string;
  tenantId: string;
  ip: string;
  userAgent: string;
  deviceName?: string;
  success: boolean;
  failureReason?: string;  // 'invalid_password' | 'account_locked' | 'mfa_failed' | 'ip_blocked'
  mfaUsed: boolean;
  createdAt: Date;
}

// ─── DPDPA (Digital Personal Data Protection Act 2023) ──────────────────────

export type DpdpaRequestType = 'export' | 'deletion' | 'correction';
export type DpdpaRequestStatus =
  | 'pending'
  | 'under_review'
  | 'approved'
  | 'rejected'
  | 'completed'
  | 'expired';

export interface DpdpaRequest {
  id: string;
  tenantId: string;
  requesterId: string;         // employee who made the request
  requesterName?: string;
  requestType: DpdpaRequestType;
  status: DpdpaRequestStatus;
  reason?: string;
  adminNotes?: string;
  reviewedBy?: string;
  reviewedAt?: Date;
  // Secure download (for export)
  downloadToken?: string;
  downloadUrl?: string;
  downloadExpiresAt?: Date;
  downloadCount: number;
  maxDownloads: number;        // default 3
  // Legal hold (blocks deletion)
  isLegalHold: boolean;
  legalHoldReason?: string;
  legalHoldBy?: string;
  legalHoldAt?: Date;
  createdAt: Date;
  completedAt?: Date;
}

export interface ConsentRecord {
  id: string;
  tenantId: string;
  employeeId: string;
  consentType: string;         // 'payroll_processing' | 'data_sharing' | 'marketing' | 'background_check'
  consentVersion: string;
  givenAt: Date;
  ipAddress?: string;
  withdrawnAt?: Date;
  withdrawnReason?: string;
  isActive: boolean;
}

// DPDPA SLA: 30 days to respond to data requests under Indian law
export const DPDPA_RESPONSE_SLA_DAYS = 30;
export const DPDPA_DOWNLOAD_EXPIRY_HOURS = 48;
export const DPDPA_MAX_DOWNLOADS = 3;

// ─── SYSTEM HEALTH ────────────────────────────────────────────────────────────

export type HealthStatus = 'healthy' | 'degraded' | 'down';

export interface ServiceHealth {
  name: string;
  status: HealthStatus;
  latencyMs?: number;
  message?: string;
  lastChecked: Date;
}

export interface QueueHealth {
  name: string;
  waiting: number;
  active: number;
  completed: number;
  failed: number;
  delayed: number;
  isPaused: boolean;
}

export interface CronExecutionLog {
  jobName: string;
  lastRun?: Date;
  lastStatus: 'success' | 'failure' | 'running' | 'never';
  lastDurationMs?: number;
  nextRun?: Date;
  errorMessage?: string;
  runCount24h: number;
}

export interface AiUsageStats {
  tenantId: string;
  period: string;           // 'YYYY-MM'
  totalRequests: number;
  totalTokensIn: number;
  totalTokensOut: number;
  estimatedCostUsd: number;
  byFeature: Record<string, { requests: number; tokensIn: number; tokensOut: number }>;
}

export interface SystemHealthSnapshot {
  timestamp: Date;
  overall: HealthStatus;
  services: {
    database: ServiceHealth;
    redis: ServiceHealth;
    storage: ServiceHealth;
  };
  queues: QueueHealth[];
  crons: CronExecutionLog[];
  lastBackup?: { at: Date; sizeGb: number; status: 'success' | 'failure'; location: string };
  failedJobs24h: number;
  aiUsage?: AiUsageStats;
  appVersion: string;
  nodeVersion: string;
  uptimeSeconds: number;
}

// ─── FEATURE FLAGS ────────────────────────────────────────────────────────────

export type FeatureFlagValue = boolean | number | string;
export type RolloutStrategy = 'all' | 'none' | 'percentage' | 'allowlist' | 'denylist';

export interface FeatureFlag {
  id: string;
  key: string;
  name: string;
  description?: string;
  category: 'beta' | 'experimental' | 'ga' | 'deprecated';
  defaultValue: FeatureFlagValue;
  // Global override
  globalEnabled: boolean;
  globalValue?: FeatureFlagValue;
  // Rollout config
  rolloutStrategy: RolloutStrategy;
  rolloutPercentage?: number;      // 0–100 for 'percentage' strategy
  allowlistTenantIds?: string[];
  denylistTenantIds?: string[];
  // Metadata
  version?: string;                // version it was introduced in
  deprecatedInVersion?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface TenantFeatureOverride {
  id: string;
  tenantId: string;
  flagKey: string;
  enabled: boolean;
  value?: FeatureFlagValue;
  reason?: string;
  setBy: string;
  setAt: Date;
  expiresAt?: Date;
}

// ─── PURE LOGIC FUNCTIONS ─────────────────────────────────────────────────────

/** Check if an IP string matches a CIDR block */
export function ipMatchesCidr(ip: string, cidr: string): boolean {
  try {
    const [range, bits] = cidr.split('/');
    if (!range || bits === undefined) return ip === cidr;
    const maskBits = parseInt(bits, 10);
    if (isNaN(maskBits)) return false;

    const ipParts = ip.split('.').map(Number);
    const rangeParts = range.split('.').map(Number);
    if (ipParts.length !== 4 || rangeParts.length !== 4) return false;

    const ipNum = ipParts.reduce((acc, oct) => (acc << 8) + oct, 0) >>> 0;
    const rangeNum = rangeParts.reduce((acc, oct) => (acc << 8) + oct, 0) >>> 0;
    const mask = maskBits === 0 ? 0 : (~0 << (32 - maskBits)) >>> 0;

    return (ipNum & mask) === (rangeNum & mask);
  } catch { return false; }
}

/** Check if any CIDR in the allowlist permits the IP */
export function checkIpAllowlist(ip: string, rules: IpAllowlistEntry[]): IpCheckResult {
  if (rules.length === 0) {
    return { allowed: true, reason: 'No IP restrictions configured' };
  }

  const now = new Date();
  const active = rules.filter(r => !r.expiresAt || r.expiresAt > now);

  // No active rules → treat as unrestricted (all rules expired)
  if (active.length === 0) {
    return { allowed: true, reason: 'No active IP restrictions' };
  }

  for (const rule of active) {
    if (ipMatchesCidr(ip, rule.cidr)) {
      return { allowed: true, matchedRule: rule, reason: `Matched rule: ${rule.label} (${rule.cidr})` };
    }
  }
  return { allowed: false, reason: `IP ${ip} not in allowlist (${active.length} active rules)` };
}

/** Determine if MFA is required for a given user's roles */
export function checkMfaRequirement(
  userRoles: string[],
  policy: MfaPolicy,
  mfaEnabled: boolean,
  accountCreatedAt: Date,
): MfaCheckResult {
  const mustEnforce = userRoles.some(r => policy.enforceForRoles.includes(r));
  if (!mustEnforce) return { required: false };

  if (mfaEnabled) return { required: true, enrolled: true };

  // Check grace period
  const hoursOld = (Date.now() - accountCreatedAt.getTime()) / 3_600_000;
  if (hoursOld < policy.gracePeriodHours) {
    return {
      required: true,
      enrolled: false,
      gracePeriodRemaining: Math.ceil(policy.gracePeriodHours - hoursOld),
    };
  }
  return { required: true, enrolled: false };
}

/** Evaluate a feature flag for a specific tenant */
export function evaluateFeatureFlag(
  flag: FeatureFlag,
  tenantId: string,
  override?: TenantFeatureOverride,
): { enabled: boolean; value: FeatureFlagValue; source: string } {
  // 1. Tenant-level override wins
  if (override) {
    if (override.expiresAt && override.expiresAt < new Date()) {
      // Expired — fall through to global
    } else {
      return { enabled: override.enabled, value: override.value ?? flag.defaultValue, source: 'tenant_override' };
    }
  }

  // 2. Global kill switch
  if (!flag.globalEnabled) {
    return { enabled: false, value: flag.defaultValue, source: 'global_disabled' };
  }

  // 3. Rollout strategy
  switch (flag.rolloutStrategy) {
    case 'all':
      return { enabled: true, value: flag.globalValue ?? flag.defaultValue, source: 'global_all' };
    case 'none':
      return { enabled: false, value: flag.defaultValue, source: 'global_none' };
    case 'allowlist':
      const inAllow = flag.allowlistTenantIds?.includes(tenantId) ?? false;
      return { enabled: inAllow, value: inAllow ? (flag.globalValue ?? flag.defaultValue) : flag.defaultValue, source: 'allowlist' };
    case 'denylist':
      const inDeny = flag.denylistTenantIds?.includes(tenantId) ?? false;
      return { enabled: !inDeny, value: !inDeny ? (flag.globalValue ?? flag.defaultValue) : flag.defaultValue, source: 'denylist' };
    case 'percentage': {
      // Deterministic: hash tenantId for consistent bucketing
      let hash = 0;
      for (let i = 0; i < tenantId.length; i++) {
        hash = ((hash << 5) - hash + tenantId.charCodeAt(i)) | 0;
      }
      const bucket = Math.abs(hash) % 100;
      const pct = flag.rolloutPercentage ?? 0;
      const inRollout = bucket < pct;
      return { enabled: inRollout, value: inRollout ? (flag.globalValue ?? flag.defaultValue) : flag.defaultValue, source: `rollout_${pct}pct` };
    }
    default:
      return { enabled: false, value: flag.defaultValue, source: 'fallback' };
  }
}

/** Parse user-agent string into device info */
export function parseUserAgent(ua: string): { browser: string; os: string; deviceName: string } {
  const ua_lower = ua.toLowerCase();

  const browser =
    ua_lower.includes('chrome') && !ua_lower.includes('edg') ? 'Chrome' :
    ua_lower.includes('firefox') ? 'Firefox' :
    ua_lower.includes('safari') && !ua_lower.includes('chrome') ? 'Safari' :
    ua_lower.includes('edg') ? 'Edge' :
    ua_lower.includes('opera') ? 'Opera' : 'Unknown';

  const os =
    ua_lower.includes('windows') ? 'Windows' :
    ua_lower.includes('iphone') ? 'iOS' :
    ua_lower.includes('mac os') ? 'macOS' :
    ua_lower.includes('android') ? 'Android' :
    ua_lower.includes('linux') ? 'Linux' : 'Unknown';

  const isMobile = ua_lower.includes('mobile') || ua_lower.includes('android') || ua_lower.includes('iphone');
  const deviceName = isMobile ? `Mobile · ${os}` : `Desktop · ${os}`;

  return { browser, os, deviceName };
}

/** Compute DPDPA SLA deadline */
export function computeDpdpaSlaDeadline(requestedAt: Date): Date {
  const d = new Date(requestedAt);
  d.setDate(d.getDate() + DPDPA_RESPONSE_SLA_DAYS);
  return d;
}

/** Check if DPDPA request is overdue */
export function isDpdpaOverdue(request: DpdpaRequest): boolean {
  if (['completed', 'rejected'].includes(request.status)) return false;
  return computeDpdpaSlaDeadline(request.createdAt) < new Date();
}

/** Generate a secure random download token */
export function generateDownloadToken(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let token = '';
  for (let i = 0; i < 48; i++) {
    token += chars[Math.floor(Math.random() * chars.length)];
  }
  return token;
}

/** Determine overall system health from service statuses */
export function computeOverallHealth(services: ServiceHealth[]): HealthStatus {
  if (services.some(s => s.status === 'down')) return 'down';
  if (services.some(s => s.status === 'degraded')) return 'degraded';
  return 'healthy';
}

// Well-known CIDR ranges (private/loopback — always allowed regardless of allowlist)
export const ALWAYS_ALLOWED_CIDRS = [
  '127.0.0.0/8',    // loopback
  '10.0.0.0/8',     // private A
  '172.16.0.0/12',  // private B
  '192.168.0.0/16', // private C
  '::1/128',        // IPv6 loopback
];

/** Check if IP is in a private/loopback range */
export function isPrivateIp(ip: string): boolean {
  return ALWAYS_ALLOWED_CIDRS.some(cidr => ipMatchesCidr(ip, cidr));
}
