import {
  Controller, Post, Get, Body, Query, Param, UseGuards, UseInterceptors, UploadedFile,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiConsumes, ApiBody } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { DataOpsService } from './dataops.service';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

@ApiTags('admin')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('hr-admin', 'super-admin')
@Controller('dataops')
export class DataOpsController {
  constructor(private readonly dataopsService: DataOpsService) {}

  @Get('presets/:entity')
  @ApiOperation({ summary: 'Get column mapping presets for an entity' })
  getPresets(@Param('entity') entity: string) {
    return this.dataopsService.getColumnMappingPresets(entity);
  }

  @Post('preview')
  @ApiOperation({ summary: 'Preview and validate CSV import data' })
  preview(
    @Body() body: {
      entity: string;
      rows: Record<string, string>[];
      columnMapping: Record<string, string>;
      dedupeField?: string;
    },
    @CurrentUser() user: JwtPayload,
  ) {
    return this.dataopsService.previewImport(
      user.tid, body.entity, body.rows, body.columnMapping, body.dedupeField,
    );
  }

  @Post('import')
  @ApiOperation({ summary: 'Execute validated import job' })
  executeImport(
    @Body() body: { entity: string; rows: Record<string, string>[] },
    @CurrentUser() user: JwtPayload,
  ) {
    return this.dataopsService.executeImport(user.tid, body.entity, body.rows, user.sub);
  }

  @Post('bulk-edit')
  @ApiOperation({ summary: 'Apply bulk grid edits to multiple records' })
  bulkEdit(
    @Body() body: {
      entity: string;
      updates: Array<{ id: string; changes: Record<string, unknown> }>;
    },
    @CurrentUser() user: JwtPayload,
  ) {
    return this.dataopsService.bulkEdit(user.tid, body.entity, body.updates, user.sub);
  }

  @Post('purge')
  @ApiOperation({ summary: 'Request secure purge (requires approval)' })
  requestPurge(
    @Body() body: { entity: string; ids: string[]; reason: string },
    @CurrentUser() user: JwtPayload,
  ) {
    return this.dataopsService.requestPurge(
      user.tid, body.entity, body.ids, user.sub, body.reason,
    );
  }
}

@Module({
  controllers: [DataOpsController],
  providers: [DataOpsService],
  exports: [DataOpsService],
})
export class DataOpsModule {}
