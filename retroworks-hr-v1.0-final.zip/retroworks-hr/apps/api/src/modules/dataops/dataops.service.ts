import { Injectable, BadRequestException, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';

export interface ImportPreviewRow {
  row: number;
  data: Record<string, string>;
  errors: string[];
  warnings: string[];
  isDuplicate: boolean;
  existingId?: string;
}

export interface ImportPreviewResult {
  total: number;
  valid: number;
  invalid: number;
  duplicates: number;
  rows: ImportPreviewRow[];
  columnMapping: Record<string, string>;
}

export interface ColumnMappingPreset {
  name: string;
  entity: string;
  mapping: Record<string, string>; // csv_column → db_field
}

const EMPLOYEE_REQUIRED_FIELDS = ['employeeCode', 'firstName', 'lastName', 'workEmail', 'dateOfJoining'];
const EMPLOYEE_FIELD_VALIDATORS: Record<string, (v: string) => string | null> = {
  workEmail: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? null : 'Invalid email format',
  dateOfJoining: (v) => isNaN(Date.parse(v)) ? 'Invalid date format (use YYYY-MM-DD)' : null,
  dateOfBirth: (v) => isNaN(Date.parse(v)) ? 'Invalid date format' : null,
  employmentType: (v) => ['full-time', 'part-time', 'contract', 'intern', 'consultant'].includes(v) ? null : 'Invalid employment type',
  gender: (v) => ['male', 'female', 'non-binary', 'prefer-not-to-say'].includes(v) ? null : 'Invalid gender value',
  noticePeriodDays: (v) => isNaN(Number(v)) ? 'Must be a number' : null,
};

@Injectable()
export class DataOpsService {
  private readonly logger = new Logger(DataOpsService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ─────────────────────────────────────────────
  // PREVIEW / VALIDATION
  // ─────────────────────────────────────────────

  async previewImport(
    tenantId: string,
    entity: string,
    csvData: Record<string, string>[],
    columnMapping: Record<string, string>,
    dedupeField: string = 'employeeCode',
  ): Promise<ImportPreviewResult> {
    const rows: ImportPreviewRow[] = [];
    let valid = 0;
    let invalid = 0;
    let duplicates = 0;

    // Load existing records for dedupe check
    const existingCodes = await this.getExistingCodes(tenantId, entity, dedupeField);

    for (let i = 0; i < csvData.length; i++) {
      const rawRow = csvData[i];
      if (!rawRow) continue;

      // Apply column mapping
      const mapped: Record<string, string> = {};
      for (const [csvCol, dbField] of Object.entries(columnMapping)) {
        if (rawRow[csvCol] !== undefined) {
          mapped[dbField] = rawRow[csvCol] ?? '';
        }
      }

      const errors: string[] = [];
      const warnings: string[] = [];

      // Required field validation
      for (const required of EMPLOYEE_REQUIRED_FIELDS) {
        if (!mapped[required]?.trim()) {
          errors.push(`Missing required field: ${required}`);
        }
      }

      // Field validators
      for (const [field, validator] of Object.entries(EMPLOYEE_FIELD_VALIDATORS)) {
        if (mapped[field]) {
          const error = validator(mapped[field] ?? '');
          if (error) errors.push(`${field}: ${error}`);
        }
      }

      // Dedupe check
      const isDuplicate = existingCodes.has(mapped[dedupeField] ?? '');
      if (isDuplicate) {
        warnings.push(`${dedupeField} "${mapped[dedupeField]}" already exists — will update`);
        duplicates++;
      }

      if (errors.length === 0) valid++;
      else invalid++;

      rows.push({
        row: i + 2, // 1-indexed, +1 for header
        data: mapped,
        errors,
        warnings,
        isDuplicate,
        existingId: isDuplicate ? existingCodes.get(mapped[dedupeField] ?? '') : undefined,
      });
    }

    return {
      total: csvData.length,
      valid,
      invalid,
      duplicates,
      rows,
      columnMapping,
    };
  }

  // ─────────────────────────────────────────────
  // EXECUTE IMPORT
  // ─────────────────────────────────────────────

  async executeImport(
    tenantId: string,
    entity: string,
    validRows: Record<string, string>[],
    importedBy: string,
  ): Promise<{ jobId: string; status: 'queued' }> {
    // In Phase 1: direct execution. Phase 4: BullMQ queue
    const jobId = `import-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

    // Emit to queue (will be picked up by job processor)
    this.events.emit('dataops.import.queued', {
      tenantId, entity, rows: validRows, importedBy, jobId,
    });

    this.logger.log(`Import job ${jobId} queued: ${validRows.length} rows for ${entity}`);
    return { jobId, status: 'queued' };
  }

  // ─────────────────────────────────────────────
  // COLUMN MAPPING PRESETS
  // ─────────────────────────────────────────────

  getColumnMappingPresets(entity: string): ColumnMappingPreset[] {
    const presets: Record<string, ColumnMappingPreset[]> = {
      employee: [
        {
          name: 'Standard Template',
          entity: 'employee',
          mapping: {
            'Employee ID': 'employeeCode',
            'First Name': 'firstName',
            'Last Name': 'lastName',
            'Work Email': 'workEmail',
            'Personal Email': 'email',
            'Date of Joining': 'dateOfJoining',
            'Department': 'departmentId',
            'Designation': 'designationId',
            'Location': 'locationId',
            'Employment Type': 'employmentType',
            'Manager ID': 'managerId',
            'Phone': 'phone',
            'Gender': 'gender',
            'Date of Birth': 'dateOfBirth',
            'Notice Period (Days)': 'noticePeriodDays',
            'PAN': 'panNumber',
            'UAN': 'uanNumber',
            'Bank Account': 'bankAccountNumber',
            'IFSC': 'ifscCode',
            'Bank Name': 'bankName',
          },
        },
        {
          name: 'Minimal (Required Only)',
          entity: 'employee',
          mapping: {
            'Emp Code': 'employeeCode',
            'First Name': 'firstName',
            'Last Name': 'lastName',
            'Email': 'workEmail',
            'Joining Date': 'dateOfJoining',
          },
        },
      ],
    };

    return presets[entity] ?? [];
  }

  // ─────────────────────────────────────────────
  // BULK EDIT (grid updates)
  // ─────────────────────────────────────────────

  async bulkEdit(
    tenantId: string,
    entity: string,
    updates: Array<{ id: string; changes: Record<string, unknown> }>,
    updatedBy: string,
  ): Promise<{ success: number; failed: number; errors: Array<{ id: string; message: string }> }> {
    let success = 0;
    let failed = 0;
    const errors: Array<{ id: string; message: string }> = [];

    // Transaction for all-or-nothing semantics
    try {
      await this.prisma.$transaction(async (tx) => {
        for (const update of updates) {
          try {
            if (entity === 'employee') {
              await tx.employee.update({
                where: { id: update.id },
                data: { ...update.changes, updatedBy, updatedAt: new Date() },
              });
            }
            success++;
          } catch (e) {
            failed++;
            errors.push({ id: update.id, message: e instanceof Error ? e.message : 'Update failed' });
          }
        }
      });
    } catch {
      this.logger.error('Bulk edit transaction failed');
    }

    return { success, failed, errors };
  }

  // ─────────────────────────────────────────────
  // SECURE PURGE (requires 2-person approval)
  // ─────────────────────────────────────────────

  async requestPurge(
    tenantId: string,
    entity: string,
    ids: string[],
    requestedBy: string,
    reason: string,
  ) {
    // Creates a DSR (Data Subject Request) record requiring approval
    return this.prisma.dataSubjectRequest.create({
      data: {
        tenantId,
        requestType: 'delete',
        email: requestedBy,
        status: 'pending',
        notes: JSON.stringify({ entity, ids, reason }),
      },
    });
  }

  // ─────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────

  private async getExistingCodes(
    tenantId: string,
    entity: string,
    field: string,
  ): Promise<Map<string, string>> {
    if (entity === 'employee') {
      const employees = await this.prisma.employee.findMany({
        where: { tenantId, deletedAt: null },
        select: { id: true, employeeCode: true },
      });
      return new Map(employees.map(e => [e.employeeCode, e.id]));
    }
    return new Map();
  }
}
