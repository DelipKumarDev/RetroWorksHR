/**
 * Engagement + Performance + Experience — NestJS Service, Controller, Module
 */

import {
  Injectable, Logger, NotFoundException, ForbiddenException, BadRequestException,
  Module, Controller, Get, Post, Put, Patch, Delete,
  Body, Param, Query, UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { PrismaClient } from '@prisma/client';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

import {
  buildTree, layoutTree, calculateENPS, computeWeightedRating,
  get9BoxCell,
  type OrgChartFilter, type PulseSurvey, type SurveyResponse,
  type PerformanceCycle, type PerformanceGoal, type PerformanceReview,
  type LeaveBalanceSummary, type TaxProjection, type DashboardSearchResult,
} from './engagement.types';

// ─── Engagement Service ────────────────────────────────────────────────────────

@Injectable()
export class EngagementService {
  private readonly logger = new Logger(EngagementService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ── ORG CHART ──────────────────────────────────────────────────────────────

  async getOrgChart(tenantId: string, filter: OrgChartFilter = {}) {
    const where: any = {
      tenantId,
      status: 'active',
      deletedAt: null,
    };
    if (filter.departmentId) where.departmentId = filter.departmentId;
    if (filter.entityId) where.legalEntityId = filter.entityId;

    const employees = await (this.prisma as any).employee.findMany({
      where,
      select: {
        id: true,
        employeeCode: true,
        firstName: true,
        lastName: true,
        managerId: true,
        avatarUrl: true,
        status: true,
        legalEntityId: true,
        department: { select: { id: true, name: true } },
        designation: { select: { name: true } },
      },
      take: 500, // Safety cap
    });

    const nodes = employees.map((e: any) => ({
      id: e.id,
      employeeCode: e.employeeCode,
      name: `${e.firstName} ${e.lastName}`,
      designation: e.designation?.name,
      department: e.department?.name,
      departmentId: e.departmentId,
      entityId: e.legalEntityId,
      managerId: e.managerId,
      avatarUrl: e.avatarUrl,
      status: e.status,
    }));

    const tree = buildTree(nodes, filter.rootNodeId);
    const laid = tree.map(root => layoutTree(root as any));

    // Departments for filter dropdown
    const departments = await (this.prisma as any).department.findMany({
      where: { tenantId, deletedAt: null },
      select: { id: true, name: true },
      orderBy: { name: 'asc' },
    });

    // Entities for multi-entity filter
    const entities = await (this.prisma as any).legalEntity?.findMany({
      where: { tenantId, isActive: true },
      select: { id: true, name: true },
    }).catch(() => []) ?? [];

    return { tree: laid, nodes, departments, entities, totalNodes: nodes.length };
  }

  // ── PULSE SURVEY ───────────────────────────────────────────────────────────

  async createSurvey(tenantId: string, dto: Partial<PulseSurvey>, createdBy: string) {
    if ((dto.questions?.length ?? 0) > 5) {
      throw new BadRequestException('Pulse surveys are limited to 5 questions');
    }
    const survey = await (this.prisma as any).pulseSurvey.create({
      data: {
        tenantId,
        title: dto.title ?? 'Pulse Survey',
        description: dto.description,
        questions: dto.questions as any,
        isAnonymous: dto.isAnonymous ?? false,
        targetAudience: dto.targetAudience ?? 'all',
        targetIds: dto.targetIds ?? [],
        status: 'draft',
        createdBy,
        opensAt: dto.opensAt,
        closesAt: dto.closesAt,
      },
    });
    return survey;
  }

  async activateSurvey(tenantId: string, surveyId: string) {
    const survey = await (this.prisma as any).pulseSurvey.findFirst({
      where: { id: surveyId, tenantId },
    });
    if (!survey) throw new NotFoundException('Survey not found');
    return (this.prisma as any).pulseSurvey.update({
      where: { id: surveyId },
      data: { status: 'active', opensAt: new Date() },
    });
  }

  async listSurveys(tenantId: string, status?: string) {
    return (this.prisma as any).pulseSurvey.findMany({
      where: { tenantId, ...(status ? { status } : {}) },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getSurveyForEmployee(surveyId: string, tenantId: string, employeeId: string) {
    const survey = await (this.prisma as any).pulseSurvey.findFirst({
      where: { id: surveyId, tenantId, status: 'active' },
    });
    if (!survey) throw new NotFoundException('Survey not found or not active');

    // Check if already responded
    const existing = await (this.prisma as any).surveyResponse.findFirst({
      where: { surveyId, respondentId: survey.isAnonymous ? undefined : employeeId },
    });

    return { survey, hasResponded: !!existing };
  }

  async submitSurveyResponse(
    surveyId: string,
    tenantId: string,
    employeeId: string,
    answers: Array<{ questionId: string; value: string | number }>,
  ) {
    const survey = await (this.prisma as any).pulseSurvey.findFirst({
      where: { id: surveyId, tenantId, status: 'active' },
    });
    if (!survey) throw new NotFoundException('Survey not active');

    // Prevent double submission (for non-anonymous)
    if (!survey.isAnonymous) {
      const existing = await (this.prisma as any).surveyResponse.findFirst({
        where: { surveyId, respondentId: employeeId },
      });
      if (existing) throw new BadRequestException('Already responded to this survey');
    }

    const response = await (this.prisma as any).surveyResponse.create({
      data: {
        surveyId,
        tenantId,
        respondentId: survey.isAnonymous ? null : employeeId,
        answers: answers as any,
        submittedAt: new Date(),
      },
    });

    this.events.emit('survey.response.submitted', { tenantId, surveyId, responseId: response.id });
    return { success: true, responseId: response.id };
  }

  async getSurveyResults(surveyId: string, tenantId: string) {
    const [survey, responses] = await Promise.all([
      (this.prisma as any).pulseSurvey.findFirst({ where: { id: surveyId, tenantId } }),
      (this.prisma as any).surveyResponse.findMany({ where: { surveyId } }),
    ]);
    if (!survey) throw new NotFoundException('Survey not found');

    const questions = survey.questions as any[];
    const questionResults = questions.map((q: any) => {
      const answers = responses
        .flatMap((r: any) => (r.answers as any[]))
        .filter((a: any) => a.questionId === q.id)
        .map((a: any) => a.value);

      if (q.type === 'nps' || q.type === 'scale') {
        const nums = answers.map(Number).filter(n => !isNaN(n));
        const average = nums.length > 0 ? Math.round((nums.reduce((a, b) => a + b, 0) / nums.length) * 10) / 10 : 0;
        const distribution: Record<string, number> = {};
        nums.forEach(n => { distribution[String(n)] = (distribution[String(n)] ?? 0) + 1; });
        return { questionId: q.id, questionText: q.text, type: q.type, average, distribution };
      }
      if (q.type === 'text') {
        return { questionId: q.id, questionText: q.text, type: q.type, textResponses: answers.map(String) };
      }
      const distribution: Record<string, number> = {};
      answers.forEach(a => { distribution[String(a)] = (distribution[String(a)] ?? 0) + 1; });
      return { questionId: q.id, questionText: q.text, type: q.type, distribution };
    });

    // eNPS from NPS question
    const npsQuestion = questions.find((q: any) => q.type === 'nps');
    let eNPS;
    if (npsQuestion) {
      const npsAnswers = responses
        .flatMap((r: any) => (r.answers as any[]))
        .filter((a: any) => a.questionId === npsQuestion.id)
        .map((a: any) => Number(a.value))
        .filter(n => !isNaN(n));
      eNPS = calculateENPS(npsAnswers);
    }

    // Count total eligible
    const totalEligible = await (this.prisma as any).employee.count({
      where: { tenantId, status: 'active', deletedAt: null },
    });

    return {
      surveyId,
      totalResponses: responses.length,
      responseRate: totalEligible > 0 ? Math.round((responses.length / totalEligible) * 100) : 0,
      questionResults,
      eNPS,
    };
  }

  async getENPSTrend(tenantId: string, months = 6) {
    const surveys = await (this.prisma as any).pulseSurvey.findMany({
      where: {
        tenantId, status: 'closed',
        closesAt: { gte: new Date(Date.now() - months * 30 * 86400_000) },
      },
      orderBy: { closesAt: 'asc' },
    });

    const trend = await Promise.all(surveys.map(async (s: any) => {
      const results = await this.getSurveyResults(s.id, tenantId);
      const period = new Date(s.closesAt).toISOString().slice(0, 7);
      return {
        period,
        score: results.eNPS?.score ?? 0,
        responses: results.totalResponses,
      };
    }));

    return trend;
  }

  // ── PERFORMANCE CYCLE ──────────────────────────────────────────────────────

  async createCycle(tenantId: string, dto: Partial<PerformanceCycle>, createdBy: string) {
    return (this.prisma as any).performanceCycle.create({
      data: {
        tenantId,
        name: dto.name ?? 'Performance Review',
        period: dto.period ?? 'H1 2024',
        status: 'planning',
        goalSettingDeadline: dto.goalSettingDeadline ?? new Date(Date.now() + 30 * 86400_000),
        selfReviewDeadline: dto.selfReviewDeadline ?? new Date(Date.now() + 60 * 86400_000),
        managerReviewDeadline: dto.managerReviewDeadline ?? new Date(Date.now() + 90 * 86400_000),
        calibrationDate: dto.calibrationDate,
        createdBy,
      },
    });
  }

  async listCycles(tenantId: string) {
    return (this.prisma as any).performanceCycle.findMany({
      where: { tenantId },
      orderBy: { createdAt: 'desc' },
    });
  }

  async getMyReview(tenantId: string, employeeId: string, cycleId: string) {
    let review = await (this.prisma as any).performanceReview.findFirst({
      where: { tenantId, employeeId, cycleId },
      include: { goals: true },
    });

    if (!review) {
      // Auto-create
      review = await (this.prisma as any).performanceReview.create({
        data: { tenantId, employeeId, cycleId, reviewStatus: 'pending' },
        include: { goals: true },
      });
    }
    return review;
  }

  async upsertGoal(tenantId: string, employeeId: string, cycleId: string, goal: Partial<PerformanceGoal>) {
    if (goal.id) {
      return (this.prisma as any).performanceGoal.update({
        where: { id: goal.id },
        data: {
          title: goal.title,
          description: goal.description,
          metric: goal.metric,
          weight: goal.weight,
          dueDate: goal.dueDate,
          progress: goal.progress,
        },
      });
    }
    // Ensure weight totals don't exceed 100
    const existing = await (this.prisma as any).performanceGoal.aggregate({
      where: { tenantId, employeeId, cycleId },
      _sum: { weight: true },
    });
    const currentTotal = existing._sum?.weight ?? 0;
    if (currentTotal + (goal.weight ?? 0) > 100) {
      throw new BadRequestException(`Goal weights would exceed 100% (current: ${currentTotal}%)`);
    }

    return (this.prisma as any).performanceGoal.create({
      data: {
        tenantId, employeeId, cycleId,
        title: goal.title ?? '',
        description: goal.description,
        metric: goal.metric,
        weight: goal.weight ?? 20,
        status: 'active',
        progress: 0,
        dueDate: goal.dueDate,
      },
    });
  }

  async submitSelfReview(
    tenantId: string,
    employeeId: string,
    cycleId: string,
    data: { overallRating: number; strengths: string; improvements: string; goalRatings: Array<{ goalId: string; rating: number }> },
  ) {
    // Update goal self ratings
    for (const gr of data.goalRatings) {
      await (this.prisma as any).performanceGoal.updateMany({
        where: { id: gr.goalId, employeeId },
        data: { selfRating: gr.rating },
      });
    }

    return (this.prisma as any).performanceReview.upsert({
      where: { employeeId_cycleId: { employeeId, cycleId } },
      create: {
        tenantId, employeeId, cycleId,
        selfOverallRating: data.overallRating,
        selfStrengths: data.strengths,
        selfImprovements: data.improvements,
        reviewStatus: 'self_review',
        selfSubmittedAt: new Date(),
      },
      update: {
        selfOverallRating: data.overallRating,
        selfStrengths: data.strengths,
        selfImprovements: data.improvements,
        reviewStatus: 'self_review',
        selfSubmittedAt: new Date(),
      },
    });
  }

  async submitManagerReview(
    tenantId: string,
    managerId: string,
    employeeId: string,
    cycleId: string,
    data: {
      overallRating: number;
      strengths: string;
      development: string;
      promotionRecommendation: string;
      performanceAxis: 1 | 2 | 3;
      potentialAxis: 1 | 2 | 3;
      goalRatings: Array<{ goalId: string; rating: number }>;
    },
  ) {
    // Verify manager relationship
    const employee = await (this.prisma as any).employee.findFirst({
      where: { id: employeeId, managerId, tenantId },
    });
    if (!employee) throw new ForbiddenException('Not authorized to review this employee');

    for (const gr of data.goalRatings) {
      await (this.prisma as any).performanceGoal.updateMany({
        where: { id: gr.goalId, employeeId },
        data: { managerRating: gr.rating },
      });
    }

    const nineBoxLabel = get9BoxCell(data.performanceAxis, data.potentialAxis);

    return (this.prisma as any).performanceReview.upsert({
      where: { employeeId_cycleId: { employeeId, cycleId } },
      create: {
        tenantId, employeeId, cycleId,
        managerOverallRating: data.overallRating,
        managerStrengths: data.strengths,
        managerDevelopment: data.development,
        promotionRecommendation: data.promotionRecommendation,
        performanceAxis: data.performanceAxis,
        potentialAxis: data.potentialAxis,
        nineBoxLabel,
        reviewStatus: 'manager_review',
        managerSubmittedAt: new Date(),
      },
      update: {
        managerOverallRating: data.overallRating,
        managerStrengths: data.strengths,
        managerDevelopment: data.development,
        promotionRecommendation: data.promotionRecommendation,
        performanceAxis: data.performanceAxis,
        potentialAxis: data.potentialAxis,
        nineBoxLabel,
        reviewStatus: 'manager_review',
        managerSubmittedAt: new Date(),
      },
    });
  }

  async getCalibrationView(tenantId: string, cycleId: string) {
    const reviews = await (this.prisma as any).performanceReview.findMany({
      where: { tenantId, cycleId, reviewStatus: { in: ['manager_review', 'calibration', 'complete'] } },
      include: {
        employee: {
          select: {
            id: true, firstName: true, lastName: true,
            designation: { select: { name: true } },
            department: { select: { name: true } },
          },
        },
        goals: true,
      },
    });

    // Build 9-box grid
    const nineBox: Record<string, Array<{ id: string; name: string; designation?: string; rating: number }>> = {};
    for (let perf = 1; perf <= 3; perf++) {
      for (let pot = 1; pot <= 3; pot++) {
        nineBox[`${perf}-${pot}`] = [];
      }
    }

    for (const r of reviews) {
      const p = r.performanceAxis ?? 2;
      const pot = r.potentialAxis ?? 2;
      const key = `${p}-${pot}`;
      const weightedRating = computeWeightedRating(r.goals ?? [], true);
      nineBox[key] = nineBox[key] ?? [];
      nineBox[key]!.push({
        id: r.employeeId,
        name: `${r.employee?.firstName} ${r.employee?.lastName}`,
        designation: r.employee?.designation?.name,
        rating: r.calibratedRating ?? r.managerOverallRating ?? weightedRating,
      });
    }

    const promotionReady = reviews
      .filter((r: any) => r.promotionRecommendation === 'ready_now')
      .map((r: any) => ({
        id: r.employeeId,
        name: `${r.employee?.firstName} ${r.employee?.lastName}`,
        department: r.employee?.department?.name,
        designation: r.employee?.designation?.name,
        rating: r.calibratedRating ?? r.managerOverallRating ?? 0,
      }));

    return { nineBox, reviews, promotionReady, totalReviewed: reviews.length };
  }

  async calibrateReview(
    tenantId: string,
    reviewId: string,
    data: { calibratedRating: number; notes: string; performanceAxis: 1|2|3; potentialAxis: 1|2|3 },
    calibratedBy: string,
  ) {
    return (this.prisma as any).performanceReview.update({
      where: { id: reviewId },
      data: {
        calibratedRating: data.calibratedRating,
        calibrationNotes: data.notes,
        performanceAxis: data.performanceAxis,
        potentialAxis: data.potentialAxis,
        nineBoxLabel: get9BoxCell(data.performanceAxis, data.potentialAxis),
        reviewStatus: 'calibration',
        calibratedAt: new Date(),
        calibratedBy,
      },
    });
  }

  // ── EMPLOYEE DASHBOARD ─────────────────────────────────────────────────────

  async getMyDashboard(tenantId: string, employeeId: string) {
    const [employee, leaveBalances, recentPayslip, openTasks, notifications, activeSurvey] =
      await Promise.all([
        (this.prisma as any).employee.findFirst({
          where: { id: employeeId },
          select: {
            id: true, firstName: true, lastName: true, employeeCode: true,
            designation: { select: { name: true } },
            department: { select: { name: true } },
            managerId: true,
            dateOfJoining: true,
          },
        }),
        (this.prisma as any).leaveBalance.findMany({
          where: { employeeId, tenantId },
          include: { leaveType: { select: { name: true, code: true } } },
          take: 8,
        }),
        (this.prisma as any).payslip.findFirst({
          where: { employeeId, tenantId },
          orderBy: { payPeriodEnd: 'desc' },
          select: { id: true, payPeriodEnd: true, netPay: true, status: true },
        }),
        (this.prisma as any).workflowTask?.findMany({
          where: { assigneeId: employeeId, status: { in: ['pending', 'in-progress'] } },
          orderBy: { createdAt: 'desc' },
          take: 5,
        }).catch(() => []) ?? [],
        (this.prisma as any).notification?.findMany({
          where: { recipientId: employeeId, isRead: false },
          orderBy: { createdAt: 'desc' },
          take: 10,
        }).catch(() => []) ?? [],
        (this.prisma as any).pulseSurvey?.findFirst({
          where: { tenantId, status: 'active' },
        }).catch(() => null) ?? null,
      ]);

    // Leave summary
    const leaveSummary: LeaveBalanceSummary = {
      employeeId,
      balances: (leaveBalances ?? []).map((b: any) => ({
        leaveTypeCode: b.leaveType?.code ?? '',
        leaveTypeName: b.leaveType?.name ?? '',
        total: b.allocated ?? 0,
        used: b.used ?? 0,
        pending: b.pending ?? 0,
        remaining: (b.allocated ?? 0) - (b.used ?? 0) - (b.pending ?? 0),
        carryForward: b.carryForward ?? 0,
      })),
    };

    // Tax quick stats (simplified)
    const tenantSettings = await (this.prisma as any).tenant.findFirst({
      where: { id: tenantId },
      select: { settings: true },
    });

    return {
      employee,
      leave: leaveSummary,
      latestPayslip: recentPayslip,
      pendingTasks: openTasks?.length ?? 0,
      notifications: notifications ?? [],
      unreadNotifications: notifications?.length ?? 0,
      activeSurvey: activeSurvey ? { id: activeSurvey.id, title: activeSurvey.title } : null,
      quickActions: [
        { id: 'apply-leave', label: 'Apply Leave', icon: 'calendar', route: '/dashboard/leave/apply', shortcut: 'Alt+L' },
        { id: 'payslip', label: 'My Payslips', icon: 'file-text', route: '/dashboard/payslips', shortcut: '' },
        { id: 'tax', label: 'Tax Declaration', icon: 'receipt', route: '/dashboard/tax', shortcut: '' },
        { id: 'team', label: 'My Team', icon: 'users', route: '/dashboard/org-chart', shortcut: '' },
        { id: 'goals', label: 'My Goals', icon: 'target', route: '/dashboard/performance', shortcut: '' },
        { id: 'help', label: 'Raise a Ticket', icon: 'help-circle', route: '/dashboard/case-engine/tickets', shortcut: '' },
      ],
    };
  }

  async getTaxProjection(tenantId: string, employeeId: string): Promise<TaxProjection> {
    const now = new Date();
    // India financial year: April–March
    const fyStart = now.getMonth() >= 3
      ? new Date(now.getFullYear(), 3, 1)
      : new Date(now.getFullYear() - 1, 3, 1);
    const fyEnd = new Date(fyStart.getFullYear() + 1, 2, 31);
    const monthsElapsed = Math.max(1, Math.round((now.getTime() - fyStart.getTime()) / (30 * 86400_000)));
    const monthsTotal = 12;
    const monthsRemaining = Math.max(0, monthsTotal - monthsElapsed);

    // YTD gross from payslips
    const ytdAgg = await (this.prisma as any).payslip.aggregate({
      where: {
        tenantId, employeeId,
        payPeriodStart: { gte: fyStart },
        status: { in: ['approved', 'paid'] },
      },
      _sum: { grossPay: true, tdsDeducted: true },
    });

    const grossYtd = ytdAgg._sum?.grossPay ?? 0;
    const tdsYtd = ytdAgg._sum?.tdsDeducted ?? 0;
    const monthlyRate = monthsElapsed > 0 ? grossYtd / monthsElapsed : 0;
    const projectedAnnualGross = grossYtd + monthlyRate * monthsRemaining;

    // New regime FY25 slabs (simplified)
    const standardDeduction = 75000;
    const taxableIncome = Math.max(0, projectedAnnualGross - standardDeduction);
    const projectedTax = computeNewRegimeTax(taxableIncome);
    const estimatedBalanceTax = Math.max(0, projectedTax - tdsYtd);
    const monthlyTdsRequired = monthsRemaining > 0 ? Math.ceil(estimatedBalanceTax / monthsRemaining) : 0;

    return {
      financialYear: `${fyStart.getFullYear()}-${(fyStart.getFullYear() + 1).toString().slice(2)}`,
      regime: 'new',
      grossSalaryYtd: grossYtd,
      projectedAnnualGross,
      standardDeduction,
      projectedTaxableIncome: taxableIncome,
      projectedTax,
      tdsDeductedYtd: tdsYtd,
      estimatedBalanceTax,
      monthlyTdsRequired,
      monthsRemaining,
    };
  }

  async search(tenantId: string, q: string, requesterId: string): Promise<DashboardSearchResult[]> {
    if (!q || q.length < 2) return [];
    const term = `%${q.toLowerCase()}%`;
    const results: DashboardSearchResult[] = [];

    // Employees
    const employees = await (this.prisma as any).employee.findMany({
      where: {
        tenantId,
        deletedAt: null,
        OR: [
          { firstName: { contains: q, mode: 'insensitive' } },
          { lastName: { contains: q, mode: 'insensitive' } },
          { employeeCode: { contains: q, mode: 'insensitive' } },
        ],
      },
      select: { id: true, firstName: true, lastName: true, employeeCode: true, designation: { select: { name: true } } },
      take: 5,
    });

    for (const e of employees) {
      results.push({
        type: 'employee',
        id: e.id,
        title: `${e.firstName} ${e.lastName}`,
        subtitle: `${e.employeeCode} · ${e.designation?.name ?? ''}`,
        route: `/dashboard/employees/${e.id}`,
        icon: 'user',
      });
    }

    // Static pages
    const pages: DashboardSearchResult[] = [
      { type: 'page', id: 'p1', title: 'Apply Leave', subtitle: 'Leave management', route: '/dashboard/leave/apply', icon: 'calendar', keywords: ['leave', 'holiday', 'vacation'] },
      { type: 'page', id: 'p2', title: 'My Payslips', subtitle: 'Salary slips', route: '/dashboard/payslips', icon: 'file', keywords: ['payslip', 'salary', 'pay', 'slip'] },
      { type: 'page', id: 'p3', title: 'Tax Declaration', subtitle: 'Investment proofs', route: '/dashboard/tax', icon: 'receipt', keywords: ['tax', 'tds', 'form16', 'investment'] },
      { type: 'page', id: 'p4', title: 'Org Chart', subtitle: 'Team hierarchy', route: '/dashboard/org-chart', icon: 'git-branch', keywords: ['org', 'chart', 'hierarchy', 'team'] },
      { type: 'page', id: 'p5', title: 'Performance Goals', subtitle: 'Review cycle', route: '/dashboard/performance', icon: 'target', keywords: ['goals', 'review', 'performance', 'kpi'] },
      { type: 'page', id: 'p6', title: 'Pulse Survey', subtitle: 'Give feedback', route: '/dashboard/pulse', icon: 'activity', keywords: ['survey', 'pulse', 'nps', 'feedback'] },
      { type: 'page', id: 'p7', title: 'Raise IT Ticket', subtitle: 'Help & support', route: '/dashboard/case-engine/tickets', icon: 'help-circle', keywords: ['ticket', 'help', 'support', 'issue'] },
      { type: 'page', id: 'p8', title: 'Billing', subtitle: 'Plan & invoices', route: '/dashboard/billing', icon: 'credit-card', keywords: ['billing', 'invoice', 'plan', 'subscription'] },
    ];

    const ql = q.toLowerCase();
    for (const page of pages) {
      if (
        page.title.toLowerCase().includes(ql) ||
        page.subtitle?.toLowerCase().includes(ql) ||
        page.keywords?.some(k => k.includes(ql))
      ) {
        results.push(page);
      }
    }

    return results.slice(0, 8);
  }

  async markNotificationsRead(tenantId: string, employeeId: string, ids: string[]) {
    return (this.prisma as any).notification?.updateMany({
      where: { id: { in: ids }, recipientId: employeeId },
      data: { isRead: true, readAt: new Date() },
    }).catch(() => null);
  }
}

// ─── Tax helper (New Regime FY25) ─────────────────────────────────────────────

function computeNewRegimeTax(income: number): number {
  if (income <= 300_000) return 0;
  if (income <= 700_000) return (income - 300_000) * 0.05;
  if (income <= 1_000_000) return 20_000 + (income - 700_000) * 0.10;
  if (income <= 1_200_000) return 50_000 + (income - 1_000_000) * 0.15;
  if (income <= 1_500_000) return 80_000 + (income - 1_200_000) * 0.20;
  return 140_000 + (income - 1_500_000) * 0.30;
}

// ─── Controller ────────────────────────────────────────────────────────────────

@ApiTags('engagement')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('engagement')
export class EngagementController {
  constructor(private readonly svc: EngagementService) {}

  // Org Chart
  @Get('org-chart')
  getOrgChart(@Query('dept') departmentId: string, @Query('entity') entityId: string, @Query('root') rootNodeId: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getOrgChart(u.tid, { departmentId, entityId, rootNodeId });
  }

  // Pulse Surveys
  @Get('surveys')
  listSurveys(@Query('status') status: string, @CurrentUser() u: JwtPayload) {
    return this.svc.listSurveys(u.tid, status);
  }

  @Post('surveys')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.CREATED)
  createSurvey(@Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.svc.createSurvey(u.tid, dto, u.sub);
  }

  @Post('surveys/:id/activate')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.OK)
  activateSurvey(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.svc.activateSurvey(u.tid, id);
  }

  @Get('surveys/:id/respond')
  getSurveyForEmployee(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getSurveyForEmployee(id, u.tid, u.sub);
  }

  @Post('surveys/:id/respond')
  @HttpCode(HttpStatus.OK)
  submitResponse(@Param('id') id: string, @Body('answers') answers: any[], @CurrentUser() u: JwtPayload) {
    return this.svc.submitSurveyResponse(id, u.tid, u.sub, answers);
  }

  @Get('surveys/:id/results')
  @Roles('hr-admin', 'super-admin', 'cfo')
  getSurveyResults(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getSurveyResults(id, u.tid);
  }

  @Get('surveys/enps-trend')
  @Roles('hr-admin', 'super-admin', 'cfo')
  getENPSTrend(@Query('months') months: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getENPSTrend(u.tid, parseInt(months ?? '6'));
  }

  // Performance
  @Get('performance/cycles')
  listCycles(@CurrentUser() u: JwtPayload) { return this.svc.listCycles(u.tid); }

  @Post('performance/cycles')
  @Roles('hr-admin', 'super-admin')
  @HttpCode(HttpStatus.CREATED)
  createCycle(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.svc.createCycle(u.tid, dto, u.sub); }

  @Get('performance/cycles/:cycleId/my-review')
  getMyReview(@Param('cycleId') cycleId: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getMyReview(u.tid, u.sub, cycleId);
  }

  @Post('performance/cycles/:cycleId/goals')
  @HttpCode(HttpStatus.OK)
  upsertGoal(@Param('cycleId') cycleId: string, @Body() goal: any, @CurrentUser() u: JwtPayload) {
    return this.svc.upsertGoal(u.tid, u.sub, cycleId, goal);
  }

  @Post('performance/cycles/:cycleId/self-review')
  @HttpCode(HttpStatus.OK)
  selfReview(@Param('cycleId') cycleId: string, @Body() data: any, @CurrentUser() u: JwtPayload) {
    return this.svc.submitSelfReview(u.tid, u.sub, cycleId, data);
  }

  @Post('performance/cycles/:cycleId/manager-review/:employeeId')
  @HttpCode(HttpStatus.OK)
  managerReview(@Param('cycleId') cycleId: string, @Param('employeeId') empId: string, @Body() data: any, @CurrentUser() u: JwtPayload) {
    return this.svc.submitManagerReview(u.tid, u.sub, empId, cycleId, data);
  }

  @Get('performance/cycles/:cycleId/calibration')
  @Roles('hr-admin', 'super-admin')
  calibrationView(@Param('cycleId') cycleId: string, @CurrentUser() u: JwtPayload) {
    return this.svc.getCalibrationView(u.tid, cycleId);
  }

  @Patch('performance/reviews/:reviewId/calibrate')
  @Roles('hr-admin', 'super-admin')
  calibrate(@Param('reviewId') reviewId: string, @Body() data: any, @CurrentUser() u: JwtPayload) {
    return this.svc.calibrateReview(u.tid, reviewId, data, u.sub);
  }

  // Dashboard
  @Get('dashboard/me')
  getMyDashboard(@CurrentUser() u: JwtPayload) { return this.svc.getMyDashboard(u.tid, u.sub); }

  @Get('dashboard/tax-projection')
  getTaxProjection(@CurrentUser() u: JwtPayload) { return this.svc.getTaxProjection(u.tid, u.sub); }

  @Get('dashboard/search')
  search(@Query('q') q: string, @CurrentUser() u: JwtPayload) { return this.svc.search(u.tid, q, u.sub); }

  @Post('dashboard/notifications/read')
  @HttpCode(HttpStatus.OK)
  markRead(@Body('ids') ids: string[], @CurrentUser() u: JwtPayload) {
    return this.svc.markNotificationsRead(u.tid, u.sub, ids);
  }
}

// ─── Module ───────────────────────────────────────────────────────────────────

@Module({
  controllers: [EngagementController],
  providers: [
    EngagementService,
    { provide: PrismaClient, useExisting: PrismaClient },
  ],
  exports: [EngagementService],
})
export class EngagementModule {}
