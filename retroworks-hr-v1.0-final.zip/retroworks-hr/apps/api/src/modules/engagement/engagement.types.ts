/**
 * Engagement + Performance + Experience — Type Definitions
 */

// ─── ORG CHART ────────────────────────────────────────────────────────────────

export interface OrgNode {
  id: string;
  employeeCode: string;
  name: string;
  designation?: string;
  department?: string;
  departmentId?: string;
  entityId?: string;
  entityName?: string;
  managerId?: string | null;
  avatarUrl?: string;
  status: 'active' | 'inactive';
  // Layout (computed client-side)
  x?: number;
  y?: number;
  depth?: number;
  children?: OrgNode[];
}

export interface OrgChartFilter {
  departmentId?: string;
  entityId?: string;
  rootNodeId?: string;   // zoom in on subtree
}

// ─── PULSE SURVEY ─────────────────────────────────────────────────────────────

export type SurveyQuestionType = 'nps' | 'scale' | 'text' | 'yesno' | 'mcq';

export interface SurveyQuestion {
  id: string;
  text: string;
  type: SurveyQuestionType;
  required: boolean;
  options?: string[];   // for mcq
  minLabel?: string;    // for scale/nps
  maxLabel?: string;
}

export interface PulseSurvey {
  id: string;
  tenantId: string;
  title: string;
  description?: string;
  questions: SurveyQuestion[];   // max 5
  isAnonymous: boolean;
  targetAudience: 'all' | 'department' | 'entity';
  targetIds?: string[];
  status: 'draft' | 'active' | 'closed';
  opensAt?: Date;
  closesAt?: Date;
  createdBy: string;
  createdAt: Date;
}

export interface SurveyResponse {
  id: string;
  surveyId: string;
  respondentId?: string;     // null if anonymous
  tenantId: string;
  answers: Array<{ questionId: string; value: string | number }>;
  submittedAt: Date;
}

export interface SurveyResult {
  surveyId: string;
  totalResponses: number;
  responseRate: number;
  questionResults: Array<{
    questionId: string;
    questionText: string;
    type: SurveyQuestionType;
    average?: number;
    distribution?: Record<string, number>;
    textResponses?: string[];
  }>;
  eNPS?: {
    score: number;          // -100 to +100
    promoters: number;
    passives: number;
    detractors: number;
  };
}

export interface ENPSTrend {
  period: string;           // 'YYYY-MM'
  score: number;
  responses: number;
}

// ─── PERFORMANCE CYCLE ────────────────────────────────────────────────────────

export type GoalStatus = 'draft' | 'active' | 'completed' | 'cancelled';
export type ReviewStatus = 'pending' | 'self_review' | 'manager_review' | 'calibration' | 'complete';

export interface PerformanceGoal {
  id: string;
  employeeId: string;
  tenantId: string;
  cycleId: string;
  title: string;
  description?: string;
  metric?: string;         // e.g. "Deliver 3 features"
  weight: number;          // % of overall rating
  status: GoalStatus;
  progress: number;        // 0–100
  selfRating?: number;     // 1–5
  managerRating?: number;
  dueDate?: Date;
  createdAt: Date;
}

export interface PerformanceCycle {
  id: string;
  tenantId: string;
  name: string;
  period: string;           // e.g. "H1 2024"
  status: 'planning' | 'goal_setting' | 'self_review' | 'manager_review' | 'calibration' | 'complete';
  goalSettingDeadline: Date;
  selfReviewDeadline: Date;
  managerReviewDeadline: Date;
  calibrationDate?: Date;
  createdAt: Date;
}

export interface PerformanceReview {
  id: string;
  employeeId: string;
  tenantId: string;
  cycleId: string;
  reviewStatus: ReviewStatus;
  // Self review
  selfOverallRating?: number;
  selfStrengths?: string;
  selfImprovements?: string;
  selfSubmittedAt?: Date;
  // Manager review
  managerOverallRating?: number;
  managerStrengths?: string;
  managerDevelopment?: string;
  promotionRecommendation?: 'ready_now' | 'ready_in_6m' | 'ready_in_12m' | 'not_ready';
  managerSubmittedAt?: Date;
  // Calibration
  calibratedRating?: number;
  calibrationNotes?: string;
  calibratedAt?: Date;
  calibratedBy?: string;
  // 9-box
  performanceAxis?: 1 | 2 | 3;    // 1=low 2=mid 3=high (Y)
  potentialAxis?: 1 | 2 | 3;      // 1=low 2=mid 3=high (X)
  goals: PerformanceGoal[];
}

// 9-box labels
export const NINE_BOX_LABELS: Record<string, string> = {
  '1-1': 'Inconsistent Player',  '2-1': 'Core Player',       '3-1': 'High Professional',
  '1-2': 'Rough Diamond',        '2-2': 'Key Player',         '3-2': 'High Performer',
  '1-3': 'Future Star',          '2-3': 'Top Talent',         '3-3': 'Star Performer',
};

// ─── EMPLOYEE DASHBOARD ────────────────────────────────────────────────────────

export interface QuickAction {
  id: string;
  label: string;
  icon: string;
  route: string;
  shortcut?: string;
  badge?: number;
}

export interface LeaveBalanceSummary {
  employeeId: string;
  balances: Array<{
    leaveTypeCode: string;
    leaveTypeName: string;
    total: number;
    used: number;
    pending: number;
    remaining: number;
    carryForward: number;
  }>;
  nextHoliday?: { name: string; date: Date };
}

export interface TaxProjection {
  financialYear: string;
  regime: 'old' | 'new';
  grossSalaryYtd: number;
  projectedAnnualGross: number;
  standardDeduction: number;
  projectedTaxableIncome: number;
  projectedTax: number;
  tdsDeductedYtd: number;
  estimatedBalanceTax: number;
  monthlyTdsRequired: number;
  monthsRemaining: number;
}

export interface DashboardSearchResult {
  type: 'employee' | 'page' | 'action' | 'payslip' | 'leave';
  id: string;
  title: string;
  subtitle?: string;
  route: string;
  icon?: string;
  keywords?: string[];
}

export interface NotificationItem {
  id: string;
  type: string;
  title: string;
  body: string;
  isRead: boolean;
  actionUrl?: string;
  createdAt: Date;
}

// ─── PIXEL AVATAR ENGINE ──────────────────────────────────────────────────────

// Deterministic pixel avatar from employee name hash
export function getAvatarSeed(name: string): number {
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = (hash << 5) - hash + name.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

// 5×5 pixel grid (symmetric left-right)
export function generatePixelAvatar(seed: number): boolean[][] {
  const grid: boolean[][] = [];
  for (let row = 0; row < 5; row++) {
    const rowData: boolean[] = [];
    for (let col = 0; col < 5; col++) {
      const mirrorCol = col <= 2 ? col : 4 - col;
      const bit = (seed >> (row * 3 + mirrorCol)) & 1;
      rowData.push(bit === 1);
    }
    grid.push(rowData);
  }
  return grid;
}

// Palette based on seed
export const AVATAR_PALETTES = [
  { bg: '#0d1f12', fg: '#00ff41' },  // Matrix green
  { bg: '#0d0d1f', fg: '#5b8af5' },  // Retro blue
  { bg: '#1f0d12', fg: '#ff4d6d' },  // Neon red
  { bg: '#1a0d1f', fg: '#bf5af2' },  // Purple
  { bg: '#1f1a0d', fg: '#ffd60a' },  // Amber
  { bg: '#0d1f1f', fg: '#00b8d9' },  // Cyan
  { bg: '#1f120d', fg: '#ff9f0a' },  // Orange
  { bg: '#0f1f0d', fg: '#30d158' },  // Apple green
];

export function getAvatarPalette(seed: number) {
  return AVATAR_PALETTES[seed % AVATAR_PALETTES.length]!;
}

// ─── ORG TREE LAYOUT ──────────────────────────────────────────────────────────

const NODE_WIDTH = 140;
const NODE_HEIGHT = 80;
const H_GAP = 24;
const V_GAP = 60;

export interface LayoutNode extends OrgNode {
  x: number;
  y: number;
  subtreeWidth: number;
}

export function buildTree(nodes: OrgNode[], rootId?: string): OrgNode[] {
  const map = new Map<string, OrgNode & { children: OrgNode[] }>();
  for (const n of nodes) map.set(n.id, { ...n, children: [] });

  const roots: (OrgNode & { children: OrgNode[] })[] = [];
  for (const node of map.values()) {
    if (node.managerId && map.has(node.managerId)) {
      map.get(node.managerId)!.children.push(node);
    } else {
      roots.push(node);
    }
  }

  if (rootId) {
    const specificRoot = map.get(rootId);
    return specificRoot ? [specificRoot] : roots;
  }
  return roots;
}

export function layoutTree(node: OrgNode & { children?: OrgNode[] }, depth = 0, startX = 0): LayoutNode & { children: LayoutNode[] } {
  let childX = startX;
  const children = (node.children ?? []).map((c) => {
    const laid = layoutTree(c as any, depth + 1, childX);
    childX += laid.subtreeWidth;
    return laid;
  });

  const subtreeWidth = children.length === 0
    ? NODE_WIDTH + H_GAP
    : children.reduce((s, c) => s + c.subtreeWidth, 0);

  const x = children.length === 0
    ? startX
    : children[0]!.x + (children[children.length - 1]!.x - children[0]!.x) / 2;

  return {
    ...node,
    x,
    y: depth * (NODE_HEIGHT + V_GAP),
    subtreeWidth,
    children,
  } as LayoutNode & { children: LayoutNode[] };
}

// ─── eNPS CALCULATION ─────────────────────────────────────────────────────────

export function calculateENPS(scores: number[]): {
  score: number; promoters: number; passives: number; detractors: number;
} {
  if (scores.length === 0) return { score: 0, promoters: 0, passives: 0, detractors: 0 };
  const promoters  = scores.filter(s => s >= 9).length;
  const passives   = scores.filter(s => s >= 7 && s <= 8).length;
  const detractors = scores.filter(s => s <= 6).length;
  const score = Math.round(((promoters - detractors) / scores.length) * 100);
  return { score, promoters, passives, detractors };
}

// ─── 9-BOX PLACEMENT ─────────────────────────────────────────────────────────

export function get9BoxCell(performance: 1|2|3, potential: 1|2|3): string {
  return NINE_BOX_LABELS[`${performance}-${potential}`] ?? 'Key Player';
}

export function computeWeightedRating(goals: PerformanceGoal[], useManager = true): number {
  const rated = goals.filter(g => useManager ? g.managerRating != null : g.selfRating != null);
  if (rated.length === 0) return 0;
  const totalWeight = rated.reduce((s, g) => s + g.weight, 0);
  if (totalWeight === 0) return 0;
  const weighted = rated.reduce((s, g) => {
    const r = useManager ? (g.managerRating ?? 0) : (g.selfRating ?? 0);
    return s + r * (g.weight / totalWeight);
  }, 0);
  return Math.round(weighted * 10) / 10;
}
