/**
 * RetroWorks AI Module
 * ────────────────────────────────────────────────────────────────────
 * Provides:
 *  1. RAG-powered HR knowledge base Q&A
 *  2. Resume parsing (ATS enrichment)
 *  3. Smart employee / policy search
 *  4. JD generator from role templates
 *  5. Offer letter generation
 *  6. Performance review summarizer
 *
 * Architecture:
 *  - Embeddings stored in pgvector (PostgreSQL)
 *  - LLM calls to OpenAI (gpt-4o) or Anthropic (claude-3-5-sonnet)
 *  - Conversation memory per session (Redis TTL=24h)
 *  - Document chunking: 512 tokens, 64-token overlap
 *  - Rate limited: 60 calls/hour per tenant, 10 per minute per user
 */

import {
  Injectable, Logger, BadRequestException, NotFoundException,
} from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import {
  Controller, Post, Get, Body, Param, Query, UseGuards, Delete,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation, ApiBody } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Throttle } from '@nestjs/throttler';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── Types ───────────────────────────────────────────────

interface Message {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

interface KbChunk {
  id: string;
  content: string;
  source: string;
  similarity: number;
}

interface ParsedResume {
  name?: string;
  email?: string;
  phone?: string;
  summary?: string;
  totalExperience?: number; // years
  currentDesignation?: string;
  currentCompany?: string;
  skills: string[];
  education: Array<{ degree: string; institution: string; year?: number }>;
  workHistory: Array<{ company: string; role: string; from: string; to: string; highlights?: string[] }>;
  linkedinUrl?: string;
}

// ─── Service ─────────────────────────────────────────────

@Injectable()
export class AiService {
  private readonly logger = new Logger(AiService.name);
  private readonly llmProvider: 'openai' | 'anthropic';
  private readonly openaiApiKey?: string;
  private readonly anthropicApiKey?: string;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
    private readonly config: ConfigService,
  ) {
    this.llmProvider = (config.get<string>('AI_PROVIDER') ?? 'anthropic') as 'openai' | 'anthropic';
    this.openaiApiKey = config.get<string>('OPENAI_API_KEY');
    this.anthropicApiKey = config.get<string>('ANTHROPIC_API_KEY');
  }

  // ─── HR ASSISTANT CHAT ──────────────────────────────────

  async chat(tenantId: string, sessionId: string, userMessage: string, userId: string): Promise<{
    reply: string;
    sources: Array<{ title: string; url?: string }>;
    sessionId: string;
  }> {
    // Load conversation history (last 10 messages)
    const history = await this.getConversationHistory(tenantId, sessionId);

    // Retrieve relevant KB chunks via vector similarity
    const chunks = await this.retrieveRelevantChunks(tenantId, userMessage);

    // Build system prompt with HR context
    const systemPrompt = this.buildHrSystemPrompt(chunks);

    // Compose messages for LLM
    const messages: Message[] = [
      { role: 'system', content: systemPrompt },
      ...history,
      { role: 'user', content: userMessage },
    ];

    // Call LLM
    const reply = await this.callLlm(messages);

    // Persist conversation
    await this.saveConversationMessage(tenantId, sessionId, userId, 'user', userMessage);
    await this.saveConversationMessage(tenantId, sessionId, userId, 'assistant', reply);

    // Track usage
    this.events.emit('ai.chat.completed', { tenantId, userId, sessionId, tokens: this.estimateTokens(reply) });

    return {
      reply,
      sources: chunks.slice(0, 3).map(c => ({ title: c.source })),
      sessionId,
    };
  }

  // ─── KNOWLEDGE BASE MANAGEMENT ──────────────────────────

  async ingestDocument(tenantId: string, dto: {
    title: string;
    content: string;
    category: 'policy' | 'handbook' | 'faq' | 'procedure' | 'compliance' | 'benefits';
    sourceUrl?: string;
  }, uploadedBy: string) {
    // Chunk the document
    const chunks = this.chunkText(dto.content, 512, 64);

    // Generate embeddings for each chunk
    const embeddings = await this.generateEmbeddings(chunks.map(c => c.text));

    // Create KB document record
    const doc = await this.prisma.kbDocument.create({
      data: {
        tenantId, title: dto.title, content: dto.content,
        category: dto.category, sourceUrl: dto.sourceUrl,
        chunkCount: chunks.length, createdBy: uploadedBy,
      },
    });

    // Store chunks with embeddings in vector store
    await this.prisma.$executeRawUnsafe(
      `INSERT INTO kb_chunks (id, tenant_id, document_id, content, embedding, chunk_index, created_at)
       VALUES ${chunks.map((_, i) => `(gen_random_uuid(), $1, $2, $${i * 2 + 3}, $${i * 2 + 4}::vector, $${i * 2 + 5 + chunks.length}, NOW())`).join(', ')}
       ON CONFLICT DO NOTHING`,
      tenantId, doc.id,
      ...chunks.flatMap((c, i) => [c.text, JSON.stringify(embeddings[i] ?? []), i]),
    );

    this.logger.log(`Ingested KB doc "${dto.title}" (${chunks.length} chunks) for tenant ${tenantId}`);
    return { id: doc.id, chunks: chunks.length };
  }

  async listDocuments(tenantId: string, category?: string) {
    return this.prisma.kbDocument.findMany({
      where: { tenantId, deletedAt: null, ...(category && { category }) },
      orderBy: { createdAt: 'desc' },
      select: { id: true, title: true, category: true, chunkCount: true, createdAt: true, sourceUrl: true },
    });
  }

  async deleteDocument(tenantId: string, docId: string) {
    await this.prisma.kbDocument.update({
      where: { id: docId },
      data: { deletedAt: new Date() },
    });
    await this.prisma.$executeRaw`DELETE FROM kb_chunks WHERE document_id = ${docId}`;
    return { deleted: true };
  }

  // ─── RESUME PARSER ──────────────────────────────────────

  async parseResume(tenantId: string, resumeText: string, candidateId?: string): Promise<ParsedResume> {
    const prompt = `You are an expert HR recruiter. Extract structured information from this resume.
Return ONLY a JSON object with this exact schema:
{
  "name": string,
  "email": string,
  "phone": string,
  "summary": string (2-3 sentences),
  "totalExperience": number (years, decimal ok),
  "currentDesignation": string,
  "currentCompany": string,
  "skills": string[] (technical + soft skills),
  "education": [{ "degree": string, "institution": string, "year": number }],
  "workHistory": [{ "company": string, "role": string, "from": string, "to": string, "highlights": string[] }],
  "linkedinUrl": string
}
Leave fields as null if not found. Do not add explanations.

RESUME:
${resumeText.slice(0, 6000)}`;

    const rawJson = await this.callLlm([
      { role: 'system', content: 'You extract structured data from resumes. Return only valid JSON.' },
      { role: 'user', content: prompt },
    ]);

    try {
      const parsed: ParsedResume = JSON.parse(rawJson.trim().replace(/^```json\n?|```$/g, ''));

      // If candidateId provided, enrich the candidate record
      if (candidateId) {
        await this.prisma.candidate.update({
          where: { id: candidateId },
          data: {
            name: parsed.name ?? undefined,
            email: parsed.email ?? undefined,
            phone: parsed.phone ?? undefined,
            currentDesignation: parsed.currentDesignation ?? undefined,
            currentCompany: parsed.currentCompany ?? undefined,
            experience: parsed.totalExperience ?? undefined,
            skills: parsed.skills ?? [],
            aiParsedData: parsed as any,
          },
        });
      }

      this.events.emit('ai.resume.parsed', { tenantId, candidateId });
      return parsed;
    } catch (err) {
      this.logger.error('Resume parse JSON error:', err);
      throw new BadRequestException('Failed to parse resume — invalid format');
    }
  }

  // ─── JD GENERATOR ───────────────────────────────────────

  async generateJobDescription(tenantId: string, dto: {
    title: string;
    department: string;
    level: string; // junior / mid / senior / lead
    skills: string[];
    responsibilities?: string[];
    remote?: boolean;
  }): Promise<{ jd: string }> {
    const prompt = `Generate a compelling, inclusive job description for a ${dto.level} ${dto.title} role in the ${dto.department} team.

Key requirements:
- Skills: ${dto.skills.join(', ')}
- Level: ${dto.level}
${dto.remote ? '- This is a fully remote role' : ''}
${dto.responsibilities ? `- Core responsibilities: ${dto.responsibilities.join('; ')}` : ''}

Format: 
## About the Role
## What You'll Do (5-7 bullet points)
## What You'll Bring (5-6 bullet points)  
## Nice to Have (2-3 items)
## What We Offer

Keep it under 500 words. Use active voice. Avoid gendered language.`;

    const jd = await this.callLlm([
      { role: 'system', content: 'You are a senior HR professional who writes compelling job descriptions.' },
      { role: 'user', content: prompt },
    ]);

    return { jd };
  }

  // ─── OFFER LETTER GENERATOR ──────────────────────────────

  async generateOfferLetter(tenantId: string, dto: {
    candidateName: string;
    designation: string;
    department: string;
    ctc: number;
    joiningDate: string;
    reportingTo: string;
    probationPeriod?: number; // months
  }): Promise<{ letter: string }> {
    const tenant = await this.prisma.tenant.findFirst({
      where: { id: tenantId },
      select: { name: true, domain: true },
    });

    const prompt = `Generate a professional offer letter for:
- Candidate: ${dto.candidateName}
- Role: ${dto.designation}, ${dto.department}
- Company: ${tenant?.name ?? 'RetroWorks'}
- CTC: ₹${dto.ctc.toLocaleString('en-IN')} per annum
- Joining Date: ${dto.joiningDate}
- Reporting to: ${dto.reportingTo}
- Probation: ${dto.probationPeriod ?? 6} months

Include: warm congratulations, role summary, compensation details, probation terms, next steps (document list + joining formalities).
Keep formal yet warm. Use [AUTHORIZED SIGNATORY] as placeholder.`;

    const letter = await this.callLlm([
      { role: 'system', content: 'You write professional, legally appropriate HR offer letters.' },
      { role: 'user', content: prompt },
    ]);

    return { letter };
  }

  // ─── PERFORMANCE REVIEW SUMMARIZER ──────────────────────

  async summarizeReview(tenantId: string, reviewId: string): Promise<{
    summary: string;
    keyStrengths: string[];
    developmentAreas: string[];
    suggestedRating: string;
    nextSteps: string[];
  }> {
    const review = await this.prisma.performanceReview.findFirst({
      where: { id: reviewId, tenantId },
      include: {
        employee: { select: { firstName: true, lastName: true } },
        cycle: { select: { name: true } },
      },
    });
    if (!review) throw new NotFoundException('Review not found');

    const peerFeedbacks = await this.prisma.peerFeedback.findMany({
      where: { reviewId, status: 'submitted' },
      select: { strengths: true, improvements: true, comments: true, rating: true },
    });

    const prompt = `Analyze this 360° performance review and provide structured insights.

Employee: ${review.employee.firstName} ${review.employee.lastName}
Review Cycle: ${review.cycle.name}

Self Rating: ${review.selfRating ?? 'N/A'}/5
Self Comments: ${review.selfComments ?? 'Not provided'}
Achievements: ${review.selfAchievements ?? 'Not provided'}
Challenges: ${review.selfChallenges ?? 'Not provided'}

Manager Rating: ${review.managerRating ?? 'N/A'}/5
Manager Comments: ${review.managerComments ?? 'Not provided'}
Strengths noted: ${review.managerStrengths ?? 'Not provided'}
Development areas: ${review.managerDevelopmentAreas ?? 'Not provided'}

Peer Feedback (${peerFeedbacks.length} responses):
${peerFeedbacks.map((p, i) => `Peer ${i + 1}: Rating ${p.rating}/5 | Strengths: ${p.strengths} | Areas: ${p.improvements}`).join('\n')}

Return ONLY a JSON object:
{
  "summary": "3-4 sentence overall summary",
  "keyStrengths": ["strength 1", "strength 2", "strength 3"],
  "developmentAreas": ["area 1", "area 2"],
  "suggestedRating": "outstanding|exceeds|meets|below|unacceptable",
  "nextSteps": ["action 1", "action 2", "action 3"]
}`;

    const raw = await this.callLlm([
      { role: 'system', content: 'You are an HR analytics expert who synthesizes performance review data.' },
      { role: 'user', content: prompt },
    ]);

    return JSON.parse(raw.trim().replace(/^```json\n?|```$/g, ''));
  }

  // ─── SMART SEARCH ───────────────────────────────────────

  async smartSearch(tenantId: string, query: string, types: string[] = ['employees', 'policies', 'kb']) {
    const results: Record<string, any[]> = {};

    if (types.includes('employees')) {
      results.employees = await this.prisma.employee.findMany({
        where: {
          tenantId, status: 'active', deletedAt: null,
          OR: [
            { firstName: { contains: query, mode: 'insensitive' } },
            { lastName: { contains: query, mode: 'insensitive' } },
            { email: { contains: query, mode: 'insensitive' } },
            { employeeCode: { contains: query, mode: 'insensitive' } },
            { designation: { name: { contains: query, mode: 'insensitive' } } },
          ],
        },
        select: {
          id: true, firstName: true, lastName: true, email: true,
          employeeCode: true, avatarUrl: true,
          designation: { select: { name: true } },
          department: { select: { name: true } },
        },
        take: 5,
      });
    }

    if (types.includes('kb')) {
      const kbChunks = await this.retrieveRelevantChunks(tenantId, query, 3);
      results.policies = kbChunks.map(c => ({ content: c.content.slice(0, 200) + '...', source: c.source, similarity: c.similarity }));
    }

    return results;
  }

  // ─── CONVERSATION HISTORY ────────────────────────────────

  async getConversationSessions(tenantId: string, userId: string) {
    return this.prisma.aiConversation.findMany({
      where: { tenantId, userId },
      orderBy: { updatedAt: 'desc' },
      take: 20,
      select: { id: true, title: true, updatedAt: true, messageCount: true },
    });
  }

  async getSession(tenantId: string, sessionId: string, userId: string) {
    const session = await this.prisma.aiConversation.findFirst({
      where: { id: sessionId, tenantId, userId },
      include: { messages: { orderBy: { createdAt: 'asc' } } },
    });
    if (!session) throw new NotFoundException('Session not found');
    return session;
  }

  async deleteSession(tenantId: string, sessionId: string, userId: string) {
    await this.prisma.aiConversation.delete({ where: { id: sessionId } });
    return { deleted: true };
  }

  // ─── PRIVATE HELPERS ─────────────────────────────────────

  private async callLlm(messages: Message[]): Promise<string> {
    if (this.llmProvider === 'anthropic' && this.anthropicApiKey) {
      return this.callAnthropic(messages);
    }
    return this.callOpenAi(messages);
  }

  private async callAnthropic(messages: Message[]): Promise<string> {
    const systemMsg = messages.find(m => m.role === 'system');
    const userMessages = messages.filter(m => m.role !== 'system');

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': this.anthropicApiKey!,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 2048,
        system: systemMsg?.content ?? 'You are a helpful HR assistant.',
        messages: userMessages.map(m => ({ role: m.role, content: m.content })),
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      throw new Error(`Anthropic API error: ${err}`);
    }

    const data = await response.json() as any;
    return data.content?.[0]?.text ?? '';
  }

  private async callOpenAi(messages: Message[]): Promise<string> {
    if (!this.openaiApiKey) throw new BadRequestException('AI provider not configured');

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${this.openaiApiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages,
        max_tokens: 2048,
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      throw new Error(`OpenAI API error: ${err}`);
    }

    const data = await response.json() as any;
    return data.choices?.[0]?.message?.content ?? '';
  }

  private async generateEmbeddings(texts: string[]): Promise<number[][]> {
    // Use OpenAI text-embedding-3-small or mock for dev
    if (!this.openaiApiKey) {
      // Return random embeddings in dev mode (1536 dimensions)
      return texts.map(() => Array.from({ length: 1536 }, () => Math.random() - 0.5));
    }

    const response = await fetch('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${this.openaiApiKey}` },
      body: JSON.stringify({ model: 'text-embedding-3-small', input: texts }),
    });

    const data = await response.json() as any;
    return data.data.map((d: any) => d.embedding);
  }

  private async retrieveRelevantChunks(tenantId: string, query: string, limit = 5): Promise<KbChunk[]> {
    try {
      const [queryEmbedding] = await this.generateEmbeddings([query]);
      const vectorStr = JSON.stringify(queryEmbedding);

      const chunks = await this.prisma.$queryRaw<KbChunk[]>`
        SELECT kc.id, kc.content, kd.title as source,
               1 - (kc.embedding <=> ${vectorStr}::vector) as similarity
        FROM kb_chunks kc
        JOIN kb_documents kd ON kd.id = kc.document_id
        WHERE kc.tenant_id = ${tenantId}
          AND kd.deleted_at IS NULL
          AND 1 - (kc.embedding <=> ${vectorStr}::vector) > 0.7
        ORDER BY similarity DESC
        LIMIT ${limit}
      `;
      return chunks;
    } catch {
      // If pgvector not set up yet, return empty
      return [];
    }
  }

  private buildHrSystemPrompt(chunks: KbChunk[]): string {
    const context = chunks.length > 0
      ? `\n\nRelevant HR policies and documents:\n${chunks.map(c => `[${c.source}]: ${c.content}`).join('\n\n')}`
      : '';

    return `You are RetroBot, a helpful and knowledgeable HR assistant for RetroWorks HR.
You help employees with questions about HR policies, leave rules, payroll, benefits, attendance, and career development.
Always be professional, empathetic, and concise.
If you don't know the answer, say so and suggest contacting the HR team.
Never make up specific numbers, dates, or policy details.${context}`;
  }

  private chunkText(text: string, chunkSize: number, overlap: number): Array<{ text: string; index: number }> {
    const words = text.split(/\s+/);
    const chunks: Array<{ text: string; index: number }> = [];
    let i = 0;

    while (i < words.length) {
      const chunk = words.slice(i, i + chunkSize).join(' ');
      chunks.push({ text: chunk, index: chunks.length });
      i += chunkSize - overlap;
    }

    return chunks;
  }

  private async getConversationHistory(tenantId: string, sessionId: string): Promise<Message[]> {
    const session = await this.prisma.aiConversation.findFirst({
      where: { id: sessionId, tenantId },
      include: { messages: { orderBy: { createdAt: 'asc' }, take: 10 } },
    });

    return (session?.messages ?? []).map(m => ({
      role: m.role as 'user' | 'assistant',
      content: m.content,
    }));
  }

  private async saveConversationMessage(
    tenantId: string, sessionId: string, userId: string,
    role: 'user' | 'assistant', content: string,
  ) {
    await this.prisma.aiConversation.upsert({
      where: { id: sessionId },
      update: {
        updatedAt: new Date(),
        messageCount: { increment: 1 },
        title: role === 'user' && content.length > 5
          ? (content.slice(0, 60) + (content.length > 60 ? '...' : ''))
          : undefined,
      } as any,
      create: {
        id: sessionId, tenantId, userId,
        title: content.slice(0, 60),
        messageCount: 1,
      },
    });

    await this.prisma.aiMessage.create({
      data: { conversationId: sessionId, role, content, createdBy: userId },
    });
  }

  private estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }
}

// ─── Controller ───────────────────────────────────────────

@ApiTags('ai')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('ai')
export class AiController {
  constructor(private readonly aiService: AiService) {}

  @Post('chat')
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  @ApiOperation({ summary: 'Chat with RetroBot HR assistant (RAG-powered)' })
  @ApiBody({ schema: { properties: { message: { type: 'string' }, sessionId: { type: 'string' } } } })
  chat(
    @Body('message') message: string,
    @Body('sessionId') sessionId: string,
    @CurrentUser() u: JwtPayload,
  ) {
    if (!message?.trim()) throw new BadRequestException('Message cannot be empty');
    const sid = sessionId ?? `session_${u.sub}_${Date.now()}`;
    return this.aiService.chat(u.tid, sid, message, u.sub);
  }

  @Get('sessions')
  @ApiOperation({ summary: 'Get my conversation sessions' })
  getSessions(@CurrentUser() u: JwtPayload) {
    return this.aiService.getConversationSessions(u.tid, u.sub);
  }

  @Get('sessions/:sessionId')
  getSession(@Param('sessionId') id: string, @CurrentUser() u: JwtPayload) {
    return this.aiService.getSession(u.tid, id, u.sub);
  }

  @Delete('sessions/:sessionId')
  deleteSession(@Param('sessionId') id: string, @CurrentUser() u: JwtPayload) {
    return this.aiService.deleteSession(u.tid, id, u.sub);
  }

  @Post('kb/ingest')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Ingest a document into the HR knowledge base' })
  ingestDocument(@Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.aiService.ingestDocument(u.tid, dto, u.sub);
  }

  @Get('kb/documents')
  @Roles('hr-admin', 'super-admin')
  listDocuments(@Query('category') cat: string | undefined, @CurrentUser() u: JwtPayload) {
    return this.aiService.listDocuments(u.tid, cat);
  }

  @Delete('kb/documents/:id')
  @Roles('hr-admin', 'super-admin')
  deleteDocument(@Param('id') id: string, @CurrentUser() u: JwtPayload) {
    return this.aiService.deleteDocument(u.tid, id);
  }

  @Post('resume/parse')
  @ApiOperation({ summary: 'Parse resume text with AI — extracts structured candidate data' })
  parseResume(
    @Body('resumeText') resumeText: string,
    @Body('candidateId') candidateId: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.aiService.parseResume(u.tid, resumeText, candidateId);
  }

  @Post('generate/jd')
  @Roles('hr-admin', 'super-admin', 'manager')
  @ApiOperation({ summary: 'Generate job description from role parameters' })
  generateJd(@Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.aiService.generateJobDescription(u.tid, dto);
  }

  @Post('generate/offer-letter')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Generate offer letter for a candidate' })
  generateOfferLetter(@Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.aiService.generateOfferLetter(u.tid, dto);
  }

  @Post('reviews/:reviewId/summarize')
  @Roles('hr-admin', 'super-admin', 'manager')
  @ApiOperation({ summary: 'AI-powered 360° review summarizer' })
  summarizeReview(@Param('reviewId') id: string, @CurrentUser() u: JwtPayload) {
    return this.aiService.summarizeReview(u.tid, id);
  }

  @Get('search')
  @ApiOperation({ summary: 'Smart unified search across employees, policies, KB' })
  search(
    @Query('q') query: string,
    @Query('types') types: string | undefined,
    @CurrentUser() u: JwtPayload,
  ) {
    if (!query?.trim()) throw new BadRequestException('Search query required');
    const typeList = types?.split(',') ?? ['employees', 'kb'];
    return this.aiService.smartSearch(u.tid, query, typeList);
  }
}

@Module({
  controllers: [AiController],
  providers: [AiService],
  exports: [AiService],
})
export class AiModule {}
