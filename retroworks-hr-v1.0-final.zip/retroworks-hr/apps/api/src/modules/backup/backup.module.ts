import { Injectable, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import { Cron } from '@nestjs/schedule';
import { Controller, Get, Post, Body, Param, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { exec } from 'child_process';
import { promisify } from 'util';
import * as fs from 'fs/promises';
import * as path from 'path';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

const execAsync = promisify(exec);

@Injectable()
export class BackupService {
  private readonly logger = new Logger(BackupService.name);
  private readonly backupDir: string;
  private readonly dbUrl: string;

  constructor(private readonly prisma: PrismaClient, private readonly events: EventEmitter2, private readonly config: ConfigService) {
    this.backupDir = config.get('BACKUP_DIR') ?? '/var/retroworks/backups';
    this.dbUrl = config.get('DATABASE_URL') ?? '';
  }

  @Cron('0 1 * * *', { name: 'daily-backup', timeZone: 'UTC' })
  async runDailyBackup() { await this.createBackup('scheduler', 'daily'); }

  @Cron('0 0 * * 0', { name: 'weekly-backup', timeZone: 'UTC' })
  async runWeeklyBackup() { await this.createBackup('scheduler', 'weekly'); }

  async createBackup(triggeredBy: string, type: 'daily' | 'weekly' | 'manual' = 'manual') {
    const backupId = `backup_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    const fileName = `retroworks_${type}_${new Date().toISOString().slice(0, 10)}_${backupId}.sql.gz`;
    const filePath = path.join(this.backupDir, fileName);
    const record = await this.prisma.backupRecord.create({ data: { id: backupId, type, status: 'running', fileName, triggeredBy, startedAt: new Date() } });

    (async () => {
      try {
        await fs.mkdir(this.backupDir, { recursive: true });
        const url = new URL(this.dbUrl.replace(/^postgres(ql)?:\/\//, 'http://'));
        const env = { ...process.env, PGPASSWORD: url.password };
        // H-06: Use .pgpass file pattern instead of PGPASSWORD env var
        // Write temp .pgpass for this operation only
        const pgpassPath = path.join('/tmp', `pgpass_${backupId}`);
        await fs.writeFile(pgpassPath, `${url.hostname}:${url.port || 5432}:${url.pathname.slice(1)}:${url.username}:${url.password}`, { mode: 0o600 });

        // H-06: Encrypt backup with AES-256-CBC via openssl
        const encryptionKey = config.get('app.backup.encryptionKey') ?? '';
        const encFilePath = filePath + '.enc';

        if (encryptionKey) {
          // Encrypted: pg_dump | gzip | openssl enc → .sql.gz.enc
          await execAsync(
            `PGPASSFILE=${pgpassPath} pg_dump -h ${url.hostname} -p ${url.port || 5432} -U ${url.username} -d ${url.pathname.slice(1)} --format=plain --clean | gzip | openssl enc -aes-256-cbc -pbkdf2 -pass env:BACKUP_ENC_KEY -out ${encFilePath}`,
            { env: { ...process.env, PGPASSFILE: pgpassPath, BACKUP_ENC_KEY: encryptionKey } },
          );
          // Remove unencrypted file if accidentally created
          await fs.unlink(filePath).catch(() => {});
          Object.assign(backupMeta, { filePath: encFilePath, encrypted: true });
        } else {
          this.logger.warn('[SECURITY] BACKUP_ENCRYPTION_KEY not set — backup is UNENCRYPTED. Set BACKUP_ENCRYPTION_KEY in production!');
          await execAsync(
            `PGPASSFILE=${pgpassPath} pg_dump -h ${url.hostname} -p ${url.port || 5432} -U ${url.username} -d ${url.pathname.slice(1)} --format=plain --clean | gzip > ${filePath}`,
            { env: { ...process.env, PGPASSFILE: pgpassPath } },
          );
          Object.assign(backupMeta, { filePath, encrypted: false });
        }

        // Remove .pgpass after use
        await fs.unlink(pgpassPath).catch(() => {});
        const stat = await fs.stat(filePath);
        const sizeMB = parseFloat((stat.size / (1024 * 1024)).toFixed(2));
        await this.prisma.backupRecord.update({ where: { id: backupId }, data: { status: 'success', completedAt: new Date(), fileSizeMB: sizeMB, filePath } });
        this.events.emit('backup.completed', { backupId, type, fileName, sizeMB });
        await this.purgeOldBackups(type);
      } catch (err: any) {
        await this.prisma.backupRecord.update({ where: { id: backupId }, data: { status: 'failed', completedAt: new Date(), error: err.message } }).catch(() => {});
        this.events.emit('backup.failed', { backupId, error: err.message });
      }
    })();

    return record;
  }

  private async purgeOldBackups(type: 'daily' | 'weekly' | 'manual') {
    const keep = type === 'daily' ? 7 : type === 'weekly' ? 4 : 10;
    const old = await this.prisma.backupRecord.findMany({ where: { type, status: 'success' }, orderBy: { startedAt: 'desc' }, skip: keep });
    for (const b of old) {
      if (b.filePath) await fs.unlink(b.filePath).catch(() => {});
      await this.prisma.backupRecord.delete({ where: { id: b.id } }).catch(() => {});
    }
  }

  async listBackups() { return this.prisma.backupRecord.findMany({ orderBy: { startedAt: 'desc' }, take: 50 }); }
  async getBackupStatus(backupId: string) { return this.prisma.backupRecord.findFirst({ where: { id: backupId } }); }

  async getBackupSummary() {
    const [total, successful, failed, last, size] = await Promise.all([
      this.prisma.backupRecord.count(),
      this.prisma.backupRecord.count({ where: { status: 'success' } }),
      this.prisma.backupRecord.count({ where: { status: 'failed' } }),
      this.prisma.backupRecord.findFirst({ where: { status: 'success' }, orderBy: { startedAt: 'desc' } }),
      this.prisma.backupRecord.aggregate({ where: { status: 'success' }, _sum: { fileSizeMB: true } }),
    ]);
    const next = new Date(); next.setDate(next.getDate() + 1); next.setHours(1, 0, 0, 0);
    return { total, successful, failed, lastBackup: last ? { id: last.id, completedAt: last.completedAt, type: last.type, sizeMB: last.fileSizeMB } : null, totalStorageMB: Math.round(size._sum.fileSizeMB ?? 0), nextScheduled: next.toISOString() };
  }

  async requestRestore(backupId: string, requestedBy: string, reason: string) {
    const backup = await this.prisma.backupRecord.findFirst({ where: { id: backupId } });
    if (!backup) return { error: 'Backup not found' };
    const restore = await this.prisma.restoreRequest.create({ data: { backupId, requestedBy, reason, status: 'pending', requestedAt: new Date() } });
    this.events.emit('backup.restore.requested', { restoreId: restore.id, backupId, requestedBy, reason, fileName: backup.fileName });
    return { restoreId: restore.id, message: 'Restore request submitted. Super admin will be notified.', backup: { id: backup.id, fileName: backup.fileName } };
  }

  async listRestoreRequests() { return this.prisma.restoreRequest.findMany({ orderBy: { requestedAt: 'desc' }, take: 20 }); }
}

@ApiTags('backup')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('super-admin')
@Controller('backup')
export class BackupController {
  constructor(private readonly svc: BackupService) {}
  @Get('summary') @ApiOperation({ summary: 'Backup health summary' }) getSummary() { return this.svc.getBackupSummary(); }
  @Get() listBackups() { return this.svc.listBackups(); }
  @Get(':id') getBackup(@Param('id') id: string) { return this.svc.getBackupStatus(id); }
  @Post('trigger') @ApiOperation({ summary: 'Trigger manual backup' }) triggerBackup(@CurrentUser() u: JwtPayload) { return this.svc.createBackup(u.sub, 'manual'); }
  @Post('restore') @ApiOperation({ summary: 'Request restore from backup' }) requestRestore(@Body() dto: { backupId: string; reason: string }, @CurrentUser() u: JwtPayload) { return this.svc.requestRestore(dto.backupId, u.sub, dto.reason); }
  @Get('restore/requests') listRestoreRequests() { return this.svc.listRestoreRequests(); }
}

@Module({ controllers: [BackupController], providers: [BackupService], exports: [BackupService] })
export class BackupModule {}
