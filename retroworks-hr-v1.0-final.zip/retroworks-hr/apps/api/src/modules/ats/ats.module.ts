import {
  Controller, Get, Post, Patch, Delete, Body, Param, Query,
  UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { AtsService } from './ats.service';
import type {
  CreateJobDto, UpdateJobDto, CreateCandidateDto, UpdateCandidateStageDto,
  ScheduleInterviewDto, SubmitInterviewFeedbackDto, CreateOfferDto, CandidateQueryDto,
} from './dto/ats.dto';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequirePermission } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import type { JwtPayload } from '@retroworks/types';

@ApiTags('ats')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard, PermissionsGuard)
@Controller('ats')
export class AtsController {
  constructor(private readonly atsService: AtsService) {}

  // ─── Jobs ───
  @Post('jobs')
  @RequirePermission({ resource: 'ats', action: 'create' })
  @ApiOperation({ summary: 'Create a job posting' })
  createJob(@Body() dto: CreateJobDto, @CurrentUser() u: JwtPayload) {
    return this.atsService.createJob(u.tid, dto, u.sub);
  }

  @Get('jobs')
  @RequirePermission({ resource: 'ats', action: 'read' })
  @ApiOperation({ summary: 'List all job postings' })
  listJobs(@Query('status') status: string | undefined, @CurrentUser() u: JwtPayload) {
    return this.atsService.listJobs(u.tid, status);
  }

  @Get('jobs/:jobId')
  @RequirePermission({ resource: 'ats', action: 'read' })
  getJob(@Param('jobId') jobId: string, @CurrentUser() u: JwtPayload) {
    return this.atsService.getJob(u.tid, jobId);
  }

  @Patch('jobs/:jobId')
  @RequirePermission({ resource: 'ats', action: 'update' })
  updateJob(@Param('jobId') jobId: string, @Body() dto: UpdateJobDto, @CurrentUser() u: JwtPayload) {
    return this.atsService.updateJob(u.tid, jobId, dto, u.sub);
  }

  @Post('jobs/:jobId/publish')
  @RequirePermission({ resource: 'ats', action: 'update' })
  publishJob(@Param('jobId') jobId: string, @CurrentUser() u: JwtPayload) {
    return this.atsService.publishJob(u.tid, jobId, u.sub);
  }

  @Post('jobs/:jobId/close')
  @RequirePermission({ resource: 'ats', action: 'update' })
  closeJob(@Param('jobId') jobId: string, @CurrentUser() u: JwtPayload) {
    return this.atsService.closeJob(u.tid, jobId, u.sub);
  }

  @Delete('jobs/:jobId')
  @RequirePermission({ resource: 'ats', action: 'delete' })
  @HttpCode(HttpStatus.NO_CONTENT)
  deleteJob(@Param('jobId') jobId: string, @CurrentUser() u: JwtPayload) {
    return this.atsService.deleteJob(u.tid, jobId, u.sub);
  }

  // ─── Candidates ───
  @Post('candidates')
  @RequirePermission({ resource: 'ats', action: 'create' })
  @ApiOperation({ summary: 'Add a candidate / apply for a job' })
  apply(@Body() dto: CreateCandidateDto, @CurrentUser() u: JwtPayload) {
    return this.atsService.applyForJob(u.tid, dto, u.sub);
  }

  @Get('candidates')
  @RequirePermission({ resource: 'ats', action: 'read' })
  listCandidates(@Query() query: CandidateQueryDto, @CurrentUser() u: JwtPayload) {
    return this.atsService.listCandidates(u.tid, query);
  }

  @Get('candidates/:candidateId')
  @RequirePermission({ resource: 'ats', action: 'read' })
  getCandidate(@Param('candidateId') id: string, @CurrentUser() u: JwtPayload) {
    return this.atsService.getCandidate(u.tid, id);
  }

  @Patch('candidates/:candidateId/stage')
  @RequirePermission({ resource: 'ats', action: 'update' })
  @ApiOperation({ summary: 'Move candidate to a new pipeline stage' })
  moveStage(
    @Param('candidateId') id: string,
    @Body() dto: UpdateCandidateStageDto,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.atsService.moveStage(u.tid, id, dto, u.sub);
  }

  // ─── Interviews ───
  @Post('interviews')
  @RequirePermission({ resource: 'ats', action: 'create' })
  @ApiOperation({ summary: 'Schedule an interview' })
  scheduleInterview(@Body() dto: ScheduleInterviewDto, @CurrentUser() u: JwtPayload) {
    return this.atsService.scheduleInterview(u.tid, dto, u.sub);
  }

  @Post('interviews/:interviewId/feedback')
  @RequirePermission({ resource: 'ats', action: 'create' })
  @ApiOperation({ summary: 'Submit interview feedback' })
  submitFeedback(
    @Param('interviewId') id: string,
    @Body() dto: SubmitInterviewFeedbackDto,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.atsService.submitFeedback(u.tid, id, dto, u.sub);
  }

  // ─── Offers ───
  @Post('offers')
  @RequirePermission({ resource: 'ats', action: 'create' })
  @ApiOperation({ summary: 'Create an offer letter' })
  createOffer(@Body() dto: CreateOfferDto, @CurrentUser() u: JwtPayload) {
    return this.atsService.createOffer(u.tid, dto, u.sub);
  }

  @Post('offers/:offerId/send')
  @RequirePermission({ resource: 'ats', action: 'update' })
  sendOffer(@Param('offerId') id: string, @CurrentUser() u: JwtPayload) {
    return this.atsService.sendOffer(u.tid, id, u.sub);
  }

  @Post('offers/:offerId/respond')
  @ApiOperation({ summary: 'Candidate accepts or declines an offer' })
  respondToOffer(
    @Param('offerId') id: string,
    @Body('response') response: 'accept' | 'decline',
    @CurrentUser() u: JwtPayload,
  ) {
    return this.atsService.respondToOffer(u.tid, id, response, u.sub);
  }

  // ─── Analytics ───
  @Get('analytics/pipeline')
  @RequirePermission({ resource: 'ats', action: 'read' })
  @ApiOperation({ summary: 'Get pipeline funnel statistics' })
  pipelineStats(@Query('jobId') jobId: string | undefined, @CurrentUser() u: JwtPayload) {
    return this.atsService.getPipelineStats(u.tid, jobId);
  }

  @Get('analytics/sources')
  @RequirePermission({ resource: 'ats', action: 'read' })
  @ApiOperation({ summary: 'Get candidate source analytics' })
  sourceAnalytics(@CurrentUser() u: JwtPayload) {
    return this.atsService.getSourceAnalytics(u.tid);
  }
}

@Module({
  controllers: [AtsController],
  providers: [AtsService],
  exports: [AtsService],
})
export class AtsModule {}
