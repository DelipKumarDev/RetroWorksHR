import { Test, type TestingModule } from '@nestjs/testing';
import { NotFoundException, ConflictException, BadRequestException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { AtsService } from '../ats.service';
import { CandidateStage } from '../dto/ats.dto';

const TENANT_ID = 'tenant-123';
const USER_ID = 'user-123';

const mockJob = {
  id: 'job-001',
  tenantId: TENANT_ID,
  title: 'Senior Software Engineer',
  status: 'open',
  openings: 2,
  jobType: 'full-time',
  deletedAt: null,
  department: null, location: null, designation: null,
};

const mockCandidate = {
  id: 'cand-001',
  tenantId: TENANT_ID,
  jobId: 'job-001',
  firstName: 'Rahul',
  lastName: 'Kumar',
  email: 'rahul.kumar@example.com',
  stage: CandidateStage.APPLIED,
  source: 'linkedin',
  stageHistory: [],
  deletedAt: null,
  createdAt: new Date(),
  updatedAt: new Date(),
  job: { id: 'job-001', title: 'Senior Software Engineer', departmentId: null },
};

const mockPrisma = {
  jobPosting: {
    findFirst: jest.fn(),
    findMany: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    updateMany: jest.fn(),
    count: jest.fn(),
  },
  candidate: {
    findFirst: jest.fn(),
    findMany: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    count: jest.fn(),
    groupBy: jest.fn(),
  },
  interview: {
    findFirst: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
  },
  offer: {
    findFirst: jest.fn(),
    create: jest.fn(),
    update: jest.fn(),
    updateMany: jest.fn(),
  },
  $queryRaw: jest.fn(),
};

const mockEvents = { emit: jest.fn() };

describe('AtsService', () => {
  let service: AtsService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        AtsService,
        { provide: 'PrismaClient', useValue: mockPrisma },
        { provide: EventEmitter2, useValue: mockEvents },
      ],
    }).compile();

    service = module.get<AtsService>(AtsService);
    jest.clearAllMocks();
  });

  // ─────────────────────────────────────────────
  // Jobs
  // ─────────────────────────────────────────────

  describe('createJob', () => {
    it('creates a job posting successfully', async () => {
      mockPrisma.jobPosting.create.mockResolvedValue(mockJob);

      const result = await service.createJob(TENANT_ID, {
        title: 'Senior Software Engineer',
        description: 'We are looking for a senior engineer with 5+ years of experience...',
      }, USER_ID);

      expect(mockPrisma.jobPosting.create).toHaveBeenCalled();
      expect(mockEvents.emit).toHaveBeenCalledWith('audit.created', expect.anything());
    });

    it('defaults status to draft', async () => {
      mockPrisma.jobPosting.create.mockImplementation((args: { data: { status: string } }) => Promise.resolve({ ...mockJob, status: args.data.status }));

      await service.createJob(TENANT_ID, {
        title: 'PM Role',
        description: 'Product manager position with 3+ years of experience required',
      }, USER_ID);

      expect(mockPrisma.jobPosting.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ status: 'draft' }) }),
      );
    });
  });

  describe('publishJob', () => {
    it('publishes a draft job', async () => {
      mockPrisma.jobPosting.findFirst.mockResolvedValue({ ...mockJob, status: 'draft' });
      mockPrisma.jobPosting.update.mockResolvedValue({ ...mockJob, status: 'open' });

      const result = await service.publishJob(TENANT_ID, 'job-001', USER_ID);
      expect(mockPrisma.jobPosting.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ status: 'open' }) }),
      );
    });

    it('throws BadRequestException if job already open', async () => {
      mockPrisma.jobPosting.findFirst.mockResolvedValue(mockJob);

      await expect(service.publishJob(TENANT_ID, 'job-001', USER_ID)).rejects.toThrow(BadRequestException);
    });
  });

  // ─────────────────────────────────────────────
  // Candidates
  // ─────────────────────────────────────────────

  describe('applyForJob', () => {
    const dto = {
      firstName: 'Priya',
      lastName: 'Sharma',
      email: 'priya@example.com',
      jobId: 'job-001',
    };

    it('applies successfully', async () => {
      mockPrisma.candidate.findFirst.mockResolvedValue(null); // No duplicate
      mockPrisma.jobPosting.findFirst.mockResolvedValue(mockJob); // Job is open
      mockPrisma.candidate.create.mockResolvedValue({ ...mockCandidate, ...dto });
      mockPrisma.employee.findFirst = jest.fn().mockResolvedValue(null); // In case needed

      await service.applyForJob(TENANT_ID, dto, USER_ID);
      expect(mockPrisma.candidate.create).toHaveBeenCalled();
    });

    it('throws ConflictException for duplicate application', async () => {
      mockPrisma.candidate.findFirst.mockResolvedValue(mockCandidate);

      await expect(service.applyForJob(TENANT_ID, dto, USER_ID)).rejects.toThrow(ConflictException);
    });

    it('throws BadRequestException for closed job', async () => {
      mockPrisma.candidate.findFirst.mockResolvedValue(null);
      mockPrisma.jobPosting.findFirst.mockResolvedValue({ ...mockJob, status: 'closed' });

      await expect(service.applyForJob(TENANT_ID, dto, USER_ID)).rejects.toThrow(BadRequestException);
    });

    it('sets initial stage to APPLIED', async () => {
      mockPrisma.candidate.findFirst.mockResolvedValue(null);
      mockPrisma.jobPosting.findFirst.mockResolvedValue(mockJob);
      mockPrisma.candidate.create.mockImplementation((args: { data: { stage: string } }) =>
        Promise.resolve({ ...mockCandidate, stage: args.data.stage }),
      );

      await service.applyForJob(TENANT_ID, dto, USER_ID);
      expect(mockPrisma.candidate.create).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ stage: CandidateStage.APPLIED }) }),
      );
    });
  });

  // ─────────────────────────────────────────────
  // Stage Movement
  // ─────────────────────────────────────────────

  describe('moveStage', () => {
    beforeEach(() => {
      mockPrisma.candidate.findFirst.mockResolvedValue({
        ...mockCandidate,
        stage: CandidateStage.SCREENING,
        stageHistory: [],
        interviews: [],
        offers: [],
      });
      mockPrisma.candidate.update.mockResolvedValue({ ...mockCandidate, stage: CandidateStage.INTERVIEW_L1 });
    });

    it('moves forward in pipeline successfully', async () => {
      const result = await service.moveStage(
        TENANT_ID, 'cand-001',
        { stage: CandidateStage.INTERVIEW_L1 },
        USER_ID,
      );

      expect(mockPrisma.candidate.update).toHaveBeenCalledWith(
        expect.objectContaining({ data: expect.objectContaining({ stage: CandidateStage.INTERVIEW_L1 }) }),
      );
    });

    it('prevents backward movement in pipeline', async () => {
      await expect(
        service.moveStage(
          TENANT_ID, 'cand-001',
          { stage: CandidateStage.APPLIED }, // Applied is before Screening
          USER_ID,
        ),
      ).rejects.toThrow(BadRequestException);
    });

    it('allows moving to rejected (terminal state) from any stage', async () => {
      mockPrisma.candidate.update.mockResolvedValue({ ...mockCandidate, stage: 'rejected' });

      await expect(
        service.moveStage(TENANT_ID, 'cand-001', { stage: CandidateStage.REJECTED }, USER_ID),
      ).resolves.toBeDefined();
    });

    it('records stage history on movement', async () => {
      await service.moveStage(
        TENANT_ID, 'cand-001',
        { stage: CandidateStage.INTERVIEW_L1, notes: 'Technical skills verified' },
        USER_ID,
      );

      const updateCall = mockPrisma.candidate.update.mock.calls[0][0] as { data: { stageHistory: unknown[] } };
      expect(updateCall.data.stageHistory).toBeInstanceOf(Array);
      expect(updateCall.data.stageHistory.length).toBeGreaterThan(0);
    });
  });

  // ─────────────────────────────────────────────
  // Analytics
  // ─────────────────────────────────────────────

  describe('getPipelineStats', () => {
    it('returns stage counts', async () => {
      mockPrisma.candidate.groupBy.mockResolvedValue([
        { stage: 'applied', _count: { id: 15 } },
        { stage: 'interview-l1', _count: { id: 8 } },
        { stage: 'hired', _count: { id: 3 } },
      ]);
      mockPrisma.jobPosting.count
        .mockResolvedValueOnce(5) // total
        .mockResolvedValueOnce(3); // open
      mockPrisma.$queryRaw.mockResolvedValue([{ avg: 22 }]);

      const stats = await service.getPipelineStats(TENANT_ID);

      expect(stats.summary.totalJobs).toBe(5);
      expect(stats.summary.openJobs).toBe(3);
      expect(stats.summary.hired).toBe(3);
      expect(stats.pipeline.find((s: { stage: string }) => s.stage === 'applied')?.count).toBe(15);
    });
  });
});
