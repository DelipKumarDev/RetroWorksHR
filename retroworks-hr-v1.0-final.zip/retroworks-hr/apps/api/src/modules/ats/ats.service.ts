import {
  Injectable, NotFoundException, ConflictException,
  BadRequestException, Logger,
} from '@nestjs/common';
import { PrismaClient, type Prisma } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import type {
  CreateJobDto, UpdateJobDto, CreateCandidateDto, UpdateCandidateStageDto,
  ScheduleInterviewDto, SubmitInterviewFeedbackDto, CreateOfferDto, CandidateQueryDto,
} from './dto/ats.dto';
import { CandidateStage, OfferStatus } from './dto/ats.dto';

const PIPELINE_STAGES: CandidateStage[] = [
  CandidateStage.APPLIED, CandidateStage.SCREENING, CandidateStage.ASSESSMENT,
  CandidateStage.INTERVIEW_L1, CandidateStage.INTERVIEW_L2, CandidateStage.INTERVIEW_HR,
  CandidateStage.BACKGROUND_CHECK, CandidateStage.OFFER_SENT,
  CandidateStage.OFFER_ACCEPTED, CandidateStage.HIRED,
];

@Injectable()
export class AtsService {
  private readonly logger = new Logger(AtsService.name);

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  // ─────────────────────────────────────────────
  // JOB POSTINGS
  // ─────────────────────────────────────────────

  async createJob(tenantId: string, dto: CreateJobDto, createdBy: string) {
    const job = await this.prisma.jobPosting.create({
      data: {
        tenantId,
        title: dto.title,
        description: dto.description,
        requirements: dto.requirements,
        benefits: dto.benefits,
        departmentId: dto.departmentId,
        locationId: dto.locationId,
        designationId: dto.designationId,
        jobType: dto.jobType ?? 'full-time',
        status: 'draft',
        openings: dto.openings ?? 1,
        minSalary: dto.minSalary,
        maxSalary: dto.maxSalary,
        minExperienceYears: dto.minExperienceYears ?? 0,
        skills: dto.skills ?? [],
        targetCloseDate: dto.targetCloseDate ? new Date(dto.targetCloseDate) : undefined,
        remote: dto.remote ?? false,
        managerId: dto.managerId,
        createdBy,
        updatedBy: createdBy,
      },
      include: this.jobInclude(),
    });

    this.events.emit('audit.created', {
      tenantId, userId: createdBy, action: 'CREATE',
      resource: 'job-posting', resourceId: job.id,
      newData: { title: job.title, status: job.status },
    });

    return job;
  }

  async publishJob(tenantId: string, jobId: string, publishedBy: string) {
    const job = await this.getJob(tenantId, jobId);
    if (job.status === 'open') throw new BadRequestException('Job is already open');

    return this.prisma.jobPosting.update({
      where: { id: jobId },
      data: { status: 'open', publishedAt: new Date(), updatedBy: publishedBy },
      include: this.jobInclude(),
    });
  }

  async closeJob(tenantId: string, jobId: string, closedBy: string) {
    return this.prisma.jobPosting.update({
      where: { id: jobId },
      data: { status: 'closed', updatedBy: closedBy },
      include: this.jobInclude(),
    });
  }

  async listJobs(tenantId: string, status?: string) {
    return this.prisma.jobPosting.findMany({
      where: { tenantId, deletedAt: null, ...(status && { status }) },
      include: {
        ...this.jobInclude(),
        _count: { select: { candidates: true } },
      },
      orderBy: [{ status: 'asc' }, { createdAt: 'desc' }],
    });
  }

  async getJob(tenantId: string, jobId: string) {
    const job = await this.prisma.jobPosting.findFirst({
      where: { id: jobId, tenantId, deletedAt: null },
      include: {
        ...this.jobInclude(),
        _count: { select: { candidates: true } },
      },
    });
    if (!job) throw new NotFoundException('Job posting not found');
    return job;
  }

  async updateJob(tenantId: string, jobId: string, dto: UpdateJobDto, updatedBy: string) {
    await this.getJob(tenantId, jobId);
    return this.prisma.jobPosting.update({
      where: { id: jobId },
      data: { ...dto, updatedBy, updatedAt: new Date() },
      include: this.jobInclude(),
    });
  }

  async deleteJob(tenantId: string, jobId: string, deletedBy: string) {
    await this.getJob(tenantId, jobId);
    await this.prisma.jobPosting.update({
      where: { id: jobId },
      data: { deletedAt: new Date(), updatedBy: deletedBy, status: 'cancelled' },
    });
  }

  // ─────────────────────────────────────────────
  // CANDIDATES
  // ─────────────────────────────────────────────

  async applyForJob(tenantId: string, dto: CreateCandidateDto, createdBy: string) {
    // Check if candidate already applied to this job
    const existing = await this.prisma.candidate.findFirst({
      where: { tenantId, email: dto.email.toLowerCase(), jobId: dto.jobId, deletedAt: null },
    });
    if (existing) {
      throw new ConflictException('This candidate has already applied for this job');
    }

    // Ensure job is open
    const job = await this.getJob(tenantId, dto.jobId);
    if (job.status !== 'open') throw new BadRequestException('This job is not accepting applications');

    const candidate = await this.prisma.candidate.create({
      data: {
        tenantId,
        firstName: dto.firstName.trim(),
        lastName: dto.lastName.trim(),
        email: dto.email.toLowerCase(),
        phone: dto.phone,
        jobId: dto.jobId,
        source: dto.source ?? 'direct',
        referredBy: dto.referredBy,
        currentCompany: dto.currentCompany,
        currentDesignation: dto.currentDesignation,
        currentCTC: dto.currentCTC,
        expectedCTC: dto.expectedCTC,
        noticePeriodDays: dto.noticePeriodDays,
        totalExperienceYears: dto.totalExperienceYears,
        resumeUrl: dto.resumeUrl,
        linkedinUrl: dto.linkedinUrl,
        portfolioUrl: dto.portfolioUrl,
        stage: CandidateStage.APPLIED,
        stageHistory: [{
          stage: CandidateStage.APPLIED,
          movedAt: new Date().toISOString(),
          movedBy: createdBy,
        }],
        createdBy,
        updatedBy: createdBy,
      },
      include: this.candidateInclude(),
    });

    this.events.emit('ats.candidate.applied', {
      tenantId, candidate, job,
    });

    return candidate;
  }

  async listCandidates(tenantId: string, query: CandidateQueryDto) {
    const limit = Math.min(query.limit ?? 25, 100);
    const where: Prisma.CandidateWhereInput = {
      tenantId,
      deletedAt: null,
      ...(query.jobId && { jobId: query.jobId }),
      ...(query.stage && { stage: query.stage }),
      ...(query.search && {
        OR: [
          { firstName: { contains: query.search, mode: 'insensitive' } },
          { lastName: { contains: query.search, mode: 'insensitive' } },
          { email: { contains: query.search, mode: 'insensitive' } },
          { currentCompany: { contains: query.search, mode: 'insensitive' } },
        ],
      }),
      ...(query.cursor && { id: { lt: query.cursor } }),
    };

    const candidates = await this.prisma.candidate.findMany({
      where,
      include: this.candidateInclude(),
      orderBy: { createdAt: 'desc' },
      take: limit + 1,
    });

    const hasMore = candidates.length > limit;
    const data = candidates.slice(0, limit);

    return {
      data,
      hasMore,
      nextCursor: hasMore ? data[data.length - 1]?.id : undefined,
      total: await this.prisma.candidate.count({ where: { tenantId, deletedAt: null } }),
    };
  }

  async getCandidate(tenantId: string, candidateId: string) {
    const candidate = await this.prisma.candidate.findFirst({
      where: { id: candidateId, tenantId, deletedAt: null },
      include: {
        ...this.candidateInclude(),
        interviews: {
          include: {
            interviewers: { select: { id: true, firstName: true, lastName: true, avatarUrl: true } },
          },
          orderBy: { scheduledAt: 'desc' },
        },
        offers: { orderBy: { createdAt: 'desc' } },
      },
    });
    if (!candidate) throw new NotFoundException('Candidate not found');
    return candidate;
  }

  async moveStage(
    tenantId: string,
    candidateId: string,
    dto: UpdateCandidateStageDto,
    movedBy: string,
  ) {
    const candidate = await this.getCandidate(tenantId, candidateId);

    // Validate stage transition
    const currentIdx = PIPELINE_STAGES.indexOf(candidate.stage as CandidateStage);
    const newIdx = PIPELINE_STAGES.indexOf(dto.stage);

    // Allow backward movement to rejected/withdrawn (terminal states)
    const isTerminal = ['rejected', 'withdrawn', 'offer-declined'].includes(dto.stage);
    if (!isTerminal && newIdx < currentIdx) {
      throw new BadRequestException(
        `Cannot move backward from ${candidate.stage} to ${dto.stage}`,
      );
    }

    const history = (candidate.stageHistory as Array<Record<string, unknown>>) ?? [];
    history.push({
      stage: dto.stage,
      movedAt: new Date().toISOString(),
      movedBy,
      notes: dto.notes,
      rejectionReason: dto.rejectionReason,
    });

    const updated = await this.prisma.candidate.update({
      where: { id: candidateId },
      data: {
        stage: dto.stage,
        rejectionReason: dto.rejectionReason,
        stageHistory: history,
        updatedBy: movedBy,
      },
      include: this.candidateInclude(),
    });

    this.events.emit(`ats.candidate.stage-changed`, {
      tenantId, candidate: updated, previousStage: candidate.stage, newStage: dto.stage,
    });

    return updated;
  }

  // ─────────────────────────────────────────────
  // INTERVIEWS
  // ─────────────────────────────────────────────

  async scheduleInterview(
    tenantId: string,
    dto: ScheduleInterviewDto,
    scheduledBy: string,
  ) {
    await this.getCandidate(tenantId, dto.candidateId);

    const interview = await this.prisma.interview.create({
      data: {
        tenantId,
        candidateId: dto.candidateId,
        type: dto.type,
        scheduledAt: new Date(dto.scheduledAt),
        durationMinutes: dto.durationMinutes ?? 60,
        location: dto.location,
        meetingUrl: dto.meetingUrl,
        notes: dto.notes,
        status: 'scheduled',
        interviewerIds: dto.interviewerIds,
        createdBy: scheduledBy,
      },
      include: {
        candidate: { select: { firstName: true, lastName: true, email: true } },
      },
    });

    // Move candidate to appropriate interview stage
    const stageMap: Record<string, CandidateStage> = {
      technical: CandidateStage.INTERVIEW_L1,
      phone: CandidateStage.SCREENING,
      panel: CandidateStage.INTERVIEW_L2,
    };

    const newStage = stageMap[dto.type] ?? CandidateStage.INTERVIEW_L1;
    await this.moveStage(
      tenantId, dto.candidateId,
      { stage: newStage, notes: `${dto.type} interview scheduled` },
      scheduledBy,
    ).catch(() => {}); // Ignore if already past this stage

    this.events.emit('ats.interview.scheduled', { tenantId, interview });

    return interview;
  }

  async submitFeedback(
    tenantId: string,
    interviewId: string,
    dto: SubmitInterviewFeedbackDto,
    submittedBy: string,
  ) {
    const interview = await this.prisma.interview.findFirst({
      where: { id: interviewId, tenantId },
    });
    if (!interview) throw new NotFoundException('Interview not found');

    const feedback = await this.prisma.interview.update({
      where: { id: interviewId },
      data: {
        feedback: {
          rating: dto.rating,
          recommendation: dto.recommendation,
          strengths: dto.strengths,
          concerns: dto.concerns,
          overallComments: dto.overallComments,
          submittedBy,
          submittedAt: new Date().toISOString(),
        },
        status: 'completed',
      },
    });

    this.events.emit('ats.interview.feedback-submitted', {
      tenantId, interviewId, recommendation: dto.recommendation,
    });

    return feedback;
  }

  // ─────────────────────────────────────────────
  // OFFERS
  // ─────────────────────────────────────────────

  async createOffer(tenantId: string, dto: CreateOfferDto, createdBy: string) {
    const candidate = await this.getCandidate(tenantId, dto.candidateId);

    // Void any existing active offers
    await this.prisma.offer.updateMany({
      where: { tenantId, candidateId: dto.candidateId, status: { in: ['draft', 'sent'] } },
      data: { status: 'revoked' },
    });

    const offer = await this.prisma.offer.create({
      data: {
        tenantId,
        candidateId: dto.candidateId,
        jobId: candidate.jobId,
        ctc: dto.ctc,
        proposedJoiningDate: new Date(dto.proposedJoiningDate),
        expiresAt: new Date(dto.expiresAt),
        designationId: dto.designationId,
        departmentId: dto.departmentId,
        locationId: dto.locationId,
        customTerms: dto.customTerms,
        status: OfferStatus.DRAFT,
        createdBy,
      },
      include: {
        candidate: { select: { firstName: true, lastName: true, email: true } },
      },
    });

    return offer;
  }

  async sendOffer(tenantId: string, offerId: string, sentBy: string) {
    const offer = await this.prisma.offer.findFirst({ where: { id: offerId, tenantId } });
    if (!offer) throw new NotFoundException('Offer not found');
    if (offer.status !== 'draft') throw new BadRequestException('Only draft offers can be sent');

    const updated = await this.prisma.offer.update({
      where: { id: offerId },
      data: { status: OfferStatus.SENT, sentAt: new Date() },
    });

    // Move candidate to offer-sent stage
    await this.moveStage(
      tenantId, offer.candidateId,
      { stage: CandidateStage.OFFER_SENT, notes: 'Offer letter sent' },
      sentBy,
    ).catch(() => {});

    this.events.emit('ats.offer.sent', { tenantId, offer: updated });

    return updated;
  }

  async respondToOffer(
    tenantId: string,
    offerId: string,
    response: 'accept' | 'decline',
    respondedBy: string,
  ) {
    const offer = await this.prisma.offer.findFirst({ where: { id: offerId, tenantId } });
    if (!offer) throw new NotFoundException('Offer not found');
    if (offer.status !== 'sent') throw new BadRequestException('Offer is not in sent state');
    if (new Date() > offer.expiresAt) throw new BadRequestException('Offer has expired');

    const status = response === 'accept' ? OfferStatus.ACCEPTED : OfferStatus.DECLINED;
    const updated = await this.prisma.offer.update({
      where: { id: offerId },
      data: { status, respondedAt: new Date() },
    });

    const stage = response === 'accept' ? CandidateStage.OFFER_ACCEPTED : CandidateStage.OFFER_DECLINED;
    await this.moveStage(tenantId, offer.candidateId, { stage }, respondedBy).catch(() => {});

    if (response === 'accept') {
      // Trigger onboarding workflow
      this.events.emit('ats.offer.accepted', { tenantId, offer: updated, candidateId: offer.candidateId });
    }

    return updated;
  }

  // ─────────────────────────────────────────────
  // ANALYTICS
  // ─────────────────────────────────────────────

  async getPipelineStats(tenantId: string, jobId?: string) {
    const where: Prisma.CandidateWhereInput = {
      tenantId, deletedAt: null,
      ...(jobId && { jobId }),
    };

    const [byStage, totalJobs, openJobs, avgTimeToHire] = await Promise.all([
      // Count by stage
      this.prisma.candidate.groupBy({
        by: ['stage'],
        where,
        _count: { id: true },
      }),
      // Total jobs
      this.prisma.jobPosting.count({ where: { tenantId, deletedAt: null } }),
      // Open jobs
      this.prisma.jobPosting.count({ where: { tenantId, status: 'open', deletedAt: null } }),
      // Time to hire (avg days from applied to hired)
      this.prisma.$queryRaw<Array<{ avg: number }>>`
        SELECT AVG(EXTRACT(EPOCH FROM (updated_at - created_at)) / 86400) as avg
        FROM candidates
        WHERE tenant_id = ${tenantId} AND stage = 'hired' AND deleted_at IS NULL
      `,
    ]);

    const stageCounts = Object.fromEntries(
      byStage.map(s => [s.stage, s._count.id]),
    );

    return {
      pipeline: PIPELINE_STAGES.map(stage => ({
        stage,
        count: stageCounts[stage] ?? 0,
      })),
      summary: {
        totalJobs,
        openJobs,
        totalCandidates: Object.values(stageCounts).reduce((a, b) => a + b, 0),
        hired: stageCounts['hired'] ?? 0,
        avgTimeToHireDays: Math.round(avgTimeToHire[0]?.avg ?? 0),
      },
    };
  }

  async getSourceAnalytics(tenantId: string) {
    const bySource = await this.prisma.candidate.groupBy({
      by: ['source', 'stage'],
      where: { tenantId, deletedAt: null },
      _count: { id: true },
    });

    const sources = new Map<string, { total: number; hired: number }>();
    for (const row of bySource) {
      const src = row.source ?? 'direct';
      const entry = sources.get(src) ?? { total: 0, hired: 0 };
      entry.total += row._count.id;
      if (row.stage === 'hired') entry.hired += row._count.id;
      sources.set(src, entry);
    }

    return Array.from(sources.entries()).map(([source, stats]) => ({
      source,
      ...stats,
      conversionRate: stats.total > 0 ? ((stats.hired / stats.total) * 100).toFixed(1) + '%' : '0%',
    }));
  }

  // ─────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────

  private jobInclude() {
    return {
      department: { select: { id: true, name: true } },
      location: { select: { id: true, name: true, city: true } },
      designation: { select: { id: true, name: true } },
    } as const;
  }

  private candidateInclude() {
    return {
      job: { select: { id: true, title: true, departmentId: true } },
    } as const;
  }
}
