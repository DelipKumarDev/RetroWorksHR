import {
  Injectable, NotFoundException, BadRequestException, ConflictException, Logger,
} from '@nestjs/common';
import { PrismaClient, type Prisma } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import {
  IsString, IsOptional, IsEnum, IsDateString, IsNumber, IsInt, Min,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  Controller, Get, Post, Patch, Body, Param, Query,
  UseGuards,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── DTOs ───────────────────────────────────────────────────

export class PunchInDto {
  @ApiPropertyOptional({ description: 'Location coordinates' })
  @IsOptional()
  @IsNumber()
  latitude?: number;

  @IsOptional()
  @IsNumber()
  longitude?: number;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  note?: string;

  @ApiPropertyOptional({ description: 'Override timestamp (HR only)' })
  @IsOptional()
  @IsDateString()
  timestamp?: string;
}

export class PunchOutDto {
  @IsOptional()
  @IsNumber()
  latitude?: number;

  @IsOptional()
  @IsNumber()
  longitude?: number;

  @IsOptional()
  @IsString()
  note?: string;

  @IsOptional()
  @IsDateString()
  timestamp?: string;
}

export class RegularisationRequestDto {
  @ApiProperty({ example: '2024-03-10' })
  @IsDateString()
  date: string;

  @ApiProperty({ description: 'Correct punch-in time' })
  @IsDateString()
  punchIn: string;

  @ApiProperty({ description: 'Correct punch-out time' })
  @IsDateString()
  punchOut: string;

  @ApiProperty({ description: 'Reason for regularisation' })
  @IsString()
  reason: string;
}

export class AttendanceQueryDto {
  @IsOptional()
  @IsString()
  employeeId?: string;

  @IsOptional()
  @IsDateString()
  from?: string;

  @IsOptional()
  @IsDateString()
  to?: string;

  @IsOptional()
  @IsString()
  departmentId?: string;

  @IsOptional()
  limit?: number;
}

// ─── Service ───────────────────────────────────────────────

@Injectable()
export class AttendanceService {
  private readonly logger = new Logger(AttendanceService.name);
  private readonly GRACE_PERIOD_MINUTES = 15;

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
  ) {}

  async punchIn(tenantId: string, dto: PunchInDto, userId: string) {
    const now = dto.timestamp ? new Date(dto.timestamp) : new Date();
    const dateStr = now.toISOString().slice(0, 10);

    // Check not already punched in today
    const existing = await this.prisma.attendanceRecord.findFirst({
      where: {
        tenantId, employeeId: userId,
        date: { gte: new Date(dateStr), lt: new Date(new Date(dateStr).getTime() + 86_400_000) },
      },
    });

    if (existing && !existing.punchOut) {
      throw new ConflictException('Already punched in. Please punch out first.');
    }

    const record = await this.prisma.attendanceRecord.create({
      data: {
        tenantId,
        employeeId: userId,
        date: new Date(dateStr),
        punchIn: now,
        punchInLatitude: dto.latitude,
        punchInLongitude: dto.longitude,
        punchInNote: dto.note,
        status: 'present',
        source: dto.timestamp ? 'manual' : 'web',
        createdBy: userId,
        updatedBy: userId,
      },
    });

    this.events.emit('attendance.punch-in', { tenantId, record, userId });

    return record;
  }

  async punchOut(tenantId: string, dto: PunchOutDto, userId: string) {
    const now = dto.timestamp ? new Date(dto.timestamp) : new Date();
    const today = now.toISOString().slice(0, 10);

    const record = await this.prisma.attendanceRecord.findFirst({
      where: {
        tenantId, employeeId: userId,
        date: { gte: new Date(today), lt: new Date(new Date(today).getTime() + 86_400_000) },
        punchOut: null,
      },
      orderBy: { punchIn: 'desc' },
    });

    if (!record) throw new NotFoundException('No active punch-in found for today');

    const workedMinutes = Math.floor((now.getTime() - record.punchIn!.getTime()) / 60_000);
    const workedHours = workedMinutes / 60;
    const isHalfDay = workedHours < 4;

    const updated = await this.prisma.attendanceRecord.update({
      where: { id: record.id },
      data: {
        punchOut: now,
        punchOutLatitude: dto.latitude,
        punchOutLongitude: dto.longitude,
        punchOutNote: dto.note,
        totalMinutes: workedMinutes,
        status: isHalfDay ? 'half-day' : 'present',
        updatedBy: userId,
      },
    });

    return updated;
  }

  async getMyAttendance(tenantId: string, employeeId: string, query: AttendanceQueryDto) {
    const from = query.from ? new Date(query.from) : new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    const to = query.to ? new Date(query.to) : new Date();

    const records = await this.prisma.attendanceRecord.findMany({
      where: {
        tenantId,
        employeeId,
        date: { gte: from, lte: to },
      },
      orderBy: { date: 'desc' },
    });

    // Calculate summary
    const summary = {
      present: 0, absent: 0, halfDay: 0, late: 0,
      totalHours: 0, avgHours: 0,
    };

    for (const r of records) {
      if (r.status === 'present') summary.present++;
      else if (r.status === 'absent') summary.absent++;
      else if (r.status === 'half-day') summary.halfDay++;
      if (r.isLate) summary.late++;
      summary.totalHours += (r.totalMinutes ?? 0) / 60;
    }

    summary.avgHours = records.length > 0
      ? Math.round((summary.totalHours / records.length) * 10) / 10
      : 0;

    return { records, summary };
  }

  async getTodayStatus(tenantId: string, employeeId: string) {
    const today = new Date().toISOString().slice(0, 10);
    const record = await this.prisma.attendanceRecord.findFirst({
      where: {
        tenantId, employeeId,
        date: { gte: new Date(today), lt: new Date(new Date(today).getTime() + 86_400_000) },
      },
      orderBy: { punchIn: 'desc' },
    });

    const now = new Date();
    return {
      status: record ? (record.punchOut ? 'punched-out' : 'punched-in') : 'not-started',
      punchIn: record?.punchIn,
      punchOut: record?.punchOut,
      totalMinutes: record?.punchOut
        ? record.totalMinutes
        : record?.punchIn
          ? Math.floor((now.getTime() - record.punchIn.getTime()) / 60_000)
          : 0,
    };
  }

  async requestRegularisation(
    tenantId: string,
    dto: RegularisationRequestDto,
    employeeId: string,
  ) {
    const dateStr = dto.date;
    const punchIn = new Date(dto.punchIn);
    const punchOut = new Date(dto.punchOut);

    if (punchOut <= punchIn) {
      throw new BadRequestException('Punch-out must be after punch-in');
    }

    // Upsert the attendance record
    const workedMinutes = Math.floor((punchOut.getTime() - punchIn.getTime()) / 60_000);

    const record = await this.prisma.attendanceRecord.upsert({
      where: {
        tenantId_employeeId_date: { tenantId, employeeId, date: new Date(dateStr) },
      } as never,
      update: {
        regularisationStatus: 'pending',
        regularisationReason: dto.reason,
        regularisedPunchIn: punchIn,
        regularisedPunchOut: punchOut,
      },
      create: {
        tenantId,
        employeeId,
        date: new Date(dateStr),
        punchIn,
        punchOut,
        totalMinutes: workedMinutes,
        status: 'regularised',
        source: 'regularisation',
        regularisationStatus: 'pending',
        regularisationReason: dto.reason,
        createdBy: employeeId,
        updatedBy: employeeId,
      },
    });

    return record;
  }

  async getTeamAttendance(
    tenantId: string,
    managerId: string,
    date?: string,
  ) {
    const dateStr = date ?? new Date().toISOString().slice(0, 10);
    const targetDate = new Date(dateStr);

    // Get direct reports
    const directReports = await this.prisma.employee.findMany({
      where: { tenantId, managerId, status: 'active', deletedAt: null },
      select: { id: true, firstName: true, lastName: true, avatarUrl: true, employeeCode: true },
    });

    const empIds = directReports.map(e => e.id);

    const records = await this.prisma.attendanceRecord.findMany({
      where: {
        tenantId,
        employeeId: { in: empIds },
        date: {
          gte: targetDate,
          lt: new Date(targetDate.getTime() + 86_400_000),
        },
      },
    });

    const byEmployee = new Map(records.map(r => [r.employeeId, r]));

    return directReports.map(emp => ({
      employee: emp,
      record: byEmployee.get(emp.id) ?? null,
      status: byEmployee.get(emp.id)
        ? byEmployee.get(emp.id)!.punchOut ? 'punched-out' : 'punched-in'
        : 'absent',
    }));
  }
}

// ─── Controller ───────────────────────────────────────────

@ApiTags('attendance')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('attendance')
export class AttendanceController {
  constructor(private readonly attendanceService: AttendanceService) {}

  @Post('punch-in')
  @ApiOperation({ summary: 'Mark punch-in for today' })
  punchIn(@Body() dto: PunchInDto, @CurrentUser() u: JwtPayload) {
    return this.attendanceService.punchIn(u.tid, dto, u.sub);
  }

  @Post('punch-out')
  @ApiOperation({ summary: 'Mark punch-out for today' })
  punchOut(@Body() dto: PunchOutDto, @CurrentUser() u: JwtPayload) {
    return this.attendanceService.punchOut(u.tid, dto, u.sub);
  }

  @Get('today')
  @ApiOperation({ summary: "Get today's attendance status" })
  todayStatus(@CurrentUser() u: JwtPayload) {
    return this.attendanceService.getTodayStatus(u.tid, u.sub);
  }

  @Get('my')
  @ApiOperation({ summary: 'Get my attendance records' })
  myAttendance(@Query() query: AttendanceQueryDto, @CurrentUser() u: JwtPayload) {
    return this.attendanceService.getMyAttendance(u.tid, u.sub, query);
  }

  @Get('employee/:employeeId')
  @Roles('manager', 'hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Get attendance for a specific employee' })
  employeeAttendance(
    @Param('employeeId') empId: string,
    @Query() query: AttendanceQueryDto,
    @CurrentUser() u: JwtPayload,
  ) {
    return this.attendanceService.getMyAttendance(u.tid, empId, query);
  }

  @Post('regularise')
  @ApiOperation({ summary: 'Request attendance regularisation' })
  regularise(@Body() dto: RegularisationRequestDto, @CurrentUser() u: JwtPayload) {
    return this.attendanceService.requestRegularisation(u.tid, dto, u.sub);
  }

  @Get('team')
  @Roles('manager', 'hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Get team attendance for a date' })
  teamAttendance(@Query('date') date: string | undefined, @CurrentUser() u: JwtPayload) {
    return this.attendanceService.getTeamAttendance(u.tid, u.sub, date);
  }
}

@Module({
  controllers: [AttendanceController],
  providers: [AttendanceService],
  exports: [AttendanceService],
})
export class AttendanceModule {}
