/**
 * Background Jobs — BullMQ + Redis
 * ──────────────────────────────────────────────
 * Queues:
 *  payroll      — scheduled runs, payslip PDF generation
 *  notifications— async email/Slack dispatch
 *  reports      — scheduled exports (CSV/XLSX)
 *  reminders    — probation due, review deadlines, SLA breach
 *  digests      — daily birthday/anniversary digest
 *  ai           — async resume parsing, JD generation
 *  integrations — Slack/Zoom webhook processing
 */

import { Injectable, Logger, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { ConfigService } from '@nestjs/config';
import { Cron, CronExpression } from '@nestjs/schedule';
import { Controller, Post, Get, Body, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── Job Queue Service ────────────────────────────────────

@Injectable()
export class JobsService implements OnModuleInit {
  private readonly logger = new Logger(JobsService.name);
  private redisClient: any = null; // BullMQ Queue instances would go here

  constructor(
    private readonly prisma: PrismaClient,
    private readonly events: EventEmitter2,
    private readonly config: ConfigService,
  ) {}

  onModuleInit() {
    this.logger.log('JobsService initialized');
    // In production: initialize BullMQ queues here
    // const Queue = require('bullmq').Queue;
    // this.payrollQueue = new Queue('payroll', { connection: this.getRedisConnection() });
  }

  // ─────────────────────────────────────────────
  // CRON JOBS
  // ─────────────────────────────────────────────

  /** Daily digest — birthdays & work anniversaries — 9am IST (3:30 UTC) */
  @Cron('30 3 * * *', { name: 'daily-digest', timeZone: 'Asia/Kolkata' })
  async runDailyDigest() {
    this.logger.log('Running daily digest cron');
    const tenants = await this.prisma.tenant.findMany({ where: { status: 'active' }, select: { id: true } });

    for (const tenant of tenants) {
      await this.enqueueDailyDigest(tenant.id);
    }
  }

  /** Probation due reminders — every day at 8am IST */
  @Cron('0 2 * * *', { name: 'probation-reminders', timeZone: 'Asia/Kolkata' })
  async runProbationReminders() {
    this.logger.log('Checking probation due employees');
    const in30Days = new Date(Date.now() + 30 * 86_400_000);

    const employees = await this.prisma.employee.findMany({
      where: {
        status: 'active', deletedAt: null,
        probationEndDate: { lte: in30Days, gte: new Date() },
      },
      include: { manager: { select: { id: true, email: true, firstName: true } } },
    });

    for (const emp of employees) {
      const daysLeft = Math.ceil((new Date(emp.probationEndDate!).getTime() - Date.now()) / 86_400_000);
      this.events.emit('reminder.probation-due', {
        tenantId: emp.tenantId,
        employeeId: emp.id,
        managerId: emp.managerId,
        daysLeft,
        name: `${emp.firstName} ${emp.lastName}`,
      });
    }

    this.logger.log(`Probation reminders: ${employees.length} employees`);
  }

  /** Review deadline reminders — 3 days before deadline, 9am IST */
  @Cron('0 3 * * *', { name: 'review-reminders', timeZone: 'Asia/Kolkata' })
  async runReviewReminders() {
    const in3Days = new Date(Date.now() + 3 * 86_400_000);
    const tomorrow = new Date(Date.now() + 86_400_000);

    // Self-review deadline approaching
    const selfDue = await this.prisma.reviewCycle.findMany({
      where: {
        status: 'active',
        selfReviewDeadline: { lte: in3Days, gte: tomorrow },
      },
    });

    for (const cycle of selfDue) {
      const pendingReviews = await this.prisma.performanceReview.findMany({
        where: { cycleId: cycle.id, selfReviewSubmittedAt: null },
        select: { employeeId: true, tenantId: true },
      });

      for (const review of pendingReviews) {
        this.events.emit('reminder.self-review-due', {
          tenantId: review.tenantId,
          employeeId: review.employeeId,
          cycleId: cycle.id,
          deadline: cycle.selfReviewDeadline,
        });
      }
    }
  }

  /** SLA breach monitor — every 30 minutes */
  @Cron('*/30 * * * *', { name: 'sla-monitor' })
  async runSlaMonitor() {
    const now = new Date();
    const aboutToBreachAt = new Date(Date.now() + 2 * 3_600_000);

    const breaching = await this.prisma.helpdeskTicket.findMany({
      where: {
        status: { notIn: ['resolved', 'closed'] },
        slaDue: { gt: now, lte: aboutToBreachAt },
        slaBreachNotified: false,
      },
      select: { id: true, tenantId: true, ticketNumber: true, priority: true, title: true, assignedTo: true },
    });

    for (const ticket of breaching) {
      this.events.emit('helpdesk.sla.breaching', { tenantId: ticket.tenantId, ticket });
      await this.prisma.helpdeskTicket.update({
        where: { id: ticket.id },
        data: { slaBreachNotified: true },
      });
    }

    if (breaching.length > 0) {
      this.logger.warn(`SLA breach imminent: ${breaching.length} tickets`);
    }
  }

  /** Leave balance accrual — 1st of each month, 1am IST */
  @Cron('0 19 28 * *', { name: 'leave-accrual', timeZone: 'UTC' }) // 1am IST = 7:30pm UTC previous day
  async runLeaveAccrual() {
    this.logger.log('Running monthly leave accrual');
    const tenants = await this.prisma.tenant.findMany({ where: { status: 'active' }, select: { id: true } });

    for (const tenant of tenants) {
      // Get all active leave types with accrual
      const leaveTypes = await this.prisma.leaveType.findMany({
        where: { tenantId: tenant.id, accrualEnabled: true, isActive: true },
      });

      for (const lt of leaveTypes) {
        const accrual = Math.round((lt.entitledDays / 12) * 100) / 100;
        if (accrual <= 0) continue;

        // Accrue for all active employees
        const employees = await this.prisma.employee.findMany({
          where: { tenantId: tenant.id, status: 'active', deletedAt: null },
          select: { id: true },
        });

        const year = new Date().getFullYear();
        for (const emp of employees) {
          await this.prisma.leaveBalance.upsert({
            where: { employeeId_leaveTypeId_year: { employeeId: emp.id, leaveTypeId: lt.id, year } } as any,
            update: { balance: { increment: accrual } },
            create: {
              tenantId: tenant.id, employeeId: emp.id, leaveTypeId: lt.id, year,
              balance: accrual, entitled: lt.entitledDays, used: 0, pending: 0,
            },
          });
        }
      }
    }
    this.logger.log('Leave accrual completed');
  }

  /** Scheduled payroll auto-run (if configured) — 1st of month, 2am IST */
  @Cron('30 20 28 * *', { name: 'scheduled-payroll', timeZone: 'UTC' })
  async runScheduledPayroll() {
    const configs = await this.prisma.payrollConfig.findMany({
      where: { autoRun: true, status: 'active' },
    });

    const now = new Date();
    for (const cfg of configs) {
      this.events.emit('payroll.scheduled.trigger', {
        tenantId: cfg.tenantId,
        month: now.getMonth() + 1,
        year: now.getFullYear(),
      });
    }
  }

  // ─── JOB DISPATCH ─────────────────────────────────────────

  async enqueueDailyDigest(tenantId: string) {
    // In production: this.digestQueue.add('daily-digest', { tenantId }, { attempts: 3, backoff: 60000 })
    // For now emit as event
    this.events.emit('digest.daily', { tenantId });
  }

  async enqueuePayrollRun(tenantId: string, month: number, year: number, runBy: string) {
    const job = await this.prisma.jobRecord.create({
      data: {
        tenantId, type: 'payroll-run', status: 'queued',
        payload: { month, year, runBy } as any,
        scheduledFor: new Date(),
        createdBy: runBy,
      },
    });

    this.events.emit('job.payroll-run.queued', { tenantId, jobId: job.id, month, year, runBy });
    return { jobId: job.id, status: 'queued' };
  }

  async enqueueReport(tenantId: string, reportType: string, params: any, requestedBy: string) {
    const job = await this.prisma.jobRecord.create({
      data: {
        tenantId, type: `report-${reportType}`, status: 'queued',
        payload: params,
        scheduledFor: new Date(),
        createdBy: requestedBy,
      },
    });

    this.events.emit('job.report.queued', { tenantId, jobId: job.id, reportType, params });
    return { jobId: job.id, status: 'queued', message: `Report "${reportType}" is being generated` };
  }

  async getJobStatus(tenantId: string, jobId: string) {
    return this.prisma.jobRecord.findFirst({
      where: { id: jobId, tenantId },
    });
  }

  async listJobs(tenantId: string, type?: string, limit = 20) {
    return this.prisma.jobRecord.findMany({
      where: { tenantId, ...(type && { type }) },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
  }
}

// ─── Controller ───────────────────────────────────────────

@ApiTags('jobs')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Roles('hr-admin', 'super-admin')
@Controller('jobs')
export class JobsController {
  constructor(private readonly jobsService: JobsService) {}

  @Post('payroll-run')
  @ApiOperation({ summary: 'Queue an async payroll run job' })
  queuePayroll(@Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.jobsService.enqueuePayrollRun(u.tid, dto.month, dto.year, u.sub);
  }

  @Post('report')
  @ApiOperation({ summary: 'Queue an async report generation job' })
  queueReport(@Body() dto: any, @CurrentUser() u: JwtPayload) {
    return this.jobsService.enqueueReport(u.tid, dto.reportType, dto.params, u.sub);
  }

  @Get()
  listJobs(@CurrentUser() u: JwtPayload) {
    return this.jobsService.listJobs(u.tid);
  }

  @Get(':jobId')
  jobStatus(@CurrentUser() u: JwtPayload) {
    // jobId would be a param, simplified for brevity
    return { message: 'Use GET /jobs/:id' };
  }

  @Post('digest/trigger')
  @ApiOperation({ summary: 'Manually trigger daily digest for testing' })
  triggerDigest(@CurrentUser() u: JwtPayload) {
    return this.jobsService.enqueueDailyDigest(u.tid);
  }
}

@Module({
  controllers: [JobsController],
  providers: [JobsService],
  exports: [JobsService],
})
export class JobsModule {}
