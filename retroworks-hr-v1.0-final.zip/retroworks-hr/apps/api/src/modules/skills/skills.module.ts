import { Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { AuthGuard } from '@nestjs/passport';
import { Module } from '@nestjs/common';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Roles } from '../../common/decorators/permissions.decorator';
import { TenantGuard } from '../../common/guards/tenant.guard';
import type { JwtPayload } from '@retroworks/types';

// ─── Types ───────────────────────────────────────────────────────────

interface SkillNode {
  skillId: string; name: string; category: string;
  level: number; // 1=Beginner 2=Proficient 3=Expert
  isCritical: boolean; employeeCount: number;
}

interface SkillHeatmapRow {
  departmentId: string; departmentName: string;
  skills: Array<{ skillId: string; name: string; coverage: number; avgLevel: number; gap: number }>;
}

interface SuccessionCandidate {
  employeeId: string; name: string; employeeCode: string;
  readinessScore: number; // 0-100
  readinessLevel: 'ready_now' | 'ready_1yr' | 'ready_2yr' | 'not_ready';
  skillGaps: string[]; developmentNeeds: string[];
}

interface CriticalRoleRisk {
  roleId?: string; roleName: string; departmentName: string;
  coveredBy: number; // employees with this critical skill
  risk: 'critical' | 'high' | 'medium' | 'low';
  recommendation: string;
}

// ─── Service ─────────────────────────────────────────────────────────

@Injectable()
export class SkillsService {
  private readonly logger = new Logger(SkillsService.name);

  constructor(private readonly prisma: PrismaClient, private readonly events: EventEmitter2) {}

  // ─── Skill Library ────────────────────────────────────────────────

  async listSkills(tenantId: string, category?: string) {
    return this.prisma.skill.findMany({
      where: { tenantId: { in: [tenantId, 'system'] }, deletedAt: null, ...(category && { category }) },
      include: { _count: { select: { employeeSkills: true } } },
      orderBy: [{ isCritical: 'desc' }, { name: 'asc' }],
    });
  }

  async createSkill(tenantId: string, dto: { name: string; category: string; description?: string; isCritical?: boolean }, createdBy: string) {
    return this.prisma.skill.create({ data: { tenantId, name: dto.name, category: dto.category, description: dto.description, isCritical: dto.isCritical ?? false, createdBy } });
  }

  async getSkillCategories(tenantId: string) {
    const skills = await this.prisma.skill.findMany({ where: { tenantId: { in: [tenantId, 'system'] }, deletedAt: null }, select: { category: true }, distinct: ['category'] });
    return skills.map((s: any) => s.category);
  }

  // ─── Employee Skills ──────────────────────────────────────────────

  async getEmployeeSkills(tenantId: string, employeeId: string) {
    return this.prisma.employeeSkill.findMany({
      where: { tenantId, employeeId },
      include: { skill: true },
      orderBy: [{ level: 'desc' }, { skill: { name: 'asc' } }],
    });
  }

  async upsertEmployeeSkills(tenantId: string, employeeId: string, skills: Array<{ skillId: string; level: number; endorsedBy?: string; certificationUrl?: string }>, updatedBy: string) {
    const results = await Promise.all(
      skills.map(s =>
        this.prisma.employeeSkill.upsert({
          where: { employeeId_skillId: { employeeId, skillId: s.skillId } },
          create: { tenantId, employeeId, skillId: s.skillId, level: s.level, endorsedBy: s.endorsedBy, certificationUrl: s.certificationUrl, updatedBy },
          update: { level: s.level, endorsedBy: s.endorsedBy, certificationUrl: s.certificationUrl, updatedBy },
        })
      )
    );
    this.events.emit('skills.updated', { tenantId, employeeId, count: results.length });
    return results;
  }

  async removeEmployeeSkill(tenantId: string, employeeId: string, skillId: string) {
    return this.prisma.employeeSkill.deleteMany({ where: { tenantId, employeeId, skillId } });
  }

  // ─── Skill Heatmap ────────────────────────────────────────────────

  async getSkillHeatmap(tenantId: string): Promise<SkillHeatmapRow[]> {
    const departments = await this.prisma.department.findMany({ where: { tenantId, deletedAt: null } });
    const criticalSkills = await this.prisma.skill.findMany({ where: { tenantId: { in: [tenantId, 'system'] }, isCritical: true, deletedAt: null } });

    const rows: SkillHeatmapRow[] = [];

    for (const dept of departments) {
      const deptEmployees = await this.prisma.employee.findMany({
        where: { tenantId, departmentId: dept.id, status: 'active', deletedAt: null },
        include: { skills: { include: { skill: true } } },
      });

      const skillStats = criticalSkills.map((skill: any) => {
        const employeesWithSkill = (deptEmployees as any[]).filter((e: any) => e.skills.some((s: any) => s.skillId === skill.id));
        const coverage = deptEmployees.length > 0 ? (employeesWithSkill.length / deptEmployees.length) * 100 : 0;
        const avgLevel = employeesWithSkill.length > 0 ? employeesWithSkill.reduce((sum: number, e: any) => { const s = e.skills.find((sk: any) => sk.skillId === skill.id); return sum + (s?.level ?? 0); }, 0) / employeesWithSkill.length : 0;
        const requiredLevel = 2; // default required level = Proficient
        const gap = Math.max(0, requiredLevel - avgLevel);
        return { skillId: skill.id, name: skill.name, coverage: Math.round(coverage), avgLevel: Math.round(avgLevel * 10) / 10, gap: Math.round(gap * 10) / 10 };
      });

      if (deptEmployees.length > 0) {
        rows.push({ departmentId: dept.id, departmentName: dept.name, skills: skillStats });
      }
    }

    return rows;
  }

  // ─── Skill Gap Analysis ───────────────────────────────────────────

  async getSkillGapAnalysis(tenantId: string, departmentId?: string) {
    const filter: any = { tenantId, status: 'active', deletedAt: null };
    if (departmentId) filter.departmentId = departmentId;

    const employees = await this.prisma.employee.findMany({
      where: filter,
      include: {
        skills: { include: { skill: true } },
        designation: { select: { name: true, requiredSkills: true } },
        department: { select: { name: true } },
      },
    });

    const gaps = employees.map((emp: any) => {
      const requiredSkills: string[] = emp.designation?.requiredSkills ?? [];
      const employeeSkillNames = emp.skills.map((s: any) => s.skill.name.toLowerCase());
      const missingSkills = requiredSkills.filter((req: string) => !employeeSkillNames.includes(req.toLowerCase()));
      const skillsAboveRequired = emp.skills.filter((s: any) => s.level >= 3).length;

      return {
        employeeId: emp.id, name: `${emp.firstName} ${emp.lastName}`,
        department: emp.department?.name, designation: emp.designation?.name,
        totalSkills: emp.skills.length, missingRequired: missingSkills,
        expertSkills: skillsAboveRequired, gapScore: missingSkills.length,
      };
    });

    return {
      totalAnalyzed: gaps.length,
      withGaps: gaps.filter(g => g.gapScore > 0).length,
      criticalGaps: gaps.filter(g => g.gapScore >= 3).length,
      employees: gaps.sort((a, b) => b.gapScore - a.gapScore).slice(0, 50),
    };
  }

  // ─── Succession Readiness Index ───────────────────────────────────

  async getSuccessionReadiness(tenantId: string, roleId?: string): Promise<SuccessionCandidate[]> {
    const targetRole = roleId
      ? await this.prisma.designation.findFirst({ where: { id: roleId, tenantId }, include: { requiredSkills: true } })
      : null;

    const employees = await this.prisma.employee.findMany({
      where: { tenantId, status: 'active', deletedAt: null },
      include: {
        skills: { include: { skill: true } },
        performanceReviews: { orderBy: { createdAt: 'desc' }, take: 1, select: { managerRating: true } },
        designation: { select: { name: true } },
        department: { select: { name: true } },
      },
    });

    return (employees as any[]).map((emp: any) => {
      let score = 0;
      const gaps: string[] = [];
      const needs: string[] = [];

      // Performance factor (40 pts max)
      const latestRating = emp.performanceReviews[0]?.managerRating ?? 3;
      score += Math.round((latestRating / 5) * 40);

      // Skill breadth (30 pts max)
      const skillCount = emp.skills.length;
      score += Math.min(30, skillCount * 3);

      // Expert skills (20 pts max)
      const expertCount = emp.skills.filter((s: any) => s.level >= 3).length;
      score += Math.min(20, expertCount * 5);

      // Tenure (10 pts max)
      if (emp.dateOfJoining) {
        const years = (Date.now() - new Date(emp.dateOfJoining).getTime()) / (365 * 86_400_000);
        score += Math.min(10, Math.round(years * 2));
      }

      // Gap check against target role
      if (targetRole) {
        const empSkillNames = emp.skills.map((s: any) => s.skill.name.toLowerCase());
        const reqSkills: any[] = (targetRole as any).requiredSkills ?? [];
        gaps.push(...reqSkills.filter((rs: any) => !empSkillNames.includes(rs.name.toLowerCase())).map((rs: any) => rs.name));
        if (gaps.length > 0) needs.push(...gaps.map((g: string) => `Training: ${g}`));
      }

      const level: SuccessionCandidate['readinessLevel'] =
        score >= 80 ? 'ready_now' : score >= 60 ? 'ready_1yr' : score >= 40 ? 'ready_2yr' : 'not_ready';

      return {
        employeeId: emp.id, name: `${emp.firstName} ${emp.lastName}`,
        employeeCode: emp.employeeCode, readinessScore: score,
        readinessLevel: level, skillGaps: gaps, developmentNeeds: needs,
      };
    }).sort((a, b) => b.readinessScore - a.readinessScore);
  }

  // ─── Critical Role Risk ───────────────────────────────────────────

  async getCriticalRoleRisk(tenantId: string): Promise<CriticalRoleRisk[]> {
    const criticalSkills = await this.prisma.skill.findMany({
      where: { tenantId: { in: [tenantId, 'system'] }, isCritical: true, deletedAt: null },
      include: { employeeSkills: { where: { employee: { tenantId, status: 'active', deletedAt: null } }, select: { employeeId: true } } },
    });

    return (criticalSkills as any[]).map((skill: any) => {
      const coveredBy = skill.employeeSkills.length;
      const risk: CriticalRoleRisk['risk'] = coveredBy === 0 ? 'critical' : coveredBy === 1 ? 'high' : coveredBy <= 3 ? 'medium' : 'low';
      return {
        roleName: skill.name, departmentName: 'Organization-wide',
        coveredBy, risk,
        recommendation: coveredBy === 0 ? 'URGENT: No coverage — hire or train immediately' : coveredBy === 1 ? 'Single point of failure — cross-train at least 1 more employee' : coveredBy <= 3 ? 'Low coverage — include in L&D plan' : 'Coverage adequate',
      };
    }).filter((r: CriticalRoleRisk) => r.risk !== 'low');
  }

  // ─── Training Pathway Suggestions ────────────────────────────────

  async suggestTrainingPathways(tenantId: string, employeeId: string) {
    const emp = await this.prisma.employee.findFirst({
      where: { id: employeeId, tenantId },
      include: {
        skills: { include: { skill: true } },
        designation: { select: { name: true } },
        performanceReviews: { orderBy: { createdAt: 'desc' }, take: 1 },
        courses: { select: { courseId: true, status: true } },
      },
    });
    if (!emp) throw new NotFoundException('Employee not found');

    const criticalSkills = await this.prisma.skill.findMany({ where: { tenantId: { in: [tenantId, 'system'] }, isCritical: true, deletedAt: null } });
    const empSkillIds = new Set((emp.skills as any[]).map((s: any) => s.skillId));
    const missingCritical = (criticalSkills as any[]).filter((s: any) => !empSkillIds.has(s.id));

    const suggestedCourses = await this.prisma.course.findMany({
      where: { tenantId, status: 'published', skills: { some: { skillId: { in: missingCritical.map((s: any) => s.id) } } } },
      include: { skills: { include: { skill: true } } },
      take: 5,
    });

    return {
      employeeId, employeeName: `${(emp as any).firstName} ${(emp as any).lastName}`,
      missingCriticalSkills: missingCritical.map((s: any) => s.name),
      suggestedCourses: (suggestedCourses as any[]).map((c: any) => ({
        courseId: c.id, title: c.title, duration: c.durationHours,
        skills: c.skills.map((s: any) => s.skill.name),
      })),
      priority: missingCritical.length > 3 ? 'high' : missingCritical.length > 1 ? 'medium' : 'low',
    };
  }

  // ─── Org Skill Summary ────────────────────────────────────────────

  async getOrgSkillSummary(tenantId: string) {
    const [totalSkills, totalEmployeesWithSkills, criticalSkillCount, gapAnalysis, criticalRisk] = await Promise.all([
      this.prisma.skill.count({ where: { tenantId: { in: [tenantId, 'system'] }, deletedAt: null } }),
      this.prisma.employeeSkill.groupBy({ by: ['employeeId'], where: { tenantId }, _count: true }).then(r => r.length),
      this.prisma.skill.count({ where: { tenantId: { in: [tenantId, 'system'] }, isCritical: true, deletedAt: null } }),
      this.getSkillGapAnalysis(tenantId),
      this.getCriticalRoleRisk(tenantId),
    ]);

    return {
      totalSkills, totalEmployeesWithSkills, criticalSkillCount,
      employeesWithGaps: gapAnalysis.withGaps,
      criticalRoleRisks: criticalRisk.filter(r => r.risk === 'critical').length,
    };
  }
}

// ─── Controller ──────────────────────────────────────────────────────

@ApiTags('skills')
@ApiBearerAuth()
@UseGuards(AuthGuard('jwt'), TenantGuard)
@Controller('skills')
export class SkillsController {
  constructor(private readonly skillsService: SkillsService) {}

  @Get()
  @ApiOperation({ summary: 'List all skills in the org skill library' })
  listSkills(@Query('category') category: string | undefined, @CurrentUser() u: JwtPayload) { return this.skillsService.listSkills(u.tid, category); }

  @Get('categories')
  getCategories(@CurrentUser() u: JwtPayload) { return this.skillsService.getSkillCategories(u.tid); }

  @Post()
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Add skill to org library (mark isCritical for succession tracking)' })
  createSkill(@Body() dto: any, @CurrentUser() u: JwtPayload) { return this.skillsService.createSkill(u.tid, dto, u.sub); }

  @Get('summary')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Org-wide skill health summary' })
  summary(@CurrentUser() u: JwtPayload) { return this.skillsService.getOrgSkillSummary(u.tid); }

  @Get('heatmap')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Skill coverage heatmap across departments' })
  heatmap(@CurrentUser() u: JwtPayload) { return this.skillsService.getSkillHeatmap(u.tid); }

  @Get('gap-analysis')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Employee skill gap analysis vs role requirements' })
  gapAnalysis(@Query('departmentId') deptId: string | undefined, @CurrentUser() u: JwtPayload) { return this.skillsService.getSkillGapAnalysis(u.tid, deptId); }

  @Get('critical-roles')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Critical role risk — skills with single/no coverage' })
  criticalRoles(@CurrentUser() u: JwtPayload) { return this.skillsService.getCriticalRoleRisk(u.tid); }

  @Get('succession/:roleId?')
  @Roles('hr-admin', 'super-admin')
  @ApiOperation({ summary: 'Succession readiness index — ranked candidates for a role' })
  succession(@Param('roleId') roleId: string | undefined, @CurrentUser() u: JwtPayload) { return this.skillsService.getSuccessionReadiness(u.tid, roleId); }

  @Get('employees/:id')
  @ApiOperation({ summary: 'Get employee skill profile' })
  employeeSkills(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.skillsService.getEmployeeSkills(u.tid, id); }

  @Post('employees/:id')
  @ApiOperation({ summary: 'Update employee skill ratings (1=Beginner, 2=Proficient, 3=Expert)' })
  upsertEmployeeSkills(@Param('id') id: string, @Body() dto: { skills: Array<{ skillId: string; level: number }> }, @CurrentUser() u: JwtPayload) {
    return this.skillsService.upsertEmployeeSkills(u.tid, id, dto.skills, u.sub);
  }

  @Delete('employees/:id/skills/:skillId')
  removeEmployeeSkill(@Param('id') id: string, @Param('skillId') skillId: string, @CurrentUser() u: JwtPayload) {
    return this.skillsService.removeEmployeeSkill(u.tid, id, skillId);
  }

  @Get('employees/:id/pathways')
  @ApiOperation({ summary: 'Suggest training pathways to close critical skill gaps' })
  trainingPathways(@Param('id') id: string, @CurrentUser() u: JwtPayload) { return this.skillsService.suggestTrainingPathways(u.tid, id); }
}

@Module({
  controllers: [SkillsController],
  providers: [SkillsService],
  exports: [SkillsService],
})
export class SkillsModule {}
