import { Module, Global, OnModuleInit, OnModuleDestroy, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Global()
@Module({
  providers: [
    {
      provide: PrismaClient,
      useFactory: () => {
        const client = new PrismaClient({
          log: process.env['NODE_ENV'] === 'development'
            ? [
                { emit: 'event', level: 'query' },
                { emit: 'stdout', level: 'error' },
                { emit: 'stdout', level: 'warn' },
              ]
            : [{ emit: 'stdout', level: 'error' }],
        });

        // Soft-delete middleware — always filter deletedAt IS NULL
        client.$use(async (params, next) => {
          const modelsWithSoftDelete = [
            'Employee', 'User', 'Department', 'Designation', 'Location',
            'LeaveType', 'WorkflowDefinition', 'FormDefinition', 'Document',
            'JobPosting', 'Candidate', 'Course', 'RagDocument',
          ];

          if (params.model && modelsWithSoftDelete.includes(params.model)) {
            if (params.action === 'findUnique' || params.action === 'findFirst') {
              params.action = 'findFirst';
              params.args.where = { ...params.args.where, deletedAt: null };
            }
            if (params.action === 'findMany') {
              params.args = params.args ?? {};
              params.args.where = { ...params.args.where, deletedAt: null };
            }
            if (params.action === 'count') {
              params.args = params.args ?? {};
              params.args.where = { ...params.args.where, deletedAt: null };
            }
            // Soft delete instead of hard delete
            if (params.action === 'delete') {
              params.action = 'update';
              params.args.data = { deletedAt: new Date() };
            }
            if (params.action === 'deleteMany') {
              params.action = 'updateMany';
              params.args.data = { deletedAt: new Date() };
            }
          }

          return next(params);
        });

        return client;
      },
    },
  ],
  exports: [PrismaClient],
})
export class DatabaseModule implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(DatabaseModule.name);

  constructor(private readonly prisma: PrismaClient) {}

  async onModuleInit(): Promise<void> {
    try {
      await this.prisma.$connect();
      this.logger.log('✅ Database connected');
    } catch (error) {
      this.logger.error('❌ Database connection failed', error);
      throw error;
    }
  }

  async onModuleDestroy(): Promise<void> {
    await this.prisma.$disconnect();
    this.logger.log('Database disconnected');
  }
}
