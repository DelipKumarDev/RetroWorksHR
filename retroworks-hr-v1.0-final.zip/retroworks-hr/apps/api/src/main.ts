/**
 * RetroWorks HR — Application Bootstrap
 * SECURITY FIX C-01: validateEnvironment() runs BEFORE NestFactory.create()
 * SECURITY FIX H-04: helmet() with strict CSP
 * SECURITY FIX H-05: forbidNonWhitelisted ValidationPipe
 * SECURITY FIX H-09: cookie-parser for httpOnly refresh token support
 */
import { NestFactory } from '@nestjs/core';
import { ValidationPipe, Logger, VersioningType } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { GlobalExceptionFilter } from './common/filters/global-exception.filter';
import {
  ResponseTransformInterceptor,
  RequestLoggingInterceptor,
  PerformanceInterceptor,
} from './common/interceptors/interceptors';
import { validateEnvironment } from './common/security/env-validator';

// C-01: Validate environment FIRST — app crashes here if secrets are missing
validateEnvironment();

async function bootstrap() {
  const logger = new Logger('Bootstrap');
  const app = await NestFactory.create(AppModule, { bufferLogs: true, rawBody: true });

  // H-09: cookie-parser required for httpOnly refresh token reading
  const cookieParser = require('cookie-parser');
  app.use(cookieParser());

  // H-04: Helmet with Content-Security-Policy
  const helmet = require('helmet');
  app.use(
    helmet({
      crossOriginEmbedderPolicy: false,
      crossOriginResourcePolicy: { policy: 'cross-origin' },
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"], // Allow inline styles for UI
          imgSrc: ["'self'", 'data:', 'https:'],
          connectSrc: ["'self'"],
          fontSrc: ["'self'", 'https:'],
          objectSrc: ["'none'"],
          mediaSrc: ["'none'"],
          frameSrc: ["'none'"],
          frameAncestors: ["'none'"],
          upgradeInsecureRequests: [],
        },
      },
      hsts: {
        maxAge: 31536000, // 1 year
        includeSubDomains: true,
        preload: true,
      },
      referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
    }),
  );

  // CORS — strict origin allowlist (no wildcard)
  const allowedOrigins = (
    process.env['ALLOWED_ORIGINS'] ?? 'http://localhost:3000'
  ).split(',').map(o => o.trim());

  app.enableCors({
    origin: allowedOrigins,
    credentials: true, // Required for httpOnly cookie refresh tokens
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'x-tenant-id', 'x-request-id'],
    exposedHeaders: ['x-request-id', 'x-ratelimit-limit', 'x-ratelimit-remaining'],
  });

  app.use(require('compression')());

  // API versioning
  app.enableVersioning({ type: VersioningType.URI });
  app.setGlobalPrefix('api/v1', { exclude: ['health', 'webhooks/:wildcard'] });

  // H-05: Global Validation Pipe — strict whitelisting, no unknown fields
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,              // Strip unknown fields
      forbidNonWhitelisted: true,   // Throw on unknown fields (mass assignment protection)
      transform: true,
      transformOptions: { enableImplicitConversion: true },
      errorHttpStatusCode: 422,
      stopAtFirstError: false,      // Report all validation errors at once
    }),
  );

  // Filters & Interceptors
  app.useGlobalFilters(new GlobalExceptionFilter());
  app.useGlobalInterceptors(
    new RequestLoggingInterceptor(),
    new PerformanceInterceptor(),
    new ResponseTransformInterceptor(),
  );

  // Swagger (non-production only)
  if (process.env['NODE_ENV'] !== 'production') {
    const doc = SwaggerModule.createDocument(
      app,
      new DocumentBuilder()
        .setTitle('RetroWorks HR API')
        .setDescription(
          'Production HRMS/HRIS — India payroll, ATS, Performance, AI & more\n\n' +
          '**Security**: JWT Bearer + httpOnly cookie refresh tokens\n' +
          '**Auth**: POST /api/v1/auth/login → access_token (15m) + rw_refresh_token cookie (7d)',
        )
        .setVersion('1.1.0')
        .addBearerAuth()
        .addCookieAuth('rw_refresh_token')
        .addServer('http://localhost:3001', 'Local Dev')
        .build(),
    );
    SwaggerModule.setup('api/docs', app, doc, {
      swaggerOptions: { persistAuthorization: true, showRequestDuration: true },
    });
    logger.log('📚 Swagger: http://localhost:3001/api/docs');
  }

  // Graceful shutdown
  for (const sig of ['SIGTERM', 'SIGINT']) {
    process.on(sig, async () => {
      logger.log(`${sig} received — graceful shutdown`);
      await app.close();
      process.exit(0);
    });
  }

  const port = parseInt(process.env['PORT'] ?? '3001');
  await app.listen(port, '0.0.0.0');
  logger.log(`🚀 RetroWorks HR API on :${port} [${process.env['NODE_ENV'] ?? 'development'}]`);
}

bootstrap().catch((err: Error) => {
  console.error('Fatal bootstrap error:', err.message);
  process.exit(1);
});
