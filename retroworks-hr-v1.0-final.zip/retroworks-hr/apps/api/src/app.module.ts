import { SecurityComplianceModule } from './modules/security-compliance/security.module';
import { EngagementModule } from './modules/engagement/engagement.module';
import { BillingModule } from './modules/billing/billing.module';
import { SetupWizardModule } from './modules/setup-wizard/setup-wizard.module';
/**
 * RetroWorks HR — App Module
 * AUDIT FIXES:
 *   AUDIT-02: PermissionsGuard registered as APP_GUARD (was missing)
 *   AUDIT-03: SanitizationModule imported (was missing from global scope)
 */
import { Module } from '@nestjs/common';
import { APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { ConfigModule } from '@nestjs/config';
import { ThrottlerModule, ThrottlerGuard } from '@nestjs/throttler';
import { EventEmitterModule } from '@nestjs/event-emitter';
import { ScheduleModule } from '@nestjs/schedule';
import { DatabaseModule } from './database/database.module';
import { HealthModule } from './modules/health/health.module';
import { AuthModule } from './modules/auth/auth.module';
import { TenantModule } from './modules/tenant/tenant.module';
import { EmployeeModule } from './modules/employee/employee.module';
import { WorkflowModule } from './modules/workflow/workflow.module';
import { FormModule } from './modules/form/form.module';
import { DataOpsModule } from './modules/dataops/dataops.module';
import { AtsModule } from './modules/ats/ats.module';
import { LeaveModule } from './modules/leave/leave.module';
import { AttendanceModule } from './modules/attendance/attendance.module';
import { OnboardingModule } from './modules/onboarding/onboarding.module';
import { AnnouncementModule } from './modules/announcement/announcement.module';
import { PayrollModule } from './modules/payroll/payroll.module';
import { PerformanceModule } from './modules/performance/performance.module';
import { LndModule } from './modules/lnd/lnd.module';
import { ExpenseModule } from './modules/expense/expense.module';
import { HelpdeskModule } from './modules/helpdesk/helpdesk.module';
import { ReportsModule } from './modules/reports/reports.module';
import { ReportBuilderModule }
import { AdvancedReportBuilderModule } from './modules/reports/advanced-report-builder/advanced-report-builder.module'; from './modules/reports/report-builder.module';
import { AiModule } from './modules/ai/ai.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { JobsModule } from './modules/jobs/jobs.module';
import { IntegrationsModule } from './modules/integrations/integrations.module';
import { SettingsModule } from './modules/settings/settings.module';
import { AutomationModule } from './modules/automation/automation.module';
import { DocumentsModule } from './modules/documents/documents.module';
import { InsightsModule } from './modules/insights/insights.module';
import { PluginsModule } from './modules/plugins/plugins.module';
import { BackupModule } from './modules/backup/backup.module';
import { CaseEngineModule } from './modules/case-engine/case-engine.module';
import { AnalyticsModule } from './modules/analytics/analytics.module'; from './modules/case-engine/case-engine.module';
import { JwtAuthGuard } from './common/guards/jwt-auth.guard';
import { PermissionsGuard } from './common/guards/permissions.guard'; // AUDIT-02: Added
import { SecurityModule } from './common/security/security.module';
import { AuditService } from './common/services/audit.service';
import { AuditInterceptor } from './common/interceptors/audit.interceptor'; // AUDIT-03: Added

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, envFilePath: ['.env.local', '.env'] }),
    ThrottlerModule.forRoot([
      { name: 'short',  ttl: 1000,    limit: 20   },
      { name: 'medium', ttl: 60000,   limit: 200  },
      { name: 'long',   ttl: 3600000, limit: 2000 },
    ]),
    EventEmitterModule.forRoot({ wildcard: true, delimiter: '.' }),
    ScheduleModule.forRoot(),
    DatabaseModule, HealthModule, AuthModule, TenantModule,
    EmployeeModule, WorkflowModule, FormModule, DataOpsModule,
    AtsModule, LeaveModule, AttendanceModule, OnboardingModule, AnnouncementModule,
    PayrollModule, PerformanceModule, LndModule, ExpenseModule, HelpdeskModule,
    ReportsModule, ReportBuilderModule,
    AiModule, NotificationsModule, JobsModule, IntegrationsModule, SettingsModule,
    AutomationModule, DocumentsModule, InsightsModule,
    PluginsModule, BackupModule,
    CaseEngineModule,
    SecurityModule, // Provides PrismaTenantService, FieldEncryptionService, RedisLockService globally
  ],
  providers: [
    // Guard order matters: Throttle → JWT → Permissions
    { provide: APP_GUARD, useClass: ThrottlerGuard },
    { provide: APP_GUARD, useClass: JwtAuthGuard },
    { provide: APP_GUARD, useClass: PermissionsGuard }, // AUDIT-02: FIXED — was missing
    // AUDIT-03: Global audit interceptor for all write operations
    { provide: APP_INTERCEPTOR, useClass: AuditInterceptor },
    AuditService,
  ],
})
export class AppModule {}
