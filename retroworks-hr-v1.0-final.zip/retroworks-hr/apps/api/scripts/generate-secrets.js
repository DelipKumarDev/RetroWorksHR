#!/usr/bin/env node
/**
 * RetroWorks HR — Secure Secret Generator
 * ─────────────────────────────────────────
 * Generates a production-ready .env file with cryptographically
 * secure random secrets for all required environment variables.
 *
 * Usage:
 *   node scripts/generate-secrets.js                    # Print to stdout
 *   node scripts/generate-secrets.js --write            # Write to .env.production
 *   node scripts/generate-secrets.js --rotate JWT_SECRET  # Rotate single secret
 *
 * ⚠️  Store the output in AWS Secrets Manager, HashiCorp Vault,
 *     or encrypted at-rest. NEVER commit to git.
 */

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const hex = (bytes = 64) => crypto.randomBytes(bytes).toString('hex');
const base64 = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');

const secrets = {
  // ── Authentication ───────────────────────────────────────────────────────
  JWT_SECRET: hex(64),                    // 128-char hex = 512-bit
  JWT_EXPIRES_IN: '15m',                  // Short-lived access tokens
  JWT_REFRESH_SECRET: hex(64),            // 128-char hex = 512-bit
  JWT_REFRESH_EXPIRES_IN: '7d',

  // ── Encryption ───────────────────────────────────────────────────────────
  ENCRYPTION_KEY: hex(32),               // 64-char hex = 256-bit AES key
  BACKUP_ENCRYPTION_KEY: hex(32),        // 64-char hex = 256-bit for backup files

  // ── Magic Links ──────────────────────────────────────────────────────────
  MAGIC_LINK_SECRET: hex(32),            // 64-char hex

  // ── Webhooks ──────────────────────────────────────────────────────────────
  WEBHOOK_SECRET: hex(32),               // 64-char hex

  // ── Application ──────────────────────────────────────────────────────────
  SESSION_SECRET: hex(32),               // Express session (if used)
};

const envTemplate = (domain) => `
# ═══════════════════════════════════════════════════════════════════════════
# RetroWorks HR — Production Environment
# Generated: ${new Date().toISOString()}
# 
# ⚠️  SECURITY NOTICE:
#   - Store this file in AWS Secrets Manager or HashiCorp Vault
#   - NEVER commit this file to git (.gitignore must include .env.production)
#   - Rotate secrets every 90 days
#   - Delete this file from local disk after loading into secret store
# ═══════════════════════════════════════════════════════════════════════════

NODE_ENV=production
PORT=3001
APP_NAME=RetroWorks HR

# ── Database ────────────────────────────────────────────────────────────────
# REQUIRED: Replace with your actual RDS/PostgreSQL connection string
DATABASE_URL=postgresql://retroworks:CHANGEME@your-rds-endpoint.ap-south-1.rds.amazonaws.com:5432/retroworks_prod

# ── Redis ───────────────────────────────────────────────────────────────────
# REQUIRED: Replace with your ElastiCache/Redis endpoint
REDIS_URL=rediss://your-elasticache-endpoint.ap-south-1.cache.amazonaws.com:6379
REDIS_TLS=true

# ── JWT Authentication (REQUIRED — auto-generated below) ────────────────────
JWT_SECRET=${secrets.JWT_SECRET}
JWT_EXPIRES_IN=${secrets.JWT_EXPIRES_IN}
JWT_REFRESH_SECRET=${secrets.JWT_REFRESH_SECRET}
JWT_REFRESH_EXPIRES_IN=${secrets.JWT_REFRESH_EXPIRES_IN}

# ── Field Encryption (REQUIRED — AES-256-GCM) ───────────────────────────────
# 64-char hex = 32 bytes = 256-bit key
ENCRYPTION_KEY=${secrets.ENCRYPTION_KEY}
USE_KMS=false
# Optional: set USE_KMS=true and configure KMS_KEY_ALIAS for AWS KMS
# KMS_KEY_ALIAS=alias/retroworks-hr-production

# ── Backup Encryption (REQUIRED for production) ──────────────────────────────
BACKUP_ENCRYPTION_KEY=${secrets.BACKUP_ENCRYPTION_KEY}
BACKUP_DIR=/var/retroworks/backups
BACKUP_S3_BUCKET=retroworks-hr-backups-prod
BACKUP_RETAIN_DAILY=7
BACKUP_RETAIN_WEEKLY=4

# ── Magic Links (REQUIRED) ───────────────────────────────────────────────────
MAGIC_LINK_SECRET=${secrets.MAGIC_LINK_SECRET}
MAGIC_LINK_EXPIRES_MINUTES=15

# ── Webhooks ─────────────────────────────────────────────────────────────────
WEBHOOK_SECRET=${secrets.WEBHOOK_SECRET}

# ── CORS (REQUIRED — no wildcards) ───────────────────────────────────────────
# Replace with your actual production domain(s)
ALLOWED_ORIGINS=https://app.retroworks.hr,https://retroworks.hr
FRONTEND_URL=https://app.retroworks.hr

# ── AWS ──────────────────────────────────────────────────────────────────────
AWS_REGION=ap-south-1
AWS_ACCESS_KEY_ID=REPLACE_WITH_IAM_KEY
AWS_SECRET_ACCESS_KEY=REPLACE_WITH_IAM_SECRET
AWS_S3_BUCKET=retroworks-hr-prod
AWS_KMS_KEY_ID=REPLACE_WITH_KMS_KEY_ID
AWS_SES_FROM_EMAIL=noreply@${domain || 'retroworks.hr'}
AWS_CLOUDFRONT_URL=https://cdn.retroworks.hr

# ── AI / Claude API ───────────────────────────────────────────────────────────
ANTHROPIC_API_KEY=sk-ant-REPLACE_WITH_ACTUAL_KEY
CONFIDENCE_THRESHOLD=0.75
# Safety: set to 'false' in production (never log AI payloads containing PII)
AI_LOG_PAYLOADS=false

# ── Rate Limiting ────────────────────────────────────────────────────────────
LOGIN_MAX_ATTEMPTS=5
LOGIN_WINDOW_MS=900000
API_MAX_PER_MINUTE=200

# ── Payroll ──────────────────────────────────────────────────────────────────
PAYROLL_RUN_LOCK_TTL=300
PAYROLL_BATCH_SIZE=50

# ── Logging ──────────────────────────────────────────────────────────────────
LOG_LEVEL=info
LOG_FORMAT=json

# ── Health Checks ────────────────────────────────────────────────────────────
HEALTH_DB_TIMEOUT_MS=2000
HEALTH_REDIS_TIMEOUT_MS=1000

# ── Metrics ──────────────────────────────────────────────────────────────────
METRICS_ENABLED=true
METRICS_PATH=/metrics
`.trimStart();

// ── Main ─────────────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
const writeMode = args.includes('--write');
const rotateKey = args.find(a => a.startsWith('--rotate='))?.split('=')[1];

if (rotateKey) {
  // Single key rotation
  if (!secrets[rotateKey]) {
    const newSecret = hex(rotateKey.includes('ENCRYPTION') ? 32 : 64);
    console.log(`\n# Key rotation for ${rotateKey}:`);
    console.log(`${rotateKey}=${newSecret}`);
    console.log(`\n⚠️  Update this value in your secret store AND redeploy all API instances.`);
    console.log(`⚠️  For ENCRYPTION_KEY rotation, run: node scripts/rotate-encryption-key.js`);
  } else {
    const newSecret = secrets[rotateKey];
    console.log(`\n# Rotated ${rotateKey}:`);
    console.log(`${rotateKey}=${newSecret}`);
  }
  process.exit(0);
}

const output = envTemplate('retroworks.hr');

if (writeMode) {
  const outputPath = path.join(process.cwd(), '.env.production');
  
  if (fs.existsSync(outputPath)) {
    const backup = `${outputPath}.${Date.now()}.bak`;
    fs.copyFileSync(outputPath, backup);
    console.error(`⚠️  Backed up existing .env.production to ${backup}`);
  }
  
  fs.writeFileSync(outputPath, output, { mode: 0o600 }); // Owner-only read/write
  console.log(`✅ Written to .env.production (permissions: 600)`);
  console.log(`\nNext steps:`);
  console.log(`  1. Replace all REPLACE_* values with actual credentials`);
  console.log(`  2. Upload to AWS Secrets Manager: aws secretsmanager create-secret --name retroworks-hr/production --secret-string file://.env.production`);
  console.log(`  3. Delete local file: shred -u .env.production`);
} else {
  console.log(output);
  console.log('\n# ─────────────────────────────────────────────────────────────');
  console.log('# To write to file: node scripts/generate-secrets.js --write');
  console.log('# To rotate a key:  node scripts/generate-secrets.js --rotate=JWT_SECRET');
  console.log('# ─────────────────────────────────────────────────────────────');
}
