import type { Preview } from '@storybook/react';
import '../src/styles/globals.css';

const preview: Preview = {
  parameters: {
    backgrounds: {
      default: 'retro-dark',
      values: [
        { name: 'retro-dark', value: '#080c08' },
        { name: 'retro-light', value: '#0d160d' },
      ],
    },
    controls: { matchers: { color: /(background|color)$/i, date: /date/i } },
    a11y: { mode: 'manual' },
  },
  globalTypes: {
    theme: {
      description: 'Global theme for components',
      defaultValue: 'dark',
      toolbar: {
        title: 'Theme',
        items: [{ value: 'dark', icon: 'circlehollow', title: 'Dark (CRT)' }],
      },
    },
  },
  decorators: [
    (Story) => (
      <div className="p-6 min-h-screen bg-retro-bg font-mono">
        <Story />
      </div>
    ),
  ],
};

export default preview;
