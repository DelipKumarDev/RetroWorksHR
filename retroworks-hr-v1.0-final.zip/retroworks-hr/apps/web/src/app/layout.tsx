import type { Metadata, Viewport } from 'next';
import { Press_Start_2P, Space_Mono } from 'next/font/google';
import '../styles/globals.css';
import { Providers } from './providers';

const pressStart2P = Press_Start_2P({
  weight: '400',
  subsets: ['latin'],
  variable: '--font-pixel',
  display: 'swap',
});

const spaceMono = Space_Mono({
  weight: ['400', '700'],
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: {
    default: 'RetroWorks HR',
    template: '%s | RetroWorks HR',
  },
  description: 'Production-grade HRMS/HRIS — Hire to Retire, powered by RetroWorks',
  keywords: ['HRMS', 'HRIS', 'payroll', 'India', 'HR software'],
  robots: { index: false, follow: false }, // Private app
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
};

export const viewport: Viewport = {
  themeColor: '#080c08',
  colorScheme: 'dark',
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en-IN"
      className={`${pressStart2P.variable} ${spaceMono.variable} dark`}
      suppressHydrationWarning
    >
      <body className="min-h-screen bg-retro-bg font-body antialiased">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
