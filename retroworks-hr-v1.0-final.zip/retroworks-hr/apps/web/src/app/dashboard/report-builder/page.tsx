import type { Metadata } from 'next';
import { ReportBuilderPage } from '../../../components/report-builder/ReportBuilderPage';
export const metadata: Metadata = { title: 'ReportBuilderPage' };
export default function Page() { return <ReportBuilderPage />; }
