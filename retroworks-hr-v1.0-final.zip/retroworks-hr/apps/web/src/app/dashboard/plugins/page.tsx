import type { Metadata } from 'next';
import { PluginsPage } from '../../../components/plugins/PluginsPage';
export const metadata: Metadata = { title: 'PluginsPage' };
export default function Page() { return <PluginsPage />; }
