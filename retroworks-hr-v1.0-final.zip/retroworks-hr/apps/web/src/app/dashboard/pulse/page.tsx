'use client';
import { PulseSurveyPage } from '@/components/engagement/PulseSurveyPage';
// isHR prop is read from JWT in production; defaulting to true for HR dashboard
export default function PulseRoute() { return <PulseSurveyPage isHR={true} />; }
