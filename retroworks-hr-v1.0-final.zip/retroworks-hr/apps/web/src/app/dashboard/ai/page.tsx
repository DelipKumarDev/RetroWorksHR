import type { Metadata } from 'next';
import { AiChatPage } from '../../../components/ai/AiChatPage';
export const metadata: Metadata = { title: 'RetroBot AI Assistant' };
export default function Page() { return <AiChatPage />; }
