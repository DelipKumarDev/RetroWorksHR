import type { Metadata } from 'next';
import { LeavePage } from '../../components/leave/LeavePage';
export const metadata: Metadata = { title: 'Leave Management' };
export default function LeaveRoute() { return <LeavePage />; }
