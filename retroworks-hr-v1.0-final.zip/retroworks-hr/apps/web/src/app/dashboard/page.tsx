'use client';
import { EmployeeDashboard } from '@/components/engagement/EmployeeDashboard';
export default function DashboardHome() { return <EmployeeDashboard />; }
