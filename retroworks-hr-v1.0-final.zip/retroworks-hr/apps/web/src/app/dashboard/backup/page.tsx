import type { Metadata } from 'next';
import { BackupPage } from '../../../components/backup/BackupPage';
export const metadata: Metadata = { title: 'BackupPage' };
export default function Page() { return <BackupPage />; }
