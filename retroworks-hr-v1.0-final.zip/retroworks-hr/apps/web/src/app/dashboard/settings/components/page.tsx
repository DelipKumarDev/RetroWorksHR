import { ExpressionEditorPage } from '@/components/payroll/expression-editor/ExpressionEditorPage';
export default function PayComponentsPage() { return <ExpressionEditorPage />; }
