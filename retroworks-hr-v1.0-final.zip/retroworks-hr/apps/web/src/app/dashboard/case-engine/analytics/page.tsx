import { CaseAnalyticsDashboard } from '../../../../components/case-engine/analytics/CaseAnalyticsDashboard';
export const metadata = { title: 'Case Analytics' };
export default function Page() { return <CaseAnalyticsDashboard />; }
