import { AssignmentRulesPage } from '../../../../components/case-engine/AssignmentRulesPage';
export const metadata = { title: 'Assignment Rules' };
export default function Page() { return <AssignmentRulesPage />; }
