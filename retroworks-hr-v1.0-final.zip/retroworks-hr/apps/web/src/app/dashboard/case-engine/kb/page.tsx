import type { Metadata } from 'next';
import { KnowledgeBasePage } from '../../../../components/case-engine/kb/KnowledgeBasePage';
export const metadata: Metadata = { title: 'KnowledgeBasePage' };
export default function Page() { return <KnowledgeBasePage />; }
