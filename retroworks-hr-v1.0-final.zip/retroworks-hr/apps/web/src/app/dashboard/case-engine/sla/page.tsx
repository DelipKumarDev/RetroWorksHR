import type { Metadata } from 'next';
import { SlaPage } from '../../../../components/case-engine/SlaKbCrmPages';
export const metadata: Metadata = { title: 'SLA Configuration' };
export default function Page() { return <SlaPage />; }
