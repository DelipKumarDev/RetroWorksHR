import type { Metadata } from 'next';
import { KanbanPage } from '../../../../components/case-engine/kanban/KanbanPage';
export const metadata: Metadata = { title: 'KanbanPage' };
export default function Page() { return <KanbanPage />; }
