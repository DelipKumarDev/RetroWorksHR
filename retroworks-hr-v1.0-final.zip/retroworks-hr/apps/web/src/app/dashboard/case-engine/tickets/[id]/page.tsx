import { TicketDetailPage } from '../../../../../components/case-engine/ticket-detail/TicketDetailPage';
export const metadata = { title: 'Ticket Detail' };
export default function Page() { return <TicketDetailPage />; }
