import type { Metadata } from 'next';
import { TicketListPage } from '../../../../components/case-engine/ticket-list/TicketListPage';
export const metadata: Metadata = { title: 'TicketListPage' };
export default function Page() { return <TicketListPage />; }
