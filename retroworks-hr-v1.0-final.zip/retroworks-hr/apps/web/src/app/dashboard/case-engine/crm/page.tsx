import type { Metadata } from 'next';
import { CRMPage } from '../../../../components/case-engine/crm/CRMPage';
export const metadata: Metadata = { title: 'CRMPage' };
export default function Page() { return <CRMPage />; }
