import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Insights' };
export default function Page() { return <div className="p-6 font-pixel text-primary-crt text-xs">Insights module loaded.</div>; }
