'use client';
import { SecurityAdminPage } from '@/components/security/SecurityAdminPage';
export default function SecurityRoute() { return <SecurityAdminPage />; }
