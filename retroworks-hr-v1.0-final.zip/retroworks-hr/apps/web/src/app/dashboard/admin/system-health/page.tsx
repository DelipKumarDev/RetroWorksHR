'use client';
import { SystemHealthPage } from '@/components/security/SystemHealthPage';
export default function SystemHealthRoute() { return <SystemHealthPage />; }
