'use client';
import { SecurityAdminPage } from '@/components/security/SecurityAdminPage';
// DPDPA is the second tab in SecurityAdminPage
export default function DpdpaRoute() { return <SecurityAdminPage />; }
