import type { Metadata } from 'next';
import { WorkflowBuilderClientPage } from '../../../components/workflow/WorkflowBuilderPage';

export const metadata: Metadata = { title: 'Workflow Builder' };

export default function WorkflowBuilderPage() {
  return <WorkflowBuilderClientPage />;
}
