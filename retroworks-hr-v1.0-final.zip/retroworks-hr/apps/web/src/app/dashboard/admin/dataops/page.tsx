import type { Metadata } from 'next';
import { DataOpsConsole } from '../../../components/dataops/DataOpsConsole';

export const metadata: Metadata = { title: 'DataOps Console' };

export default function DataOpsPage() {
  return <DataOpsConsole />;
}
