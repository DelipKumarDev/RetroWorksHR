'use client';
import { FeatureFlagsPage } from '@/components/security/FeatureFlagsPage';
export default function FeatureFlagsRoute() { return <FeatureFlagsPage isAdmin={true} />; }
