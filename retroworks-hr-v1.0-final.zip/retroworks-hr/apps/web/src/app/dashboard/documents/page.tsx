import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'Documents' };
export default function Page() { return <div className="p-6 font-pixel text-primary-crt text-xs">Documents module loaded.</div>; }
