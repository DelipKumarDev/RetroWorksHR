import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'simulation' };
export default function Page() { return <div className="p-6 font-pixel text-primary-crt text-[10px]">simulation module</div>; }
