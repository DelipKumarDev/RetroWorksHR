import type { Metadata } from 'next';
import { PayrollPage } from '../../components/payroll/PayrollPage';
export const metadata: Metadata = { title: 'My Payslips' };
export default function Page() { return <PayrollPage />; }
