import { BillingPage } from '@/components/billing/BillingPage';
// Upgrade route renders same page — BillingPage auto-opens upgrade modal
export default function UpgradeRoute() { return <BillingPage />; }
