import { PayrollAuditPage } from '@/components/audit/PayrollAuditPage';
export default function AuditPage() { return <PayrollAuditPage />; }
