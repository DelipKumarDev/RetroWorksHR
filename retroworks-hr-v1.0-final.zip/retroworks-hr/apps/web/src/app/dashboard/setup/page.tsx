import type { Metadata } from 'next';
import { SetupWizard } from '../../../components/setup-wizard/SetupWizard';
export const metadata: Metadata = { title: 'Company Setup' };
export default function Page() { return <SetupWizard />; }
