import type { Metadata } from 'next';
import { AutomationPage } from '../../../components/automation/AutomationPage';
export const metadata: Metadata = { title: 'Automation Rules' };
export default function Page() { return <AutomationPage />; }
