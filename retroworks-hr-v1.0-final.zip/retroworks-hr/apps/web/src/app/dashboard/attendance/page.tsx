import type { Metadata } from 'next';
import { AttendancePage } from '../../components/attendance/AttendancePage';
export const metadata: Metadata = { title: 'Attendance' };
export default function AttendanceRoute() { return <AttendancePage />; }
