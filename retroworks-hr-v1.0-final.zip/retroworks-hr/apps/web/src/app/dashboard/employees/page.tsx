import type { Metadata } from 'next';
import { EmployeeListClient } from '../../components/employee/EmployeeList';

export const metadata: Metadata = { title: 'Employees' };

export default function EmployeesPage() {
  return <EmployeeListClient />;
}
