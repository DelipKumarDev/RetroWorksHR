import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'analytics-lab' };
export default function Page() { return <div className="p-6 font-pixel text-primary-crt text-[10px]">analytics-lab module</div>; }
