'use client';
import { PerformancePage } from '@/components/engagement/PerformancePage';
export default function PerformanceRoute() { return <PerformancePage isHR={false} isManager={false} />; }
