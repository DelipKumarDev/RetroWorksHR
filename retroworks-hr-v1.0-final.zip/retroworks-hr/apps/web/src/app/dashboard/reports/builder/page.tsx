import { ReportBuilderPage } from '@/components/reports/builder/ReportBuilderPage';
export default function ReportBuilderRoute() { return <ReportBuilderPage />; }
