import type { Metadata } from 'next';
import { ReportsDashboard } from '../../components/reports/ReportsDashboard';
export const metadata: Metadata = { title: 'HR Reports' };
export default function Page() { return <ReportsDashboard />; }
