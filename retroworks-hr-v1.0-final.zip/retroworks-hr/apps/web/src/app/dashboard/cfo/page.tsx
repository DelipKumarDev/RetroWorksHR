import { CfoDashboardPage } from '@/components/cfo/CfoDashboardPage';
export default function CfoPage() { return <CfoDashboardPage />; }
