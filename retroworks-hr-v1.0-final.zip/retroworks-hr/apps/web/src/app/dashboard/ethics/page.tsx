import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'ethics' };
export default function Page() { return <div className="p-6 font-pixel text-primary-crt text-[10px]">ethics module</div>; }
