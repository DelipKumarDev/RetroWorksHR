import type { Metadata } from 'next';
import { AtsKanbanBoard } from '../../components/ats/AtsKanbanBoard';
export const metadata: Metadata = { title: 'Recruitment Pipeline' };
export default function AtsPage() { return <AtsKanbanBoard />; }
