import { OrgChartPage } from '@/components/engagement/OrgChartPage';
export const metadata = { title: 'Org Chart — RetroWorks HR' };
export default function OrgChartRoute() { return <OrgChartPage />; }
