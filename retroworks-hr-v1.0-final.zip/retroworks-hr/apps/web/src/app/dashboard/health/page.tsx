import { SetupWizardPage } from '@/components/onboarding/SetupWizardPage';
export default function HealthRoute() { return <SetupWizardPage />; }
