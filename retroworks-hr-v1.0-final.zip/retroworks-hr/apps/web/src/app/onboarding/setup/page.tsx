import { SetupWizardPage } from '@/components/onboarding/SetupWizardPage';
export default function SetupWizardRoute() { return <SetupWizardPage />; }
