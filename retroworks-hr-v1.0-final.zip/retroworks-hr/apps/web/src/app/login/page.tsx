import type { Metadata } from 'next';
import { LoginForm } from '../../components/auth/LoginForm';

export const metadata: Metadata = {
  title: 'Sign In',
};

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-retro-bg crt-screen flex items-center justify-center p-4">
      {/* Background grid */}
      <div
        className="fixed inset-0 bg-pixel-grid opacity-20 pointer-events-none"
        aria-hidden="true"
      />

      {/* Terminal glow */}
      <div
        className="fixed inset-0 bg-terminal-glow pointer-events-none"
        aria-hidden="true"
      />

      {/* Login panel */}
      <div className="relative w-full max-w-sm animate-fade-in">
        {/* ASCII art header */}
        <div className="text-center mb-8">
          <pre
            className="font-pixel text-primary-crt text-[6px] leading-tight hidden sm:block"
            aria-hidden="true"
          >{`
██████╗ ███████╗████████╗██████╗  ██████╗ 
██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔═══██╗
██████╔╝█████╗     ██║   ██████╔╝██║   ██║
██╔══██╗██╔══╝     ██║   ██╔══██╗██║   ██║
██║  ██║███████╗   ██║   ██║  ██║╚██████╔╝
╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ 
          `}</pre>
          <h1 className="font-pixel text-pixel-base text-primary-crt glow-text">
            RetroWorks HR
          </h1>
          <p className="font-mono text-xs text-primary-600 mt-2">
            v0.1.0 | SYSTEM READY
          </p>
        </div>

        {/* Auth panel */}
        <div className="bg-retro-card border-2 border-primary-800 rounded shadow-glow-strong">
          {/* Terminal chrome */}
          <div className="flex items-center gap-2 px-4 py-2 border-b border-retro-border bg-retro-bg">
            <span className="w-2 h-2 bg-red-600 opacity-70" />
            <span className="w-2 h-2 bg-accent-dim opacity-70" />
            <span className="w-2 h-2 bg-primary-700 opacity-70" />
            <span className="ml-2 font-pixel text-[8px] text-primary-700">
              AUTH.SYS
            </span>
          </div>

          <div className="p-6">
            <div className="mb-6">
              <p className="font-mono text-xs text-primary-500 mb-1">
                <span className="text-primary-crt">$</span> identify_user --secure
              </p>
              <p className="font-mono text-xs text-primary-700">
                Enter credentials to access HR terminal
              </p>
            </div>

            <LoginForm />

            <div className="mt-6 pt-4 border-t border-retro-border text-center">
              <p className="font-mono text-[10px] text-primary-700">
                Secured with{' '}
                <span className="text-primary-500">TLS 1.3</span>
                {' + '}
                <span className="text-primary-500">AES-256</span>
              </p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center font-pixel text-[7px] text-primary-800 mt-4">
          © 2024 RetroWorks · All rights reserved
        </p>
      </div>
    </main>
  );
}
