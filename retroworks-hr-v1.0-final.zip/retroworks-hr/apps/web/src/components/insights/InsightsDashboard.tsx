'use client';

import { useQuery } from '@tanstack/react-query';
import {
  TrendingDown, AlertTriangle, BarChart2, Users, DollarSign,
  CheckCircle, AlertCircle, TrendingUp, Info, RefreshCw,
  Calendar, Star,
} from 'lucide-react';

const api = (path: string) =>
  fetch(`/api/v1${path}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token') ?? ''}` } }).then(r => r.json());

type Severity = 'critical' | 'warning' | 'info';
type Category = 'attrition' | 'leave' | 'payroll' | 'performance' | 'compliance' | 'forecast';

interface Insight {
  id: string; category: Category; severity: Severity;
  title: string; description: string;
  affectedCount?: number;
  employees?: Array<{ id: string; name: string; value?: string | number }>;
  recommendation?: string;
  metric?: { label: string; value: string | number; trend?: 'up' | 'down' | 'flat' };
}

const SEVERITY_STYLES: Record<Severity, { bg: string; border: string; icon: React.ReactNode; badge: string }> = {
  critical: {
    bg: 'bg-red-950/30', border: 'border-red-800',
    icon: <AlertCircle className="w-4 h-4 text-red-400" />,
    badge: 'bg-red-950 border-red-800 text-red-400',
  },
  warning: {
    bg: 'bg-yellow-950/20', border: 'border-yellow-800',
    icon: <AlertTriangle className="w-4 h-4 text-yellow-400" />,
    badge: 'bg-yellow-950 border-yellow-800 text-yellow-400',
  },
  info: {
    bg: 'bg-blue-950/10', border: 'border-blue-900',
    icon: <Info className="w-4 h-4 text-blue-400" />,
    badge: 'bg-blue-950 border-blue-900 text-blue-400',
  },
};

const CATEGORY_ICONS: Record<Category, React.ReactNode> = {
  attrition: <TrendingDown className="w-3.5 h-3.5" />,
  leave: <Calendar className="w-3.5 h-3.5" />,
  payroll: <DollarSign className="w-3.5 h-3.5" />,
  performance: <Star className="w-3.5 h-3.5" />,
  compliance: <CheckCircle className="w-3.5 h-3.5" />,
  forecast: <TrendingUp className="w-3.5 h-3.5" />,
};

const TREND_ICON = {
  up: <TrendingUp className="w-3 h-3 text-green-400" />,
  down: <TrendingDown className="w-3 h-3 text-red-400" />,
  flat: <BarChart2 className="w-3 h-3 text-primary-600" />,
};

function InsightCard({ insight }: { insight: Insight }) {
  const styles = SEVERITY_STYLES[insight.severity];

  return (
    <div className={`rounded-xl border p-5 ${styles.bg} ${styles.border}`}>
      <div className="flex items-start gap-3">
        <div className="shrink-0 mt-0.5">{styles.icon}</div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span className={`flex items-center gap-1 px-1.5 py-0.5 rounded border font-pixel text-[6px] ${styles.badge}`}>
              {CATEGORY_ICONS[insight.category]}
              {insight.category.toUpperCase()}
            </span>
            {insight.affectedCount !== undefined && (
              <span className="px-1.5 py-0.5 bg-retro-bg border border-retro-border rounded font-mono text-[8px] text-primary-600">
                {insight.affectedCount} affected
              </span>
            )}
          </div>

          <h3 className="font-mono text-sm text-primary-300 font-medium mb-1">{insight.title}</h3>
          <p className="font-mono text-xs text-primary-600 leading-relaxed mb-3">{insight.description}</p>

          {/* Metric */}
          {insight.metric && (
            <div className="flex items-center gap-2 mb-3 p-2 bg-retro-bg border border-retro-border rounded">
              <div>
                <p className="font-mono text-[9px] text-primary-700">{insight.metric.label}</p>
                <p className="font-mono text-lg text-primary-crt">{insight.metric.value}</p>
              </div>
              {insight.metric.trend && <div className="ml-auto">{TREND_ICON[insight.metric.trend]}</div>}
            </div>
          )}

          {/* Affected employees */}
          {insight.employees && insight.employees.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-3">
              {insight.employees.slice(0, 4).map(e => (
                <a key={e.id} href={`/dashboard/employees/${e.id}`}
                  className="flex items-center gap-1.5 px-2 py-1 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-500 hover:border-primary-700 transition-all">
                  <Users className="w-2.5 h-2.5" />
                  {e.name}
                  {e.value && <span className="text-primary-700">({e.value})</span>}
                </a>
              ))}
              {insight.employees.length > 4 && (
                <span className="px-2 py-1 font-mono text-[9px] text-primary-700">+{insight.employees.length - 4} more</span>
              )}
            </div>
          )}

          {/* Recommendation */}
          {insight.recommendation && (
            <div className="flex items-start gap-2 p-2.5 bg-retro-bg border border-retro-border rounded-lg">
              <CheckCircle className="w-3.5 h-3.5 text-green-400 shrink-0 mt-0.5" />
              <p className="font-mono text-[10px] text-primary-600">{insight.recommendation}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function NineBoxGrid() {
  // Placeholder 9-box grid (Performance × Potential)
  const boxes = [
    { label: 'Question Mark', perf: 'low', pot: 'high', color: 'bg-yellow-950 border-yellow-800', count: 2 },
    { label: 'Rising Star', perf: 'mid', pot: 'high', color: 'bg-blue-950 border-blue-800', count: 5 },
    { label: 'Star', perf: 'high', pot: 'high', color: 'bg-green-950 border-green-800', count: 3 },
    { label: 'Under Performer', perf: 'low', pot: 'mid', color: 'bg-red-950 border-red-800', count: 1 },
    { label: 'Core Player', perf: 'mid', pot: 'mid', color: 'bg-primary-950 border-primary-700', count: 18 },
    { label: 'High Performer', perf: 'high', pot: 'mid', color: 'bg-teal-950 border-teal-800', count: 8 },
    { label: 'Risk', perf: 'low', pot: 'low', color: 'bg-red-950 border-red-900', count: 2 },
    { label: 'Specialist', perf: 'mid', pot: 'low', color: 'bg-primary-950 border-primary-800', count: 6 },
    { label: 'Consistent Star', perf: 'high', pot: 'low', color: 'bg-orange-950 border-orange-800', count: 4 },
  ];

  const perfLabels = ['High Performance', 'Mid Performance', 'Low Performance'];
  const potLabels = ['Low Potential', 'Mid Potential', 'High Potential'];

  const grid = [
    [boxes[0], boxes[1], boxes[2]],
    [boxes[3], boxes[4], boxes[5]],
    [boxes[6], boxes[7], boxes[8]],
  ].reverse();

  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <p className="font-pixel text-[8px] text-primary-500 mb-4">9-BOX PERFORMANCE DISTRIBUTION</p>
      <div className="flex gap-2">
        {/* Y-axis */}
        <div className="flex flex-col justify-around w-16 shrink-0">
          {perfLabels.map(l => <p key={l} className="font-mono text-[8px] text-primary-700 text-right leading-tight">{l}</p>)}
        </div>
        {/* Grid */}
        <div className="flex-1">
          <div className="grid grid-rows-3 grid-cols-3 gap-1.5 aspect-square">
            {grid.flat().map((box, i) => (
              <div key={i} className={`flex flex-col items-center justify-center rounded border p-1 ${box.color} cursor-default`}>
                <p className="font-pixel text-[14px] text-primary-300">{box.count}</p>
                <p className="font-mono text-[7px] text-primary-700 text-center leading-tight">{box.label}</p>
              </div>
            ))}
          </div>
          {/* X-axis */}
          <div className="grid grid-cols-3 gap-1.5 mt-1">
            {potLabels.map(l => <p key={l} className="font-mono text-[8px] text-primary-700 text-center">{l}</p>)}
          </div>
        </div>
      </div>
    </div>
  );
}

export function InsightsDashboard() {
  const { data = [], isLoading, refetch, isFetching } = useQuery<Insight[]>({
    queryKey: ['insights-all'],
    queryFn: () => api('/insights').then(r => r.data ?? []),
  });

  const insights = data as Insight[];
  const critical = insights.filter(i => i.severity === 'critical');
  const warnings = insights.filter(i => i.severity === 'warning');
  const infos = insights.filter(i => i.severity === 'info');

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">HR INSIGHTS</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">Rule-based signals · Refreshed daily at 7am IST</p>
        </div>
        <button onClick={() => refetch()} disabled={isFetching}
          className="flex items-center gap-2 px-3 py-2 border border-retro-border rounded font-pixel text-[7px] text-primary-600 hover:text-primary-400 disabled:opacity-50">
          <RefreshCw className={`w-3 h-3 ${isFetching ? 'animate-spin' : ''}`} /> REFRESH
        </button>
      </div>

      {/* Summary pills */}
      <div className="flex gap-3">
        {[
          { label: 'Critical', count: critical.length, cls: 'bg-red-950 border-red-800 text-red-400' },
          { label: 'Warning', count: warnings.length, cls: 'bg-yellow-950 border-yellow-800 text-yellow-400' },
          { label: 'Info', count: infos.length, cls: 'bg-blue-950 border-blue-900 text-blue-400' },
        ].map(p => (
          <div key={p.label} className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border font-mono ${p.cls}`}>
            <span className="text-xl font-pixel">{p.count}</span>
            <span className="text-sm">{p.label}</span>
          </div>
        ))}
      </div>

      {isLoading ? (
        <div className="py-16 text-center font-mono text-sm text-primary-700">Generating insights…</div>
      ) : insights.length === 0 ? (
        <div className="py-16 text-center">
          <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
          <p className="font-pixel text-[9px] text-primary-400 mb-1">All Clear!</p>
          <p className="font-mono text-xs text-primary-700">No active insights. Your HR metrics look healthy.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4">
          {/* Left: Critical + Warning */}
          <div className="space-y-4">
            {[...critical, ...warnings].map(i => <InsightCard key={i.id} insight={i} />)}
          </div>
          {/* Right: Info + 9-box */}
          <div className="space-y-4">
            {infos.map(i => <InsightCard key={i.id} insight={i} />)}
            <NineBoxGrid />
          </div>
        </div>
      )}
    </div>
  );
}
