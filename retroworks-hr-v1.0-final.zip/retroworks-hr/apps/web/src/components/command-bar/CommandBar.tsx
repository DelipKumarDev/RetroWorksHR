'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { Search, User, FileText, Calendar, BarChart2, Bot, Settings, LogOut, Zap, CreditCard, Clock, Users, ChevronRight, Command } from 'lucide-react';

const apiFetch = async (path: string) => {
  const res = await fetch(`/api/v1${path}`, { headers: { Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}` } });
  return res.json();
};

type RT = 'employee' | 'nav' | 'action';
interface Res { id: string; type: RT; label: string; sublabel?: string; icon: React.ReactNode; href?: string; action?: () => void; kbd?: string }

const NAV_ITEMS: Res[] = [
  { id: 'n-dash', type: 'nav', label: 'Dashboard', icon: <BarChart2 className="w-4 h-4" />, href: '/dashboard' },
  { id: 'n-emp', type: 'nav', label: 'Employees', icon: <Users className="w-4 h-4" />, href: '/dashboard/employees' },
  { id: 'n-leave', type: 'nav', label: 'Leave Management', icon: <Calendar className="w-4 h-4" />, href: '/dashboard/leave' },
  { id: 'n-att', type: 'nav', label: 'Attendance', icon: <Clock className="w-4 h-4" />, href: '/dashboard/attendance' },
  { id: 'n-pay', type: 'nav', label: 'Payroll & Payslips', icon: <CreditCard className="w-4 h-4" />, href: '/dashboard/payroll' },
  { id: 'n-ats', type: 'nav', label: 'Recruitment (ATS)', icon: <Users className="w-4 h-4" />, href: '/dashboard/ats' },
  { id: 'n-perf', type: 'nav', label: 'Performance Reviews', icon: <BarChart2 className="w-4 h-4" />, href: '/dashboard/performance' },
  { id: 'n-lnd', type: 'nav', label: 'Learning & Development', icon: <FileText className="w-4 h-4" />, href: '/dashboard/lnd' },
  { id: 'n-exp', type: 'nav', label: 'Expenses', icon: <CreditCard className="w-4 h-4" />, href: '/dashboard/expenses' },
  { id: 'n-hd', type: 'nav', label: 'HR Helpdesk', icon: <Zap className="w-4 h-4" />, href: '/dashboard/helpdesk' },
  { id: 'n-ai', type: 'nav', label: 'RetroBot AI', icon: <Bot className="w-4 h-4" />, href: '/dashboard/ai' },
  { id: 'n-rep', type: 'nav', label: 'Reports & Analytics', icon: <BarChart2 className="w-4 h-4" />, href: '/dashboard/reports' },
  { id: 'n-set', type: 'nav', label: 'Settings', icon: <Settings className="w-4 h-4" />, href: '/dashboard/settings' },
];

const QUICK_ACTIONS: Res[] = [
  { id: 'a-leave', type: 'action', label: 'Apply for Leave', sublabel: 'Submit a new leave request', icon: <Calendar className="w-4 h-4 text-blue-400" />, href: '/dashboard/leave?apply=true', kbd: 'L' },
  { id: 'a-payslip', type: 'action', label: 'Download Latest Payslip', sublabel: 'Get your most recent payslip', icon: <CreditCard className="w-4 h-4 text-green-400" />, href: '/dashboard/payroll' },
  { id: 'a-ticket', type: 'action', label: 'Raise HR Ticket', sublabel: 'Submit an HR support request', icon: <Zap className="w-4 h-4 text-yellow-400" />, href: '/dashboard/helpdesk?new=true' },
  { id: 'a-profile', type: 'action', label: 'Edit My Profile', sublabel: 'Update personal information', icon: <User className="w-4 h-4 text-purple-400" />, href: '/dashboard/employees/me' },
  { id: 'a-ai', type: 'action', label: 'Ask RetroBot', sublabel: 'Chat with the HR AI assistant', icon: <Bot className="w-4 h-4 text-primary-crt" />, href: '/dashboard/ai' },
  { id: 'a-logout', type: 'action', label: 'Sign Out', sublabel: 'End your session', icon: <LogOut className="w-4 h-4 text-red-400" />, action: () => { if (typeof localStorage !== 'undefined') localStorage.clear(); window.location.href = '/login'; } },
];

export function CommandBar() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  const { data: searchData } = useQuery({
    queryKey: ['cmd-search', query],
    queryFn: () => apiFetch(`/ai/search?q=${encodeURIComponent(query)}&types=employees`).then(r => r.data ?? {}),
    enabled: open && query.length >= 2,
    staleTime: 5000,
  });

  const empResults: Res[] = (searchData?.employees ?? []).slice(0, 5).map((e: any) => ({
    id: `emp-${e.id}`, type: 'employee' as RT,
    label: `${e.firstName} ${e.lastName}`,
    sublabel: `${e.designation?.name ?? ''} · ${e.department?.name ?? ''} · ${e.employeeCode}`,
    icon: <div className="w-7 h-7 rounded-full bg-primary-900 border border-primary-700 flex items-center justify-center font-mono text-[9px] text-primary-400">{e.firstName?.[0]}{e.lastName?.[0]}</div>,
    href: `/dashboard/employees/${e.id}`,
  }));

  const filtNavs = query.length < 2 ? [] : NAV_ITEMS.filter(n => n.label.toLowerCase().includes(query.toLowerCase())).slice(0, 4);
  const filtActions = query.length < 2 ? QUICK_ACTIONS : QUICK_ACTIONS.filter(a => a.label.toLowerCase().includes(query.toLowerCase()) || (a.sublabel ?? '').toLowerCase().includes(query.toLowerCase()));
  const all: Res[] = [...empResults, ...filtNavs, ...filtActions];

  const handleSelect = useCallback((r: Res) => {
    setOpen(false); setQuery('');
    if (r.action) { r.action(); return; }
    if (r.href) router.push(r.href);
  }, [router]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); setOpen(o => !o); setQuery(''); setSelected(0); }
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  useEffect(() => {
    if (!open) return;
    const h = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') { e.preventDefault(); setSelected(s => Math.min(s + 1, all.length - 1)); }
      if (e.key === 'ArrowUp') { e.preventDefault(); setSelected(s => Math.max(s - 1, 0)); }
      if (e.key === 'Enter' && all[selected]) handleSelect(all[selected]);
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [open, selected, all, handleSelect]);

  useEffect(() => { if (open) { setTimeout(() => inputRef.current?.focus(), 50); setSelected(0); } }, [open]);

  if (!open) return (
    <button onClick={() => setOpen(true)} className="flex items-center gap-2 px-3 py-1.5 bg-retro-bg border border-retro-border rounded-lg font-mono text-xs text-primary-700 hover:border-primary-700 hover:text-primary-500 transition-all">
      <Search className="w-3.5 h-3.5" /><span>Search…</span>
      <span className="ml-2 flex items-center gap-0.5 text-[9px] text-primary-800"><Command className="w-2.5 h-2.5" />K</span>
    </button>
  );

  return (
    <div className="fixed inset-0 z-[200] flex items-start justify-center pt-20">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setOpen(false)} />
      <div className="relative w-full max-w-xl bg-retro-card border border-retro-border rounded-xl shadow-2xl overflow-hidden">
        <div className="flex items-center gap-3 px-4 py-3 border-b border-retro-border">
          <Search className="w-4 h-4 text-primary-600 shrink-0" />
          <input ref={inputRef} value={query} onChange={e => { setQuery(e.target.value); setSelected(0); }} placeholder="Search employees, pages, actions…" className="flex-1 bg-transparent font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:outline-none" />
          {query && <button onClick={() => setQuery('')} className="text-primary-700 hover:text-primary-500 font-mono text-xs">Clear</button>}
          <kbd className="font-mono text-[9px] text-primary-800 border border-retro-border rounded px-1.5 py-0.5">ESC</kbd>
        </div>
        <div className="max-h-80 overflow-y-auto">
          {all.length === 0 && query.length >= 2 && <div className="py-10 text-center font-mono text-sm text-primary-700">No results for "{query}"</div>}
          {query.length < 2 && <p className="px-3 pt-3 pb-1 font-pixel text-[7px] text-primary-800">QUICK ACTIONS</p>}
          {empResults.length > 0 && <p className="px-3 pt-3 pb-1 font-pixel text-[7px] text-primary-800">EMPLOYEES</p>}
          {all.map((r, i) => {
            const newGroup = i > 0 && r.type !== all[i-1].type;
            return (
              <div key={r.id}>
                {newGroup && <p className="px-3 pt-3 pb-1 font-pixel text-[7px] text-primary-800">{r.type === 'nav' ? 'NAVIGATION' : 'ACTIONS'}</p>}
                <button onMouseEnter={() => setSelected(i)} onClick={() => handleSelect(r)} className={`w-full flex items-center gap-3 px-4 py-2.5 text-left transition-colors ${i === selected ? 'bg-primary-950' : 'hover:bg-surface-raised'}`}>
                  <div className="shrink-0 text-primary-700">{r.icon}</div>
                  <div className="flex-1 min-w-0">
                    <p className={`font-mono text-sm truncate ${i === selected ? 'text-primary-200' : 'text-primary-400'}`}>{r.label}</p>
                    {r.sublabel && <p className="font-mono text-[10px] text-primary-700 truncate">{r.sublabel}</p>}
                  </div>
                  {r.kbd && <kbd className="shrink-0 font-mono text-[8px] text-primary-800 border border-retro-border rounded px-1.5 py-0.5">{r.kbd}</kbd>}
                  <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${i === selected ? 'text-primary-500' : 'text-primary-800'}`} />
                </button>
              </div>
            );
          })}
        </div>
        <div className="flex items-center gap-4 px-4 py-2 border-t border-retro-border bg-retro-bg">
          {[['↑↓', 'navigate'], ['↵', 'select'], ['esc', 'close']].map(([k, v]) => (
            <span key={k} className="flex items-center gap-1 font-mono text-[9px] text-primary-800"><kbd className="border border-retro-border rounded px-1">{k}</kbd> {v}</span>
          ))}
        </div>
      </div>
    </div>
  );
}
