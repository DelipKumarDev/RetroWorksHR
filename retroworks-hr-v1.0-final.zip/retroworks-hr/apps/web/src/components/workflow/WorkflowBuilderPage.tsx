'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, GitBranch, Settings, Eye, Edit3, Archive, RefreshCw } from 'lucide-react';
import { WorkflowBuilder } from './WorkflowBuilder';
import type { WorkflowNode, WorkflowTransition } from '@retroworks/types';

interface WorkflowDef {
  id: string;
  name: string;
  module: string;
  entityType: string;
  version: number;
  status: 'draft' | 'active' | 'archived';
  publishedAt?: string;
  _count: { instances: number };
}

const MODULE_COLORS: Record<string, string> = {
  leave: 'text-blue-400 bg-blue-950 border-blue-800',
  payroll: 'text-green-400 bg-green-950 border-green-800',
  ats: 'text-purple-400 bg-purple-950 border-purple-800',
  expense: 'text-amber-400 bg-amber-950 border-amber-800',
  helpdesk: 'text-cyan-400 bg-cyan-950 border-cyan-800',
};

export function WorkflowBuilderClientPage() {
  const [selected, setSelected] = useState<WorkflowDef | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [newModule, setNewModule] = useState('leave');
  const qc = useQueryClient();

  const { data: workflows = [], isLoading } = useQuery<WorkflowDef[]>({
    queryKey: ['workflows'],
    queryFn: async () => {
      const res = await fetch('/api/v1/workflows', {
        headers: { Authorization: `Bearer ${localStorage.getItem('token') ?? ''}` },
      });
      const json = await res.json() as { data: WorkflowDef[] };
      return json.data ?? [];
    },
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch('/api/v1/workflows', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token') ?? ''}`,
        },
        body: JSON.stringify({
          name: newName,
          module: newModule,
          entityType: `${newModule}-request`,
          nodes: [
            { id: 'start', type: 'start', label: 'Start', x: 250, y: 50, config: {} },
            { id: 'pending', type: 'state', label: 'Pending', x: 200, y: 160, config: { assigneeRoles: ['manager'] } },
            { id: 'end', type: 'end', label: 'End', x: 250, y: 320, config: {} },
          ],
          transitions: [
            { id: 't1', fromNodeId: 'start', toNodeId: 'pending', label: 'Submit', trigger: 'manual' },
            { id: 't2', fromNodeId: 'pending', toNodeId: 'end', label: 'approve', trigger: 'manual' },
          ],
        }),
      });
      return res.json();
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['workflows'] });
      setIsCreating(false);
      setNewName('');
    },
  });

  const statusColors: Record<string, string> = {
    draft: 'text-primary-600 bg-retro-bg border-retro-border',
    active: 'text-green-400 bg-green-950 border-green-800',
    archived: 'text-primary-800 bg-retro-bg border-retro-border',
  };

  return (
    <div className="flex h-full gap-4 min-h-0">
      {/* Left panel — workflow list */}
      <div className="w-72 shrink-0 flex flex-col gap-3">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h2 className="font-pixel text-[10px] text-primary-400">WORKFLOWS</h2>
          <button
            onClick={() => setIsCreating(true)}
            className="flex items-center gap-1 px-2 py-1 bg-primary-950 border border-primary-700 hover:border-primary-crt hover:shadow-glow font-pixel text-[7px] text-primary-crt rounded transition-all"
          >
            <Plus className="w-3 h-3" /> NEW
          </button>
        </div>

        {/* New workflow form */}
        {isCreating && (
          <div className="bg-retro-card border border-primary-800 rounded p-3 space-y-2 animate-slide-down">
            <input
              value={newName}
              onChange={e => setNewName(e.target.value)}
              placeholder="Workflow name..."
              className="w-full bg-retro-bg border border-retro-border rounded px-2 py-1.5 font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none"
              autoFocus
            />
            <select
              value={newModule}
              onChange={e => setNewModule(e.target.value)}
              className="w-full bg-retro-bg border border-retro-border rounded px-2 py-1.5 font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none"
            >
              <option value="leave">Leave</option>
              <option value="payroll">Payroll</option>
              <option value="ats">Recruitment</option>
              <option value="expense">Expense</option>
              <option value="helpdesk">Helpdesk</option>
              <option value="onboarding">Onboarding</option>
            </select>
            <div className="flex gap-2">
              <button
                onClick={() => createMutation.mutate()}
                disabled={!newName.trim() || createMutation.isPending}
                className="flex-1 py-1 bg-primary-900 border border-primary-600 font-pixel text-[7px] text-primary-crt rounded hover:shadow-glow disabled:opacity-50"
              >
                CREATE
              </button>
              <button
                onClick={() => setIsCreating(false)}
                className="px-2 py-1 border border-retro-border font-mono text-xs text-primary-700 rounded"
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* Workflow list */}
        <div className="flex-1 overflow-y-auto space-y-2">
          {isLoading ? (
            Array.from({ length: 3 }, (_, i) => (
              <div key={i} className="h-16 skeleton rounded" />
            ))
          ) : workflows.length === 0 ? (
            <div className="text-center py-8">
              <GitBranch className="w-8 h-8 text-primary-800 mx-auto mb-2" />
              <p className="font-pixel text-[8px] text-primary-800">No workflows yet</p>
            </div>
          ) : (
            workflows.map(wf => (
              <button
                key={wf.id}
                onClick={() => setSelected(wf)}
                className={`w-full text-left p-3 rounded border transition-all ${
                  selected?.id === wf.id
                    ? 'bg-primary-950 border-primary-700 shadow-glow'
                    : 'bg-retro-card border-retro-border hover:border-primary-800'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="font-pixel text-[8px] text-primary-300 truncate">{wf.name}</p>
                    <p className="font-mono text-[10px] text-primary-700 mt-0.5">v{wf.version} · {wf._count.instances} runs</p>
                  </div>
                  <span className={`px-1.5 py-0.5 border rounded font-pixel text-[6px] shrink-0 ${statusColors[wf.status]}`}>
                    {wf.status.toUpperCase()}
                  </span>
                </div>
                <span className={`mt-1 inline-block px-1.5 py-0.5 border rounded font-mono text-[9px] ${MODULE_COLORS[wf.module] ?? 'text-primary-600 bg-retro-bg border-retro-border'}`}>
                  {wf.module}
                </span>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Right panel — editor */}
      <div className="flex-1 bg-retro-card border border-retro-border rounded overflow-hidden">
        {selected ? (
          <div className="h-full flex flex-col">
            {/* Editor header */}
            <div className="flex items-center gap-3 px-4 py-3 border-b border-retro-border bg-retro-bg">
              <span className="w-2 h-2 bg-red-600 opacity-70" />
              <span className="w-2 h-2 bg-accent-dim opacity-70" />
              <span className="w-2 h-2 bg-primary-700 opacity-70" />
              <span className="font-pixel text-[8px] text-primary-600 ml-1">
                {selected.name}
              </span>
              <span className={`px-1.5 py-0.5 border rounded font-pixel text-[6px] ${statusColors[selected.status]}`}>
                {selected.status.toUpperCase()}
              </span>
            </div>
            <WorkflowBuilder
              workflowId={selected.id}
              readOnly={selected.status === 'active'}
              onSave={async (nodes, transitions) => {
                await fetch(`/api/v1/workflows/${selected.id}`, {
                  method: 'PATCH',
                  headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${localStorage.getItem('token') ?? ''}`,
                  },
                  body: JSON.stringify({ nodes, transitions }),
                });
                void qc.invalidateQueries({ queryKey: ['workflows'] });
              }}
            />
          </div>
        ) : (
          <div className="h-full flex flex-col items-center justify-center text-center p-8">
            <GitBranch className="w-12 h-12 text-primary-800 mb-4" />
            <p className="font-pixel text-[10px] text-primary-600 mb-2">
              SELECT A WORKFLOW
            </p>
            <p className="font-mono text-xs text-primary-800">
              Choose a workflow from the left or create a new one
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
