'use client';

import { useCallback, useState } from 'react';
import ReactFlow, {
  type Node, type Edge, type Connection,
  addEdge, useNodesState, useEdgesState,
  Background, Controls, MiniMap,
  MarkerType, Panel,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Plus, Save, Play, RotateCcw, GitBranch, Zap } from 'lucide-react';
import type { WorkflowNode, WorkflowTransition } from '@retroworks/types';

// ─────────────────────────────────────────────
// Custom Node Components
// ─────────────────────────────────────────────

function StartNode({ data }: { data: { label: string } }) {
  return (
    <div className="px-4 py-2 bg-primary-950 border-2 border-primary-crt rounded font-pixel text-[8px] text-primary-crt shadow-glow min-w-[80px] text-center">
      ▶ {data.label}
    </div>
  );
}

function StateNode({ data, selected }: { data: { label: string; roles?: string[] }; selected: boolean }) {
  return (
    <div className={`px-4 py-3 bg-retro-card border-2 rounded min-w-[120px] transition-all ${
      selected ? 'border-primary-crt shadow-glow-strong' : 'border-retro-border'
    }`}>
      <p className="font-pixel text-[8px] text-primary-400 text-center mb-1">{data.label}</p>
      {data.roles?.map(r => (
        <span key={r} className="block text-center font-mono text-[9px] text-primary-700">{r}</span>
      ))}
    </div>
  );
}

function DecisionNode({ data, selected }: { data: { label: string }; selected: boolean }) {
  return (
    <div className={`w-20 h-20 flex items-center justify-center bg-amber-950 border-2 rounded rotate-45 transition-all ${
      selected ? 'border-accent-crt shadow-glow-accent' : 'border-accent/50'
    }`}>
      <span className="-rotate-45 font-pixel text-[7px] text-accent-crt text-center px-1">{data.label}</span>
    </div>
  );
}

function EndNode({ data }: { data: { label: string } }) {
  return (
    <div className="px-4 py-2 bg-retro-bg border-2 border-primary-800 rounded font-pixel text-[8px] text-primary-700 min-w-[80px] text-center">
      ⏹ {data.label}
    </div>
  );
}

const NODE_TYPES = {
  start: StartNode,
  state: StateNode,
  decision: DecisionNode,
  end: EndNode,
};

// ─────────────────────────────────────────────
// Default workflow template (Leave Approval)
// ─────────────────────────────────────────────

const DEFAULT_NODES: Node[] = [
  { id: 'start', type: 'start', position: { x: 250, y: 50 }, data: { label: 'Start' } },
  { id: 'pending', type: 'state', position: { x: 200, y: 160 }, data: { label: 'Pending Review', roles: ['manager'] } },
  { id: 'approved', type: 'state', position: { x: 100, y: 320 }, data: { label: 'Approved' } },
  { id: 'rejected', type: 'state', position: { x: 380, y: 320 }, data: { label: 'Rejected' } },
  { id: 'end', type: 'end', position: { x: 250, y: 460 }, data: { label: 'End' } },
];

const DEFAULT_EDGES: Edge[] = [
  { id: 'e1', source: 'start', target: 'pending', animated: true, style: { stroke: '#22c55e' } },
  { id: 'e2', source: 'pending', target: 'approved', label: 'Approve', style: { stroke: '#22c55e' }, markerEnd: { type: MarkerType.ArrowClosed, color: '#22c55e' } },
  { id: 'e3', source: 'pending', target: 'rejected', label: 'Reject', style: { stroke: '#ef4444' }, markerEnd: { type: MarkerType.ArrowClosed, color: '#ef4444' } },
  { id: 'e4', source: 'approved', target: 'end', style: { stroke: '#22c55e' }, markerEnd: { type: MarkerType.ArrowClosed, color: '#22c55e' } },
  { id: 'e5', source: 'rejected', target: 'end', style: { stroke: '#60706 0' }, markerEnd: { type: MarkerType.ArrowClosed, color: '#607060' } },
];

// ─────────────────────────────────────────────
// Workflow Builder Component
// ─────────────────────────────────────────────

interface WorkflowBuilderProps {
  workflowId?: string;
  initialNodes?: Node[];
  initialEdges?: Edge[];
  onSave?: (nodes: WorkflowNode[], transitions: WorkflowTransition[]) => Promise<void>;
  readOnly?: boolean;
}

export function WorkflowBuilder({
  workflowId,
  initialNodes = DEFAULT_NODES,
  initialEdges = DEFAULT_EDGES,
  onSave,
  readOnly = false,
}: WorkflowBuilderProps) {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState<Node | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saved' | 'error'>('idle');

  const onConnect = useCallback(
    (connection: Connection) => {
      if (readOnly) return;
      setEdges(eds =>
        addEdge({
          ...connection,
          animated: true,
          style: { stroke: '#22c55e' },
          markerEnd: { type: MarkerType.ArrowClosed, color: '#22c55e' },
          label: 'Transition',
        }, eds)
      );
    },
    [readOnly, setEdges],
  );

  const addNode = (type: 'state' | 'decision') => {
    const newNode: Node = {
      id: `node-${Date.now()}`,
      type,
      position: { x: 200 + Math.random() * 100, y: 200 + Math.random() * 100 },
      data: {
        label: type === 'state' ? 'New State' : 'Decision',
        roles: type === 'state' ? ['employee'] : undefined,
      },
    };
    setNodes(nds => [...nds, newNode]);
  };

  const handleSave = async () => {
    if (!onSave) return;
    setIsSaving(true);
    try {
      // Convert React Flow nodes/edges → workflow types
      const wfNodes: WorkflowNode[] = nodes.map(n => ({
        id: n.id,
        type: (n.type ?? 'state') as WorkflowNode['type'],
        label: (n.data as { label: string }).label,
        x: n.position.x,
        y: n.position.y,
        config: {
          assigneeRoles: (n.data as { roles?: string[] }).roles,
        },
      }));

      const wfTransitions: WorkflowTransition[] = edges.map(e => ({
        id: e.id,
        fromNodeId: e.source,
        toNodeId: e.target,
        label: (e.label as string) || 'Transition',
        trigger: 'manual' as const,
        conditions: [],
        actions: [],
      }));

      await onSave(wfNodes, wfTransitions);
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 3000);
    } catch {
      setSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      {!readOnly && (
        <div className="flex items-center gap-2 px-4 py-2 bg-retro-bg-secondary border-b border-retro-border">
          <span className="font-pixel text-[8px] text-primary-700 mr-2">ADD NODE:</span>

          <button
            onClick={() => addNode('state')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-retro-card border border-retro-border hover:border-primary-700 font-pixel text-[8px] text-primary-500 rounded transition-all"
          >
            <Plus className="w-3 h-3" /> State
          </button>
          <button
            onClick={() => addNode('decision')}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-950/50 border border-accent/30 hover:border-accent font-pixel text-[8px] text-accent rounded transition-all"
          >
            <GitBranch className="w-3 h-3" /> Decision
          </button>

          <div className="flex-1" />

          {/* Save button */}
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="flex items-center gap-1.5 px-4 py-1.5 bg-primary-900 border border-primary-600 hover:border-primary-crt hover:shadow-glow font-pixel text-[8px] text-primary-crt rounded transition-all disabled:opacity-50"
          >
            {isSaving ? <span className="animate-blink-cursor">▋</span> : <Save className="w-3 h-3" />}
            {saveStatus === 'saved' ? '✓ SAVED' : saveStatus === 'error' ? '✗ ERROR' : 'SAVE'}
          </button>

          <button className="flex items-center gap-1.5 px-3 py-1.5 bg-green-950 border border-green-700 hover:border-green-500 font-pixel text-[8px] text-green-400 rounded transition-all">
            <Play className="w-3 h-3" /> PUBLISH
          </button>
        </div>
      )}

      {/* Flow Canvas */}
      <div className="flex-1 relative bg-retro-bg" style={{ height: 600 }}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={readOnly ? undefined : onNodesChange}
          onEdgesChange={readOnly ? undefined : onEdgesChange}
          onConnect={onConnect}
          onNodeClick={(_, node) => setSelectedNode(node)}
          nodeTypes={NODE_TYPES}
          fitView
          className="bg-retro-bg"
          proOptions={{ hideAttribution: true }}
        >
          <Background color="#1a2e1a" gap={24} />
          <Controls
            className="[&>button]:bg-retro-card [&>button]:border [&>button]:border-retro-border [&>button]:text-primary-500"
          />
          <MiniMap
            className="bg-retro-bg border border-retro-border"
            nodeColor="#1a2e1a"
            maskColor="rgba(8,12,8,0.8)"
          />

          {/* Legend */}
          <Panel position="top-left">
            <div className="bg-retro-card border border-retro-border rounded p-3 text-[9px] font-mono">
              <p className="text-primary-600 mb-2 font-pixel text-[7px]">LEGEND</p>
              <div className="space-y-1">
                <div className="flex items-center gap-2"><span className="w-3 h-0.5 bg-primary-crt" /> Transition</div>
                <div className="flex items-center gap-2"><span className="w-3 h-0.5 bg-red-500" /> Rejection</div>
                <div className="flex items-center gap-2"><span className="w-3 h-3 border border-primary-crt bg-primary-950" /> State</div>
                <div className="flex items-center gap-2"><span className="w-3 h-3 border border-accent bg-amber-950 rotate-45" /> Decision</div>
              </div>
            </div>
          </Panel>
        </ReactFlow>
      </div>

      {/* Node Properties Panel */}
      {selectedNode && !readOnly && (
        <div className="border-t border-retro-border bg-retro-bg-secondary p-4">
          <div className="flex items-center gap-2 mb-3">
            <Zap className="w-4 h-4 text-primary-600" />
            <span className="font-pixel text-[9px] text-primary-500">NODE PROPERTIES</span>
            <button
              onClick={() => setSelectedNode(null)}
              className="ml-auto font-mono text-xs text-primary-700 hover:text-primary-500"
            >
              ✕
            </button>
          </div>
          <div className="grid grid-cols-3 gap-4 text-sm">
            <div>
              <label className="block font-pixel text-[7px] text-primary-700 mb-1">ID</label>
              <p className="font-mono text-xs text-primary-500">{selectedNode.id}</p>
            </div>
            <div>
              <label className="block font-pixel text-[7px] text-primary-700 mb-1">TYPE</label>
              <p className="font-mono text-xs text-primary-400">{selectedNode.type}</p>
            </div>
            <div>
              <label className="block font-pixel text-[7px] text-primary-700 mb-1">LABEL</label>
              <input
                defaultValue={(selectedNode.data as { label: string }).label}
                className="w-full bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none"
                onChange={(e) => {
                  setNodes(nds =>
                    nds.map(n =>
                      n.id === selectedNode.id
                        ? { ...n, data: { ...n.data, label: e.target.value } }
                        : n
                    )
                  );
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
