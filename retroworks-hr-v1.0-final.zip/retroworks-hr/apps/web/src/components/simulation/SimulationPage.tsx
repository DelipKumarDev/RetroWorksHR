'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Play, Building2, TrendingUp, TrendingDown, Users, DollarSign, AlertTriangle, ChevronDown, ChevronUp, Trash2, Save } from 'lucide-react';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...(opts?.headers ?? {}) } });
  return res.json();
};

const SCENARIOS = [
  { id: 'mass_attrition', label: 'Mass Attrition', icon: <TrendingDown className="w-4 h-4 text-red-400" />, desc: 'Simulate N employees resigning', color: 'red' },
  { id: 'salary_increment', label: 'Salary Increment', icon: <TrendingUp className="w-4 h-4 text-green-400" />, desc: 'Apply % increment to a cohort', color: 'green' },
  { id: 'hiring_plan', label: 'Hiring Plan', icon: <Users className="w-4 h-4 text-blue-400" />, desc: 'Add N new hires at given CTC', color: 'blue' },
  { id: 'promotion', label: 'Promotion Round', icon: <TrendingUp className="w-4 h-4 text-purple-400" />, desc: 'Promote employees with % hike', color: 'purple' },
  { id: 'department_create', label: 'New Department', icon: <Building2 className="w-4 h-4 text-yellow-400" />, desc: 'Model new team with headcount', color: 'yellow' },
];

function MetricTile({ label, value, delta, prefix = '' }: { label: string; value: string | number; delta?: number; prefix?: string }) {
  const isPos = delta !== undefined && delta > 0;
  const isNeg = delta !== undefined && delta < 0;
  return (
    <div className="bg-retro-card border border-retro-border rounded-lg p-4">
      <p className="font-mono text-[10px] text-primary-700 mb-1">{label}</p>
      <p className="font-pixel text-[14px] text-primary-crt">{prefix}{value}</p>
      {delta !== undefined && delta !== 0 && (
        <p className={`font-mono text-[10px] mt-1 flex items-center gap-0.5 ${isPos ? 'text-green-400' : 'text-red-400'}`}>
          {isPos ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
          {isPos ? '+' : ''}{typeof delta === 'number' && Math.abs(delta) < 1000 ? delta.toFixed(1) : delta.toLocaleString('en-IN')}
        </p>
      )}
    </div>
  );
}

function RiskFlag({ flag }: { flag: { severity: string; title: string; detail: string } }) {
  const colors = { critical: 'bg-red-950/20 border-red-900 text-red-400', warning: 'bg-yellow-950/20 border-yellow-900 text-yellow-400', info: 'bg-primary-950/20 border-primary-900 text-primary-400' };
  return (
    <div className={`flex items-start gap-3 p-3 rounded-lg border ${(colors as any)[flag.severity] ?? colors.info}`}>
      <AlertTriangle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
      <div><p className="font-mono text-xs font-medium">{flag.title}</p><p className="font-mono text-[10px] mt-0.5 opacity-80">{flag.detail}</p></div>
    </div>
  );
}

export function SimulationPage() {
  const [scenario, setScenario] = useState('mass_attrition');
  const [params, setParams] = useState<Record<string, any>>({});
  const [name, setName] = useState('');
  const [result, setResult] = useState<any>(null);
  const qc = useQueryClient();

  const { data: baseline } = useQuery({ queryKey: ['sim-baseline'], queryFn: () => api('/simulation/baseline').then(r => r.data) });
  const { data: savedScenarios = [] } = useQuery({ queryKey: ['sim-scenarios'], queryFn: () => api('/simulation/scenarios').then(r => r.data ?? []) });
  const { data: departments = [] } = useQuery({ queryKey: ['departments'], queryFn: () => api('/settings/departments').then(r => r.data ?? []) });

  const runMutation = useMutation({
    mutationFn: () => api('/simulation/run', { method: 'POST', body: JSON.stringify({ scenario, name: name || `${scenario} scenario`, ...params }) }),
    onSuccess: r => { setResult(r.data); qc.invalidateQueries({ queryKey: ['sim-scenarios'] }); },
  });
  const delMutation = useMutation({
    mutationFn: (id: string) => api(`/simulation/scenarios/${id}`, { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sim-scenarios'] }),
  });

  const inputCls = "w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 focus:border-primary-600 focus:outline-none";
  const sel = SCENARIOS.find(s => s.id === scenario);

  const formatINR = (n: number) => n >= 100_000 ? `₹${(n / 100_000).toFixed(1)}L` : `₹${n.toLocaleString('en-IN')}`;

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-pixel text-[10px] text-primary-crt">ORG DIGITAL TWIN</h1>
        <p className="font-mono text-xs text-primary-700 mt-1">Simulate what-if scenarios before making decisions — no competitor does this natively</p>
      </div>

      {/* Baseline */}
      {baseline && (
        <div className="grid grid-cols-5 gap-3">
          <MetricTile label="Total Headcount" value={baseline.headcount} />
          <MetricTile label="Monthly Payroll" value={formatINR(baseline.monthlyPayroll)} />
          <MetricTile label="Annual Payroll" value={formatINR(baseline.annualPayroll)} />
          <MetricTile label="Avg CTC" value={formatINR(baseline.averageCTC)} />
          <MetricTile label="Employer Cost/mo" value={formatINR(baseline.monthlyEmployerCost)} />
        </div>
      )}

      <div className="grid grid-cols-12 gap-5">
        {/* Left: Builder */}
        <div className="col-span-7 space-y-5">
          <div className="bg-retro-card border border-retro-border rounded-xl p-5 space-y-4">
            <p className="font-pixel text-[8px] text-primary-500">SELECT SCENARIO</p>
            <div className="grid grid-cols-3 gap-2">
              {SCENARIOS.map(s => (
                <button key={s.id} onClick={() => { setScenario(s.id); setParams({}); setResult(null); }} className={`flex items-start gap-2 p-3 rounded-lg border text-left transition-all ${scenario === s.id ? 'bg-primary-950 border-primary-700 shadow-glow' : 'bg-retro-bg border-retro-border hover:border-primary-800'}`}>
                  {s.icon}
                  <div><p className={`font-mono text-xs ${scenario === s.id ? 'text-primary-300' : 'text-primary-600'}`}>{s.label}</p><p className="font-mono text-[9px] text-primary-800 mt-0.5">{s.desc}</p></div>
                </button>
              ))}
            </div>

            <div>
              <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">SCENARIO NAME</label>
              <input value={name} onChange={e => setName(e.target.value)} placeholder={`e.g. Q1 ${sel?.label} Plan`} className={inputCls} />
            </div>

            {/* Dynamic params */}
            {scenario === 'mass_attrition' && (
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">NUMBER OF RESIGNATIONS</label><input type="number" min="1" value={params.attritionCount ?? 5} onChange={e => setParams({ ...params, attritionCount: +e.target.value })} className={inputCls} /></div>
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">DEPARTMENT (optional)</label><select value={params.attritionDepartmentId ?? ''} onChange={e => setParams({ ...params, attritionDepartmentId: e.target.value || undefined })} className={`${inputCls}`}><option value="">All departments</option>{(departments as any[]).map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
              </div>
            )}
            {scenario === 'salary_increment' && (
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">INCREMENT %</label><input type="number" min="1" max="100" value={params.incrementPercent ?? 10} onChange={e => setParams({ ...params, incrementPercent: +e.target.value })} className={inputCls} /></div>
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">DEPARTMENT (optional)</label><select value={params.incrementDepartmentId ?? ''} onChange={e => setParams({ ...params, incrementDepartmentId: e.target.value || undefined })} className={inputCls}><option value="">All departments</option>{(departments as any[]).map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
              </div>
            )}
            {scenario === 'hiring_plan' && (
              <div className="grid grid-cols-3 gap-3">
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">HIRE COUNT</label><input type="number" min="1" value={params.hireCount ?? 10} onChange={e => setParams({ ...params, hireCount: +e.target.value })} className={inputCls} /></div>
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">AVG CTC (₹)</label><input type="number" value={params.hireAverageCTC ?? 800000} onChange={e => setParams({ ...params, hireAverageCTC: +e.target.value })} className={inputCls} /></div>
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">DEPARTMENT</label><select value={params.hireDepartmentId ?? ''} onChange={e => setParams({ ...params, hireDepartmentId: e.target.value || undefined })} className={inputCls}><option value="">Select</option>{(departments as any[]).map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></div>
              </div>
            )}
            {scenario === 'promotion' && (
              <div className="grid grid-cols-2 gap-3">
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">PROMOTE COUNT</label><input type="number" min="1" value={params.promoteCount ?? 5} onChange={e => setParams({ ...params, promoteCount: +e.target.value })} className={inputCls} /></div>
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">HIKE %</label><input type="number" min="1" value={params.promoteIncrementPercent ?? 20} onChange={e => setParams({ ...params, promoteIncrementPercent: +e.target.value })} className={inputCls} /></div>
              </div>
            )}
            {scenario === 'department_create' && (
              <div className="grid grid-cols-3 gap-3">
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">DEPT NAME</label><input value={params.newDeptName ?? ''} onChange={e => setParams({ ...params, newDeptName: e.target.value })} className={inputCls} /></div>
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">HEADCOUNT</label><input type="number" min="1" value={params.newDeptHeadcount ?? 10} onChange={e => setParams({ ...params, newDeptHeadcount: +e.target.value })} className={inputCls} /></div>
                <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">AVG CTC (₹)</label><input type="number" value={params.newDeptAverageCTC ?? 1000000} onChange={e => setParams({ ...params, newDeptAverageCTC: +e.target.value })} className={inputCls} /></div>
              </div>
            )}

            <button onClick={() => runMutation.mutate()} disabled={runMutation.isPending} className="flex items-center gap-2 px-5 py-2.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500 disabled:opacity-50 transition-all w-full justify-center">
              <Play className="w-4 h-4" />{runMutation.isPending ? 'Running simulation…' : 'Run Simulation'}
            </button>
          </div>

          {/* Result */}
          {result && (
            <div className="bg-retro-card border border-primary-800 rounded-xl p-5 space-y-4">
              <p className="font-pixel text-[8px] text-primary-crt">SIMULATION RESULT — {result.name}</p>
              <div className="grid grid-cols-3 gap-3">
                <MetricTile label="Headcount Δ" value={result.delta.headcountChange >= 0 ? `+${result.delta.headcountChange}` : result.delta.headcountChange} delta={result.delta.headcountChange} />
                <MetricTile label="Monthly Payroll Δ" value={formatINR(Math.abs(result.delta.monthlyPayrollChange))} delta={result.delta.monthlyPayrollChange} />
                <MetricTile label="Annual Payroll Δ" value={formatINR(Math.abs(result.delta.annualPayrollChange))} delta={result.delta.annualPayrollChange} />
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-3 bg-retro-bg border border-retro-border rounded"><p className="text-primary-700 mb-2 font-pixel text-[7px]">BASELINE</p><p className="text-primary-500">{result.baseline.headcount} people · {formatINR(result.baseline.monthlyPayroll)}/mo</p></div>
                <div className="p-3 bg-primary-950/30 border border-primary-800 rounded"><p className="text-primary-crt mb-2 font-pixel text-[7px]">PROJECTED</p><p className="text-primary-400">{result.projected.headcount} people · {formatINR(result.projected.monthlyPayroll)}/mo</p></div>
              </div>
              {result.riskFlags?.length > 0 && <div className="space-y-2">{result.riskFlags.map((f: any, i: number) => <RiskFlag key={i} flag={f} />)}</div>}
            </div>
          )}
        </div>

        {/* Right: Saved Scenarios */}
        <div className="col-span-5 space-y-4">
          <p className="font-pixel text-[8px] text-primary-500">SAVED SCENARIOS</p>
          {(savedScenarios as any[]).length === 0 ? (
            <div className="text-center py-10 bg-retro-card border border-retro-border rounded-xl"><Save className="w-8 h-8 text-primary-800 mx-auto mb-2" /><p className="font-mono text-xs text-primary-700">No saved scenarios yet</p></div>
          ) : (savedScenarios as any[]).map((s: any) => (
            <div key={s.id} className="bg-retro-card border border-retro-border rounded-lg p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <p className="font-mono text-sm text-primary-300 truncate">{s.name}</p>
                  <p className="font-mono text-[9px] text-primary-700 mt-0.5">{s.scenario.replace('_', ' ')} · {new Date(s.createdAt).toLocaleDateString('en-IN')}</p>
                  <div className="flex gap-3 mt-2 font-mono text-[10px]">
                    <span className={`${s.headcountDelta >= 0 ? 'text-green-400' : 'text-red-400'}`}>{s.headcountDelta >= 0 ? '+' : ''}{s.headcountDelta} headcount</span>
                    <span className={`${s.payrollDelta >= 0 ? 'text-blue-400' : 'text-green-400'}`}>{s.payrollDelta >= 0 ? '+' : ''}{formatINR(Math.abs(s.payrollDelta))}/mo</span>
                  </div>
                </div>
                <button onClick={() => delMutation.mutate(s.id)} className="text-primary-800 hover:text-red-400 p-1"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
