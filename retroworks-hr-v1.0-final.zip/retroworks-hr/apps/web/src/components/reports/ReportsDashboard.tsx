'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Users, TrendingDown, TrendingUp, IndianRupee,
  BarChart3, PieChart, Activity, Calendar,
} from 'lucide-react';

const api = (path: string) =>
  fetch(`/api/v1${path}`, {
    headers: {
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
    },
  }).then(r => r.json());

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

function StatCard({ label, value, sub, icon, trend }: {
  label: string; value: string | number; sub?: string;
  icon: React.ReactNode; trend?: { value: string; positive: boolean };
}) {
  return (
    <div className="bg-retro-card border border-retro-border rounded-lg p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="font-pixel text-[7px] text-primary-700 mb-1">{label}</p>
          <p className="font-pixel text-pixel-xl text-primary-crt">{value}</p>
          {sub && <p className="font-mono text-[10px] text-primary-700 mt-0.5">{sub}</p>}
          {trend && (
            <div className={`flex items-center gap-1 mt-1 font-mono text-[9px] ${trend.positive ? 'text-green-400' : 'text-red-400'}`}>
              {trend.positive ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
              {trend.value}
            </div>
          )}
        </div>
        <div className="text-primary-800">{icon}</div>
      </div>
    </div>
  );
}

function HorizontalBar({ label, value, total, color = 'bg-primary-crt' }: {
  label: string; value: number; total: number; color?: string;
}) {
  const pct = total > 0 ? (value / total) * 100 : 0;
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between font-mono text-xs">
        <span className="text-primary-500 truncate max-w-36">{label}</span>
        <span className="text-primary-400 shrink-0 ml-2">{value} <span className="text-primary-700">({pct.toFixed(0)}%)</span></span>
      </div>
      <div className="h-1.5 bg-retro-bg rounded-full overflow-hidden">
        <div className={`h-full ${color} rounded-full transition-all duration-700`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

type Tab = 'headcount' | 'attrition' | 'payroll' | 'leave';

export function ReportsDashboard() {
  const [tab, setTab] = useState<Tab>('headcount');
  const [payrollMonth, setPayrollMonth] = useState(new Date().getMonth() + 1);
  const [payrollYear, setPayrollYear] = useState(new Date().getFullYear());

  const { data: headcount } = useQuery({
    queryKey: ['reports-headcount'],
    queryFn: () => api('/reports/headcount').then(r => r.data),
    enabled: tab === 'headcount',
  });

  const { data: attrition } = useQuery({
    queryKey: ['reports-attrition'],
    queryFn: () => api('/reports/attrition-trend?months=12').then(r => r.data),
    enabled: tab === 'attrition',
  });

  const { data: payroll } = useQuery({
    queryKey: ['reports-payroll', payrollMonth, payrollYear],
    queryFn: () => api(`/reports/payroll?month=${payrollMonth}&year=${payrollYear}`).then(r => r.data),
    enabled: tab === 'payroll',
  });

  const { data: leaveReport } = useQuery({
    queryKey: ['reports-leave'],
    queryFn: () => api(`/reports/leave?year=${new Date().getFullYear()}`).then(r => r.data),
    enabled: tab === 'leave',
  });

  const hc = headcount?.summary;

  return (
    <div className="space-y-5 animate-fade-in">
      <div>
        <h1 className="font-pixel text-[10px] text-primary-400">HR REPORTS</h1>
        <p className="font-mono text-xs text-primary-700 mt-1">Analytics & statutory compliance reports</p>
      </div>

      {/* Summary Stats (always visible) */}
      {hc && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <StatCard label="TOTAL HEADCOUNT" value={hc.totalActive} icon={<Users className="w-5 h-5" />} />
          <StatCard label="NEW JOINERS (30D)" value={hc.newJoiners30Days} icon={<TrendingUp className="w-5 h-5" />} sub="last 30 days" trend={{ value: `+${hc.newJoiners30Days}`, positive: true }} />
          <StatCard label="ATTRITION (30D)" value={hc.attrition30Days} icon={<TrendingDown className="w-5 h-5" />} sub={hc.attritionRate30Days} trend={{ value: hc.attritionRate30Days, positive: false }} />
          <StatCard label="NET CHANGE" value={hc.newJoiners30Days - hc.attrition30Days} icon={<Activity className="w-5 h-5" />} sub="last 30 days" />
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-0 border-b border-retro-border">
        {([
          { key: 'headcount', label: 'Headcount', icon: <Users className="w-3 h-3" /> },
          { key: 'attrition', label: 'Attrition Trend', icon: <TrendingDown className="w-3 h-3" /> },
          { key: 'payroll', label: 'Payroll', icon: <IndianRupee className="w-3 h-3" /> },
          { key: 'leave', label: 'Leave', icon: <Calendar className="w-3 h-3" /> },
        ] as const).map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 px-4 py-2 font-pixel text-[8px] border-b-2 transition-all ${
              tab === t.key ? 'border-primary-crt text-primary-crt' : 'border-transparent text-primary-700 hover:text-primary-500'
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* ── Headcount ── */}
      {tab === 'headcount' && headcount && (
        <div className="grid grid-cols-2 gap-5">
          {/* By Department */}
          <div className="bg-retro-card border border-retro-border rounded-lg p-4">
            <p className="font-pixel text-[8px] text-primary-500 mb-4">BY DEPARTMENT</p>
            <div className="space-y-3">
              {(headcount.byDepartment ?? []).slice(0, 8).map((d: any) => (
                <HorizontalBar key={d.department} label={d.department} value={d.count} total={hc?.totalActive ?? 1} />
              ))}
            </div>
          </div>

          {/* By Location */}
          <div className="bg-retro-card border border-retro-border rounded-lg p-4">
            <p className="font-pixel text-[8px] text-primary-500 mb-4">BY LOCATION</p>
            <div className="space-y-3">
              {(headcount.byLocation ?? []).slice(0, 8).map((l: any) => (
                <HorizontalBar key={l.location} label={l.location} value={l.count} total={hc?.totalActive ?? 1} color="bg-blue-600" />
              ))}
            </div>
          </div>

          {/* By Type */}
          <div className="bg-retro-card border border-retro-border rounded-lg p-4">
            <p className="font-pixel text-[8px] text-primary-500 mb-4">BY EMPLOYMENT TYPE</p>
            <div className="space-y-3">
              {(headcount.byEmploymentType ?? []).map((t: any) => (
                <HorizontalBar key={t.type} label={t.type} value={t.count} total={hc?.totalActive ?? 1} color="bg-purple-600" />
              ))}
            </div>
          </div>

          {/* By Gender */}
          <div className="bg-retro-card border border-retro-border rounded-lg p-4">
            <p className="font-pixel text-[8px] text-primary-500 mb-4">GENDER DIVERSITY</p>
            <div className="space-y-3">
              {(headcount.byGender ?? []).map((g: any) => (
                <HorizontalBar key={g.gender} label={g.gender} value={g.count} total={hc?.totalActive ?? 1} color="bg-amber-600" />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── Attrition Trend ── */}
      {tab === 'attrition' && attrition && (
        <div className="bg-retro-card border border-retro-border rounded-lg p-5">
          <p className="font-pixel text-[8px] text-primary-500 mb-5">MONTHLY JOINERS VS LEAVERS (12 MONTHS)</p>

          {/* Simple ASCII bar chart */}
          <div className="overflow-x-auto">
            <div className="flex items-end gap-2 min-w-max h-40 pb-2">
              {(attrition as any[]).map((month: any) => {
                const maxVal = Math.max(...(attrition as any[]).map((m: any) => Math.max(m.joiners, m.leavers)));
                const joinH = maxVal > 0 ? (month.joiners / maxVal) * 100 : 0;
                const leaveH = maxVal > 0 ? (month.leavers / maxVal) * 100 : 0;
                return (
                  <div key={month.month} className="flex flex-col items-center gap-0.5">
                    <div className="flex items-end gap-0.5 h-28">
                      <div className="w-3 bg-primary-crt/70 rounded-sm transition-all" style={{ height: `${joinH}%` }} title={`Joiners: ${month.joiners}`} />
                      <div className="w-3 bg-red-600/70 rounded-sm transition-all" style={{ height: `${leaveH}%` }} title={`Leavers: ${month.leavers}`} />
                    </div>
                    <p className="font-mono text-[8px] text-primary-700">{month.month}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Legend */}
          <div className="flex gap-5 mt-3">
            <div className="flex items-center gap-1.5 font-mono text-xs text-primary-500">
              <span className="w-3 h-3 bg-primary-crt/70 rounded-sm" /> Joiners
            </div>
            <div className="flex items-center gap-1.5 font-mono text-xs text-primary-500">
              <span className="w-3 h-3 bg-red-600/70 rounded-sm" /> Leavers
            </div>
          </div>

          {/* Table */}
          <table className="w-full mt-4 text-xs">
            <thead>
              <tr className="border-b border-retro-border">
                {['Month', 'Joiners', 'Leavers', 'Net Change', 'Attrition Rate'].map(h => (
                  <th key={h} className="py-2 px-3 font-pixel text-[7px] text-primary-700 text-left">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {(attrition as any[]).map((month: any) => (
                <tr key={month.month} className="border-b border-retro-border/30 hover:bg-surface-raised">
                  <td className="py-2 px-3 font-mono text-primary-400">{month.month}</td>
                  <td className="py-2 px-3 font-mono text-green-400">+{month.joiners}</td>
                  <td className="py-2 px-3 font-mono text-red-400">-{month.leavers}</td>
                  <td className={`py-2 px-3 font-mono ${month.netChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {month.netChange >= 0 ? '+' : ''}{month.netChange}
                  </td>
                  <td className="py-2 px-3 font-mono text-primary-600">{month.attritionRate}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ── Payroll Report ── */}
      {tab === 'payroll' && (
        <div className="space-y-4">
          {/* Period selector */}
          <div className="flex items-center gap-3">
            <select
              value={payrollMonth}
              onChange={e => setPayrollMonth(parseInt(e.target.value))}
              className="px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:border-primary-600 focus:outline-none"
            >
              {Array.from({ length: 12 }, (_, i) => (
                <option key={i + 1} value={i + 1}>
                  {new Date(2024, i).toLocaleDateString('en-IN', { month: 'long' })}
                </option>
              ))}
            </select>
            <select
              value={payrollYear}
              onChange={e => setPayrollYear(parseInt(e.target.value))}
              className="px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:border-primary-600 focus:outline-none"
            >
              {[2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
            </select>
          </div>

          {payroll && (
            <div className="space-y-4">
              {/* Summary cards */}
              <div className="grid grid-cols-4 gap-3">
                {[
                  { label: 'TOTAL GROSS', value: fmt(payroll.totals?.grossPay ?? 0) },
                  { label: 'TOTAL NET PAY', value: fmt(payroll.totals?.netPay ?? 0) },
                  { label: 'TOTAL PF (EE)', value: fmt(payroll.totals?.pfEmployee ?? 0) },
                  { label: 'TOTAL TDS', value: fmt(payroll.totals?.tdsDeducted ?? 0) },
                ].map(c => (
                  <div key={c.label} className="bg-retro-card border border-retro-border rounded p-3">
                    <p className="font-pixel text-[7px] text-primary-700">{c.label}</p>
                    <p className="font-mono text-sm text-primary-300 font-medium mt-1">{c.value}</p>
                  </div>
                ))}
              </div>

              {/* Statutory breakdown */}
              <div className="bg-retro-card border border-retro-border rounded-lg p-4">
                <p className="font-pixel text-[8px] text-primary-500 mb-3">STATUTORY CONTRIBUTIONS</p>
                <div className="grid grid-cols-2 gap-4 font-mono text-xs">
                  <div className="space-y-2">
                    <div className="flex justify-between"><span className="text-primary-600">PF — Employee (12%)</span><span className="text-primary-400">{fmt(payroll.totals?.pfEmployee ?? 0)}</span></div>
                    <div className="flex justify-between"><span className="text-primary-600">PF — Employer (EPF 3.67%)</span><span className="text-primary-400">{fmt(payroll.totals?.pfEmployer ?? 0)}</span></div>
                    <div className="flex justify-between"><span className="text-primary-600">EPS — Employer (8.33%)</span><span className="text-primary-400">{fmt(0)}</span></div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between"><span className="text-primary-600">ESI — Employee (0.75%)</span><span className="text-primary-400">{fmt(payroll.totals?.esiEmployee ?? 0)}</span></div>
                    <div className="flex justify-between"><span className="text-primary-600">ESI — Employer (3.25%)</span><span className="text-primary-400">{fmt(payroll.totals?.esiEmployer ?? 0)}</span></div>
                    <div className="flex justify-between"><span className="text-primary-600">Professional Tax</span><span className="text-primary-400">{fmt(payroll.totals?.professionalTax ?? 0)}</span></div>
                    <div className="flex justify-between"><span className="text-primary-600">TDS (Income Tax)</span><span className="text-primary-400">{fmt(payroll.totals?.tdsDeducted ?? 0)}</span></div>
                  </div>
                </div>
              </div>

              {/* Per-employee table */}
              <div className="bg-retro-card border border-retro-border rounded-lg overflow-hidden">
                <div className="px-4 py-2 bg-retro-bg border-b border-retro-border">
                  <p className="font-pixel text-[7px] text-primary-600">EMPLOYEE PAYROLL DETAILS ({payroll.employeeCount} employees)</p>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-retro-border">
                        {['Code', 'Name', 'Dept', 'Gross', 'PF', 'TDS', 'Net Pay'].map(h => (
                          <th key={h} className="py-2 px-3 font-pixel text-[7px] text-primary-700 text-left">{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {(payroll.payslips ?? []).slice(0, 20).map((p: any) => (
                        <tr key={p.employeeCode} className="border-b border-retro-border/30 hover:bg-surface-raised">
                          <td className="py-2 px-3 font-mono text-primary-600">{p.employeeCode}</td>
                          <td className="py-2 px-3 font-mono text-primary-300">{p.name}</td>
                          <td className="py-2 px-3 font-mono text-primary-600">{p.department ?? '—'}</td>
                          <td className="py-2 px-3 font-mono text-primary-400">{fmt(p.grossPay)}</td>
                          <td className="py-2 px-3 font-mono text-primary-600">{fmt(p.pfEmployee)}</td>
                          <td className="py-2 px-3 font-mono text-primary-600">{fmt(p.tds)}</td>
                          <td className="py-2 px-3 font-mono text-primary-crt font-medium">{fmt(p.netPay)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── Leave Report ── */}
      {tab === 'leave' && leaveReport && (
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-retro-card border border-retro-border rounded-lg p-4">
            <p className="font-pixel text-[8px] text-primary-500 mb-3">BY STATUS</p>
            <div className="space-y-2">
              {(leaveReport.byStatus ?? []).map((s: any) => (
                <div key={s.status} className="flex justify-between font-mono text-xs">
                  <span className="text-primary-500 capitalize">{s.status}</span>
                  <span className="text-primary-400">{s._count.id} requests</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-retro-card border border-retro-border rounded-lg p-4">
            <p className="font-pixel text-[8px] text-primary-500 mb-3">BY LEAVE TYPE</p>
            <div className="space-y-2">
              {(leaveReport.byType ?? []).map((t: any) => (
                <div key={t.leaveTypeId} className="flex justify-between font-mono text-xs">
                  <span className="text-primary-600">{t.leaveTypeId?.slice(0, 8)}...</span>
                  <span className="text-primary-400">{t._sum.days ?? 0} days</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
