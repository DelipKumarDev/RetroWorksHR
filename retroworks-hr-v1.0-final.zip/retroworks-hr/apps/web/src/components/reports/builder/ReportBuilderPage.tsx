'use client';
/**
 * Advanced Report Builder UI
 * ─────────────────────────────────────────────────────────────────────────────
 * Full drag-drop enterprise report builder.
 * Tab workflow: Module → Fields → Filters → Group/Agg → Visualise → Save/Schedule
 *
 * Performance: all API calls via React Query with caching.
 * No inline styles — pure Tailwind utilities.
 */

import { useState, useCallback, useMemo, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Table, BarChart3, LineChart, PieChart, LayoutGrid, Flame,
  Plus, Trash2, ChevronDown, ChevronRight, GripVertical,
  Save, Share2, Calendar, Download, Play, Lock, Eye, EyeOff,
  Copy, History, RotateCcw, Filter, Layers, Calculator,
  AlertTriangle, CheckCircle, Info, X, Settings,
} from 'lucide-react';

// ─── Types ───────────────────────────────────────────────────────────────────

type ChartType = 'table' | 'bar' | 'line' | 'pie' | 'kpi' | 'heatmap';
type FilterOp = 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains' | 'in' | 'isNull' | 'isNotNull';
type AggFn = 'SUM' | 'COUNT' | 'AVG' | 'MIN' | 'MAX' | 'COUNT_DISTINCT';
type Visibility = 'PRIVATE' | 'SHARED' | 'ENTITY';
type Freq = 'DAILY' | 'WEEKLY' | 'MONTHLY';

interface FieldDef {
  key: string; label: string; type: string;
  module: string; _masked?: boolean;
  pii?: boolean; sensitivePayroll?: boolean;
  aggregatable?: boolean; filterable?: boolean;
  groupable?: boolean; sortable?: boolean;
  options?: string[];
}

interface FilterCondition { field: string; operator: FilterOp; value?: string | number | boolean; }
interface FilterGroup { logic: 'AND' | 'OR'; conditions: (FilterCondition | FilterGroup)[]; }
interface AggSpec { field: string; fn: AggFn; alias: string; }
interface CalcField { alias: string; formula: string; type: 'number'; }

// ─── API client ───────────────────────────────────────────────────────────────

const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${tok()}`, 'Content-Type': 'application/json', ...((opts?.headers ?? {}) as any) },
  }).then(r => r.json()).then(r => r.data ?? r);

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

const MODULES = [
  { id: 'employees',   label: 'Employees',    icon: '👤', color: 'text-blue-400' },
  { id: 'payroll',     label: 'Payroll',      icon: '💰', color: 'text-green-400' },
  { id: 'leave',       label: 'Leave',        icon: '🌴', color: 'text-amber-400' },
  { id: 'attendance',  label: 'Attendance',   icon: '📅', color: 'text-purple-400' },
  { id: 'tds',         label: 'TDS',          icon: '📋', color: 'text-red-400' },
  { id: 'performance', label: 'Performance',  icon: '⭐', color: 'text-yellow-400' },
  { id: 'audit',       label: 'Audit Log',    icon: '🔍', color: 'text-cyan-400' },
];

const CHART_OPTIONS: { type: ChartType; label: string; icon: any }[] = [
  { type: 'table',   label: 'Table',    icon: Table },
  { type: 'bar',     label: 'Bar',      icon: BarChart3 },
  { type: 'line',    label: 'Line',     icon: LineChart },
  { type: 'pie',     label: 'Pie',      icon: PieChart },
  { type: 'kpi',     label: 'KPI Card', icon: LayoutGrid },
  { type: 'heatmap', label: 'Heatmap',  icon: Flame },
];

const AGG_FNS: AggFn[] = ['SUM', 'COUNT', 'AVG', 'MIN', 'MAX', 'COUNT_DISTINCT'];
const FILTER_OPS: { op: FilterOp; label: string }[] = [
  { op: 'eq', label: 'equals' }, { op: 'neq', label: 'not equals' },
  { op: 'gt', label: '>' }, { op: 'gte', label: '>=' },
  { op: 'lt', label: '<' }, { op: 'lte', label: '<=' },
  { op: 'contains', label: 'contains' }, { op: 'in', label: 'is in' },
  { op: 'isNull', label: 'is empty' }, { op: 'isNotNull', label: 'is not empty' },
];

// ─── Sub-components ───────────────────────────────────────────────────────────

function FieldChip({ field, onRemove, onDragStart }: {
  field: FieldDef; onRemove: () => void; onDragStart?: () => void;
}) {
  return (
    <div
      draggable
      onDragStart={onDragStart}
      className="flex items-center gap-1.5 px-3 py-1.5 bg-primary-950 border border-primary-800 rounded
                 cursor-grab active:cursor-grabbing group hover:border-primary-600 transition-colors"
    >
      <GripVertical className="w-3 h-3 text-primary-800 group-hover:text-primary-600" />
      <span className="font-mono text-xs text-primary-400">{field.label}</span>
      {field._masked && <Lock className="w-3 h-3 text-amber-600" title="PII masked for your role" />}
      <button onClick={onRemove} className="text-primary-800 hover:text-red-400 ml-1">
        <X className="w-3 h-3" />
      </button>
    </div>
  );
}

function FilterRow({ condition, fields, onChange, onRemove }: {
  condition: FilterCondition;
  fields: FieldDef[];
  onChange: (c: FilterCondition) => void;
  onRemove: () => void;
}) {
  const filterableFields = fields.filter(f => f.filterable !== false);
  const selectedField = filterableFields.find(f => f.key === condition.field);
  const needsValue = !['isNull', 'isNotNull'].includes(condition.operator);

  return (
    <div className="flex items-center gap-2 p-2 bg-retro-bg border border-retro-border rounded">
      <select
        value={condition.field}
        onChange={e => onChange({ ...condition, field: e.target.value })}
        className="bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none"
      >
        <option value="">Select field...</option>
        {filterableFields.map(f => <option key={f.key} value={f.key}>{f.label}</option>)}
      </select>

      <select
        value={condition.operator}
        onChange={e => onChange({ ...condition, operator: e.target.value as FilterOp })}
        className="bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none"
      >
        {FILTER_OPS.map(op => <option key={op.op} value={op.op}>{op.label}</option>)}
      </select>

      {needsValue && (
        selectedField?.options ? (
          <select
            value={String(condition.value ?? '')}
            onChange={e => onChange({ ...condition, value: e.target.value })}
            className="bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none"
          >
            <option value="">Any</option>
            {selectedField.options.map(o => <option key={o} value={o}>{o}</option>)}
          </select>
        ) : (
          <input
            type={selectedField?.type === 'number' ? 'number' : selectedField?.type === 'date' ? 'date' : 'text'}
            value={String(condition.value ?? '')}
            onChange={e => onChange({ ...condition, value: e.target.value })}
            placeholder="value"
            className="flex-1 bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none"
          />
        )
      )}

      <button onClick={onRemove} className="text-primary-800 hover:text-red-400">
        <Trash2 className="w-3 h-3" />
      </button>
    </div>
  );
}

function AggRow({ agg, fields, onChange, onRemove }: {
  agg: AggSpec; fields: FieldDef[];
  onChange: (a: AggSpec) => void; onRemove: () => void;
}) {
  const numericFields = fields.filter(f => f.type === 'number' && f.aggregatable !== false);
  return (
    <div className="flex items-center gap-2 p-2 bg-retro-bg border border-retro-border rounded">
      <select value={agg.fn} onChange={e => onChange({ ...agg, fn: e.target.value as AggFn })}
        className="bg-retro-bg border border-retro-border rounded px-2 py-1 font-pixel text-[7px] text-amber-400 focus:border-primary-crt outline-none">
        {AGG_FNS.map(fn => <option key={fn} value={fn}>{fn}</option>)}
      </select>
      <select value={agg.field} onChange={e => onChange({ ...agg, field: e.target.value })}
        className="bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none">
        <option value="">Select field...</option>
        {numericFields.map(f => <option key={f.key} value={f.key}>{f.label}</option>)}
        <option value="_count">Row Count</option>
      </select>
      <span className="font-mono text-xs text-primary-700">as</span>
      <input value={agg.alias} onChange={e => onChange({ ...agg, alias: e.target.value })}
        placeholder="column_name" className="w-32 bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none" />
      <button onClick={onRemove} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>
    </div>
  );
}

// ─── Visualisation renderers ──────────────────────────────────────────────────

function TableViz({ rows, fields }: { rows: any[]; fields: string[] }) {
  if (!rows.length) return <div className="font-mono text-xs text-primary-700 py-8 text-center">No data</div>;
  const cols = fields.length ? fields : Object.keys(rows[0]!).filter(k => k !== 'id').slice(0, 12);

  return (
    <div className="overflow-x-auto">
      <table className="w-full font-mono text-[10px]">
        <thead>
          <tr className="border-b border-retro-border">
            {cols.map(c => (
              <th key={c} className="text-left py-2 px-3 text-primary-600 font-pixel text-[7px] whitespace-nowrap">{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.slice(0, 200).map((row, i) => (
            <tr key={i} className={`border-b border-retro-border/20 hover:bg-primary-950/20 ${i % 2 === 0 ? '' : 'bg-retro-bg/30'}`}>
              {cols.map(c => (
                <td key={c} className="py-2 px-3 text-primary-400 whitespace-nowrap max-w-[200px] truncate">
                  {row[c] !== null && row[c] !== undefined ? String(row[c]) : <span className="text-primary-800">—</span>}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {rows.length > 200 && (
        <div className="font-mono text-[10px] text-primary-700 py-2 text-center">
          Showing 200 of {rows.length} rows. Export for full dataset.
        </div>
      )}
    </div>
  );
}

function BarViz({ rows, fields }: { rows: any[]; fields: string[] }) {
  if (!rows.length) return null;
  const labelKey = fields[0] ?? Object.keys(rows[0]!)[0]!;
  const valueKey = fields[1] ?? Object.keys(rows[0]!)[1]!;
  const maxVal = Math.max(...rows.map((r: any) => Number(r[valueKey] ?? 0)));

  return (
    <div className="space-y-1.5 max-h-80 overflow-y-auto pr-2">
      {rows.slice(0, 30).map((row, i) => {
        const val = Number(row[valueKey] ?? 0);
        return (
          <div key={i} className="flex items-center gap-3">
            <div className="w-32 font-mono text-[9px] text-primary-600 truncate text-right">{String(row[labelKey])}</div>
            <div className="flex-1 bg-retro-bg border border-retro-border/30 h-5 overflow-hidden rounded">
              <div className="h-full bg-primary-800 transition-all" style={{ width: `${maxVal > 0 ? (val / maxVal) * 100 : 0}%` }} />
            </div>
            <div className="w-24 font-pixel text-[7px] text-primary-crt text-right">
              {typeof val === 'number' && val > 1000 ? fmt(val) : val}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function KpiViz({ rows, fields }: { rows: any[]; fields: string[] }) {
  if (!rows.length) return null;
  const numericFields = fields.filter(k => typeof rows[0]?.[k] === 'number').slice(0, 4);

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {numericFields.map(k => {
        const total = rows.reduce((s, r) => s + Number(r[k] ?? 0), 0);
        return (
          <div key={k} className="bg-retro-card border border-retro-border rounded p-4 text-center">
            <div className="font-pixel text-[6px] text-primary-700 mb-1 uppercase">{k}</div>
            <div className="font-pixel text-[11px] text-primary-crt">{total > 1000 ? fmt(total) : total.toFixed(2)}</div>
          </div>
        );
      })}
    </div>
  );
}

function HeatmapViz({ rows, fields }: { rows: any[]; fields: string[] }) {
  if (!rows.length) return null;
  // Simple intensity heatmap: first field = label, second = value
  const labelKey = fields[0] ?? 'date';
  const valueKey = fields[1] ?? 'totalDays';
  const vals = rows.map(r => Number(r[valueKey] ?? 0));
  const max = Math.max(...vals, 1);

  const getColor = (val: number) => {
    const pct = val / max;
    if (pct === 0) return 'bg-retro-bg';
    if (pct < 0.25) return 'bg-green-900/40';
    if (pct < 0.5)  return 'bg-amber-800/40';
    if (pct < 0.75) return 'bg-orange-700/50';
    return 'bg-red-700/60';
  };

  return (
    <div className="flex flex-wrap gap-1">
      {rows.slice(0, 90).map((row, i) => (
        <div
          key={i}
          title={`${row[labelKey]}: ${row[valueKey]}`}
          className={`w-8 h-8 rounded cursor-default border border-retro-border/20 ${getColor(Number(row[valueKey] ?? 0))}`}
        />
      ))}
    </div>
  );
}

function DataViz({ chartType, rows, fields }: { chartType: ChartType; rows: any[]; fields: string[] }) {
  switch (chartType) {
    case 'bar':     return <BarViz rows={rows} fields={fields} />;
    case 'kpi':     return <KpiViz rows={rows} fields={fields} />;
    case 'heatmap': return <HeatmapViz rows={rows} fields={fields} />;
    case 'line':    return <BarViz rows={rows} fields={fields} />; // simplified; production would use recharts
    case 'pie':     return <BarViz rows={rows} fields={fields} />; // simplified
    default:        return <TableViz rows={rows} fields={fields} />;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN REPORT BUILDER PAGE
// ─────────────────────────────────────────────────────────────────────────────

const TABS = ['MODULE', 'FIELDS', 'FILTERS', 'GROUP & AGG', 'VISUALISE', 'SAVE'] as const;
type Tab = typeof TABS[number];

export function ReportBuilderPage() {
  const qc = useQueryClient();

  // ── Builder state ──────────────────────────────────────────────────────────
  const [activeTab, setActiveTab] = useState<Tab>('MODULE');
  const [selectedModule, setSelectedModule]     = useState('');
  const [selectedJoin, setSelectedJoin]         = useState('');
  const [selectedFields, setSelectedFields]     = useState<FieldDef[]>([]);
  const [filterGroup, setFilterGroup]           = useState<FilterGroup>({ logic: 'AND', conditions: [] });
  const [groupBy, setGroupBy]                   = useState<string[]>([]);
  const [aggregations, setAggregations]         = useState<AggSpec[]>([]);
  const [calculatedFields, setCalculatedFields] = useState<CalcField[]>([]);
  const [sortBy, setSortBy]                     = useState('');
  const [sortOrder, setSortOrder]               = useState<'asc' | 'desc'>('desc');
  const [chartType, setChartType]               = useState<ChartType>('table');
  const [dragField, setDragField]               = useState<FieldDef | null>(null);
  const dropZoneRef = useRef<HTMLDivElement>(null);

  // ── Save/schedule state ────────────────────────────────────────────────────
  const [reportName, setReportName]         = useState('');
  const [reportDesc, setReportDesc]         = useState('');
  const [visibility, setVisibility]         = useState<Visibility>('PRIVATE');
  const [schedEnabled, setSchedEnabled]     = useState(false);
  const [schedFreq, setSchedFreq]           = useState<Freq>('WEEKLY');
  const [schedEmails, setSchedEmails]       = useState('');
  const [schedFormat, setSchedFormat]       = useState<'csv' | 'json'>('csv');

  // ── Results state ──────────────────────────────────────────────────────────
  const [results, setResults]     = useState<any[] | null>(null);
  const [resultMeta, setResultMeta] = useState<any>(null);
  const [cursor, setCursor]       = useState<string | undefined>();

  // ── Data loading ───────────────────────────────────────────────────────────
  const { data: catalogue } = useQuery({
    queryKey: ['report-catalogue'],
    queryFn: () => api('/reports/advanced/catalogue'),
    staleTime: 5 * 60 * 1000,
  });

  const { data: savedReports = [] } = useQuery({
    queryKey: ['saved-reports'],
    queryFn: () => api('/reports/advanced/reports'),
  });

  const currentModuleFields: FieldDef[] = useMemo(() =>
    (catalogue?.modules?.[selectedModule] ?? []) as FieldDef[],
    [catalogue, selectedModule],
  );

  const availableJoins = useMemo(() =>
    (catalogue?.joins ?? []).filter((j: any) =>
      j.primaryModule === selectedModule || j.joinedModule === selectedModule
    ),
    [catalogue, selectedModule],
  );

  // ── Run report ─────────────────────────────────────────────────────────────
  const run = useMutation({
    mutationFn: () => api('/reports/advanced/run', {
      method: 'POST',
      body: JSON.stringify({
        module: selectedModule,
        fields: selectedFields.map(f => f.key),
        joinId: selectedJoin || undefined,
        filterGroup: filterGroup.conditions.length ? filterGroup : undefined,
        groupBy: groupBy.length ? groupBy : undefined,
        aggregations: aggregations.length ? aggregations : undefined,
        calculatedFields: calculatedFields.length ? calculatedFields : undefined,
        sortBy: sortBy || undefined,
        sortOrder,
        limit: 500,
        chartType,
      }),
    }),
    onSuccess: (data) => {
      setResults(data.rows ?? []);
      setResultMeta({ total: data.total, executionMs: data.executionMs, maskedFields: data.maskedFields ?? [], warnings: data.warnings ?? [] });
    },
  });

  // ── Save report ────────────────────────────────────────────────────────────
  const save = useMutation({
    mutationFn: () => api('/reports/advanced/reports', {
      method: 'POST',
      body: JSON.stringify({
        name: reportName, description: reportDesc,
        module: selectedModule,
        fields: selectedFields.map(f => f.key),
        joinId: selectedJoin || undefined,
        filterGroup: filterGroup.conditions.length ? filterGroup : undefined,
        groupBy: groupBy.length ? groupBy : undefined,
        aggregations: aggregations.length ? aggregations : undefined,
        calculatedFields: calculatedFields.length ? calculatedFields : undefined,
        sortBy: sortBy || undefined, sortOrder, chartType, visibility,
        scheduledDelivery: schedEnabled ? {
          enabled: true, frequency: schedFreq,
          emails: schedEmails.split(',').map(e => e.trim()).filter(Boolean),
          format: schedFormat,
        } : { enabled: false },
      }),
    }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['saved-reports'] }),
  });

  // ── Drag-drop handlers ─────────────────────────────────────────────────────
  const handleDragStart = useCallback((field: FieldDef) => setDragField(field), []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    if (!dragField) return;
    if (!selectedFields.find(f => f.key === dragField.key)) {
      setSelectedFields(prev => [...prev, dragField]);
    }
    setDragField(null);
  }, [dragField, selectedFields]);

  const removeField = useCallback((key: string) => {
    setSelectedFields(prev => prev.filter(f => f.key !== key));
    setGroupBy(prev => prev.filter(g => g !== key));
  }, []);

  const addFilter = () =>
    setFilterGroup(prev => ({
      ...prev,
      conditions: [...prev.conditions, { field: currentModuleFields[0]?.key ?? '', operator: 'eq', value: '' }],
    }));

  const updateFilter = (i: number, c: FilterCondition) =>
    setFilterGroup(prev => ({
      ...prev,
      conditions: prev.conditions.map((x, idx) => idx === i ? c : x),
    }));

  const removeFilter = (i: number) =>
    setFilterGroup(prev => ({ ...prev, conditions: prev.conditions.filter((_, idx) => idx !== i) }));

  const canRun = selectedModule && selectedFields.length > 0;

  // ── Left panel: saved reports ──────────────────────────────────────────────
  function loadSavedReport(report: any) {
    setSelectedModule(report.module);
    setSelectedFields(
      (report.fields as string[]).map(key => {
        const cat = catalogue?.modules?.[report.module] as FieldDef[] ?? [];
        return cat.find(f => f.key === key) ?? { key, label: key, type: 'string', module: report.module };
      })
    );
    setFilterGroup(report.filterGroup ?? { logic: 'AND', conditions: [] });
    setGroupBy(report.groupBy ?? []);
    setAggregations(report.aggregations ?? []);
    setChartType(report.chartType ?? 'table');
    setReportName(report.name);
    setReportDesc(report.description ?? '');
    setVisibility(report.visibility ?? 'PRIVATE');
    if (report.scheduledDelivery?.enabled) {
      setSchedEnabled(true);
      setSchedFreq(report.scheduledDelivery.frequency);
      setSchedEmails((report.scheduledDelivery.emails ?? []).join(', '));
      setSchedFormat(report.scheduledDelivery.format ?? 'csv');
    }
    setActiveTab('FIELDS');
  }

  return (
    <div className="flex gap-4 h-full animate-fade-in" style={{ minHeight: '80vh' }}>

      {/* ── LEFT SIDEBAR: Saved reports ──────────────────────────────────── */}
      <div className="w-60 flex-shrink-0 space-y-2">
        <div className="font-pixel text-[7px] text-primary-600 mb-2">SAVED REPORTS</div>
        <button
          onClick={() => { setSelectedModule(''); setSelectedFields([]); setResults(null); setActiveTab('MODULE'); }}
          className="w-full text-left px-3 py-2 border border-dashed border-primary-800 rounded font-pixel text-[7px] text-primary-700 hover:border-primary-600 hover:text-primary-500 flex items-center gap-2"
        >
          <Plus className="w-3 h-3" /> NEW REPORT
        </button>

        {(savedReports as any[]).map((r: any) => (
          <button
            key={r.id}
            onClick={() => loadSavedReport(r)}
            className="w-full text-left px-3 py-2.5 rounded border border-retro-border bg-retro-card hover:border-primary-700 space-y-0.5 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs text-primary-400 truncate">{r.name}</span>
              {r.visibility === 'SHARED' && <Share2 className="w-2.5 h-2.5 text-primary-700 flex-shrink-0" />}
              {r.scheduledDelivery?.enabled && <Calendar className="w-2.5 h-2.5 text-amber-700 flex-shrink-0" />}
            </div>
            <div className="font-pixel text-[6px] text-primary-800">{r.module?.toUpperCase()}</div>
          </button>
        ))}
      </div>

      {/* ── MAIN BUILDER AREA ─────────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col gap-3 min-w-0">

        {/* Tab bar */}
        <div className="flex gap-0.5 border-b border-retro-border">
          {TABS.map((tab, i) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 font-pixel text-[7px] border-b-2 transition-colors whitespace-nowrap ${
                activeTab === tab
                  ? 'border-primary-crt text-primary-crt'
                  : 'border-transparent text-primary-700 hover:text-primary-500'
              }`}
            >
              {i + 1}. {tab}
            </button>
          ))}
          <div className="flex-1" />
          {/* Quick run */}
          <button
            onClick={() => run.mutate()}
            disabled={!canRun || run.isPending}
            className="flex items-center gap-1.5 px-4 py-2 bg-primary-900 border border-primary-700 font-pixel text-[7px] text-primary-crt hover:bg-primary-800 disabled:opacity-40 rounded mb-1"
          >
            <Play className="w-3 h-3" />
            {run.isPending ? 'RUNNING...' : 'RUN'}
          </button>
        </div>

        {/* ── TAB: MODULE ─────────────────────────────────────────────────── */}
        {activeTab === 'MODULE' && (
          <div className="space-y-3">
            <div className="font-pixel text-[8px] text-primary-600">SELECT DATA SOURCE</div>
            <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
              {MODULES.map(m => (
                <button
                  key={m.id}
                  onClick={() => { setSelectedModule(m.id); setSelectedFields([]); setActiveTab('FIELDS'); }}
                  className={`flex flex-col items-center justify-center gap-2 p-4 rounded border transition-all ${
                    selectedModule === m.id
                      ? 'bg-primary-950 border-primary-700 shadow-glow'
                      : 'bg-retro-card border-retro-border hover:border-primary-800'
                  }`}
                >
                  <span className="text-2xl">{m.icon}</span>
                  <span className={`font-pixel text-[8px] ${selectedModule === m.id ? m.color : 'text-primary-600'}`}>
                    {m.label}
                  </span>
                </button>
              ))}
            </div>

            {/* Joins */}
            {availableJoins.length > 0 && (
              <div className="space-y-2">
                <div className="font-pixel text-[7px] text-primary-700 mt-2">CROSS-MODULE JOINS (pre-approved only)</div>
                {availableJoins.map((j: any) => (
                  <button
                    key={j.id}
                    onClick={() => setSelectedJoin(selectedJoin === j.id ? '' : j.id)}
                    className={`w-full text-left px-4 py-3 rounded border transition-all ${
                      selectedJoin === j.id
                        ? 'bg-cyan-950/30 border-cyan-800'
                        : 'bg-retro-card border-retro-border hover:border-cyan-800/40'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <Layers className="w-3 h-3 text-cyan-600" />
                      <span className="font-mono text-xs text-primary-400">{j.label}</span>
                      {selectedJoin === j.id && <CheckCircle className="w-3 h-3 text-cyan-400 ml-auto" />}
                    </div>
                    <div className="font-mono text-[10px] text-primary-700 mt-0.5 ml-5">{j.description}</div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ── TAB: FIELDS ─────────────────────────────────────────────────── */}
        {activeTab === 'FIELDS' && (
          <div className="flex gap-4 h-full">
            {/* Available fields */}
            <div className="w-64 flex-shrink-0">
              <div className="font-pixel text-[7px] text-primary-600 mb-2">AVAILABLE FIELDS</div>
              <div className="space-y-1 max-h-96 overflow-y-auto pr-1">
                {currentModuleFields.map(f => (
                  <div
                    key={f.key}
                    draggable
                    onDragStart={() => handleDragStart(f)}
                    onClick={() => !selectedFields.find(s => s.key === f.key) && setSelectedFields(prev => [...prev, f])}
                    className="flex items-center gap-2 px-3 py-2 rounded border border-retro-border/30 hover:border-primary-700 hover:bg-primary-950/20 cursor-pointer transition-colors group"
                  >
                    <GripVertical className="w-3 h-3 text-primary-800 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="font-mono text-xs text-primary-400 truncate">{f.label}</div>
                      <div className="font-pixel text-[6px] text-primary-800 uppercase">{f.type}</div>
                    </div>
                    {f._masked && <Lock className="w-3 h-3 text-amber-600 flex-shrink-0" />}
                    {selectedFields.find(s => s.key === f.key) && (
                      <CheckCircle className="w-3 h-3 text-green-600 flex-shrink-0" />
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Drop zone */}
            <div className="flex-1">
              <div className="font-pixel text-[7px] text-primary-600 mb-2">
                SELECTED FIELDS ({selectedFields.length})
              </div>
              <div
                ref={dropZoneRef}
                onDragOver={e => e.preventDefault()}
                onDrop={handleDrop}
                className={`min-h-40 p-3 rounded border-2 border-dashed transition-colors ${
                  dragField
                    ? 'border-primary-600 bg-primary-950/20'
                    : 'border-retro-border/40 bg-retro-bg/30'
                }`}
              >
                {selectedFields.length === 0 ? (
                  <div className="flex items-center justify-center h-32 font-mono text-xs text-primary-800">
                    Drag fields here or click to add
                  </div>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {selectedFields.map(f => (
                      <FieldChip
                        key={f.key}
                        field={f}
                        onRemove={() => removeField(f.key)}
                        onDragStart={() => handleDragStart(f)}
                      />
                    ))}
                  </div>
                )}
              </div>

              {/* Sort */}
              {selectedFields.length > 0 && (
                <div className="flex items-center gap-3 mt-3">
                  <span className="font-pixel text-[7px] text-primary-700">SORT BY</span>
                  <select value={sortBy} onChange={e => setSortBy(e.target.value)}
                    className="bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none">
                    <option value="">None</option>
                    {selectedFields.filter(f => f.sortable !== false).map(f => (
                      <option key={f.key} value={f.key}>{f.label}</option>
                    ))}
                  </select>
                  <select value={sortOrder} onChange={e => setSortOrder(e.target.value as any)}
                    className="bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none">
                    <option value="asc">↑ Asc</option>
                    <option value="desc">↓ Desc</option>
                  </select>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── TAB: FILTERS ────────────────────────────────────────────────── */}
        {activeTab === 'FILTERS' && (
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="font-pixel text-[8px] text-primary-600">FILTER CONDITIONS</div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-primary-700">Match</span>
                <select
                  value={filterGroup.logic}
                  onChange={e => setFilterGroup(prev => ({ ...prev, logic: e.target.value as any }))}
                  className="bg-retro-bg border border-retro-border rounded px-2 py-1 font-pixel text-[7px] text-primary-crt focus:border-primary-crt outline-none"
                >
                  <option value="AND">ALL (AND)</option>
                  <option value="OR">ANY (OR)</option>
                </select>
                <span className="font-mono text-xs text-primary-700">conditions</span>
              </div>
              <button
                onClick={addFilter}
                className="flex items-center gap-1 px-3 py-1 border border-retro-border font-pixel text-[7px] text-primary-600 hover:text-primary-400 rounded"
              >
                <Plus className="w-3 h-3" /> ADD CONDITION
              </button>
            </div>

            <div className="space-y-2">
              {(filterGroup.conditions as FilterCondition[]).map((cond, i) => (
                <FilterRow
                  key={i}
                  condition={cond}
                  fields={currentModuleFields}
                  onChange={c => updateFilter(i, c)}
                  onRemove={() => removeFilter(i)}
                />
              ))}
              {filterGroup.conditions.length === 0 && (
                <div className="font-mono text-xs text-primary-800 py-4 text-center border border-dashed border-retro-border/30 rounded">
                  No filters — all records will be returned.
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── TAB: GROUP & AGG ────────────────────────────────────────────── */}
        {activeTab === 'GROUP & AGG' && (
          <div className="space-y-4">
            <div>
              <div className="font-pixel text-[7px] text-primary-600 mb-2">GROUP BY</div>
              <div className="flex flex-wrap gap-2">
                {selectedFields.filter(f => f.groupable !== false).map(f => (
                  <button
                    key={f.key}
                    onClick={() => setGroupBy(prev =>
                      prev.includes(f.key) ? prev.filter(g => g !== f.key) : [...prev, f.key]
                    )}
                    className={`px-3 py-1.5 rounded border font-mono text-xs transition-colors ${
                      groupBy.includes(f.key)
                        ? 'bg-primary-950 border-primary-700 text-primary-crt'
                        : 'border-retro-border text-primary-700 hover:border-primary-700'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="font-pixel text-[7px] text-primary-600">AGGREGATIONS</div>
                <button
                  onClick={() => setAggregations(prev => [...prev, { field: '', fn: 'SUM', alias: 'total' }])}
                  className="flex items-center gap-1 px-2 py-1 border border-retro-border font-pixel text-[6px] text-primary-700 hover:text-primary-500 rounded"
                >
                  <Plus className="w-2.5 h-2.5" /> ADD
                </button>
              </div>
              <div className="space-y-2">
                {aggregations.map((agg, i) => (
                  <AggRow
                    key={i}
                    agg={agg}
                    fields={currentModuleFields}
                    onChange={a => setAggregations(prev => prev.map((x, idx) => idx === i ? a : x))}
                    onRemove={() => setAggregations(prev => prev.filter((_, idx) => idx !== i))}
                  />
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="font-pixel text-[7px] text-primary-600 flex items-center gap-1">
                  <Calculator className="w-3 h-3" /> CALCULATED FIELDS
                </div>
                <button
                  onClick={() => setCalculatedFields(prev => [...prev, { alias: 'calc_field', formula: '', type: 'number' }])}
                  className="flex items-center gap-1 px-2 py-1 border border-retro-border font-pixel text-[6px] text-primary-700 hover:text-primary-500 rounded"
                >
                  <Plus className="w-2.5 h-2.5" /> ADD
                </button>
              </div>
              <div className="space-y-2">
                {calculatedFields.map((cf, i) => (
                  <div key={i} className="flex items-center gap-2 p-2 bg-retro-bg border border-retro-border rounded">
                    <input
                      value={cf.alias}
                      onChange={e => setCalculatedFields(prev => prev.map((x, idx) => idx === i ? { ...x, alias: e.target.value } : x))}
                      placeholder="alias"
                      className="w-28 bg-retro-bg border border-retro-border/40 rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none"
                    />
                    <span className="font-mono text-xs text-primary-700">=</span>
                    <input
                      value={cf.formula}
                      onChange={e => setCalculatedFields(prev => prev.map((x, idx) => idx === i ? { ...x, formula: e.target.value } : x))}
                      placeholder="e.g. grossPay - netPay"
                      className="flex-1 bg-retro-bg border border-retro-border/40 rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none"
                    />
                    <button onClick={() => setCalculatedFields(prev => prev.filter((_, idx) => idx !== i))} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── TAB: VISUALISE ──────────────────────────────────────────────── */}
        {activeTab === 'VISUALISE' && (
          <div className="space-y-4">
            {/* Chart type selector */}
            <div className="flex gap-2">
              {CHART_OPTIONS.map(({ type, label, icon: Icon }) => (
                <button
                  key={type}
                  onClick={() => setChartType(type)}
                  className={`flex flex-col items-center gap-1.5 px-4 py-3 rounded border transition-all ${
                    chartType === type
                      ? 'bg-primary-950 border-primary-700 text-primary-crt'
                      : 'bg-retro-card border-retro-border text-primary-700 hover:border-primary-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="font-pixel text-[6px]">{label}</span>
                </button>
              ))}
            </div>

            {/* Results */}
            {results === null && (
              <div className="flex flex-col items-center justify-center py-16 space-y-3 border border-dashed border-retro-border/30 rounded">
                <Play className="w-8 h-8 text-primary-800" />
                <div className="font-pixel text-[7px] text-primary-700">CLICK RUN TO EXECUTE REPORT</div>
              </div>
            )}

            {run.isError && (
              <div className="flex items-center gap-2 px-4 py-3 bg-red-950/20 border border-red-800 rounded">
                <AlertTriangle className="w-4 h-4 text-red-400" />
                <span className="font-mono text-xs text-red-400">Query failed — check your fields and filters</span>
              </div>
            )}

            {results !== null && (
              <div className="space-y-3">
                {/* Meta bar */}
                <div className="flex items-center gap-4 font-mono text-[10px] text-primary-700">
                  <span>{resultMeta?.total ?? 0} rows</span>
                  <span>{resultMeta?.executionMs ?? 0}ms</span>
                  {resultMeta?.maskedFields?.length > 0 && (
                    <span className="flex items-center gap-1 text-amber-600">
                      <Lock className="w-3 h-3" /> {resultMeta.maskedFields.length} fields masked
                    </span>
                  )}
                  {resultMeta?.warnings?.length > 0 && (
                    <span className="flex items-center gap-1 text-amber-500">
                      <AlertTriangle className="w-3 h-3" /> {resultMeta.warnings[0]}
                    </span>
                  )}
                </div>

                {/* Visualisation */}
                <div className="border border-retro-border rounded p-4 bg-retro-card">
                  <DataViz
                    chartType={chartType}
                    rows={results}
                    fields={selectedFields.map(f => f.key)}
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── TAB: SAVE ───────────────────────────────────────────────────── */}
        {activeTab === 'SAVE' && (
          <div className="space-y-5 max-w-xl">
            <div className="space-y-3">
              <div className="font-pixel text-[8px] text-primary-600">REPORT DETAILS</div>
              <div>
                <label className="font-pixel text-[7px] text-primary-700 block mb-1">REPORT NAME *</label>
                <input
                  value={reportName}
                  onChange={e => setReportName(e.target.value)}
                  placeholder="Headcount vs Payroll Cost"
                  className="w-full bg-retro-bg border border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none"
                />
              </div>
              <div>
                <label className="font-pixel text-[7px] text-primary-700 block mb-1">DESCRIPTION</label>
                <textarea
                  value={reportDesc}
                  onChange={e => setReportDesc(e.target.value)}
                  placeholder="Optional description..."
                  rows={2}
                  className="w-full bg-retro-bg border border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none resize-none"
                />
              </div>
              <div>
                <label className="font-pixel text-[7px] text-primary-700 block mb-1">VISIBILITY</label>
                <div className="flex gap-2">
                  {([['PRIVATE', '🔒 Private', 'Only you'], ['SHARED', '👥 Shared', 'All users in tenant'], ['ENTITY', '🏢 Entity', 'Entity-scoped']] as const).map(([v, label, desc]) => (
                    <button
                      key={v}
                      onClick={() => setVisibility(v)}
                      className={`flex-1 px-3 py-2 rounded border text-left transition-all ${visibility === v ? 'bg-primary-950 border-primary-700' : 'border-retro-border hover:border-primary-800'}`}
                    >
                      <div className="font-mono text-xs text-primary-400">{label}</div>
                      <div className="font-pixel text-[6px] text-primary-800">{desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Schedule */}
            <div className="space-y-3 pt-3 border-t border-retro-border">
              <div className="flex items-center gap-3">
                <div className="font-pixel text-[8px] text-primary-600">SCHEDULED DELIVERY</div>
                <button
                  onClick={() => setSchedEnabled(prev => !prev)}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded border font-pixel text-[7px] transition-colors ${schedEnabled ? 'border-amber-700 bg-amber-950/20 text-amber-400' : 'border-retro-border text-primary-700'}`}
                >
                  <Calendar className="w-3 h-3" />
                  {schedEnabled ? 'ENABLED' : 'DISABLED'}
                </button>
              </div>

              {schedEnabled && (
                <div className="space-y-3 pl-3 border-l-2 border-amber-800/30">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="font-pixel text-[7px] text-primary-700 block mb-1">FREQUENCY</label>
                      <select value={schedFreq} onChange={e => setSchedFreq(e.target.value as Freq)}
                        className="w-full bg-retro-bg border border-retro-border rounded px-2 py-1.5 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none">
                        <option value="DAILY">Daily (6am IST)</option>
                        <option value="WEEKLY">Weekly (Mon 7am IST)</option>
                        <option value="MONTHLY">Monthly (1st 7am IST)</option>
                      </select>
                    </div>
                    <div>
                      <label className="font-pixel text-[7px] text-primary-700 block mb-1">FORMAT</label>
                      <select value={schedFormat} onChange={e => setSchedFormat(e.target.value as any)}
                        className="w-full bg-retro-bg border border-retro-border rounded px-2 py-1.5 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none">
                        <option value="csv">CSV</option>
                        <option value="json">JSON</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="font-pixel text-[7px] text-primary-700 block mb-1">RECIPIENT EMAILS (comma-separated)</label>
                    <input
                      value={schedEmails}
                      onChange={e => setSchedEmails(e.target.value)}
                      placeholder="cfo@company.com, finance@company.com"
                      className="w-full bg-retro-bg border border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none"
                    />
                  </div>
                  <div className="flex items-center gap-2 px-3 py-2 bg-amber-950/10 border border-amber-800/30 rounded">
                    <Info className="w-3 h-3 text-amber-600 flex-shrink-0" />
                    <span className="font-mono text-[10px] text-amber-700">PII masking is always enforced on scheduled delivery.</span>
                  </div>
                </div>
              )}
            </div>

            {/* Save button */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => save.mutate()}
                disabled={!reportName || !selectedModule || !selectedFields.length || save.isPending}
                className="flex items-center gap-2 px-6 py-2.5 bg-primary-900 border border-primary-700 font-pixel text-[8px] text-primary-crt rounded hover:bg-primary-800 disabled:opacity-40"
              >
                <Save className="w-4 h-4" />
                {save.isPending ? 'SAVING...' : 'SAVE REPORT'}
              </button>

              {save.isSuccess && (
                <div className="flex items-center gap-2 font-pixel text-[7px] text-green-400">
                  <CheckCircle className="w-4 h-4" /> Report saved!
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
