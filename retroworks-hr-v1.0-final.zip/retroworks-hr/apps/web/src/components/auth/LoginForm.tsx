'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import Link from 'next/link';

const loginSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: z.string().min(1, 'Password required'),
});

const magicLinkSchema = z.object({
  email: z.string().email('Invalid email address'),
});

type LoginInput = z.infer<typeof loginSchema>;
type MagicLinkInput = z.infer<typeof magicLinkSchema>;

type Mode = 'password' | 'magic-link' | 'magic-sent';

export function LoginForm() {
  const [mode, setMode] = useState<Mode>('password');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const passwordForm = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
  });

  const magicForm = useForm<MagicLinkInput>({
    resolver: zodResolver(magicLinkSchema),
  });

  async function handlePasswordLogin(data: LoginInput) {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/v1/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const body = (await response.json()) as { error?: { message?: string } };
        throw new Error(body.error?.message ?? 'Authentication failed');
      }

      // Redirect handled by middleware / response
      window.location.href = '/dashboard';
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  }

  async function handleMagicLink(data: MagicLinkInput) {
    setIsLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/v1/auth/magic-link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const body = (await response.json()) as { error?: { message?: string } };
        throw new Error(body.error?.message ?? 'Failed to send magic link');
      }

      setMode('magic-sent');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to send magic link');
    } finally {
      setIsLoading(false);
    }
  }

  if (mode === 'magic-sent') {
    return (
      <div className="text-center space-y-4">
        <div className="font-pixel text-pixel-sm text-primary-crt animate-glow-pulse">
          ✓ LINK SENT
        </div>
        <p className="font-mono text-xs text-primary-500">
          Check your email for the magic link.
          <br />
          It expires in 15 minutes.
        </p>
        <button
          onClick={() => { setMode('password'); setError(null); }}
          className="font-mono text-xs text-primary-700 hover:text-primary-500 underline"
        >
          ← Back to login
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Mode toggle */}
      <div className="flex gap-1 p-0.5 bg-retro-bg border border-retro-border rounded">
        <button
          type="button"
          onClick={() => { setMode('password'); setError(null); }}
          className={`flex-1 py-1.5 px-2 font-pixel text-[8px] transition-all rounded-sm ${
            mode === 'password'
              ? 'bg-primary-900 text-primary-crt shadow-glow'
              : 'text-primary-700 hover:text-primary-500'
          }`}
        >
          PASSWORD
        </button>
        <button
          type="button"
          onClick={() => { setMode('magic-link'); setError(null); }}
          className={`flex-1 py-1.5 px-2 font-pixel text-[8px] transition-all rounded-sm ${
            mode === 'magic-link'
              ? 'bg-primary-900 text-primary-crt shadow-glow'
              : 'text-primary-700 hover:text-primary-500'
          }`}
        >
          MAGIC LINK
        </button>
      </div>

      {/* Error */}
      {error && (
        <div
          role="alert"
          className="flex items-center gap-2 px-3 py-2 bg-red-950 border border-red-800 rounded font-mono text-xs text-red-400"
        >
          <span aria-hidden>✗</span> {error}
        </div>
      )}

      {/* Password form */}
      {mode === 'password' && (
        <form onSubmit={passwordForm.handleSubmit(handlePasswordLogin)} noValidate className="space-y-4">
          <div className="space-y-1">
            <label htmlFor="email" className="block font-pixel text-[8px] text-primary-600 uppercase tracking-widest">
              Email
            </label>
            <input
              id="email"
              type="email"
              autoComplete="email"
              placeholder="user@company.com"
              className="w-full bg-retro-bg border-2 border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:shadow-glow focus:outline-none caret-primary-crt transition-all"
              {...passwordForm.register('email')}
              aria-invalid={Boolean(passwordForm.formState.errors.email)}
            />
            {passwordForm.formState.errors.email && (
              <p className="font-mono text-xs text-red-400">✗ {passwordForm.formState.errors.email.message}</p>
            )}
          </div>

          <div className="space-y-1">
            <label htmlFor="password" className="block font-pixel text-[8px] text-primary-600 uppercase tracking-widest">
              Password
            </label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              placeholder="••••••••••••"
              className="w-full bg-retro-bg border-2 border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:shadow-glow focus:outline-none caret-primary-crt transition-all"
              {...passwordForm.register('password')}
              aria-invalid={Boolean(passwordForm.formState.errors.password)}
            />
            {passwordForm.formState.errors.password && (
              <p className="font-mono text-xs text-red-400">✗ {passwordForm.formState.errors.password.message}</p>
            )}
          </div>

          <div className="flex items-center justify-between">
            <Link href="/forgot-password" className="font-mono text-[10px] text-primary-700 hover:text-primary-500">
              Forgot password?
            </Link>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full h-10 bg-primary-900 border-2 border-primary-600 text-primary-crt font-pixel text-[9px] uppercase tracking-widest rounded hover:bg-primary-800 hover:border-primary-crt hover:shadow-glow disabled:opacity-50 disabled:cursor-not-allowed transition-all active:translate-y-px"
          >
            {isLoading ? (
              <span className="animate-blink-cursor">▋</span>
            ) : (
              '[ AUTHENTICATE ]'
            )}
          </button>

          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-retro-border" />
            </div>
            <div className="relative flex justify-center">
              <span className="bg-retro-card px-2 font-mono text-[10px] text-primary-700">or</span>
            </div>
          </div>

          <a
            href={`${process.env.NEXT_PUBLIC_OIDC_URL ?? '#'}`}
            className="flex items-center justify-center gap-2 w-full h-10 bg-transparent border-2 border-retro-border text-primary-600 font-pixel text-[8px] uppercase tracking-wider rounded hover:border-primary-700 hover:text-primary-400 transition-all"
          >
            <span>🔐</span> SSO Login
          </a>
        </form>
      )}

      {/* Magic link form */}
      {mode === 'magic-link' && (
        <form onSubmit={magicForm.handleSubmit(handleMagicLink)} noValidate className="space-y-4">
          <p className="font-mono text-xs text-primary-600">
            Enter your work email. We&apos;ll send a secure one-time login link.
          </p>

          <div className="space-y-1">
            <label htmlFor="magic-email" className="block font-pixel text-[8px] text-primary-600 uppercase tracking-widest">
              Work Email
            </label>
            <input
              id="magic-email"
              type="email"
              autoComplete="email"
              placeholder="user@company.com"
              className="w-full bg-retro-bg border-2 border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:shadow-glow focus:outline-none caret-primary-crt transition-all"
              {...magicForm.register('email')}
            />
            {magicForm.formState.errors.email && (
              <p className="font-mono text-xs text-red-400">✗ {magicForm.formState.errors.email.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full h-10 bg-primary-900 border-2 border-primary-600 text-primary-crt font-pixel text-[9px] uppercase tracking-widest rounded hover:bg-primary-800 hover:border-primary-crt hover:shadow-glow disabled:opacity-50 disabled:cursor-not-allowed transition-all active:translate-y-px"
          >
            {isLoading ? (
              <span className="animate-blink-cursor">▋</span>
            ) : (
              '[ SEND MAGIC LINK ]'
            )}
          </button>
        </form>
      )}
    </div>
  );
}
