'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useMutation } from '@tanstack/react-query';
import {
  Building2, Users, MapPin, Calendar, CreditCard,
  CheckCircle, ChevronRight, ChevronLeft, Zap, Sparkles,
  Factory, Code, ShoppingBag, Stethoscope, GraduationCap, Briefcase,
} from 'lucide-react';

const api = async (path: string, body: any) => {
  const res = await fetch(`/api/v1${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${localStorage.getItem('token') ?? ''}`,
    },
    body: JSON.stringify(body),
  });
  return res.json();
};

// ─── Industry Presets ────────────────────────────────────────────────

const INDUSTRY_PRESETS = [
  {
    id: 'tech',
    icon: <Code className="w-5 h-5" />,
    name: 'Technology / SaaS',
    description: 'Software, IT services, product companies',
    defaults: {
      leavePolicy: { cl: 12, sl: 12, el: 18, lta: 1 },
      workingHours: 9,
      workingDays: [1, 2, 3, 4, 5],
      probationMonths: 6,
      noticePeriodDays: 90,
      pfOptIn: true,
    },
  },
  {
    id: 'manufacturing',
    icon: <Factory className="w-5 h-5" />,
    name: 'Manufacturing',
    description: 'Production, engineering, industrial',
    defaults: {
      leavePolicy: { cl: 10, sl: 12, el: 15, lta: 1 },
      workingHours: 8,
      workingDays: [1, 2, 3, 4, 5, 6],
      probationMonths: 3,
      noticePeriodDays: 30,
      pfOptIn: true,
    },
  },
  {
    id: 'retail',
    icon: <ShoppingBag className="w-5 h-5" />,
    name: 'Retail / E-commerce',
    description: 'Retail, trade, distribution',
    defaults: {
      leavePolicy: { cl: 8, sl: 10, el: 12, lta: 1 },
      workingHours: 9,
      workingDays: [0, 1, 2, 3, 4, 5, 6],
      probationMonths: 3,
      noticePeriodDays: 30,
      pfOptIn: true,
    },
  },
  {
    id: 'healthcare',
    icon: <Stethoscope className="w-5 h-5" />,
    name: 'Healthcare',
    description: 'Hospitals, clinics, pharma',
    defaults: {
      leavePolicy: { cl: 12, sl: 15, el: 18, lta: 1 },
      workingHours: 8,
      workingDays: [1, 2, 3, 4, 5, 6],
      probationMonths: 6,
      noticePeriodDays: 60,
      pfOptIn: true,
    },
  },
  {
    id: 'education',
    icon: <GraduationCap className="w-5 h-5" />,
    name: 'Education',
    description: 'Schools, colleges, ed-tech',
    defaults: {
      leavePolicy: { cl: 10, sl: 12, el: 30, lta: 1 },
      workingHours: 7,
      workingDays: [1, 2, 3, 4, 5],
      probationMonths: 12,
      noticePeriodDays: 90,
      pfOptIn: true,
    },
  },
  {
    id: 'services',
    icon: <Briefcase className="w-5 h-5" />,
    name: 'Professional Services',
    description: 'Consulting, legal, finance, BFSI',
    defaults: {
      leavePolicy: { cl: 12, sl: 12, el: 21, lta: 1 },
      workingHours: 9,
      workingDays: [1, 2, 3, 4, 5],
      probationMonths: 6,
      noticePeriodDays: 90,
      pfOptIn: true,
    },
  },
];

const INDIA_HOLIDAYS_2025 = [
  { name: 'Republic Day', date: '2025-01-26' },
  { name: 'Holi', date: '2025-03-14' },
  { name: 'Good Friday', date: '2025-04-18' },
  { name: 'Maharashtra Day', date: '2025-05-01' },
  { name: 'Independence Day', date: '2025-08-15' },
  { name: 'Gandhi Jayanti', date: '2025-10-02' },
  { name: 'Dussehra', date: '2025-10-02' },
  { name: 'Diwali', date: '2025-10-20' },
  { name: 'Christmas', date: '2025-12-25' },
];

const STEPS = [
  { id: 'company', label: 'Company Info', icon: <Building2 className="w-4 h-4" /> },
  { id: 'industry', label: 'Industry', icon: <Briefcase className="w-4 h-4" /> },
  { id: 'headcount', label: 'Team Size', icon: <Users className="w-4 h-4" /> },
  { id: 'location', label: 'Locations', icon: <MapPin className="w-4 h-4" /> },
  { id: 'policies', label: 'Policies', icon: <Calendar className="w-4 h-4" /> },
  { id: 'payroll', label: 'Payroll', icon: <CreditCard className="w-4 h-4" /> },
  { id: 'review', label: 'Review & Launch', icon: <CheckCircle className="w-4 h-4" /> },
];

interface WizardState {
  company: { name: string; website: string; cin: string; gstin: string; pan: string };
  industry: string;
  headcount: string;
  locations: Array<{ name: string; city: string; state: string; stateCode: string }>;
  policies: {
    cl: number; sl: number; el: number;
    workingDays: number; workingHours: number;
    probationMonths: number; noticePeriodDays: number;
    includeIndiaHolidays: boolean;
  };
  payroll: {
    taxRegime: 'old' | 'new';
    pfOptIn: boolean;
    salaryComponents: string[];
    autoRun: boolean;
    runDay: number;
  };
}

const defaultState: WizardState = {
  company: { name: '', website: '', cin: '', gstin: '', pan: '' },
  industry: '',
  headcount: '1-50',
  locations: [{ name: 'Head Office', city: 'Bengaluru', state: 'Karnataka', stateCode: 'KA' }],
  policies: { cl: 12, sl: 12, el: 18, workingDays: 5, workingHours: 9, probationMonths: 6, noticePeriodDays: 90, includeIndiaHolidays: true },
  payroll: { taxRegime: 'new', pfOptIn: true, salaryComponents: ['basic', 'hra', 'special', 'lta', 'medical'], autoRun: false, runDay: 28 },
};

function ProgressBar({ step, total }: { step: number; total: number }) {
  return (
    <div className="w-full h-1 bg-retro-border rounded-full overflow-hidden">
      <div
        className="h-full bg-primary-crt rounded-full transition-all duration-500"
        style={{ width: `${((step + 1) / total) * 100}%` }}
      />
    </div>
  );
}

function StepIndicator({ steps, currentStep }: { steps: typeof STEPS; currentStep: number }) {
  return (
    <div className="flex items-center gap-0">
      {steps.map((s, i) => (
        <div key={s.id} className="flex items-center">
          <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded font-pixel text-[7px] transition-all ${
            i === currentStep
              ? 'bg-primary-900 border border-primary-700 text-primary-crt'
              : i < currentStep
              ? 'text-green-400'
              : 'text-primary-800'
          }`}>
            {i < currentStep ? <CheckCircle className="w-3 h-3" /> : s.icon}
            <span className="hidden sm:block">{s.label}</span>
          </div>
          {i < steps.length - 1 && <ChevronRight className="w-3 h-3 text-primary-800 shrink-0" />}
        </div>
      ))}
    </div>
  );
}

// ─── Step Components ──────────────────────────────────────────────────

function CompanyStep({ data, onChange }: { data: WizardState['company']; onChange: (d: WizardState['company']) => void }) {
  return (
    <div className="space-y-5">
      <div className="text-center space-y-2">
        <div className="w-14 h-14 mx-auto rounded-lg bg-primary-950 border border-primary-800 flex items-center justify-center">
          <Building2 className="w-7 h-7 text-primary-crt" />
        </div>
        <h2 className="font-pixel text-[11px] text-primary-300">Tell us about your company</h2>
        <p className="font-mono text-xs text-primary-700">This sets up your HR workspace</p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        {[
          { key: 'name', label: 'Company Name *', placeholder: 'Acme Technologies Pvt. Ltd.' },
          { key: 'website', label: 'Website', placeholder: 'https://acme.com' },
          { key: 'cin', label: 'CIN', placeholder: 'U72200KA2020PTC123456' },
          { key: 'gstin', label: 'GSTIN', placeholder: '29AABCS1429B1Z1' },
          { key: 'pan', label: 'PAN', placeholder: 'AABCS1429B' },
        ].map(f => (
          <div key={f.key} className={f.key === 'name' ? 'col-span-2' : ''}>
            <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">{f.label}</label>
            <input
              value={(data as any)[f.key]}
              onChange={e => onChange({ ...data, [f.key]: e.target.value })}
              placeholder={f.placeholder}
              className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none focus:shadow-glow"
            />
          </div>
        ))}
      </div>
    </div>
  );
}

function IndustryStep({ selected, onSelect }: { selected: string; onSelect: (id: string) => void }) {
  return (
    <div className="space-y-5">
      <div className="text-center space-y-2">
        <h2 className="font-pixel text-[11px] text-primary-300">What industry are you in?</h2>
        <p className="font-mono text-xs text-primary-700">We'll configure smart defaults based on your industry</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {INDUSTRY_PRESETS.map(preset => (
          <button
            key={preset.id}
            onClick={() => onSelect(preset.id)}
            className={`flex items-start gap-3 p-4 rounded-lg border text-left transition-all ${
              selected === preset.id
                ? 'bg-primary-950 border-primary-600 shadow-glow'
                : 'bg-retro-bg border-retro-border hover:border-primary-800'
            }`}
          >
            <div className={`shrink-0 p-1.5 rounded ${selected === preset.id ? 'text-primary-crt' : 'text-primary-700'}`}>
              {preset.icon}
            </div>
            <div>
              <p className={`font-mono text-sm font-medium ${selected === preset.id ? 'text-primary-300' : 'text-primary-500'}`}>
                {preset.name}
              </p>
              <p className="font-mono text-[10px] text-primary-700 mt-0.5">{preset.description}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function HeadcountStep({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const ranges = [
    { id: '1-50', label: '1–50', sub: 'Startup / Small' },
    { id: '51-200', label: '51–200', sub: 'Growing' },
    { id: '201-500', label: '201–500', sub: 'Mid-size' },
    { id: '501-1000', label: '501–1,000', sub: 'Large' },
    { id: '1000+', label: '1,000+', sub: 'Enterprise' },
  ];

  return (
    <div className="space-y-5">
      <div className="text-center space-y-2">
        <h2 className="font-pixel text-[11px] text-primary-300">How large is your team?</h2>
        <p className="font-mono text-xs text-primary-700">This helps us suggest the right approval matrix and policies</p>
      </div>
      <div className="grid grid-cols-5 gap-3">
        {ranges.map(r => (
          <button
            key={r.id}
            onClick={() => onChange(r.id)}
            className={`flex flex-col items-center gap-2 p-5 rounded-lg border transition-all ${
              value === r.id ? 'bg-primary-950 border-primary-600 shadow-glow' : 'bg-retro-bg border-retro-border hover:border-primary-800'
            }`}
          >
            <p className={`font-pixel text-[12px] ${value === r.id ? 'text-primary-crt' : 'text-primary-500'}`}>{r.label}</p>
            <p className="font-mono text-[9px] text-primary-700">{r.sub}</p>
          </button>
        ))}
      </div>
    </div>
  );
}

function PoliciesStep({ data, onChange, industry }: {
  data: WizardState['policies']; onChange: (d: WizardState['policies']) => void; industry: string;
}) {
  const preset = INDUSTRY_PRESETS.find(p => p.id === industry);

  const applyPreset = () => {
    if (preset) {
      onChange({
        ...data,
        cl: preset.defaults.leavePolicy.cl,
        sl: preset.defaults.leavePolicy.sl,
        el: preset.defaults.leavePolicy.el,
        workingDays: preset.defaults.workingDays.length,
        workingHours: preset.defaults.workingHours,
        probationMonths: preset.defaults.probationMonths,
        noticePeriodDays: preset.defaults.noticePeriodDays,
      });
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-pixel text-[11px] text-primary-300">Leave & HR Policies</h2>
          <p className="font-mono text-xs text-primary-700 mt-1">Configure your company-wide policies</p>
        </div>
        {preset && (
          <button
            onClick={applyPreset}
            className="flex items-center gap-2 px-3 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-400 hover:border-primary-500"
          >
            <Zap className="w-3 h-3" /> Apply {preset.name} Defaults
          </button>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4">
        {[
          { key: 'cl', label: 'Casual Leave (days/year)' },
          { key: 'sl', label: 'Sick Leave (days/year)' },
          { key: 'el', label: 'Earned Leave (days/year)' },
          { key: 'workingDays', label: 'Working Days/Week' },
          { key: 'workingHours', label: 'Working Hours/Day' },
          { key: 'probationMonths', label: 'Probation (months)' },
          { key: 'noticePeriodDays', label: 'Notice Period (days)' },
        ].map(f => (
          <div key={f.key}>
            <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">{f.label}</label>
            <input
              type="number"
              value={(data as any)[f.key]}
              onChange={e => onChange({ ...data, [f.key]: parseInt(e.target.value) })}
              className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 focus:border-primary-600 focus:outline-none"
            />
          </div>
        ))}
      </div>

      <div className="flex items-center gap-3 p-4 bg-retro-bg border border-retro-border rounded-lg">
        <input
          type="checkbox"
          id="india-holidays"
          checked={data.includeIndiaHolidays}
          onChange={e => onChange({ ...data, includeIndiaHolidays: e.target.checked })}
          className="w-4 h-4 accent-green-500"
        />
        <div>
          <label htmlFor="india-holidays" className="font-mono text-sm text-primary-300 cursor-pointer">
            Include India National Holidays (2025)
          </label>
          <p className="font-mono text-[10px] text-primary-700 mt-0.5">
            Auto-imports {INDIA_HOLIDAYS_2025.length} holidays: Republic Day, Holi, Independence Day, Diwali, Christmas…
          </p>
        </div>
      </div>
    </div>
  );
}

function PayrollStep({ data, onChange }: { data: WizardState['payroll']; onChange: (d: WizardState['payroll']) => void }) {
  const components = [
    { key: 'basic', label: 'Basic Pay', required: true },
    { key: 'hra', label: 'House Rent Allowance', required: true },
    { key: 'special', label: 'Special Allowance', required: false },
    { key: 'lta', label: 'Leave Travel Allowance', required: false },
    { key: 'medical', label: 'Medical Allowance', required: false },
    { key: 'transport', label: 'Transport Allowance', required: false },
    { key: 'performance', label: 'Performance Bonus', required: false },
  ];

  const toggleComponent = (key: string) => {
    if (['basic', 'hra'].includes(key)) return; // Required
    const current = data.salaryComponents;
    onChange({
      ...data,
      salaryComponents: current.includes(key) ? current.filter(c => c !== key) : [...current, key],
    });
  };

  return (
    <div className="space-y-5">
      <div>
        <h2 className="font-pixel text-[11px] text-primary-300">Payroll Configuration</h2>
        <p className="font-mono text-xs text-primary-700 mt-1">India-compliant statutory rules pre-configured</p>
      </div>

      <div className="grid grid-cols-2 gap-5">
        <div>
          <p className="font-pixel text-[7px] text-primary-600 mb-3">TAX REGIME (DEFAULT)</p>
          <div className="flex gap-3">
            {(['new', 'old'] as const).map(regime => (
              <button
                key={regime}
                onClick={() => onChange({ ...data, taxRegime: regime })}
                className={`flex-1 py-3 rounded-lg border font-pixel text-[8px] transition-all ${
                  data.taxRegime === regime
                    ? 'bg-primary-950 border-primary-600 text-primary-crt shadow-glow'
                    : 'bg-retro-bg border-retro-border text-primary-700 hover:border-primary-800'
                }`}
              >
                {regime.toUpperCase()} REGIME
                <p className="font-mono text-[8px] text-primary-700 mt-1 normal-case">
                  {regime === 'new' ? '₹75K std deduction, ₹7L rebate' : '80C/80D/HRA deductions'}
                </p>
              </button>
            ))}
          </div>
        </div>

        <div>
          <p className="font-pixel text-[7px] text-primary-600 mb-3">PROVIDENT FUND</p>
          <div className="space-y-2">
            {[
              { key: 'pfOptIn', label: 'PF Opt-In by Default', sub: '12% employee + 12% employer' },
              { key: 'autoRun', label: 'Auto-Run Payroll', sub: `On ${data.runDay}th of each month` },
            ].map(opt => (
              <div key={opt.key} className="flex items-center justify-between p-3 bg-retro-bg border border-retro-border rounded">
                <div>
                  <p className="font-mono text-xs text-primary-400">{opt.label}</p>
                  <p className="font-mono text-[10px] text-primary-700">{opt.sub}</p>
                </div>
                <button onClick={() => onChange({ ...data, [opt.key]: !(data as any)[opt.key] })}>
                  <div className={`w-10 h-5 rounded-full border transition-all ${(data as any)[opt.key] ? 'bg-green-900 border-green-700' : 'bg-retro-bg border-retro-border'}`}>
                    <div className={`w-3.5 h-3.5 rounded-full bg-current mt-0.5 transition-all ${(data as any)[opt.key] ? 'ml-5 text-green-400' : 'ml-0.5 text-primary-700'}`} />
                  </div>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div>
        <p className="font-pixel text-[7px] text-primary-600 mb-3">SALARY COMPONENTS</p>
        <div className="grid grid-cols-4 gap-2">
          {components.map(c => {
            const active = data.salaryComponents.includes(c.key) || c.required;
            return (
              <button
                key={c.key}
                onClick={() => toggleComponent(c.key)}
                disabled={c.required}
                className={`flex items-center gap-2 px-3 py-2 rounded border font-mono text-xs transition-all ${
                  active
                    ? 'bg-primary-950 border-primary-700 text-primary-300'
                    : 'bg-retro-bg border-retro-border text-primary-700 hover:border-primary-800'
                } ${c.required ? 'opacity-70 cursor-default' : ''}`}
              >
                <div className={`w-2 h-2 rounded-full ${active ? 'bg-primary-crt' : 'bg-primary-800'}`} />
                {c.label}
                {c.required && <span className="text-primary-800 ml-auto">req</span>}
              </button>
            );
          })}
        </div>
      </div>

      <div className="p-4 bg-primary-950/30 border border-primary-900 rounded-lg">
        <p className="font-pixel text-[7px] text-primary-600 mb-2">PRE-CONFIGURED STATUTORY RULES</p>
        <div className="grid grid-cols-3 gap-2 font-mono text-[10px]">
          {['PF: 12% + 12%', 'ESI: 0.75% + 3.25%', 'PT: State-wise slabs', '₹15K PF wage ceiling', '₹21K ESI threshold', '4% Health & Ed Cess', 'Rebate u/s 87A', 'Surcharge slabs', 'Gratuity formula'].map(r => (
            <div key={r} className="flex items-center gap-1.5 text-primary-600">
              <CheckCircle className="w-2.5 h-2.5 text-green-500 shrink-0" /> {r}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ReviewStep({ state }: { state: WizardState }) {
  const preset = INDUSTRY_PRESETS.find(p => p.id === state.industry);
  return (
    <div className="space-y-5">
      <div className="text-center space-y-2">
        <div className="w-14 h-14 mx-auto rounded-lg bg-green-950 border border-green-800 flex items-center justify-center">
          <Sparkles className="w-7 h-7 text-green-400" />
        </div>
        <h2 className="font-pixel text-[11px] text-primary-300">Ready to Launch!</h2>
        <p className="font-mono text-xs text-primary-700">Review your configuration and we'll set everything up</p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        {[
          { title: 'Company', items: [['Name', state.company.name], ['Industry', preset?.name ?? state.industry], ['Headcount', state.headcount]] },
          { title: 'Policies', items: [['Casual Leave', `${state.policies.cl} days`], ['Sick Leave', `${state.policies.sl} days`], ['Earned Leave', `${state.policies.el} days`], ['Working Days', `${state.policies.workingDays}/week`]] },
          { title: 'Payroll', items: [['Tax Regime', state.payroll.taxRegime.toUpperCase()], ['PF Opt-In', state.payroll.pfOptIn ? 'Yes' : 'No'], ['Auto-Run', state.payroll.autoRun ? 'Enabled' : 'Manual'], ['Components', `${state.payroll.salaryComponents.length} enabled`]] },
          { title: 'Auto-Created', items: [['Leave Types', '4 types (CL/SL/EL/LTA)'], ['Holidays', `${state.policies.includeIndiaHolidays ? INDIA_HOLIDAYS_2025.length : 0} India holidays`], ['Workflows', '3 default workflows'], ['Approval Matrix', 'Manager → HR flow']] },
        ].map(section => (
          <div key={section.title} className="bg-retro-bg border border-retro-border rounded-lg p-4">
            <p className="font-pixel text-[7px] text-primary-600 mb-3">{section.title.toUpperCase()}</p>
            <div className="space-y-1.5">
              {section.items.map(([label, value]) => (
                <div key={label} className="flex justify-between font-mono text-xs">
                  <span className="text-primary-600">{label}</span>
                  <span className="text-primary-300">{value}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main Wizard ──────────────────────────────────────────────────────

export function SetupWizard() {
  const [currentStep, setCurrentStep] = useState(0);
  const [state, setState] = useState<WizardState>(defaultState);
  const router = useRouter();

  const setupMutation = useMutation({
    mutationFn: () => api('/setup/complete', state),
    onSuccess: () => router.push('/dashboard'),
  });

  const canProceed = () => {
    switch (currentStep) {
      case 0: return state.company.name.trim().length > 0;
      case 1: return state.industry !== '';
      default: return true;
    }
  };

  const applyIndustryPreset = (industryId: string) => {
    const preset = INDUSTRY_PRESETS.find(p => p.id === industryId);
    if (preset) {
      setState(s => ({
        ...s,
        industry: industryId,
        policies: {
          ...s.policies,
          cl: preset.defaults.leavePolicy.cl,
          sl: preset.defaults.leavePolicy.sl,
          el: preset.defaults.leavePolicy.el,
          workingDays: preset.defaults.workingDays.length,
          workingHours: preset.defaults.workingHours,
          probationMonths: preset.defaults.probationMonths,
          noticePeriodDays: preset.defaults.noticePeriodDays,
        },
        payroll: { ...s.payroll, pfOptIn: preset.defaults.pfOptIn },
      }));
    } else {
      setState(s => ({ ...s, industry: industryId }));
    }
  };

  const stepContent = [
    <CompanyStep key="company" data={state.company} onChange={d => setState(s => ({ ...s, company: d }))} />,
    <IndustryStep key="industry" selected={state.industry} onSelect={applyIndustryPreset} />,
    <HeadcountStep key="headcount" value={state.headcount} onChange={v => setState(s => ({ ...s, headcount: v }))} />,
    <div key="location" className="text-center py-8 text-primary-600 font-mono">Location configuration — add office locations after setup</div>,
    <PoliciesStep key="policies" data={state.policies} onChange={d => setState(s => ({ ...s, policies: d }))} industry={state.industry} />,
    <PayrollStep key="payroll" data={state.payroll} onChange={d => setState(s => ({ ...s, payroll: d }))} />,
    <ReviewStep key="review" state={state} />,
  ];

  return (
    <div className="min-h-screen bg-retro-bg flex items-center justify-center p-6">
      <div className="w-full max-w-3xl">
        {/* Header */}
        <div className="text-center mb-8">
          <p className="font-pixel text-[8px] text-primary-700 mb-1">RETROWORKS HR</p>
          <h1 className="font-pixel text-[12px] text-primary-crt">COMPANY SETUP</h1>
          <p className="font-mono text-xs text-primary-700 mt-2">Let's configure your HR workspace in a few steps</p>
        </div>

        {/* Progress */}
        <div className="mb-6 space-y-3">
          <StepIndicator steps={STEPS} currentStep={currentStep} />
          <ProgressBar step={currentStep} total={STEPS.length} />
        </div>

        {/* Content */}
        <div className="bg-retro-card border border-retro-border rounded-xl p-8 min-h-80">
          {stepContent[currentStep]}
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-6">
          <button
            onClick={() => setCurrentStep(s => s - 1)}
            disabled={currentStep === 0}
            className="flex items-center gap-2 px-4 py-2 border border-retro-border rounded font-mono text-sm text-primary-600 hover:text-primary-400 disabled:opacity-30 transition-all"
          >
            <ChevronLeft className="w-4 h-4" /> Back
          </button>

          <span className="font-mono text-xs text-primary-700">
            Step {currentStep + 1} of {STEPS.length}
          </span>

          {currentStep === STEPS.length - 1 ? (
            <button
              onClick={() => setupMutation.mutate()}
              disabled={setupMutation.isPending}
              className="flex items-center gap-2 px-6 py-2.5 bg-green-900 border border-green-700 rounded font-pixel text-[8px] text-green-300 hover:border-green-500 disabled:opacity-50 transition-all shadow-glow"
            >
              <Sparkles className="w-4 h-4" />
              {setupMutation.isPending ? 'Setting up…' : 'Launch RetroWorks HR'}
            </button>
          ) : (
            <button
              onClick={() => setCurrentStep(s => s + 1)}
              disabled={!canProceed()}
              className="flex items-center gap-2 px-4 py-2.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500 disabled:opacity-30 transition-all"
            >
              Continue <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
