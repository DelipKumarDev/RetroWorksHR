'use client';
import { useQuery } from '@tanstack/react-query';
import { Shield, CheckCircle, XCircle, AlertTriangle, Clock, MinusCircle } from 'lucide-react';

const api = (path: string) => fetch(`/api/v1${path}`, { headers: { Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}` } }).then(r => r.json());

const STATUS_CONFIG = {
  compliant: { icon: <CheckCircle className="w-4 h-4" />, color: 'text-green-400', bg: 'bg-green-950/20 border-green-900', label: 'Compliant' },
  non_compliant: { icon: <XCircle className="w-4 h-4" />, color: 'text-red-400', bg: 'bg-red-950/20 border-red-900', label: 'Non-Compliant' },
  warning: { icon: <AlertTriangle className="w-4 h-4" />, color: 'text-yellow-400', bg: 'bg-yellow-950/20 border-yellow-900', label: 'Warning' },
  pending: { icon: <Clock className="w-4 h-4" />, color: 'text-blue-400', bg: 'bg-blue-950/20 border-blue-900', label: 'Pending' },
  not_applicable: { icon: <MinusCircle className="w-4 h-4" />, color: 'text-primary-700', bg: 'bg-retro-bg border-retro-border', label: 'N/A' },
};

function GradeMeter({ score, grade }: { score: number; grade: string }) {
  const color = score >= 90 ? '#22c55e' : score >= 75 ? '#3b82f6' : score >= 60 ? '#eab308' : score >= 40 ? '#f97316' : '#ef4444';
  const circumference = 2 * Math.PI * 54;
  const dash = (score / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative w-36 h-36">
        <svg className="w-full h-full -rotate-90" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="54" fill="none" stroke="#1a1a1a" strokeWidth="12" />
          <circle cx="60" cy="60" r="54" fill="none" stroke={color} strokeWidth="12" strokeDasharray={`${dash} ${circumference}`} strokeLinecap="round" style={{ transition: 'stroke-dasharray 1s ease' }} />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="font-pixel text-[28px]" style={{ color }}>{grade}</span>
          <span className="font-mono text-xs text-primary-600">{score}%</span>
        </div>
      </div>
      <p className="font-mono text-xs text-primary-600 text-center">
        {score >= 90 ? 'Excellent compliance' : score >= 75 ? 'Good — minor gaps' : score >= 60 ? 'Needs attention' : 'Critical violations'}
      </p>
    </div>
  );
}

export function ComplianceDashboard() {
  const { data, isLoading } = useQuery({ queryKey: ['compliance-score'], queryFn: () => api('/compliance/score').then(r => r.data), refetchInterval: 300_000 });
  const { data: stateWise = [] } = useQuery({ queryKey: ['compliance-state'], queryFn: () => api('/compliance/state-wise').then(r => r.data ?? []) });

  if (isLoading) return <div className="text-center py-20 font-mono text-primary-700 animate-pulse">Loading compliance data…</div>;

  const checks = data?.checks ?? [];
  const nonCompliant = checks.filter((c: any) => c.status === 'non_compliant');
  const warnings = checks.filter((c: any) => c.status === 'warning');

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="font-pixel text-[10px] text-primary-crt">LIVE COMPLIANCE MONITOR</h1>
        <p className="font-mono text-xs text-primary-700 mt-1">Real-time India statutory compliance — PF · ESI · Labour Law · Wages · Filing</p>
      </div>

      <div className="grid grid-cols-12 gap-5">
        {/* Score */}
        <div className="col-span-4 bg-retro-card border border-retro-border rounded-xl p-6 flex flex-col items-center justify-center">
          <p className="font-pixel text-[8px] text-primary-600 mb-4">COMPLIANCE SCORE</p>
          <GradeMeter score={data?.overallScore ?? 0} grade={data?.grade ?? '-'} />
          <div className="grid grid-cols-3 gap-3 w-full mt-5">
            {[['Passed', checks.filter((c: any) => c.status === 'compliant').length, 'text-green-400'], ['Warnings', warnings.length, 'text-yellow-400'], ['Failed', nonCompliant.length, 'text-red-400']].map(([l, v, cls]) => (
              <div key={l as string} className="text-center"><p className={`font-pixel text-[14px] ${cls as string}`}>{v as number}</p><p className="font-mono text-[8px] text-primary-700">{l as string}</p></div>
            ))}
          </div>
          <p className="font-mono text-[9px] text-primary-800 mt-4">Updated: {data?.lastUpdated ? new Date(data.lastUpdated).toLocaleString('en-IN') : '—'}</p>
        </div>

        {/* Checks */}
        <div className="col-span-8 space-y-3">
          <p className="font-pixel text-[8px] text-primary-500">STATUTORY CHECKS</p>
          {checks.map((check: any) => {
            const cfg = (STATUS_CONFIG as any)[check.status] ?? STATUS_CONFIG.pending;
            return (
              <div key={check.id} className={`flex items-start gap-3 p-4 border rounded-lg ${cfg.bg}`}>
                <div className={cfg.color}>{cfg.icon}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <p className={`font-mono text-sm font-medium ${cfg.color}`}>{check.name}</p>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className={`font-pixel text-[8px] px-2 py-0.5 rounded border ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                      <span className="font-mono text-[9px] text-primary-700">{check.score}pts</span>
                    </div>
                  </div>
                  <p className="font-mono text-[10px] text-primary-700 mt-0.5">{check.details}</p>
                  {check.dueDate && <p className="font-mono text-[9px] text-primary-800 mt-1">Due: {check.dueDate}{check.filedDate ? ` · Filed: ${new Date(check.filedDate).toLocaleDateString('en-IN')}` : ''}</p>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* State-wise */}
      {(stateWise as any[]).length > 0 && (
        <div>
          <p className="font-pixel text-[8px] text-primary-500 mb-3">STATE-WISE COMPLIANCE (YOUR LOCATIONS)</p>
          <div className="overflow-x-auto">
            <table className="w-full font-mono text-xs">
              <thead><tr className="border-b border-retro-border">{['Location', 'State', 'Min Wage/mo', 'PT Annual', 'PT Applicable'].map(h => <th key={h} className="text-left py-2 px-3 text-primary-700 font-pixel text-[7px]">{h}</th>)}</tr></thead>
              <tbody>{(stateWise as any[]).map((row: any) => (
                <tr key={row.locationId} className="border-b border-retro-border/30 hover:bg-surface-raised">
                  <td className="py-2.5 px-3 text-primary-300">{row.locationName}</td>
                  <td className="py-2.5 px-3 text-primary-600">{row.stateCode}</td>
                  <td className="py-2.5 px-3 text-primary-400">₹{row.minimumWage?.toLocaleString('en-IN') ?? 'N/A'}</td>
                  <td className="py-2.5 px-3 text-primary-400">{row.ptAnnual ? `₹${row.ptAnnual}` : '₹0'}</td>
                  <td className="py-2.5 px-3">{row.ptApplicable ? <CheckCircle className="w-3.5 h-3.5 text-green-400" /> : <MinusCircle className="w-3.5 h-3.5 text-primary-700" />}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
