'use client';

import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Bell, Check, CheckCheck, X, AlertCircle, Gift, FileText, Calendar, Star } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const api = async (path: string, options?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
      ...options?.headers,
    },
  });
  return res.json();
};

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  link?: string;
  read: boolean;
  createdAt: string;
}

const NOTIF_ICONS: Record<string, React.ReactNode> = {
  'leave.approved': <Check className="w-3.5 h-3.5 text-green-400" />,
  'leave.rejected': <X className="w-3.5 h-3.5 text-red-400" />,
  'leave.submitted': <Calendar className="w-3.5 h-3.5 text-blue-400" />,
  'payslip.ready': <FileText className="w-3.5 h-3.5 text-yellow-400" />,
  'review.completed': <Star className="w-3.5 h-3.5 text-purple-400" />,
  'birthday': <Gift className="w-3.5 h-3.5 text-pink-400" />,
  'work-anniversary': <Gift className="w-3.5 h-3.5 text-yellow-400" />,
};

const getIcon = (type: string) =>
  NOTIF_ICONS[type] ?? <AlertCircle className="w-3.5 h-3.5 text-primary-600" />;

export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);
  const queryClient = useQueryClient();

  const { data: count = 0 } = useQuery<number>({
    queryKey: ['notif-count'],
    queryFn: () => api('/notifications/count').then(r => r.data ?? 0),
    refetchInterval: 30_000, // Poll every 30s
  });

  const { data: notifications = [] } = useQuery<Notification[]>({
    queryKey: ['notifications'],
    queryFn: () => api('/notifications').then(r => r.data ?? []),
    enabled: open,
  });

  const markReadMutation = useMutation({
    mutationFn: (ids?: string[]) => api('/notifications/read', { method: 'POST', body: JSON.stringify({ ids }) }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notif-count'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
  });

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    if (open) document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const unread = notifications.filter(n => !n.read);
  const displayCount = count > 99 ? '99+' : count;

  return (
    <div className="relative" ref={panelRef}>
      <button
        onClick={() => setOpen(o => !o)}
        className="relative p-2 rounded text-primary-600 hover:text-primary-400 hover:bg-surface-raised transition-all"
        aria-label={`${count} unread notifications`}
      >
        <Bell className="w-4.5 h-4.5" />
        {count > 0 && (
          <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 flex items-center justify-center bg-red-600 text-white font-mono text-[8px] rounded-full px-0.5">
            {displayCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 bg-retro-card border border-retro-border rounded-lg shadow-xl z-50 overflow-hidden">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-3 border-b border-retro-border bg-retro-bg">
            <div className="flex items-center gap-2">
              <span className="font-pixel text-[8px] text-primary-500">NOTIFICATIONS</span>
              {count > 0 && (
                <span className="px-1.5 py-0.5 bg-red-900 border border-red-700 rounded font-mono text-[8px] text-red-400">
                  {count} new
                </span>
              )}
            </div>
            {unread.length > 0 && (
              <button
                onClick={() => markReadMutation.mutate(undefined)}
                className="flex items-center gap-1 font-mono text-[9px] text-primary-600 hover:text-primary-400"
              >
                <CheckCheck className="w-3 h-3" /> Mark all read
              </button>
            )}
          </div>

          {/* List */}
          <div className="max-h-96 overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="py-10 text-center">
                <Bell className="w-8 h-8 text-primary-800 mx-auto mb-2" />
                <p className="font-pixel text-[7px] text-primary-700">No notifications</p>
              </div>
            ) : (
              notifications.slice(0, 20).map(notif => (
                <div
                  key={notif.id}
                  onClick={() => {
                    if (!notif.read) markReadMutation.mutate([notif.id]);
                    if (notif.link) window.location.href = notif.link;
                    setOpen(false);
                  }}
                  className={`flex gap-3 px-4 py-3 border-b border-retro-border/50 cursor-pointer transition-all hover:bg-surface-raised ${
                    !notif.read ? 'bg-primary-950/30' : ''
                  }`}
                >
                  {/* Icon */}
                  <div className="shrink-0 w-7 h-7 rounded-full bg-retro-bg border border-retro-border flex items-center justify-center mt-0.5">
                    {getIcon(notif.type)}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <p className={`font-mono text-xs leading-tight ${!notif.read ? 'text-primary-300 font-medium' : 'text-primary-500'}`}>
                        {notif.title}
                      </p>
                      {!notif.read && <div className="shrink-0 w-1.5 h-1.5 rounded-full bg-primary-crt mt-1" />}
                    </div>
                    <p className="font-mono text-[10px] text-primary-700 mt-0.5 leading-relaxed line-clamp-2">
                      {notif.message}
                    </p>
                    <p className="font-mono text-[9px] text-primary-800 mt-1">
                      {formatDistanceToNow(new Date(notif.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="px-4 py-2 border-t border-retro-border text-center">
              <a href="/dashboard/notifications" className="font-mono text-[9px] text-primary-600 hover:text-primary-400">
                View all notifications →
              </a>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
