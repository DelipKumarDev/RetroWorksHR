'use client';
/**
 * System Health Dashboard — /admin/system-health
 * DB · Redis · Storage · Queues · Crons · Failed Jobs · AI Usage
 * RetroWorks HR v1.0
 */

import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Database, Cpu, HardDrive, Activity, Clock, AlertTriangle,
  CheckCircle, XCircle, AlertCircle, RefreshCw, Zap, Terminal,
} from 'lucide-react';

const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string) =>
  fetch(`/api/v1/security${path}`, { headers: { Authorization: `Bearer ${tok()}` } })
    .then(r => r.json()).then(r => r.data ?? r);

const fmt  = (n: number) => n >= 1_000_000 ? `${(n/1_000_000).toFixed(1)}M` : n >= 1_000 ? `${(n/1_000).toFixed(1)}K` : String(n);
const fmtT = (d: string | Date) => new Date(d).toLocaleString('en-IN', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit', second:'2-digit' });
const fmtUp = (s: number) => { const h=Math.floor(s/3600), m=Math.floor((s%3600)/60), sec=s%60; return h>0?`${h}h ${m}m`:m>0?`${m}m ${sec}s`:`${sec}s`; };

function StatusDot({ status }: { status: string }) {
  return <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
    status==='healthy'  ? 'bg-green-400 shadow-[0_0_6px_rgba(74,222,128,0.8)]' :
    status==='degraded' ? 'bg-amber-400 shadow-[0_0_6px_rgba(251,191,36,0.8)]' :
    'bg-red-400 shadow-[0_0_6px_rgba(248,113,113,0.8)] animate-pulse'}`} />;
}

function StatusBadge({ status }: { status: string }) {
  const c = status==='healthy'?'text-green-400 border-green-800 bg-green-950/20':status==='degraded'?'text-amber-400 border-amber-800 bg-amber-950/20':'text-red-400 border-red-800 bg-red-950/20 animate-pulse';
  return <span className={`font-pixel text-[5px] px-2 py-0.5 rounded border ${c}`}>{status.toUpperCase()}</span>;
}

function ServiceCard({ svc, icon: Icon }: { svc: any; icon: any }) {
  return (
    <div className={`border rounded p-4 space-y-2 ${svc.status==='down'?'border-red-800/60 bg-red-950/5':svc.status==='degraded'?'border-amber-800/60':'border-retro-border'}`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <StatusDot status={svc.status} />
          <Icon className="w-3.5 h-3.5 text-primary-600" />
          <span className="font-pixel text-[7px] text-primary-500">{(svc.name||'').toUpperCase()}</span>
        </div>
        <StatusBadge status={svc.status} />
      </div>
      {svc.latencyMs!=null && (
        <div className="flex justify-between">
          <span className="font-pixel text-[6px] text-primary-800">LATENCY</span>
          <span className={`font-mono text-[10px] ${svc.latencyMs>100?'text-amber-400':'text-primary-500'}`}>{svc.latencyMs}ms</span>
        </div>
      )}
      {svc.message && <div className="font-mono text-[9px] text-red-400 truncate">{svc.message}</div>}
      <div className="font-pixel text-[5px] text-primary-800">CHECKED {fmtT(svc.lastChecked)}</div>
    </div>
  );
}

function QueueCard({ q }: { q: any }) {
  const bad = q.failed>0 || q.waiting>100;
  return (
    <div className={`border rounded p-3 space-y-2 ${bad?'border-amber-800/50':'border-retro-border'}`}>
      <div className="flex items-center justify-between">
        <span className="font-pixel text-[7px] text-primary-500">{q.name}</span>
        {q.isPaused && <span className="font-pixel text-[5px] text-amber-400 border border-amber-800 px-1 rounded">PAUSED</span>}
      </div>
      <div className="grid grid-cols-4 gap-1 text-center">
        {[['WAITING',q.waiting,q.waiting>100?'text-amber-400':'text-primary-500'],
          ['ACTIVE',q.active,'text-blue-400'],
          ['FAILED',q.failed,q.failed>0?'text-red-400':'text-primary-700'],
          ['DONE',q.completed,'text-primary-700']].map(([l,v,c]) => (
          <div key={l as string}>
            <div className={`font-pixel text-[11px] ${c}`}>{fmt(Number(v))}</div>
            <div className="font-pixel text-[4px] text-primary-800 mt-0.5">{l}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function CronTable({ crons }: { crons: any[] }) {
  const ICON: Record<string,any> = {
    success: <CheckCircle className="w-3 h-3 text-green-400" />,
    failure: <XCircle className="w-3 h-3 text-red-400" />,
    running: <RefreshCw className="w-3 h-3 text-blue-400 animate-spin" />,
    never:   <AlertCircle className="w-3 h-3 text-primary-800" />,
  };
  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-retro-border">
            {['JOB','STATUS','LAST RUN','DURATION','RUNS 24H'].map(h=>(
              <th key={h} className="text-left px-3 py-2 font-pixel text-[5px] text-primary-800">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {crons.map((c:any)=>(
            <tr key={c.jobName} className="border-b border-retro-border/50 hover:bg-retro-bg-secondary/50">
              <td className="px-3 py-2 font-mono text-[10px] text-primary-500">{c.jobName}</td>
              <td className="px-3 py-2"><div className="flex items-center gap-1.5">{ICON[c.lastStatus]??ICON.never}<span className="font-pixel text-[6px] text-primary-700">{c.lastStatus.toUpperCase()}</span></div></td>
              <td className="px-3 py-2 font-mono text-[9px] text-primary-700">{c.lastRun?fmtT(c.lastRun):'—'}</td>
              <td className="px-3 py-2 font-mono text-[9px] text-primary-700">{c.lastDurationMs?`${c.lastDurationMs}ms`:'—'}</td>
              <td className="px-3 py-2 text-center font-pixel text-[8px] text-primary-500">{c.runCount24h}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function UptimeClock({ seconds }: { seconds: number }) {
  const [s, setS] = useState(seconds);
  useEffect(() => { const iv = setInterval(()=>setS(x=>x+1),1000); return ()=>clearInterval(iv); }, []);
  return <span className="font-mono text-sm text-primary-crt">{fmtUp(s)}</span>;
}

export function SystemHealthPage() {
  const { data: h, isLoading, refetch, isFetching } = useQuery({
    queryKey: ['system-health'],
    queryFn: () => api('/system-health'),
    refetchInterval: 30_000,
  });

  const SVC_ICONS: Record<string,any> = { database: Database, redis: Cpu, storage: HardDrive };

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="font-pixel text-[9px] text-primary-500">SYSTEM HEALTH</div>
          <div className="font-mono text-xs text-primary-700 mt-0.5">
            RetroWorks HR v{h?.appVersion??'1.0.0'} · Node {h?.nodeVersion??'—'}
          </div>
        </div>
        <div className="flex items-center gap-3">
          {h && <div className="flex items-center gap-2"><StatusDot status={h.overall}/><StatusBadge status={h.overall}/></div>}
          <button onClick={()=>refetch()} disabled={isFetching}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border rounded font-pixel text-[6px] text-primary-700 hover:border-primary-700 disabled:opacity-40">
            <RefreshCw className={`w-3 h-3 ${isFetching?'animate-spin':''}`}/>REFRESH
          </button>
        </div>
      </div>

      {isLoading && <div className="py-16 text-center font-pixel text-[8px] text-primary-700 animate-pulse">CHECKING SYSTEM STATUS...</div>}

      {h && (<>
        {/* Stats bar */}
        <div className="grid grid-cols-4 gap-3">
          {[{l:'UPTIME',v:<UptimeClock seconds={h.uptimeSeconds}/>,icon:Clock},
            {l:'FAILED JOBS 24H',v:<span className={`font-mono text-sm ${h.failedJobs24h>0?'text-red-400':'text-primary-crt'}`}>{h.failedJobs24h}</span>,icon:AlertTriangle},
            {l:'LAST BACKUP',v:<span className="font-mono text-xs text-primary-500">{h.lastBackup?fmtT(h.lastBackup.at):'Never'}</span>,icon:HardDrive},
            {l:'CHECKED',v:<span className="font-mono text-xs text-primary-700">{fmtT(h.timestamp)}</span>,icon:Activity},
          ].map(s=>(
            <div key={s.l} className="border border-retro-border rounded p-3">
              <div className="flex items-center gap-1 mb-1"><s.icon className="w-3 h-3 text-primary-800"/><span className="font-pixel text-[5px] text-primary-800">{s.l}</span></div>
              {s.v}
            </div>
          ))}
        </div>

        {/* Backup detail */}
        {h.lastBackup && (
          <div className={`flex items-center gap-3 px-3 py-2 border rounded ${h.lastBackup.status==='success'?'border-green-800/50 bg-green-950/10':'border-red-800/50 bg-red-950/10'}`}>
            <HardDrive className={`w-4 h-4 ${h.lastBackup.status==='success'?'text-green-400':'text-red-400'}`}/>
            <span className="font-mono text-[10px] text-primary-500">{fmtT(h.lastBackup.at)}</span>
            <span className="font-mono text-[10px] text-primary-700">{h.lastBackup.sizeGb} GB</span>
            <span className={`font-pixel text-[5px] px-1.5 py-0.5 rounded border ml-auto ${h.lastBackup.status==='success'?'text-green-400 border-green-800':'text-red-400 border-red-800'}`}>{h.lastBackup.status.toUpperCase()}</span>
            <span className="font-mono text-[9px] text-primary-800">{h.lastBackup.location}</span>
          </div>
        )}

        {/* Services */}
        <div>
          <div className="font-pixel text-[7px] text-primary-700 mb-2">SERVICES</div>
          <div className="grid grid-cols-3 gap-3">
            {Object.entries(h.services).map(([name,svc]:any)=>(
              <ServiceCard key={name} svc={{...svc,name}} icon={SVC_ICONS[name]??Database}/>
            ))}
          </div>
        </div>

        {/* Queues */}
        {h.queues?.length>0 && (
          <div>
            <div className="font-pixel text-[7px] text-primary-700 mb-2">JOB QUEUES</div>
            <div className="grid grid-cols-2 gap-3">{h.queues.map((q:any)=><QueueCard key={q.name} q={q}/>)}</div>
          </div>
        )}

        {/* Cron log */}
        {h.crons?.length>0 && (
          <div className="border border-retro-border rounded overflow-hidden">
            <div className="flex items-center gap-2 px-4 py-2 border-b border-retro-border bg-retro-bg-secondary">
              <Terminal className="w-3.5 h-3.5 text-primary-600"/>
              <span className="font-pixel text-[7px] text-primary-500">CRON EXECUTION LOG</span>
            </div>
            <CronTable crons={h.crons}/>
          </div>
        )}

        {/* AI usage */}
        {h.aiUsage && (
          <div className="border border-retro-border rounded p-4">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-3.5 h-3.5 text-violet-400"/>
              <span className="font-pixel text-[7px] text-primary-500">AI USAGE — {h.aiUsage.period}</span>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {[['REQUESTS',fmt(h.aiUsage.totalRequests),'text-primary-crt'],
                ['TOKENS IN',fmt(h.aiUsage.totalTokensIn),'text-blue-400'],
                ['TOKENS OUT',fmt(h.aiUsage.totalTokensOut),'text-violet-400'],
                ['EST. COST',`$${h.aiUsage.estimatedCostUsd.toFixed(2)}`,'text-amber-400']
              ].map(([l,v,c])=>(
                <div key={l} className="text-center">
                  <div className={`font-pixel text-[14px] ${c}`}>{v}</div>
                  <div className="font-pixel text-[5px] text-primary-800 mt-0.5">{l}</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </>)}
    </div>
  );
}
