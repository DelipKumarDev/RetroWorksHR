'use client';
/**
 * Security Admin — MFA · IP Allowlist · Sessions · Login History · DPDPA · Consent
 * RetroWorks HR v1.0
 */

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Shield, Wifi, Monitor, Clock, LogIn, Lock, Unlock,
  Plus, Trash2, Check, X, AlertTriangle, FileDown,
  Eye, EyeOff, ChevronRight, RefreshCw, Globe,
} from 'lucide-react';

const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1/security${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${tok()}`, 'Content-Type': 'application/json', ...((opts?.headers ?? {}) as any) },
  }).then(r => r.json()).then(r => r.data ?? r);

const fmtDate = (d: string | Date) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
const fmtDay  = (d: string | Date) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

// ── MFA Policy Panel ──────────────────────────────────────────────────────────
function MfaPolicyPanel() {
  const qc = useQueryClient();
  const { data: policy } = useQuery({ queryKey: ['mfa-policy'], queryFn: () => api('/mfa/policy') });
  const [roles, setRoles] = useState<string[]>([]);
  const [grace, setGrace] = useState(24);
  const [editing, setEditing] = useState(false);

  const ROLE_OPTIONS = ['super-admin', 'hr-admin', 'payroll-admin', 'manager', 'cfo'];

  const saveMut = useMutation({
    mutationFn: () => api('/mfa/policy', { method: 'PUT', body: JSON.stringify({ enforceForRoles: roles, gracePeriodHours: grace }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['mfa-policy'] }); setEditing(false); },
  });

  const current = policy ?? { enforceForRoles: ['payroll-admin','super-admin'], gracePeriodHours: 24 };

  return (
    <div className="border border-retro-border rounded p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-primary-600" />
          <span className="font-pixel text-[8px] text-primary-500">MFA POLICY</span>
        </div>
        <button onClick={() => { setEditing(!editing); setRoles(current.enforceForRoles ?? []); setGrace(current.gracePeriodHours ?? 24); }}
          className="font-pixel text-[6px] text-primary-700 hover:text-primary-crt border border-retro-border px-2 py-1 rounded">
          {editing ? 'CANCEL' : 'EDIT'}
        </button>
      </div>

      {!editing ? (
        <div className="space-y-2">
          <div>
            <div className="font-pixel text-[6px] text-primary-800 mb-1">ENFORCED ROLES</div>
            <div className="flex flex-wrap gap-1">
              {(current.enforceForRoles ?? []).map((r: string) => (
                <span key={r} className="font-pixel text-[6px] text-primary-crt border border-primary-700 px-2 py-0.5 rounded bg-primary-950">
                  {r}
                </span>
              ))}
            </div>
          </div>
          <div className="flex justify-between">
            <span className="font-pixel text-[6px] text-primary-800">GRACE PERIOD</span>
            <span className="font-mono text-[10px] text-primary-500">{current.gracePeriodHours}h after account creation</span>
          </div>
        </div>
      ) : (
        <div className="space-y-3">
          <div>
            <div className="font-pixel text-[6px] text-primary-700 mb-2">ENFORCE MFA FOR ROLES</div>
            <div className="flex flex-wrap gap-1">
              {ROLE_OPTIONS.map(r => (
                <button key={r}
                  onClick={() => setRoles(rs => rs.includes(r) ? rs.filter(x => x !== r) : [...rs, r])}
                  className={`font-pixel text-[6px] px-2 py-1 rounded border transition-all ${
                    roles.includes(r) ? 'text-primary-crt border-primary-700 bg-primary-950' : 'text-primary-800 border-retro-border hover:border-primary-700'
                  }`}>
                  {r}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <label className="font-pixel text-[6px] text-primary-700">GRACE PERIOD (HOURS)</label>
            <input type="number" min={0} max={168} value={grace} onChange={e => setGrace(parseInt(e.target.value))}
              className="w-20 px-2 py-1 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none" />
          </div>
          <button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}
            className="px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
            {saveMut.isPending ? 'SAVING...' : 'SAVE POLICY'}
          </button>
        </div>
      )}
    </div>
  );
}

// ── IP Allowlist Panel ────────────────────────────────────────────────────────
function IpAllowlistPanel() {
  const qc = useQueryClient();
  const { data: rules = [] } = useQuery({ queryKey: ['ip-allowlist'], queryFn: () => api('/ip-allowlist') });
  const [cidr, setCidr] = useState('');
  const [label, setLabel] = useState('');
  const [adding, setAdding] = useState(false);

  const addMut = useMutation({
    mutationFn: () => api('/ip-allowlist', { method: 'POST', body: JSON.stringify({ cidr, label }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['ip-allowlist'] }); setCidr(''); setLabel(''); setAdding(false); },
  });
  const delMut = useMutation({
    mutationFn: (id: string) => api(`/ip-allowlist/${id}`, { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['ip-allowlist'] }),
  });

  return (
    <div className="border border-retro-border rounded p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Globe className="w-4 h-4 text-primary-600" />
          <span className="font-pixel text-[8px] text-primary-500">IP ALLOWLIST</span>
          <span className="font-mono text-[9px] text-primary-800">{rules.length > 0 ? `${rules.length} rules` : 'No restrictions'}</span>
        </div>
        <button onClick={() => setAdding(!adding)}
          className="flex items-center gap-1 font-pixel text-[6px] text-primary-700 hover:text-primary-crt border border-retro-border px-2 py-1 rounded">
          <Plus className="w-2.5 h-2.5" /> ADD RULE
        </button>
      </div>

      {rules.length === 0 && !adding && (
        <div className="py-4 text-center font-pixel text-[7px] text-primary-800">
          No IP restrictions. All IPs are allowed.
        </div>
      )}

      {rules.map((r: any) => {
        const expired = r.expiresAt && new Date(r.expiresAt) < new Date();
        return (
          <div key={r.id} className={`flex items-center gap-3 px-3 py-2 rounded border ${expired ? 'border-retro-border opacity-40' : 'border-retro-border'}`}>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm text-primary-400">{r.cidr}</span>
                {expired && <span className="font-pixel text-[5px] text-red-400 border border-red-800 px-1 rounded">EXPIRED</span>}
              </div>
              <div className="font-pixel text-[6px] text-primary-700 mt-0.5">{r.label} · Added {fmtDay(r.createdAt)}</div>
            </div>
            <button onClick={() => delMut.mutate(r.id)} className="text-primary-800 hover:text-red-400">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}

      {adding && (
        <div className="border border-primary-700/40 rounded p-3 space-y-2 animate-slide-down">
          <div className="flex gap-2">
            <input value={cidr} onChange={e => setCidr(e.target.value)} placeholder="203.0.113.0/24 or IP"
              className="flex-1 px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none" />
            <input value={label} onChange={e => setLabel(e.target.value)} placeholder="Label (e.g. Office)"
              className="flex-1 px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none" />
          </div>
          <div className="flex gap-2">
            <button onClick={() => addMut.mutate()} disabled={!cidr || !label || addMut.isPending}
              className="px-4 py-1.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
              {addMut.isPending ? 'ADDING...' : 'ADD RULE'}
            </button>
            <button onClick={() => setAdding(false)} className="px-3 py-1.5 border border-retro-border rounded font-pixel text-[7px] text-primary-800">CANCEL</button>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Sessions Panel ────────────────────────────────────────────────────────────
function SessionsPanel() {
  const qc = useQueryClient();
  const { data: sessions = [] } = useQuery({ queryKey: ['sessions'], queryFn: () => api('/sessions') });
  const [showHistory, setShowHistory] = useState(false);
  const { data: history = [] } = useQuery({
    queryKey: ['login-history'],
    queryFn: () => api('/login-history?limit=20'),
    enabled: showHistory,
  });

  const revokeMut = useMutation({
    mutationFn: (id: string) => api(`/sessions/${id}`, { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sessions'] }),
  });
  const revokeAllMut = useMutation({
    mutationFn: () => api('/sessions', { method: 'DELETE' }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['sessions'] }),
  });

  const activeSessions = sessions.filter((s: any) => s.isActive);

  return (
    <div className="border border-retro-border rounded p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Monitor className="w-4 h-4 text-primary-600" />
          <span className="font-pixel text-[8px] text-primary-500">ACTIVE SESSIONS</span>
          <span className="font-pixel text-[6px] text-primary-700 border border-primary-700 px-1.5 py-0.5 rounded">{activeSessions.length} ACTIVE</span>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowHistory(!showHistory)}
            className="font-pixel text-[6px] text-primary-700 hover:text-primary-crt border border-retro-border px-2 py-1 rounded">
            {showHistory ? 'HIDE HISTORY' : 'LOGIN HISTORY'}
          </button>
          {activeSessions.length > 1 && (
            <button onClick={() => revokeAllMut.mutate()}
              className="font-pixel text-[6px] text-red-400 hover:text-red-300 border border-red-800 px-2 py-1 rounded">
              REVOKE ALL OTHERS
            </button>
          )}
        </div>
      </div>

      {sessions.map((s: any) => (
        <div key={s.id} className={`flex items-center gap-3 px-3 py-2 rounded border ${
          s.isCurrentSession ? 'border-primary-700 bg-primary-950/20' : 'border-retro-border'
        }`}>
          <Monitor className={`w-4 h-4 ${s.isActive ? 'text-primary-600' : 'text-primary-800'}`} />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="font-pixel text-[7px] text-primary-400">{s.deviceName ?? 'Unknown Device'}</span>
              {s.isCurrentSession && (
                <span className="font-pixel text-[5px] text-green-400 border border-green-800 px-1.5 py-0.5 rounded">CURRENT</span>
              )}
              {!s.isActive && (
                <span className="font-pixel text-[5px] text-primary-800 border border-retro-border px-1 rounded">REVOKED</span>
              )}
            </div>
            <div className="font-mono text-[9px] text-primary-700 mt-0.5">
              {s.browser} · {s.ip} · {fmtDate(s.lastActiveAt)}
            </div>
          </div>
          {s.isActive && !s.isCurrentSession && (
            <button onClick={() => revokeMut.mutate(s.id)}
              className="font-pixel text-[6px] text-red-400 hover:text-red-300 border border-red-800 px-2 py-1 rounded">
              REVOKE
            </button>
          )}
        </div>
      ))}

      {showHistory && (
        <div className="border-t border-retro-border pt-3 space-y-1">
          <div className="font-pixel text-[6px] text-primary-700 mb-2">LOGIN HISTORY</div>
          {history.map((h: any) => (
            <div key={h.id} className="flex items-center gap-3 px-2 py-1.5">
              <div className={`w-2 h-2 rounded-full ${h.success ? 'bg-green-500' : 'bg-red-500'}`} />
              <div className="flex-1">
                <div className="font-mono text-[9px] text-primary-500">{h.ip} · {h.deviceName}</div>
                {!h.success && <div className="font-pixel text-[5px] text-red-400">{h.failureReason}</div>}
              </div>
              <span className="font-pixel text-[5px] text-primary-800">{fmtDate(h.createdAt)}</span>
              {h.mfaUsed && <span className="font-pixel text-[5px] text-blue-400 border border-blue-800 px-1 rounded">MFA</span>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── DPDPA Panel ───────────────────────────────────────────────────────────────
function DpdpaPanel() {
  const qc = useQueryClient();
  const { data: requests = [] } = useQuery({ queryKey: ['dpdpa-requests'], queryFn: () => api('/dpdpa/requests') });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [notes, setNotes] = useState('');
  const [legalHoldReason, setLegalHoldReason] = useState('');

  const approveMut = useMutation({
    mutationFn: (id: string) => api(`/dpdpa/requests/${id}/approve`, { method: 'POST', body: JSON.stringify({ notes }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['dpdpa-requests'] }); setSelectedId(null); },
  });
  const rejectMut = useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) => api(`/dpdpa/requests/${id}/reject`, { method: 'POST', body: JSON.stringify({ reason }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['dpdpa-requests'] }); setSelectedId(null); },
  });
  const holdMut = useMutation({
    mutationFn: ({ id, hold }: { id: string; hold: boolean }) =>
      api(`/dpdpa/requests/${id}/legal-hold`, { method: 'PATCH', body: JSON.stringify({ hold, reason: legalHoldReason }) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['dpdpa-requests'] }); setLegalHoldReason(''); },
  });

  const STATUS_COLORS: Record<string, string> = {
    pending: 'text-amber-400 border-amber-800',
    under_review: 'text-blue-400 border-blue-800',
    approved: 'text-green-400 border-green-800',
    completed: 'text-primary-600 border-retro-border',
    rejected: 'text-red-400 border-red-800',
    expired: 'text-primary-800 border-retro-border',
  };

  const TYPE_LABELS: Record<string, string> = { export: 'Data Export', deletion: 'Deletion', correction: 'Correction' };

  const slaWarning = (req: any) => {
    const deadline = new Date(req.createdAt);
    deadline.setDate(deadline.getDate() + 30);
    const daysLeft = Math.ceil((deadline.getTime() - Date.now()) / 86_400_000);
    return daysLeft <= 5 && ['pending','under_review'].includes(req.status) ? daysLeft : null;
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="font-pixel text-[8px] text-primary-500">DPDPA REQUESTS</div>
        <span className="font-mono text-[9px] text-primary-700">30-day SLA under DPDPA 2023</span>
      </div>

      {requests.length === 0 && (
        <div className="py-8 text-center font-pixel text-[7px] text-primary-800">No pending data requests.</div>
      )}

      {requests.map((r: any) => {
        const daysLeft = slaWarning(r);
        const sel = selectedId === r.id;
        return (
          <div key={r.id} className={`border rounded p-3 space-y-2 ${r.isLegalHold ? 'border-amber-800/60' : 'border-retro-border'}`}>
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-pixel text-[8px] text-primary-400">{TYPE_LABELS[r.requestType] ?? r.requestType}</span>
                  <span className={`font-pixel text-[5px] border px-1.5 py-0.5 rounded ${STATUS_COLORS[r.status] ?? ''}`}>{r.status.toUpperCase()}</span>
                  {r.isLegalHold && (
                    <span className="font-pixel text-[5px] text-amber-400 border border-amber-800 px-1.5 py-0.5 rounded">⚠ LEGAL HOLD</span>
                  )}
                </div>
                <div className="font-mono text-[9px] text-primary-700 mt-0.5">
                  {r.requester?.firstName} {r.requester?.lastName} · {r.requester?.employeeCode}
                </div>
                <div className="font-pixel text-[5px] text-primary-800 mt-0.5">Submitted: {fmtDay(r.createdAt)}</div>
              </div>
              <div className="flex flex-col items-end gap-1">
                {daysLeft !== null && daysLeft <= 3 && (
                  <div className="flex items-center gap-1">
                    <AlertTriangle className="w-3 h-3 text-red-400" />
                    <span className="font-pixel text-[5px] text-red-400">{daysLeft}d SLA!</span>
                  </div>
                )}
                {['pending','under_review'].includes(r.status) && !r.isLegalHold && (
                  <button onClick={() => setSelectedId(sel ? null : r.id)}
                    className="font-pixel text-[6px] text-primary-700 hover:text-primary-crt border border-retro-border px-2 py-1 rounded">
                    {sel ? 'CANCEL' : 'REVIEW'}
                  </button>
                )}
              </div>
            </div>

            {r.reason && <div className="font-mono text-[9px] text-primary-700 italic">"{r.reason}"</div>}

            {/* Download link for completed export */}
            {r.requestType === 'export' && r.downloadToken && r.status === 'completed' && (
              <div className="flex items-center gap-2 px-2 py-1.5 bg-green-950/20 border border-green-800/50 rounded">
                <FileDown className="w-3 h-3 text-green-400" />
                <span className="font-mono text-[9px] text-green-400">
                  Secure download ready · {r.downloadCount}/{r.maxDownloads} uses · Expires {fmtDay(r.downloadExpiresAt)}
                </span>
              </div>
            )}

            {/* Review actions */}
            {sel && (
              <div className="border-t border-retro-border pt-2 space-y-2 animate-slide-down">
                <textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Admin notes (optional)..."
                  className="w-full px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-[10px] text-primary-500 focus:border-primary-700 focus:outline-none resize-none" />
                <div className="flex gap-2">
                  <button onClick={() => approveMut.mutate(r.id)} disabled={approveMut.isPending}
                    className="flex items-center gap-1 px-3 py-1.5 bg-green-950 border border-green-700 rounded font-pixel text-[6px] text-green-300 hover:bg-green-900 disabled:opacity-40">
                    <Check className="w-2.5 h-2.5" /> APPROVE
                  </button>
                  <button onClick={() => rejectMut.mutate({ id: r.id, reason: notes })} disabled={rejectMut.isPending}
                    className="flex items-center gap-1 px-3 py-1.5 bg-red-950 border border-red-800 rounded font-pixel text-[6px] text-red-300 hover:bg-red-900 disabled:opacity-40">
                    <X className="w-2.5 h-2.5" /> REJECT
                  </button>
                  <div className="flex-1" />
                  {!r.isLegalHold ? (
                    <div className="flex items-center gap-1">
                      <input value={legalHoldReason} onChange={e => setLegalHoldReason(e.target.value)}
                        placeholder="Legal hold reason..."
                        className="px-2 py-1 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-500 focus:border-primary-700 focus:outline-none w-36" />
                      <button onClick={() => holdMut.mutate({ id: r.id, hold: true })} disabled={!legalHoldReason || holdMut.isPending}
                        className="px-2 py-1.5 border border-amber-800 rounded font-pixel text-[5px] text-amber-400 hover:bg-amber-950/20 disabled:opacity-40">
                        LEGAL HOLD
                      </button>
                    </div>
                  ) : (
                    <button onClick={() => holdMut.mutate({ id: r.id, hold: false })}
                      className="px-2 py-1.5 border border-amber-800 rounded font-pixel text-[5px] text-amber-400 hover:bg-amber-950/20">
                      RELEASE HOLD
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// MAIN SECURITY PAGE
// ════════════════════════════════════════════════════════════════════════════════

export function SecurityAdminPage() {
  const [tab, setTab] = useState<'controls' | 'dpdpa'>('controls');

  return (
    <div className="space-y-4 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-pixel text-[9px] text-primary-500">SECURITY & COMPLIANCE</div>
          <div className="font-mono text-xs text-primary-700 mt-0.5">
            MFA · IP Allowlist · Sessions · DPDPA 2023 · Consent
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-green-400" />
          <span className="font-pixel text-[6px] text-green-400">COMPLIANT</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-retro-border">
        {[
          { id: 'controls', label: 'SECURITY CONTROLS', icon: Shield },
          { id: 'dpdpa', label: 'DPDPA WORKFLOW', icon: FileDown },
        ].map(t => (
          <button key={t.id} onClick={() => setTab(t.id as any)}
            className={`flex items-center gap-1.5 px-4 py-2 font-pixel text-[7px] border-b-2 -mb-px transition-colors ${
              tab === t.id ? 'border-primary-crt text-primary-crt' : 'border-transparent text-primary-700 hover:text-primary-500'
            }`}>
            <t.icon className="w-3 h-3" />{t.label}
          </button>
        ))}
      </div>

      {tab === 'controls' && (
        <div className="space-y-4">
          <MfaPolicyPanel />
          <IpAllowlistPanel />
          <SessionsPanel />
        </div>
      )}

      {tab === 'dpdpa' && <DpdpaPanel />}
    </div>
  );
}
