'use client';
/**
 * Feature Flag Control — Tenant-level beta control + controlled rollout
 * RetroWorks HR v1.0
 */

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Flag, ToggleLeft, ToggleRight, ChevronDown, ChevronUp,
  Users, Percent, Globe, Lock, Plus, X, Edit3, Check,
  AlertTriangle, Beaker, Layers, CheckCircle,
} from 'lucide-react';

const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1/security${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${tok()}`, 'Content-Type': 'application/json', ...((opts?.headers ?? {}) as any) },
  }).then(r => r.json()).then(r => r.data ?? r);

const fmtDate = (d: string | Date) =>
  new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

// ── Category config ───────────────────────────────────────────────────────────
const CAT = {
  beta:         { label: 'Beta',         cls: 'text-blue-400 border-blue-800 bg-blue-950/10',     icon: Beaker },
  experimental: { label: 'Experimental', cls: 'text-amber-400 border-amber-800 bg-amber-950/10',  icon: AlertTriangle },
  ga:           { label: 'GA',           cls: 'text-green-400 border-green-800 bg-green-950/10',  icon: CheckCircle },
  deprecated:   { label: 'Deprecated',   cls: 'text-primary-800 border-retro-border',              icon: X },
} as const;

const STRATEGY_ICON: Record<string, any> = {
  all: Globe, none: Lock, allowlist: Users, denylist: X, percentage: Percent,
};
const STRATEGY_LABEL: Record<string, string> = {
  all: 'All Tenants', none: 'No Tenants', allowlist: 'Allowlist',
  denylist: 'Denylist', percentage: 'Percentage Rollout',
};

// ── Toggle switch ─────────────────────────────────────────────────────────────
function Toggle({ checked, onChange, disabled }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean }) {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative inline-flex w-10 h-5 rounded-full transition-colors ${
        checked ? 'bg-primary-700' : 'bg-retro-border'
      } ${disabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`}
    >
      <div className={`w-4 h-4 rounded-full m-0.5 transition-transform ${
        checked ? 'translate-x-5 bg-primary-crt' : 'translate-x-0 bg-primary-800'
      }`} />
    </button>
  );
}

// ── Rollout bar ───────────────────────────────────────────────────────────────
function RolloutBar({ pct }: { pct: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 h-2 bg-retro-bg rounded overflow-hidden">
        <div
          className="h-full bg-primary-700 rounded transition-all"
          style={{ width: `${pct}%` }}
        />
      </div>
      <span className="font-pixel text-[8px] text-primary-500 w-8 text-right">{pct}%</span>
    </div>
  );
}

// ── Global flag editor (super-admin) ──────────────────────────────────────────
function GlobalFlagEditor({ flag, onClose }: { flag: any; onClose: () => void }) {
  const qc = useQueryClient();
  const [form, setForm] = useState({
    globalEnabled: flag.globalEnabled ?? true,
    rolloutStrategy: flag.rolloutStrategy ?? 'all',
    rolloutPercentage: flag.rolloutPercentage ?? 0,
    allowlistTenantIds: (flag.allowlistTenantIds ?? []).join(', '),
    denylistTenantIds: (flag.denylistTenantIds ?? []).join(', '),
  });

  const saveMut = useMutation({
    mutationFn: () => api(`/feature-flags/${flag.key}`, {
      method: 'PUT',
      body: JSON.stringify({
        globalEnabled: form.globalEnabled,
        rolloutStrategy: form.rolloutStrategy,
        rolloutPercentage: form.rolloutPercentage,
        allowlistTenantIds: form.allowlistTenantIds.split(',').map((s: string) => s.trim()).filter(Boolean),
        denylistTenantIds: form.denylistTenantIds.split(',').map((s: string) => s.trim()).filter(Boolean),
      }),
    }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['feature-flags'] }); onClose(); },
  });

  return (
    <div className="border border-primary-700/50 rounded p-4 space-y-3 mt-2 animate-slide-down bg-retro-bg-secondary/20">
      <div className="font-pixel text-[6px] text-primary-600 mb-1">GLOBAL CONFIGURATION</div>

      {/* Global kill switch */}
      <div className="flex items-center gap-3">
        <Toggle checked={form.globalEnabled} onChange={v => setForm(f => ({ ...f, globalEnabled: v }))} />
        <span className="font-pixel text-[6px] text-primary-700">GLOBALLY ENABLED</span>
      </div>

      {/* Rollout strategy */}
      <div>
        <label className="font-pixel text-[6px] text-primary-700 block mb-1">ROLLOUT STRATEGY</label>
        <div className="flex flex-wrap gap-1">
          {Object.keys(STRATEGY_LABEL).map(s => (
            <button key={s}
              onClick={() => setForm(f => ({ ...f, rolloutStrategy: s }))}
              className={`font-pixel text-[6px] px-2 py-1 rounded border transition-all ${
                form.rolloutStrategy === s
                  ? 'border-primary-crt bg-primary-950 text-primary-crt'
                  : 'border-retro-border text-primary-800 hover:border-primary-700'
              }`}>
              {STRATEGY_LABEL[s]}
            </button>
          ))}
        </div>
      </div>

      {form.rolloutStrategy === 'percentage' && (
        <div>
          <label className="font-pixel text-[6px] text-primary-700 block mb-1">ROLLOUT % ({form.rolloutPercentage}%)</label>
          <input type="range" min={0} max={100} value={form.rolloutPercentage}
            onChange={e => setForm(f => ({ ...f, rolloutPercentage: parseInt(e.target.value) }))}
            className="w-full accent-green-500" />
          <RolloutBar pct={form.rolloutPercentage} />
        </div>
      )}

      {form.rolloutStrategy === 'allowlist' && (
        <div>
          <label className="font-pixel text-[6px] text-primary-700 block mb-1">ALLOWED TENANT IDs (comma-separated)</label>
          <input value={form.allowlistTenantIds} onChange={e => setForm(f => ({ ...f, allowlistTenantIds: e.target.value }))}
            placeholder="tenant-abc, tenant-xyz"
            className="w-full px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-[10px] text-primary-500 focus:border-primary-700 focus:outline-none" />
        </div>
      )}

      {form.rolloutStrategy === 'denylist' && (
        <div>
          <label className="font-pixel text-[6px] text-primary-700 block mb-1">BLOCKED TENANT IDs (comma-separated)</label>
          <input value={form.denylistTenantIds} onChange={e => setForm(f => ({ ...f, denylistTenantIds: e.target.value }))}
            placeholder="tenant-bad, tenant-old"
            className="w-full px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-[10px] text-primary-500 focus:border-primary-700 focus:outline-none" />
        </div>
      )}

      <div className="flex gap-2 pt-1">
        <button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}
          className="flex items-center gap-1 px-4 py-1.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
          <Check className="w-2.5 h-2.5" />{saveMut.isPending ? 'SAVING...' : 'SAVE'}
        </button>
        <button onClick={onClose} className="px-3 py-1.5 border border-retro-border rounded font-pixel text-[7px] text-primary-800 hover:text-primary-600">CANCEL</button>
      </div>
    </div>
  );
}

// ── Tenant override form ──────────────────────────────────────────────────────
function TenantOverrideForm({
  flagKey, existing, onClose,
}: { flagKey: string; existing: any; onClose: () => void }) {
  const qc = useQueryClient();
  const [enabled, setEnabled] = useState(existing?.enabled ?? false);
  const [reason, setReason] = useState(existing?.reason ?? '');

  const saveMut = useMutation({
    mutationFn: () => api(`/feature-flags/${flagKey}/tenant-override`, {
      method: 'PUT',
      body: JSON.stringify({ enabled, reason }),
    }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['tenant-flags'] }); onClose(); },
  });

  const delMut = useMutation({
    mutationFn: () => api(`/feature-flags/${flagKey}/tenant-override`, { method: 'DELETE' }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['tenant-flags'] }); onClose(); },
  });

  return (
    <div className="border border-primary-700/40 rounded p-3 space-y-2 mt-1.5 animate-slide-down bg-retro-bg-secondary/20">
      <div className="flex items-center gap-3">
        <Toggle checked={enabled} onChange={setEnabled} />
        <span className="font-pixel text-[6px] text-primary-700">FORCE {enabled ? 'ENABLED' : 'DISABLED'} FOR THIS TENANT</span>
      </div>
      <input value={reason} onChange={e => setReason(e.target.value)}
        placeholder="Reason for override..."
        className="w-full px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-[10px] text-primary-500 focus:border-primary-700 focus:outline-none" />
      <div className="flex gap-2">
        <button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}
          className="px-3 py-1.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[6px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
          {saveMut.isPending ? '...' : 'SAVE OVERRIDE'}
        </button>
        {existing && (
          <button onClick={() => delMut.mutate()}
            className="px-3 py-1.5 border border-red-800 rounded font-pixel text-[6px] text-red-400 hover:bg-red-950/20">
            CLEAR OVERRIDE
          </button>
        )}
        <button onClick={onClose} className="px-3 py-1.5 border border-retro-border rounded font-pixel text-[6px] text-primary-800">CANCEL</button>
      </div>
    </div>
  );
}

// ── Flag row ──────────────────────────────────────────────────────────────────
function FlagRow({ flag, isSuperAdmin }: { flag: any; isSuperAdmin: boolean }) {
  const [showGlobal, setShowGlobal] = useState(false);
  const [showOverride, setShowOverride] = useState(false);

  const catMeta = CAT[flag.category as keyof typeof CAT] ?? CAT.beta;
  const CatIcon = catMeta.icon;
  const StrategyIcon = STRATEGY_ICON[flag.rolloutStrategy] ?? Globe;

  const effectiveEnabled = flag.tenantEnabled ?? flag.globalEnabled;
  const hasOverride = !!flag.override;

  return (
    <div className={`border rounded p-3 space-y-0.5 ${
      hasOverride ? 'border-primary-700/40' : 'border-retro-border'
    }`}>
      {/* Main row */}
      <div className="flex items-center gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-pixel text-[8px] text-primary-400">{flag.name}</span>
            <span className={`font-pixel text-[5px] border px-1.5 py-0.5 rounded ${catMeta.cls}`}>
              <CatIcon className="w-2 h-2 inline-block mr-0.5" />{catMeta.label}
            </span>
            {hasOverride && (
              <span className="font-pixel text-[5px] text-primary-crt border border-primary-700 px-1.5 py-0.5 rounded">
                TENANT OVERRIDE
              </span>
            )}
            {flag.version && (
              <span className="font-pixel text-[5px] text-primary-800">v{flag.version}</span>
            )}
          </div>
          <div className="font-mono text-[9px] text-primary-700 mt-0.5 truncate">
            {flag.description ?? flag.key}
          </div>
        </div>

        {/* Strategy badge */}
        <div className="flex items-center gap-1 shrink-0">
          <StrategyIcon className="w-3 h-3 text-primary-700" />
          <span className="font-pixel text-[5px] text-primary-800 hidden sm:inline">
            {STRATEGY_LABEL[flag.rolloutStrategy] ?? flag.rolloutStrategy}
          </span>
          {flag.rolloutStrategy === 'percentage' && (
            <span className="font-pixel text-[6px] text-primary-600">({flag.rolloutPercentage ?? 0}%)</span>
          )}
        </div>

        {/* Effective status */}
        <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${
          effectiveEnabled ? 'bg-green-500 shadow-[0_0_6px_rgba(34,197,94,0.6)]' : 'bg-primary-800'
        }`} />

        {/* Actions */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={() => { setShowOverride(!showOverride); setShowGlobal(false); }}
            className="font-pixel text-[5px] text-primary-700 hover:text-primary-crt border border-retro-border px-1.5 py-1 rounded"
          >
            {showOverride ? 'CLOSE' : 'OVERRIDE'}
          </button>
          {isSuperAdmin && (
            <button
              onClick={() => { setShowGlobal(!showGlobal); setShowOverride(false); }}
              className="font-pixel text-[5px] text-primary-700 hover:text-primary-crt border border-retro-border px-1.5 py-1 rounded"
            >
              <Edit3 className="w-2.5 h-2.5" />
            </button>
          )}
        </div>
      </div>

      {/* Percentage rollout bar */}
      {flag.rolloutStrategy === 'percentage' && !showGlobal && !showOverride && (
        <div className="pt-1">
          <RolloutBar pct={flag.rolloutPercentage ?? 0} />
        </div>
      )}

      {/* Expanded panels */}
      {showGlobal && isSuperAdmin && (
        <GlobalFlagEditor flag={flag} onClose={() => setShowGlobal(false)} />
      )}
      {showOverride && (
        <TenantOverrideForm
          flagKey={flag.key}
          existing={flag.override}
          onClose={() => setShowOverride(false)}
        />
      )}
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════════════
// MAIN FEATURE FLAGS PAGE
// ════════════════════════════════════════════════════════════════════════════════

export function FeatureFlagsPage({ isSuperAdmin = false }: { isSuperAdmin?: boolean }) {
  const [filter, setFilter] = useState<'all' | 'beta' | 'experimental' | 'ga' | 'deprecated'>('all');
  const [search, setSearch] = useState('');

  const queryKey = isSuperAdmin ? ['feature-flags'] : ['tenant-flags'];
  const queryFn = isSuperAdmin
    ? () => api('/feature-flags')
    : () => api('/feature-flags/tenant');

  const { data: flags = [], isLoading } = useQuery({ queryKey, queryFn });

  const filtered = flags.filter((f: any) => {
    if (filter !== 'all' && f.category !== filter) return false;
    if (search && !f.name.toLowerCase().includes(search.toLowerCase()) &&
        !f.key.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const countByCategory = flags.reduce((acc: any, f: any) => {
    acc[f.category] = (acc[f.category] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="font-pixel text-[9px] text-primary-500">FEATURE FLAGS</div>
          <div className="font-mono text-xs text-primary-700 mt-0.5">
            Beta control · Controlled rollout · Tenant overrides
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Flag className="w-4 h-4 text-primary-600" />
          <span className="font-pixel text-[6px] text-primary-700">{flags.length} FLAGS</span>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-4 gap-2">
        {(['beta', 'experimental', 'ga', 'deprecated'] as const).map(cat => {
          const meta = CAT[cat];
          const count = countByCategory[cat] ?? 0;
          return (
            <button key={cat}
              onClick={() => setFilter(filter === cat ? 'all' : cat)}
              className={`border rounded p-3 text-center transition-colors ${
                filter === cat ? 'border-primary-700 bg-primary-950/20' : 'border-retro-border hover:border-primary-700/50'
              }`}>
              <div className={`font-pixel text-[18px] ${meta.cls.split(' ')[0]}`}>{count}</div>
              <div className="font-pixel text-[5px] text-primary-800 mt-0.5">{meta.label.toUpperCase()}</div>
            </button>
          );
        })}
      </div>

      {/* Search */}
      <input value={search} onChange={e => setSearch(e.target.value)}
        placeholder="Search flags..."
        className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none" />

      {/* Flag list */}
      {isLoading && (
        <div className="py-8 text-center font-pixel text-[7px] text-primary-800 animate-pulse">LOADING FLAGS...</div>
      )}

      <div className="space-y-2">
        {filtered.map((f: any) => (
          <FlagRow key={f.key} flag={f} isSuperAdmin={isSuperAdmin} />
        ))}
        {!isLoading && filtered.length === 0 && (
          <div className="py-8 text-center font-pixel text-[7px] text-primary-800">
            {search ? `No flags matching "${search}"` : 'No flags found.'}
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 pt-2 border-t border-retro-border">
        <span className="font-pixel text-[5px] text-primary-800">
          <span className="text-green-500">●</span> FLAG ENABLED FOR TENANT
        </span>
        <span className="font-pixel text-[5px] text-primary-800">
          <span className="text-primary-700">●</span> FLAG DISABLED
        </span>
        <span className="font-pixel text-[5px] text-primary-800">
          TENANT OVERRIDE = ignores global rollout
        </span>
      </div>
    </div>
  );
}
