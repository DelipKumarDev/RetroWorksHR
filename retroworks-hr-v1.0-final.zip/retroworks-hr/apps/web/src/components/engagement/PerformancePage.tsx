'use client';
/**
 * Performance Cycle — Goals · Self Review · Manager Review · 9-Box · Calibration
 * Lightweight, no enterprise bloat. One screen per phase.
 */

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Target, Star, ChevronRight, Plus, Check, TrendingUp,
  Award, Users, Edit3, X, BarChart2,
} from 'lucide-react';

// ── API ────────────────────────────────────────────────────────────────────────
const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1/engagement${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${tok()}`, 'Content-Type': 'application/json', ...((opts?.headers ?? {}) as any) },
  }).then(r => r.json()).then(r => r.data ?? r);

// ── 9-box labels & colors ─────────────────────────────────────────────────────
const NINE_BOX: Record<string, { label: string; color: string; bg: string }> = {
  '3-1': { label: 'High Professional', color: '#4ade80', bg: 'rgba(74,222,128,0.08)' },
  '3-2': { label: 'High Performer',    color: '#22c55e', bg: 'rgba(34,197,94,0.12)' },
  '3-3': { label: 'Star Performer',    color: '#00ff41', bg: 'rgba(0,255,65,0.15)'  },
  '2-1': { label: 'Core Player',       color: '#60a5fa', bg: 'rgba(96,165,250,0.08)' },
  '2-2': { label: 'Key Player',        color: '#93c5fd', bg: 'rgba(147,197,253,0.10)' },
  '2-3': { label: 'Top Talent',        color: '#a78bfa', bg: 'rgba(167,139,250,0.12)' },
  '1-1': { label: 'Inconsistent',      color: '#f87171', bg: 'rgba(248,113,113,0.06)' },
  '1-2': { label: 'Rough Diamond',     color: '#fb923c', bg: 'rgba(251,146,60,0.08)' },
  '1-3': { label: 'Future Star',       color: '#fbbf24', bg: 'rgba(251,191,36,0.10)' },
};

const PROMO_LABELS: Record<string, { l: string; c: string }> = {
  ready_now:     { l: 'Ready Now',      c: 'text-green-400 border-green-800' },
  ready_in_6m:   { l: 'Ready in 6M',   c: 'text-blue-400 border-blue-800' },
  ready_in_12m:  { l: 'Ready in 12M',  c: 'text-amber-400 border-amber-800' },
  not_ready:     { l: 'Not Ready',      c: 'text-primary-700 border-retro-border' },
};

// ── Star rating ────────────────────────────────────────────────────────────────
function StarRating({ value, onChange, max = 5 }: { value: number; onChange?: (v: number) => void; max?: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: max }, (_, i) => i + 1).map(n => (
        <button key={n} onClick={() => onChange?.(n)} disabled={!onChange}
          className={`transition-colors ${onChange ? 'cursor-pointer' : 'cursor-default'}`}>
          <Star className={`w-4 h-4 ${n <= value ? 'fill-amber-400 text-amber-400' : 'text-primary-800'}`} />
        </button>
      ))}
    </div>
  );
}

// ── Progress bar ───────────────────────────────────────────────────────────────
function ProgressBar({ pct, color = '#22c55e' }: { pct: number; color?: string }) {
  return (
    <div className="h-1.5 bg-retro-bg rounded overflow-hidden">
      <div className="h-full rounded transition-all" style={{ width: `${pct}%`, backgroundColor: color }} />
    </div>
  );
}

// ── GOALS PANEL ───────────────────────────────────────────────────────────────
function GoalsPanel({ cycleId, readOnly = false }: { cycleId: string; readOnly?: boolean }) {
  const qc = useQueryClient();
  const { data: review, isLoading } = useQuery({
    queryKey: ['my-review', cycleId],
    queryFn: () => api(`/performance/cycles/${cycleId}/my-review`),
  });

  const [newGoal, setNewGoal] = useState({ title: '', metric: '', weight: 20, dueDate: '' });
  const [adding, setAdding] = useState(false);

  const addMut = useMutation({
    mutationFn: () => api(`/performance/cycles/${cycleId}/goals`, {
      method: 'POST',
      body: JSON.stringify(newGoal),
    }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['my-review', cycleId] });
      setAdding(false);
      setNewGoal({ title: '', metric: '', weight: 20, dueDate: '' });
    },
  });

  const goals = review?.goals ?? [];
  const totalWeight = goals.reduce((s: number, g: any) => s + (g.weight ?? 0), 0);

  if (isLoading) return <div className="font-pixel text-[8px] text-primary-800 py-8 text-center animate-pulse">LOADING...</div>;

  return (
    <div className="space-y-3">
      {/* Weight meter */}
      <div className="flex items-center gap-3">
        <span className="font-pixel text-[6px] text-primary-700">GOAL WEIGHT</span>
        <div className="flex-1"><ProgressBar pct={totalWeight} color={totalWeight > 100 ? '#f87171' : totalWeight === 100 ? '#00ff41' : '#22c55e'} /></div>
        <span className={`font-pixel text-[8px] ${totalWeight === 100 ? 'text-primary-crt' : totalWeight > 100 ? 'text-red-400' : 'text-primary-700'}`}>{totalWeight}%</span>
      </div>

      {/* Goals list */}
      {goals.map((g: any) => (
        <div key={g.id} className="border border-retro-border rounded p-3 space-y-2">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1">
              <div className="font-pixel text-[8px] text-primary-400">{g.title}</div>
              {g.metric && <div className="font-mono text-[9px] text-primary-700 mt-0.5">{g.metric}</div>}
            </div>
            <span className="font-pixel text-[7px] text-primary-600 shrink-0">{g.weight}%</span>
          </div>
          <div className="space-y-1">
            <ProgressBar pct={g.progress ?? 0} />
            <div className="flex justify-between font-pixel text-[5px] text-primary-800">
              <span>PROGRESS</span><span>{g.progress ?? 0}%</span>
            </div>
          </div>
          {(g.selfRating || g.managerRating) && (
            <div className="flex gap-4">
              {g.selfRating && <div className="flex items-center gap-1"><span className="font-pixel text-[5px] text-primary-800">SELF</span><StarRating value={g.selfRating} /></div>}
              {g.managerRating && <div className="flex items-center gap-1"><span className="font-pixel text-[5px] text-primary-800">MGR</span><StarRating value={g.managerRating} /></div>}
            </div>
          )}
        </div>
      ))}

      {goals.length === 0 && !adding && (
        <div className="py-8 text-center font-pixel text-[7px] text-primary-800">No goals set yet.</div>
      )}

      {/* Add goal form */}
      {!readOnly && adding && (
        <div className="border border-primary-700/50 rounded p-3 space-y-3 animate-slide-up">
          <input value={newGoal.title} onChange={e => setNewGoal(g => ({ ...g, title: e.target.value }))}
            placeholder="Goal title..."
            className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none" />
          <input value={newGoal.metric} onChange={e => setNewGoal(g => ({ ...g, metric: e.target.value }))}
            placeholder="Success metric (e.g. Deliver X features)"
            className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none" />
          <div className="flex gap-3">
            <div className="flex-1">
              <label className="font-pixel text-[6px] text-primary-800 block mb-1">WEIGHT %</label>
              <input type="number" min={5} max={100} value={newGoal.weight}
                onChange={e => setNewGoal(g => ({ ...g, weight: parseInt(e.target.value) || 0 }))}
                className="w-full px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none" />
            </div>
            <div className="flex-1">
              <label className="font-pixel text-[6px] text-primary-800 block mb-1">DUE DATE</label>
              <input type="date" value={newGoal.dueDate} onChange={e => setNewGoal(g => ({ ...g, dueDate: e.target.value }))}
                className="w-full px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none" />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => addMut.mutate()} disabled={!newGoal.title || addMut.isPending}
              className="px-4 py-1.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
              {addMut.isPending ? 'SAVING...' : 'SAVE GOAL'}
            </button>
            <button onClick={() => setAdding(false)} className="px-4 py-1.5 border border-retro-border rounded font-pixel text-[7px] text-primary-800"><X className="w-3 h-3" /></button>
          </div>
        </div>
      )}

      {!readOnly && !adding && totalWeight < 100 && (
        <button onClick={() => setAdding(true)}
          className="w-full py-2 border border-dashed border-primary-800 rounded font-pixel text-[7px] text-primary-800 hover:border-primary-700 hover:text-primary-600 flex items-center justify-center gap-1">
          <Plus className="w-3 h-3" /> ADD GOAL ({100 - totalWeight}% REMAINING)
        </button>
      )}
    </div>
  );
}

// ── SELF REVIEW FORM ───────────────────────────────────────────────────────────
function SelfReviewForm({ cycleId }: { cycleId: string }) {
  const qc = useQueryClient();
  const { data: review } = useQuery({
    queryKey: ['my-review', cycleId],
    queryFn: () => api(`/performance/cycles/${cycleId}/my-review`),
  });

  const [form, setForm] = useState({
    overallRating: 0, strengths: '', improvements: '',
    goalRatings: [] as Array<{ goalId: string; rating: number }>,
  });

  const submitMut = useMutation({
    mutationFn: () => api(`/performance/cycles/${cycleId}/self-review`, {
      method: 'POST',
      body: JSON.stringify(form),
    }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['my-review', cycleId] }),
  });

  const goals = review?.goals ?? [];

  if (review?.selfSubmittedAt) {
    return (
      <div className="flex flex-col items-center justify-center py-12 space-y-2">
        <Check className="w-10 h-10 text-green-400" />
        <div className="font-pixel text-[8px] text-green-400">SELF REVIEW SUBMITTED</div>
        <div className="font-mono text-xs text-primary-700">Awaiting manager review.</div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <label className="font-pixel text-[6px] text-primary-700 block mb-2">OVERALL SELF RATING</label>
        <StarRating value={form.overallRating} onChange={v => setForm(f => ({ ...f, overallRating: v }))} />
      </div>

      {goals.length > 0 && (
        <div className="space-y-2">
          <label className="font-pixel text-[6px] text-primary-700">RATE YOUR GOALS</label>
          {goals.map((g: any) => {
            const gr = form.goalRatings.find(r => r.goalId === g.id);
            return (
              <div key={g.id} className="flex items-center justify-between border border-retro-border rounded px-3 py-2">
                <span className="font-mono text-[10px] text-primary-500 flex-1 mr-4">{g.title}</span>
                <StarRating value={gr?.rating ?? 0} onChange={v => {
                  setForm(f => ({
                    ...f,
                    goalRatings: [...f.goalRatings.filter(r => r.goalId !== g.id), { goalId: g.id, rating: v }],
                  }));
                }} />
              </div>
            );
          })}
        </div>
      )}

      <div>
        <label className="font-pixel text-[6px] text-primary-700 block mb-1">YOUR STRENGTHS</label>
        <textarea rows={3} value={form.strengths} onChange={e => setForm(f => ({ ...f, strengths: e.target.value }))}
          className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none resize-none"
          placeholder="What went well this cycle?" />
      </div>

      <div>
        <label className="font-pixel text-[6px] text-primary-700 block mb-1">AREAS FOR GROWTH</label>
        <textarea rows={3} value={form.improvements} onChange={e => setForm(f => ({ ...f, improvements: e.target.value }))}
          className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none resize-none"
          placeholder="Where do you want to grow?" />
      </div>

      <button onClick={() => submitMut.mutate()}
        disabled={form.overallRating === 0 || !form.strengths || submitMut.isPending}
        className="flex items-center gap-2 px-5 py-2.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
        <Check className="w-3 h-3" />{submitMut.isPending ? 'SUBMITTING...' : 'SUBMIT SELF REVIEW'}
      </button>
    </div>
  );
}

// ── 9-BOX MATRIX ──────────────────────────────────────────────────────────────
function NineBoxMatrix({ data }: { data: { nineBox: Record<string, Array<{ id: string; name: string; rating: number }>> } }) {
  const [hover, setHover] = useState<string | null>(null);

  return (
    <div className="space-y-2">
      {/* Y axis label */}
      <div className="flex items-center gap-2 mb-1">
        <div className="font-pixel text-[6px] text-primary-800 writing-vertical rotate-180" style={{ writingMode: 'vertical-lr' }}>PERFORMANCE ↑</div>
        <div className="flex-1">
          <div className="grid grid-cols-3 gap-1">
            {[3, 2, 1].map(perf =>
              [1, 2, 3].map(pot => {
                const key = `${perf}-${pot}`;
                const meta = NINE_BOX[key]!;
                const employees = data.nineBox[key] ?? [];
                const isHovered = hover === key;
                return (
                  <div
                    key={key}
                    className="relative rounded border transition-all cursor-default min-h-[72px] p-2"
                    style={{
                      borderColor: isHovered ? meta.color : '#1a2e1a',
                      background: isHovered ? meta.bg : 'rgba(13,26,13,0.5)',
                    }}
                    onMouseEnter={() => setHover(key)}
                    onMouseLeave={() => setHover(null)}
                  >
                    <div className="font-pixel text-[5.5px] mb-1" style={{ color: meta.color }}>{meta.label}</div>
                    <div className="flex flex-wrap gap-1">
                      {employees.slice(0, 6).map(e => (
                        <div key={e.id} title={e.name}
                          className="w-5 h-5 rounded-sm flex items-center justify-center font-pixel text-[5px]"
                          style={{ background: meta.bg, border: `1px solid ${meta.color}40`, color: meta.color }}>
                          {e.name.charAt(0)}
                        </div>
                      ))}
                      {employees.length > 6 && (
                        <div className="w-5 h-5 rounded-sm flex items-center justify-center font-pixel text-[5px] text-primary-800 border border-retro-border">
                          +{employees.length - 6}
                        </div>
                      )}
                    </div>
                    <div className="absolute bottom-1 right-1 font-pixel text-[5px] text-primary-800">{employees.length}</div>
                  </div>
                );
              })
            )}
          </div>
          {/* X axis label */}
          <div className="font-pixel text-[6px] text-primary-800 text-center mt-1">POTENTIAL →</div>
        </div>
      </div>
    </div>
  );
}

// ── CALIBRATION VIEW (HR only) ─────────────────────────────────────────────────
function CalibrationView({ cycleId }: { cycleId: string }) {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ['calibration', cycleId],
    queryFn: () => api(`/performance/cycles/${cycleId}/calibration`),
  });

  const [editId, setEditId] = useState<string | null>(null);
  const [calibForm, setCalibForm] = useState({ calibratedRating: 0, notes: '', performanceAxis: 2 as 1|2|3, potentialAxis: 2 as 1|2|3 });

  const calibMut = useMutation({
    mutationFn: (reviewId: string) => api(`/performance/reviews/${reviewId}/calibrate`, {
      method: 'PATCH',
      body: JSON.stringify(calibForm),
    }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['calibration', cycleId] }); setEditId(null); },
  });

  if (isLoading) return <div className="font-pixel text-[8px] text-primary-800 py-8 text-center animate-pulse">LOADING...</div>;
  if (!data) return null;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-3 mb-2">
        {[
          { l: 'REVIEWED', v: data.totalReviewed, c: 'text-primary-crt' },
          { l: 'PROMOTION READY', v: data.promotionReady?.length ?? 0, c: 'text-amber-400' },
        ].map(s => (
          <div key={s.l} className="border border-retro-border rounded p-3 text-center">
            <div className={`font-pixel text-[18px] ${s.c}`}>{s.v}</div>
            <div className="font-pixel text-[5px] text-primary-800 mt-0.5">{s.l}</div>
          </div>
        ))}
      </div>

      {/* 9-box */}
      <div className="border border-retro-border rounded p-4">
        <div className="font-pixel text-[7px] text-primary-600 mb-3">9-BOX MATRIX</div>
        <NineBoxMatrix data={data} />
      </div>

      {/* Promotion ready */}
      {data.promotionReady?.length > 0 && (
        <div className="border border-amber-900/50 rounded p-4">
          <div className="font-pixel text-[7px] text-amber-400 mb-3 flex items-center gap-2">
            <Award className="w-3 h-3" /> PROMOTION RECOMMENDATIONS
          </div>
          <div className="space-y-1.5">
            {data.promotionReady.map((e: any) => (
              <div key={e.id} className="flex items-center justify-between px-3 py-2 border border-amber-900/30 rounded bg-amber-950/10">
                <div>
                  <div className="font-pixel text-[8px] text-amber-300">{e.name}</div>
                  <div className="font-mono text-[9px] text-amber-700 mt-0.5">{e.designation} · {e.department}</div>
                </div>
                <div className="flex items-center gap-2">
                  <StarRating value={e.rating} />
                  <span className="font-pixel text-[6px] text-amber-400 border border-amber-800 px-2 py-0.5 rounded">READY NOW</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Per-review calibration */}
      <div className="space-y-2">
        <div className="font-pixel text-[7px] text-primary-600">CALIBRATE REVIEWS</div>
        {data.reviews?.map((r: any) => (
          <div key={r.id} className="border border-retro-border rounded p-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="font-pixel text-[8px] text-primary-400">
                  {r.employee?.firstName} {r.employee?.lastName}
                </div>
                <div className="font-mono text-[9px] text-primary-700 mt-0.5">
                  {r.employee?.designation?.name} · MGR: {r.managerOverallRating ?? '—'}/5
                  {r.calibratedRating && ` · CAL: ${r.calibratedRating}/5`}
                </div>
              </div>
              {editId !== r.id ? (
                <button onClick={() => {
                  setEditId(r.id);
                  setCalibForm({ calibratedRating: r.calibratedRating ?? r.managerOverallRating ?? 3, notes: r.calibrationNotes ?? '', performanceAxis: r.performanceAxis ?? 2, potentialAxis: r.potentialAxis ?? 2 });
                }}
                  className="flex items-center gap-1 px-3 py-1.5 border border-retro-border rounded font-pixel text-[6px] text-primary-700 hover:border-primary-700">
                  <Edit3 className="w-2.5 h-2.5" /> CALIBRATE
                </button>
              ) : (
                <button onClick={() => setEditId(null)} className="text-primary-800"><X className="w-3 h-3" /></button>
              )}
            </div>

            {editId === r.id && (
              <div className="mt-3 space-y-3 pt-3 border-t border-retro-border animate-slide-down">
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="font-pixel text-[6px] text-primary-700 block mb-1">FINAL RATING</label>
                    <StarRating value={calibForm.calibratedRating} onChange={v => setCalibForm(f => ({ ...f, calibratedRating: v }))} />
                  </div>
                  <div>
                    <label className="font-pixel text-[6px] text-primary-700 block mb-1">PERFORMANCE (1-3)</label>
                    <div className="flex gap-1">
                      {[1,2,3].map(n => (
                        <button key={n} onClick={() => setCalibForm(f => ({ ...f, performanceAxis: n as 1|2|3 }))}
                          className={`w-7 h-7 rounded border font-pixel text-[8px] ${calibForm.performanceAxis === n ? 'border-primary-crt bg-primary-900 text-primary-crt' : 'border-retro-border text-primary-700'}`}>{n}</button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="font-pixel text-[6px] text-primary-700 block mb-1">POTENTIAL (1-3)</label>
                    <div className="flex gap-1">
                      {[1,2,3].map(n => (
                        <button key={n} onClick={() => setCalibForm(f => ({ ...f, potentialAxis: n as 1|2|3 }))}
                          className={`w-7 h-7 rounded border font-pixel text-[8px] ${calibForm.potentialAxis === n ? 'border-primary-crt bg-primary-900 text-primary-crt' : 'border-retro-border text-primary-700'}`}>{n}</button>
                      ))}
                    </div>
                  </div>
                </div>
                <textarea rows={2} value={calibForm.notes} onChange={e => setCalibForm(f => ({ ...f, notes: e.target.value }))}
                  className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-[10px] text-primary-500 focus:border-primary-700 focus:outline-none resize-none"
                  placeholder="Calibration notes..." />
                <button onClick={() => calibMut.mutate(r.id)} disabled={calibMut.isPending}
                  className="px-4 py-1.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
                  {calibMut.isPending ? 'SAVING...' : 'SAVE CALIBRATION'}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// MAIN PERFORMANCE PAGE
// ══════════════════════════════════════════════════════════════════════════════

export function PerformancePage({ isHR = false, isManager = false }: { isHR?: boolean; isManager?: boolean }) {
  const [tab, setTab] = useState<'goals' | 'self' | 'calibration'>('goals');
  const [activeCycle, setActiveCycle] = useState<string | null>(null);

  const { data: cycles } = useQuery({
    queryKey: ['perf-cycles'],
    queryFn: () => api('/performance/cycles'),
  });

  const current = cycles?.find((c: any) => c.status !== 'complete') ?? cycles?.[0];

  // Auto-select latest active cycle
  if (current && !activeCycle) setActiveCycle(current.id);

  const statusMeta: Record<string, { label: string; cls: string }> = {
    planning:       { label: 'Planning',       cls: 'text-primary-700 border-retro-border' },
    goal_setting:   { label: 'Goal Setting',   cls: 'text-blue-400 border-blue-800' },
    self_review:    { label: 'Self Review',    cls: 'text-amber-400 border-amber-800' },
    manager_review: { label: 'Manager Review', cls: 'text-violet-400 border-violet-800' },
    calibration:    { label: 'Calibration',    cls: 'text-orange-400 border-orange-800' },
    complete:       { label: 'Complete',        cls: 'text-green-400 border-green-800' },
  };

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header + cycle selector */}
      <div className="flex items-start justify-between">
        <div>
          <div className="font-pixel text-[9px] text-primary-500">PERFORMANCE</div>
          <div className="font-mono text-xs text-primary-700 mt-0.5">Goals · Reviews · 9-Box · Calibration</div>
        </div>
        {cycles?.length > 0 && (
          <select value={activeCycle ?? ''} onChange={e => setActiveCycle(e.target.value)}
            className="px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-[10px] text-primary-500 focus:outline-none">
            {cycles.map((c: any) => (
              <option key={c.id} value={c.id}>{c.name} — {c.period}</option>
            ))}
          </select>
        )}
      </div>

      {/* Cycle status bar */}
      {current && (
        <div className="flex items-center gap-2 p-2 border border-retro-border rounded bg-retro-bg-secondary overflow-x-auto">
          {['goal_setting', 'self_review', 'manager_review', 'calibration', 'complete'].map(phase => {
            const steps = ['planning','goal_setting','self_review','manager_review','calibration','complete'];
            const phaseIdx = steps.indexOf(phase);
            const currentIdx = steps.indexOf(current.status);
            const done = currentIdx > phaseIdx;
            const active = current.status === phase;
            return (
              <div key={phase} className="flex items-center gap-2 shrink-0">
                <div className={`flex items-center gap-1.5 px-2 py-1 rounded ${active ? 'bg-primary-950' : ''}`}>
                  <div className={`w-2 h-2 rounded-full ${done ? 'bg-green-500' : active ? 'bg-primary-crt animate-pulse' : 'bg-retro-border'}`} />
                  <span className={`font-pixel text-[6px] ${active ? 'text-primary-crt' : done ? 'text-primary-700' : 'text-primary-800'}`}>
                    {phase.replace('_', ' ').toUpperCase()}
                  </span>
                </div>
                {phase !== 'complete' && <ChevronRight className="w-2.5 h-2.5 text-primary-800 shrink-0" />}
              </div>
            );
          })}
        </div>
      )}

      {!activeCycle && (
        <div className="py-12 text-center font-pixel text-[7px] text-primary-800">
          No performance cycles found.{isHR ? ' Create one to get started.' : ''}
        </div>
      )}

      {activeCycle && (
        <>
          {/* Tab nav */}
          <div className="flex gap-1 border-b border-retro-border">
            {[
              { id: 'goals', label: 'GOALS', icon: Target },
              { id: 'self', label: 'SELF REVIEW', icon: Star },
              ...((isHR || isManager) ? [{ id: 'calibration' as any, label: 'CALIBRATION', icon: BarChart2 }] : []),
            ].map(t => (
              <button key={t.id} onClick={() => setTab(t.id as any)}
                className={`flex items-center gap-1.5 px-4 py-2 font-pixel text-[7px] border-b-2 -mb-px transition-colors ${
                  tab === t.id ? 'border-primary-crt text-primary-crt' : 'border-transparent text-primary-700 hover:text-primary-500'
                }`}>
                <t.icon className="w-3 h-3" />{t.label}
              </button>
            ))}
          </div>

          {/* Tab content */}
          <div className="pt-1">
            {tab === 'goals' && <GoalsPanel cycleId={activeCycle} readOnly={false} />}
            {tab === 'self' && <SelfReviewForm cycleId={activeCycle} />}
            {tab === 'calibration' && (isHR || isManager) && <CalibrationView cycleId={activeCycle} />}
          </div>
        </>
      )}
    </div>
  );
}
