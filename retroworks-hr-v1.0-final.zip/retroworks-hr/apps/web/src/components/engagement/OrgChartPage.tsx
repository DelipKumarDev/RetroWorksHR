'use client';
/**
 * OrgChart — Pixel retro tree renderer
 * Drag to pan · Click to focus subtree · Filter by dept/entity
 * Pixel avatars generated deterministically from name hash
 */

import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronDown, Search, ZoomIn, ZoomOut, Home, Building2, Users, X } from 'lucide-react';

// ── types ──────────────────────────────────────────────────────────────────────
interface OrgNode {
  id: string; name: string; designation?: string; department?: string;
  departmentId?: string; entityId?: string; entityName?: string;
  managerId?: string | null; avatarUrl?: string; status: string;
  x: number; y: number; subtreeWidth: number;
  children?: OrgNode[];
}

// ── design tokens ──────────────────────────────────────────────────────────────
const PALETTES = [
  { bg: '#0d1f12', fg: '#00ff41' }, { bg: '#0d0d1f', fg: '#5b8af5' },
  { bg: '#1f0d12', fg: '#ff4d6d' }, { bg: '#1a0d1f', fg: '#bf5af2' },
  { bg: '#1f1a0d', fg: '#ffd60a' }, { bg: '#0d1f1f', fg: '#00b8d9' },
  { bg: '#1f120d', fg: '#ff9f0a' }, { bg: '#0f1f0d', fg: '#30d158' },
];

const NODE_W = 148;
const NODE_H = 76;

// ── pixel avatar ───────────────────────────────────────────────────────────────
function hashName(name: string): number {
  let h = 0;
  for (let i = 0; i < name.length; i++) { h = (h << 5) - h + name.charCodeAt(i); h |= 0; }
  return Math.abs(h);
}

function PixelAvatar({ name, size = 32 }: { name: string; size?: number }) {
  const seed = hashName(name);
  const palette = PALETTES[seed % PALETTES.length]!;
  const grid: boolean[][] = [];
  for (let r = 0; r < 5; r++) {
    const row: boolean[] = [];
    for (let c = 0; c < 5; c++) {
      const mc = c <= 2 ? c : 4 - c;
      row.push(((seed >> (r * 3 + mc)) & 1) === 1);
    }
    grid.push(row);
  }
  const px = size / 5;
  return (
    <svg width={size} height={size} style={{ imageRendering: 'pixelated', flexShrink: 0 }}>
      <rect width={size} height={size} fill={palette.bg} />
      {grid.map((row, r) =>
        row.map((on, c) => on ? (
          <rect key={`${r}-${c}`} x={c * px} y={r * px} width={px} height={px} fill={palette.fg} />
        ) : null)
      )}
    </svg>
  );
}

// ── canvas tree layout ─────────────────────────────────────────────────────────
function flattenTree(node: OrgNode, depth = 0, out: Array<{ node: OrgNode; depth: number }> = []) {
  out.push({ node, depth });
  (node.children ?? []).forEach(c => flattenTree(c, depth + 1, out));
  return out;
}

function collectEdges(node: OrgNode, edges: Array<{ px: number; py: number; cx: number; cy: number }> = []) {
  (node.children ?? []).forEach(child => {
    edges.push({ px: node.x + NODE_W / 2, py: node.y + NODE_H, cx: child.x + NODE_W / 2, cy: child.y });
    collectEdges(child, edges);
  });
  return edges;
}

// ── single node card (canvas) ──────────────────────────────────────────────────
function drawNode(
  ctx: CanvasRenderingContext2D,
  node: OrgNode,
  ox: number, oy: number,
  scale: number,
  focused: boolean,
  avatarCache: Map<string, HTMLCanvasElement>,
) {
  const x = (node.x + ox) * scale;
  const y = (node.y + oy) * scale;
  const w = NODE_W * scale;
  const h = NODE_H * scale;
  const r = 4 * scale;

  // card bg
  ctx.fillStyle = focused ? '#0d2a0d' : '#0b180b';
  ctx.strokeStyle = focused ? '#00ff41' : '#1a2e1a';
  ctx.lineWidth = (focused ? 1.5 : 1) * scale;
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.fill();
  ctx.stroke();

  // avatar
  const av = avatarCache.get(node.name);
  if (av) {
    const avSize = 28 * scale;
    ctx.drawImage(av, x + 8 * scale, y + h / 2 - avSize / 2, avSize, avSize);
  }

  // text
  const textX = x + 44 * scale;
  ctx.fillStyle = focused ? '#00ff41' : '#4ade80';
  ctx.font = `bold ${9 * scale}px 'Space Mono', monospace`;
  ctx.fillText(truncate(node.name, 14), textX, y + 22 * scale);

  ctx.fillStyle = '#15803d';
  ctx.font = `${7 * scale}px 'Space Mono', monospace`;
  ctx.fillText(truncate(node.designation ?? '', 17), textX, y + 34 * scale);

  ctx.fillStyle = '#166534';
  ctx.font = `${6.5 * scale}px 'Space Mono', monospace`;
  ctx.fillText(truncate(node.department ?? '', 17), textX, y + 45 * scale);

  // entity badge
  if (node.entityName) {
    ctx.fillStyle = '#1a2e1a';
    ctx.fillRect(x + 8 * scale, y + h - 16 * scale, NODE_W * scale - 16 * scale, 12 * scale);
    ctx.fillStyle = '#15803d';
    ctx.font = `${5.5 * scale}px 'Space Mono', monospace`;
    ctx.fillText(truncate(node.entityName, 20), x + 11 * scale, y + h - 7 * scale);
  }
}

function truncate(s: string, n: number) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }

// ── Build pixel avatar canvas ──────────────────────────────────────────────────
function buildAvatarCanvas(name: string, size: number): HTMLCanvasElement {
  const seed = hashName(name);
  const palette = PALETTES[seed % PALETTES.length]!;
  const c = document.createElement('canvas');
  c.width = c.height = size;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = palette.bg;
  ctx.fillRect(0, 0, size, size);
  const px = size / 5;
  for (let r = 0; r < 5; r++) {
    for (let col = 0; col < 5; col++) {
      const mc = col <= 2 ? col : 4 - col;
      if (((seed >> (r * 3 + mc)) & 1) === 1) {
        ctx.fillStyle = palette.fg;
        ctx.fillRect(col * px, r * px, px, px);
      }
    }
  }
  return c;
}

// ── API ────────────────────────────────────────────────────────────────────────
const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string) =>
  fetch(`/api/v1/engagement${path}`, { headers: { Authorization: `Bearer ${tok()}` } })
    .then(r => r.json()).then(r => r.data ?? r);

// ══════════════════════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ══════════════════════════════════════════════════════════════════════════════

export function OrgChartPage() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const avatarCache = useRef<Map<string, HTMLCanvasElement>>(new Map());
  const [deptFilter, setDeptFilter] = useState('');
  const [entityFilter, setEntityFilter] = useState('');
  const [rootNode, setRootNode] = useState('');
  const [search, setSearch] = useState('');
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<OrgNode | null>(null);

  // pan/zoom
  const [offset, setOffset] = useState({ x: 40, y: 40 });
  const [scale, setScale] = useState(1);
  const drag = useRef({ dragging: false, startX: 0, startY: 0, ox: 0, oy: 0 });

  const { data, isLoading } = useQuery({
    queryKey: ['org-chart', deptFilter, entityFilter, rootNode],
    queryFn: () => {
      const p = new URLSearchParams();
      if (deptFilter) p.set('dept', deptFilter);
      if (entityFilter) p.set('entity', entityFilter);
      if (rootNode) p.set('root', rootNode);
      return api(`/org-chart?${p}`);
    },
  });

  const tree: OrgNode[] = data?.tree ?? [];
  const departments: any[] = data?.departments ?? [];
  const entities: any[] = data?.entities ?? [];

  // Pre-build avatar canvases
  useEffect(() => {
    if (!tree.length) return;
    const flat = tree.flatMap(root => flattenTree(root).map(f => f.node));
    flat.forEach(n => {
      if (!avatarCache.current.has(n.name)) {
        avatarCache.current.set(n.name, buildAvatarCanvas(n.name, 28));
      }
    });
  }, [tree]);

  // Search highlight
  const matchedIds = useMemo(() => {
    if (!search) return new Set<string>();
    const q = search.toLowerCase();
    const flat = tree.flatMap(root => flattenTree(root).map(f => f.node));
    return new Set(flat.filter(n =>
      n.name.toLowerCase().includes(q) || n.designation?.toLowerCase().includes(q)
    ).map(n => n.id));
  }, [search, tree]);

  // Render canvas
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !tree.length) return;
    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Background grid
    ctx.strokeStyle = 'rgba(26,46,26,0.3)';
    ctx.lineWidth = 0.5;
    const gs = 24 * scale;
    for (let x = (offset.x * scale) % gs; x < canvas.width; x += gs) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
    }
    for (let y = (offset.y * scale) % gs; y < canvas.height; y += gs) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
    }

    // Collect all flat nodes + edges
    const allNodes = tree.flatMap(root => flattenTree(root).map(f => f.node));
    const allEdges = tree.flatMap(root => collectEdges(root));

    // Draw edges
    ctx.strokeStyle = '#1a3a1a';
    ctx.lineWidth = 1.5 * scale;
    allEdges.forEach(({ px, py, cx, cy }) => {
      const mx = (px + offset.x) * scale;
      const my = (py + offset.y) * scale;
      const nx = (cx + offset.x) * scale;
      const ny = (cy + offset.y) * scale;
      const mid = (my + ny) / 2;
      ctx.beginPath();
      ctx.moveTo(mx, my);
      ctx.bezierCurveTo(mx, mid, nx, mid, nx, ny);
      ctx.stroke();
    });

    // Draw nodes (search dimming)
    allNodes.forEach(node => {
      const focused = (search && matchedIds.has(node.id)) ||
                      (!search && node.id === hoveredId) ||
                      node.id === selectedNode?.id;
      if (search && !matchedIds.has(node.id)) {
        ctx.globalAlpha = 0.2;
      }
      drawNode(ctx, node, offset.x, offset.y, scale, !!focused, avatarCache.current);
      ctx.globalAlpha = 1;
    });
  }, [tree, offset, scale, hoveredId, selectedNode, search, matchedIds]);

  useEffect(() => { render(); }, [render]);

  // Resize observer
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ro = new ResizeObserver(() => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      render();
    });
    ro.observe(canvas);
    return () => ro.disconnect();
  }, [render]);

  // Hit test
  const hitTest = useCallback((ex: number, ey: number): OrgNode | null => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const cx = (ex - rect.left) / scale - offset.x;
    const cy = (ey - rect.top) / scale - offset.y;
    const allNodes = tree.flatMap(root => flattenTree(root).map(f => f.node));
    return allNodes.find(n => cx >= n.x && cx <= n.x + NODE_W && cy >= n.y && cy <= n.y + NODE_H) ?? null;
  }, [tree, offset, scale]);

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    if (drag.current.dragging) {
      setOffset({
        x: drag.current.ox + (e.clientX - drag.current.startX) / scale,
        y: drag.current.oy + (e.clientY - drag.current.startY) / scale,
      });
      return;
    }
    const hit = hitTest(e.clientX, e.clientY);
    setHoveredId(hit?.id ?? null);
    if (canvasRef.current) canvasRef.current.style.cursor = hit ? 'pointer' : 'grab';
  }, [hitTest, scale]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    drag.current = { dragging: true, startX: e.clientX, startY: e.clientY, ox: offset.x, oy: offset.y };
    if (canvasRef.current) canvasRef.current.style.cursor = 'grabbing';
  }, [offset]);

  const handleMouseUp = useCallback((e: React.MouseEvent) => {
    if (!drag.current.dragging) return;
    const moved = Math.abs(e.clientX - drag.current.startX) + Math.abs(e.clientY - drag.current.startY);
    drag.current.dragging = false;
    if (moved < 4) {
      const hit = hitTest(e.clientX, e.clientY);
      setSelectedNode(hit ?? null);
    }
  }, [hitTest]);

  const handleWheel = useCallback((e: React.WheelEvent) => {
    e.preventDefault();
    setScale(s => Math.max(0.3, Math.min(2.0, s - e.deltaY * 0.001)));
  }, []);

  const resetView = () => { setOffset({ x: 40, y: 40 }); setScale(1); setRootNode(''); };

  return (
    <div className="h-full flex flex-col bg-retro-bg" style={{ height: 'calc(100vh - 120px)' }}>
      {/* toolbar */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-retro-border bg-retro-bg-secondary flex-shrink-0">
        <div className="font-pixel text-[7px] text-primary-crt mr-2">ORG CHART</div>

        {/* search */}
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-primary-700" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search name..."
            className="pl-7 pr-3 py-1 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-500 w-40 focus:border-primary-700 focus:outline-none"
          />
          {search && <button onClick={() => setSearch('')} className="absolute right-1 top-1/2 -translate-y-1/2"><X className="w-2.5 h-2.5 text-primary-700" /></button>}
        </div>

        {/* dept filter */}
        <select
          value={deptFilter}
          onChange={e => setDeptFilter(e.target.value)}
          className="px-2 py-1 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-600 focus:outline-none"
        >
          <option value="">All Departments</option>
          {departments.map((d: any) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>

        {/* entity filter (multi-entity) */}
        {entities.length > 1 && (
          <select
            value={entityFilter}
            onChange={e => setEntityFilter(e.target.value)}
            className="px-2 py-1 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-600 focus:outline-none"
          >
            <option value="">All Entities</option>
            {entities.map((e: any) => <option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        )}

        <div className="ml-auto flex items-center gap-1">
          <button onClick={() => setScale(s => Math.min(2, s + 0.1))} className="p-1 border border-retro-border rounded hover:border-primary-700">
            <ZoomIn className="w-3 h-3 text-primary-700" />
          </button>
          <span className="font-pixel text-[6px] text-primary-800 w-10 text-center">{Math.round(scale * 100)}%</span>
          <button onClick={() => setScale(s => Math.max(0.3, s - 0.1))} className="p-1 border border-retro-border rounded hover:border-primary-700">
            <ZoomOut className="w-3 h-3 text-primary-700" />
          </button>
          <button onClick={resetView} className="p-1 border border-retro-border rounded hover:border-primary-700 ml-1">
            <Home className="w-3 h-3 text-primary-700" />
          </button>
          <span className="font-pixel text-[6px] text-primary-800 ml-2">{data?.totalNodes ?? 0} NODES</span>
        </div>
      </div>

      {/* canvas */}
      <div className="flex-1 relative overflow-hidden">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center z-10">
            <div className="font-pixel text-[8px] text-primary-700 animate-pulse">LOADING HIERARCHY...</div>
          </div>
        )}
        <canvas
          ref={canvasRef}
          className="w-full h-full"
          onMouseMove={handleMouseMove}
          onMouseDown={handleMouseDown}
          onMouseUp={handleMouseUp}
          onMouseLeave={() => { drag.current.dragging = false; }}
          onWheel={handleWheel}
          style={{ cursor: 'grab' }}
        />

        {/* Node detail panel */}
        {selectedNode && (
          <div className="absolute top-3 right-3 w-60 bg-retro-bg border border-primary-700 rounded p-4 animate-slide-down shadow-glow">
            <button onClick={() => setSelectedNode(null)} className="absolute top-2 right-2 text-primary-800 hover:text-primary-500"><X className="w-3 h-3" /></button>
            <div className="flex items-center gap-3 mb-3">
              <PixelAvatar name={selectedNode.name} size={40} />
              <div>
                <div className="font-pixel text-[8px] text-primary-crt">{selectedNode.name}</div>
                <div className="font-mono text-[9px] text-primary-600 mt-0.5">{selectedNode.designation}</div>
              </div>
            </div>
            <div className="space-y-1.5">
              {selectedNode.department && (
                <div className="flex items-center gap-2">
                  <Users className="w-3 h-3 text-primary-800" />
                  <span className="font-mono text-[9px] text-primary-600">{selectedNode.department}</span>
                </div>
              )}
              {selectedNode.entityName && (
                <div className="flex items-center gap-2">
                  <Building2 className="w-3 h-3 text-primary-800" />
                  <span className="font-mono text-[9px] text-primary-600">{selectedNode.entityName}</span>
                </div>
              )}
            </div>
            <div className="flex gap-2 mt-3">
              <button
                onClick={() => { setRootNode(selectedNode.id); setSelectedNode(null); }}
                className="flex-1 py-1 border border-retro-border rounded font-pixel text-[6px] text-primary-700 hover:text-primary-crt hover:border-primary-700"
              >
                FOCUS SUBTREE
              </button>
              <button
                onClick={() => { window.location.href = `/dashboard/employees/${selectedNode.id}`; }}
                className="flex-1 py-1 border border-retro-border rounded font-pixel text-[6px] text-primary-700 hover:text-primary-crt hover:border-primary-700"
              >
                VIEW PROFILE
              </button>
            </div>
          </div>
        )}

        {/* Zoom hint */}
        <div className="absolute bottom-3 left-3 font-pixel text-[6px] text-primary-800 opacity-60">
          DRAG TO PAN · SCROLL TO ZOOM · CLICK NODE TO FOCUS
        </div>
      </div>
    </div>
  );
}
