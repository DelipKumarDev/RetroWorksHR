'use client';
/**
 * Pulse Survey — 5-question max · Anonymous option · eNPS · Trend chart
 * HR sees create + results. Employees see respond only.
 */

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Send, BarChart2, Activity, X, ChevronRight, Check, Users } from 'lucide-react';

// ── API ────────────────────────────────────────────────────────────────────────
const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1/engagement${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${tok()}`, 'Content-Type': 'application/json', ...((opts?.headers ?? {}) as any) },
  }).then(r => r.json()).then(r => r.data ?? r);

const fmtDate = (d: string | Date) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });

// ── eNPS color ─────────────────────────────────────────────────────────────────
function enpsColor(score: number) {
  if (score >= 50) return 'text-green-400';
  if (score >= 0) return 'text-amber-400';
  return 'text-red-400';
}

// ── Trend sparkline ────────────────────────────────────────────────────────────
function ENPSSparkline({ data }: { data: Array<{ period: string; score: number }> }) {
  if (data.length < 2) return null;
  const min = Math.min(...data.map(d => d.score), -100);
  const max = Math.max(...data.map(d => d.score), 100);
  const range = max - min || 1;
  const W = 200, H = 48;
  const pts = data.map((d, i) => ({
    x: (i / (data.length - 1)) * W,
    y: H - ((d.score - min) / range) * H,
  }));
  const path = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
  const latest = data[data.length - 1]!;
  const prev = data[data.length - 2]!;
  const delta = latest.score - prev.score;

  return (
    <div>
      <div className="flex items-end gap-3 mb-2">
        <div className={`font-pixel text-[22px] ${enpsColor(latest.score)}`}>{latest.score > 0 ? '+' : ''}{latest.score}</div>
        <div className={`font-pixel text-[8px] mb-1 ${delta >= 0 ? 'text-green-400' : 'text-red-400'}`}>
          {delta >= 0 ? '▲' : '▼'} {Math.abs(delta)} pts
        </div>
      </div>
      <svg width={W} height={H} className="overflow-visible">
        {/* zero line */}
        <line x1={0} y1={H - ((0 - min) / range) * H} x2={W} y2={H - ((0 - min) / range) * H}
          stroke="#1a2e1a" strokeWidth={1} strokeDasharray="4,3" />
        {/* area fill */}
        <path d={`${path} L${W},${H} L0,${H} Z`} fill="rgba(34,197,94,0.06)" />
        {/* line */}
        <path d={path} fill="none" stroke="#22c55e" strokeWidth={1.5} />
        {/* dots */}
        {pts.map((p, i) => (
          <circle key={i} cx={p.x} cy={p.y} r={2.5} fill="#00ff41" />
        ))}
      </svg>
      <div className="flex justify-between font-pixel text-[5px] text-primary-800 mt-1">
        {data.map(d => <span key={d.period}>{d.period.slice(5)}</span>)}
      </div>
    </div>
  );
}

// ── Scale question input ────────────────────────────────────────────────────────
function ScaleInput({ q, value, onChange, type }: { q: any; value: number | null; onChange: (v: number) => void; type: 'scale' | 'nps' }) {
  const max = type === 'nps' ? 10 : 5;
  return (
    <div className="flex gap-1 flex-wrap">
      {Array.from({ length: max + 1 }, (_, i) => i).map(n => (
        <button
          key={n}
          onClick={() => onChange(n)}
          className={`w-8 h-8 rounded border font-pixel text-[8px] transition-all ${
            value === n ? 'bg-primary-900 border-primary-crt text-primary-crt shadow-glow' : 'border-retro-border text-primary-700 hover:border-primary-700'
          }`}
        >
          {n}
        </button>
      ))}
    </div>
  );
}

// ── CREATOR VIEW ─────────────────────────────────────────────────────────────────
function CreateSurveyPanel({ onCreated }: { onCreated: () => void }) {
  const qc = useQueryClient();
  const [title, setTitle] = useState('Monthly Pulse');
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [questions, setQuestions] = useState<Array<{ id: string; text: string; type: string; required: boolean }>>([
    { id: 'q1', text: 'How likely are you to recommend this company as a great place to work?', type: 'nps', required: true },
    { id: 'q2', text: 'How satisfied are you with your work-life balance?', type: 'scale', required: true },
    { id: 'q3', text: 'What is one thing we can improve this month?', type: 'text', required: false },
  ]);

  const addQ = () => {
    if (questions.length >= 5) return;
    setQuestions(qs => [...qs, { id: `q${Date.now()}`, text: '', type: 'scale', required: false }]);
  };

  const createMut = useMutation({
    mutationFn: () => api('/surveys', {
      method: 'POST',
      body: JSON.stringify({ title, isAnonymous, questions }),
    }),
    onSuccess: (survey) => {
      // Immediately activate
      return api(`/surveys/${survey.id}/activate`, { method: 'POST' })
        .then(() => { qc.invalidateQueries({ queryKey: ['surveys'] }); onCreated(); });
    },
  });

  return (
    <div className="border border-retro-border rounded p-5 space-y-4 animate-slide-up">
      <div className="font-pixel text-[8px] text-primary-500">CREATE PULSE SURVEY</div>

      <div className="space-y-2">
        <label className="font-pixel text-[6px] text-primary-700">SURVEY TITLE</label>
        <input value={title} onChange={e => setTitle(e.target.value)}
          className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none" />
      </div>

      <div className="flex items-center gap-3">
        <label className="relative inline-flex cursor-pointer">
          <input type="checkbox" checked={isAnonymous} onChange={e => setIsAnonymous(e.target.checked)} className="sr-only" />
          <div className={`w-8 h-4 rounded-full transition-colors ${isAnonymous ? 'bg-primary-700' : 'bg-retro-border'}`}>
            <div className={`w-3 h-3 bg-primary-crt rounded-full m-0.5 transition-transform ${isAnonymous ? 'translate-x-4' : ''}`} />
          </div>
        </label>
        <span className="font-pixel text-[7px] text-primary-600">ANONYMOUS RESPONSES</span>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="font-pixel text-[6px] text-primary-700">QUESTIONS ({questions.length}/5)</label>
          {questions.length < 5 && (
            <button onClick={addQ} className="flex items-center gap-1 font-pixel text-[6px] text-primary-700 hover:text-primary-crt">
              <Plus className="w-2.5 h-2.5" /> ADD
            </button>
          )}
        </div>
        {questions.map((q, i) => (
          <div key={q.id} className="flex gap-2 items-start">
            <span className="font-pixel text-[6px] text-primary-800 mt-2 w-3">Q{i + 1}</span>
            <input value={q.text} onChange={e => {
              const qs = [...questions]; qs[i] = { ...qs[i]!, text: e.target.value }; setQuestions(qs);
            }}
              className="flex-1 px-2 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-[10px] text-primary-500 focus:border-primary-700 focus:outline-none"
              placeholder="Question text..." />
            <select value={q.type} onChange={e => {
              const qs = [...questions]; qs[i] = { ...qs[i]!, type: e.target.value }; setQuestions(qs);
            }}
              className="px-2 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-600 focus:outline-none">
              <option value="nps">eNPS (0–10)</option>
              <option value="scale">Scale (0–5)</option>
              <option value="text">Open Text</option>
              <option value="yesno">Yes / No</option>
            </select>
            {questions.length > 1 && (
              <button onClick={() => setQuestions(qs => qs.filter((_, j) => j !== i))}
                className="mt-1 text-primary-800 hover:text-red-400"><X className="w-3 h-3" /></button>
            )}
          </div>
        ))}
      </div>

      <div className="flex gap-2 pt-2">
        <button onClick={() => createMut.mutate()}
          disabled={createMut.isPending || !title || questions.some(q => !q.text)}
          className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
          <Send className="w-3 h-3" />
          {createMut.isPending ? 'LAUNCHING...' : 'LAUNCH SURVEY'}
        </button>
        <button onClick={onCreated} className="px-4 py-2 border border-retro-border rounded font-pixel text-[7px] text-primary-800 hover:text-primary-600">
          CANCEL
        </button>
      </div>
    </div>
  );
}

// ── RESPOND VIEW ───────────────────────────────────────────────────────────────
function RespondPanel({ surveyId }: { surveyId: string }) {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ['survey-respond', surveyId],
    queryFn: () => api(`/surveys/${surveyId}/respond`),
  });

  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [done, setDone] = useState(false);

  const submitMut = useMutation({
    mutationFn: () => api(`/surveys/${surveyId}/respond`, {
      method: 'POST',
      body: JSON.stringify({
        answers: Object.entries(answers).map(([questionId, value]) => ({ questionId, value })),
      }),
    }),
    onSuccess: () => { setDone(true); qc.invalidateQueries({ queryKey: ['surveys'] }); },
  });

  if (data?.hasResponded || done) {
    return (
      <div className="flex flex-col items-center justify-center py-12 space-y-3">
        <div className="w-12 h-12 rounded-full border border-green-700 bg-green-950/20 flex items-center justify-center">
          <Check className="w-6 h-6 text-green-400" />
        </div>
        <div className="font-pixel text-[8px] text-green-400">RESPONSE RECORDED</div>
        <div className="font-mono text-xs text-primary-700 text-center">
          {data?.survey?.isAnonymous ? 'Your response is anonymous.' : 'Thank you for your feedback.'}
        </div>
      </div>
    );
  }

  if (!data?.survey) return <div className="font-pixel text-[8px] text-primary-800 py-8 text-center">LOADING SURVEY...</div>;
  const { survey } = data;
  const questions = survey.questions ?? [];
  const allAnswered = questions.filter((q: any) => q.required).every((q: any) => answers[q.id] != null);

  return (
    <div className="space-y-5">
      <div>
        <div className="font-pixel text-[9px] text-primary-crt">{survey.title}</div>
        {survey.isAnonymous && (
          <div className="flex items-center gap-1.5 mt-1">
            <div className="w-2 h-2 rounded-full bg-green-500" />
            <span className="font-mono text-[9px] text-green-400">Anonymous — your identity is not recorded</span>
          </div>
        )}
      </div>

      {questions.map((q: any, i: number) => (
        <div key={q.id} className="space-y-2">
          <div className="flex items-start gap-2">
            <span className="font-pixel text-[6px] text-primary-800 mt-1">Q{i + 1}</span>
            <div>
              <div className="font-mono text-sm text-primary-400">{q.text}</div>
              {q.required && <span className="font-pixel text-[5px] text-primary-800">REQUIRED</span>}
            </div>
          </div>

          {(q.type === 'nps' || q.type === 'scale') && (
            <div>
              <ScaleInput q={q} type={q.type} value={answers[q.id] ?? null} onChange={v => setAnswers(a => ({ ...a, [q.id]: v }))} />
              {q.type === 'nps' && (
                <div className="flex justify-between font-pixel text-[5px] text-primary-800 mt-1 px-0.5">
                  <span>Not at all likely</span><span>Extremely likely</span>
                </div>
              )}
            </div>
          )}
          {q.type === 'text' && (
            <textarea
              value={answers[q.id] ?? ''}
              onChange={e => setAnswers(a => ({ ...a, [q.id]: e.target.value }))}
              rows={3}
              className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-700 focus:outline-none resize-none"
              placeholder="Your response..."
            />
          )}
          {q.type === 'yesno' && (
            <div className="flex gap-2">
              {['Yes', 'No'].map(opt => (
                <button key={opt} onClick={() => setAnswers(a => ({ ...a, [q.id]: opt }))}
                  className={`px-6 py-1.5 rounded border font-pixel text-[7px] transition-all ${answers[q.id] === opt ? 'bg-primary-900 border-primary-crt text-primary-crt' : 'border-retro-border text-primary-700 hover:border-primary-700'}`}>
                  {opt.toUpperCase()}
                </button>
              ))}
            </div>
          )}
        </div>
      ))}

      <button
        onClick={() => submitMut.mutate()}
        disabled={!allAnswered || submitMut.isPending}
        className="flex items-center gap-2 px-5 py-2.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
        <Send className="w-3 h-3" />
        {submitMut.isPending ? 'SUBMITTING...' : 'SUBMIT RESPONSE'}
      </button>
    </div>
  );
}

// ── RESULTS VIEW ───────────────────────────────────────────────────────────────
function ResultsPanel({ surveyId }: { surveyId: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ['survey-results', surveyId],
    queryFn: () => api(`/surveys/${surveyId}/results`),
  });

  if (isLoading) return <div className="font-pixel text-[8px] text-primary-800 py-8 text-center animate-pulse">LOADING RESULTS...</div>;
  if (!data) return null;

  return (
    <div className="space-y-4">
      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'RESPONSES', value: data.totalResponses, cls: 'text-primary-crt' },
          { label: 'RESPONSE RATE', value: `${data.responseRate}%`, cls: 'text-blue-400' },
          { label: 'eNPS SCORE', value: data.eNPS ? (data.eNPS.score > 0 ? `+${data.eNPS.score}` : String(data.eNPS.score)) : '—', cls: data.eNPS ? enpsColor(data.eNPS.score) : 'text-primary-700' },
        ].map(s => (
          <div key={s.label} className="border border-retro-border rounded p-3 text-center">
            <div className={`font-pixel text-[18px] ${s.cls}`}>{s.value}</div>
            <div className="font-pixel text-[5px] text-primary-800 mt-0.5">{s.label}</div>
          </div>
        ))}
      </div>

      {/* eNPS breakdown */}
      {data.eNPS && (
        <div className="border border-retro-border rounded p-3">
          <div className="font-pixel text-[6px] text-primary-700 mb-2">eNPS BREAKDOWN</div>
          <div className="flex gap-1 h-5">
            {[
              { label: 'Promoters', count: data.eNPS.promoters, cls: 'bg-green-700' },
              { label: 'Passives', count: data.eNPS.passives, cls: 'bg-amber-700' },
              { label: 'Detractors', count: data.eNPS.detractors, cls: 'bg-red-800' },
            ].map(b => {
              const total = data.eNPS.promoters + data.eNPS.passives + data.eNPS.detractors || 1;
              return (
                <div key={b.label} className={`${b.cls} rounded-sm`} style={{ width: `${b.count / total * 100}%`, minWidth: b.count > 0 ? '4px' : 0 }} title={`${b.label}: ${b.count}`} />
              );
            })}
          </div>
          <div className="flex gap-3 mt-1.5">
            {[
              { l: 'Promoters', n: data.eNPS.promoters, c: 'text-green-400' },
              { l: 'Passives', n: data.eNPS.passives, c: 'text-amber-400' },
              { l: 'Detractors', n: data.eNPS.detractors, c: 'text-red-400' },
            ].map(b => (
              <span key={b.l} className={`font-pixel text-[6px] ${b.c}`}>{b.l}: {b.n}</span>
            ))}
          </div>
        </div>
      )}

      {/* Per-question results */}
      {data.questionResults?.map((qr: any, i: number) => (
        <div key={qr.questionId} className="border border-retro-border rounded p-3 space-y-2">
          <div className="font-pixel text-[6px] text-primary-700">Q{i + 1}</div>
          <div className="font-mono text-sm text-primary-500">{qr.questionText}</div>
          {qr.average != null && (
            <div className="flex items-center gap-3">
              <div className="font-pixel text-[14px] text-primary-crt">{qr.average.toFixed(1)}</div>
              <div className="flex-1 h-2 bg-retro-bg rounded overflow-hidden">
                <div className="h-full bg-primary-700" style={{ width: `${(qr.average / (qr.type === 'nps' ? 10 : 5)) * 100}%` }} />
              </div>
              <span className="font-pixel text-[6px] text-primary-800">avg</span>
            </div>
          )}
          {qr.distribution && (
            <div className="space-y-0.5">
              {Object.entries(qr.distribution).sort((a: any, b: any) => Number(a[0]) - Number(b[0])).map(([k, v]) => {
                const max = Math.max(...Object.values(qr.distribution));
                return (
                  <div key={k} className="flex items-center gap-2">
                    <span className="font-pixel text-[6px] text-primary-800 w-4">{k}</span>
                    <div className="flex-1 h-1.5 bg-retro-bg rounded overflow-hidden">
                      <div className="h-full bg-primary-800" style={{ width: `${((v as number) / (max as number)) * 100}%` }} />
                    </div>
                    <span className="font-pixel text-[6px] text-primary-800 w-4">{v as number}</span>
                  </div>
                );
              })}
            </div>
          )}
          {qr.textResponses?.length > 0 && (
            <div className="space-y-1 max-h-24 overflow-y-auto">
              {qr.textResponses.slice(0, 5).map((r: string, j: number) => (
                <div key={j} className="font-mono text-[9px] text-primary-700 pl-2 border-l border-retro-border">"{r}"</div>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// MAIN PULSE SURVEY PAGE
// ══════════════════════════════════════════════════════════════════════════════

export function PulseSurveyPage({ isHR = false }: { isHR?: boolean }) {
  const [view, setView] = useState<'list' | 'create' | 'respond' | 'results'>('list');
  const [activeSurveyId, setActiveSurveyId] = useState<string | null>(null);

  const { data: surveys } = useQuery({
    queryKey: ['surveys'],
    queryFn: () => api('/surveys'),
  });

  const { data: trend } = useQuery({
    queryKey: ['enps-trend'],
    queryFn: () => api('/surveys/enps-trend?months=6'),
    enabled: isHR,
  });

  return (
    <div className="space-y-4 animate-fade-in">
      {/* header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="font-pixel text-[9px] text-primary-500">PULSE SURVEY</div>
          <div className="font-mono text-xs text-primary-700 mt-0.5">Employee feedback · Anonymous · eNPS tracking</div>
        </div>
        {isHR && view === 'list' && (
          <button onClick={() => setView('create')}
            className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800">
            <Plus className="w-3 h-3" /> NEW SURVEY
          </button>
        )}
        {view !== 'list' && (
          <button onClick={() => { setView('list'); setActiveSurveyId(null); }}
            className="font-pixel text-[7px] text-primary-700 hover:text-primary-500 border border-retro-border px-3 py-1.5 rounded">
            ← BACK
          </button>
        )}
      </div>

      {view === 'create' && <CreateSurveyPanel onCreated={() => setView('list')} />}
      {view === 'respond' && activeSurveyId && <RespondPanel surveyId={activeSurveyId} />}
      {view === 'results' && activeSurveyId && <ResultsPanel surveyId={activeSurveyId} />}

      {view === 'list' && (
        <>
          {/* eNPS trend (HR only) */}
          {isHR && trend?.length > 0 && (
            <div className="border border-retro-border rounded p-4">
              <div className="font-pixel text-[7px] text-primary-600 mb-3">eNPS TREND — LAST 6 MONTHS</div>
              <ENPSSparkline data={trend} />
            </div>
          )}

          {/* Survey list */}
          <div className="space-y-2">
            {(surveys ?? []).map((s: any) => (
              <div key={s.id} className="border border-retro-border rounded p-3 flex items-center gap-3 hover:border-primary-700/50 transition-colors">
                <Activity className="w-4 h-4 text-primary-700 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <div className="font-pixel text-[8px] text-primary-400">{s.title}</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`font-pixel text-[5px] px-1.5 py-0.5 rounded border ${
                      s.status === 'active' ? 'text-green-400 border-green-800' :
                      s.status === 'closed' ? 'text-primary-800 border-retro-border' :
                      'text-amber-400 border-amber-800'
                    }`}>{s.status.toUpperCase()}</span>
                    {s.isAnonymous && <span className="font-pixel text-[5px] text-primary-800">ANONYMOUS</span>}
                    <span className="font-pixel text-[5px] text-primary-800">{s.questions?.length ?? 0} QUESTIONS</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  {s.status === 'active' && !isHR && (
                    <button onClick={() => { setActiveSurveyId(s.id); setView('respond'); }}
                      className="flex items-center gap-1 px-3 py-1.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[6px] text-primary-crt hover:bg-primary-800">
                      RESPOND <ChevronRight className="w-2.5 h-2.5" />
                    </button>
                  )}
                  {isHR && (
                    <button onClick={() => { setActiveSurveyId(s.id); setView('results'); }}
                      className="flex items-center gap-1 px-3 py-1.5 border border-retro-border rounded font-pixel text-[6px] text-primary-700 hover:border-primary-700">
                      <BarChart2 className="w-2.5 h-2.5" /> RESULTS
                    </button>
                  )}
                </div>
              </div>
            ))}
            {(surveys ?? []).length === 0 && (
              <div className="py-12 text-center font-pixel text-[7px] text-primary-800">
                {isHR ? 'No surveys yet. Create your first pulse.' : 'No active surveys right now.'}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
