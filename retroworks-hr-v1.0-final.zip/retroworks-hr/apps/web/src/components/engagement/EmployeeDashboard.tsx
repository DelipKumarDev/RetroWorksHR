'use client';
/**
 * Employee Dashboard — Zero-training UX
 * Quick actions · Leave balance · Payslip button · Tax preview
 * Notification center · Ctrl+K smart search
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Calendar, FileText, Receipt, Users, Target, HelpCircle,
  Bell, Search, X, ChevronRight, TrendingUp, TrendingDown,
  Check, Clock, Activity, CreditCard, Building2, ArrowRight,
  Zap, Star, AlertTriangle, LogOut, Settings,
} from 'lucide-react';

// ── API ────────────────────────────────────────────────────────────────────────
const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1/engagement${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${tok()}`, 'Content-Type': 'application/json', ...((opts?.headers ?? {}) as any) },
  }).then(r => r.json()).then(r => r.data ?? r);

const fmt = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const fmtDate = (d: string | Date) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
const fmtMonth = (d: string | Date) => new Date(d).toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

// ── ICON MAP ──────────────────────────────────────────────────────────────────
const ICONS: Record<string, any> = {
  calendar: Calendar, 'file-text': FileText, receipt: Receipt,
  users: Users, target: Target, 'help-circle': HelpCircle,
  activity: Activity, 'credit-card': CreditCard, 'git-branch': Building2,
  user: Users, file: FileText,
};

// ══════════════════════════════════════════════════════════════════════════════
// CTRL+K COMMAND PALETTE
// ══════════════════════════════════════════════════════════════════════════════

function CommandPalette({ onClose }: { onClose: () => void }) {
  const [q, setQ] = useState('');
  const [idx, setIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const { data: results } = useQuery({
    queryKey: ['search', q],
    queryFn: () => api(`/dashboard/search?q=${encodeURIComponent(q)}`),
    enabled: q.length >= 1,
  });

  useEffect(() => { setTimeout(() => inputRef.current?.focus(), 50); }, []);

  useEffect(() => { setIdx(0); }, [results]);

  const handleKey = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Escape') { onClose(); return; }
    if (!results?.length) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); setIdx(i => Math.min(i + 1, results.length - 1)); }
    if (e.key === 'ArrowUp') { e.preventDefault(); setIdx(i => Math.max(i - 1, 0)); }
    if (e.key === 'Enter') { window.location.href = results[idx]?.route; onClose(); }
  }, [results, idx, onClose]);

  const typeColor: Record<string, string> = {
    employee: 'text-blue-400',
    page: 'text-primary-600',
    action: 'text-amber-400',
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-start justify-center pt-[15vh]" onClick={onClose}>
      <div className="w-full max-w-xl mx-4" onClick={e => e.stopPropagation()}>
        {/* Input */}
        <div className="flex items-center gap-3 px-4 py-3 bg-retro-bg border border-primary-700 rounded-t shadow-glow-strong">
          <Search className="w-4 h-4 text-primary-600 flex-shrink-0" />
          <input
            ref={inputRef}
            value={q}
            onChange={e => setQ(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Search people, pages, actions..."
            className="flex-1 bg-transparent font-mono text-sm text-primary-400 placeholder-primary-800 focus:outline-none"
          />
          <span className="font-pixel text-[6px] text-primary-800 border border-retro-border px-1.5 py-0.5 rounded">ESC</span>
        </div>

        {/* Results */}
        <div className="bg-retro-bg border-x border-b border-primary-700 rounded-b overflow-hidden">
          {q.length === 0 && (
            <div className="px-4 py-2 border-b border-retro-border">
              <div className="font-pixel text-[5px] text-primary-800 mb-2">QUICK NAVIGATION</div>
              <div className="grid grid-cols-4 gap-1">
                {[
                  { label: 'Apply Leave', route: '/dashboard/leave/apply', icon: Calendar },
                  { label: 'Payslips', route: '/dashboard/payslips', icon: FileText },
                  { label: 'Tax',      route: '/dashboard/tax', icon: Receipt },
                  { label: 'Org Chart', route: '/dashboard/org-chart', icon: Building2 },
                ].map(a => (
                  <button key={a.label} onClick={() => { window.location.href = a.route; onClose(); }}
                    className="flex flex-col items-center gap-1 p-2 rounded border border-retro-border hover:border-primary-700 transition-colors">
                    <a.icon className="w-4 h-4 text-primary-700" />
                    <span className="font-pixel text-[5px] text-primary-800">{a.label}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {results?.length > 0 && (
            <div>
              {results.map((r: any, i: number) => {
                const Icon = ICONS[r.icon ?? 'file-text'] ?? FileText;
                return (
                  <button key={r.id} onClick={() => { window.location.href = r.route; onClose(); }}
                    onMouseEnter={() => setIdx(i)}
                    className={`w-full flex items-center gap-3 px-4 py-2.5 transition-colors ${i === idx ? 'bg-primary-950' : ''}`}>
                    <Icon className={`w-4 h-4 flex-shrink-0 ${typeColor[r.type] ?? 'text-primary-700'}`} />
                    <div className="flex-1 text-left">
                      <div className="font-pixel text-[8px] text-primary-400">{r.title}</div>
                      {r.subtitle && <div className="font-mono text-[9px] text-primary-700 mt-0.5">{r.subtitle}</div>}
                    </div>
                    <ChevronRight className="w-3 h-3 text-primary-800" />
                  </button>
                );
              })}
            </div>
          )}

          {q.length >= 1 && !results?.length && (
            <div className="px-4 py-6 text-center font-pixel text-[7px] text-primary-800">
              No results for "{q}"
            </div>
          )}

          <div className="px-4 py-2 border-t border-retro-border flex gap-4">
            <span className="font-pixel text-[5px] text-primary-800">↑↓ NAVIGATE</span>
            <span className="font-pixel text-[5px] text-primary-800">↵ OPEN</span>
            <span className="font-pixel text-[5px] text-primary-800">ESC CLOSE</span>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── NOTIFICATION PANEL ────────────────────────────────────────────────────────
function NotificationPanel({ notifications, onMarkRead, onClose }: {
  notifications: any[]; onMarkRead: (ids: string[]) => void; onClose: () => void;
}) {
  const unread = notifications.filter(n => !n.isRead);

  return (
    <div className="absolute top-8 right-0 w-80 bg-retro-bg border border-retro-border rounded shadow-glow z-40 animate-slide-down">
      <div className="flex items-center justify-between px-4 py-2 border-b border-retro-border">
        <span className="font-pixel text-[7px] text-primary-500">NOTIFICATIONS</span>
        <div className="flex items-center gap-2">
          {unread.length > 0 && (
            <button onClick={() => onMarkRead(unread.map(n => n.id))}
              className="font-pixel text-[5px] text-primary-700 hover:text-primary-500">MARK ALL READ</button>
          )}
          <button onClick={onClose}><X className="w-3 h-3 text-primary-800" /></button>
        </div>
      </div>
      <div className="max-h-80 overflow-y-auto">
        {notifications.length === 0 && (
          <div className="px-4 py-8 text-center font-pixel text-[7px] text-primary-800">All caught up!</div>
        )}
        {notifications.map(n => (
          <div key={n.id} className={`px-4 py-3 border-b border-retro-border/50 ${!n.isRead ? 'bg-primary-950/20' : ''}`}>
            <div className="flex items-start gap-2">
              {!n.isRead && <div className="w-1.5 h-1.5 rounded-full bg-primary-crt mt-1.5 flex-shrink-0 animate-pulse" />}
              <div className="flex-1 min-w-0">
                <div className="font-pixel text-[7px] text-primary-400 truncate">{n.title}</div>
                <div className="font-mono text-[9px] text-primary-700 mt-0.5 line-clamp-2">{n.body}</div>
                <div className="font-pixel text-[5px] text-primary-800 mt-1">{fmtDate(n.createdAt)}</div>
              </div>
            </div>
            {n.actionUrl && (
              <a href={n.actionUrl} className="mt-1 flex items-center gap-1 font-pixel text-[6px] text-primary-700 hover:text-primary-crt" onClick={onClose}>
                VIEW <ArrowRight className="w-2 h-2" />
              </a>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ── LEAVE BALANCE CARD ────────────────────────────────────────────────────────
function LeaveBalanceCard({ leave }: { leave: any }) {
  const balances = leave?.balances ?? [];
  const total = balances.reduce((s: number, b: any) => s + b.remaining, 0);

  return (
    <div className="border border-retro-border rounded p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-3.5 h-3.5 text-primary-700" />
          <span className="font-pixel text-[7px] text-primary-600">LEAVE BALANCE</span>
        </div>
        <a href="/dashboard/leave/apply"
          className="font-pixel text-[6px] text-primary-700 hover:text-primary-crt border border-retro-border px-2 py-1 rounded">
          APPLY +
        </a>
      </div>

      {/* Big total */}
      <div className="mb-3">
        <span className="font-pixel text-[24px] text-primary-crt">{total}</span>
        <span className="font-mono text-xs text-primary-700 ml-2">days available</span>
      </div>

      {/* Per-type breakdown */}
      <div className="space-y-1.5">
        {balances.slice(0, 4).map((b: any) => (
          <div key={b.leaveTypeCode}>
            <div className="flex justify-between mb-0.5">
              <span className="font-pixel text-[6px] text-primary-700">{b.leaveTypeName}</span>
              <span className="font-mono text-[9px] text-primary-500">{b.remaining}/{b.total}</span>
            </div>
            <div className="h-1 bg-retro-bg rounded overflow-hidden">
              <div className="h-full bg-primary-800 rounded" style={{ width: `${b.total ? (b.remaining / b.total) * 100 : 0}%` }} />
            </div>
          </div>
        ))}
      </div>

      {leave?.nextHoliday && (
        <div className="mt-3 px-2 py-1.5 bg-retro-bg-secondary rounded flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
          <span className="font-pixel text-[6px] text-amber-400">{leave.nextHoliday.name}</span>
          <span className="font-mono text-[9px] text-amber-700 ml-auto">{fmtDate(leave.nextHoliday.date)}</span>
        </div>
      )}
    </div>
  );
}

// ── TAX PROJECTION CARD ────────────────────────────────────────────────────────
function TaxProjectionCard() {
  const { data: tax } = useQuery({
    queryKey: ['tax-projection'],
    queryFn: () => api('/dashboard/tax-projection'),
  });

  if (!tax) return (
    <div className="border border-retro-border rounded p-4 animate-pulse">
      <div className="font-pixel text-[7px] text-primary-800">LOADING TAX...</div>
    </div>
  );

  const isRefund = tax.estimatedBalanceTax < 0;
  const balanceAbs = Math.abs(tax.estimatedBalanceTax);

  return (
    <div className="border border-retro-border rounded p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Receipt className="w-3.5 h-3.5 text-primary-700" />
          <span className="font-pixel text-[7px] text-primary-600">TAX PROJECTION</span>
        </div>
        <span className="font-pixel text-[6px] text-primary-800 border border-retro-border px-1.5 py-0.5 rounded">FY {tax.financialYear}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-3">
        <div>
          <div className="font-pixel text-[5px] text-primary-800 mb-0.5">PROJECTED ANNUAL</div>
          <div className="font-mono text-sm text-primary-400">{fmt(tax.projectedAnnualGross)}</div>
        </div>
        <div>
          <div className="font-pixel text-[5px] text-primary-800 mb-0.5">PROJECTED TAX</div>
          <div className="font-mono text-sm text-primary-400">{fmt(tax.projectedTax)}</div>
        </div>
      </div>

      <div className={`flex items-center gap-2 px-3 py-2 rounded border ${
        isRefund ? 'bg-green-950/20 border-green-800' : 'bg-amber-950/10 border-amber-900/50'
      }`}>
        {isRefund
          ? <TrendingDown className="w-4 h-4 text-green-400 flex-shrink-0" />
          : <TrendingUp className="w-4 h-4 text-amber-400 flex-shrink-0" />
        }
        <div>
          <div className={`font-pixel text-[7px] ${isRefund ? 'text-green-400' : 'text-amber-400'}`}>
            {isRefund ? `Estimated refund: ${fmt(balanceAbs)}` : `Balance tax: ${fmt(balanceAbs)}`}
          </div>
          <div className="font-mono text-[9px] text-primary-700 mt-0.5">
            {tax.monthsRemaining} months left · {fmt(tax.monthlyTdsRequired)}/mo TDS req.
          </div>
        </div>
      </div>

      <a href="/dashboard/tax" className="mt-2 flex items-center gap-1 font-pixel text-[6px] text-primary-700 hover:text-primary-crt">
        FULL DECLARATION <ArrowRight className="w-2 h-2" />
      </a>
    </div>
  );
}

// ── QUICK ACTIONS ─────────────────────────────────────────────────────────────
function QuickActionsGrid({ actions }: { actions: any[] }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      {actions.map(a => {
        const Icon = ICONS[a.icon ?? 'file-text'] ?? FileText;
        return (
          <a key={a.id} href={a.route}
            className="flex flex-col items-center gap-2 p-3 border border-retro-border rounded hover:border-primary-700 hover:bg-primary-950/20 transition-all group">
            <div className="w-8 h-8 rounded border border-retro-border group-hover:border-primary-700 flex items-center justify-center bg-retro-bg-secondary">
              <Icon className="w-4 h-4 text-primary-700 group-hover:text-primary-500" />
            </div>
            <span className="font-pixel text-[6px] text-primary-700 group-hover:text-primary-500 text-center">{a.label}</span>
            {a.badge > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 rounded-full font-pixel text-[5px] text-white flex items-center justify-center">{a.badge}</span>
            )}
          </a>
        );
      })}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// MAIN DASHBOARD
// ══════════════════════════════════════════════════════════════════════════════

export function EmployeeDashboard() {
  const qc = useQueryClient();
  const [showPalette, setShowPalette] = useState(false);
  const [showNotifs, setShowNotifs] = useState(false);

  const { data: dash, isLoading } = useQuery({
    queryKey: ['my-dashboard'],
    queryFn: () => api('/dashboard/me'),
    refetchInterval: 60_000,
  });

  const markReadMut = useMutation({
    mutationFn: (ids: string[]) => api('/dashboard/notifications/read', { method: 'POST', body: JSON.stringify({ ids }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['my-dashboard'] }),
  });

  // Ctrl+K listener
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); setShowPalette(p => !p); }
      if (e.key === 'Escape') { setShowPalette(false); setShowNotifs(false); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-64 space-y-3">
        <div className="font-pixel text-[8px] text-primary-700 animate-pulse">LOADING DASHBOARD...</div>
        <div className="font-mono text-xs text-primary-800">Initialising workspace</div>
      </div>
    );
  }

  const emp = dash?.employee;
  const notifications = dash?.notifications ?? [];
  const unreadCount = dash?.unreadNotifications ?? 0;

  // Greeting
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'GOOD MORNING' : hour < 17 ? 'GOOD AFTERNOON' : 'GOOD EVENING';

  return (
    <div className="space-y-4 animate-fade-in relative">
      {/* Command palette */}
      {showPalette && <CommandPalette onClose={() => setShowPalette(false)} />}

      {/* Top bar */}
      <div className="flex items-center justify-between">
        <div>
          <div className="font-pixel text-[7px] text-primary-700">{greeting},</div>
          <div className="font-pixel text-[11px] text-primary-crt mt-0.5">{emp?.firstName} {emp?.lastName}</div>
          <div className="font-mono text-xs text-primary-700 mt-0.5">
            {emp?.designation?.name} · {emp?.department?.name}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Search button */}
          <button onClick={() => setShowPalette(true)}
            className="flex items-center gap-2 px-3 py-1.5 bg-retro-bg border border-retro-border rounded hover:border-primary-700 transition-colors">
            <Search className="w-3 h-3 text-primary-700" />
            <span className="font-mono text-[10px] text-primary-800 hidden sm:block">Search...</span>
            <span className="font-pixel text-[5px] text-primary-800 border border-retro-border px-1 py-0.5 rounded hidden sm:block">⌘K</span>
          </button>

          {/* Notifications */}
          <div className="relative">
            <button onClick={() => setShowNotifs(p => !p)}
              className="relative p-2 border border-retro-border rounded hover:border-primary-700">
              <Bell className="w-4 h-4 text-primary-700" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 rounded-full font-pixel text-[5px] text-white flex items-center justify-center">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>
            {showNotifs && (
              <NotificationPanel
                notifications={notifications}
                onMarkRead={ids => markReadMut.mutate(ids)}
                onClose={() => setShowNotifs(false)}
              />
            )}
          </div>
        </div>
      </div>

      {/* Active survey banner */}
      {dash?.activeSurvey && (
        <div className="flex items-center gap-3 p-3 bg-blue-950/20 border border-blue-800/50 rounded animate-slide-down">
          <Activity className="w-4 h-4 text-blue-400 flex-shrink-0" />
          <div className="flex-1">
            <span className="font-pixel text-[7px] text-blue-400">PULSE SURVEY ACTIVE</span>
            <span className="font-mono text-[10px] text-blue-600 ml-2">{dash.activeSurvey.title}</span>
          </div>
          <a href="/dashboard/pulse" className="flex items-center gap-1 font-pixel text-[6px] text-blue-400 hover:text-blue-300 border border-blue-800 px-3 py-1.5 rounded">
            RESPOND <ArrowRight className="w-2.5 h-2.5" />
          </a>
        </div>
      )}

      {/* Main grid */}
      <div className="grid grid-cols-12 gap-4">

        {/* Left col — quick actions + payslip */}
        <div className="col-span-12 lg:col-span-4 space-y-4">

          {/* Quick actions */}
          <div className="border border-retro-border rounded p-4">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-3.5 h-3.5 text-primary-700" />
              <span className="font-pixel text-[7px] text-primary-600">QUICK ACTIONS</span>
              <span className="ml-auto font-pixel text-[5px] text-primary-800">CTRL+K TO SEARCH</span>
            </div>
            <QuickActionsGrid actions={dash?.quickActions ?? []} />
          </div>

          {/* Latest payslip */}
          {dash?.latestPayslip && (
            <div className="border border-retro-border rounded p-4">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="w-3.5 h-3.5 text-primary-700" />
                <span className="font-pixel text-[7px] text-primary-600">LATEST PAYSLIP</span>
              </div>
              <div className="flex items-center justify-between mb-2">
                <div>
                  <div className="font-mono text-sm text-primary-400">{fmt(dash.latestPayslip.netPay)}</div>
                  <div className="font-pixel text-[5px] text-primary-800 mt-0.5">
                    {fmtMonth(dash.latestPayslip.payPeriodEnd)}
                  </div>
                </div>
                <span className={`font-pixel text-[5px] px-2 py-0.5 rounded border ${
                  dash.latestPayslip.status === 'paid' ? 'text-green-400 border-green-800' :
                  'text-amber-400 border-amber-800'
                }`}>{dash.latestPayslip.status.toUpperCase()}</span>
              </div>
              <a href="/dashboard/payslips"
                className="flex items-center gap-1 w-full py-2 border border-retro-border rounded font-pixel text-[6px] text-primary-700 hover:border-primary-700 hover:text-primary-crt justify-center">
                <FileText className="w-3 h-3" /> VIEW ALL PAYSLIPS
              </a>
            </div>
          )}
        </div>

        {/* Middle col — leave + pending tasks */}
        <div className="col-span-12 lg:col-span-4 space-y-4">
          <LeaveBalanceCard leave={dash?.leave} />

          {/* Pending tasks */}
          {(dash?.pendingTasks ?? 0) > 0 && (
            <div className="border border-amber-900/40 rounded p-4 bg-amber-950/10">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span className="font-pixel text-[7px] text-amber-400">PENDING ACTIONS</span>
              </div>
              <div className="font-pixel text-[20px] text-amber-300">{dash.pendingTasks}</div>
              <div className="font-mono text-xs text-amber-700">tasks awaiting your action</div>
              <a href="/dashboard/tasks" className="mt-2 flex items-center gap-1 font-pixel text-[6px] text-amber-400 hover:text-amber-300">
                VIEW TASKS <ArrowRight className="w-2 h-2" />
              </a>
            </div>
          )}
        </div>

        {/* Right col — tax + stats */}
        <div className="col-span-12 lg:col-span-4 space-y-4">
          <TaxProjectionCard />

          {/* Employee at-a-glance */}
          <div className="border border-retro-border rounded p-4 space-y-2">
            <div className="font-pixel text-[7px] text-primary-600 mb-2">AT A GLANCE</div>
            {[
              { label: 'Employee Code', value: emp?.employeeCode },
              { label: 'Department', value: emp?.department?.name },
              { label: 'Designation', value: emp?.designation?.name },
              { label: 'Date of Joining', value: emp?.dateOfJoining ? fmtDate(emp.dateOfJoining) : '—' },
            ].map(item => (
              <div key={item.label} className="flex justify-between">
                <span className="font-pixel text-[6px] text-primary-800">{item.label}</span>
                <span className="font-mono text-[10px] text-primary-500">{item.value ?? '—'}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer hint */}
      <div className="flex items-center justify-center gap-4 pt-2 border-t border-retro-border">
        <span className="font-pixel text-[5px] text-primary-800">⌘K SEARCH</span>
        <span className="font-pixel text-[5px] text-primary-800">·</span>
        <span className="font-pixel text-[5px] text-primary-800">RETROWORKS HR v9.0</span>
        <span className="font-pixel text-[5px] text-primary-800">·</span>
        <a href="/dashboard/billing" className="font-pixel text-[5px] text-primary-800 hover:text-primary-600">BILLING</a>
      </div>
    </div>
  );
}
