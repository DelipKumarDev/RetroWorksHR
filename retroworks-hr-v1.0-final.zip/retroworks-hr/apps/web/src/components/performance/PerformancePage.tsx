'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Target, Star, ChevronDown, ChevronUp, Plus, Users, CheckSquare,
} from 'lucide-react';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
      ...opts?.headers,
    },
  }).then(r => r.json());

// Progress ring SVG component
function ProgressRing({ progress, size = 56, strokeWidth = 4, color = '#22c55e' }: {
  progress: number; size?: number; strokeWidth?: number; color?: string;
}) {
  const radius = (size - strokeWidth * 2) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;

  return (
    <svg width={size} height={size} className="-rotate-90">
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#1a2a1a" strokeWidth={strokeWidth} />
      <circle
        cx={size / 2} cy={size / 2} r={radius} fill="none"
        stroke={color} strokeWidth={strokeWidth}
        strokeDasharray={circumference} strokeDashoffset={offset}
        strokeLinecap="round" className="transition-all duration-700"
      />
      <text x="50%" y="50%" textAnchor="middle" dy=".3em" className="rotate-90 origin-center fill-current"
        style={{ fontSize: size * 0.2, fill: '#a0c4a0', fontFamily: 'monospace', transform: `rotate(90deg) translate(0, -${size}px)` }}>
        {progress}%
      </text>
    </svg>
  );
}

function OkrCard({ objective, onUpdateKr }: {
  objective: {
    id: string; title: string; level: string; progress: number;
    keyResults: Array<{ id: string; title: string; currentValue: number; targetValue: number; unit: string; progress: number }>;
  };
  onUpdateKr: (krId: string, value: number) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const [editingKr, setEditingKr] = useState<string | null>(null);
  const [newValue, setNewValue] = useState('');

  const levelColors: Record<string, string> = {
    company: 'border-primary-crt text-primary-crt',
    team: 'border-blue-600 text-blue-400',
    individual: 'border-purple-600 text-purple-400',
  };

  return (
    <div className="bg-retro-card border border-retro-border rounded overflow-hidden">
      <div
        className="flex items-center gap-4 p-4 cursor-pointer hover:bg-surface-raised"
        onClick={() => setExpanded(e => !e)}
      >
        <ProgressRing
          progress={objective.progress}
          color={objective.progress >= 70 ? '#22c55e' : objective.progress >= 40 ? '#f59e0b' : '#ef4444'}
        />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className={`px-1.5 py-0.5 border rounded font-pixel text-[6px] ${levelColors[objective.level] ?? levelColors['individual']!}`}>
              {objective.level.toUpperCase()}
            </span>
          </div>
          <p className="font-mono text-sm text-primary-300 leading-tight">{objective.title}</p>
          <p className="font-mono text-[10px] text-primary-700 mt-0.5">
            {objective.keyResults.length} key result{objective.keyResults.length !== 1 ? 's' : ''}
          </p>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-primary-700" /> : <ChevronDown className="w-4 h-4 text-primary-700" />}
      </div>

      {expanded && (
        <div className="border-t border-retro-border divide-y divide-retro-border/50">
          {objective.keyResults.map(kr => (
            <div key={kr.id} className="px-4 py-3">
              <div className="flex items-center justify-between gap-2">
                <p className="font-mono text-xs text-primary-400 flex-1">{kr.title}</p>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="font-mono text-xs text-primary-600">
                    {kr.currentValue}/{kr.targetValue} {kr.unit}
                  </span>
                  <button
                    onClick={(e) => { e.stopPropagation(); setEditingKr(kr.id); setNewValue(String(kr.currentValue)); }}
                    className="font-pixel text-[6px] text-primary-700 hover:text-primary-400 border border-retro-border px-1.5 py-0.5 rounded"
                  >
                    UPDATE
                  </button>
                </div>
              </div>

              {/* Progress bar */}
              <div className="mt-2 h-1.5 bg-retro-bg rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all"
                  style={{
                    width: `${kr.progress}%`,
                    backgroundColor: kr.progress >= 70 ? '#22c55e' : kr.progress >= 40 ? '#f59e0b' : '#ef4444',
                  }}
                />
              </div>
              <p className="font-mono text-[9px] text-primary-800 mt-0.5">{kr.progress}% complete</p>

              {editingKr === kr.id && (
                <div className="mt-2 flex items-center gap-2" onClick={e => e.stopPropagation()}>
                  <input
                    type="number"
                    value={newValue}
                    onChange={e => setNewValue(e.target.value)}
                    className="w-24 px-2 py-1 bg-retro-bg border border-primary-700 rounded font-mono text-xs text-primary-300 focus:outline-none"
                    placeholder={String(kr.targetValue)}
                  />
                  <span className="font-mono text-xs text-primary-700">{kr.unit}</span>
                  <button
                    onClick={() => { onUpdateKr(kr.id, parseFloat(newValue)); setEditingKr(null); }}
                    className="px-2 py-1 bg-primary-900 border border-primary-600 font-pixel text-[6px] text-primary-crt rounded"
                  >
                    SAVE
                  </button>
                  <button onClick={() => setEditingKr(null)} className="font-mono text-xs text-primary-700">✕</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function PerformancePage() {
  const [tab, setTab] = useState<'okr' | 'reviews' | 'team'>('okr');
  const [selectedCycle, setSelectedCycle] = useState<string>('');
  const qc = useQueryClient();

  const { data: cycles = [] } = useQuery({
    queryKey: ['review-cycles'],
    queryFn: () => api('/performance/cycles').then(r => r.data ?? []),
  });

  const activeCycle = (cycles as Array<{ id: string; status: string }>).find(c => c.status === 'active') ?? (cycles as Array<{ id: string }>)[0];
  const cycleId = selectedCycle || activeCycle?.id || '';

  const { data: okrs = [] } = useQuery({
    queryKey: ['okrs', cycleId],
    queryFn: () => api(`/performance/okrs?cycleId=${cycleId}`).then(r => r.data ?? []),
    enabled: !!cycleId && tab === 'okr',
  });

  const { data: myReviews = [] } = useQuery({
    queryKey: ['my-reviews', cycleId],
    queryFn: () => api(`/performance/reviews/mine?cycleId=${cycleId}`).then(r => r.data ?? []),
    enabled: !!cycleId && tab === 'reviews',
  });

  const { data: teamProgress = [] } = useQuery({
    queryKey: ['team-review-progress', cycleId],
    queryFn: () => api(`/performance/team-progress?cycleId=${cycleId}`).then(r => r.data ?? []),
    enabled: !!cycleId && tab === 'team',
  });

  const updateKrMutation = useMutation({
    mutationFn: ({ id, value }: { id: string; value: number }) =>
      api(`/performance/key-results/${id}`, { method: 'PATCH', body: JSON.stringify({ currentValue: value }) }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['okrs'] }),
  });

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">PERFORMANCE</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">OKRs, reviews, and 360° feedback</p>
        </div>

        <select
          value={cycleId}
          onChange={e => setSelectedCycle(e.target.value)}
          className="px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:border-primary-600 focus:outline-none"
        >
          {(cycles as Array<{ id: string; name: string; status: string }>).map(c => (
            <option key={c.id} value={c.id}>{c.name} ({c.status})</option>
          ))}
        </select>
      </div>

      {/* Tabs */}
      <div className="flex gap-0 border-b border-retro-border">
        {([
          { key: 'okr', label: 'OKRs', icon: <Target className="w-3 h-3" /> },
          { key: 'reviews', label: 'My Reviews', icon: <Star className="w-3 h-3" /> },
          { key: 'team', label: 'Team Progress', icon: <Users className="w-3 h-3" /> },
        ] as const).map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 px-4 py-2 font-pixel text-[8px] border-b-2 transition-all ${
              tab === t.key ? 'border-primary-crt text-primary-crt' : 'border-transparent text-primary-700 hover:text-primary-500'
            }`}
          >
            {t.icon}{t.label}
          </button>
        ))}
      </div>

      {/* OKRs */}
      {tab === 'okr' && (
        <div className="space-y-3">
          {(okrs as Array<Parameters<typeof OkrCard>[0]['objective']>).length === 0 ? (
            <div className="text-center py-12">
              <Target className="w-10 h-10 text-primary-800 mx-auto mb-3" />
              <p className="font-pixel text-[8px] text-primary-700">No OKRs set for this cycle</p>
            </div>
          ) : (
            (okrs as Array<Parameters<typeof OkrCard>[0]['objective']>).map(obj => (
              <OkrCard
                key={obj.id}
                objective={obj}
                onUpdateKr={(id, value) => updateKrMutation.mutate({ id, value })}
              />
            ))
          )}
        </div>
      )}

      {/* Reviews */}
      {tab === 'reviews' && (
        <div className="space-y-3">
          {(myReviews as Array<{
            id: string; reviewType: string; status: string;
            reviewee: { firstName: string; lastName: string };
            reviewer: { firstName: string; lastName: string };
            cycle: { name: string };
            overallRating?: number;
          }>).map(review => {
            const isReviewer = review.reviewType !== 'self';
            return (
              <div key={review.id} className="bg-retro-card border border-retro-border rounded p-4 flex items-center gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className={`font-pixel text-[7px] px-1.5 py-0.5 border rounded ${
                      review.reviewType === 'self' ? 'border-primary-700 text-primary-600' :
                      review.reviewType === 'manager' ? 'border-amber-700 text-amber-400' :
                      'border-blue-700 text-blue-400'
                    }`}>
                      {review.reviewType.toUpperCase()}
                    </span>
                    <p className="font-mono text-sm text-primary-300">
                      {isReviewer ? `Review for ${review.reviewee.firstName} ${review.reviewee.lastName}` : 'Self Review'}
                    </p>
                  </div>
                  <p className="font-mono text-xs text-primary-700 mt-1">{review.cycle.name}</p>
                </div>
                {review.status === 'submitted' && review.overallRating ? (
                  <div className="flex items-center gap-1">
                    {Array.from({ length: 5 }, (_, i) => (
                      <Star
                        key={i}
                        className={`w-3.5 h-3.5 ${i < review.overallRating! ? 'text-amber-400 fill-amber-400' : 'text-primary-800'}`}
                      />
                    ))}
                  </div>
                ) : (
                  <span className={`font-pixel text-[7px] px-2 py-1 border rounded ${
                    review.status === 'submitted' ? 'border-green-700 text-green-400 bg-green-950' :
                    'border-amber-700 text-amber-400 bg-amber-950'
                  }`}>
                    {review.status === 'submitted' ? '✓ DONE' : 'PENDING'}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Team Progress */}
      {tab === 'team' && (
        <div className="space-y-2">
          {(teamProgress as Array<{
            employee: { firstName: string; lastName: string; avatarUrl?: string };
            total: number; done: number; completionRate: number;
          }>).map((item, i) => (
            <div key={i} className="bg-retro-card border border-retro-border rounded p-3 flex items-center gap-4">
              <div className="w-8 h-8 bg-primary-900 border border-primary-800 rounded font-pixel text-[7px] text-primary-600 flex items-center justify-center shrink-0">
                {item.employee.firstName[0]}{item.employee.lastName[0]}
              </div>
              <div className="flex-1">
                <p className="font-mono text-sm text-primary-300">{item.employee.firstName} {item.employee.lastName}</p>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex-1 h-1.5 bg-retro-bg rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary-crt rounded-full"
                      style={{ width: `${item.completionRate}%` }}
                    />
                  </div>
                  <span className="font-mono text-[10px] text-primary-700 shrink-0">
                    {item.done}/{item.total} reviews
                  </span>
                </div>
              </div>
              <span className={`font-pixel text-[8px] ${item.completionRate === 100 ? 'text-green-400' : 'text-primary-700'}`}>
                {item.completionRate}%
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
