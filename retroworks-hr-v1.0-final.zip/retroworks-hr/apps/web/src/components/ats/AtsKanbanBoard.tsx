'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Briefcase, Plus, Search, Users, ChevronDown, Mail, Phone, Building2,
  Star, Clock, CheckCircle2, XCircle,
} from 'lucide-react';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
      ...opts?.headers,
    },
  }).then(r => r.json());

const STAGES = [
  { key: 'applied', label: 'Applied', color: 'border-primary-800' },
  { key: 'screening', label: 'Screening', color: 'border-blue-800' },
  { key: 'interview-l1', label: 'L1 Interview', color: 'border-purple-800' },
  { key: 'interview-l2', label: 'L2 Interview', color: 'border-violet-800' },
  { key: 'interview-hr', label: 'HR Round', color: 'border-amber-800' },
  { key: 'offer-sent', label: 'Offer Sent', color: 'border-green-800' },
  { key: 'hired', label: 'Hired', color: 'border-primary-crt' },
];

interface Candidate {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  currentCompany?: string;
  currentDesignation?: string;
  totalExperienceYears?: number;
  expectedCTC?: number;
  stage: string;
  source?: string;
  job: { title: string };
  createdAt: string;
}

function CandidateCard({
  candidate, onMoveStage,
}: {
  candidate: Candidate;
  onMoveStage: (id: string, stage: string) => void;
}) {
  const [showMoveMenu, setShowMoveMenu] = useState(false);
  const stageIdx = STAGES.findIndex(s => s.key === candidate.stage);

  return (
    <div className="bg-retro-bg border border-retro-border rounded p-3 space-y-2 group hover:border-primary-800 transition-all cursor-pointer">
      {/* Name + source */}
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-mono text-sm text-primary-200 font-medium">
            {candidate.firstName} {candidate.lastName}
          </p>
          {candidate.currentDesignation && (
            <p className="font-mono text-[10px] text-primary-700">{candidate.currentDesignation}</p>
          )}
        </div>
        {candidate.source && (
          <span className="px-1.5 py-0.5 bg-retro-card border border-retro-border rounded font-mono text-[9px] text-primary-700 shrink-0">
            {candidate.source}
          </span>
        )}
      </div>

      {/* Company + experience */}
      {(candidate.currentCompany || candidate.totalExperienceYears) && (
        <div className="flex items-center gap-3 text-[10px] font-mono text-primary-700">
          {candidate.currentCompany && (
            <span className="flex items-center gap-1">
              <Building2 className="w-2.5 h-2.5" /> {candidate.currentCompany}
            </span>
          )}
          {candidate.totalExperienceYears !== undefined && (
            <span>{candidate.totalExperienceYears}yr exp</span>
          )}
        </div>
      )}

      {/* Expected CTC */}
      {candidate.expectedCTC && (
        <p className="font-mono text-[10px] text-primary-600">
          ₹{(candidate.expectedCTC / 100000).toFixed(1)}L expected
        </p>
      )}

      {/* Actions */}
      <div className="flex items-center gap-2 pt-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <a href={`mailto:${candidate.email}`} className="text-primary-700 hover:text-primary-400">
          <Mail className="w-3.5 h-3.5" />
        </a>
        <div className="flex-1" />
        <div className="relative">
          <button
            onClick={() => setShowMoveMenu(m => !m)}
            className="flex items-center gap-1 px-2 py-1 border border-retro-border hover:border-primary-700 font-pixel text-[6px] text-primary-600 rounded"
          >
            MOVE <ChevronDown className="w-2.5 h-2.5" />
          </button>
          {showMoveMenu && (
            <div className="absolute right-0 top-full mt-1 bg-retro-card border border-retro-border rounded shadow-lg z-10 min-w-32">
              {STAGES.slice(stageIdx + 1).map(s => (
                <button
                  key={s.key}
                  onClick={() => { onMoveStage(candidate.id, s.key); setShowMoveMenu(false); }}
                  className="w-full text-left px-3 py-1.5 font-mono text-xs text-primary-400 hover:bg-surface-raised hover:text-primary-300"
                >
                  {s.label}
                </button>
              ))}
              <div className="border-t border-retro-border mt-1">
                <button
                  onClick={() => { onMoveStage(candidate.id, 'rejected'); setShowMoveMenu(false); }}
                  className="w-full text-left px-3 py-1.5 font-mono text-xs text-red-400 hover:bg-red-950/30"
                >
                  ✗ Reject
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export function AtsKanbanBoard() {
  const [selectedJob, setSelectedJob] = useState<string | 'all'>('all');
  const [search, setSearch] = useState('');
  const qc = useQueryClient();

  const { data: jobs = [] } = useQuery({
    queryKey: ['ats-jobs'],
    queryFn: () => api('/ats/jobs?status=open').then(r => r.data ?? []),
  });

  const { data: candidatesData } = useQuery({
    queryKey: ['ats-candidates', selectedJob, search],
    queryFn: () => {
      const params = new URLSearchParams({ limit: '200' });
      if (selectedJob !== 'all') params.set('jobId', selectedJob);
      if (search) params.set('search', search);
      return api(`/ats/candidates?${params}`).then(r => r.data);
    },
  });

  const stageMutation = useMutation({
    mutationFn: ({ id, stage }: { id: string; stage: string }) =>
      api(`/ats/candidates/${id}/stage`, { method: 'PATCH', body: JSON.stringify({ stage }) }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['ats-candidates'] }),
  });

  const candidates: Candidate[] = candidatesData?.data ?? [];

  const byStage = (stageKey: string) =>
    candidates.filter(c => c.stage === stageKey);

  return (
    <div className="flex flex-col h-full space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-4 flex-wrap">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">RECRUITMENT PIPELINE</h1>
          <p className="font-mono text-xs text-primary-700 mt-0.5">{candidates.length} candidates tracked</p>
        </div>

        {/* Job filter */}
        <select
          value={selectedJob}
          onChange={e => setSelectedJob(e.target.value)}
          className="px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:border-primary-600 focus:outline-none"
        >
          <option value="all">All Positions</option>
          {(jobs as Array<{ id: string; title: string; _count: { candidates: number } }>).map(j => (
            <option key={j.id} value={j.id}>{j.title} ({j._count?.candidates ?? 0})</option>
          ))}
        </select>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3 h-3 text-primary-700" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search candidates..."
            className="pl-8 pr-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none w-48"
          />
        </div>

        <div className="flex-1" />

        <button className="flex items-center gap-1.5 px-3 py-1.5 bg-primary-900 border border-primary-600 hover:border-primary-crt hover:shadow-glow font-pixel text-[7px] text-primary-crt rounded transition-all">
          <Plus className="w-3 h-3" /> Add Candidate
        </button>
      </div>

      {/* Kanban board */}
      <div className="flex gap-3 overflow-x-auto pb-4 min-h-0 flex-1">
        {STAGES.map(stage => {
          const cols = byStage(stage.key);
          return (
            <div
              key={stage.key}
              className="flex-shrink-0 w-60 flex flex-col"
            >
              {/* Column header */}
              <div className={`flex items-center justify-between px-3 py-2 bg-retro-card border-t-2 ${stage.color} border-x border-b border-retro-border rounded-t`}>
                <span className="font-pixel text-[7px] text-primary-500">{stage.label}</span>
                <span className="font-mono text-[10px] text-primary-700 bg-retro-bg px-1.5 rounded">{cols.length}</span>
              </div>

              {/* Cards */}
              <div className="flex-1 bg-retro-bg/50 border-x border-b border-retro-border rounded-b p-2 space-y-2 overflow-y-auto min-h-24 max-h-[calc(100vh-280px)]">
                {cols.length === 0 ? (
                  <p className="font-mono text-[10px] text-primary-800 text-center py-4">Empty</p>
                ) : (
                  cols.map(c => (
                    <CandidateCard
                      key={c.id}
                      candidate={c}
                      onMoveStage={(id, stage) => stageMutation.mutate({ id, stage })}
                    />
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
