'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Calendar, FileText, Clock, CheckCircle, AlertCircle, Gift,
  BarChart2, DollarSign, Zap, ArrowRight, ChevronRight,
  Sun, Star, TrendingUp, Users,
} from 'lucide-react';
import { formatDistanceToNow, format, isToday } from 'date-fns';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${localStorage.getItem('token') ?? ''}`, ...opts?.headers },
  }).then(r => r.json());

// ─── Mini Widgets ─────────────────────────────────────────

function LeaveBalanceWidget() {
  const { data } = useQuery({ queryKey: ['leave-balance-widget'], queryFn: () => api('/leave/balance/me').then(r => r.data ?? []) });
  const balances: any[] = data ?? [];

  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-blue-400" />
          <p className="font-pixel text-[8px] text-primary-500">LEAVE BALANCE</p>
        </div>
        <a href="/dashboard/leave" className="font-mono text-[9px] text-primary-600 hover:text-primary-400 flex items-center gap-0.5">
          Apply <ChevronRight className="w-3 h-3" />
        </a>
      </div>
      <div className="space-y-2.5">
        {balances.slice(0, 4).map((b: any) => {
          const pct = b.entitled > 0 ? (b.balance / b.entitled) * 100 : 0;
          return (
            <div key={b.id}>
              <div className="flex justify-between font-mono text-xs mb-1">
                <span className="text-primary-500">{b.leaveType?.name}</span>
                <span className="text-primary-300">{b.balance} <span className="text-primary-700">/ {b.entitled} days</span></span>
              </div>
              <div className="h-1.5 bg-retro-bg rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${pct > 50 ? 'bg-green-500' : pct > 25 ? 'bg-yellow-500' : 'bg-red-500'}`}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          );
        })}
        {balances.length === 0 && <p className="font-mono text-xs text-primary-700">No leave types configured</p>}
      </div>
    </div>
  );
}

function AttendanceWidget() {
  const queryClient = useQueryClient();
  const { data: todayStatus } = useQuery({
    queryKey: ['attendance-today'],
    queryFn: () => api('/attendance/today').then(r => r.data),
  });

  const punchMutation = useMutation({
    mutationFn: (type: 'in' | 'out') => api('/attendance/punch', { method: 'POST', body: JSON.stringify({ type }) }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['attendance-today'] }),
  });

  const isPunchedIn = todayStatus?.punchIn && !todayStatus?.punchOut;
  const isPunchedOut = todayStatus?.punchIn && todayStatus?.punchOut;

  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Clock className="w-4 h-4 text-green-400" />
        <p className="font-pixel text-[8px] text-primary-500">ATTENDANCE</p>
      </div>

      <div className="text-center space-y-3">
        <div className={`w-16 h-16 mx-auto rounded-full border-2 flex items-center justify-center transition-all ${
          isPunchedIn ? 'border-green-500 bg-green-950/30 shadow-[0_0_20px_rgba(34,197,94,0.2)]' :
          isPunchedOut ? 'border-primary-700 bg-retro-bg' : 'border-retro-border bg-retro-bg'
        }`}>
          <Clock className={`w-7 h-7 ${isPunchedIn ? 'text-green-400' : 'text-primary-700'}`} />
        </div>

        {todayStatus?.punchIn && (
          <div className="font-mono text-xs text-primary-500">
            In: <span className="text-primary-300">{format(new Date(todayStatus.punchIn), 'hh:mm a')}</span>
            {todayStatus?.punchOut && (
              <> · Out: <span className="text-primary-300">{format(new Date(todayStatus.punchOut), 'hh:mm a')}</span></>
            )}
          </div>
        )}

        {!isPunchedOut && (
          <button
            onClick={() => punchMutation.mutate(isPunchedIn ? 'out' : 'in')}
            disabled={punchMutation.isPending}
            className={`w-full py-2 rounded font-pixel text-[8px] transition-all ${
              isPunchedIn
                ? 'bg-red-950 border border-red-800 text-red-400 hover:border-red-600'
                : 'bg-green-950 border border-green-800 text-green-400 hover:border-green-600'
            }`}
          >
            {punchMutation.isPending ? '…' : isPunchedIn ? 'PUNCH OUT' : 'PUNCH IN'}
          </button>
        )}

        {isPunchedOut && (
          <p className="font-mono text-[10px] text-primary-700">
            {todayStatus?.workingHours?.toFixed(1)}h worked today
          </p>
        )}
      </div>
    </div>
  );
}

function PendingActionsWidget() {
  const { data } = useQuery({
    queryKey: ['pending-actions'],
    queryFn: () => api('/me/pending-actions').then(r => r.data ?? []),
  });

  const pending: any[] = data ?? [];

  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-yellow-400" />
          <p className="font-pixel text-[8px] text-primary-500">PENDING ACTIONS</p>
        </div>
        {pending.length > 0 && (
          <span className="px-2 py-0.5 bg-yellow-950 border border-yellow-800 rounded font-mono text-[9px] text-yellow-400">
            {pending.length}
          </span>
        )}
      </div>

      <div className="space-y-2">
        {pending.length === 0 ? (
          <div className="flex items-center gap-2 py-3">
            <CheckCircle className="w-4 h-4 text-green-400" />
            <p className="font-mono text-xs text-primary-600">All caught up! No pending actions.</p>
          </div>
        ) : pending.map((action: any) => (
          <a key={action.id} href={action.href} className="flex items-center gap-3 p-2.5 bg-retro-bg border border-retro-border rounded hover:border-primary-700 transition-all group">
            <div className="shrink-0 w-6 h-6 rounded flex items-center justify-center bg-yellow-950 border border-yellow-900">
              <AlertCircle className="w-3.5 h-3.5 text-yellow-400" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-mono text-xs text-primary-300 truncate">{action.title}</p>
              {action.due && <p className="font-mono text-[9px] text-primary-700">{formatDistanceToNow(new Date(action.due), { addSuffix: true })}</p>}
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-primary-700 group-hover:text-primary-400" />
          </a>
        ))}
      </div>
    </div>
  );
}

function LatestPayslipWidget() {
  const { data: payslip } = useQuery({
    queryKey: ['latest-payslip'],
    queryFn: () => api('/payroll/payslips/me?limit=1').then(r => r.data?.[0]),
  });

  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <DollarSign className="w-4 h-4 text-yellow-400" />
          <p className="font-pixel text-[8px] text-primary-500">LATEST PAYSLIP</p>
        </div>
        <a href="/dashboard/payroll" className="font-mono text-[9px] text-primary-600 hover:text-primary-400">
          View all →
        </a>
      </div>

      {payslip ? (
        <div className="space-y-3">
          <div>
            <p className="font-pixel text-[8px] text-primary-700">
              {new Date(0, payslip.month - 1).toLocaleString('default', { month: 'long' })} {payslip.year}
            </p>
            <p className="font-mono text-2xl text-primary-crt mt-1">
              ₹{payslip.netPay?.toLocaleString('en-IN')}
            </p>
            <p className="font-mono text-[10px] text-primary-700">Net Pay · Gross ₹{payslip.grossPay?.toLocaleString('en-IN')}</p>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[10px] font-mono">
            <div className="flex justify-between">
              <span className="text-primary-700">PF</span>
              <span className="text-primary-500">₹{payslip.pfDeducted?.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-primary-700">TDS</span>
              <span className="text-primary-500">₹{payslip.tdsDeducted?.toLocaleString('en-IN')}</span>
            </div>
          </div>
          <a
            href={`/dashboard/payroll?payslip=${payslip.id}&action=download`}
            className="flex items-center gap-2 w-full justify-center py-2 border border-retro-border rounded font-pixel text-[7px] text-primary-600 hover:border-primary-600 hover:text-primary-400 transition-all"
          >
            <FileText className="w-3 h-3" /> DOWNLOAD PDF
          </a>
        </div>
      ) : (
        <div className="py-4 text-center">
          <p className="font-mono text-xs text-primary-700">No payslips yet</p>
        </div>
      )}
    </div>
  );
}

function InsightsBannerWidget() {
  const { data } = useQuery({
    queryKey: ['insights-banner'],
    queryFn: () => api('/insights').then(r => r.data ?? []),
  });

  const critical = (data ?? []).filter((i: any) => i.severity === 'critical');
  if (!critical.length) return null;

  return (
    <div className="bg-red-950/30 border border-red-800 rounded-xl p-4 mb-4">
      <div className="flex items-center gap-2 mb-2">
        <AlertCircle className="w-4 h-4 text-red-400" />
        <p className="font-pixel text-[8px] text-red-400">{critical.length} CRITICAL ALERT{critical.length > 1 ? 'S' : ''}</p>
      </div>
      {critical.slice(0, 2).map((i: any) => (
        <div key={i.id} className="flex items-start gap-2 mb-1.5">
          <div className="w-1.5 h-1.5 rounded-full bg-red-500 mt-1.5 shrink-0" />
          <p className="font-mono text-xs text-red-300">{i.title}</p>
        </div>
      ))}
      <a href="/dashboard/insights" className="font-mono text-[10px] text-red-400 hover:text-red-300 flex items-center gap-1 mt-2">
        View all insights <ArrowRight className="w-3 h-3" />
      </a>
    </div>
  );
}

// ─── Upcoming Anniversaries ───────────────────────────────

function TeamEventsWidget() {
  const today = new Date();

  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <Gift className="w-4 h-4 text-pink-400" />
        <p className="font-pixel text-[8px] text-primary-500">TEAM EVENTS</p>
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-3 p-2 rounded bg-retro-bg border border-retro-border">
          <span className="text-lg">🎂</span>
          <div>
            <p className="font-mono text-xs text-primary-300">Priya S. — Birthday Today!</p>
            <p className="font-mono text-[9px] text-primary-700">Engineering · Bengaluru</p>
          </div>
        </div>
        <div className="flex items-center gap-3 p-2 rounded bg-retro-bg border border-retro-border">
          <span className="text-lg">🎉</span>
          <div>
            <p className="font-mono text-xs text-primary-300">Arjun K. — 3 Year Anniversary</p>
            <p className="font-mono text-[9px] text-primary-700">Product · Mumbai</p>
          </div>
        </div>
        <p className="font-mono text-[9px] text-primary-800 text-center pt-1">Powered by live data in production</p>
      </div>
    </div>
  );
}

// ─── Main Employee Home ───────────────────────────────────

export function EmployeeHomePage() {
  const { data: me } = useQuery({
    queryKey: ['me'],
    queryFn: () => api('/employees/me').then(r => r.data),
  });

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Greeting */}
      <div className="flex items-center justify-between">
        <div>
          <p className="font-mono text-xs text-primary-700">{greeting},</p>
          <h1 className="font-pixel text-[13px] text-primary-300 mt-0.5">
            {me?.firstName ?? 'Employee'} {me?.lastName ?? ''}
          </h1>
          <p className="font-mono text-xs text-primary-700 mt-1">
            {me?.designation?.name ?? 'Team Member'} · {me?.department?.name ?? ''}
            {me?.employeeCode && ` · ${me.employeeCode}`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Sun className="w-5 h-5 text-yellow-500 opacity-60" />
          <p className="font-mono text-xs text-primary-700">{format(new Date(), 'EEEE, d MMMM')}</p>
        </div>
      </div>

      {/* Critical Insights Banner (HR managers only) */}
      <InsightsBannerWidget />

      {/* Main Grid */}
      <div className="grid grid-cols-12 gap-4">
        {/* Left column — attendance + leave + payslip */}
        <div className="col-span-3 space-y-4">
          <AttendanceWidget />
          <LatestPayslipWidget />
        </div>

        {/* Center — pending actions + team events */}
        <div className="col-span-5 space-y-4">
          <PendingActionsWidget />
          <LeaveBalanceWidget />
        </div>

        {/* Right — quick links + team events */}
        <div className="col-span-4 space-y-4">
          <TeamEventsWidget />

          {/* Quick Links */}
          <div className="bg-retro-card border border-retro-border rounded-xl p-5">
            <p className="font-pixel text-[8px] text-primary-500 mb-3">QUICK LINKS</p>
            <div className="space-y-1">
              {[
                { label: 'Apply Leave', href: '/dashboard/leave?action=apply', icon: <Calendar className="w-3.5 h-3.5" /> },
                { label: 'View Goals', href: '/dashboard/performance', icon: <Star className="w-3.5 h-3.5" /> },
                { label: 'Submit Expense', href: '/dashboard/expenses?action=new', icon: <DollarSign className="w-3.5 h-3.5" /> },
                { label: 'HR Helpdesk', href: '/dashboard/helpdesk?action=new', icon: <AlertCircle className="w-3.5 h-3.5" /> },
                { label: 'Ask RetroBot', href: '/dashboard/ai', icon: <Zap className="w-3.5 h-3.5" /> },
                { label: 'My Team', href: '/dashboard/employees', icon: <Users className="w-3.5 h-3.5" /> },
              ].map(l => (
                <a key={l.href} href={l.href}
                  className="flex items-center gap-2.5 px-3 py-2 rounded font-mono text-xs text-primary-500 hover:bg-surface-raised hover:text-primary-300 transition-all"
                >
                  <span className="text-primary-700">{l.icon}</span>
                  {l.label}
                  <ChevronRight className="w-3 h-3 ml-auto text-primary-800" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
