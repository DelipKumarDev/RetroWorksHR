'use client';

import { useQuery } from '@tanstack/react-query';
import {
  Calendar, CreditCard, Clock, CheckCircle, AlertTriangle,
  ChevronRight, TrendingUp, Zap, BookOpen, Star, Gift,
  FileText, Users,
} from 'lucide-react';
import Link from 'next/link';

const api = async (path: string) => {
  const res = await fetch(`/api/v1${path}`, {
    headers: { Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}` },
  });
  return res.json();
};

function StatCard({ label, value, sub, icon, href, color = 'primary' }: {
  label: string; value: string | number; sub?: string;
  icon: React.ReactNode; href?: string; color?: string;
}) {
  const content = (
    <div className={`bg-retro-card border border-retro-border rounded-lg p-4 hover:border-primary-700 transition-all group ${href ? 'cursor-pointer' : ''}`}>
      <div className="flex items-start justify-between mb-3">
        <div className={`p-1.5 rounded bg-retro-bg border border-retro-border text-primary-600 group-hover:text-primary-400 transition-colors`}>{icon}</div>
        {href && <ChevronRight className="w-3.5 h-3.5 text-primary-800 group-hover:text-primary-600 transition-colors" />}
      </div>
      <p className="font-pixel text-[16px] text-primary-crt">{value}</p>
      <p className="font-mono text-[10px] text-primary-600 mt-0.5">{label}</p>
      {sub && <p className="font-mono text-[9px] text-primary-800 mt-0.5">{sub}</p>}
    </div>
  );
  return href ? <Link href={href}>{content}</Link> : content;
}

function PendingActionCard({ title, description, type, href }: {
  title: string; description: string; type: 'urgent' | 'pending' | 'info'; href: string;
}) {
  const colors = {
    urgent: 'border-red-900 bg-red-950/20',
    pending: 'border-yellow-900 bg-yellow-950/10',
    info: 'border-primary-900 bg-primary-950/20',
  };
  const icons = {
    urgent: <AlertTriangle className="w-3.5 h-3.5 text-red-400" />,
    pending: <Clock className="w-3.5 h-3.5 text-yellow-400" />,
    info: <CheckCircle className="w-3.5 h-3.5 text-blue-400" />,
  };

  return (
    <Link href={href}>
      <div className={`flex items-center gap-3 px-4 py-3 border rounded-lg transition-all hover:opacity-80 ${colors[type]}`}>
        <div className="shrink-0">{icons[type]}</div>
        <div className="flex-1 min-w-0">
          <p className="font-mono text-sm text-primary-300 truncate">{title}</p>
          <p className="font-mono text-[10px] text-primary-700 truncate">{description}</p>
        </div>
        <ChevronRight className="w-3.5 h-3.5 text-primary-700 shrink-0" />
      </div>
    </Link>
  );
}

function LeaveBalanceBar({ label, used, total, color }: { label: string; used: number; total: number; color: string }) {
  const pct = total > 0 ? Math.min((used / total) * 100, 100) : 0;
  return (
    <div>
      <div className="flex justify-between font-mono text-xs mb-1">
        <span className="text-primary-600">{label}</span>
        <span className="text-primary-400">{total - used} / {total} remaining</span>
      </div>
      <div className="h-1.5 bg-retro-bg rounded-full overflow-hidden border border-retro-border">
        <div className={`h-full rounded-full ${color} transition-all duration-700`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function EmployeeHomeDashboard() {
  const { data: me } = useQuery({ queryKey: ['me'], queryFn: () => api('/employees/me').then(r => r.data), staleTime: 60000 });
  const { data: leaveBalance = [] } = useQuery({ queryKey: ['leave-balance-me'], queryFn: () => api('/leave/balance/me').then(r => r.data ?? []) });
  const { data: payslips = [] } = useQuery({ queryKey: ['payslips-me'], queryFn: () => api('/payroll/payslips/me').then(r => r.data ?? []) });
  const { data: notifCount = 0 } = useQuery({ queryKey: ['notif-count'], queryFn: () => api('/notifications/count').then(r => r.data ?? 0) });
  const { data: attendance } = useQuery({ queryKey: ['attendance-today'], queryFn: () => api('/attendance/today').then(r => r.data) });
  const { data: announcements = [] } = useQuery({ queryKey: ['announcements-recent'], queryFn: () => api('/announcements?limit=3').then(r => r.data ?? []) });
  const { data: myGoals = [] } = useQuery({ queryKey: ['goals-me'], queryFn: () => api('/performance/goals/me').then(r => r.data ?? []) });
  const { data: myLearning } = useQuery({ queryKey: ['learning-me'], queryFn: () => api('/lnd/my-learning').then(r => r.data) });

  const latestPayslip = (payslips as any[])[0];
  const clLeave = (leaveBalance as any[]).find((l: any) => l.leaveType?.code === 'CL');
  const slLeave = (leaveBalance as any[]).find((l: any) => l.leaveType?.code === 'SL');
  const elLeave = (leaveBalance as any[]).find((l: any) => l.leaveType?.code === 'EL');

  const today = new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' });
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';
  const clockedIn = attendance?.checkIn && !attendance?.checkOut;
  const daysToAnniversary = me?.dateOfJoining
    ? (() => {
        const doj = new Date(me.dateOfJoining);
        const thisYear = new Date(new Date().getFullYear(), doj.getMonth(), doj.getDate());
        const diff = Math.ceil((thisYear.getTime() - Date.now()) / 86_400_000);
        return diff >= 0 && diff <= 7 ? diff : null;
      })()
    : null;

  // Build pending actions
  const pendingActions = [];
  if (!attendance?.checkIn) pendingActions.push({ title: 'Clock In', description: "You haven't clocked in today", type: 'pending' as const, href: '/dashboard/attendance' });
  if (notifCount > 0) pendingActions.push({ title: `${notifCount} unread notification${notifCount > 1 ? 's' : ''}`, description: 'Check your notifications', type: 'info' as const, href: '/dashboard/notifications' });
  const incompleteGoals = (myGoals as any[]).filter((g: any) => (g.progress ?? 0) < 100).length;
  if (incompleteGoals > 0) pendingActions.push({ title: `${incompleteGoals} goal${incompleteGoals > 1 ? 's' : ''} need progress update`, description: 'Update your OKR progress', type: 'pending' as const, href: '/dashboard/performance' });
  if (myLearning?.inProgress > 0) pendingActions.push({ title: `${myLearning.inProgress} course${myLearning.inProgress > 1 ? 's' : ''} in progress`, description: 'Continue your learning journey', type: 'info' as const, href: '/dashboard/lnd' });

  const quickLinks = [
    { label: 'Apply Leave', icon: <Calendar className="w-3.5 h-3.5" />, href: '/dashboard/leave?apply=true' },
    { label: 'My Payslips', icon: <CreditCard className="w-3.5 h-3.5" />, href: '/dashboard/payroll' },
    { label: 'Raise Ticket', icon: <Zap className="w-3.5 h-3.5" />, href: '/dashboard/helpdesk?new=true' },
    { label: 'My Goals', icon: <TrendingUp className="w-3.5 h-3.5" />, href: '/dashboard/performance' },
    { label: 'Browse Courses', icon: <BookOpen className="w-3.5 h-3.5" />, href: '/dashboard/lnd' },
    { label: 'My Team', icon: <Users className="w-3.5 h-3.5" />, href: '/dashboard/employees?team=me' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Greeting header */}
      <div className="flex items-start justify-between">
        <div>
          <p className="font-mono text-xs text-primary-700">{today}</p>
          <h1 className="font-pixel text-[13px] text-primary-crt mt-1">
            {greeting}, {me?.firstName ?? '—'}! 👋
          </h1>
          {daysToAnniversary !== null && (
            <div className="flex items-center gap-2 mt-2 px-3 py-1.5 bg-yellow-950/30 border border-yellow-900 rounded-lg w-fit">
              <Gift className="w-3.5 h-3.5 text-yellow-400" />
              <span className="font-mono text-xs text-yellow-400">
                {daysToAnniversary === 0 ? '🎉 Happy Work Anniversary!' : `Work anniversary in ${daysToAnniversary} day${daysToAnniversary > 1 ? 's' : ''}!`}
              </span>
            </div>
          )}
        </div>

        {/* Clock in/out status */}
        <div className={`flex items-center gap-2 px-4 py-2.5 rounded-lg border font-mono text-xs ${
          clockedIn ? 'bg-green-950/30 border-green-900 text-green-400' : 'bg-retro-bg border-retro-border text-primary-600'
        }`}>
          <Clock className="w-4 h-4" />
          {clockedIn ? `Clocked in at ${new Date(attendance.checkIn).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}` : 'Not clocked in'}
        </div>
      </div>

      <div className="grid grid-cols-12 gap-5">
        {/* Left column */}
        <div className="col-span-8 space-y-5">
          {/* Stats row */}
          <div className="grid grid-cols-4 gap-3">
            <StatCard label="Casual Leave Left" value={clLeave ? clLeave.balance - clLeave.pending : '—'} sub={`of ${clLeave?.entitled ?? '—'} days`} icon={<Calendar className="w-4 h-4" />} href="/dashboard/leave" />
            <StatCard label="Sick Leave Left" value={slLeave ? slLeave.balance - slLeave.pending : '—'} sub={`of ${slLeave?.entitled ?? '—'} days`} icon={<Calendar className="w-4 h-4" />} href="/dashboard/leave" />
            <StatCard label="Net Pay (Last)" value={latestPayslip ? `₹${Number(latestPayslip.netPay).toLocaleString('en-IN')}` : '—'} sub={latestPayslip ? `${latestPayslip.month}/${latestPayslip.year}` : 'No payslip yet'} icon={<CreditCard className="w-4 h-4" />} href="/dashboard/payroll" />
            <StatCard label="Goals Complete" value={`${(myGoals as any[]).filter((g: any) => g.progress >= 100).length}/${(myGoals as any[]).length}`} sub="This review cycle" icon={<Star className="w-4 h-4" />} href="/dashboard/performance" />
          </div>

          {/* Pending Actions */}
          {pendingActions.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <p className="font-pixel text-[8px] text-primary-500">PENDING ACTIONS</p>
                <span className="px-1.5 py-0.5 bg-yellow-950 border border-yellow-900 rounded font-mono text-[8px] text-yellow-400">{pendingActions.length}</span>
              </div>
              <div className="space-y-2">
                {pendingActions.map((a, i) => <PendingActionCard key={i} {...a} />)}
              </div>
            </div>
          )}

          {/* Announcements */}
          {(announcements as any[]).length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="font-pixel text-[8px] text-primary-500">ANNOUNCEMENTS</p>
                <Link href="/dashboard/announcements" className="font-mono text-[9px] text-primary-700 hover:text-primary-500">View all →</Link>
              </div>
              <div className="space-y-2">
                {(announcements as any[]).map((a: any) => (
                  <div key={a.id} className="p-4 bg-retro-card border border-retro-border rounded-lg">
                    <div className="flex items-start gap-2">
                      <FileText className="w-3.5 h-3.5 text-primary-600 mt-0.5 shrink-0" />
                      <div>
                        <p className="font-mono text-sm text-primary-300">{a.title}</p>
                        <p className="font-mono text-[10px] text-primary-700 mt-0.5 line-clamp-2">{a.content}</p>
                        <p className="font-mono text-[9px] text-primary-800 mt-1">{new Date(a.publishedAt ?? a.createdAt).toLocaleDateString('en-IN')}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right column */}
        <div className="col-span-4 space-y-5">
          {/* Quick links */}
          <div>
            <p className="font-pixel text-[8px] text-primary-500 mb-3">QUICK ACTIONS</p>
            <div className="grid grid-cols-2 gap-2">
              {quickLinks.map(l => (
                <Link key={l.label} href={l.href}>
                  <div className="flex flex-col items-center gap-2 p-3 bg-retro-card border border-retro-border rounded-lg hover:border-primary-700 hover:bg-surface-raised transition-all text-center">
                    <div className="text-primary-600">{l.icon}</div>
                    <p className="font-mono text-[10px] text-primary-500">{l.label}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Leave balances */}
          <div className="bg-retro-card border border-retro-border rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <p className="font-pixel text-[8px] text-primary-500">LEAVE BALANCES</p>
              <Link href="/dashboard/leave" className="font-mono text-[9px] text-primary-700 hover:text-primary-500">View →</Link>
            </div>
            <div className="space-y-3">
              {clLeave && <LeaveBalanceBar label="Casual Leave" used={clLeave.used + clLeave.pending} total={clLeave.entitled} color="bg-blue-500" />}
              {slLeave && <LeaveBalanceBar label="Sick Leave" used={slLeave.used + slLeave.pending} total={slLeave.entitled} color="bg-green-500" />}
              {elLeave && <LeaveBalanceBar label="Earned Leave" used={elLeave.used + elLeave.pending} total={elLeave.entitled} color="bg-purple-500" />}
            </div>
          </div>

          {/* Learning in progress */}
          {myLearning && (
            <div className="bg-retro-card border border-retro-border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <p className="font-pixel text-[8px] text-primary-500">MY LEARNING</p>
                <Link href="/dashboard/lnd" className="font-mono text-[9px] text-primary-700 hover:text-primary-500">View →</Link>
              </div>
              <div className="space-y-2 font-mono text-xs">
                {[['Enrolled', myLearning.enrolled], ['In Progress', myLearning.inProgress], ['Completed', myLearning.completed]].map(([label, val]) => (
                  <div key={label as string} className="flex justify-between">
                    <span className="text-primary-700">{label}</span>
                    <span className="text-primary-400">{val ?? 0}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
