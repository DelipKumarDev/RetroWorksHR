'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Settings, Users, Calendar, Zap, Shield, Building2,
  MapPin, ToggleLeft, ToggleRight, CheckCircle, XCircle, Plus, Edit,
} from 'lucide-react';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
      ...opts?.headers,
    },
  });
  return res.json();
};

type Tab = 'roles' | 'leave-types' | 'integrations' | 'features' | 'payroll' | 'departments' | 'audit';

function FeatureRow({ label, description, value, onToggle }: {
  label: string; description: string; value: boolean; onToggle: () => void;
}) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-retro-border/50">
      <div>
        <p className="font-mono text-sm text-primary-400">{label}</p>
        <p className="font-mono text-xs text-primary-700 mt-0.5">{description}</p>
      </div>
      <button onClick={onToggle} className="shrink-0 ml-4">
        {value
          ? <ToggleRight className="w-8 h-8 text-primary-crt" />
          : <ToggleLeft className="w-8 h-8 text-primary-700" />
        }
      </button>
    </div>
  );
}

function IntegrationCard({ name, icon, description, connected, type, onConnect, onDisconnect }: {
  name: string; icon: string; description: string; type: string;
  connected?: { status: string }; onConnect: (type: string) => void; onDisconnect: (type: string) => void;
}) {
  const isConnected = connected?.status === 'active';
  return (
    <div className="bg-retro-bg border border-retro-border rounded-lg p-4">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <span className="text-2xl">{icon}</span>
          <div>
            <p className="font-mono text-sm text-primary-300 font-medium">{name}</p>
            <p className="font-mono text-xs text-primary-700 mt-0.5">{description}</p>
          </div>
        </div>
        {isConnected
          ? <CheckCircle className="w-4 h-4 text-green-400" />
          : <XCircle className="w-4 h-4 text-primary-800" />
        }
      </div>
      <div className="flex gap-2 mt-3">
        {isConnected ? (
          <button
            onClick={() => onDisconnect(type)}
            className="px-3 py-1.5 border border-red-800 rounded font-mono text-xs text-red-400 hover:border-red-600 transition-all"
          >
            Disconnect
          </button>
        ) : (
          <button
            onClick={() => onConnect(type)}
            className="px-3 py-1.5 bg-primary-900 border border-primary-700 rounded font-mono text-xs text-primary-400 hover:border-primary-500 transition-all"
          >
            Connect
          </button>
        )}
        {isConnected && (
          <span className="flex items-center font-mono text-[10px] text-green-400 gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" /> Active
          </span>
        )}
      </div>
    </div>
  );
}

export function SettingsPage() {
  const [tab, setTab] = useState<Tab>('roles');
  const queryClient = useQueryClient();

  const { data: roles } = useQuery({
    queryKey: ['settings-roles'],
    queryFn: () => api('/settings/roles').then(r => r.data),
    enabled: tab === 'roles',
  });

  const { data: leaveTypes = [] } = useQuery<any[]>({
    queryKey: ['settings-leave-types'],
    queryFn: () => api('/settings/leave-types').then(r => r.data ?? []),
    enabled: tab === 'leave-types',
  });

  const { data: integrations = [] } = useQuery<any[]>({
    queryKey: ['settings-integrations'],
    queryFn: () => api('/integrations').then(r => r.data ?? []),
    enabled: tab === 'integrations',
  });

  const { data: features, refetch: refetchFeatures } = useQuery<Record<string, boolean>>({
    queryKey: ['settings-features'],
    queryFn: () => api('/settings/features').then(r => r.data ?? {}),
    enabled: tab === 'features',
  });

  const { data: payrollConfig } = useQuery<any>({
    queryKey: ['settings-payroll'],
    queryFn: () => api('/settings/payroll').then(r => r.data),
    enabled: tab === 'payroll',
  });

  const { data: auditLog = [] } = useQuery<any[]>({
    queryKey: ['audit-log'],
    queryFn: () => api('/settings/audit-log').then(r => r.data ?? []),
    enabled: tab === 'audit',
  });

  const toggleFeature = useMutation({
    mutationFn: (newFlags: Record<string, boolean>) =>
      api('/settings/features', { method: 'PATCH', body: JSON.stringify(newFlags) }),
    onSuccess: () => refetchFeatures(),
  });

  const disconnectMutation = useMutation({
    mutationFn: (type: string) => api(`/integrations/${type}/disconnect`, { method: 'POST' }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['settings-integrations'] }),
  });

  const FEATURE_DEFS = [
    { key: 'ai', label: 'AI HR Assistant (RetroBot)', description: 'RAG-powered HR chatbot with policy Q&A and resume parsing' },
    { key: 'slackIntegration', label: 'Slack Integration', description: 'Leave notifications, birthday messages, slash commands' },
    { key: 'zoomIntegration', label: 'Zoom Integration', description: 'Auto-create Zoom meetings for interview scheduling' },
    { key: 'advancedReports', label: 'Advanced Reports', description: 'Attrition trends, diversity analytics, payroll breakdowns' },
    { key: 'lnd', label: 'Learning & Development', description: 'Course catalog, enrollments, learning paths' },
    { key: 'expenses', label: 'Expense Management', description: 'Claim submission, approval, and reimbursement tracking' },
    { key: 'helpdesk', label: 'HR Helpdesk', description: 'Ticket system with SLA tracking and knowledge base' },
  ];

  const TABS = [
    { key: 'roles', label: 'Roles & Permissions', icon: <Shield className="w-3 h-3" /> },
    { key: 'leave-types', label: 'Leave Types', icon: <Calendar className="w-3 h-3" /> },
    { key: 'integrations', label: 'Integrations', icon: <Zap className="w-3 h-3" /> },
    { key: 'features', label: 'Feature Flags', icon: <ToggleRight className="w-3 h-3" /> },
    { key: 'payroll', label: 'Payroll Config', icon: <Settings className="w-3 h-3" /> },
    { key: 'audit', label: 'Audit Log', icon: <Shield className="w-3 h-3" /> },
  ] as const;

  return (
    <div className="space-y-5 animate-fade-in">
      <div>
        <h1 className="font-pixel text-[10px] text-primary-400">SETTINGS</h1>
        <p className="font-mono text-xs text-primary-700 mt-1">Tenant configuration, roles & integrations</p>
      </div>

      <div className="flex gap-0 border-b border-retro-border overflow-x-auto">
        {TABS.map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 px-4 py-2 font-pixel text-[8px] whitespace-nowrap border-b-2 transition-all ${
              tab === t.key ? 'border-primary-crt text-primary-crt' : 'border-transparent text-primary-700 hover:text-primary-500'
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* ── Roles ── */}
      {tab === 'roles' && roles && (
        <div className="grid grid-cols-2 gap-5">
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="font-pixel text-[8px] text-primary-500">SYSTEM ROLES</p>
            </div>
            <div className="space-y-2">
              {(roles.systemRoles ?? []).map((r: any) => (
                <div key={r.name} className="bg-retro-card border border-retro-border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-sm text-primary-300 font-medium">{r.name}</span>
                    <span className="px-2 py-0.5 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-700">System</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {(r.permissions.includes('*') ? ['All permissions'] : r.permissions.slice(0, 5)).map((p: string) => (
                      <span key={p} className="px-1.5 py-0.5 bg-primary-950 border border-primary-900 rounded font-mono text-[8px] text-primary-700">{p}</span>
                    ))}
                    {!r.permissions.includes('*') && r.permissions.length > 5 && (
                      <span className="px-1.5 py-0.5 font-mono text-[8px] text-primary-800">+{r.permissions.length - 5} more</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="font-pixel text-[8px] text-primary-500">CUSTOM ROLES</p>
              <button className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border rounded font-pixel text-[7px] text-primary-600 hover:text-primary-400">
                <Plus className="w-3 h-3" /> New Role
              </button>
            </div>
            {(roles.customRoles ?? []).length === 0 ? (
              <div className="bg-retro-card border border-retro-border rounded-lg p-8 text-center">
                <Shield className="w-8 h-8 text-primary-800 mx-auto mb-2" />
                <p className="font-pixel text-[7px] text-primary-700">No custom roles yet</p>
              </div>
            ) : (roles.customRoles ?? []).map((r: any) => (
              <div key={r.id} className="bg-retro-card border border-retro-border rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-sm text-primary-300">{r.name}</span>
                  <button className="p-1 text-primary-700 hover:text-primary-400"><Edit className="w-3.5 h-3.5" /></button>
                </div>
                <p className="font-mono text-xs text-primary-700 mt-1">{r._count?.assignments ?? 0} members</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Leave Types ── */}
      {tab === 'leave-types' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <p className="font-pixel text-[8px] text-primary-500">CONFIGURED LEAVE TYPES ({leaveTypes.length})</p>
            <button className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border rounded font-pixel text-[7px] text-primary-600 hover:text-primary-400 hover:border-primary-600">
              <Plus className="w-3 h-3" /> Add Leave Type
            </button>
          </div>
          <div className="bg-retro-card border border-retro-border rounded-lg overflow-hidden">
            <table className="w-full text-xs">
              <thead><tr className="border-b border-retro-border bg-retro-bg">
                {['Code', 'Name', 'Entitled Days', 'Paid', 'Approval', 'Half Day', 'Accrual', 'Active', ''].map(h => (
                  <th key={h} className="py-2 px-3 font-pixel text-[7px] text-primary-700 text-left">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {leaveTypes.map((lt: any) => (
                  <tr key={lt.id} className="border-b border-retro-border/30 hover:bg-surface-raised">
                    <td className="py-2 px-3 font-mono text-primary-500 font-medium">{lt.code}</td>
                    <td className="py-2 px-3 font-mono text-primary-300">{lt.name}</td>
                    <td className="py-2 px-3 font-mono text-primary-400">{lt.entitledDays}</td>
                    <td className="py-2 px-3">{lt.isPaid ? <span className="text-green-400">✓</span> : <span className="text-red-400">✗</span>}</td>
                    <td className="py-2 px-3">{lt.requiresApproval ? <span className="text-yellow-400">Required</span> : <span className="text-primary-600">Auto</span>}</td>
                    <td className="py-2 px-3">{lt.allowHalfDay ? <span className="text-green-400">✓</span> : <span className="text-primary-700">—</span>}</td>
                    <td className="py-2 px-3">{lt.accrualEnabled ? <span className="text-blue-400">✓</span> : <span className="text-primary-700">—</span>}</td>
                    <td className="py-2 px-3">{lt.isActive ? <CheckCircle className="w-3.5 h-3.5 text-green-400" /> : <XCircle className="w-3.5 h-3.5 text-red-400" />}</td>
                    <td className="py-2 px-3"><button className="text-primary-700 hover:text-primary-400"><Edit className="w-3 h-3" /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── Integrations ── */}
      {tab === 'integrations' && (
        <div className="grid grid-cols-2 gap-4">
          {integrations.map((intg: any) => (
            <IntegrationCard
              key={intg.type}
              name={intg.name}
              icon={intg.icon}
              description={intg.description}
              type={intg.type}
              connected={intg.connected}
              onConnect={(type) => alert(`OAuth flow for ${type} — configure in .env and visit /integrations/${type}/connect`)}
              onDisconnect={(type) => disconnectMutation.mutate(type)}
            />
          ))}
        </div>
      )}

      {/* ── Feature Flags ── */}
      {tab === 'features' && features && (
        <div className="bg-retro-card border border-retro-border rounded-lg p-5">
          <p className="font-pixel text-[8px] text-primary-500 mb-4">FEATURE FLAGS</p>
          <div className="space-y-0">
            {FEATURE_DEFS.map(f => (
              <FeatureRow
                key={f.key}
                label={f.label}
                description={f.description}
                value={features[f.key] ?? false}
                onToggle={() => toggleFeature.mutate({ ...features, [f.key]: !features[f.key] })}
              />
            ))}
          </div>
          <p className="font-mono text-[9px] text-primary-700 mt-4">Changes take effect immediately. No restart required.</p>
        </div>
      )}

      {/* ── Payroll Config ── */}
      {tab === 'payroll' && (
        <div className="grid grid-cols-2 gap-5">
          <div className="bg-retro-card border border-retro-border rounded-lg p-5 space-y-4">
            <p className="font-pixel text-[8px] text-primary-500">PAYROLL CONFIGURATION</p>
            <div className="space-y-3 font-mono text-xs">
              {payrollConfig ? [
                ['Default Tax Regime', payrollConfig.defaultTaxRegime?.toUpperCase()],
                ['Working Days / Month', payrollConfig.defaultWorkingDays],
                ['PF Opt-In by Default', payrollConfig.defaultPfOptIn ? 'Yes' : 'No'],
                ['Auto-Run Payroll', payrollConfig.autoRun ? 'Enabled' : 'Disabled'],
                ['Run Day', payrollConfig.runDay ? `${payrollConfig.runDay}th of each month` : 'Manual'],
                ['Salary Revision Month', payrollConfig.salaryRevisionMonth ? `Month ${payrollConfig.salaryRevisionMonth}` : 'April'],
              ].map(([label, value]) => (
                <div key={label as string} className="flex justify-between py-1.5 border-b border-retro-border/50">
                  <span className="text-primary-600">{label}</span>
                  <span className="text-primary-300">{value}</span>
                </div>
              )) : <p className="text-primary-700">No payroll config found. Default settings apply.</p>}
            </div>
            <button className="px-3 py-2 border border-retro-border rounded font-pixel text-[7px] text-primary-600 hover:text-primary-400 hover:border-primary-600 transition-all">
              Edit Config
            </button>
          </div>

          <div className="bg-retro-card border border-retro-border rounded-lg p-5">
            <p className="font-pixel text-[8px] text-primary-500 mb-4">STATUTORY RATES (FY 2024-25)</p>
            <div className="space-y-2 font-mono text-xs">
              {[
                ['PF — Employee', '12% of basic (≤₹15,000 ceiling)'],
                ['PF — Employer (EPF)', '3.67% of basic'],
                ['PF — Employer (EPS)', '8.33% of basic'],
                ['PF Admin Charge', '0.5% of PF wage'],
                ['ESI — Employee', '0.75% of gross (if ≤₹21,000)'],
                ['ESI — Employer', '3.25% of gross'],
                ['Standard Deduction', '₹75,000 / year'],
                ['New Regime Rebate', '₹25,000 (if income ≤₹7L)'],
                ['HEC Cess', '4% on tax + surcharge'],
              ].map(([label, value]) => (
                <div key={label} className="flex justify-between py-1 border-b border-retro-border/30">
                  <span className="text-primary-600">{label}</span>
                  <span className="text-primary-400 text-right max-w-40">{value}</span>
                </div>
              ))}
            </div>
            <p className="font-mono text-[9px] text-primary-800 mt-3">Rates are hardcoded per Finance Act 2024. Update via code when Budget changes.</p>
          </div>
        </div>
      )}

      {/* ── Audit Log ── */}
      {tab === 'audit' && (
        <div className="bg-retro-card border border-retro-border rounded-lg overflow-hidden">
          <div className="px-4 py-2 bg-retro-bg border-b border-retro-border">
            <p className="font-pixel text-[7px] text-primary-600">AUDIT LOG — Last 50 events</p>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead><tr className="border-b border-retro-border">
                {['Time', 'User', 'Action', 'Resource', 'Details'].map(h => (
                  <th key={h} className="py-2 px-3 font-pixel text-[7px] text-primary-700 text-left">{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {auditLog.length === 0 ? (
                  <tr><td colSpan={5} className="py-8 text-center font-mono text-xs text-primary-700">No audit events found</td></tr>
                ) : auditLog.map((log: any) => (
                  <tr key={log.id} className="border-b border-retro-border/30 hover:bg-surface-raised">
                    <td className="py-2 px-3 font-mono text-[10px] text-primary-700">{new Date(log.createdAt).toLocaleString('en-IN')}</td>
                    <td className="py-2 px-3 font-mono text-primary-500">{log.user?.firstName} {log.user?.lastName}</td>
                    <td className="py-2 px-3"><span className="px-1.5 py-0.5 bg-primary-950 border border-primary-900 rounded font-mono text-[8px] text-primary-500">{log.action}</span></td>
                    <td className="py-2 px-3 font-mono text-primary-600">{log.resource}</td>
                    <td className="py-2 px-3 font-mono text-[10px] text-primary-700 truncate max-w-48">{JSON.stringify(log.newData ?? {})}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
