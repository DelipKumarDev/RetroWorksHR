'use client';

import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, CheckCircle2, XCircle, AlertTriangle, Play, RotateCcw, Database } from 'lucide-react';
import type { Metadata } from 'next';

interface PreviewRow {
  row: number;
  data: Record<string, string>;
  errors: string[];
  warnings: string[];
  isDuplicate: boolean;
}

interface PreviewResult {
  total: number;
  valid: number;
  invalid: number;
  duplicates: number;
  rows: PreviewRow[];
  columnMapping: Record<string, string>;
}

type Step = 'upload' | 'mapping' | 'preview' | 'importing' | 'done';

// Parse CSV text to rows
function parseCsv(text: string): { headers: string[]; rows: Record<string, string>[] } {
  const lines = text.trim().split('\n');
  const headers = (lines[0] ?? '').split(',').map(h => h.trim().replace(/^"|"$/g, ''));
  const rows = lines.slice(1).map(line => {
    const values = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
    return Object.fromEntries(headers.map((h, i) => [h, values[i] ?? '']));
  });
  return { headers, rows };
}

export function DataOpsConsole() {
  const [step, setStep] = useState<Step>('upload');
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [csvRows, setCsvRows] = useState<Record<string, string>[]>([]);
  const [columnMapping, setColumnMapping] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<PreviewResult | null>(null);
  const [importResult, setImportResult] = useState<{ jobId: string } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [fileName, setFileName] = useState('');

  const DB_FIELDS = [
    { label: '— Skip —', value: '' },
    { label: 'Employee Code *', value: 'employeeCode' },
    { label: 'First Name *', value: 'firstName' },
    { label: 'Last Name *', value: 'lastName' },
    { label: 'Work Email *', value: 'workEmail' },
    { label: 'Date of Joining *', value: 'dateOfJoining' },
    { label: 'Personal Email', value: 'email' },
    { label: 'Phone', value: 'phone' },
    { label: 'Gender', value: 'gender' },
    { label: 'Date of Birth', value: 'dateOfBirth' },
    { label: 'Employment Type', value: 'employmentType' },
    { label: 'Department', value: 'departmentId' },
    { label: 'Designation', value: 'designationId' },
    { label: 'Location', value: 'locationId' },
    { label: 'Manager ID', value: 'managerId' },
    { label: 'Notice Period (Days)', value: 'noticePeriodDays' },
    { label: 'PAN Number', value: 'panNumber' },
    { label: 'UAN Number', value: 'uanNumber' },
    { label: 'Bank Account', value: 'bankAccountNumber' },
    { label: 'IFSC Code', value: 'ifscCode' },
  ];

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target?.result as string;
      const { headers, rows } = parseCsv(text);
      setCsvHeaders(headers);
      setCsvRows(rows);

      // Auto-map obvious columns
      const autoMapping: Record<string, string> = {};
      for (const h of headers) {
        const normalized = h.toLowerCase().replace(/\s+/g, '');
        if (normalized.includes('empcode') || normalized.includes('employeeid')) autoMapping[h] = 'employeeCode';
        else if (normalized.includes('firstname') || normalized === 'first') autoMapping[h] = 'firstName';
        else if (normalized.includes('lastname') || normalized === 'last') autoMapping[h] = 'lastName';
        else if (normalized.includes('email') && normalized.includes('work')) autoMapping[h] = 'workEmail';
        else if (normalized.includes('email')) autoMapping[h] = 'workEmail';
        else if (normalized.includes('joining') || normalized.includes('doj')) autoMapping[h] = 'dateOfJoining';
        else if (normalized.includes('phone')) autoMapping[h] = 'phone';
        else if (normalized.includes('gender')) autoMapping[h] = 'gender';
        else if (normalized.includes('department') || normalized.includes('dept')) autoMapping[h] = 'departmentId';
      }
      setColumnMapping(autoMapping);
      setStep('mapping');
    };
    reader.readAsText(file);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/csv': ['.csv'], 'application/vnd.ms-excel': ['.xls', '.xlsx'] },
    maxFiles: 1,
  });

  const runPreview = async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/v1/dataops/preview', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token') ?? ''}`,
        },
        body: JSON.stringify({ entity: 'employee', rows: csvRows, columnMapping }),
      });
      const json = await res.json() as { data: PreviewResult };
      setPreview(json.data);
      setStep('preview');
    } catch {
      // handle error
    } finally {
      setIsLoading(false);
    }
  };

  const executeImport = async () => {
    if (!preview) return;
    setStep('importing');
    setIsLoading(true);
    try {
      const validRows = preview.rows.filter(r => r.errors.length === 0).map(r => r.data);
      const res = await fetch('/api/v1/dataops/import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token') ?? ''}`,
        },
        body: JSON.stringify({ entity: 'employee', rows: validRows }),
      });
      const json = await res.json() as { data: { jobId: string } };
      setImportResult(json.data);
      setStep('done');
    } finally {
      setIsLoading(false);
    }
  };

  const reset = () => {
    setStep('upload');
    setCsvHeaders([]);
    setCsvRows([]);
    setColumnMapping({});
    setPreview(null);
    setImportResult(null);
    setFileName('');
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">DATAOPS CONSOLE</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">Import, validate, and manage bulk data</p>
        </div>
        {step !== 'upload' && (
          <button onClick={reset} className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border hover:border-primary-700 font-pixel text-[8px] text-primary-600 rounded transition-all">
            <RotateCcw className="w-3 h-3" /> Start Over
          </button>
        )}
      </div>

      {/* Step indicator */}
      <div className="flex items-center gap-0 font-pixel text-[7px]">
        {(['upload', 'mapping', 'preview', 'done'] as const).map((s, i) => (
          <div key={s} className="flex items-center">
            <div className={`px-3 py-1.5 border transition-all ${
              step === s ? 'border-primary-crt bg-primary-950 text-primary-crt shadow-glow' :
              ['upload', 'mapping', 'preview', 'done'].indexOf(step) > i
                ? 'border-primary-700 bg-primary-950/50 text-primary-600'
                : 'border-retro-border text-primary-800'
            }`}>
              {i + 1}. {s.toUpperCase()}
            </div>
            {i < 3 && <span className="text-primary-800 px-1">→</span>}
          </div>
        ))}
      </div>

      {/* STEP 1: Upload */}
      {step === 'upload' && (
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-all ${
            isDragActive
              ? 'border-primary-crt bg-primary-950/50 shadow-glow'
              : 'border-retro-border hover:border-primary-700 hover:bg-surface-raised'
          }`}
        >
          <input {...getInputProps()} aria-label="Upload CSV file" />
          <Upload className="w-10 h-10 text-primary-700 mx-auto mb-4" />
          <p className="font-pixel text-[9px] text-primary-500 mb-2">
            DROP CSV FILE HERE
          </p>
          <p className="font-mono text-xs text-primary-700">
            or click to browse · CSV, XLS, XLSX supported
          </p>
          <p className="font-mono text-[10px] text-primary-800 mt-2">
            Max 10MB · Up to 10,000 rows
          </p>
        </div>
      )}

      {/* STEP 2: Column Mapping */}
      {step === 'mapping' && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-primary-600" />
            <span className="font-mono text-sm text-primary-400">{fileName}</span>
            <span className="font-mono text-xs text-primary-700">· {csvRows.length} rows · {csvHeaders.length} columns</span>
          </div>

          <div className="bg-retro-card border border-retro-border rounded overflow-hidden">
            <div className="px-4 py-3 border-b border-retro-border bg-retro-bg">
              <p className="font-pixel text-[8px] text-primary-500">COLUMN MAPPING</p>
              <p className="font-mono text-xs text-primary-700 mt-0.5">Map your CSV columns to HR fields</p>
            </div>
            <div className="p-4 space-y-2 max-h-96 overflow-y-auto">
              {csvHeaders.map(header => (
                <div key={header} className="flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <span className="font-mono text-sm text-primary-300 truncate block">{header}</span>
                    <span className="font-mono text-[10px] text-primary-700">
                      Sample: {csvRows[0]?.[header] ?? '—'}
                    </span>
                  </div>
                  <span className="text-primary-700">→</span>
                  <select
                    value={columnMapping[header] ?? ''}
                    onChange={e => setColumnMapping(m => ({ ...m, [header]: e.target.value }))}
                    className="w-48 px-2 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none"
                    aria-label={`Map column ${header}`}
                  >
                    {DB_FIELDS.map(f => (
                      <option key={f.value} value={f.value}>{f.label}</option>
                    ))}
                  </select>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={runPreview}
            disabled={isLoading}
            className="flex items-center gap-2 px-6 py-2 bg-primary-900 border border-primary-600 hover:border-primary-crt hover:shadow-glow font-pixel text-[8px] text-primary-crt rounded transition-all disabled:opacity-50"
          >
            {isLoading ? <span className="animate-blink-cursor">▋</span> : <Play className="w-4 h-4" />}
            RUN DRY-RUN PREVIEW
          </button>
        </div>
      )}

      {/* STEP 3: Preview */}
      {step === 'preview' && preview && (
        <div className="space-y-4">
          {/* Stats */}
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'Total Rows', value: preview.total, color: 'text-primary-400' },
              { label: 'Valid', value: preview.valid, color: 'text-green-400' },
              { label: 'Invalid', value: preview.invalid, color: 'text-red-400' },
              { label: 'Will Update', value: preview.duplicates, color: 'text-amber-400' },
            ].map(stat => (
              <div key={stat.label} className="bg-retro-card border border-retro-border rounded p-3 text-center">
                <p className={`font-pixel text-pixel-lg ${stat.color}`}>{stat.value}</p>
                <p className="font-pixel text-[7px] text-primary-700 mt-1">{stat.label}</p>
              </div>
            ))}
          </div>

          {/* Row preview table */}
          <div className="bg-retro-card border border-retro-border rounded overflow-hidden max-h-96 overflow-y-auto">
            <table className="w-full text-xs" aria-label="Import preview">
              <thead className="sticky top-0 bg-retro-bg">
                <tr>
                  <th className="w-12 py-2 px-3 font-pixel text-[7px] text-primary-700 text-left">ROW</th>
                  <th className="py-2 px-3 font-pixel text-[7px] text-primary-700 text-left">CODE</th>
                  <th className="py-2 px-3 font-pixel text-[7px] text-primary-700 text-left">NAME</th>
                  <th className="py-2 px-3 font-pixel text-[7px] text-primary-700 text-left">STATUS</th>
                  <th className="py-2 px-3 font-pixel text-[7px] text-primary-700 text-left">ISSUES</th>
                </tr>
              </thead>
              <tbody>
                {preview.rows.slice(0, 50).map(row => (
                  <tr key={row.row} className={row.errors.length > 0 ? 'bg-red-950/20' : row.isDuplicate ? 'bg-amber-950/20' : ''}>
                    <td className="py-1.5 px-3 font-mono text-primary-700">{row.row}</td>
                    <td className="py-1.5 px-3 font-mono text-primary-400">{row.data['employeeCode'] ?? '—'}</td>
                    <td className="py-1.5 px-3 font-mono text-primary-300">
                      {[row.data['firstName'], row.data['lastName']].filter(Boolean).join(' ') || '—'}
                    </td>
                    <td className="py-1.5 px-3">
                      {row.errors.length > 0 ? (
                        <XCircle className="w-4 h-4 text-red-400" aria-label="Error" />
                      ) : row.isDuplicate ? (
                        <AlertTriangle className="w-4 h-4 text-amber-400" aria-label="Will update" />
                      ) : (
                        <CheckCircle2 className="w-4 h-4 text-green-400" aria-label="Valid" />
                      )}
                    </td>
                    <td className="py-1.5 px-3 font-mono text-[10px]">
                      {row.errors.map(e => <span key={e} className="text-red-400 block">{e}</span>)}
                      {row.warnings.map(w => <span key={w} className="text-amber-400 block">{w}</span>)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {preview.invalid > 0 && (
            <p className="font-mono text-xs text-amber-400 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              {preview.invalid} invalid rows will be skipped. Only {preview.valid} valid rows will be imported.
            </p>
          )}

          <button
            onClick={executeImport}
            disabled={preview.valid === 0}
            className="flex items-center gap-2 px-6 py-2 bg-primary-900 border border-primary-600 hover:border-primary-crt hover:shadow-glow font-pixel text-[8px] text-primary-crt rounded transition-all disabled:opacity-50"
          >
            <Database className="w-4 h-4" />
            IMPORT {preview.valid} VALID ROWS
          </button>
        </div>
      )}

      {/* STEP 4: Done */}
      {step === 'done' && importResult && (
        <div className="text-center py-12 space-y-4">
          <CheckCircle2 className="w-12 h-12 text-primary-crt mx-auto animate-glow-pulse" />
          <p className="font-pixel text-[10px] text-primary-crt">IMPORT QUEUED</p>
          <p className="font-mono text-sm text-primary-500">
            Job ID: <span className="text-primary-300">{importResult.jobId}</span>
          </p>
          <p className="font-mono text-xs text-primary-700">
            Import is processing in the background. You&apos;ll receive a notification when complete.
          </p>
          <button onClick={reset} className="px-6 py-2 bg-primary-950 border border-primary-700 hover:border-primary-crt font-pixel text-[8px] text-primary-500 rounded transition-all">
            IMPORT ANOTHER FILE
          </button>
        </div>
      )}

      {/* Importing animation */}
      {step === 'importing' && (
        <div className="text-center py-12 space-y-4">
          <Database className="w-12 h-12 text-primary-700 mx-auto" />
          <p className="font-pixel text-[10px] text-primary-500 animate-blink-cursor">
            PROCESSING IMPORT▋
          </p>
          <div className="progress-bar w-64 mx-auto">
            <div className="progress-fill animate-pulse" style={{ width: '60%' }} />
          </div>
        </div>
      )}
    </div>
  );
}
