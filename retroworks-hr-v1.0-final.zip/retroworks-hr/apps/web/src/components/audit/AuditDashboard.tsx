'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Shield, Filter, Download, Clock, User, Search, ChevronDown, ChevronRight, Lock } from 'lucide-react';

const api = (path: string) =>
  fetch(`/api/v1${path}`, { headers: { Authorization: `Bearer ${localStorage.getItem('token') ?? ''}` } }).then(r => r.json());

interface AuditEntry {
  id: string; action: string; resource: string; resourceId: string;
  userId: string; user?: { firstName: string; lastName: string; email: string };
  previousData?: Record<string, unknown>; newData?: Record<string, unknown>;
  ipAddress?: string; userAgent?: string; createdAt: string;
}

const ACTION_COLORS: Record<string, string> = {
  CREATE: 'text-green-400 border-green-900 bg-green-950',
  UPDATE: 'text-yellow-400 border-yellow-900 bg-yellow-950',
  DELETE: 'text-red-400 border-red-900 bg-red-950',
  LOGIN: 'text-blue-400 border-blue-900 bg-blue-950',
  EXPORT: 'text-purple-400 border-purple-900 bg-purple-950',
  ROLE_ASSIGNED: 'text-orange-400 border-orange-900 bg-orange-950',
};

function DiffView({ prev, next }: { prev?: Record<string, unknown>; next?: Record<string, unknown> }) {
  if (!prev && !next) return null;
  const keys = [...new Set([...Object.keys(prev ?? {}), ...Object.keys(next ?? {})])];
  const changes = keys.filter(k => JSON.stringify(prev?.[k]) !== JSON.stringify(next?.[k]));
  if (!changes.length) return null;

  return (
    <div className="mt-3 rounded-lg overflow-hidden border border-retro-border text-[10px] font-mono">
      <div className="px-3 py-1.5 bg-retro-bg border-b border-retro-border font-pixel text-[7px] text-primary-700">CHANGES</div>
      {changes.map(key => (
        <div key={key} className="grid grid-cols-3 border-b border-retro-border/50 last:border-0">
          <div className="px-3 py-2 text-primary-600 border-r border-retro-border">{key}</div>
          <div className="px-3 py-2 text-red-400 border-r border-retro-border bg-red-950/10 line-through">
            {prev?.[key] !== undefined ? JSON.stringify(prev[key]) : '—'}
          </div>
          <div className="px-3 py-2 text-green-400 bg-green-950/10">
            {next?.[key] !== undefined ? JSON.stringify(next[key]) : '—'}
          </div>
        </div>
      ))}
    </div>
  );
}

function AuditRow({ entry }: { entry: AuditEntry }) {
  const [expanded, setExpanded] = useState(false);
  const colorClass = ACTION_COLORS[entry.action] ?? 'text-primary-500 border-retro-border bg-retro-bg';

  return (
    <div className={`border-b border-retro-border/30 transition-all ${expanded ? 'bg-surface-raised' : 'hover:bg-surface-raised'}`}>
      <div className="flex items-center gap-3 px-4 py-3 cursor-pointer" onClick={() => setExpanded(e => !e)}>
        {/* Timestamp */}
        <div className="w-36 shrink-0">
          <p className="font-mono text-[10px] text-primary-500">{new Date(entry.createdAt).toLocaleDateString('en-IN')}</p>
          <p className="font-mono text-[9px] text-primary-700">{new Date(entry.createdAt).toLocaleTimeString('en-IN')}</p>
        </div>

        {/* User */}
        <div className="w-32 shrink-0">
          <p className="font-mono text-xs text-primary-400 truncate">
            {entry.user ? `${entry.user.firstName} ${entry.user.lastName}` : entry.userId}
          </p>
          <p className="font-mono text-[9px] text-primary-700 truncate">{entry.user?.email}</p>
        </div>

        {/* Action */}
        <span className={`px-2 py-0.5 rounded border font-pixel text-[7px] ${colorClass}`}>
          {entry.action}
        </span>

        {/* Resource */}
        <div className="flex-1 min-w-0">
          <p className="font-mono text-xs text-primary-500 truncate">{entry.resource}</p>
          <p className="font-mono text-[9px] text-primary-700 font-light truncate">{entry.resourceId}</p>
        </div>

        {/* Changes indicator */}
        {(entry.previousData || entry.newData) && (
          <span className="font-mono text-[9px] text-primary-700 shrink-0">
            {Object.keys(entry.previousData ?? {}).length + Object.keys(entry.newData ?? {}).length} fields
          </span>
        )}

        {expanded ? <ChevronDown className="w-3.5 h-3.5 text-primary-700 shrink-0" /> : <ChevronRight className="w-3.5 h-3.5 text-primary-700 shrink-0" />}
      </div>

      {expanded && (
        <div className="px-4 pb-3">
          <DiffView prev={entry.previousData} next={entry.newData} />
          <div className="flex gap-4 mt-2 font-mono text-[9px] text-primary-800">
            {entry.ipAddress && <span>IP: {entry.ipAddress}</span>}
            {entry.userAgent && <span>UA: {entry.userAgent.slice(0, 60)}…</span>}
          </div>
        </div>
      )}
    </div>
  );
}

export function AuditDashboard() {
  const [search, setSearch] = useState('');
  const [resource, setResource] = useState('');
  const [action, setAction] = useState('');

  const params = new URLSearchParams();
  if (resource) params.set('resource', resource);
  if (action) params.set('action', action);

  const { data = [], isLoading } = useQuery<AuditEntry[]>({
    queryKey: ['audit-log', resource, action],
    queryFn: () => api(`/settings/audit-log?${params}`).then(r => r.data ?? []),
  });

  const filtered = (data as AuditEntry[]).filter(e =>
    !search || `${e.action} ${e.resource} ${e.user?.firstName} ${e.user?.email}`.toLowerCase().includes(search.toLowerCase())
  );

  const exportCsv = () => {
    const headers = ['Timestamp', 'User', 'Email', 'Action', 'Resource', 'Resource ID'];
    const rows = filtered.map(e => [
      new Date(e.createdAt).toISOString(),
      e.user ? `${e.user.firstName} ${e.user.lastName}` : e.userId,
      e.user?.email ?? '',
      e.action, e.resource, e.resourceId,
    ]);
    const csv = [headers, ...rows].map(r => r.map(c => `"${c}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `audit-log-${Date.now()}.csv`; a.click();
    URL.revokeObjectURL(url);
  };

  const RESOURCES = ['', 'employee', 'payroll', 'leave', 'ats', 'performance', 'settings', 'user'];
  const ACTIONS = ['', 'CREATE', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT', 'EXPORT', 'ROLE_ASSIGNED'];

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">AUDIT & COMPLIANCE</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">Complete tamper-proof audit trail · {filtered.length} entries</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-3 py-2 border border-yellow-800 rounded font-pixel text-[7px] text-yellow-400 hover:border-yellow-600">
            <Lock className="w-3 h-3" /> LEGAL HOLD
          </button>
          <button onClick={exportCsv} className="flex items-center gap-2 px-3 py-2 border border-retro-border rounded font-pixel text-[7px] text-primary-600 hover:text-primary-400">
            <Download className="w-3 h-3" /> EXPORT CSV
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Total Events', value: data.length, icon: <Shield className="w-3.5 h-3.5 text-primary-600" /> },
          { label: 'Today', value: (data as AuditEntry[]).filter(e => new Date(e.createdAt).toDateString() === new Date().toDateString()).length, icon: <Clock className="w-3.5 h-3.5 text-blue-400" /> },
          { label: 'Unique Users', value: new Set((data as AuditEntry[]).map(e => e.userId)).size, icon: <User className="w-3.5 h-3.5 text-green-400" /> },
          { label: 'Failed Logins', value: 0, icon: <Shield className="w-3.5 h-3.5 text-red-400" /> },
        ].map(s => (
          <div key={s.label} className="bg-retro-card border border-retro-border rounded-lg p-4 flex items-center gap-3">
            {s.icon}
            <div>
              <p className="font-pixel text-[14px] text-primary-300">{s.value}</p>
              <p className="font-mono text-[9px] text-primary-700">{s.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex gap-3 items-center">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-primary-700" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by user, action, resource…"
            className="w-full pl-9 pr-4 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 outline-none" />
        </div>
        <select value={resource} onChange={e => setResource(e.target.value)}
          className="px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-600 outline-none">
          {RESOURCES.map(r => <option key={r} value={r}>{r || 'All Resources'}</option>)}
        </select>
        <select value={action} onChange={e => setAction(e.target.value)}
          className="px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-500 focus:border-primary-600 outline-none">
          {ACTIONS.map(a => <option key={a} value={a}>{a || 'All Actions'}</option>)}
        </select>
      </div>

      {/* Log table */}
      <div className="bg-retro-card border border-retro-border rounded-xl overflow-hidden">
        <div className="grid grid-cols-[144px_128px_100px_1fr_80px_16px] gap-3 px-4 py-2 bg-retro-bg border-b border-retro-border">
          {['Timestamp', 'User', 'Action', 'Resource', 'Changes', ''].map(h => (
            <p key={h} className="font-pixel text-[7px] text-primary-700">{h}</p>
          ))}
        </div>
        {isLoading ? (
          <div className="py-12 text-center font-mono text-sm text-primary-700">Loading audit log…</div>
        ) : filtered.length === 0 ? (
          <div className="py-12 text-center">
            <Shield className="w-8 h-8 text-primary-800 mx-auto mb-2" />
            <p className="font-mono text-xs text-primary-700">No audit entries found</p>
          </div>
        ) : (
          filtered.map(entry => <AuditRow key={entry.id} entry={entry} />)
        )}
      </div>

      {/* Legal hold notice */}
      <div className="flex items-start gap-3 p-4 bg-yellow-950/20 border border-yellow-900 rounded-lg">
        <Lock className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
        <div className="font-mono text-xs">
          <p className="text-yellow-400 font-medium mb-0.5">Legal Hold</p>
          <p className="text-yellow-700">Apply legal hold to prevent deletion of specific records. Hold status is tracked in the audit log. Consult your legal team before applying or removing holds.</p>
        </div>
      </div>
    </div>
  );
}
