'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Shield, AlertTriangle, AlertCircle, Info, CheckCircle,
  ChevronDown, ChevronRight, Download, Play, Clock, RefreshCw,
} from 'lucide-react';

const token = () =>
  typeof localStorage !== 'undefined' ? (localStorage.getItem('token') ?? '') : '';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${token()}`, 'Content-Type': 'application/json', ...(opts?.headers ?? {}) },
  }).then(r => r.json());

// ── Severity config ───────────────────────────────────────────────────────────
const SEV = {
  CRITICAL: { color: 'text-red-400',    bg: 'bg-red-950/30 border-red-800/40',    icon: AlertTriangle, label: 'CRITICAL' },
  HIGH:     { color: 'text-orange-400', bg: 'bg-orange-950/20 border-orange-800/30', icon: AlertCircle, label: 'HIGH' },
  MEDIUM:   { color: 'text-amber-400',  bg: 'bg-amber-950/20 border-amber-800/30',  icon: AlertCircle,  label: 'MEDIUM' },
  LOW:      { color: 'text-blue-400',   bg: 'bg-blue-950/20 border-blue-800/30',    icon: Info,         label: 'LOW' },
} as const;

const RISK_BADGE: Record<string, string> = {
  CLEAN:    'text-green-400 border-green-800 bg-green-950/20',
  LOW:      'text-blue-400 border-blue-800 bg-blue-950/20',
  MEDIUM:   'text-amber-400 border-amber-800 bg-amber-950/20',
  HIGH:     'text-orange-400 border-orange-800 bg-orange-950/20',
  CRITICAL: 'text-red-400 border-red-800 bg-red-950/20',
};

const CAT_LABELS: Record<string, string> = {
  TDS_ANOMALY: 'TDS',
  PF_COMPLIANCE: 'PF',
  ESI_THRESHOLD: 'ESI',
  PT_MISMATCH: 'PT',
  DUPLICATE_RUN: 'DUPLICATE',
  SALARY_OUTLIER: 'SALARY',
  LEAVE_LEDGER: 'LEAVE',
};

// ── Single finding row (expandable) ──────────────────────────────────────────
function FindingRow({ finding }: { finding: any }) {
  const [open, setOpen] = useState(false);
  const s = SEV[finding.severity as keyof typeof SEV] ?? SEV.LOW;
  const Icon = s.icon;

  return (
    <div className={`border rounded ${s.bg} mb-2`}>
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left"
      >
        <Icon className={`w-4 h-4 flex-shrink-0 ${s.color}`} />
        <span className={`font-pixel text-[7px] px-2 py-0.5 border rounded ${s.color} border-current`}>
          {s.label}
        </span>
        <span className="font-mono text-[9px] text-primary-600 px-2 py-0.5 bg-retro-bg border border-retro-border rounded">
          {CAT_LABELS[finding.category] ?? finding.category}
        </span>
        <span className="font-mono text-[10px] text-primary-400 flex-1 text-left">{finding.message}</span>
        {finding.employeeName && (
          <span className="font-mono text-[9px] text-primary-700 hidden md:block">{finding.employeeName}</span>
        )}
        {open ? <ChevronDown className="w-3 h-3 text-primary-700" /> : <ChevronRight className="w-3 h-3 text-primary-700" />}
      </button>

      {open && (
        <div className="px-4 pb-3 space-y-2 border-t border-retro-border/30 pt-2">
          <div className="grid grid-cols-2 gap-4 font-mono text-[10px]">
            {finding.actual !== undefined && (
              <div className="text-primary-700">Actual: <span className="text-primary-400">{finding.actual}</span></div>
            )}
            {finding.expected !== undefined && (
              <div className="text-primary-700">Expected: <span className="text-primary-400">{finding.expected}</span></div>
            )}
            {finding.deviationPercent && (
              <div className="text-primary-700">Deviation: <span className={s.color}>{finding.deviationPercent.toFixed(1)}%</span></div>
            )}
            {finding.month && (
              <div className="text-primary-700">Period: <span className="text-primary-400">{finding.month}/{finding.year}</span></div>
            )}
          </div>
          <div className="font-mono text-[10px] text-primary-600">
            <span className="text-primary-800">Code: </span>
            <span className="font-pixel text-[7px]">{finding.code}</span>
          </div>
          <div className="flex items-start gap-2">
            <CheckCircle className="w-3 h-3 text-green-700 mt-0.5 flex-shrink-0" />
            <span className="font-mono text-[10px] text-primary-600">{finding.recommendation}</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Risk Score Gauge ──────────────────────────────────────────────────────────
function RiskGauge({ score, level }: { score: number; level: string }) {
  const r = 40, cx = 60, cy = 60;
  const circumference = Math.PI * r; // half circle
  const strokeDash = (score / 100) * circumference;
  const color = level === 'CLEAN' ? '#22c55e' : level === 'LOW' ? '#60a5fa' : level === 'MEDIUM' ? '#f59e0b' : level === 'HIGH' ? '#f97316' : '#ef4444';

  return (
    <svg width="120" height="70" className="overflow-visible">
      {/* Background arc */}
      <path d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
        fill="none" stroke="rgb(26,46,26)" strokeWidth="8" />
      {/* Score arc */}
      <path d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`}
        fill="none" stroke={color} strokeWidth="8"
        strokeDasharray={`${strokeDash} ${circumference}`}
        strokeLinecap="round" />
      <text x={cx} y={cy - 6} textAnchor="middle" fontSize="14" fontWeight="bold" fill={color}>{score}</text>
      <text x={cx} y={cy + 8} textAnchor="middle" fontSize="7" fill="rgb(96,112,96)">RISK SCORE</text>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN AUDIT PAGE
// ─────────────────────────────────────────────────────────────────────────────

export function PayrollAuditPage() {
  const now = new Date();
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear]   = useState(now.getFullYear());
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [report, setReport] = useState<any>(null);
  const qc = useQueryClient();

  const { data: history = [] } = useQuery({
    queryKey: ['audit-history'],
    queryFn: () => api('/analytics/audit/history').then(r => r.data ?? []),
  });

  const runAudit = useMutation({
    mutationFn: () =>
      api(`/analytics/audit/run?month=${month}&year=${year}`, { method: 'POST' }).then(r => r.data ?? r),
    onSuccess: (data) => {
      setReport(data);
      qc.invalidateQueries({ queryKey: ['audit-history'] });
    },
  });

  const findings = report?.findings ?? [];
  const filtered = activeCategory === 'ALL'
    ? findings
    : findings.filter((f: any) => f.category === activeCategory);

  const categories = ['ALL', 'TDS_ANOMALY', 'PF_COMPLIANCE', 'ESI_THRESHOLD', 'PT_MISMATCH', 'DUPLICATE_RUN', 'SALARY_OUTLIER', 'LEAVE_LEDGER'];

  const MONTHS = ['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">PAYROLL AUDIT MODE</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">Automated statutory + compliance anomaly detection</p>
        </div>
        {report && (
          <a
            href={`/api/v1/analytics/audit/export/summary?month=${month}&year=${year}`}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border font-pixel text-[7px] text-primary-600 hover:text-primary-400 rounded"
          >
            <Download className="w-3 h-3" /> Export CSV
          </a>
        )}
      </div>

      {/* Audit Controls */}
      <div className="flex items-end gap-4 bg-retro-card border border-retro-border rounded p-4">
        <div>
          <label className="font-pixel text-[7px] text-primary-700 block mb-1">MONTH</label>
          <select
            value={month}
            onChange={e => setMonth(parseInt(e.target.value))}
            className="bg-retro-bg border border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none"
          >
            {MONTHS.slice(1).map((m, i) => (
              <option key={i + 1} value={i + 1}>{m}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="font-pixel text-[7px] text-primary-700 block mb-1">YEAR</label>
          <select
            value={year}
            onChange={e => setYear(parseInt(e.target.value))}
            className="bg-retro-bg border border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none"
          >
            {[2023, 2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>
        <button
          onClick={() => runAudit.mutate()}
          disabled={runAudit.isPending}
          className="flex items-center gap-2 px-6 py-2 bg-primary-900 border border-primary-700 font-pixel text-[7px] text-primary-crt rounded hover:bg-primary-800 disabled:opacity-50 transition-colors"
        >
          {runAudit.isPending
            ? <><RefreshCw className="w-3 h-3 animate-spin" /> SCANNING...</>
            : <><Play className="w-3 h-3" /> RUN AUDIT</>
          }
        </button>
      </div>

      {/* Results */}
      {report && (
        <div className="space-y-4">
          {/* Risk Summary */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <div className="col-span-2 md:col-span-1 flex flex-col items-center justify-center bg-retro-card border border-retro-border rounded p-4">
              <RiskGauge score={report.riskScore} level={report.riskLevel} />
              <span className={`font-pixel text-[8px] mt-2 px-3 py-1 border rounded ${RISK_BADGE[report.riskLevel] ?? ''}`}>
                {report.riskLevel}
              </span>
            </div>
            {[
              { label: 'CRITICAL', count: report.criticalCount, color: 'text-red-400 border-red-800 bg-red-950/20' },
              { label: 'HIGH',     count: report.highCount,     color: 'text-orange-400 border-orange-800 bg-orange-950/20' },
              { label: 'MEDIUM',   count: report.mediumCount,   color: 'text-amber-400 border-amber-800 bg-amber-950/20' },
              { label: 'LOW',      count: report.lowCount,      color: 'text-blue-400 border-blue-800 bg-blue-950/20' },
            ].map(({ label, count, color }) => (
              <div key={label} className={`border rounded p-4 flex flex-col items-center justify-center ${color}`}>
                <div className="font-pixel text-[9px] mb-1">{label}</div>
                <div className="font-pixel text-[16px]">{count}</div>
                <div className="font-mono text-[9px] opacity-60">findings</div>
              </div>
            ))}
          </div>

          {/* Summary stats */}
          <div className="font-mono text-[10px] text-primary-700 flex gap-4">
            <span>Payslips scanned: <strong className="text-primary-400">{report.totalPayslipsScanned}</strong></span>
            <span>Runs checked: <strong className="text-primary-400">{report.totalRunsScanned}</strong></span>
            <span>Total findings: <strong className="text-primary-400">{report.totalFindingsCount}</strong></span>
          </div>

          {/* Category filter */}
          <div className="flex flex-wrap gap-2">
            {categories.map(cat => {
              const catCount = cat === 'ALL'
                ? findings.length
                : findings.filter((f: any) => f.category === cat).length;
              if (cat !== 'ALL' && catCount === 0) return null;
              return (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`font-pixel text-[7px] px-3 py-1.5 border rounded transition-colors ${
                    activeCategory === cat
                      ? 'border-primary-crt text-primary-crt bg-primary-950/40'
                      : 'border-retro-border text-primary-700 hover:border-primary-700'
                  }`}
                >
                  {CAT_LABELS[cat] ?? cat} ({catCount})
                </button>
              );
            })}
          </div>

          {/* Findings list */}
          <div>
            {filtered.length === 0 ? (
              <div className="flex items-center gap-3 py-8 justify-center">
                <CheckCircle className="w-6 h-6 text-green-500" />
                <div>
                  <div className="font-pixel text-[8px] text-green-400">
                    {activeCategory === 'ALL' ? 'NO ANOMALIES DETECTED' : `NO ${CAT_LABELS[activeCategory]} ISSUES`}
                  </div>
                  <div className="font-mono text-[10px] text-primary-700 mt-1">All checks passed for this category.</div>
                </div>
              </div>
            ) : (
              filtered.map((f: any) => <FindingRow key={f.id} finding={f} />)
            )}
          </div>
        </div>
      )}

      {/* Audit history */}
      {!report && history.length > 0 && (
        <div className="bg-retro-card border border-retro-border rounded p-4">
          <div className="font-pixel text-[8px] text-primary-600 mb-3">RECENT AUDIT HISTORY</div>
          <div className="space-y-2">
            {(history as any[]).map((h: any, i: number) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-retro-border/30">
                <div className="flex items-center gap-3">
                  <Clock className="w-3 h-3 text-primary-800" />
                  <span className="font-mono text-[10px] text-primary-500">
                    {MONTHS[h.month]} {h.year}
                  </span>
                </div>
                <span className={`font-pixel text-[7px] px-2 py-0.5 border rounded ${RISK_BADGE[h.riskLevel] ?? ''}`}>
                  {h.riskLevel}
                </span>
                <span className="font-mono text-[10px] text-primary-700">{h.findingsCount} findings</span>
                <span className="font-mono text-[9px] text-primary-800">
                  {new Date(h.generatedAt).toLocaleDateString('en-IN')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {!report && history.length === 0 && !runAudit.isPending && (
        <div className="flex flex-col items-center justify-center py-16 space-y-4">
          <Shield className="w-12 h-12 text-primary-800" />
          <div className="font-pixel text-[8px] text-primary-600">AUDIT NOT YET RUN</div>
          <div className="font-mono text-xs text-primary-700">Select a month and click RUN AUDIT to scan for anomalies.</div>
        </div>
      )}
    </div>
  );
}
