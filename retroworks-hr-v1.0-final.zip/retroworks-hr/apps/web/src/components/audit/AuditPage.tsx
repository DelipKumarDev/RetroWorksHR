'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Shield, Search, Download, Filter, ChevronDown, ChevronRight,
  AlertTriangle, Lock, CheckCircle, Eye, Clock, User,
} from 'lucide-react';

const api = async (path: string) => {
  const res = await fetch(`/api/v1${path}`, { headers: { Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}` } });
  return res.json();
};

const ACTION_COLORS: Record<string, string> = {
  created: 'text-green-400 bg-green-950 border-green-900',
  updated: 'text-blue-400 bg-blue-950 border-blue-900',
  deleted: 'text-red-400 bg-red-950 border-red-900',
  approved: 'text-green-400 bg-green-950 border-green-900',
  rejected: 'text-red-400 bg-red-950 border-red-900',
  login: 'text-primary-400 bg-primary-950 border-primary-800',
  export: 'text-yellow-400 bg-yellow-950 border-yellow-900',
  'permission-change': 'text-purple-400 bg-purple-950 border-purple-900',
};

const RESOURCE_ICONS: Record<string, string> = {
  employee: '👤', leave: '📅', payroll: '💰', attendance: '⏰',
  performance: '⭐', expense: '🧾', helpdesk: '🎫', role: '🔑',
  settings: '⚙️', auth: '🔐', document: '📄', automation: '⚡',
};

function DiffViewer({ oldData, newData }: { oldData: Record<string, unknown>; newData: Record<string, unknown> }) {
  const allKeys = [...new Set([...Object.keys(oldData ?? {}), ...Object.keys(newData ?? {})])];
  const changed = allKeys.filter(k => JSON.stringify(oldData?.[k]) !== JSON.stringify(newData?.[k]));
  if (changed.length === 0) return <p className="font-mono text-xs text-primary-700">No field changes detected</p>;

  return (
    <div className="space-y-1.5">
      {changed.map(key => (
        <div key={key} className="grid grid-cols-3 gap-2 items-start font-mono text-[10px]">
          <span className="text-primary-600 truncate">{key}</span>
          <div className="px-2 py-1 bg-red-950/30 border border-red-900/40 rounded text-red-400 line-through truncate">
            {JSON.stringify(oldData?.[key]) ?? 'null'}
          </div>
          <div className="px-2 py-1 bg-green-950/30 border border-green-900/40 rounded text-green-400 truncate">
            {JSON.stringify(newData?.[key]) ?? 'null'}
          </div>
        </div>
      ))}
    </div>
  );
}

function AuditRow({ entry }: { entry: any }) {
  const [expanded, setExpanded] = useState(false);
  const actionStyle = ACTION_COLORS[entry.action] ?? 'text-primary-400 bg-primary-950 border-primary-800';
  const resourceIcon = RESOURCE_ICONS[entry.resource] ?? '📋';
  const hasChanges = entry.oldData || entry.newData;

  return (
    <div className={`border-b border-retro-border/30 ${expanded ? 'bg-retro-bg' : 'hover:bg-retro-bg/50'} transition-colors`}>
      <div className="flex items-center gap-3 px-4 py-3 cursor-pointer" onClick={() => hasChanges && setExpanded(e => !e)}>
        {/* Time */}
        <div className="w-36 shrink-0">
          <p className="font-mono text-[10px] text-primary-500">{new Date(entry.createdAt).toLocaleDateString('en-IN', { dateStyle: 'short' })}</p>
          <p className="font-mono text-[9px] text-primary-700">{new Date(entry.createdAt).toLocaleTimeString('en-IN', { timeStyle: 'short' })}</p>
        </div>

        {/* User */}
        <div className="w-40 shrink-0">
          <div className="flex items-center gap-1.5">
            <div className="w-5 h-5 rounded-full bg-primary-900 border border-primary-800 flex items-center justify-center font-mono text-[7px] text-primary-500">
              {(entry.user?.firstName?.[0] ?? '?')}{(entry.user?.lastName?.[0] ?? '')}
            </div>
            <p className="font-mono text-[10px] text-primary-400 truncate">{entry.user ? `${entry.user.firstName} ${entry.user.lastName}` : entry.userId?.slice(0, 8) + '…'}</p>
          </div>
        </div>

        {/* Action badge */}
        <div className="w-32 shrink-0">
          <span className={`inline-flex px-2 py-0.5 rounded border text-[8px] font-pixel ${actionStyle}`}>{entry.action}</span>
        </div>

        {/* Resource */}
        <div className="flex-1 min-w-0 flex items-center gap-2">
          <span className="text-sm">{resourceIcon}</span>
          <span className="font-mono text-xs text-primary-400 truncate">{entry.resource}</span>
          {entry.resourceId && <span className="font-mono text-[9px] text-primary-700 truncate">#{entry.resourceId.slice(0, 8)}</span>}
        </div>

        {/* IP */}
        {entry.ipAddress && <span className="font-mono text-[9px] text-primary-800 shrink-0">{entry.ipAddress}</span>}

        {/* Expand */}
        {hasChanges && (
          <div className="shrink-0 text-primary-700">
            {expanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
          </div>
        )}
      </div>

      {/* Expanded diff */}
      {expanded && hasChanges && (
        <div className="px-4 pb-4 border-t border-retro-border/20">
          <div className="mt-3 grid grid-cols-3 gap-2 mb-2">
            <span className="font-pixel text-[7px] text-primary-700">FIELD</span>
            <span className="font-pixel text-[7px] text-red-700">BEFORE</span>
            <span className="font-pixel text-[7px] text-green-700">AFTER</span>
          </div>
          <DiffViewer oldData={entry.oldData ?? {}} newData={entry.newData ?? {}} />
        </div>
      )}
    </div>
  );
}

export function AuditPage() {
  const [search, setSearch] = useState('');
  const [resource, setResource] = useState('');
  const [action, setAction] = useState('');
  const [page, setPage] = useState(0);
  const limit = 50;

  const params = new URLSearchParams({ limit: String(limit), offset: String(page * limit), ...(resource && { resource }), ...(action && { action }) });
  const { data: auditData, isLoading } = useQuery({
    queryKey: ['audit-log', resource, action, page],
    queryFn: () => api(`/settings/audit-log?${params}`).then(r => r.data ?? { entries: [], total: 0 }),
    refetchInterval: 30000,
  });

  const entries: any[] = auditData?.entries ?? (Array.isArray(auditData) ? auditData : []);
  const total: number = auditData?.total ?? entries.length;

  const filtered = search
    ? entries.filter(e => `${e.user?.firstName} ${e.user?.lastName} ${e.resource} ${e.action} ${e.resourceId}`.toLowerCase().includes(search.toLowerCase()))
    : entries;

  const resources = ['employee', 'leave', 'payroll', 'attendance', 'performance', 'expense', 'helpdesk', 'role', 'settings', 'auth', 'document', 'automation'];
  const actions = ['created', 'updated', 'deleted', 'approved', 'rejected', 'login', 'export', 'permission-change'];

  const stats = entries.reduce((acc: Record<string, number>, e: any) => { acc[e.action] = (acc[e.action] ?? 0) + 1; return acc; }, {});

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">AUDIT & COMPLIANCE CENTER</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">Full audit trail — who changed what, when, and how</p>
        </div>
        <a href={`/api/v1/settings/audit-log/export?format=csv`} className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500">
          <Download className="w-3.5 h-3.5" /> Export
        </a>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-5 gap-3">
        {[
          { label: 'Total Events', value: total, icon: <Shield className="w-3.5 h-3.5" /> },
          { label: 'Creates', value: stats.created ?? 0, icon: <CheckCircle className="w-3.5 h-3.5 text-green-400" /> },
          { label: 'Updates', value: stats.updated ?? 0, icon: <Eye className="w-3.5 h-3.5 text-blue-400" /> },
          { label: 'Deletes', value: stats.deleted ?? 0, icon: <AlertTriangle className="w-3.5 h-3.5 text-red-400" /> },
          { label: 'Permission Changes', value: stats['permission-change'] ?? 0, icon: <Lock className="w-3.5 h-3.5 text-purple-400" /> },
        ].map(s => (
          <div key={s.label} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg">
            <div className="text-primary-600">{s.icon}</div>
            <div><p className="font-pixel text-[14px] text-primary-crt">{s.value}</p><p className="font-mono text-[9px] text-primary-700">{s.label}</p></div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-primary-700" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by user, resource, action…" className="w-full pl-8 pr-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none" />
        </div>
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-primary-700" />
          <select value={resource} onChange={e => { setResource(e.target.value); setPage(0); }} className="px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:border-primary-600 focus:outline-none">
            <option value="">All resources</option>
            {resources.map(r => <option key={r} value={r}>{RESOURCE_ICONS[r]} {r}</option>)}
          </select>
          <select value={action} onChange={e => { setAction(e.target.value); setPage(0); }} className="px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:border-primary-600 focus:outline-none">
            <option value="">All actions</option>
            {actions.map(a => <option key={a} value={a}>{a}</option>)}
          </select>
        </div>
      </div>

      {/* Log table */}
      <div className="bg-retro-card border border-retro-border rounded-xl overflow-hidden">
        {/* Table header */}
        <div className="flex items-center gap-3 px-4 py-2 border-b border-retro-border bg-retro-bg">
          <span className="w-36 shrink-0 font-pixel text-[7px] text-primary-700">TIMESTAMP</span>
          <span className="w-40 shrink-0 font-pixel text-[7px] text-primary-700">USER</span>
          <span className="w-32 shrink-0 font-pixel text-[7px] text-primary-700">ACTION</span>
          <span className="flex-1 font-pixel text-[7px] text-primary-700">RESOURCE</span>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-16 gap-3 font-mono text-sm text-primary-700">
            <Clock className="w-5 h-5 animate-spin" />Loading audit log…
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-2">
            <Shield className="w-10 h-10 text-primary-800" />
            <p className="font-mono text-sm text-primary-700">No audit entries found</p>
          </div>
        ) : (
          filtered.map((entry: any) => <AuditRow key={entry.id} entry={entry} />)
        )}
      </div>

      {/* Pagination */}
      {total > limit && (
        <div className="flex items-center justify-between font-mono text-xs text-primary-700">
          <span>Showing {page * limit + 1}–{Math.min((page + 1) * limit, total)} of {total} events</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} className="px-3 py-1.5 border border-retro-border rounded disabled:opacity-30 hover:border-primary-700">← Prev</button>
            <button onClick={() => setPage(p => p + 1)} disabled={(page + 1) * limit >= total} className="px-3 py-1.5 border border-retro-border rounded disabled:opacity-30 hover:border-primary-700">Next →</button>
          </div>
        </div>
      )}
    </div>
  );
}
