'use client';

import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import {
  Users, Calendar, DollarSign, Target, Ticket,
  AlertTriangle, CheckCircle, Clock, TrendingUp, Zap,
  ArrowRight, Bot, BarChart3, RefreshCw, Shield,
  BookMarked, Kanban, TrendingDown, Activity,
} from 'lucide-react';

const api = async (path: string) => {
  const res = await fetch(`/api/v1${path}`, { headers: { Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}` } });
  return res.json();
};

// ─── Section Card ──────────────────────────────────────────────────

function SectionCard({ title, value, sub, href, color, icon, alert }: { title: string; value: string | number; sub?: string; href: string; color: string; icon: React.ReactNode; alert?: boolean }) {
  return (
    <Link href={href}>
      <div className={`flex items-center gap-4 p-4 bg-retro-card border rounded-lg hover:border-primary-700 transition-all group ${alert ? 'border-red-900/60 hover:border-red-700' : 'border-retro-border'}`}>
        <div className={`w-10 h-10 rounded-lg border flex items-center justify-center shrink-0 ${alert ? 'bg-red-950 border-red-800 text-red-400' : 'bg-retro-bg border-retro-border'}`}>{icon}</div>
        <div className="flex-1 min-w-0">
          <p className={`font-pixel text-[18px] leading-none ${color}`}>{value}</p>
          <p className="font-mono text-[10px] text-primary-700 mt-0.5">{title}</p>
          {sub && <p className={`font-mono text-[9px] mt-0.5 ${alert ? 'text-red-700' : 'text-primary-800'}`}>{sub}</p>}
        </div>
        <ArrowRight className="w-3.5 h-3.5 text-primary-800 shrink-0 group-hover:text-primary-500 transition-colors" />
      </div>
    </Link>
  );
}

// ─── HRMS Quick Actions ─────────────────────────────────────────────

function HrmsQuickActions() {
  const actions = [
    { label: 'Apply Leave', href: '/dashboard/leave?apply=true', icon: <Calendar className="w-3.5 h-3.5" /> },
    { label: 'My Payslip', href: '/dashboard/payroll', icon: <DollarSign className="w-3.5 h-3.5" /> },
    { label: 'Clock In', href: '/dashboard/attendance', icon: <Clock className="w-3.5 h-3.5" /> },
    { label: 'My Goals', href: '/dashboard/performance', icon: <Target className="w-3.5 h-3.5" /> },
    { label: 'New Hire', href: '/dashboard/ats', icon: <Users className="w-3.5 h-3.5" /> },
    { label: 'Run Payroll', href: '/dashboard/payroll?run=true', icon: <DollarSign className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="grid grid-cols-3 gap-2">
      {actions.map(a => (
        <Link key={a.href} href={a.href}
          className="flex items-center gap-2 px-3 py-2.5 bg-retro-bg border border-retro-border rounded-lg font-mono text-xs text-primary-500 hover:border-primary-700 hover:text-primary-300 transition-all">
          <span className="text-primary-600">{a.icon}</span>{a.label}
        </Link>
      ))}
    </div>
  );
}

// ─── Recent Tickets Widget ──────────────────────────────────────────

function RecentTickets({ tickets }: { tickets: any[] }) {
  const PRIORITY_COLORS: Record<string, string> = { p1: 'text-red-400', p2: 'text-orange-400', p3: 'text-blue-400', p4: 'text-primary-600' };
  const TYPE_ICONS: Record<string, string> = { internal: '🏢', external: '🌐', payroll: '💰', IT: '💻', admin: '📋', vendor: '🤝', custom: '⚡' };

  if (!tickets?.length) return <p className="font-mono text-xs text-primary-800 text-center py-4">No active tickets</p>;

  return (
    <div className="space-y-2">
      {tickets.slice(0, 5).map((t: any) => (
        <Link key={t.id} href={`/dashboard/case-engine/tickets/${t.id}`}
          className="flex items-center gap-3 p-3 bg-retro-bg border border-retro-border rounded-lg hover:border-primary-700 transition-all">
          <span className="text-sm shrink-0">{TYPE_ICONS[t.type] ?? '📋'}</span>
          <div className="flex-1 min-w-0">
            <p className="font-mono text-xs text-primary-300 truncate">{t.title}</p>
            <p className="font-mono text-[9px] text-primary-700">{t.ticketNumber} · {t.category?.name ?? t.type}</p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {t.slaBreached && <AlertTriangle className="w-3 h-3 text-red-400" />}
            <span className={`font-pixel text-[7px] ${PRIORITY_COLORS[t.priority]}`}>{t.priority.toUpperCase()}</span>
          </div>
        </Link>
      ))}
      <Link href="/dashboard/case-engine/tickets" className="flex items-center justify-center gap-1 py-2 font-mono text-[10px] text-primary-700 hover:text-primary-400 transition-colors">
        View all tickets <ArrowRight className="w-3 h-3" />
      </Link>
    </div>
  );
}

// ─── Platform Health Strip ──────────────────────────────────────────

function PlatformHealthStrip({ hrmsStats, caseStats, insightsSummary }: { hrmsStats: any; caseStats: any; insightsSummary: any }) {
  const checks = [
    { label: 'Payroll', ok: !hrmsStats?.payrollIssues, note: hrmsStats?.payrollIssues ? 'Run pending' : 'Up to date' },
    { label: 'Attendance', ok: true, note: 'Syncing' },
    { label: 'SLA Breach', ok: (caseStats?.breached ?? 0) === 0, note: `${caseStats?.breached ?? 0} breached` },
    { label: 'Attrition Risk', ok: (insightsSummary?.attrition?.highRisk ?? 0) < 3, note: `${insightsSummary?.attrition?.highRisk ?? 0} high risk` },
    { label: 'Backup', ok: true, note: 'Last: today' },
  ];

  return (
    <div className="flex items-center gap-3 px-4 py-3 bg-retro-bg border border-retro-border rounded-lg">
      <span className="font-pixel text-[7px] text-primary-700 shrink-0">PLATFORM HEALTH</span>
      <div className="flex-1 flex items-center gap-4 flex-wrap">
        {checks.map(c => (
          <div key={c.label} className="flex items-center gap-1.5">
            <div className={`w-1.5 h-1.5 rounded-full ${c.ok ? 'bg-primary-crt' : 'bg-red-400'}`} />
            <span className={`font-mono text-[9px] ${c.ok ? 'text-primary-500' : 'text-red-400'}`}>{c.label}</span>
            <span className="font-mono text-[8px] text-primary-800">({c.note})</span>
          </div>
        ))}
      </div>
      <span className="font-mono text-[9px] text-primary-800 shrink-0">{new Date().toLocaleTimeString('en-IN', { timeStyle: 'short' })} IST</span>
    </div>
  );
}

// ─── Cross-Domain Alerts ────────────────────────────────────────────

function CrossDomainAlerts({ data }: { data: any }) {
  if (!data?.length) return null;

  return (
    <div className="space-y-2">
      {data.map((alert: any, i: number) => (
        <Link key={i} href={alert.href ?? '#'} className="flex items-start gap-3 p-3 bg-retro-bg border border-yellow-900/40 rounded-lg hover:border-yellow-700/60 transition-all">
          <Zap className="w-3.5 h-3.5 text-yellow-400 shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <p className="font-mono text-xs text-primary-300">{alert.title}</p>
            <p className="font-mono text-[9px] text-primary-700 mt-0.5">{alert.description}</p>
          </div>
          <span className="font-pixel text-[7px] text-yellow-700 border border-yellow-900 rounded px-1.5 shrink-0">{alert.module}</span>
        </Link>
      ))}
    </div>
  );
}

// ─── Main Page ──────────────────────────────────────────────────────

export function UnifiedPlatformHome() {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  const { data: hrmsStats } = useQuery({ queryKey: ['hrms-dashboard-stats'], queryFn: () => api('/dashboard/stats').then(r => r.data).catch(() => ({})), staleTime: 60000 });
  const { data: caseStats } = useQuery({ queryKey: ['ticket-stats'], queryFn: () => api('/case-engine/tickets/stats').then(r => r.data).catch(() => ({})), staleTime: 30000 });
  const { data: insightsSummary } = useQuery({ queryKey: ['insights-dashboard'], queryFn: () => api('/insights/dashboard').then(r => r.data).catch(() => ({})), staleTime: 120000 });
  const { data: recentTickets } = useQuery({ queryKey: ['recent-tickets'], queryFn: () => api('/case-engine/tickets?limit=5&status=open').then(r => r.data?.tickets ?? []).catch(() => []), staleTime: 30000 });

  // Synthesize cross-domain alerts from both domains
  const crossDomainAlerts = [
    ...(insightsSummary?.attrition?.highRisk > 0 ? [{ title: `${insightsSummary.attrition.highRisk} employee(s) flagged as high attrition risk`, description: 'AI Insights Engine detected patterns suggesting resignation risk', href: '/dashboard/insights', module: 'INSIGHTS' }] : []),
    ...(caseStats?.breached > 0 ? [{ title: `${caseStats.breached} ticket(s) SLA breached`, description: 'Immediate attention required — customers waiting', href: '/dashboard/case-engine/tickets?slaBreached=true', module: 'CASE ENGINE' }] : []),
    ...(hrmsStats?.pendingLeaves > 10 ? [{ title: `${hrmsStats.pendingLeaves} leave requests awaiting approval`, description: 'Manager action required to avoid SLA breach', href: '/dashboard/leave', module: 'LEAVE' }] : []),
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-pixel text-[11px] text-primary-crt">{greeting}, Admin</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">
            {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/dashboard/ai" className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-crt hover:border-primary-500 shadow-glow">
            <Bot className="w-3.5 h-3.5" /> Ask RetroBot
          </Link>
        </div>
      </div>

      {/* Platform health strip */}
      <PlatformHealthStrip hrmsStats={hrmsStats} caseStats={caseStats} insightsSummary={insightsSummary} />

      {/* Cross-domain alerts */}
      {crossDomainAlerts.length > 0 && (
        <div>
          <p className="font-pixel text-[7px] text-primary-700 mb-2">CROSS-DOMAIN ALERTS</p>
          <CrossDomainAlerts data={crossDomainAlerts} />
        </div>
      )}

      {/* Two column layout */}
      <div className="grid grid-cols-12 gap-5">
        {/* Left: HRMS Overview */}
        <div className="col-span-7 space-y-5">
          <div>
            <p className="font-pixel text-[7px] text-primary-700 mb-3">HRMS OVERVIEW</p>
            <div className="grid grid-cols-2 gap-3">
              <SectionCard title="Active Employees" value={hrmsStats?.totalEmployees ?? '—'} sub={`+${hrmsStats?.newThisMonth ?? 0} this month`} href="/dashboard/employees" color="text-primary-crt" icon={<Users className="w-4 h-4 text-primary-500" />} />
              <SectionCard title="Leave Requests Pending" value={hrmsStats?.pendingLeaves ?? '—'} sub="Awaiting manager approval" href="/dashboard/leave" color="text-yellow-400" icon={<Calendar className="w-4 h-4 text-yellow-600" />} alert={(hrmsStats?.pendingLeaves ?? 0) > 10} />
              <SectionCard title="Payroll — This Month" value={hrmsStats?.payrollTotal ? `₹${(hrmsStats.payrollTotal / 100000).toFixed(1)}L` : '—'} sub={`${hrmsStats?.payrollHeadcount ?? 0} employees processed`} href="/dashboard/payroll" color="text-green-400" icon={<DollarSign className="w-4 h-4 text-green-600" />} />
              <SectionCard title="Open Performances" value={hrmsStats?.openReviews ?? '—'} sub="Reviews in progress" href="/dashboard/performance" color="text-blue-400" icon={<Target className="w-4 h-4 text-blue-600" />} />
              <SectionCard title="High Attrition Risk" value={insightsSummary?.attrition?.highRisk ?? '—'} sub="Employees flagged by AI" href="/dashboard/insights" color="text-red-400" icon={<TrendingDown className="w-4 h-4 text-red-600" />} alert={(insightsSummary?.attrition?.highRisk ?? 0) > 0} />
              <SectionCard title="Headcount Trend" value={insightsSummary?.headcount?.trend ?? '—'} sub={`+${insightsSummary?.headcount?.monthlyAddition ?? 0}/mo`} href="/dashboard/insights" color="text-primary-400" icon={<Activity className="w-4 h-4 text-primary-600" />} />
            </div>
          </div>

          <div>
            <p className="font-pixel text-[7px] text-primary-700 mb-3">QUICK ACTIONS</p>
            <HrmsQuickActions />
          </div>

          <div>
            <p className="font-pixel text-[7px] text-primary-700 mb-3">PLATFORM TOOLS</p>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'Report Builder', href: '/dashboard/report-builder', icon: <BarChart3 className="w-3.5 h-3.5" /> },
                { label: 'Automation', href: '/dashboard/automation', icon: <Zap className="w-3.5 h-3.5" /> },
                { label: 'AI Insights', href: '/dashboard/insights', icon: <TrendingUp className="w-3.5 h-3.5" /> },
                { label: 'Documents', href: '/dashboard/documents', icon: <BookMarked className="w-3.5 h-3.5" /> },
                { label: 'Audit Log', href: '/dashboard/audit', icon: <Shield className="w-3.5 h-3.5" /> },
                { label: 'Plugins', href: '/dashboard/plugins', icon: <Zap className="w-3.5 h-3.5" /> },
              ].map(a => (
                <Link key={a.href} href={a.href}
                  className="flex items-center gap-2 px-3 py-2.5 bg-retro-bg border border-retro-border rounded-lg font-mono text-xs text-primary-500 hover:border-primary-700 hover:text-primary-300 transition-all">
                  <span className="text-primary-700">{a.icon}</span>{a.label}
                </Link>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Case Engine */}
        <div className="col-span-5 space-y-5">
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="font-pixel text-[7px] text-primary-700">CASE ENGINE</p>
              <div className="flex items-center gap-1">
                <div className="w-1.5 h-1.5 rounded-full bg-primary-crt animate-pulse" />
                <span className="font-mono text-[8px] text-primary-crt">LIVE</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <SectionCard title="Open Tickets" value={caseStats?.open ?? '—'} href="/dashboard/case-engine/tickets?status=open" color="text-green-400" icon={<Ticket className="w-4 h-4 text-green-600" />} />
              <SectionCard title="SLA Breached" value={caseStats?.breached ?? '—'} sub="Needs immediate action" href="/dashboard/case-engine/tickets?slaBreached=true" color="text-red-400" icon={<AlertTriangle className="w-4 h-4 text-red-600" />} alert={(caseStats?.breached ?? 0) > 0} />
              <SectionCard title="Resolved Today" value={caseStats?.resolvedToday ?? '—'} href="/dashboard/case-engine/tickets?status=resolved" color="text-primary-400" icon={<CheckCircle className="w-4 h-4 text-primary-600" />} />
              <SectionCard title="Avg Resolution" value={caseStats?.avgResolutionHours ? `${caseStats.avgResolutionHours}h` : '—'} href="/dashboard/case-engine/analytics" color="text-blue-400" icon={<Clock className="w-4 h-4 text-blue-600" />} />
            </div>

            {/* Case Engine quick nav */}
            <div className="grid grid-cols-2 gap-2 mb-4">
              <Link href="/dashboard/case-engine/tickets" className="flex items-center gap-2 px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-500 hover:border-primary-700 transition-all">
                <Ticket className="w-3 h-3" />All Tickets
              </Link>
              <Link href="/dashboard/case-engine/kanban" className="flex items-center gap-2 px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-500 hover:border-primary-700 transition-all">
                <Kanban className="w-3 h-3" />Kanban Board
              </Link>
              <Link href="/dashboard/case-engine/kb" className="flex items-center gap-2 px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-500 hover:border-primary-700 transition-all">
                <BookMarked className="w-3 h-3" />Knowledge Base
              </Link>
              <Link href="/dashboard/case-engine/analytics" className="flex items-center gap-2 px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-500 hover:border-primary-700 transition-all">
                <TrendingUp className="w-3 h-3" />Analytics
              </Link>
            </div>

            {/* Recent tickets */}
            <p className="font-pixel text-[7px] text-primary-700 mb-2">RECENT OPEN TICKETS</p>
            <RecentTickets tickets={recentTickets ?? []} />
          </div>
        </div>
      </div>

      {/* Footer: Cross-domain automation status */}
      <div className="p-4 bg-retro-bg border border-retro-border rounded-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Zap className="w-3.5 h-3.5 text-primary-crt" />
            <div>
              <p className="font-pixel text-[7px] text-primary-400">CROSS-DOMAIN AUTOMATION</p>
              <p className="font-mono text-[10px] text-primary-700">Employee join → IT ticket • Exit → Clearance ticket • Payroll anomaly → Finance case</p>
            </div>
          </div>
          <Link href="/dashboard/automation" className="flex items-center gap-1.5 font-mono text-[9px] text-primary-600 hover:text-primary-400">
            Configure <ArrowRight className="w-3 h-3" />
          </Link>
        </div>
      </div>
    </div>
  );
}
