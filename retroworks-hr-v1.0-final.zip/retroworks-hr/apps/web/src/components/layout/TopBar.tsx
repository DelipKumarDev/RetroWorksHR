'use client';

import { Bell, Search, HelpCircle } from 'lucide-react';
import { usePathname } from 'next/navigation';

const ROUTE_LABELS: Record<string, string> = {
  '/dashboard': 'Dashboard',
  '/dashboard/employees': 'Employees',
  '/dashboard/leave': 'Leave Management',
  '/dashboard/attendance': 'Attendance',
  '/dashboard/payroll': 'Payroll',
  '/dashboard/ats': 'Recruitment',
  '/dashboard/performance': 'Performance',
  '/dashboard/lnd': 'Learning & Development',
  '/dashboard/helpdesk': 'Helpdesk',
  '/dashboard/ai': 'AI HR Copilot',
  '/dashboard/admin': 'Administration',
  '/dashboard/settings': 'Settings',
};

export function TopBar() {
  const pathname = usePathname();
  const pageLabel = ROUTE_LABELS[pathname] ?? 'RetroWorks HR';

  return (
    <header className="h-14 bg-retro-bg-secondary border-b border-retro-border flex items-center gap-4 px-6 sticky top-0 z-raised">
      {/* Page title */}
      <div className="flex-1 min-w-0">
        <h1 className="font-pixel text-[10px] text-primary-400 truncate">
          {pageLabel}
        </h1>
      </div>

      {/* Search */}
      <div className="relative hidden md:block">
        <Search
          className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-primary-700"
          aria-hidden
        />
        <input
          type="search"
          placeholder="Search employees, tickets..."
          aria-label="Search"
          className="pl-9 pr-4 py-1.5 w-64 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none focus:shadow-glow caret-primary-crt"
        />
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        {/* Notifications */}
        <button
          type="button"
          aria-label="Notifications (3 unread)"
          className="relative w-8 h-8 flex items-center justify-center text-primary-600 hover:text-primary-400 hover:bg-surface-raised rounded transition-colors"
        >
          <Bell className="w-4 h-4" />
          <span
            className="absolute top-1 right-1 w-1.5 h-1.5 bg-accent rounded-full"
            aria-hidden="true"
          />
        </button>

        {/* Help */}
        <button
          type="button"
          aria-label="Help"
          className="w-8 h-8 flex items-center justify-center text-primary-600 hover:text-primary-400 hover:bg-surface-raised rounded transition-colors"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        {/* System status indicator */}
        <div
          className="hidden lg:flex items-center gap-1.5 px-2 py-1 border border-retro-border rounded"
          title="System status"
        >
          <span className="status-dot online" />
          <span className="font-pixel text-[7px] text-primary-700">SYS OK</span>
        </div>
      </div>
    </header>
  );
}
