'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Users, Calendar, Clock, DollarSign, Target, BookOpen,
  Receipt, Monitor, LifeBuoy, BarChart3, Settings, UserPlus,
  LogIn, Megaphone, Bot, LayoutDashboard, ShieldCheck,
  Ticket, Kanban, Database, Globe, BookMarked, TrendingUp,
  Zap, ChevronDown, ChevronRight, Puzzle, HardDrive, Shield,
  Star, Wand2,
} from 'lucide-react';

interface NavItem {
  label: string; href: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  children?: NavItem[];
}

const HRMS_NAV: NavItem[] = [
  { label: 'Dashboard', href: '/dashboard', icon: LayoutDashboard },
  { label: 'Announcements', href: '/dashboard/announcements', icon: Megaphone },
  { label: 'Recruitment', href: '/dashboard/ats', icon: UserPlus },
  { label: 'Employees', href: '/dashboard/employees', icon: Users },
  { label: 'Leave', href: '/dashboard/leave', icon: Calendar },
  { label: 'Attendance', href: '/dashboard/attendance', icon: Clock },
  { label: 'Payroll', href: '/dashboard/payroll', icon: DollarSign },
  { label: 'Performance', href: '/dashboard/performance', icon: Target },
  { label: 'L&D', href: '/dashboard/lnd', icon: BookOpen },
  { label: 'Expenses', href: '/dashboard/expenses', icon: Receipt },
  { label: 'Helpdesk', href: '/dashboard/helpdesk', icon: LifeBuoy },
];

const CASE_ENGINE_NAV: NavItem[] = [
  { label: 'All Tickets', href: '/dashboard/case-engine/tickets', icon: Ticket },
  { label: 'Kanban Board', href: '/dashboard/case-engine/kanban', icon: Kanban },
  { label: 'Knowledge Base', href: '/dashboard/case-engine/kb', icon: BookMarked },
  { label: 'CRM Lite', href: '/dashboard/case-engine/crm', icon: Globe },
  { label: 'Analytics', href: '/dashboard/case-engine/analytics', icon: TrendingUp },
  { label: 'SLA Policies', href: '/dashboard/case-engine/sla', icon: Clock },
  { label: 'Routing Rules', href: '/dashboard/case-engine/assignment-rules', icon: Zap },
];

const PLATFORM_NAV: NavItem[] = [
  { label: 'AI Copilot', href: '/dashboard/ai', icon: Bot, badge: 'BETA' },
  { label: 'Report Builder', href: '/dashboard/report-builder', icon: BarChart3 },
  { label: 'Automation', href: '/dashboard/automation', icon: Wand2 },
  { label: 'Insights', href: '/dashboard/insights', icon: Star },
];

const ADMIN_NAV: NavItem[] = [
  { label: 'Plugins', href: '/dashboard/plugins', icon: Puzzle },
  { label: 'Backup', href: '/dashboard/backup', icon: HardDrive },
  { label: 'Audit Log', href: '/dashboard/audit', icon: Shield },
  { label: 'Settings', href: '/dashboard/settings', icon: Settings },
  { label: 'Onboarding', href: '/dashboard/onboarding', icon: LogIn },
];

function NavSection({ title, items, isActive }: { title: string; items: NavItem[]; isActive: (href: string) => boolean }) {
  const [open, setOpen] = useState(true);
  const hasActive = items.some(i => isActive(i.href));

  return (
    <div className="mb-1">
      <button
        onClick={() => setOpen(o => !o)}
        className={`w-full flex items-center justify-between px-3 py-1.5 mb-1 font-pixel text-[7px] uppercase tracking-widest transition-colors ${hasActive ? 'text-primary-600' : 'text-primary-800 hover:text-primary-600'}`}
      >
        {title}
        {open ? <ChevronDown className="w-2.5 h-2.5" /> : <ChevronRight className="w-2.5 h-2.5" />}
      </button>
      {open && (
        <ul className="space-y-0.5" role="list">
          {items.map(item => (
            <li key={item.href}>
              <Link
                href={item.href}
                className={`nav-item ${isActive(item.href) ? 'active' : ''}`}
                aria-current={isActive(item.href) ? 'page' : undefined}
              >
                <item.icon className="w-3.5 h-3.5 shrink-0" aria-hidden />
                <span className="flex-1 truncate">{item.label}</span>
                {item.badge && (
                  <span className="px-1 py-0.5 bg-accent/20 border border-accent/50 text-accent font-pixel text-[6px] rounded-none">
                    {item.badge}
                  </span>
                )}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function Sidebar() {
  const pathname = usePathname();
  const isActive = (href: string) =>
    href === '/dashboard' ? pathname === href : pathname.startsWith(href);

  return (
    <aside
      className="fixed left-0 top-0 h-full w-64 bg-retro-bg-secondary border-r border-retro-border flex flex-col z-sticky overflow-hidden"
      aria-label="Main navigation"
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-retro-border shrink-0">
        <div className="w-8 h-8 bg-primary-900 border-2 border-primary-700 flex items-center justify-center text-primary-crt font-pixel text-[8px]">
          RW
        </div>
        <div>
          <p className="font-pixel text-[8px] text-primary-crt leading-none">RetroWorks</p>
          <p className="font-mono text-[9px] text-primary-700 mt-0.5">Unified Platform</p>
        </div>
      </div>

      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 focus:z-50 focus:px-4 focus:py-2 focus:bg-primary-900 focus:text-primary-crt focus:font-pixel focus:text-[8px]"
      >
        Skip to main content
      </a>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-3 px-2" aria-label="Platform navigation">
        {/* HRMS */}
        <NavSection title="HRMS" items={HRMS_NAV} isActive={isActive} />

        {/* Case Engine — visual separator */}
        <div className="my-2 mx-3 border-t border-retro-border/50" />
        <div className="flex items-center gap-2 px-3 py-1 mb-1">
          <Ticket className="w-3 h-3 text-primary-crt" />
          <span className="font-pixel text-[7px] text-primary-crt">CASE ENGINE</span>
        </div>
        <ul className="space-y-0.5 mb-2" role="list">
          {CASE_ENGINE_NAV.map(item => (
            <li key={item.href}>
              <Link href={item.href} className={`nav-item ${isActive(item.href) ? 'active' : ''}`} aria-current={isActive(item.href) ? 'page' : undefined}>
                <item.icon className="w-3.5 h-3.5 shrink-0" aria-hidden />
                <span className="flex-1 truncate">{item.label}</span>
              </Link>
            </li>
          ))}
        </ul>

        {/* Platform */}
        <div className="my-2 mx-3 border-t border-retro-border/50" />
        <NavSection title="Platform" items={PLATFORM_NAV} isActive={isActive} />

        {/* Admin */}
        <div className="my-2 mx-3 border-t border-retro-border/50" />
        <NavSection title="Admin" items={ADMIN_NAV} isActive={isActive} />
      </nav>

      {/* User footer */}
      <div className="border-t border-retro-border p-3 shrink-0">
        <div className="flex items-center gap-2">
          <div className="pixel-avatar w-8 h-8 text-[8px] shrink-0">AD</div>
          <div className="min-w-0 flex-1">
            <p className="font-mono text-xs text-primary-300 truncate">Admin User</p>
            <p className="font-mono text-[10px] text-primary-700 truncate">admin@company.com</p>
          </div>
          <span className="status-dot online" title="Online" />
        </div>
      </div>
    </aside>
  );
}
