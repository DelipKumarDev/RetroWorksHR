'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, ComposedChart, Area,
} from 'recharts';
import {
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle,
  Users, Ticket, Clock, BarChart2, Target, Zap,
} from 'lucide-react';

const api = async (path: string) => {
  const r = await fetch(`/api/v1${path}`, { headers: { Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}` } });
  return r.json();
};

const CRT = ['#4ade80', '#22d3ee', '#a78bfa', '#f59e0b', '#f87171', '#34d399', '#60a5fa', '#c084fc'];

const PRIORITY_COLORS: Record<string, string> = { p1: '#ef4444', p2: '#f59e0b', p3: '#22d3ee', p4: '#4b5563' };
const PRIORITY_LABELS: Record<string, string> = { p1: 'Critical', p2: 'High', p3: 'Medium', p4: 'Low' };

function StatCard({ label, value, sub, trend, icon, color = 'text-primary-crt' }: any) {
  const isPositive = parseFloat(trend) > 0;
  return (
    <div className="p-5 bg-retro-card border border-retro-border rounded-xl">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className={`font-pixel text-[18px] ${color}`}>{value}</p>
          <p className="font-mono text-xs text-primary-600 mt-1">{label}</p>
          {sub && <p className="font-mono text-[9px] text-primary-800 mt-0.5">{sub}</p>}
        </div>
        <div className="text-primary-700">{icon}</div>
      </div>
      {trend !== undefined && (
        <div className={`flex items-center gap-1 mt-2 font-mono text-[9px] ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
          {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
          {Math.abs(parseFloat(trend))}% vs last month
        </div>
      )}
    </div>
  );
}

function VolumeTrendChart({ data }: { data: any[] }) {
  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <p className="font-pixel text-[8px] text-primary-500 mb-4">12-MONTH TICKET VOLUME</p>
      <ResponsiveContainer width="100%" height={240}>
        <ComposedChart data={data} margin={{ left: -20, right: 5 }}>
          <XAxis dataKey="label" tick={{ fontSize: 8, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <YAxis tick={{ fontSize: 8, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #1a2332', fontFamily: 'monospace', fontSize: 9 }} />
          <Legend wrapperStyle={{ fontSize: 9, fontFamily: 'monospace' }} />
          <Bar dataKey="created" fill="#4ade80" name="Created" radius={[2, 2, 0, 0]} opacity={0.8} />
          <Bar dataKey="resolved" fill="#22d3ee" name="Resolved" radius={[2, 2, 0, 0]} opacity={0.8} />
          <Line dataKey="breached" stroke="#ef4444" name="SLA Breached" strokeWidth={2} dot={false} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}

function AgentTable({ data }: { data: any[] }) {
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [year, setYear] = useState(new Date().getFullYear());
  const { data: agentData = [] } = useQuery({
    queryKey: ['agent-perf', month, year],
    queryFn: () => api(`/case-engine/analytics/agent-performance?month=${month}&year=${year}`).then(r => r.data ?? []),
  });
  const agents = agentData.length ? agentData : data;

  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <p className="font-pixel text-[8px] text-primary-500">AGENT PERFORMANCE</p>
        <div className="flex items-center gap-2">
          <select value={month} onChange={e => setMonth(+e.target.value)} className="px-2 py-1 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-400 focus:outline-none">
            {Array.from({ length: 12 }, (_, i) => <option key={i+1} value={i+1}>{new Date(2024, i).toLocaleString('en-IN', { month: 'short' })}</option>)}
          </select>
          <select value={year} onChange={e => setYear(+e.target.value)} className="px-2 py-1 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-400 focus:outline-none">
            {[2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>
      </div>
      <div className="overflow-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-retro-border">
              {['Agent', 'Designation', 'Assigned', 'Resolved', 'Resolution %', 'SLA Breached', 'Breach %'].map(h => (
                <th key={h} className="px-3 py-2 text-left font-pixel text-[7px] text-primary-700 whitespace-nowrap">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(agents as any[]).slice(0, 20).map((a: any) => (
              <tr key={a.agentId} className="border-b border-retro-border/30 hover:bg-retro-bg">
                <td className="px-3 py-2.5 font-mono text-xs text-primary-300">{a.name}</td>
                <td className="px-3 py-2.5 font-mono text-[10px] text-primary-600">{a.designation ?? '—'}</td>
                <td className="px-3 py-2.5 font-pixel text-[10px] text-primary-crt">{a.assigned}</td>
                <td className="px-3 py-2.5 font-pixel text-[10px] text-green-400">{a.resolved}</td>
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 bg-retro-border rounded-full"><div className="h-full bg-green-500 rounded-full" style={{ width: a.resolutionRate }} /></div>
                    <span className="font-mono text-[9px] text-green-400 w-10 shrink-0">{a.resolutionRate}</span>
                  </div>
                </td>
                <td className="px-3 py-2.5 font-pixel text-[10px] text-red-400">{a.slaBreached}</td>
                <td className="px-3 py-2.5 font-mono text-[10px] text-red-700">{a.slaBreachRate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function HeadcountCorrelationChart({ data }: { data: any[] }) {
  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <p className="font-pixel text-[8px] text-primary-500 mb-1">TICKET vs HEADCOUNT CORRELATION</p>
      <p className="font-mono text-[9px] text-primary-800 mb-4">Tickets per employee ratio — rising ratio suggests need for automation</p>
      <ResponsiveContainer width="100%" height={200}>
        <ComposedChart data={data} margin={{ left: -20, right: 5 }}>
          <XAxis dataKey="label" tick={{ fontSize: 8, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <YAxis yAxisId="left" tick={{ fontSize: 8, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 8, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #1a2332', fontFamily: 'monospace', fontSize: 9 }} />
          <Bar yAxisId="left" dataKey="ticketCount" fill="#4ade80" name="Tickets" radius={[2, 2, 0, 0]} opacity={0.7} />
          <Line yAxisId="right" dataKey="ticketsPerEmployee" stroke="#f59e0b" name="Tickets/Employee" strokeWidth={2} dot={false} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}

function SLABreachChart({ data }: { data: any }) {
  const byCategory = data?.byCategory ?? [];
  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <p className="font-pixel text-[8px] text-primary-500">SLA BREACH BY CATEGORY</p>
        <div className="flex items-center gap-2">
          <span className={`font-pixel text-[14px] ${parseFloat(data?.breachRate) > 20 ? 'text-red-400' : 'text-green-400'}`}>{data?.breachRate ?? '—'}</span>
          <span className="font-mono text-[9px] text-primary-700">breach rate</span>
        </div>
      </div>
      <div className="space-y-2">
        {byCategory.slice(0, 8).map((c: any, i: number) => (
          <div key={c.category} className="flex items-center gap-3">
            <span className="font-mono text-[10px] text-primary-500 w-32 truncate">{c.category}</span>
            <div className="flex-1 h-1.5 bg-retro-border rounded-full">
              <div className="h-full rounded-full" style={{ width: `${Math.min(100, (c.count / (byCategory[0]?.count ?? 1)) * 100)}%`, background: CRT[i % CRT.length] }} />
            </div>
            <span className="font-pixel text-[10px] text-primary-crt w-8 text-right">{c.count}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function CategoryBreakdownChart({ data }: { data: any[] }) {
  const top8 = data.slice(0, 8).map((c, i) => ({ ...c, fill: CRT[i % CRT.length] }));
  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <p className="font-pixel text-[8px] text-primary-500 mb-4">TICKETS BY CATEGORY</p>
      <div className="grid grid-cols-2 gap-5">
        <ResponsiveContainer width="100%" height={180}>
          <PieChart>
            <Pie data={top8} dataKey="total" nameKey="name" cx="50%" cy="50%" outerRadius={75} label={({ percent }) => `${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={8}>
              {top8.map((c, i) => <Cell key={i} fill={c.fill} />)}
            </Pie>
            <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #1a2332', fontFamily: 'monospace', fontSize: 9 }} />
          </PieChart>
        </ResponsiveContainer>
        <div className="space-y-2 overflow-auto max-h-44">
          {top8.map((c, i) => (
            <div key={c.name} className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full shrink-0" style={{ background: c.fill }} />
              <span className="font-mono text-[10px] text-primary-500 flex-1 truncate">{c.name}</span>
              <span className="font-pixel text-[10px] text-primary-crt">{c.total}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function LeaveQueryTrendChart({ data }: { data: any[] }) {
  return (
    <div className="bg-retro-card border border-retro-border rounded-xl p-5">
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="font-pixel text-[8px] text-primary-500">LEAVE/PAYROLL/IT QUERY TRENDS</p>
          <p className="font-mono text-[9px] text-primary-800 mt-1">Recurring issues → automation candidates</p>
        </div>
        <div className="flex items-center gap-1 px-2 py-1 bg-yellow-950/30 border border-yellow-900 rounded">
          <Zap className="w-3 h-3 text-yellow-400" />
          <span className="font-mono text-[8px] text-yellow-400">AI insight ready</span>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={180}>
        <LineChart data={data} margin={{ left: -20, right: 5 }}>
          <XAxis dataKey="label" tick={{ fontSize: 8, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <YAxis tick={{ fontSize: 8, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #1a2332', fontFamily: 'monospace', fontSize: 9 }} />
          <Legend wrapperStyle={{ fontSize: 9, fontFamily: 'monospace' }} />
          <Line dataKey="leaveTickets" stroke="#4ade80" name="Leave" strokeWidth={2} dot={false} />
          <Line dataKey="payrollTickets" stroke="#f59e0b" name="Payroll" strokeWidth={2} dot={false} />
          <Line dataKey="itTickets" stroke="#22d3ee" name="IT" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────────────────

export function CaseAnalyticsDashboard() {
  const { data: dashData } = useQuery({ queryKey: ['case-dashboard'], queryFn: () => api('/case-engine/analytics/dashboard').then(r => r.data ?? {}) });
  const { data: volumeData = [] } = useQuery({ queryKey: ['case-volume'], queryFn: () => api('/case-engine/analytics/volume-trend').then(r => r.data ?? []) });
  const { data: slaData } = useQuery({ queryKey: ['case-sla'], queryFn: () => api('/case-engine/analytics/sla-report').then(r => r.data) });
  const { data: agentData = [] } = useQuery({ queryKey: ['case-agents'], queryFn: () => api('/case-engine/analytics/agent-performance').then(r => r.data ?? []) });
  const { data: correlationData = [] } = useQuery({ queryKey: ['case-correlation'], queryFn: () => api('/case-engine/analytics/headcount-correlation').then(r => r.data ?? []) });
  const { data: categoryData = [] } = useQuery({ queryKey: ['case-categories'], queryFn: () => api('/case-engine/analytics/category-breakdown').then(r => r.data ?? []) });
  const { data: leaveQueryData = [] } = useQuery({ queryKey: ['case-leave-query'], queryFn: () => api('/case-engine/analytics/leave-query-trend').then(r => r.data ?? []) });

  const summary = (dashData as any)?.summary ?? {};

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">CASE ENGINE ANALYTICS</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">SLA performance · Agent efficiency · Cross-domain insights</p>
        </div>
      </div>

      {/* Summary KPIs */}
      <div className="grid grid-cols-6 gap-3">
        <StatCard label="Open Tickets" value={summary.open ?? '—'} icon={<Ticket className="w-4 h-4" />} />
        <StatCard label="In Progress" value={summary.inProgress ?? '—'} icon={<Clock className="w-4 h-4" />} color="text-yellow-400" />
        <StatCard label="Resolved This Month" value={summary.resolvedThisMonth ?? '—'} trend={summary.resolutionTrend?.replace('%','')} icon={<CheckCircle className="w-4 h-4 text-green-400" />} color="text-green-400" />
        <StatCard label="SLA Breached" value={summary.slaBreached ?? '—'} icon={<AlertTriangle className="w-4 h-4 text-red-400" />} color="text-red-400" />
        <StatCard label="New This Month" value={summary.newThisMonth ?? '—'} trend={summary.volumeTrend?.replace('%','')} icon={<BarChart2 className="w-4 h-4" />} />
        <StatCard label="Resolution Trend" value={summary.resolutionTrend ?? '—'} icon={<Target className="w-4 h-4 text-purple-400" />} color="text-purple-400" />
      </div>

      {/* Row 2 */}
      <div className="grid grid-cols-3 gap-4">
        <div className="col-span-2"><VolumeTrendChart data={volumeData as any[]} /></div>
        <div><SLABreachChart data={slaData} /></div>
      </div>

      {/* Row 3 */}
      <div className="grid grid-cols-2 gap-4">
        <CategoryBreakdownChart data={categoryData as any[]} />
        <HeadcountCorrelationChart data={correlationData as any[]} />
      </div>

      {/* Row 4 */}
      <LeaveQueryTrendChart data={leaveQueryData as any[]} />

      {/* Agent Performance */}
      <AgentTable data={agentData as any[]} />
    </div>
  );
}
