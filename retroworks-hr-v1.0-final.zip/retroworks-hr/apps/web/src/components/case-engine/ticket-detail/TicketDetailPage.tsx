'use client';

import { useState, useRef, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Send, Lock, Unlock, Bot, BookOpen, AlertTriangle, Clock,
  ChevronDown, User, Tag, Paperclip, ArrowLeft, CheckCircle,
  RefreshCw, Sparkles, MessageSquare, Activity, Settings,
} from 'lucide-react';
import Link from 'next/link';
import { useParams } from 'next/navigation';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers } });
  return res.json();
};

const PRIORITY_COLORS: Record<string, string> = { p1: 'text-red-400', p2: 'text-orange-400', p3: 'text-blue-400', p4: 'text-primary-500' };
const PRIORITY_LABELS: Record<string, string> = { p1: 'Critical', p2: 'High', p3: 'Normal', p4: 'Low' };
const STATUS_COLORS: Record<string, string> = { 'open': 'text-green-400', 'in-progress': 'text-blue-400', 'pending': 'text-yellow-400', 'resolved': 'text-primary-400', 'closed': 'text-primary-700' };
const STATUSES = ['open', 'in-progress', 'pending', 'waiting', 'resolved', 'closed'];
const TYPE_ICONS: Record<string, string> = { internal: '🏢', external: '🌐', payroll: '💰', IT: '💻', admin: '📋', vendor: '🤝', custom: '⚡' };

// ─── Message Bubble ───────────────────────────────────────────────────────────

function MessageBubble({ msg, isAgent }: { msg: any; isAgent: boolean }) {
  const isInternal = msg.isInternal;
  const isAI = msg.isAiDraft;
  const initials = isAgent ? 'ME' : (msg.authorType === 'system' ? '⚙️' : isAI ? '🤖' : 'C');

  return (
    <div className={`flex gap-3 ${isAgent ? 'flex-row-reverse' : 'flex-row'}`}>
      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-mono text-[9px] shrink-0 border ${isInternal ? 'bg-yellow-950 border-yellow-800 text-yellow-400' : isAI ? 'bg-purple-950 border-purple-800' : 'bg-primary-900 border-primary-800 text-primary-400'}`}>
        {initials}
      </div>
      <div className={`max-w-[70%] space-y-1 ${isAgent ? 'items-end' : 'items-start'} flex flex-col`}>
        <div className={`px-4 py-3 rounded-xl font-mono text-xs leading-relaxed whitespace-pre-wrap ${isInternal ? 'bg-yellow-950/30 border border-yellow-900/40 text-yellow-300' : isAgent ? 'bg-primary-950 border border-primary-800 text-primary-300' : 'bg-retro-card border border-retro-border text-primary-300'}`}>
          {isInternal && <span className="flex items-center gap-1 font-pixel text-[7px] text-yellow-600 mb-2"><Lock className="w-2.5 h-2.5" />INTERNAL NOTE</span>}
          {isAI && <span className="flex items-center gap-1 font-pixel text-[7px] text-purple-500 mb-2"><Bot className="w-2.5 h-2.5" />AI DRAFT</span>}
          {msg.body}
        </div>
        <span className="font-mono text-[9px] text-primary-800">{new Date(msg.createdAt).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}</span>
      </div>
    </div>
  );
}

// ─── KB Suggestion Panel ──────────────────────────────────────────────────────

function KBSuggestions({ tenantTitle, description }: { tenantTitle: string; description?: string }) {
  const { data } = useQuery({
    queryKey: ['kb-suggest', tenantTitle],
    queryFn: () => api('/case-engine/ai/suggest-kb', { method: 'POST', body: JSON.stringify({ title: tenantTitle, description }) }).then(r => r.data),
    enabled: !!tenantTitle,
  });

  if (!data?.suggested?.length) return null;

  return (
    <div className="p-3 bg-retro-bg border border-primary-900 rounded-lg">
      <p className="font-pixel text-[7px] text-primary-700 mb-2 flex items-center gap-1"><BookOpen className="w-3 h-3" />KB SUGGESTIONS</p>
      <div className="space-y-1.5">
        {data.suggested.slice(0, 3).map((a: any) => (
          <a key={a.id} href={`/dashboard/case-engine/kb/${a.id}`} target="_blank" className="block p-2 bg-retro-card border border-retro-border rounded hover:border-primary-700 transition-colors">
            <p className="font-mono text-[10px] text-primary-400 truncate">{a.title}</p>
            <p className="font-mono text-[9px] text-primary-700">{a.category?.name} · {a.views} views · 👍 {a.helpful}</p>
          </a>
        ))}
      </div>
    </div>
  );
}

// ─── SLA Indicator ────────────────────────────────────────────────────────────

function SLAIndicator({ ticket }: { ticket: any }) {
  if (!ticket.slaResolutionDue) return null;
  const due = new Date(ticket.slaResolutionDue);
  const now = new Date();
  const remainingMs = due.getTime() - now.getTime();
  const totalMs = due.getTime() - new Date(ticket.createdAt).getTime();
  const pct = Math.max(0, Math.min(100, ((totalMs - remainingMs) / totalMs) * 100));
  const remainingH = Math.max(0, Math.floor(remainingMs / 3_600_000));
  const remainingM = Math.max(0, Math.floor((remainingMs % 3_600_000) / 60_000));

  const color = ticket.slaBreached ? 'bg-red-400' : remainingMs < 3_600_000 ? 'bg-yellow-400' : 'bg-green-400';

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between font-mono text-[10px]">
        <span className="text-primary-600">Resolution SLA</span>
        <span className={ticket.slaBreached ? 'text-red-400' : remainingMs < 3_600_000 ? 'text-yellow-400' : 'text-primary-400'}>
          {ticket.slaBreached ? 'BREACHED' : `${remainingH}h ${remainingM}m left`}
        </span>
      </div>
      <div className="h-1.5 bg-retro-bg rounded-full overflow-hidden border border-retro-border">
        <div className={`h-full rounded-full transition-all ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <p className="font-mono text-[9px] text-primary-800">Due: {due.toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}</p>
    </div>
  );
}

// ─── Activity Timeline ────────────────────────────────────────────────────────

function ActivityTimeline({ activities }: { activities: any[] }) {
  return (
    <div className="space-y-2">
      {activities.slice(0, 15).map((a: any) => (
        <div key={a.id} className="flex items-start gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-primary-800 mt-1.5 shrink-0" />
          <div>
            <p className="font-mono text-[10px] text-primary-500">{a.event.replace(/_/g, ' ')}{a.oldValue && a.newValue ? `: ${a.oldValue} → ${a.newValue}` : ''}</p>
            <p className="font-mono text-[9px] text-primary-800">{new Date(a.createdAt).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Main Ticket Detail ───────────────────────────────────────────────────────

type Panel = 'thread' | 'activity' | 'kb';

export function TicketDetailPage() {
  const params = useParams<{ id: string }>();
  const ticketId = params?.id ?? '';
  const [replyBody, setReplyBody] = useState('');
  const [isInternal, setIsInternal] = useState(false);
  const [panel, setPanel] = useState<Panel>('thread');
  const [draftLoading, setDraftLoading] = useState(false);
  const threadRef = useRef<HTMLDivElement>(null);
  const qc = useQueryClient();

  const { data: ticket, isLoading } = useQuery({ queryKey: ['ticket', ticketId], queryFn: () => api(`/case-engine/tickets/${ticketId}`).then(r => r.data) });
  const { data: messagesData } = useQuery({ queryKey: ['ticket-messages', ticketId], queryFn: () => api(`/case-engine/tickets/${ticketId}/messages`).then(r => r.data ?? []), refetchInterval: 10000 });

  const messages: any[] = messagesData ?? [];

  const replyMut = useMutation({
    mutationFn: (dto: any) => api(`/case-engine/tickets/${ticketId}/messages`, { method: 'POST', body: JSON.stringify(dto) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['ticket-messages', ticketId] }); qc.invalidateQueries({ queryKey: ['ticket', ticketId] }); setReplyBody(''); },
  });

  const statusMut = useMutation({ mutationFn: (status: string) => api(`/case-engine/tickets/${ticketId}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }), onSuccess: () => qc.invalidateQueries({ queryKey: ['ticket', ticketId] }) });
  const assignMut = useMutation({ mutationFn: (dto: any) => api(`/case-engine/tickets/${ticketId}/assign`, { method: 'PATCH', body: JSON.stringify(dto) }), onSuccess: () => qc.invalidateQueries({ queryKey: ['ticket', ticketId] }) });

  const draftResponse = async () => {
    setDraftLoading(true);
    const res = await api(`/case-engine/ai/draft-response/${ticketId}`, { method: 'POST', body: JSON.stringify({}) }).catch(() => ({ data: { draft: '' } }));
    if (res.data?.draft) setReplyBody(res.data.draft);
    setDraftLoading(false);
  };

  useEffect(() => {
    if (threadRef.current) threadRef.current.scrollTop = threadRef.current.scrollHeight;
  }, [messages.length]);

  if (isLoading) return <div className="flex items-center justify-center h-64 font-mono text-primary-700"><RefreshCw className="w-5 h-5 animate-spin mr-3" />Loading ticket…</div>;
  if (!ticket) return <div className="text-center py-16 font-mono text-primary-700">Ticket not found</div>;

  return (
    <div className="flex h-[calc(100vh-80px)] gap-4 animate-fade-in">
      {/* Main thread column */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="flex items-start gap-3 mb-4">
          <Link href="/dashboard/case-engine/tickets" className="mt-1 text-primary-700 hover:text-primary-400"><ArrowLeft className="w-4 h-4" /></Link>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-mono text-xs text-primary-700">{ticket.ticketNumber}</span>
              <span className="font-mono text-xs">{TYPE_ICONS[ticket.type] ?? '📋'}</span>
              {ticket.slaBreached && <span className="flex items-center gap-1 px-1.5 py-0.5 bg-red-950 border border-red-800 rounded font-pixel text-[7px] text-red-400"><AlertTriangle className="w-2.5 h-2.5" />SLA BREACHED</span>}
              {ticket.sentiment === 'critical' && <span className="px-1.5 py-0.5 bg-red-950 border border-red-800 rounded font-pixel text-[7px] text-red-400">⚠️ CRITICAL SENTIMENT</span>}
            </div>
            <h1 className="font-mono text-base text-primary-200 mt-1">{ticket.title}</h1>
          </div>

          {/* Status dropdown */}
          <div className="relative">
            <select value={ticket.status} onChange={e => statusMut.mutate(e.target.value)} className={`px-3 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs focus:border-primary-600 focus:outline-none ${STATUS_COLORS[ticket.status]}`}>
              {STATUSES.map(s => <option key={s} value={s}>{s.charAt(0).toUpperCase() + s.slice(1)}</option>)}
            </select>
          </div>
        </div>

        {/* Tab bar */}
        <div className="flex items-center gap-1 p-1 bg-retro-bg border border-retro-border rounded-lg w-fit mb-4">
          {[['thread', <MessageSquare key="t" className="w-3 h-3" />, 'Thread'], ['activity', <Activity key="a" className="w-3 h-3" />, 'Activity'], ['kb', <BookOpen key="k" className="w-3 h-3" />, 'KB']].map(([id, icon, label]) => (
            <button key={id as string} onClick={() => setPanel(id as Panel)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded font-mono text-xs transition-all ${panel === id ? 'bg-primary-900 border border-primary-700 text-primary-300' : 'text-primary-700 hover:text-primary-500'}`}>
              {icon}{label}
            </button>
          ))}
        </div>

        {/* Thread / Activity / KB */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-2" ref={threadRef}>
          {panel === 'thread' && (
            <>
              {/* Original description */}
              {ticket.description && (
                <div className="p-4 bg-retro-card border border-retro-border rounded-xl">
                  <p className="font-pixel text-[7px] text-primary-700 mb-2">ORIGINAL DESCRIPTION</p>
                  <p className="font-mono text-xs text-primary-400 leading-relaxed whitespace-pre-wrap">{ticket.description}</p>
                </div>
              )}
              {messages.map(m => <MessageBubble key={m.id} msg={m} isAgent={m.authorType === 'employee' && m.authorId !== ticket.requesterId} />)}
            </>
          )}
          {panel === 'activity' && <ActivityTimeline activities={ticket.activities ?? []} />}
          {panel === 'kb' && <KBSuggestions tenantTitle={ticket.title} description={ticket.description} />}
        </div>

        {/* Reply box */}
        <div className="mt-4 bg-retro-card border border-retro-border rounded-xl p-4 space-y-3">
          <div className="flex items-center gap-2">
            <button onClick={() => setIsInternal(f => !f)} className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded border font-mono text-xs transition-all ${isInternal ? 'bg-yellow-950 border-yellow-800 text-yellow-400' : 'bg-retro-bg border-retro-border text-primary-600 hover:text-primary-400'}`}>
              {isInternal ? <Lock className="w-3 h-3" /> : <Unlock className="w-3 h-3" />}
              {isInternal ? 'Internal Note' : 'Public Reply'}
            </button>
            <button onClick={draftResponse} disabled={draftLoading} className="flex items-center gap-1.5 px-2.5 py-1.5 bg-retro-bg border border-primary-900 rounded font-mono text-xs text-primary-600 hover:text-primary-400 disabled:opacity-40">
              {draftLoading ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
              AI Draft
            </button>
          </div>
          <textarea value={replyBody} onChange={e => setReplyBody(e.target.value)} placeholder={isInternal ? 'Internal note — only agents can see this…' : 'Type a reply…'} rows={3} className={`w-full px-3 py-2 bg-retro-bg border rounded font-mono text-xs text-primary-300 focus:outline-none resize-none ${isInternal ? 'border-yellow-900 focus:border-yellow-700' : 'border-retro-border focus:border-primary-600'}`} />
          <div className="flex items-center justify-between">
            <span className="font-mono text-[9px] text-primary-800">{replyBody.length} chars</span>
            <button onClick={() => replyMut.mutate({ body: replyBody, isInternal })} disabled={!replyBody.trim() || replyMut.isPending} className="flex items-center gap-1.5 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 disabled:opacity-40 shadow-glow">
              <Send className="w-3 h-3" /> {replyMut.isPending ? 'Sending…' : isInternal ? 'Save Note' : 'Send Reply'}
            </button>
          </div>
        </div>
      </div>

      {/* Right sidebar */}
      <div className="w-72 shrink-0 space-y-4 overflow-y-auto">
        {/* SLA Panel */}
        <div className="p-4 bg-retro-card border border-retro-border rounded-xl space-y-3">
          <p className="font-pixel text-[8px] text-primary-500">SLA TRACKING</p>
          <SLAIndicator ticket={ticket} />
        </div>

        {/* Details */}
        <div className="p-4 bg-retro-card border border-retro-border rounded-xl space-y-3">
          <p className="font-pixel text-[8px] text-primary-500">TICKET DETAILS</p>
          {[
            { label: 'Priority', value: <span className={`font-mono text-xs ${PRIORITY_COLORS[ticket.priority]}`}>{PRIORITY_LABELS[ticket.priority]}</span> },
            { label: 'Type', value: <span className="font-mono text-xs text-primary-400">{TYPE_ICONS[ticket.type]} {ticket.type}</span> },
            { label: 'Category', value: <span className="font-mono text-xs text-primary-400">{ticket.category?.name ?? '—'}</span> },
            { label: 'Source', value: <span className="font-mono text-xs text-primary-600">{ticket.source}</span> },
            { label: 'Sentiment', value: ticket.sentiment ? <span className={`font-mono text-xs ${ticket.sentiment === 'critical' ? 'text-red-400' : ticket.sentiment === 'negative' ? 'text-orange-400' : ticket.sentiment === 'positive' ? 'text-green-400' : 'text-primary-500'}`}>{ticket.sentiment}</span> : <span className="font-mono text-xs text-primary-800">—</span> },
            { label: 'Linked to', value: ticket.linkedEntityType ? <span className="font-mono text-xs text-primary-600">{ticket.linkedEntityType}</span> : <span className="font-mono text-xs text-primary-800">—</span> },
            { label: 'Created', value: <span className="font-mono text-xs text-primary-600">{new Date(ticket.createdAt).toLocaleDateString('en-IN')}</span> },
          ].map(d => (
            <div key={d.label} className="flex items-center justify-between"><span className="font-mono text-[10px] text-primary-700">{d.label}</span>{d.value}</div>
          ))}
        </div>

        {/* Tags */}
        {ticket.tagLinks?.length > 0 && (
          <div className="p-4 bg-retro-card border border-retro-border rounded-xl">
            <p className="font-pixel text-[8px] text-primary-500 mb-2">TAGS</p>
            <div className="flex flex-wrap gap-1.5">
              {ticket.tagLinks.map((tl: any) => <span key={tl.tagId} className="px-2 py-0.5 rounded font-mono text-[9px]" style={{ color: tl.tag.color, borderColor: tl.tag.color + '40', border: '1px solid' }}>{tl.tag.name}</span>)}
            </div>
          </div>
        )}

        {/* Followers */}
        {ticket.followers?.length > 0 && (
          <div className="p-4 bg-retro-card border border-retro-border rounded-xl">
            <p className="font-pixel text-[8px] text-primary-500 mb-2">FOLLOWERS</p>
            <div className="flex flex-wrap gap-1.5">
              {ticket.followers.map((f: any) => (
                <div key={f.userId} className="w-7 h-7 rounded-full bg-primary-900 border border-primary-800 flex items-center justify-center font-mono text-[8px] text-primary-500">{f.userId.slice(0, 2).toUpperCase()}</div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
