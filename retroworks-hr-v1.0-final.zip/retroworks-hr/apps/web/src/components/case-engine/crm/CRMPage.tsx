'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Building2, Users, TrendingUp, Plus, ChevronRight, Ticket,
  Phone, Mail, Globe, Search, Pencil, X, DollarSign,
} from 'lucide-react';

const api = async (path: string, opts?: RequestInit) => {
  const r = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers } });
  return r.json();
};

const STAGE_COLORS: Record<string, string> = {
  prospect: 'text-primary-500 border-primary-800 bg-primary-950',
  qualified: 'text-blue-400 border-blue-900 bg-blue-950',
  proposal: 'text-yellow-400 border-yellow-900 bg-yellow-950',
  negotiation: 'text-orange-400 border-orange-900 bg-orange-950',
  won: 'text-green-400 border-green-900 bg-green-950',
  lost: 'text-red-400 border-red-900 bg-red-950',
};

const STAGE_PCT: Record<string, number> = { prospect: 10, qualified: 25, proposal: 50, negotiation: 75, won: 100, lost: 0 };

function AccountModal({ account, onSave, onClose }: { account?: any; onSave: (data: any) => void; onClose: () => void }) {
  const [form, setForm] = useState({ name: account?.name ?? '', industry: account?.industry ?? '', website: account?.website ?? '', phone: account?.phone ?? '', email: account?.email ?? '', tier: account?.tier ?? 'smb' });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative bg-retro-card border border-primary-800 rounded-xl p-6 w-full max-w-lg space-y-4">
        <h3 className="font-pixel text-[9px] text-primary-crt">{account ? 'EDIT ACCOUNT' : 'NEW ACCOUNT'}</h3>
        <div className="grid grid-cols-2 gap-3">
          {[
            { k: 'name', label: 'Company Name', span: 'col-span-2' },
            { k: 'industry', label: 'Industry' },
            { k: 'website', label: 'Website' },
            { k: 'email', label: 'Email' },
            { k: 'phone', label: 'Phone' },
          ].map(f => (
            <div key={f.k} className={f.span}>
              <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">{f.label.toUpperCase()}</label>
              <input value={(form as any)[f.k]} onChange={e => setForm(p => ({ ...p, [f.k]: e.target.value }))} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none" />
            </div>
          ))}
          <div>
            <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">TIER</label>
            <select value={form.tier} onChange={e => setForm(p => ({ ...p, tier: e.target.value }))} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:outline-none">
              {['enterprise', 'mid-market', 'smb'].map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
        </div>
        <div className="flex gap-3 pt-2">
          <button onClick={() => onSave(form)} className="flex-1 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400">{account ? 'Save Changes' : 'Create Account'}</button>
          <button onClick={onClose} className="flex-1 py-2 border border-retro-border rounded font-mono text-xs text-primary-600">Cancel</button>
        </div>
      </div>
    </div>
  );
}

function AccountsTab() {
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<any | null>(null);
  const [creating, setCreating] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const qc = useQueryClient();

  const { data: accounts = [] } = useQuery({ queryKey: ['crm-accounts'], queryFn: () => api('/case-engine/crm/accounts').then(r => r.data ?? []) });
  const createMut = useMutation({ mutationFn: (dto: any) => api('/case-engine/crm/accounts', { method: 'POST', body: JSON.stringify(dto) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['crm-accounts'] }); setCreating(false); } });
  const updateMut = useMutation({ mutationFn: ({ id, ...dto }: any) => api(`/case-engine/crm/accounts/${id}`, { method: 'PUT', body: JSON.stringify(dto) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['crm-accounts'] }); setEditing(null); } });

  const filtered = (accounts as any[]).filter((a: any) => !search || `${a.name} ${a.industry}`.toLowerCase().includes(search.toLowerCase()));
  const selected = selectedId ? (accounts as any[]).find((a: any) => a.id === selectedId) : null;

  return (
    <div className="grid grid-cols-3 gap-5">
      <div className="col-span-1 space-y-3">
        <div className="flex items-center gap-2">
          <div className="relative flex-1"><Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-primary-700" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search accounts…" className="w-full pl-7 pr-2 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none" /></div>
          <button onClick={() => setCreating(true)} className="flex items-center gap-1 px-2.5 py-1.5 bg-primary-900 border border-primary-700 rounded font-mono text-[9px] text-primary-400"><Plus className="w-3 h-3" />New</button>
        </div>
        <div className="space-y-1.5 max-h-[60vh] overflow-y-auto pr-1">
          {filtered.map((a: any) => (
            <div key={a.id} onClick={() => setSelectedId(a.id)} className={`p-3 rounded-lg border cursor-pointer transition-all ${selectedId === a.id ? 'bg-primary-950 border-primary-700' : 'bg-retro-card border-retro-border hover:border-primary-800'}`}>
              <div className="flex items-center gap-2">
                <Building2 className="w-3.5 h-3.5 text-primary-600 shrink-0" />
                <p className="font-mono text-sm text-primary-300 truncate">{a.name}</p>
              </div>
              <div className="flex items-center gap-2 mt-1">
                {a.industry && <span className="font-mono text-[9px] text-primary-700">{a.industry}</span>}
                {a.tier && <span className="font-mono text-[8px] border border-primary-800 rounded px-1 text-primary-700">{a.tier}</span>}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Account Detail */}
      <div className="col-span-2">
        {selected ? (
          <div className="bg-retro-card border border-retro-border rounded-xl p-5 space-y-5">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="font-mono text-lg text-primary-200">{selected.name}</h2>
                <div className="flex items-center gap-3 mt-1 font-mono text-[10px] text-primary-600">
                  {selected.industry && <span>{selected.industry}</span>}
                  {selected.tier && <span className="border border-primary-800 rounded px-1.5">{selected.tier}</span>}
                </div>
              </div>
              <button onClick={() => setEditing(selected)} className="flex items-center gap-1 font-mono text-[9px] text-primary-600 hover:text-primary-400"><Pencil className="w-3 h-3" />Edit</button>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {selected.email && <a href={`mailto:${selected.email}`} className="flex items-center gap-2 font-mono text-xs text-primary-500 hover:text-primary-400"><Mail className="w-3.5 h-3.5" />{selected.email}</a>}
              {selected.phone && <span className="flex items-center gap-2 font-mono text-xs text-primary-500"><Phone className="w-3.5 h-3.5" />{selected.phone}</span>}
              {selected.website && <a href={selected.website} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 font-mono text-xs text-primary-500 hover:text-primary-400"><Globe className="w-3.5 h-3.5" />{selected.website}</a>}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="font-pixel text-[7px] text-primary-700 mb-2">CONTACTS ({(selected.contacts ?? []).length})</p>
                <div className="space-y-1.5">{(selected.contacts ?? []).slice(0, 5).map((c: any) => <div key={c.id} className="flex items-center gap-2 p-2 bg-retro-bg border border-retro-border rounded"><Users className="w-3 h-3 text-primary-700" /><span className="font-mono text-xs text-primary-400">{c.firstName} {c.lastName}</span><span className="font-mono text-[9px] text-primary-700 ml-auto">{c.email}</span></div>)}</div>
              </div>
              <div>
                <p className="font-pixel text-[7px] text-primary-700 mb-2">OPPORTUNITIES</p>
                <div className="space-y-1.5">{(selected.opportunities ?? []).slice(0, 5).map((o: any) => <div key={o.id} className="flex items-center gap-2 p-2 bg-retro-bg border border-retro-border rounded"><span className={`px-1.5 py-0.5 rounded border text-[8px] font-pixel ${STAGE_COLORS[o.stage]}`}>{o.stage}</span><span className="font-mono text-xs text-primary-400 flex-1 truncate">{o.title}</span>{o.value && <span className="font-mono text-[10px] text-green-400">₹{Number(o.value).toLocaleString('en-IN')}</span>}</div>)}</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-48 gap-3 bg-retro-card border border-retro-border rounded-xl">
            <Building2 className="w-10 h-10 text-primary-800" />
            <p className="font-mono text-sm text-primary-700">Select an account to view details</p>
          </div>
        )}
      </div>

      {(creating || editing) && <AccountModal account={editing ?? undefined} onSave={data => editing ? updateMut.mutate({ id: editing.id, ...data }) : createMut.mutate(data)} onClose={() => { setCreating(false); setEditing(null); }} />}
    </div>
  );
}

function OpportunitiesTab() {
  const { data: accounts = [] } = useQuery({ queryKey: ['crm-accounts'], queryFn: () => api('/case-engine/crm/accounts').then(r => r.data ?? []) });

  const allOpps = (accounts as any[]).flatMap((a: any) => (a.opportunities ?? []).map((o: any) => ({ ...o, accountName: a.name })));
  const stages = ['prospect', 'qualified', 'proposal', 'negotiation', 'won', 'lost'];

  const totalValue = allOpps.filter(o => o.stage !== 'lost').reduce((s, o) => s + Number(o.value ?? 0), 0);
  const wonValue = allOpps.filter(o => o.stage === 'won').reduce((s, o) => s + Number(o.value ?? 0), 0);

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Pipeline Value', value: `₹${(totalValue / 100000).toFixed(1)}L`, icon: <DollarSign className="w-4 h-4 text-green-400" /> },
          { label: 'Won This Year', value: `₹${(wonValue / 100000).toFixed(1)}L`, icon: <TrendingUp className="w-4 h-4 text-blue-400" /> },
          { label: 'Open Deals', value: allOpps.filter(o => !['won', 'lost'].includes(o.stage)).length, icon: <Ticket className="w-4 h-4 text-yellow-400" /> },
        ].map(s => (
          <div key={s.label} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg">
            {s.icon}<div><p className="font-pixel text-[14px] text-primary-crt">{s.value}</p><p className="font-mono text-[9px] text-primary-700">{s.label}</p></div>
          </div>
        ))}
      </div>

      {/* Kanban-style pipeline */}
      <div className="grid grid-cols-6 gap-3 overflow-x-auto">
        {stages.map(stage => {
          const opps = allOpps.filter(o => o.stage === stage);
          return (
            <div key={stage} className="min-w-44">
              <div className="flex items-center justify-between mb-2">
                <span className={`px-2 py-0.5 rounded border text-[8px] font-pixel ${STAGE_COLORS[stage]}`}>{stage}</span>
                <span className="font-mono text-[9px] text-primary-700">{opps.length}</span>
              </div>
              <div className="space-y-2">
                {opps.map(o => (
                  <div key={o.id} className="p-3 bg-retro-card border border-retro-border rounded-lg space-y-1">
                    <p className="font-mono text-xs text-primary-300 line-clamp-2">{o.title}</p>
                    <p className="font-mono text-[9px] text-primary-700">{o.accountName}</p>
                    {o.value && <p className="font-pixel text-[9px] text-green-400">₹{Number(o.value).toLocaleString('en-IN')}</p>}
                    {o.probability > 0 && (
                      <div className="h-1 bg-retro-border rounded-full"><div className="h-full bg-primary-600 rounded-full" style={{ width: `${o.probability}%` }} /></div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

type Tab = 'accounts' | 'opportunities' | 'contacts';

export function CRMPage() {
  const [tab, setTab] = useState<Tab>('accounts');

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'accounts', label: 'Accounts', icon: <Building2 className="w-3.5 h-3.5" /> },
    { id: 'opportunities', label: 'Pipeline', icon: <TrendingUp className="w-3.5 h-3.5" /> },
    { id: 'contacts', label: 'Contacts', icon: <Users className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="space-y-5 animate-fade-in">
      <div><h1 className="font-pixel text-[10px] text-primary-400">CRM LITE</h1><p className="font-mono text-xs text-primary-700 mt-1">Accounts · Contacts · Pipeline — linked to tickets</p></div>
      <div className="flex items-center gap-1 p-1 bg-retro-bg border border-retro-border rounded-lg w-fit">
        {tabs.map(t => <button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-2 px-4 py-2 rounded font-mono text-xs transition-all ${tab === t.id ? 'bg-primary-900 border border-primary-700 text-primary-300' : 'text-primary-700 hover:text-primary-500'}`}>{t.icon}{t.label}</button>)}
      </div>
      {tab === 'accounts' && <AccountsTab />}
      {tab === 'opportunities' && <OpportunitiesTab />}
      {tab === 'contacts' && <div className="text-center py-16 text-primary-700 font-mono text-sm">Contacts linked to accounts — select an account to view</div>}
    </div>
  );
}
