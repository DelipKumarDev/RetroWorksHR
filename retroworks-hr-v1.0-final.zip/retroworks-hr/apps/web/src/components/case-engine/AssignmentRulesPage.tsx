'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Zap, Plus, Trash2, ToggleLeft, ToggleRight, ChevronRight,
  Play, RefreshCw, AlertTriangle, Check, X, Save,
} from 'lucide-react';

const api = async (path: string, opts?: RequestInit) => {
  const r = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers } });
  return r.json();
};

const OPERATORS = [
  { value: 'eq', label: '= equals' }, { value: 'neq', label: '≠ not equals' },
  { value: 'contains', label: '~ contains' }, { value: 'in', label: '∈ is in' },
  { value: 'gt', label: '> greater than' }, { value: 'lt', label: '< less than' },
  { value: 'is_null', label: '∅ is empty' }, { value: 'is_not_null', label: '✓ is set' },
];

function RuleEditor({ rule, catalogue, onSave, onCancel }: { rule?: any; catalogue: any; onSave: (data: any) => void; onCancel: () => void }) {
  const [name, setName] = useState(rule?.name ?? '');
  const [desc, setDesc] = useState(rule?.description ?? '');
  const [priority, setPriority] = useState(rule?.priority ?? 0);
  const [logic, setLogic] = useState(rule?.conditionLogic ?? 'AND');
  const [conditions, setConditions] = useState<any[]>(rule?.conditions ?? []);
  const [actions, setActions] = useState<any[]>(rule?.actions ?? []);

  const fields = catalogue?.fields ?? [];
  const actionCatalogue = catalogue?.actions ?? [];

  const addCondition = () => setConditions(c => [...c, { field: fields[0]?.key ?? '', operator: 'eq', value: '' }]);
  const removeCondition = (i: number) => setConditions(c => c.filter((_, j) => j !== i));
  const updateCondition = (i: number, key: string, val: string) => setConditions(c => c.map((r, j) => j === i ? { ...r, [key]: val } : r));

  const addAction = () => setActions(a => [...a, { type: actionCatalogue[0]?.type ?? '', value: '' }]);
  const removeAction = (i: number) => setActions(a => a.filter((_, j) => j !== i));
  const updateAction = (i: number, key: string, val: string) => setActions(a => a.map((r, j) => j === i ? { ...r, [key]: val } : r));

  const getActionDef = (type: string) => actionCatalogue.find((a: any) => a.type === type);

  const preview = `IF ${conditions.length} condition${conditions.length !== 1 ? 's' : ''} (${logic}) → ${actions.length} action${actions.length !== 1 ? 's' : ''}`;

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-3 gap-3">
        <div className="col-span-2">
          <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">RULE NAME</label>
          <input value={name} onChange={e => setName(e.target.value)} placeholder="Auto-assign payroll tickets to finance team" className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 focus:border-primary-600 focus:outline-none" />
        </div>
        <div>
          <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">PRIORITY (higher = runs first)</label>
          <input type="number" value={priority} onChange={e => setPriority(+e.target.value)} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 focus:border-primary-600 focus:outline-none" />
        </div>
      </div>

      {/* IF Block */}
      <div className="p-4 bg-retro-bg border border-retro-border rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="font-pixel text-[9px] text-yellow-400">IF</span>
            <div className="flex items-center gap-1 p-0.5 bg-retro-card border border-retro-border rounded">
              {['AND', 'OR'].map(l => <button key={l} onClick={() => setLogic(l)} className={`px-2.5 py-1 rounded font-mono text-[9px] transition-all ${logic === l ? 'bg-primary-900 text-primary-300' : 'text-primary-700'}`}>{l}</button>)}
            </div>
            <span className="font-mono text-[9px] text-primary-700">all/any conditions match</span>
          </div>
          <button onClick={addCondition} className="flex items-center gap-1 font-mono text-[9px] text-primary-600 hover:text-primary-400"><Plus className="w-3 h-3" />Add condition</button>
        </div>
        {conditions.length === 0 ? <p className="font-mono text-xs text-primary-800 py-2 text-center">No conditions — rule applies to all tickets</p> : (
          <div className="space-y-2">
            {conditions.map((cond, i) => (
              <div key={i} className="flex items-center gap-2">
                {i > 0 && <span className="font-pixel text-[8px] text-primary-700 w-6 text-right shrink-0">{logic}</span>}
                {i === 0 && <div className="w-6 shrink-0" />}
                <select value={cond.field} onChange={e => updateCondition(i, 'field', e.target.value)} className="flex-1 px-2.5 py-1.5 bg-retro-card border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none">
                  {fields.map((f: any) => <option key={f.key} value={f.key}>{f.label}</option>)}
                </select>
                <select value={cond.operator} onChange={e => updateCondition(i, 'operator', e.target.value)} className="w-36 px-2.5 py-1.5 bg-retro-card border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none">
                  {OPERATORS.map(op => <option key={op.value} value={op.value}>{op.label}</option>)}
                </select>
                {!['is_null', 'is_not_null'].includes(cond.operator) && (() => {
                  const fieldDef = fields.find((f: any) => f.key === cond.field);
                  if (fieldDef?.options) return (
                    <select value={cond.value} onChange={e => updateCondition(i, 'value', e.target.value)} className="flex-1 px-2.5 py-1.5 bg-retro-card border border-retro-border rounded font-mono text-xs text-primary-300 focus:outline-none">
                      {fieldDef.options.map((o: string) => <option key={o} value={o}>{o}</option>)}
                    </select>
                  );
                  return <input value={cond.value} onChange={e => updateCondition(i, 'value', e.target.value)} placeholder="value" className="flex-1 px-2.5 py-1.5 bg-retro-card border border-retro-border rounded font-mono text-xs text-primary-300 focus:outline-none" />;
                })()}
                <button onClick={() => removeCondition(i)} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* THEN Block */}
      <div className="p-4 bg-retro-bg border border-retro-border rounded-xl space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-pixel text-[9px] text-green-400">THEN</span>
          <button onClick={addAction} className="flex items-center gap-1 font-mono text-[9px] text-primary-600 hover:text-primary-400"><Plus className="w-3 h-3" />Add action</button>
        </div>
        {actions.length === 0 ? <p className="font-mono text-xs text-primary-800 py-2 text-center">No actions — add at least one</p> : (
          <div className="space-y-2">
            {actions.map((action, i) => {
              const actionDef = getActionDef(action.type);
              return (
                <div key={i} className="flex items-center gap-2">
                  <select value={action.type} onChange={e => updateAction(i, 'type', e.target.value)} className="flex-1 px-2.5 py-1.5 bg-retro-card border border-retro-border rounded font-mono text-xs text-primary-300 focus:outline-none">
                    {actionCatalogue.map((a: any) => <option key={a.type} value={a.type}>{a.label}</option>)}
                  </select>
                  {actionDef?.paramType === 'enum' ? (
                    <select value={action.value} onChange={e => updateAction(i, 'value', e.target.value)} className="flex-1 px-2.5 py-1.5 bg-retro-card border border-retro-border rounded font-mono text-xs text-primary-300 focus:outline-none">
                      {actionDef.options?.map((o: string) => <option key={o} value={o}>{o}</option>)}
                    </select>
                  ) : (
                    <input value={action.value} onChange={e => updateAction(i, 'value', e.target.value)} placeholder={actionDef?.paramLabel ?? 'value'} className="flex-1 px-2.5 py-1.5 bg-retro-card border border-retro-border rounded font-mono text-xs text-primary-300 focus:outline-none" />
                  )}
                  <button onClick={() => removeAction(i)} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Preview + Save */}
      <div className="flex items-center gap-3">
        <div className="flex-1 px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-600">{preview}</div>
        <button onClick={() => onSave({ name, description: desc, priority, conditionLogic: logic, conditions, actions })} disabled={!name || actions.length === 0} className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 disabled:opacity-40">
          <Save className="w-3.5 h-3.5" /> {rule ? 'Update Rule' : 'Save Rule'}
        </button>
        <button onClick={onCancel} className="px-4 py-2 border border-retro-border rounded font-mono text-xs text-primary-600">Cancel</button>
      </div>
    </div>
  );
}

export function AssignmentRulesPage() {
  const [editing, setEditing] = useState<any | null>(null);
  const [creating, setCreating] = useState(false);
  const qc = useQueryClient();

  const { data: rules = [] } = useQuery({ queryKey: ['assignment-rules'], queryFn: () => api('/case-engine/assignment-rules').then(r => r.data ?? []) });
  const { data: catalogue } = useQuery({ queryKey: ['ar-catalogue'], queryFn: () => api('/case-engine/assignment-rules/catalogue').then(r => r.data) });

  const createMut = useMutation({ mutationFn: (dto: any) => api('/case-engine/assignment-rules', { method: 'POST', body: JSON.stringify(dto) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['assignment-rules'] }); setCreating(false); } });
  const updateMut = useMutation({ mutationFn: ({ id, ...dto }: any) => api(`/case-engine/assignment-rules/${id}`, { method: 'PUT', body: JSON.stringify(dto) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['assignment-rules'] }); setEditing(null); } });
  const toggleMut = useMutation({ mutationFn: (id: string) => api(`/case-engine/assignment-rules/${id}/toggle`, { method: 'PATCH' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['assignment-rules'] }) });
  const deleteMut = useMutation({ mutationFn: (id: string) => api(`/case-engine/assignment-rules/${id}`, { method: 'DELETE' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['assignment-rules'] }) });

  const activeCount = (rules as any[]).filter((r: any) => r.isActive).length;

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div><h1 className="font-pixel text-[10px] text-primary-400">ASSIGNMENT RULES</h1><p className="font-mono text-xs text-primary-700 mt-1">{activeCount} active rules · Auto-route tickets by type, category, priority</p></div>
        <button onClick={() => { setCreating(true); setEditing(null); }} className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500"><Plus className="w-3.5 h-3.5" />New Rule</button>
      </div>

      {/* Editor */}
      {(creating || editing) && (
        <div className="bg-retro-card border border-primary-800 rounded-xl p-5">
          <RuleEditor
            rule={editing ?? undefined}
            catalogue={catalogue}
            onSave={data => editing ? updateMut.mutate({ id: editing.id, ...data }) : createMut.mutate(data)}
            onCancel={() => { setCreating(false); setEditing(null); }}
          />
        </div>
      )}

      {/* Rule list */}
      <div className="space-y-2">
        {(rules as any[]).length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3 bg-retro-card border border-retro-border rounded-xl">
            <Zap className="w-10 h-10 text-primary-800" />
            <p className="font-mono text-sm text-primary-700">No assignment rules yet</p>
            <p className="font-mono text-xs text-primary-800">Rules auto-route tickets, set SLAs, and assign agents</p>
          </div>
        ) : (rules as any[]).map((rule: any) => {
          const conditions = rule.conditions ?? [];
          const actions = rule.actions ?? [];
          return (
            <div key={rule.id} className={`p-4 bg-retro-card border rounded-lg transition-all ${rule.isActive ? 'border-primary-800' : 'border-retro-border opacity-60'}`}>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 font-pixel text-[8px] text-primary-700 bg-retro-bg border border-retro-border rounded px-2 py-1">
                  #{rule.priority}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-mono text-sm text-primary-300">{rule.name}</p>
                    {!rule.isActive && <span className="font-mono text-[9px] text-primary-800">inactive</span>}
                  </div>
                  <div className="flex items-center gap-3 mt-1 font-mono text-[10px] text-primary-700">
                    <span className="text-yellow-400">IF</span>
                    <span>{conditions.length} condition{conditions.length !== 1 ? 's' : ''} ({rule.conditionLogic})</span>
                    <span className="text-green-400">→ THEN</span>
                    <span>{actions.length} action{actions.length !== 1 ? 's' : ''}</span>
                    {rule.runCount > 0 && <span>· ran {rule.runCount}×</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button onClick={() => toggleMut.mutate(rule.id)}>
                    {rule.isActive ? <ToggleRight className="w-5 h-5 text-primary-crt" /> : <ToggleLeft className="w-5 h-5 text-primary-700" />}
                  </button>
                  <button onClick={() => { setEditing(rule); setCreating(false); }} className="font-mono text-[9px] text-primary-600 hover:text-primary-400">Edit</button>
                  <button onClick={() => { if (confirm('Delete this rule?')) deleteMut.mutate(rule.id); }} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>

              {/* Condition preview */}
              {conditions.length > 0 && (
                <div className="mt-3 flex items-center gap-2 flex-wrap pl-10">
                  {conditions.slice(0, 3).map((c: any, i: number) => (
                    <span key={i} className="flex items-center gap-1 px-2 py-0.5 bg-yellow-950/20 border border-yellow-900/40 rounded font-mono text-[9px] text-yellow-700">
                      {c.field} {c.operator} {c.value}
                    </span>
                  ))}
                  {conditions.length > 3 && <span className="font-mono text-[9px] text-primary-800">+{conditions.length - 3} more</span>}
                  <ChevronRight className="w-3 h-3 text-primary-700" />
                  {actions.slice(0, 2).map((a: any, i: number) => (
                    <span key={i} className="flex items-center gap-1 px-2 py-0.5 bg-green-950/20 border border-green-900/40 rounded font-mono text-[9px] text-green-700">
                      {a.type.replace(/_/g, ' ')} {a.value}
                    </span>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
