'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { AlertTriangle, Clock, List, RefreshCw } from 'lucide-react';
import Link from 'next/link';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers } });
  return res.json();
};

const PRIORITY_COLORS: Record<string, string> = { p1: 'border-l-red-500', p2: 'border-l-orange-500', p3: 'border-l-blue-600', p4: 'border-l-primary-700' };
const PRIORITY_DOTS: Record<string, string> = { p1: 'bg-red-400', p2: 'bg-orange-400', p3: 'bg-blue-400', p4: 'bg-primary-700' };
const TYPE_ICONS: Record<string, string> = { internal: '🏢', external: '🌐', payroll: '💰', IT: '💻', admin: '📋', vendor: '🤝', custom: '⚡' };

const COLUMNS: { id: string; label: string; color: string }[] = [
  { id: 'open', label: 'OPEN', color: 'text-green-400' },
  { id: 'in-progress', label: 'IN PROGRESS', color: 'text-blue-400' },
  { id: 'pending', label: 'PENDING', color: 'text-yellow-400' },
  { id: 'resolved', label: 'RESOLVED', color: 'text-primary-500' },
];

function TicketCard({ ticket, onStatusChange }: { ticket: any; onStatusChange: (id: string, status: string) => void }) {
  const slaWarn = ticket.slaResolutionDue && !ticket.slaBreached && new Date(ticket.slaResolutionDue) < new Date(Date.now() + 3_600_000);

  return (
    <Link href={`/dashboard/case-engine/tickets/${ticket.id}`}>
      <div className={`bg-retro-card border border-retro-border border-l-4 ${PRIORITY_COLORS[ticket.priority] ?? 'border-l-primary-800'} rounded-lg p-3 space-y-2.5 hover:border-primary-700 transition-colors cursor-pointer`}>
        {/* Header */}
        <div className="flex items-start justify-between gap-2">
          <span className="font-mono text-[9px] text-primary-700">{ticket.ticketNumber}</span>
          <div className="flex items-center gap-1 shrink-0">
            {ticket.slaBreached && <AlertTriangle className="w-3 h-3 text-red-400" />}
            {slaWarn && !ticket.slaBreached && <Clock className="w-3 h-3 text-yellow-400" />}
            <span className="font-mono text-xs">{TYPE_ICONS[ticket.type] ?? '📋'}</span>
          </div>
        </div>

        {/* Title */}
        <p className="font-mono text-xs text-primary-300 leading-relaxed line-clamp-2">{ticket.title}</p>

        {/* Category & priority */}
        <div className="flex items-center gap-2">
          {ticket.category && <span className="px-1.5 py-0.5 bg-retro-bg border border-retro-border rounded font-mono text-[8px] text-primary-600">{ticket.category.name}</span>}
          <div className="flex items-center gap-1">
            <div className={`w-1.5 h-1.5 rounded-full ${PRIORITY_DOTS[ticket.priority]}`} />
            <span className="font-mono text-[8px] text-primary-700">{ticket.priority.toUpperCase()}</span>
          </div>
        </div>

        {/* Tags */}
        {ticket.tagLinks?.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {ticket.tagLinks.slice(0, 3).map((tl: any) => (
              <span key={tl.tagId} className="px-1.5 py-0.5 rounded font-mono text-[8px]" style={{ color: tl.tag.color, borderColor: tl.tag.color + '40', border: '1px solid' }}>{tl.tag.name}</span>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-1 border-t border-retro-border/30">
          {ticket.assignee ? (
            <div className="flex items-center gap-1.5">
              <div className="w-5 h-5 rounded-full bg-primary-900 border border-primary-800 flex items-center justify-center font-mono text-[7px] text-primary-500">
                {ticket.assignee.firstName[0]}{ticket.assignee.lastName[0]}
              </div>
              <span className="font-mono text-[9px] text-primary-600">{ticket.assignee.firstName}</span>
            </div>
          ) : <span className="font-mono text-[9px] text-primary-800">Unassigned</span>}
          <span className={`font-mono text-[9px] ${ticket.slaBreached ? 'text-red-400' : slaWarn ? 'text-yellow-400' : 'text-primary-800'}`}>
            {ticket.slaResolutionDue ? new Date(ticket.slaResolutionDue).toLocaleDateString('en-IN', { dateStyle: 'short' }) : '—'}
          </span>
        </div>
      </div>
    </Link>
  );
}

function KanbanColumn({ column, tickets, onStatusChange }: { column: { id: string; label: string; color: string }; tickets: any[]; onStatusChange: (id: string, status: string) => void }) {
  const [isDragOver, setIsDragOver] = useState(false);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const ticketId = e.dataTransfer.getData('ticketId');
    if (ticketId) onStatusChange(ticketId, column.id);
    setIsDragOver(false);
  };

  return (
    <div
      className={`flex-1 min-w-0 flex flex-col border rounded-xl transition-colors ${isDragOver ? 'border-primary-600 bg-primary-950/20' : 'border-retro-border bg-retro-bg'}`}
      onDragOver={e => { e.preventDefault(); setIsDragOver(true); }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={handleDrop}
    >
      {/* Column header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-retro-border">
        <span className={`font-pixel text-[8px] ${column.color}`}>{column.label}</span>
        <span className="font-mono text-[10px] text-primary-700">{tickets.length}</span>
      </div>

      {/* Cards */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2.5 min-h-24">
        {tickets.map(t => (
          <div key={t.id} draggable onDragStart={e => e.dataTransfer.setData('ticketId', t.id)}>
            <TicketCard ticket={t} onStatusChange={onStatusChange} />
          </div>
        ))}
        {tickets.length === 0 && (
          <div className="flex items-center justify-center h-16 border border-dashed border-retro-border rounded-lg">
            <p className="font-mono text-[10px] text-primary-800">Drop tickets here</p>
          </div>
        )}
      </div>
    </div>
  );
}

export function KanbanPage() {
  const qc = useQueryClient();

  const { data: kanbanData, isLoading } = useQuery({
    queryKey: ['kanban'],
    queryFn: () => api('/case-engine/tickets/kanban').then(r => r.data ?? { columns: {}, total: 0 }),
    refetchInterval: 30000,
  });

  const statusMut = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      api(`/case-engine/tickets/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['kanban'] }),
  });

  const columns = kanbanData?.columns ?? {};

  return (
    <div className="flex flex-col h-[calc(100vh-80px)] animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">KANBAN BOARD</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">Drag & drop tickets · {kanbanData?.total ?? 0} active tickets</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => qc.invalidateQueries({ queryKey: ['kanban'] })} className="text-primary-700 hover:text-primary-400"><RefreshCw className="w-4 h-4" /></button>
          <Link href="/dashboard/case-engine/tickets" className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border rounded font-mono text-xs text-primary-600 hover:text-primary-400">
            <List className="w-3.5 h-3.5" /> List
          </Link>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center flex-1 gap-3 font-mono text-sm text-primary-700"><RefreshCw className="w-5 h-5 animate-spin" />Loading board…</div>
      ) : (
        <div className="flex gap-4 flex-1 overflow-x-auto">
          {COLUMNS.map(col => (
            <KanbanColumn key={col.id} column={col} tickets={columns[col.id] ?? []} onStatusChange={(id, status) => statusMut.mutate({ id, status })} />
          ))}
        </div>
      )}
    </div>
  );
}
