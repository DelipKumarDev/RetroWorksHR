'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Search, Filter, Plus, ChevronDown, AlertTriangle, Clock,
  CheckCircle, Circle, ArrowUp, ArrowRight, ArrowDown, Minus,
  Tag, User, Calendar, RefreshCw, LayoutGrid, List, X,
} from 'lucide-react';
import Link from 'next/link';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers },
  });
  return res.json();
};

// ─── Constants ────────────────────────────────────────────────────────────────

const PRIORITY_CONFIG: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  p1: { label: 'Critical', color: 'text-red-400 bg-red-950 border-red-800', icon: <ArrowUp className="w-2.5 h-2.5" /> },
  p2: { label: 'High', color: 'text-orange-400 bg-orange-950 border-orange-800', icon: <ArrowRight className="w-2.5 h-2.5" /> },
  p3: { label: 'Normal', color: 'text-blue-400 bg-blue-950 border-blue-800', icon: <Minus className="w-2.5 h-2.5" /> },
  p4: { label: 'Low', color: 'text-primary-500 bg-primary-950 border-primary-800', icon: <ArrowDown className="w-2.5 h-2.5" /> },
};

const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  'open': { label: 'Open', color: 'text-green-400 bg-green-950 border-green-800' },
  'in-progress': { label: 'In Progress', color: 'text-blue-400 bg-blue-950 border-blue-800' },
  'pending': { label: 'Pending', color: 'text-yellow-400 bg-yellow-950 border-yellow-800' },
  'waiting': { label: 'Waiting', color: 'text-purple-400 bg-purple-950 border-purple-800' },
  'resolved': { label: 'Resolved', color: 'text-primary-400 bg-primary-950 border-primary-800' },
  'closed': { label: 'Closed', color: 'text-primary-700 bg-retro-bg border-retro-border' },
};

const TYPE_ICONS: Record<string, string> = {
  internal: '🏢', external: '🌐', payroll: '💰', IT: '💻', admin: '📋', vendor: '🤝', custom: '⚡',
};

// ─── Stat Cards ───────────────────────────────────────────────────────────────

function StatCards({ stats }: { stats: any }) {
  return (
    <div className="grid grid-cols-6 gap-3">
      {[
        { label: 'Open', value: stats?.open, color: 'text-green-400', icon: <Circle className="w-3.5 h-3.5 text-green-400" /> },
        { label: 'In Progress', value: stats?.inProgress, color: 'text-blue-400', icon: <RefreshCw className="w-3.5 h-3.5 text-blue-400" /> },
        { label: 'Pending', value: stats?.pending, color: 'text-yellow-400', icon: <Clock className="w-3.5 h-3.5 text-yellow-400" /> },
        { label: 'SLA Breached', value: stats?.breached, color: 'text-red-400', icon: <AlertTriangle className="w-3.5 h-3.5 text-red-400" /> },
        { label: 'Resolved', value: stats?.resolved, color: 'text-primary-400', icon: <CheckCircle className="w-3.5 h-3.5 text-primary-400" /> },
        { label: 'Today', value: stats?.todayCreated, color: 'text-primary-crt', icon: <Calendar className="w-3.5 h-3.5 text-primary-600" /> },
      ].map(s => (
        <div key={s.label} className="flex items-center gap-3 p-3 bg-retro-card border border-retro-border rounded-lg">
          {s.icon}
          <div><p className={`font-pixel text-[16px] ${s.color}`}>{s.value ?? '—'}</p><p className="font-mono text-[9px] text-primary-700">{s.label}</p></div>
        </div>
      ))}
    </div>
  );
}

// ─── Priority Badge ───────────────────────────────────────────────────────────

function PriorityBadge({ priority }: { priority: string }) {
  const cfg = PRIORITY_CONFIG[priority] ?? PRIORITY_CONFIG.p3;
  return (
    <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded border text-[8px] font-pixel ${cfg.color}`}>
      {cfg.icon}{cfg.label}
    </span>
  );
}

function StatusBadge({ status }: { status: string }) {
  const cfg = STATUS_CONFIG[status] ?? STATUS_CONFIG.open;
  return <span className={`inline-flex px-1.5 py-0.5 rounded border text-[8px] font-pixel ${cfg.color}`}>{cfg.label}</span>;
}

// ─── Create Ticket Modal ──────────────────────────────────────────────────────

function CreateTicketModal({ onClose, onSuccess }: { onClose: () => void; onSuccess: () => void }) {
  const [form, setForm] = useState({ type: 'internal', title: '', description: '', priority: 'p3' });
  const { data: cats } = useQuery({ queryKey: ['ticket-categories'], queryFn: () => api('/case-engine/tickets/categories/list').then(r => r.data ?? []) });
  const mut = useMutation({ mutationFn: () => api('/case-engine/tickets', { method: 'POST', body: JSON.stringify(form) }), onSuccess });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative bg-retro-card border border-primary-800 rounded-xl p-6 w-full max-w-lg space-y-4 shadow-glow">
        <div className="flex items-center justify-between">
          <h3 className="font-pixel text-[9px] text-primary-crt">NEW TICKET</h3>
          <button onClick={onClose}><X className="w-4 h-4 text-primary-700" /></button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[
            { key: 'type', label: 'TYPE', el: <select value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none">{Object.entries(TYPE_ICONS).map(([t, icon]) => <option key={t} value={t}>{icon} {t}</option>)}</select> },
            { key: 'priority', label: 'PRIORITY', el: <select value={form.priority} onChange={e => setForm(f => ({ ...f, priority: e.target.value }))} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none">{Object.entries(PRIORITY_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}</select> },
          ].map(f => (
            <div key={f.key}><label className="block font-pixel text-[7px] text-primary-600 mb-1">{f.label}</label>{f.el}</div>
          ))}
        </div>
        <div><label className="block font-pixel text-[7px] text-primary-600 mb-1">TITLE *</label><input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Describe the issue…" className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none" /></div>
        <div><label className="block font-pixel text-[7px] text-primary-600 mb-1">DESCRIPTION</label><textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} rows={4} placeholder="Additional context…" className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none resize-none" /></div>
        <div className="flex gap-3">
          <button onClick={() => mut.mutate()} disabled={!form.title || mut.isPending} className="flex-1 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 disabled:opacity-40">{mut.isPending ? 'Creating…' : 'Create Ticket'}</button>
          <button onClick={onClose} className="flex-1 py-2 border border-retro-border rounded font-mono text-xs text-primary-600">Cancel</button>
        </div>
      </div>
    </div>
  );
}

// ─── Main Ticket List ─────────────────────────────────────────────────────────

export function TicketListPage() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [priority, setPriority] = useState('');
  const [type, setType] = useState('');
  const [slaBreached, setSlaBreached] = useState(false);
  const [page, setPage] = useState(0);
  const [creating, setCreating] = useState(false);
  const limit = 25;
  const qc = useQueryClient();

  const params = new URLSearchParams({ limit: String(limit), offset: String(page * limit), ...(status && { status }), ...(priority && { priority }), ...(type && { type }), ...(slaBreached && { slaBreached: 'true' }), ...(search && { search }) });
  const { data: statsData } = useQuery({ queryKey: ['ticket-stats'], queryFn: () => api('/case-engine/tickets/dashboard').then(r => r.data), refetchInterval: 30000 });
  const { data: ticketData, isLoading } = useQuery({ queryKey: ['tickets', status, priority, type, slaBreached, search, page], queryFn: () => api(`/case-engine/tickets?${params}`).then(r => r.data ?? { tickets: [], total: 0 }), keepPreviousData: true });

  const updateStatus = useMutation({ mutationFn: ({ id, status }: any) => api(`/case-engine/tickets/${id}/status`, { method: 'PATCH', body: JSON.stringify({ status }) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['tickets'] }); qc.invalidateQueries({ queryKey: ['ticket-stats'] }); } });

  const tickets: any[] = ticketData?.tickets ?? [];
  const total: number = ticketData?.total ?? 0;

  const clearFilters = () => { setStatus(''); setPriority(''); setType(''); setSlaBreached(false); setSearch(''); setPage(0); };
  const hasFilters = status || priority || type || slaBreached || search;

  const cls = { select: 'px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:border-primary-600 focus:outline-none' };

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">CASE ENGINE</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">Unified ticket management · Freshdesk-level SLA engine · AI Copilot</p>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/dashboard/case-engine/kanban" className="flex items-center gap-1.5 px-3 py-2 border border-retro-border rounded font-mono text-xs text-primary-600 hover:text-primary-400">
            <LayoutGrid className="w-3.5 h-3.5" /> Kanban
          </Link>
          <button onClick={() => setCreating(true)} className="flex items-center gap-1.5 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500 shadow-glow">
            <Plus className="w-3.5 h-3.5" /> New Ticket
          </button>
        </div>
      </div>

      <StatCards stats={statsData} />

      {/* Filter bar */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-primary-700" />
          <input value={search} onChange={e => { setSearch(e.target.value); setPage(0); }} placeholder="Search tickets…" className="w-full pl-8 pr-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none" />
        </div>
        <select value={status} onChange={e => { setStatus(e.target.value); setPage(0); }} className={cls.select}>
          <option value="">All statuses</option>
          {Object.entries(STATUS_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <select value={priority} onChange={e => { setPriority(e.target.value); setPage(0); }} className={cls.select}>
          <option value="">All priorities</option>
          {Object.entries(PRIORITY_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
        <select value={type} onChange={e => { setType(e.target.value); setPage(0); }} className={cls.select}>
          <option value="">All types</option>
          {Object.keys(TYPE_ICONS).map(t => <option key={t} value={t}>{TYPE_ICONS[t]} {t}</option>)}
        </select>
        <button onClick={() => { setSlaBreached(s => !s); setPage(0); }} className={`flex items-center gap-1.5 px-3 py-2 rounded border font-mono text-xs transition-all ${slaBreached ? 'bg-red-950 border-red-800 text-red-400' : 'border-retro-border text-primary-700 hover:text-primary-400'}`}>
          <AlertTriangle className="w-3 h-3" /> SLA Breached
        </button>
        {hasFilters && <button onClick={clearFilters} className="flex items-center gap-1 font-mono text-xs text-primary-700 hover:text-primary-400"><X className="w-3 h-3" />Clear</button>}
      </div>

      {/* Ticket table */}
      <div className="bg-retro-card border border-retro-border rounded-xl overflow-hidden">
        <div className="grid grid-cols-12 gap-2 px-4 py-2.5 border-b border-retro-border bg-retro-bg">
          {['TICKET ID', 'TITLE', 'TYPE', 'PRIORITY', 'STATUS', 'ASSIGNEE', 'SLA', 'CREATED'].map((h, i) => (
            <span key={h} className={`font-pixel text-[7px] text-primary-700 ${i === 1 ? 'col-span-4' : ''}`}>{h}</span>
          ))}
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12 gap-3 font-mono text-sm text-primary-700"><RefreshCw className="w-4 h-4 animate-spin" />Loading tickets…</div>
        ) : tickets.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 gap-2"><Circle className="w-10 h-10 text-primary-800" /><p className="font-mono text-sm text-primary-700">No tickets found</p></div>
        ) : (
          tickets.map(t => (
            <Link key={t.id} href={`/dashboard/case-engine/tickets/${t.id}`} className="grid grid-cols-12 gap-2 items-center px-4 py-3 border-b border-retro-border/30 hover:bg-retro-bg/50 transition-colors cursor-pointer">
              {/* Ticket number */}
              <div className="flex items-center gap-1.5">
                {t.slaBreached && <AlertTriangle className="w-3 h-3 text-red-400 shrink-0" />}
                <span className="font-mono text-[10px] text-primary-500">{t.ticketNumber}</span>
              </div>
              {/* Title */}
              <div className="col-span-4 min-w-0">
                <p className="font-mono text-xs text-primary-300 truncate">{t.title}</p>
                {t.category && <p className="font-mono text-[9px] text-primary-700 truncate">{t.category.name}</p>}
              </div>
              {/* Type */}
              <span className="font-mono text-xs text-primary-600">{TYPE_ICONS[t.type] ?? '📋'} {t.type}</span>
              {/* Priority */}
              <PriorityBadge priority={t.priority} />
              {/* Status */}
              <StatusBadge status={t.status} />
              {/* Assignee */}
              <span className="font-mono text-[10px] text-primary-600 truncate">
                {t.assignee ? `${t.assignee.firstName} ${t.assignee.lastName}` : '—'}
              </span>
              {/* SLA */}
              <div className="font-mono text-[10px]">
                {t.slaResolutionDue ? (
                  <span className={t.slaBreached ? 'text-red-400' : new Date(t.slaResolutionDue) < new Date(Date.now() + 3_600_000) ? 'text-yellow-400' : 'text-primary-600'}>
                    {new Date(t.slaResolutionDue).toLocaleDateString('en-IN', { dateStyle: 'short' })}
                  </span>
                ) : <span className="text-primary-800">—</span>}
              </div>
              {/* Created */}
              <span className="font-mono text-[10px] text-primary-700">{new Date(t.createdAt).toLocaleDateString('en-IN', { dateStyle: 'short' })}</span>
            </Link>
          ))
        )}
      </div>

      {/* Pagination */}
      {total > limit && (
        <div className="flex items-center justify-between font-mono text-xs text-primary-700">
          <span>{page * limit + 1}–{Math.min((page + 1) * limit, total)} of {total} tickets</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0} className="px-3 py-1.5 border border-retro-border rounded disabled:opacity-30 hover:border-primary-700">← Prev</button>
            <button onClick={() => setPage(p => p + 1)} disabled={(page + 1) * limit >= total} className="px-3 py-1.5 border border-retro-border rounded disabled:opacity-30 hover:border-primary-700">Next →</button>
          </div>
        </div>
      )}

      {creating && <CreateTicketModal onClose={() => setCreating(false)} onSuccess={() => { setCreating(false); qc.invalidateQueries({ queryKey: ['tickets'] }); qc.invalidateQueries({ queryKey: ['ticket-stats'] }); }} />}
    </div>
  );
}
