'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { X, Plus, AlertTriangle, ChevronDown } from 'lucide-react';
import { useRouter } from 'next/navigation';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers },
  });
  return res.json();
};

const cls = {
  input: 'w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none',
  select: 'w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none',
  label: 'block font-pixel text-[7px] text-primary-600 mb-1.5',
};

const TICKET_TYPES = ['internal', 'external', 'payroll', 'IT', 'admin', 'vendor', 'custom'];
const TYPE_ICONS: Record<string, string> = { internal: '🏢', external: '🌐', payroll: '💰', IT: '💻', admin: '📋', vendor: '🤝', custom: '⚡' };
const PRIORITIES = [
  { value: 'p1', label: '🔴 P1 — Critical', desc: 'System down / data breach' },
  { value: 'p2', label: '🟠 P2 — High', desc: 'Major feature broken' },
  { value: 'p3', label: '🔵 P3 — Normal', desc: 'Standard request' },
  { value: 'p4', label: '⚪ P4 — Low', desc: 'Nice to have' },
];
const ENTITY_TYPES = ['', 'employee', 'department', 'payroll_run', 'asset', 'account', 'vendor', 'custom'];

interface CreateTicketModalProps { onClose: () => void; defaultType?: string; defaultLinkedEntityType?: string; defaultLinkedEntityId?: string; }

export function CreateTicketModal({ onClose, defaultType = '', defaultLinkedEntityType = '', defaultLinkedEntityId = '' }: CreateTicketModalProps) {
  const router = useRouter();
  const qc = useQueryClient();

  const [form, setForm] = useState({
    type: defaultType || 'internal',
    title: '',
    description: '',
    priority: 'p3',
    categoryId: '',
    subcategoryId: '',
    linkedEntityType: defaultLinkedEntityType,
    linkedEntityId: defaultLinkedEntityId,
    source: 'web',
    tags: [] as string[],
    tagInput: '',
  });

  const set = (key: string, val: unknown) => setForm(f => ({ ...f, [key]: val }));

  const { data: categoriesData } = useQuery({ queryKey: ['ticket-categories', form.type], queryFn: () => api(`/case-engine/categories?type=${form.type}`).then(r => r.data ?? []) });
  const { data: slaData } = useQuery({ queryKey: ['slas'], queryFn: () => api('/case-engine/sla').then(r => r.data ?? []) });

  const categories = (categoriesData as any[]) ?? [];
  const selectedCategory = categories.find((c: any) => c.id === form.categoryId);
  const subcategories = selectedCategory?.children ?? [];

  // SLA preview
  const defaultSla = (slaData as any[] ?? []).find((s: any) => s.isDefault);
  const categorySla = selectedCategory?.defaultSlaId ? (slaData as any[] ?? []).find((s: any) => s.id === selectedCategory.defaultSlaId) : null;
  const activeSla = categorySla ?? defaultSla;
  const slaKey = form.priority;
  const responseMin = activeSla ? (activeSla as any)[`${slaKey}ResponseMinutes`] : null;
  const resolveMin = activeSla ? (activeSla as any)[`${slaKey}ResolutionMinutes`] : null;

  const addTag = () => { if (form.tagInput.trim() && !form.tags.includes(form.tagInput.trim())) { set('tags', [...form.tags, form.tagInput.trim()]); set('tagInput', ''); } };

  const createMut = useMutation({
    mutationFn: (dto: any) => api('/case-engine/tickets', { method: 'POST', body: JSON.stringify(dto) }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ['tickets'] });
      qc.invalidateQueries({ queryKey: ['ticket-stats'] });
      if (res.data?.id) router.push(`/dashboard/case-engine/tickets/${res.data.id}`);
      else onClose();
    },
  });

  const handleSubmit = () => {
    if (!form.title.trim()) return;
    const { tagInput, ...rest } = form;
    createMut.mutate(rest);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-retro-card border border-primary-800 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-glow">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-retro-border">
          <div>
            <h2 className="font-pixel text-[10px] text-primary-crt">NEW TICKET</h2>
            <p className="font-mono text-[10px] text-primary-700 mt-0.5">Create a support case in the unified Case Engine</p>
          </div>
          <button onClick={onClose} className="text-primary-700 hover:text-primary-400"><X className="w-4 h-4" /></button>
        </div>

        <div className="p-6 space-y-5">
          {/* Ticket type selector */}
          <div>
            <label className={cls.label}>TICKET TYPE</label>
            <div className="grid grid-cols-4 gap-2">
              {TICKET_TYPES.map(t => (
                <button key={t} onClick={() => { set('type', t); set('categoryId', ''); set('subcategoryId', ''); }}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded border font-mono text-xs transition-all ${form.type === t ? 'bg-primary-950 border-primary-700 text-primary-300' : 'border-retro-border text-primary-700 hover:border-primary-800'}`}>
                  <span>{TYPE_ICONS[t]}</span>{t}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className={cls.label}>SUBJECT *</label>
            <input value={form.title} onChange={e => set('title', e.target.value)} placeholder="Brief, clear description of the issue…" className={cls.input} />
          </div>

          {/* Description */}
          <div>
            <label className={cls.label}>DESCRIPTION</label>
            <textarea value={form.description} onChange={e => set('description', e.target.value)} placeholder="Describe the issue in detail. Steps to reproduce, expected vs actual behavior, error messages…" rows={4} className={`${cls.input} resize-none leading-relaxed`} />
          </div>

          {/* Priority + Category row */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={cls.label}>PRIORITY</label>
              <div className="space-y-1">
                {PRIORITIES.map(p => (
                  <button key={p.value} onClick={() => set('priority', p.value)}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded border text-left transition-all ${form.priority === p.value ? 'bg-primary-950 border-primary-700' : 'border-retro-border hover:border-primary-800'}`}>
                    <span className="font-mono text-xs text-primary-300">{p.label}</span>
                    <span className="font-mono text-[9px] text-primary-700 ml-auto">{p.desc}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              {/* Category */}
              <div>
                <label className={cls.label}>CATEGORY</label>
                <select value={form.categoryId} onChange={e => { set('categoryId', e.target.value); set('subcategoryId', ''); }} className={cls.select}>
                  <option value="">Select category…</option>
                  {categories.filter((c: any) => !c.parentId).map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>

              {subcategories.length > 0 && (
                <div>
                  <label className={cls.label}>SUBCATEGORY</label>
                  <select value={form.subcategoryId} onChange={e => set('subcategoryId', e.target.value)} className={cls.select}>
                    <option value="">Select subcategory…</option>
                    {subcategories.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
              )}

              {/* SLA preview */}
              {activeSla && responseMin && (
                <div className="p-3 bg-retro-bg border border-retro-border rounded">
                  <p className="font-pixel text-[7px] text-primary-700 mb-1">SLA PREVIEW — {activeSla.name}</p>
                  <p className="font-mono text-[10px] text-primary-400">Response: <span className="text-primary-300">{responseMin}m</span></p>
                  <p className="font-mono text-[10px] text-primary-400">Resolve: <span className="text-primary-300">{Math.round(resolveMin / 60)}h</span></p>
                  {activeSla.businessHoursOnly && <p className="font-mono text-[9px] text-blue-600 mt-1">Business hours only</p>}
                </div>
              )}

              {/* Linked entity */}
              <div>
                <label className={cls.label}>LINK TO ENTITY (OPTIONAL)</label>
                <div className="grid grid-cols-2 gap-2">
                  <select value={form.linkedEntityType} onChange={e => { set('linkedEntityType', e.target.value); set('linkedEntityId', ''); }} className={cls.select}>
                    {ENTITY_TYPES.map(e => <option key={e} value={e}>{e || 'None'}</option>)}
                  </select>
                  {form.linkedEntityType && <input value={form.linkedEntityId} onChange={e => set('linkedEntityId', e.target.value)} placeholder="Entity ID…" className={cls.input} />}
                </div>
              </div>
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className={cls.label}>TAGS</label>
            <div className="flex items-center gap-2">
              <input value={form.tagInput} onChange={e => set('tagInput', e.target.value)} onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addTag())} placeholder="Add tag and press Enter…" className={`${cls.input} flex-1`} />
              <button onClick={addTag} className="p-2 border border-retro-border rounded text-primary-600 hover:text-primary-400"><Plus className="w-3.5 h-3.5" /></button>
            </div>
            {form.tags.length > 0 && (
              <div className="flex items-center gap-2 mt-2 flex-wrap">
                {form.tags.map(tag => (
                  <span key={tag} className="flex items-center gap-1 px-2 py-0.5 bg-primary-950 border border-primary-800 rounded font-mono text-[9px] text-primary-400">
                    {tag}<button onClick={() => set('tags', form.tags.filter(t => t !== tag))} className="text-primary-700 hover:text-red-400 ml-1"><X className="w-2.5 h-2.5" /></button>
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-retro-border">
          <p className="font-mono text-[10px] text-primary-800">* Required fields. Ticket will be auto-assigned based on routing rules.</p>
          <div className="flex items-center gap-3">
            <button onClick={onClose} className="px-4 py-2 font-mono text-xs text-primary-600 hover:text-primary-400">Cancel</button>
            <button onClick={handleSubmit} disabled={!form.title.trim() || createMut.isPending}
              className="flex items-center gap-2 px-5 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-crt hover:border-primary-500 disabled:opacity-40 shadow-glow">
              {createMut.isPending ? 'Creating…' : '+ Create Ticket'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
