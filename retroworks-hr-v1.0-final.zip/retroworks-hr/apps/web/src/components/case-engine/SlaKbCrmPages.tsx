'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Clock, Plus, Trash2, Edit3, Save, X, Search, BookOpen,
  Eye, EyeOff, ThumbsUp, Globe, Lock, FileText, Users,
  Building, Phone, Mail, TrendingUp, CheckCircle, RefreshCw, AlertTriangle,
} from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers } });
  return res.json();
};

const cls = {
  input: 'w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none',
  select: 'w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none',
  btn: 'flex items-center gap-1.5 px-3 py-1.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500',
  label: 'block font-pixel text-[7px] text-primary-600 mb-1.5',
};

// ══════════════════════════════════════════════════════════════════════════════
// SLA CONFIGURATION PAGE
// ══════════════════════════════════════════════════════════════════════════════

export function SLAConfigPage() {
  const [editing, setEditing] = useState<any | null>(null);
  const [isNew, setIsNew] = useState(false);
  const qc = useQueryClient();

  const { data: slas = [] } = useQuery({ queryKey: ['slas'], queryFn: () => api('/case-engine/sla').then(r => r.data ?? []) });
  const { data: analytics } = useQuery({ queryKey: ['sla-analytics'], queryFn: () => api('/case-engine/sla/analytics').then(r => r.data) });

  const saveMut = useMutation({
    mutationFn: (dto: any) => dto.id ? api(`/case-engine/sla/${dto.id}`, { method: 'PUT', body: JSON.stringify(dto) }) : api('/case-engine/sla', { method: 'POST', body: JSON.stringify(dto) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['slas'] }); setEditing(null); setIsNew(false); },
  });
  const deleteMut = useMutation({ mutationFn: (id: string) => api(`/case-engine/sla/${id}`, { method: 'DELETE' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['slas'] }) });

  const blank = { name: '', p1ResponseMinutes: 60, p2ResponseMinutes: 240, p3ResponseMinutes: 480, p4ResponseMinutes: 1440, p1ResolutionMinutes: 240, p2ResolutionMinutes: 960, p3ResolutionMinutes: 2880, p4ResolutionMinutes: 10080, businessHoursOnly: true, workdayStart: '09:00', workdayEnd: '18:00', isDefault: false };

  const startNew = () => { setEditing({ ...blank }); setIsNew(true); };

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div><h1 className="font-pixel text-[10px] text-primary-400">SLA CONFIGURATION</h1><p className="font-mono text-xs text-primary-700 mt-1">Business-hours-aware SLA policies · Escalation matrix · Breach monitoring</p></div>
        <button onClick={startNew} className={cls.btn}><Plus className="w-3.5 h-3.5" />New SLA Policy</button>
      </div>

      {/* Analytics row */}
      {analytics && (
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: 'Total Tickets', value: analytics.total, color: 'text-primary-crt' },
            { label: 'SLA Breached', value: analytics.breached, color: 'text-red-400' },
            { label: 'Breach Rate', value: `${analytics.breachRate}%`, color: analytics.breachRate > 10 ? 'text-red-400' : 'text-green-400' },
            { label: 'Period', value: new Date(analytics.period?.from).toLocaleDateString('en-IN', { dateStyle: 'short' }), color: 'text-primary-500' },
          ].map(s => (
            <div key={s.label} className="p-4 bg-retro-card border border-retro-border rounded-lg">
              <p className={`font-pixel text-[16px] ${s.color}`}>{s.value}</p>
              <p className="font-mono text-[9px] text-primary-700 mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      )}

      {/* SLA Policies */}
      <div className="space-y-3">
        {(slas as any[]).map((sla: any) => (
          <div key={sla.id} className={`p-5 bg-retro-card border rounded-xl ${sla.isDefault ? 'border-primary-700' : 'border-retro-border'}`}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <p className="font-mono text-sm text-primary-300">{sla.name}</p>
                {sla.isDefault && <span className="px-1.5 py-0.5 bg-primary-950 border border-primary-800 rounded font-pixel text-[7px] text-primary-crt">DEFAULT</span>}
                {sla.businessHoursOnly && <span className="flex items-center gap-1 font-mono text-[9px] text-blue-400 border border-blue-900 rounded px-1.5"><Clock className="w-2.5 h-2.5" />Business hrs</span>}
              </div>
              <div className="flex items-center gap-2">
                <button onClick={() => { setEditing({ ...sla }); setIsNew(false); }} className="text-primary-700 hover:text-primary-400"><Edit3 className="w-3.5 h-3.5" /></button>
                {!sla.isDefault && <button onClick={() => { if (confirm('Delete this SLA?')) deleteMut.mutate(sla.id); }} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>}
              </div>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {['p1', 'p2', 'p3', 'p4'].map(p => {
                const LABELS: Record<string, string> = { p1: '🔴 Critical', p2: '🟠 High', p3: '🔵 Normal', p4: '⚪ Low' };
                return (
                  <div key={p} className="p-3 bg-retro-bg border border-retro-border rounded">
                    <p className="font-mono text-[9px] text-primary-600 mb-2">{LABELS[p]}</p>
                    <p className="font-mono text-[10px] text-primary-400">Response: {sla[`${p}ResponseMinutes`]}m</p>
                    <p className="font-mono text-[10px] text-primary-400">Resolve: {Math.round(sla[`${p}ResolutionMinutes`] / 60)}h</p>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Edit/Create modal */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60" onClick={() => { setEditing(null); setIsNew(false); }} />
          <div className="relative bg-retro-card border border-primary-800 rounded-xl p-6 w-full max-w-2xl space-y-4 overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between"><h3 className="font-pixel text-[9px] text-primary-crt">{isNew ? 'CREATE SLA POLICY' : 'EDIT SLA POLICY'}</h3><button onClick={() => { setEditing(null); setIsNew(false); }}><X className="w-4 h-4 text-primary-700" /></button></div>
            <div><label className={cls.label}>POLICY NAME</label><input value={editing.name} onChange={e => setEditing((s: any) => ({ ...s, name: e.target.value }))} className={cls.input} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><label className={cls.label}>WORK START</label><input type="time" value={editing.workdayStart} onChange={e => setEditing((s: any) => ({ ...s, workdayStart: e.target.value }))} className={cls.input} /></div>
              <div><label className={cls.label}>WORK END</label><input type="time" value={editing.workdayEnd} onChange={e => setEditing((s: any) => ({ ...s, workdayEnd: e.target.value }))} className={cls.input} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {['p1', 'p2', 'p3', 'p4'].map(p => {
                const NAMES: Record<string, string> = { p1: 'Critical', p2: 'High', p3: 'Normal', p4: 'Low' };
                return (
                  <div key={p} className="p-3 bg-retro-bg border border-retro-border rounded space-y-2">
                    <p className="font-pixel text-[7px] text-primary-600">{NAMES[p]} ({p.toUpperCase()})</p>
                    <div><label className={cls.label}>Response (min)</label><input type="number" value={editing[`${p}ResponseMinutes`]} onChange={e => setEditing((s: any) => ({ ...s, [`${p}ResponseMinutes`]: +e.target.value }))} className={cls.input} /></div>
                    <div><label className={cls.label}>Resolution (min)</label><input type="number" value={editing[`${p}ResolutionMinutes`]} onChange={e => setEditing((s: any) => ({ ...s, [`${p}ResolutionMinutes`]: +e.target.value }))} className={cls.input} /></div>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 font-mono text-xs text-primary-400 cursor-pointer"><input type="checkbox" checked={editing.businessHoursOnly} onChange={e => setEditing((s: any) => ({ ...s, businessHoursOnly: e.target.checked })} className="accent-primary-600" />Business hours only</label>
              <label className="flex items-center gap-2 font-mono text-xs text-primary-400 cursor-pointer"><input type="checkbox" checked={editing.isDefault} onChange={e => setEditing((s: any) => ({ ...s, isDefault: e.target.checked })} className="accent-primary-600" />Set as default</label>
            </div>
            <div className="flex gap-3">
              <button onClick={() => saveMut.mutate(editing)} disabled={!editing.name || saveMut.isPending} className={`flex-1 py-2 ${cls.btn}`}><Save className="w-3.5 h-3.5" />{saveMut.isPending ? 'Saving…' : 'Save Policy'}</button>
              <button onClick={() => { setEditing(null); setIsNew(false); }} className="flex-1 py-2 border border-retro-border rounded font-mono text-xs text-primary-600">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// KNOWLEDGE BASE PAGE
// ══════════════════════════════════════════════════════════════════════════════

export function KBPage() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('published');
  const [editArticle, setEditArticle] = useState<any | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [form, setForm] = useState({ title: '', content: '', excerpt: '', visibility: 'internal', status: 'draft', tags: '' });
  const qc = useQueryClient();

  const { data: stats } = useQuery({ queryKey: ['kb-stats'], queryFn: () => api('/case-engine/kb/articles/stats').then(r => r.data) });
  const { data: articlesData } = useQuery({ queryKey: ['kb-articles', status, search], queryFn: () => api(`/case-engine/kb/articles?status=${status}&search=${encodeURIComponent(search)}`).then(r => r.data ?? { articles: [] }) });
  const { data: categories = [] } = useQuery({ queryKey: ['kb-categories'], queryFn: () => api('/case-engine/kb/categories').then(r => r.data ?? []) });

  const articles: any[] = articlesData?.articles ?? [];

  const saveMut = useMutation({
    mutationFn: (dto: any) => dto.id ? api(`/case-engine/kb/articles/${dto.id}`, { method: 'PUT', body: JSON.stringify(dto) }) : api('/case-engine/kb/articles', { method: 'POST', body: JSON.stringify(dto) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['kb-articles'] }); qc.invalidateQueries({ queryKey: ['kb-stats'] }); setEditArticle(null); setIsNew(false); },
  });
  const deleteMut = useMutation({ mutationFn: (id: string) => api(`/case-engine/kb/articles/${id}`, { method: 'DELETE' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['kb-articles'] }) });

  const VISIBILITY_ICONS: Record<string, React.ReactNode> = { public: <Globe className="w-3 h-3" />, internal: <Lock className="w-3 h-3" />, 'agents-only': <Eye className="w-3 h-3" /> };

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div><h1 className="font-pixel text-[10px] text-primary-400">KNOWLEDGE BASE</h1><p className="font-mono text-xs text-primary-700 mt-1">Articles · Categories · Version history · AI-powered search</p></div>
        <button onClick={() => { setForm({ title: '', content: '', excerpt: '', visibility: 'internal', status: 'draft', tags: '' }); setIsNew(true); setEditArticle({}); }} className={cls.btn}><Plus className="w-3.5 h-3.5" />New Article</button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-4 gap-3">
          {[{ label: 'Total', v: stats.total, c: 'text-primary-crt' }, { label: 'Published', v: stats.published, c: 'text-green-400' }, { label: 'Drafts', v: stats.drafts, c: 'text-yellow-400' }, { label: 'Top Viewed', v: stats.topViewed?.[0]?.views ?? 0, c: 'text-blue-400' }]
            .map(s => <div key={s.label} className="p-4 bg-retro-card border border-retro-border rounded-lg"><p className={`font-pixel text-[16px] ${s.c}`}>{s.v}</p><p className="font-mono text-[9px] text-primary-700 mt-1">{s.label}</p></div>)}
        </div>
      )}

      {/* Filter */}
      <div className="flex items-center gap-2">
        <div className="relative flex-1"><Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-primary-700" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search articles…" className="w-full pl-8 pr-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none" /></div>
        <select value={status} onChange={e => setStatus(e.target.value)} className="px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:border-primary-600 focus:outline-none">
          <option value="">All</option><option value="published">Published</option><option value="draft">Drafts</option><option value="archived">Archived</option>
        </select>
      </div>

      {/* Article list */}
      <div className="space-y-2">
        {articles.map((a: any) => (
          <div key={a.id} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg hover:border-primary-800 transition-colors">
            <FileText className="w-4 h-4 text-primary-600 shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2"><p className="font-mono text-sm text-primary-300 truncate">{a.title}</p><span className="text-primary-600 shrink-0">{VISIBILITY_ICONS[a.visibility]}</span></div>
              <p className="font-mono text-[9px] text-primary-700 mt-0.5">{a.category?.name ?? 'No category'} · v{a.version} · 👁 {a.views} · 👍 {a.helpful}</p>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <span className={`px-1.5 py-0.5 rounded border font-pixel text-[7px] ${a.status === 'published' ? 'text-green-400 border-green-900 bg-green-950' : 'text-yellow-400 border-yellow-900 bg-yellow-950'}`}>{a.status}</span>
              <button onClick={() => { setEditArticle(a); setForm({ title: a.title, content: a.content, excerpt: a.excerpt ?? '', visibility: a.visibility, status: a.status, tags: (a.tags ?? []).join(', ') }); setIsNew(false); }} className="text-primary-700 hover:text-primary-400"><Edit3 className="w-3.5 h-3.5" /></button>
              <button onClick={() => { if (confirm('Delete article?')) deleteMut.mutate(a.id); }} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
            </div>
          </div>
        ))}
      </div>

      {/* Editor modal */}
      {editArticle !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60" onClick={() => { setEditArticle(null); setIsNew(false); }} />
          <div className="relative bg-retro-card border border-primary-800 rounded-xl p-6 w-full max-w-3xl space-y-4 overflow-y-auto max-h-[90vh]">
            <div className="flex items-center justify-between"><h3 className="font-pixel text-[9px] text-primary-crt">{isNew ? 'NEW ARTICLE' : 'EDIT ARTICLE'}</h3><button onClick={() => { setEditArticle(null); setIsNew(false); }}><X className="w-4 h-4 text-primary-700" /></button></div>
            <div><label className={cls.label}>TITLE</label><input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} className={cls.input} /></div>
            <div className="grid grid-cols-3 gap-3">
              <div><label className={cls.label}>VISIBILITY</label><select value={form.visibility} onChange={e => setForm(f => ({ ...f, visibility: e.target.value }))} className={cls.select}><option value="internal">Internal</option><option value="public">Public</option><option value="agents-only">Agents Only</option></select></div>
              <div><label className={cls.label}>STATUS</label><select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))} className={cls.select}><option value="draft">Draft</option><option value="published">Published</option><option value="archived">Archived</option></select></div>
              <div><label className={cls.label}>TAGS (comma-separated)</label><input value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} placeholder="payroll, leave, onboarding" className={cls.input} /></div>
            </div>
            <div><label className={cls.label}>EXCERPT</label><input value={form.excerpt} onChange={e => setForm(f => ({ ...f, excerpt: e.target.value }))} className={cls.input} /></div>
            <div><label className={cls.label}>CONTENT (Markdown supported)</label><textarea value={form.content} onChange={e => setForm(f => ({ ...f, content: e.target.value }))} rows={12} className={`${cls.input} resize-y font-mono text-xs leading-relaxed`} /></div>
            <div className="flex gap-3">
              <button onClick={() => saveMut.mutate({ ...(editArticle.id ? { id: editArticle.id } : {}), ...form, tags: form.tags.split(',').map((t: string) => t.trim()).filter(Boolean) })} disabled={!form.title || !form.content || saveMut.isPending} className={`flex-1 py-2 ${cls.btn}`}><Save className="w-3.5 h-3.5" />{saveMut.isPending ? 'Saving…' : 'Save Article'}</button>
              <button onClick={() => { setEditArticle(null); setIsNew(false); }} className="flex-1 py-2 border border-retro-border rounded font-mono text-xs text-primary-600">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// CRM DASHBOARD PAGE
// ══════════════════════════════════════════════════════════════════════════════

export function CRMDashboardPage() {
  const [tab, setTab] = useState<'accounts' | 'contacts' | 'pipeline'>('accounts');
  const [search, setSearch] = useState('');
  const [editAccount, setEditAccount] = useState<any | null>(null);
  const qc = useQueryClient();

  const { data: accountsData } = useQuery({ queryKey: ['crm-accounts', search], queryFn: () => api(`/case-engine/crm/accounts?search=${encodeURIComponent(search)}`).then(r => r.data ?? { accounts: [] }) });
  const { data: contactsData } = useQuery({ queryKey: ['crm-contacts', search], queryFn: () => api(`/case-engine/crm/contacts?search=${encodeURIComponent(search)}`).then(r => r.data ?? { contacts: [] }) });
  const { data: pipeline = [] } = useQuery({ queryKey: ['crm-pipeline'], queryFn: () => api('/case-engine/crm/pipeline').then(r => r.data ?? []) });

  const accounts: any[] = accountsData?.accounts ?? [];
  const contacts: any[] = contactsData?.contacts ?? [];

  const createAccMut = useMutation({ mutationFn: (dto: any) => api('/case-engine/crm/accounts', { method: 'POST', body: JSON.stringify(dto) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['crm-accounts'] }); setEditAccount(null); } });

  const pipelineTotal = (pipeline as any[]).reduce((s: number, p: any) => s + Number(p.value ?? 0), 0);
  const STAGE_COLORS: Record<string, string> = { prospect: '#4ade80', qualified: '#22d3ee', proposal: '#a78bfa', negotiation: '#f59e0b', won: '#4ade80', lost: '#f87171' };

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div><h1 className="font-pixel text-[10px] text-primary-400">CRM LITE</h1><p className="font-mono text-xs text-primary-700 mt-1">Accounts · Contacts · Opportunity Pipeline</p></div>
        <button onClick={() => setEditAccount({})} className={cls.btn}><Plus className="w-3.5 h-3.5" />New Account</button>
      </div>

      {/* Pipeline KPIs */}
      <div className="grid grid-cols-4 gap-3">
        <div className="p-4 bg-retro-card border border-retro-border rounded-lg"><p className="font-pixel text-[16px] text-primary-crt">{accounts.length}</p><p className="font-mono text-[9px] text-primary-700">Accounts</p></div>
        <div className="p-4 bg-retro-card border border-retro-border rounded-lg"><p className="font-pixel text-[16px] text-blue-400">{contacts.length}</p><p className="font-mono text-[9px] text-primary-700">Contacts</p></div>
        <div className="p-4 bg-retro-card border border-retro-border rounded-lg"><p className="font-pixel text-[16px] text-purple-400">{(pipeline as any[]).reduce((s: number, p: any) => s + (p.count ?? 0), 0)}</p><p className="font-mono text-[9px] text-primary-700">Opportunities</p></div>
        <div className="p-4 bg-retro-card border border-retro-border rounded-lg"><p className="font-pixel text-[14px] text-green-400">₹{(pipelineTotal / 100000).toFixed(1)}L</p><p className="font-mono text-[9px] text-primary-700">Pipeline Value</p></div>
      </div>

      {/* Tab bar */}
      <div className="flex items-center gap-1 p-1 bg-retro-bg border border-retro-border rounded-lg w-fit">
        {(['accounts', 'contacts', 'pipeline'] as const).map(t => (
          <button key={t} onClick={() => setTab(t)} className={`px-4 py-2 rounded font-mono text-xs transition-all ${tab === t ? 'bg-primary-900 border border-primary-700 text-primary-300' : 'text-primary-700 hover:text-primary-500'}`}>{t.charAt(0).toUpperCase() + t.slice(1)}</button>
        ))}
      </div>

      <div className="relative"><Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-primary-700" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search…" className="w-full pl-8 pr-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none" /></div>

      {tab === 'accounts' && (
        <div className="space-y-2">
          {accounts.map((a: any) => (
            <div key={a.id} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg">
              <Building className="w-4 h-4 text-primary-600 shrink-0" />
              <div className="flex-1 min-w-0"><p className="font-mono text-sm text-primary-300">{a.name}</p><p className="font-mono text-[9px] text-primary-700">{a.industry ?? '—'} · {a._count?.contacts ?? 0} contacts · {a._count?.opportunities ?? 0} opps</p></div>
              <span className={`font-mono text-[9px] px-2 py-0.5 rounded border ${a.status === 'active' ? 'text-green-400 border-green-900' : 'text-primary-700 border-retro-border'}`}>{a.status}</span>
            </div>
          ))}
        </div>
      )}

      {tab === 'contacts' && (
        <div className="space-y-2">
          {contacts.map((c: any) => (
            <div key={c.id} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg">
              <Users className="w-4 h-4 text-primary-600 shrink-0" />
              <div className="flex-1 min-w-0"><p className="font-mono text-sm text-primary-300">{c.firstName} {c.lastName}</p><p className="font-mono text-[9px] text-primary-700">{c.account?.name ?? 'No account'} · {c.email ?? '—'}</p></div>
              {c.phone && <span className="flex items-center gap-1 font-mono text-[9px] text-primary-600"><Phone className="w-3 h-3" />{c.phone}</span>}
            </div>
          ))}
        </div>
      )}

      {tab === 'pipeline' && (
        <div className="space-y-4">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={pipeline as any[]} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
              <XAxis dataKey="stage" tick={{ fontSize: 9, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
              <YAxis tick={{ fontSize: 9, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
              <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #1a2332', fontFamily: 'monospace', fontSize: 10 }} />
              <Bar dataKey="count" fill="#4ade80" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="space-y-2">
            {(pipeline as any[]).map((p: any) => (
              <div key={p.stage} className="flex items-center justify-between p-3 bg-retro-card border border-retro-border rounded-lg">
                <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full" style={{ background: STAGE_COLORS[p.stage] ?? '#4b5563' }} /><span className="font-mono text-xs text-primary-400 capitalize">{p.stage}</span></div>
                <div className="flex items-center gap-6"><span className="font-mono text-xs text-primary-600">{p.count} deals</span><span className="font-mono text-xs text-green-400">₹{(Number(p.value ?? 0) / 100000).toFixed(1)}L</span></div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* New Account modal */}
      {editAccount !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60" onClick={() => setEditAccount(null)} />
          <div className="relative bg-retro-card border border-primary-800 rounded-xl p-6 w-full max-w-md space-y-4">
            <div className="flex items-center justify-between"><h3 className="font-pixel text-[9px] text-primary-crt">NEW ACCOUNT</h3><button onClick={() => setEditAccount(null)}><X className="w-4 h-4 text-primary-700" /></button></div>
            <AccountForm onSave={dto => createAccMut.mutate(dto)} onCancel={() => setEditAccount(null)} saving={createAccMut.isPending} />
          </div>
        </div>
      )}
    </div>
  );
}

function AccountForm({ onSave, onCancel, saving }: { onSave: (dto: any) => void; onCancel: () => void; saving: boolean }) {
  const [form, setForm] = useState({ name: '', industry: '', website: '', phone: '', email: '', tier: 'smb' });
  return (
    <div className="space-y-3">
      <div><label className={cls.label}>COMPANY NAME *</label><input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className={cls.input} /></div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className={cls.label}>INDUSTRY</label><input value={form.industry} onChange={e => setForm(f => ({ ...f, industry: e.target.value }))} className={cls.input} /></div>
        <div><label className={cls.label}>TIER</label><select value={form.tier} onChange={e => setForm(f => ({ ...f, tier: e.target.value }))} className={cls.select}><option value="smb">SMB</option><option value="mid-market">Mid-Market</option><option value="enterprise">Enterprise</option></select></div>
      </div>
      <div><label className={cls.label}>WEBSITE</label><input value={form.website} onChange={e => setForm(f => ({ ...f, website: e.target.value }))} className={cls.input} /></div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className={cls.label}>PHONE</label><input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} className={cls.input} /></div>
        <div><label className={cls.label}>EMAIL</label><input value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} className={cls.input} /></div>
      </div>
      <div className="flex gap-3">
        <button onClick={() => onSave(form)} disabled={!form.name || saving} className={`flex-1 py-2 ${cls.btn}`}>{saving ? 'Saving…' : 'Create Account'}</button>
        <button onClick={onCancel} className="flex-1 py-2 border border-retro-border rounded font-mono text-xs text-primary-600">Cancel</button>
      </div>
    </div>
  );
}
