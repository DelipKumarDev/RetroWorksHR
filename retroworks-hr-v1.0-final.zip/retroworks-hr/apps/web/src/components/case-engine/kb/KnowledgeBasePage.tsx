'use client';

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  BookOpen, Plus, ChevronRight, Eye, EyeOff, FileText,
  Tag, History, ThumbsUp, ThumbsDown, Pencil, Check, X,
  Search, Globe, Lock, Users, Cpu, Save, RotateCcw,
} from 'lucide-react';

const api = async (path: string, opts?: RequestInit) => {
  const r = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers } });
  return r.json();
};

const VISIBILITY_META: Record<string, { icon: React.ReactNode; label: string; color: string }> = {
  public: { icon: <Globe className="w-3 h-3" />, label: 'Public', color: 'text-green-400 border-green-900' },
  internal: { icon: <Users className="w-3 h-3" />, label: 'Internal', color: 'text-blue-400 border-blue-900' },
  'agents-only': { icon: <Lock className="w-3 h-3" />, label: 'Agents Only', color: 'text-yellow-400 border-yellow-900' },
};

const STATUS_META: Record<string, { color: string; label: string }> = {
  draft: { color: 'text-primary-500 border-primary-800', label: 'Draft' },
  published: { color: 'text-green-400 border-green-900', label: 'Published' },
  archived: { color: 'text-red-400 border-red-900', label: 'Archived' },
};

function ArticleEditor({ article, categories, onSave, onCancel }: { article?: any; categories: any[]; onSave: (data: any) => void; onCancel: () => void }) {
  const [form, setForm] = useState({
    title: article?.title ?? '',
    content: article?.content ?? '',
    categoryId: article?.categoryId ?? '',
    visibility: article?.visibility ?? 'internal',
    status: article?.status ?? 'draft',
    tags: (article?.tags ?? []).join(', '),
  });
  const [tagInput, setTagInput] = useState((article?.tags ?? []).join(', '));
  const wordCount = form.content.split(/\s+/).filter(Boolean).length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-pixel text-[9px] text-primary-crt">{article ? 'EDIT ARTICLE' : 'NEW ARTICLE'}</h3>
        <div className="flex items-center gap-2">
          <span className="font-mono text-[9px] text-primary-700">{wordCount} words</span>
          {article?.version && <span className="font-mono text-[9px] text-primary-700">v{article.version}</span>}
        </div>
      </div>
      <input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="Article title…" className="w-full px-3 py-2.5 bg-retro-bg border border-retro-border rounded font-mono text-base text-primary-200 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none" />
      <div className="grid grid-cols-3 gap-3">
        <div>
          <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">CATEGORY</label>
          <select value={form.categoryId} onChange={e => setForm(p => ({ ...p, categoryId: e.target.value }))} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:outline-none">
            <option value="">Uncategorized</option>
            {categories.map((c: any) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
        <div>
          <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">VISIBILITY</label>
          <select value={form.visibility} onChange={e => setForm(p => ({ ...p, visibility: e.target.value }))} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:outline-none">
            <option value="public">🌍 Public</option>
            <option value="internal">👥 Internal (employees)</option>
            <option value="agents-only">🔒 Agents Only</option>
          </select>
        </div>
        <div>
          <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">STATUS</label>
          <select value={form.status} onChange={e => setForm(p => ({ ...p, status: e.target.value }))} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:outline-none">
            <option value="draft">Draft</option>
            <option value="published">Published</option>
            <option value="archived">Archived</option>
          </select>
        </div>
      </div>
      <div>
        <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">CONTENT (Markdown supported)</label>
        <textarea value={form.content} onChange={e => setForm(p => ({ ...p, content: e.target.value }))} rows={14} placeholder="Write your article here…&#10;&#10;Supports markdown: # Headers, **bold**, *italic*, - lists, `code`" className="w-full px-3 py-2.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none resize-none leading-relaxed" />
      </div>
      <div>
        <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">TAGS (comma separated)</label>
        <input value={tagInput} onChange={e => setTagInput(e.target.value)} placeholder="leave policy, payroll, PF, India" className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none" />
      </div>
      <div className="flex items-center gap-3">
        <button onClick={() => onSave({ ...form, tags: tagInput.split(',').map((t: string) => t.trim()).filter(Boolean) })} disabled={!form.title} className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500 disabled:opacity-40">
          <Save className="w-3.5 h-3.5" /> {form.status === 'published' ? 'Publish' : 'Save Draft'}
        </button>
        <button onClick={onCancel} className="px-4 py-2 border border-retro-border rounded font-mono text-xs text-primary-600 hover:text-primary-400">Cancel</button>
      </div>
    </div>
  );
}

function ArticleList({ articles, onSelect, onNew, selected }: any) {
  const [search, setSearch] = useState('');
  const [vis, setVis] = useState('');

  const filtered = (articles as any[]).filter((a: any) => {
    const matchSearch = !search || `${a.title} ${a.tags?.join(' ')}`.toLowerCase().includes(search.toLowerCase());
    const matchVis = !vis || a.visibility === vis;
    return matchSearch && matchVis;
  });

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <div className="relative flex-1"><Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-primary-700" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search articles…" className="w-full pl-7 pr-2 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none" /></div>
        <select value={vis} onChange={e => setVis(e.target.value)} className="px-2 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:outline-none">
          <option value="">All visibility</option>
          <option value="public">Public</option>
          <option value="internal">Internal</option>
          <option value="agents-only">Agents</option>
        </select>
        <button onClick={onNew} className="flex items-center gap-1 px-2.5 py-1.5 bg-primary-900 border border-primary-700 rounded font-mono text-[9px] text-primary-400 hover:border-primary-500"><Plus className="w-3 h-3" />New</button>
      </div>
      <div className="space-y-1.5">
        {filtered.length === 0 ? <p className="text-center py-8 font-mono text-sm text-primary-700">No articles found</p> : (
          filtered.map((a: any) => {
            const vis = VISIBILITY_META[a.visibility] ?? VISIBILITY_META.internal;
            const st = STATUS_META[a.status] ?? STATUS_META.draft;
            return (
              <div key={a.id} onClick={() => onSelect(a)} className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${selected?.id === a.id ? 'bg-primary-950 border-primary-700' : 'bg-retro-card border-retro-border hover:border-primary-800'}`}>
                <FileText className="w-3.5 h-3.5 text-primary-600 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-mono text-sm text-primary-300 truncate">{a.title}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className={`flex items-center gap-1 font-mono text-[8px] border rounded px-1.5 ${vis.color}`}>{vis.icon}{vis.label}</span>
                    <span className={`font-mono text-[8px] border rounded px-1.5 ${st.color}`}>{st.label}</span>
                    {a.aiEmbedded && <span className="flex items-center gap-1 font-mono text-[8px] text-purple-400 border border-purple-900 rounded px-1.5"><Cpu className="w-2.5 h-2.5" />AI</span>}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="flex items-center gap-2 font-mono text-[9px] text-primary-700">
                    <span className="flex items-center gap-0.5"><ThumbsUp className="w-2.5 h-2.5" />{a.helpful}</span>
                    <span>{a.views} views</span>
                  </div>
                  <p className="font-mono text-[8px] text-primary-800 mt-0.5">v{a.version}</p>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

function VersionHistoryModal({ articleId, onClose }: { articleId: string; onClose: () => void }) {
  const { data: versions = [] } = useQuery({ queryKey: ['kb-versions', articleId], queryFn: () => api(`/case-engine/kb/articles/${articleId}/versions`).then(r => r.data ?? []) });
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative bg-retro-card border border-primary-800 rounded-xl p-6 w-full max-w-lg space-y-4 max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between"><h3 className="font-pixel text-[9px] text-primary-crt">VERSION HISTORY</h3><button onClick={onClose}><X className="w-4 h-4 text-primary-700" /></button></div>
        <div className="space-y-2">
          {(versions as any[]).map((v: any) => (
            <div key={v.id} className="flex items-center gap-3 p-3 bg-retro-bg border border-retro-border rounded-lg">
              <History className="w-3.5 h-3.5 text-primary-600" />
              <div className="flex-1"><p className="font-mono text-sm text-primary-400">v{v.version} — {v.title}</p><p className="font-mono text-[9px] text-primary-700">by {v.savedBy} · {new Date(v.createdAt).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}</p></div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function KnowledgeBasePage() {
  const [selected, setSelected] = useState<any | null>(null);
  const [editing, setEditing] = useState(false);
  const [creating, setCreating] = useState(false);
  const [showVersions, setShowVersions] = useState(false);
  const qc = useQueryClient();

  const { data: articles = [] } = useQuery({ queryKey: ['kb-articles'], queryFn: () => api('/case-engine/kb/articles').then(r => r.data?.articles ?? r.data ?? []) });
  const { data: categories = [] } = useQuery({ queryKey: ['kb-categories'], queryFn: () => api('/case-engine/kb/categories').then(r => r.data ?? []) });

  const createMut = useMutation({ mutationFn: (dto: any) => api('/case-engine/kb/articles', { method: 'POST', body: JSON.stringify(dto) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['kb-articles'] }); setCreating(false); } });
  const updateMut = useMutation({ mutationFn: ({ id, ...dto }: any) => api(`/case-engine/kb/articles/${id}`, { method: 'PUT', body: JSON.stringify(dto) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['kb-articles'] }); setEditing(false); } });
  const embedMut = useMutation({ mutationFn: (id: string) => api(`/case-engine/kb/articles/${id}/embed`, { method: 'POST' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['kb-articles'] }) });

  const stats = {
    total: (articles as any[]).length,
    published: (articles as any[]).filter((a: any) => a.status === 'published').length,
    aiIndexed: (articles as any[]).filter((a: any) => a.aiEmbedded).length,
    totalViews: (articles as any[]).reduce((s: number, a: any) => s + (a.views ?? 0), 0),
  };

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div><h1 className="font-pixel text-[10px] text-primary-400">KNOWLEDGE BASE</h1><p className="font-mono text-xs text-primary-700 mt-1">Articles · Versioning · AI-indexed · Role visibility</p></div>
        <div className="flex items-center gap-3 font-mono text-[10px] text-primary-700">
          <span>{stats.total} articles</span>
          <span className="text-green-400">{stats.published} published</span>
          <span className="flex items-center gap-1 text-purple-400"><Cpu className="w-3 h-3" />{stats.aiIndexed} AI-indexed</span>
          <span>{stats.totalViews} total views</span>
        </div>
      </div>

      <div className="grid grid-cols-5 gap-5">
        {/* Article list */}
        <div className="col-span-2">
          <ArticleList articles={articles} onSelect={(a: any) => { setSelected(a); setEditing(false); }} onNew={() => { setSelected(null); setCreating(true); setEditing(false); }} selected={selected} />
        </div>

        {/* Editor / Detail */}
        <div className="col-span-3">
          {creating && (
            <div className="bg-retro-card border border-primary-800 rounded-xl p-5">
              <ArticleEditor categories={categories as any[]} onSave={data => createMut.mutate(data)} onCancel={() => setCreating(false)} />
            </div>
          )}
          {selected && !creating && !editing && (
            <div className="bg-retro-card border border-retro-border rounded-xl p-5 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <h2 className="font-mono text-lg text-primary-200">{selected.title}</h2>
                  <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                    {selected.visibility && (() => { const v = VISIBILITY_META[selected.visibility]; return <span className={`flex items-center gap-1 px-2 py-0.5 border rounded font-mono text-[9px] ${v.color}`}>{v.icon}{v.label}</span>; })()}
                    {selected.status && (() => { const s = STATUS_META[selected.status]; return <span className={`px-2 py-0.5 border rounded font-pixel text-[8px] ${s.color}`}>{s.label}</span>; })()}
                    {selected.aiEmbedded && <span className="flex items-center gap-1 px-2 py-0.5 border border-purple-900 rounded font-mono text-[9px] text-purple-400"><Cpu className="w-2.5 h-2.5" />AI Indexed</span>}
                    <span className="font-mono text-[9px] text-primary-700">v{selected.version}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button onClick={() => setShowVersions(true)} className="flex items-center gap-1 font-mono text-[9px] text-primary-600 hover:text-primary-400"><History className="w-3 h-3" />History</button>
                  {!selected.aiEmbedded && <button onClick={() => embedMut.mutate(selected.id)} className="flex items-center gap-1 font-mono text-[9px] text-purple-600 hover:text-purple-400"><Cpu className="w-3 h-3" />Index for AI</button>}
                  <button onClick={() => setEditing(true)} className="flex items-center gap-1 font-mono text-[9px] text-primary-600 hover:text-primary-400"><Pencil className="w-3 h-3" />Edit</button>
                </div>
              </div>
              {selected.tags?.length > 0 && (
                <div className="flex items-center gap-1.5 flex-wrap">
                  <Tag className="w-3 h-3 text-primary-700" />
                  {selected.tags.map((t: string) => <span key={t} className="px-2 py-0.5 bg-retro-bg border border-retro-border rounded font-mono text-[9px] text-primary-600">{t}</span>)}
                </div>
              )}
              <div className="prose prose-invert max-w-none">
                <pre className="font-mono text-xs text-primary-400 leading-relaxed whitespace-pre-wrap">{selected.content}</pre>
              </div>
              <div className="flex items-center gap-4 pt-2 border-t border-retro-border font-mono text-[10px] text-primary-700">
                <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{selected.views} views</span>
                <span className="flex items-center gap-1"><ThumbsUp className="w-3 h-3 text-green-400" />{selected.helpful} helpful</span>
                <span className="flex items-center gap-1"><ThumbsDown className="w-3 h-3 text-red-400" />{selected.notHelpful} not helpful</span>
              </div>
            </div>
          )}
          {selected && editing && (
            <div className="bg-retro-card border border-primary-800 rounded-xl p-5">
              <ArticleEditor article={selected} categories={categories as any[]} onSave={data => updateMut.mutate({ id: selected.id, ...data })} onCancel={() => setEditing(false)} />
            </div>
          )}
          {!selected && !creating && (
            <div className="flex flex-col items-center justify-center h-64 gap-3 bg-retro-card border border-retro-border rounded-xl">
              <BookOpen className="w-10 h-10 text-primary-800" />
              <p className="font-mono text-sm text-primary-700">Select an article or create a new one</p>
            </div>
          )}
        </div>
      </div>

      {showVersions && selected && <VersionHistoryModal articleId={selected.id} onClose={() => setShowVersions(false)} />}
    </div>
  );
}
