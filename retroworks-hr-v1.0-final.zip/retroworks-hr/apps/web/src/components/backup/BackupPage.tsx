'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Database, Play, Clock, CheckCircle, XCircle, RefreshCw,
  HardDrive, AlertTriangle, RotateCcw, Calendar, Download,
} from 'lucide-react';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers } });
  return res.json();
};

const STATUS_STYLES: Record<string, string> = {
  success: 'text-green-400 bg-green-950 border-green-900',
  failed: 'text-red-400 bg-red-950 border-red-900',
  running: 'text-yellow-400 bg-yellow-950 border-yellow-900',
  pending: 'text-blue-400 bg-blue-950 border-blue-900',
};

export function BackupPage() {
  const [restoreBackupId, setRestoreBackupId] = useState('');
  const [restoreReason, setRestoreReason] = useState('');
  const [showRestoreForm, setShowRestoreForm] = useState(false);
  const [restoreSuccess, setRestoreSuccess] = useState<string | null>(null);
  const qc = useQueryClient();

  const { data: summary } = useQuery({ queryKey: ['backup-summary'], queryFn: () => api('/backup/summary').then(r => r.data), refetchInterval: 30000 });
  const { data: backups = [], isLoading } = useQuery({ queryKey: ['backups'], queryFn: () => api('/backup').then(r => r.data ?? []), refetchInterval: 30000 });
  const { data: restoreReqs = [] } = useQuery({ queryKey: ['restore-requests'], queryFn: () => api('/backup/restore/requests').then(r => r.data ?? []) });

  const triggerMut = useMutation({ mutationFn: () => api('/backup/trigger', { method: 'POST' }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['backups'] }); qc.invalidateQueries({ queryKey: ['backup-summary'] }); } });
  const restoreMut = useMutation({
    mutationFn: (dto: any) => api('/backup/restore', { method: 'POST', body: JSON.stringify(dto) }),
    onSuccess: (res) => { setRestoreSuccess(res.data?.restoreId ?? ''); setShowRestoreForm(false); setRestoreBackupId(''); setRestoreReason(''); qc.invalidateQueries({ queryKey: ['restore-requests'] }); },
  });

  const backupList = backups as any[];

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div><h1 className="font-pixel text-[10px] text-primary-400">BACKUP & RECOVERY</h1><p className="font-mono text-xs text-primary-700 mt-1">Automated daily/weekly backups · Manual trigger · Restore requests</p></div>
        <button onClick={() => triggerMut.mutate()} disabled={triggerMut.isPending} className="flex items-center gap-2 px-4 py-2.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500 disabled:opacity-40">
          {triggerMut.isPending ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
          {triggerMut.isPending ? 'Running…' : 'Trigger Manual Backup'}
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: 'Last Backup', value: summary?.lastBackup ? new Date(summary.lastBackup.completedAt).toLocaleDateString('en-IN', { dateStyle: 'short' }) : 'Never', sub: summary?.lastBackup?.type ?? '', icon: <CheckCircle className="w-4 h-4 text-green-400" /> },
          { label: 'Total Backups', value: summary?.total ?? '—', sub: `${summary?.successful ?? 0} successful`, icon: <Database className="w-4 h-4 text-blue-400" /> },
          { label: 'Storage Used', value: summary?.totalStorageMB ? `${summary.totalStorageMB} MB` : '—', sub: 'Compressed .sql.gz', icon: <HardDrive className="w-4 h-4 text-purple-400" /> },
          { label: 'Next Scheduled', value: summary?.nextScheduled ? new Date(summary.nextScheduled).toLocaleTimeString('en-IN', { timeStyle: 'short' }) : '—', sub: 'Daily at 1am UTC', icon: <Calendar className="w-4 h-4 text-yellow-400" /> },
        ].map(s => (
          <div key={s.label} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg">
            <div>{s.icon}</div>
            <div><p className="font-pixel text-[13px] text-primary-crt">{s.value}</p><p className="font-mono text-[9px] text-primary-700">{s.label}</p>{s.sub && <p className="font-mono text-[8px] text-primary-800">{s.sub}</p>}</div>
          </div>
        ))}
      </div>

      {/* Failed warning */}
      {(summary?.failed ?? 0) > 0 && (
        <div className="flex items-center gap-3 p-4 bg-red-950/20 border border-red-900 rounded-lg">
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
          <p className="font-mono text-sm text-red-400">{summary.failed} backup failure{summary.failed > 1 ? 's' : ''} recorded — check logs and verify database connectivity.</p>
        </div>
      )}

      {/* Restore request success */}
      {restoreSuccess && (
        <div className="flex items-center gap-3 p-4 bg-blue-950/20 border border-blue-900 rounded-lg">
          <CheckCircle className="w-4 h-4 text-blue-400 shrink-0" />
          <div>
            <p className="font-mono text-sm text-blue-400">Restore request submitted (ID: {restoreSuccess})</p>
            <p className="font-mono text-[10px] text-blue-700">Super admin has been notified. Actual restore requires manual confirmation.</p>
          </div>
          <button onClick={() => setRestoreSuccess(null)} className="ml-auto text-blue-700 hover:text-blue-500 font-mono text-xs">Dismiss</button>
        </div>
      )}

      {/* Backup list */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <p className="font-pixel text-[8px] text-primary-500">BACKUP HISTORY</p>
          <button onClick={() => qc.invalidateQueries({ queryKey: ['backups'] })} className="text-primary-700 hover:text-primary-400"><RefreshCw className="w-3.5 h-3.5" /></button>
        </div>

        <div className="bg-retro-card border border-retro-border rounded-xl overflow-hidden">
          <div className="grid grid-cols-6 gap-3 px-4 py-2 border-b border-retro-border bg-retro-bg font-pixel text-[7px] text-primary-700">
            <span className="col-span-2">BACKUP ID</span><span>TYPE</span><span>STATUS</span><span>SIZE</span><span>ACTIONS</span>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12 gap-3 font-mono text-sm text-primary-700"><RefreshCw className="w-4 h-4 animate-spin" />Loading backups…</div>
          ) : backupList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 gap-2"><Database className="w-8 h-8 text-primary-800" /><p className="font-mono text-sm text-primary-700">No backups yet — trigger a manual backup to get started</p></div>
          ) : (
            backupList.map((b: any) => (
              <div key={b.id} className="grid grid-cols-6 gap-3 items-center px-4 py-3 border-b border-retro-border/30 hover:bg-retro-bg/50">
                <div className="col-span-2">
                  <p className="font-mono text-xs text-primary-400 truncate">{b.id}</p>
                  <p className="font-mono text-[9px] text-primary-700">{new Date(b.startedAt).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}</p>
                </div>
                <span className="font-mono text-xs text-primary-500 capitalize">{b.type}</span>
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded border text-[8px] font-pixel w-fit ${STATUS_STYLES[b.status] ?? ''}`}>
                  {b.status === 'running' && <RefreshCw className="w-2.5 h-2.5 animate-spin" />}
                  {b.status === 'success' && <CheckCircle className="w-2.5 h-2.5" />}
                  {b.status === 'failed' && <XCircle className="w-2.5 h-2.5" />}
                  {b.status}
                </span>
                <span className="font-mono text-xs text-primary-500">{b.fileSizeMB ? `${b.fileSizeMB} MB` : '—'}</span>
                <div className="flex items-center gap-2">
                  {b.status === 'success' && (
                    <button onClick={() => { setRestoreBackupId(b.id); setShowRestoreForm(true); }} className="flex items-center gap-1 font-mono text-[9px] text-primary-600 hover:text-primary-400">
                      <RotateCcw className="w-3 h-3" /> Restore
                    </button>
                  )}
                  {b.status === 'failed' && b.error && <span className="font-mono text-[9px] text-red-700 truncate" title={b.error}>Error</span>}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Restore request form */}
      {showRestoreForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60" onClick={() => setShowRestoreForm(false)} />
          <div className="relative bg-retro-card border border-primary-800 rounded-xl p-6 w-full max-w-md space-y-4">
            <h3 className="font-pixel text-[9px] text-primary-crt">REQUEST RESTORE</h3>
            <div className="p-3 bg-yellow-950/20 border border-yellow-900 rounded text-yellow-400 font-mono text-xs">
              ⚠️ This will request a database restore. Current data will be replaced. Super admin approval required.
            </div>
            <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">BACKUP ID</label><input value={restoreBackupId} readOnly className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-500" /></div>
            <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">REASON FOR RESTORE *</label><textarea value={restoreReason} onChange={e => setRestoreReason(e.target.value)} placeholder="Describe why you need this restore..." rows={3} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none resize-none" /></div>
            <div className="flex gap-3">
              <button onClick={() => restoreMut.mutate({ backupId: restoreBackupId, reason: restoreReason })} disabled={!restoreReason || restoreMut.isPending} className="flex-1 py-2 bg-red-900 border border-red-700 rounded font-pixel text-[8px] text-red-300 disabled:opacity-40">
                {restoreMut.isPending ? 'Submitting…' : 'Submit Restore Request'}
              </button>
              <button onClick={() => setShowRestoreForm(false)} className="flex-1 py-2 border border-retro-border rounded font-mono text-xs text-primary-600">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Restore requests log */}
      {(restoreReqs as any[]).length > 0 && (
        <div>
          <p className="font-pixel text-[8px] text-primary-500 mb-3">RESTORE REQUESTS</p>
          <div className="space-y-2">
            {(restoreReqs as any[]).map((r: any) => (
              <div key={r.id} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg">
                <RotateCcw className="w-4 h-4 text-primary-600 shrink-0" />
                <div className="flex-1"><p className="font-mono text-xs text-primary-400">Backup: {r.backupId}</p><p className="font-mono text-[10px] text-primary-700">{r.reason}</p></div>
                <span className={`px-2 py-0.5 rounded border text-[8px] font-pixel ${STATUS_STYLES[r.status] ?? ''}`}>{r.status}</span>
                <span className="font-mono text-[9px] text-primary-700">{new Date(r.requestedAt).toLocaleDateString('en-IN')}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
