'use client';

import { useState, useMemo } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import {
  BarChart2, Table, PieChart, TrendingUp, Plus, Trash2,
  Download, Save, Play, ChevronRight, RefreshCw, Star,
  FileText, Filter, Columns, Share2, Clock, X,
} from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart as RePie, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers },
  });
  return res.json();
};

const CRT_PALETTE = ['#4ade80', '#22d3ee', '#a78bfa', '#f59e0b', '#f87171', '#34d399', '#60a5fa', '#c084fc'];

type ChartType = 'table' | 'bar' | 'line' | 'pie';
const MODULE_OPTIONS = ['employees', 'leave', 'payroll', 'attendance', 'performance'];

interface FilterRow { field: string; operator: string; value: string }

const OPERATORS = [
  { value: 'eq', label: '= equals' },
  { value: 'neq', label: '≠ not equals' },
  { value: 'gt', label: '> greater than' },
  { value: 'gte', label: '≥ greater or equal' },
  { value: 'lt', label: '< less than' },
  { value: 'lte', label: '≤ less or equal' },
  { value: 'contains', label: '~ contains' },
];

const cls = {
  input: 'px-2.5 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none',
  select: 'px-2.5 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none',
  btn: 'flex items-center gap-1.5 px-3 py-1.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-400 hover:border-primary-500 transition-all',
};

// ─── Chart Renderer ───────────────────────────────────────────────

function ChartView({ data, chartType, fields }: { data: any[]; chartType: ChartType; fields: string[] }) {
  if (!data.length) return <div className="flex items-center justify-center h-48 text-primary-700 font-mono text-sm">No data to display</div>;

  const xField = fields[0] ?? 'name';
  const numFields = fields.slice(1).filter(f => {
    const sample = data[0]?.[f];
    return !isNaN(Number(sample));
  });

  if (chartType === 'table') {
    return (
      <div className="overflow-auto max-h-96">
        <table className="w-full">
          <thead>
            <tr className="border-b border-retro-border">
              {fields.map(f => <th key={f} className="px-3 py-2 text-left font-pixel text-[7px] text-primary-600 whitespace-nowrap">{f.split('.').pop()?.toUpperCase()}</th>)}
            </tr>
          </thead>
          <tbody>
            {data.map((row, i) => (
              <tr key={i} className="border-b border-retro-border/30 hover:bg-retro-bg">
                {fields.map(f => <td key={f} className="px-3 py-2 font-mono text-xs text-primary-400 whitespace-nowrap">{String(row[f] ?? '—')}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (chartType === 'bar' && numFields.length > 0) {
    return (
      <ResponsiveContainer width="100%" height={280}>
        <BarChart data={data.slice(0, 50)} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
          <XAxis dataKey={xField} tick={{ fontSize: 9, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <YAxis tick={{ fontSize: 9, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #1a2332', fontFamily: 'monospace', fontSize: 10 }} />
          <Legend wrapperStyle={{ fontSize: 9, fontFamily: 'monospace' }} />
          {numFields.map((f, i) => <Bar key={f} dataKey={f} fill={CRT_PALETTE[i % CRT_PALETTE.length]} radius={[2, 2, 0, 0]} />)}
        </BarChart>
      </ResponsiveContainer>
    );
  }

  if (chartType === 'line' && numFields.length > 0) {
    return (
      <ResponsiveContainer width="100%" height={280}>
        <LineChart data={data.slice(0, 50)} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
          <XAxis dataKey={xField} tick={{ fontSize: 9, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <YAxis tick={{ fontSize: 9, fill: '#4b5563', fontFamily: 'monospace' }} tickLine={false} />
          <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #1a2332', fontFamily: 'monospace', fontSize: 10 }} />
          {numFields.map((f, i) => <Line key={f} dataKey={f} stroke={CRT_PALETTE[i % CRT_PALETTE.length]} strokeWidth={2} dot={false} />)}
        </LineChart>
      </ResponsiveContainer>
    );
  }

  if (chartType === 'pie') {
    const pieData = data.slice(0, 10).map(r => ({ name: String(r[xField] ?? ''), value: Number(r[numFields[0]] ?? 0) }));
    return (
      <ResponsiveContainer width="100%" height={280}>
        <RePie margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
          <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false} fontSize={9}>
            {pieData.map((_, i) => <Cell key={i} fill={CRT_PALETTE[i % CRT_PALETTE.length]} />)}
          </Pie>
          <Tooltip contentStyle={{ background: '#0d1117', border: '1px solid #1a2332', fontFamily: 'monospace', fontSize: 10 }} />
        </RePie>
      </ResponsiveContainer>
    );
  }

  return <div className="flex items-center justify-center h-48 text-primary-700 font-mono text-xs">Select a different chart type</div>;
}

// ─── Prebuilt Reports Tab ─────────────────────────────────────────

function PrebuiltReportsTab() {
  const [running, setRunning] = useState<string | null>(null);
  const [result, setResult] = useState<{ id: string; data: any } | null>(null);
  const [params, setParams] = useState({ month: new Date().getMonth() + 1, year: new Date().getFullYear() });

  const { data: catalogue = [] } = useQuery({ queryKey: ['prebuilt-catalogue'], queryFn: () => api('/report-builder/catalogue/prebuilt').then(r => r.data ?? []) });

  const runReport = async (id: string) => {
    setRunning(id);
    const res = await api(`/report-builder/prebuilt/${id}?month=${params.month}&year=${params.year}`);
    setResult({ id, data: res.data });
    setRunning(null);
  };

  const categories = [...new Set((catalogue as any[]).map((r: any) => r.category))];

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <label className="font-pixel text-[7px] text-primary-600">MONTH</label>
          <select value={params.month} onChange={e => setParams(p => ({ ...p, month: +e.target.value }))} className={cls.select}>
            {Array.from({ length: 12 }, (_, i) => <option key={i+1} value={i+1}>{new Date(2024, i).toLocaleString('en-IN', { month: 'long' })}</option>)}
          </select>
        </div>
        <div className="flex items-center gap-2">
          <label className="font-pixel text-[7px] text-primary-600">YEAR</label>
          <select value={params.year} onChange={e => setParams(p => ({ ...p, year: +e.target.value }))} className={cls.select}>
            {[2023, 2024, 2025, 2026].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </div>
      </div>

      {categories.map(cat => (
        <div key={cat as string}>
          <p className="font-pixel text-[7px] text-primary-700 mb-2">{cat as string}</p>
          <div className="grid grid-cols-3 gap-3">
            {(catalogue as any[]).filter((r: any) => r.category === cat).map((report: any) => (
              <div key={report.id} className={`p-4 bg-retro-card border rounded-lg transition-all cursor-pointer ${result?.id === report.id ? 'border-primary-700' : 'border-retro-border hover:border-primary-800'}`} onClick={() => runReport(report.id)}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-mono text-sm text-primary-300">{report.name}</p>
                    <p className="font-mono text-[10px] text-primary-700 mt-1">{report.description}</p>
                  </div>
                  {running === report.id ? <RefreshCw className="w-3.5 h-3.5 text-primary-600 animate-spin shrink-0" /> : <Play className="w-3.5 h-3.5 text-primary-700 shrink-0" />}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}

      {result && (
        <div className="bg-retro-card border border-primary-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <p className="font-pixel text-[8px] text-primary-400">REPORT RESULTS</p>
            <div className="flex items-center gap-2">
              <span className="font-mono text-[10px] text-primary-700">{result.data?.total ?? result.data?.rows?.length ?? 0} rows</span>
              <button onClick={() => setResult(null)} className="text-primary-700 hover:text-primary-400"><X className="w-3.5 h-3.5" /></button>
            </div>
          </div>
          {result.data?.summary && (
            <div className="grid grid-cols-4 gap-3 mb-4">
              {Object.entries(result.data.summary).map(([k, v]) => (
                <div key={k} className="p-3 bg-retro-bg border border-retro-border rounded">
                  <p className="font-pixel text-[12px] text-primary-crt">{typeof v === 'number' ? (v > 1000 ? `₹${v.toLocaleString('en-IN')}` : v) : String(v)}</p>
                  <p className="font-mono text-[9px] text-primary-700">{k}</p>
                </div>
              ))}
            </div>
          )}
          {result.data?.rows?.length > 0 && (
            <div className="overflow-auto max-h-80">
              <table className="w-full">
                <thead><tr className="border-b border-retro-border">{Object.keys(result.data.rows[0]).slice(0, 8).map((k: string) => <th key={k} className="px-3 py-2 text-left font-pixel text-[7px] text-primary-600 whitespace-nowrap">{k.toUpperCase()}</th>)}</tr></thead>
                <tbody>{result.data.rows.slice(0, 50).map((row: any, i: number) => (
                  <tr key={i} className="border-b border-retro-border/30 hover:bg-retro-bg">
                    {Object.keys(row).slice(0, 8).map((k: string) => <td key={k} className="px-3 py-2 font-mono text-xs text-primary-400 whitespace-nowrap">{String(row[k] ?? '—')}</td>)}
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Custom Builder Tab ───────────────────────────────────────────

function CustomBuilderTab() {
  const [module, setModule] = useState('employees');
  const [selectedFields, setSelectedFields] = useState<string[]>([]);
  const [filters, setFilters] = useState<FilterRow[]>([]);
  const [chartType, setChartType] = useState<ChartType>('table');
  const [result, setResult] = useState<any[] | null>(null);
  const [running, setRunning] = useState(false);
  const [reportName, setReportName] = useState('');
  const [savingReport, setSavingReport] = useState(false);

  const { data: fieldCatalogue } = useQuery({ queryKey: ['field-catalogue'], queryFn: () => api('/report-builder/catalogue/fields').then(r => r.data) });
  const availableFields = useMemo(() => (fieldCatalogue?.[module] ?? []) as { key: string; label: string; type: string }[], [fieldCatalogue, module]);

  const toggleField = (key: string) => setSelectedFields(f => f.includes(key) ? f.filter(k => k !== key) : [...f, key]);

  const runQuery = async () => {
    if (selectedFields.length === 0) return;
    setRunning(true);
    const res = await api('/report-builder/run', {
      method: 'POST',
      body: JSON.stringify({ module, fields: selectedFields, filters }),
    });
    setResult(res.data?.rows ?? []);
    setRunning(false);
  };

  const saveReport = async () => {
    if (!reportName) return;
    setSavingReport(true);
    await api('/report-builder/reports', { method: 'POST', body: JSON.stringify({ name: reportName, module, fields: selectedFields, filters, chartType }) });
    setSavingReport(false);
    setReportName('');
  };

  const chartTypes: { type: ChartType; icon: React.ReactNode; label: string }[] = [
    { type: 'table', icon: <Table className="w-3.5 h-3.5" />, label: 'Table' },
    { type: 'bar', icon: <BarChart2 className="w-3.5 h-3.5" />, label: 'Bar' },
    { type: 'line', icon: <TrendingUp className="w-3.5 h-3.5" />, label: 'Line' },
    { type: 'pie', icon: <PieChart className="w-3.5 h-3.5" />, label: 'Pie' },
  ];

  return (
    <div className="grid grid-cols-12 gap-5">
      {/* Left panel — field picker */}
      <div className="col-span-3 space-y-4">
        <div>
          <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">DATA SOURCE</label>
          <select value={module} onChange={e => { setModule(e.target.value); setSelectedFields([]); }} className={`${cls.select} w-full`}>
            {MODULE_OPTIONS.map(m => <option key={m} value={m}>{m.charAt(0).toUpperCase() + m.slice(1)}</option>)}
          </select>
        </div>

        <div>
          <p className="font-pixel text-[7px] text-primary-600 mb-2">AVAILABLE FIELDS</p>
          <div className="space-y-1 max-h-80 overflow-y-auto pr-1">
            {availableFields.map(f => (
              <button key={f.key} onClick={() => toggleField(f.key)}
                className={`w-full flex items-center gap-2 px-2.5 py-2 rounded text-left font-mono text-xs transition-all ${selectedFields.includes(f.key) ? 'bg-primary-950 border border-primary-700 text-primary-300' : 'border border-transparent text-primary-600 hover:border-retro-border hover:text-primary-400'}`}>
                <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${selectedFields.includes(f.key) ? 'bg-primary-crt' : 'bg-primary-800'}`} />
                <span className="truncate">{f.label}</span>
                <span className={`ml-auto text-[8px] shrink-0 ${f.type === 'number' ? 'text-yellow-700' : f.type === 'date' ? 'text-blue-700' : 'text-primary-800'}`}>{f.type}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Filters */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <p className="font-pixel text-[7px] text-primary-600">FILTERS</p>
            <button onClick={() => setFilters(f => [...f, { field: availableFields[0]?.key ?? '', operator: 'eq', value: '' }])} className="text-primary-700 hover:text-primary-400"><Plus className="w-3 h-3" /></button>
          </div>
          <div className="space-y-2">
            {filters.map((f, i) => (
              <div key={i} className="flex flex-col gap-1 p-2 bg-retro-bg border border-retro-border rounded">
                <div className="flex items-center gap-1">
                  <select value={f.field} onChange={e => setFilters(fl => fl.map((r, j) => j === i ? { ...r, field: e.target.value } : r))} className={`${cls.select} flex-1 text-[9px]`}>
                    {availableFields.map(af => <option key={af.key} value={af.key}>{af.label}</option>)}
                  </select>
                  <button onClick={() => setFilters(fl => fl.filter((_, j) => j !== i))} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>
                </div>
                <select value={f.operator} onChange={e => setFilters(fl => fl.map((r, j) => j === i ? { ...r, operator: e.target.value } : r))} className={`${cls.select} text-[9px]`}>
                  {OPERATORS.map(op => <option key={op.value} value={op.value}>{op.label}</option>)}
                </select>
                <input value={f.value} onChange={e => setFilters(fl => fl.map((r, j) => j === i ? { ...r, value: e.target.value } : r))} placeholder="value" className={`${cls.input} text-[9px]`} />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right panel — preview */}
      <div className="col-span-9 space-y-4">
        {/* Toolbar */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1 p-1 bg-retro-bg border border-retro-border rounded">
            {chartTypes.map(ct => (
              <button key={ct.type} onClick={() => setChartType(ct.type)} className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded font-mono text-[9px] transition-all ${chartType === ct.type ? 'bg-primary-900 text-primary-300' : 'text-primary-700 hover:text-primary-500'}`}>
                {ct.icon}{ct.label}
              </button>
            ))}
          </div>
          <button onClick={runQuery} disabled={selectedFields.length === 0 || running} className={`${cls.btn} disabled:opacity-40`}>
            {running ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />}
            {running ? 'Running…' : 'Run Report'}
          </button>
          {result && (
            <a href={`/api/v1/report-builder/run/export?format=csv`} className={cls.btn}>
              <Download className="w-3 h-3" /> Export CSV
            </a>
          )}
        </div>

        {/* Selected fields display */}
        {selectedFields.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-pixel text-[7px] text-primary-700">COLUMNS:</span>
            {selectedFields.map(f => {
              const fd = availableFields.find(af => af.key === f);
              return (
                <span key={f} className="flex items-center gap-1 px-2 py-0.5 bg-primary-950 border border-primary-800 rounded font-mono text-[9px] text-primary-400">
                  {fd?.label ?? f}
                  <button onClick={() => toggleField(f)} className="text-primary-700 hover:text-red-400 ml-1"><X className="w-2.5 h-2.5" /></button>
                </span>
              );
            })}
          </div>
        )}

        {/* Chart / results */}
        <div className="bg-retro-card border border-retro-border rounded-xl p-5 min-h-64">
          {!result && !running && (
            <div className="flex flex-col items-center justify-center h-48 gap-3">
              <BarChart2 className="w-10 h-10 text-primary-800" />
              <p className="font-mono text-sm text-primary-700">Select fields and click Run Report</p>
            </div>
          )}
          {running && <div className="flex items-center justify-center h-48 gap-3 font-mono text-sm text-primary-600"><RefreshCw className="w-5 h-5 animate-spin" />Running query…</div>}
          {result && <ChartView data={result} chartType={chartType} fields={selectedFields} />}
        </div>

        {/* Save report */}
        {result && (
          <div className="flex items-center gap-3">
            <input value={reportName} onChange={e => setReportName(e.target.value)} placeholder="Report name to save…" className={`${cls.input} flex-1`} />
            <button onClick={saveReport} disabled={!reportName || savingReport} className={`${cls.btn} disabled:opacity-40`}>
              <Save className="w-3 h-3" /> {savingReport ? 'Saving…' : 'Save Report'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Saved Reports Tab ────────────────────────────────────────────

function SavedReportsTab() {
  const { data: reports = [] } = useQuery({ queryKey: ['saved-reports'], queryFn: () => api('/report-builder/reports').then(r => r.data ?? []) });

  return (
    <div className="space-y-3">
      {(reports as any[]).length === 0 ? (
        <div className="text-center py-16 text-primary-700 font-mono text-sm">No saved reports yet. Build and save one from the Custom Builder tab.</div>
      ) : (reports as any[]).map((r: any) => (
        <div key={r.id} className="flex items-center justify-between p-4 bg-retro-card border border-retro-border rounded-lg">
          <div>
            <div className="flex items-center gap-2">
              <p className="font-mono text-sm text-primary-300">{r.name}</p>
              {r.isShared && <span className="flex items-center gap-1 font-mono text-[8px] text-blue-400 border border-blue-900 rounded px-1.5"><Share2 className="w-2.5 h-2.5" />Shared</span>}
              {r.scheduledDelivery?.enabled && <span className="flex items-center gap-1 font-mono text-[8px] text-yellow-400 border border-yellow-900 rounded px-1.5"><Clock className="w-2.5 h-2.5" />Scheduled</span>}
            </div>
            <p className="font-mono text-[10px] text-primary-700 mt-0.5">{r.module} · {(r.fields ?? []).length} fields · updated {new Date(r.updatedAt).toLocaleDateString('en-IN')}</p>
          </div>
          <div className="flex items-center gap-2">
            <a href={`/api/v1/report-builder/reports/${r.id}/export?format=csv`} className={cls.btn}><Download className="w-3 h-3" />CSV</a>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Main Page ────────────────────────────────────────────────────

type Tab = 'builder' | 'prebuilt' | 'saved';

export function ReportBuilderPage() {
  const [tab, setTab] = useState<Tab>('prebuilt');

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'prebuilt', label: 'Prebuilt Reports', icon: <Star className="w-3.5 h-3.5" /> },
    { id: 'builder', label: 'Custom Builder', icon: <Columns className="w-3.5 h-3.5" /> },
    { id: 'saved', label: 'Saved Reports', icon: <Save className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="space-y-5 animate-fade-in">
      <div>
        <h1 className="font-pixel text-[10px] text-primary-400">REPORT BUILDER</h1>
        <p className="font-mono text-xs text-primary-700 mt-1">Build custom reports, run statutory India reports, schedule email delivery</p>
      </div>

      {/* Tab bar */}
      <div className="flex items-center gap-1 p-1 bg-retro-bg border border-retro-border rounded-lg w-fit">
        {tabs.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded font-mono text-xs transition-all ${tab === t.id ? 'bg-primary-900 border border-primary-700 text-primary-300 shadow-glow' : 'text-primary-700 hover:text-primary-500'}`}>
            {t.icon}{t.label}
          </button>
        ))}
      </div>

      <div>
        {tab === 'prebuilt' && <PrebuiltReportsTab />}
        {tab === 'builder' && <CustomBuilderTab />}
        {tab === 'saved' && <SavedReportsTab />}
      </div>
    </div>
  );
}
