'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  BookOpen, Play, Trophy, Award, Clock, CheckCircle2, ChevronRight,
  Zap, BarChart2,
} from 'lucide-react';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
      ...opts?.headers,
    },
  }).then(r => r.json());

const LEVEL_CONFIG = {
  beginner: { label: 'Beginner', color: 'text-green-400 border-green-800' },
  intermediate: { label: 'Intermediate', color: 'text-amber-400 border-amber-800' },
  advanced: { label: 'Advanced', color: 'text-red-400 border-red-800' },
};

function CourseCard({ course, onEnroll }: {
  course: {
    id: string; title: string; description: string; category: string;
    level: string; durationMinutes: number; mandatory: boolean; hasCertificate: boolean;
    _count: { enrollments: number; modules: number };
    enrollment?: { progress: number; status: string } | null;
  };
  onEnroll: (id: string) => void;
}) {
  const lvl = LEVEL_CONFIG[course.level as keyof typeof LEVEL_CONFIG] ?? LEVEL_CONFIG.beginner;
  const isEnrolled = !!course.enrollment;
  const isComplete = course.enrollment?.status === 'completed';
  const progress = course.enrollment?.progress ?? 0;

  return (
    <div className="bg-retro-card border border-retro-border rounded overflow-hidden hover:border-primary-800 transition-all group">
      {/* Thumbnail placeholder */}
      <div className="h-28 bg-primary-950 relative flex items-center justify-center border-b border-retro-border">
        <BookOpen className="w-10 h-10 text-primary-800" />
        {course.mandatory && (
          <span className="absolute top-2 left-2 px-1.5 py-0.5 bg-red-950 border border-red-800 font-pixel text-[6px] text-red-400 rounded">
            MANDATORY
          </span>
        )}
        {isComplete && (
          <div className="absolute inset-0 bg-green-950/50 flex items-center justify-center">
            <CheckCircle2 className="w-8 h-8 text-green-400" />
          </div>
        )}
        {!isComplete && isEnrolled && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-retro-bg">
            <div className="h-full bg-primary-crt" style={{ width: `${progress}%` }} />
          </div>
        )}
      </div>

      <div className="p-4 space-y-2">
        <div className="flex items-center gap-2">
          <span className={`font-pixel text-[6px] border px-1.5 py-0.5 rounded ${lvl.color}`}>{lvl.label}</span>
          {course.hasCertificate && <Award className="w-3.5 h-3.5 text-amber-600" title="Certificate on completion" />}
          <span className="font-mono text-[9px] text-primary-700 ml-auto">{course.category}</span>
        </div>

        <h3 className="font-mono text-sm text-primary-300 leading-tight line-clamp-2">{course.title}</h3>

        <div className="flex items-center gap-3 font-mono text-[10px] text-primary-700">
          <span className="flex items-center gap-1"><Clock className="w-2.5 h-2.5" /> {Math.round(course.durationMinutes / 60)}h</span>
          <span>{course._count.modules} modules</span>
          <span>{course._count.enrollments} enrolled</span>
        </div>

        {isEnrolled && !isComplete && (
          <div className="flex items-center gap-2">
            <div className="flex-1 h-1 bg-retro-bg rounded-full">
              <div className="h-full bg-primary-crt rounded-full" style={{ width: `${progress}%` }} />
            </div>
            <span className="font-mono text-[9px] text-primary-700">{progress}%</span>
          </div>
        )}

        <button
          onClick={() => onEnroll(course.id)}
          disabled={isComplete}
          className={`w-full py-1.5 font-pixel text-[7px] rounded border transition-all ${
            isComplete
              ? 'border-green-800 text-green-600 bg-green-950/30 cursor-default'
              : isEnrolled
                ? 'border-primary-700 text-primary-crt bg-primary-950 hover:border-primary-crt hover:shadow-glow'
                : 'border-primary-700 text-primary-500 hover:border-primary-600 hover:text-primary-400'
          }`}
        >
          {isComplete ? '✓ COMPLETED' : isEnrolled ? '▶ CONTINUE' : '+ ENROLL'}
        </button>
      </div>
    </div>
  );
}

export function LearningPage() {
  const [tab, setTab] = useState<'catalog' | 'my-courses' | 'leaderboard'>('catalog');
  const [category, setCategory] = useState('');
  const qc = useQueryClient();

  const { data: courses = [] } = useQuery({
    queryKey: ['courses', category],
    queryFn: () => api(`/learning/courses${category ? `?category=${category}` : ''}`).then(r => r.data ?? []),
  });

  const { data: myCourses = [] } = useQuery({
    queryKey: ['my-courses'],
    queryFn: () => api('/learning/my-courses').then(r => r.data ?? []),
    enabled: tab === 'my-courses',
  });

  const { data: stats } = useQuery({
    queryKey: ['learning-stats'],
    queryFn: () => api('/learning/stats').then(r => r.data),
  });

  const { data: leaderboard = [] } = useQuery({
    queryKey: ['learning-leaderboard'],
    queryFn: () => api('/learning/leaderboard').then(r => r.data ?? []),
    enabled: tab === 'leaderboard',
  });

  const enrollMutation = useMutation({
    mutationFn: (courseId: string) => api(`/learning/courses/${courseId}/enroll`, { method: 'POST' }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['courses'] });
      void qc.invalidateQueries({ queryKey: ['my-courses'] });
      void qc.invalidateQueries({ queryKey: ['learning-stats'] });
    },
  });

  const categories = ['All', ...new Set((courses as Array<{ category: string }>).map(c => c.category))];

  return (
    <div className="space-y-5 animate-fade-in">
      <div>
        <h1 className="font-pixel text-[10px] text-primary-400">LEARNING & DEVELOPMENT</h1>
        <p className="font-mono text-xs text-primary-700 mt-1">Courses, skills, and certifications</p>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: 'Enrolled', value: stats.total, icon: <BookOpen className="w-3.5 h-3.5" /> },
            { label: 'Completed', value: stats.completed, icon: <CheckCircle2 className="w-3.5 h-3.5" /> },
            { label: 'In Progress', value: stats.inProgress, icon: <Play className="w-3.5 h-3.5" /> },
            { label: 'Certificates', value: stats.certificates, icon: <Award className="w-3.5 h-3.5" /> },
          ].map(s => (
            <div key={s.label} className="bg-retro-card border border-retro-border rounded p-3 text-center">
              <div className="flex justify-center text-primary-700 mb-1">{s.icon}</div>
              <p className="font-pixel text-pixel-lg text-primary-crt">{s.value}</p>
              <p className="font-pixel text-[6px] text-primary-700 mt-0.5">{s.label.toUpperCase()}</p>
            </div>
          ))}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-0 border-b border-retro-border">
        {([
          { key: 'catalog', label: 'Course Catalog' },
          { key: 'my-courses', label: 'My Courses' },
          { key: 'leaderboard', label: 'Leaderboard' },
        ] as const).map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2 font-pixel text-[8px] border-b-2 transition-all ${
              tab === t.key ? 'border-primary-crt text-primary-crt' : 'border-transparent text-primary-700 hover:text-primary-500'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Catalog */}
      {tab === 'catalog' && (
        <>
          <div className="flex gap-2 flex-wrap">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setCategory(cat === 'All' ? '' : cat)}
                className={`px-3 py-1 font-mono text-xs rounded border transition-all ${
                  (cat === 'All' && !category) || cat === category
                    ? 'border-primary-crt text-primary-crt bg-primary-950'
                    : 'border-retro-border text-primary-700 hover:border-primary-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {(courses as Parameters<typeof CourseCard>[0]['course'][]).map(course => (
              <CourseCard
                key={course.id}
                course={course}
                onEnroll={(id) => enrollMutation.mutate(id)}
              />
            ))}
          </div>
        </>
      )}

      {/* My Courses */}
      {tab === 'my-courses' && (
        <div className="space-y-3">
          {(myCourses as Array<{
            id: string; progress: number; status: string; enrolledAt: string; completedAt?: string;
            course: { title: string; category: string; level: string; durationMinutes: number; hasCertificate: boolean };
          }>).map(enrollment => (
            <div key={enrollment.id} className="bg-retro-card border border-retro-border rounded p-4 flex items-center gap-4">
              <div className={`w-10 h-10 rounded border-2 flex items-center justify-center shrink-0 ${
                enrollment.status === 'completed' ? 'border-green-600 bg-green-950' : 'border-primary-800 bg-primary-950'
              }`}>
                {enrollment.status === 'completed'
                  ? <CheckCircle2 className="w-5 h-5 text-green-400" />
                  : <Play className="w-4 h-4 text-primary-600" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-mono text-sm text-primary-300 truncate">{enrollment.course.title}</p>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex-1 h-1 bg-retro-bg rounded-full">
                    <div className="h-full bg-primary-crt rounded-full" style={{ width: `${enrollment.progress}%` }} />
                  </div>
                  <span className="font-mono text-[10px] text-primary-700">{enrollment.progress}%</span>
                </div>
              </div>
              {enrollment.course.hasCertificate && enrollment.status === 'completed' && (
                <Award className="w-5 h-5 text-amber-500 shrink-0" title="Certificate earned!" />
              )}
            </div>
          ))}
        </div>
      )}

      {/* Leaderboard */}
      {tab === 'leaderboard' && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 mb-4">
            <Trophy className="w-5 h-5 text-amber-500" />
            <h2 className="font-pixel text-[9px] text-primary-400">TOP LEARNERS</h2>
          </div>
          {(leaderboard as Array<{
            employee: { firstName: string; lastName: string; department?: { name: string } };
            coursesCompleted: number;
          }>).map((entry, i) => (
            <div key={i} className="bg-retro-card border border-retro-border rounded p-3 flex items-center gap-4">
              <span className={`font-pixel text-[10px] w-6 text-center ${
                i === 0 ? 'text-amber-400' : i === 1 ? 'text-primary-400' : i === 2 ? 'text-amber-700' : 'text-primary-700'
              }`}>
                {i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`}
              </span>
              <div className="flex-1">
                <p className="font-mono text-sm text-primary-300">
                  {entry.employee.firstName} {entry.employee.lastName}
                </p>
                <p className="font-mono text-[10px] text-primary-700">{entry.employee.department?.name ?? ''}</p>
              </div>
              <div className="text-right">
                <p className="font-pixel text-[10px] text-primary-crt">{entry.coursesCompleted}</p>
                <p className="font-mono text-[9px] text-primary-700">courses</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
