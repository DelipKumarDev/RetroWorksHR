'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Zap, Plus, Trash2, ToggleLeft, ToggleRight, Play, Clock, CheckCircle, ArrowRight, ChevronRight } from 'lucide-react';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers } });
  return res.json();
};

interface Condition { field: string; operator: string; value: string }
interface Action { type: string; params: Record<string, string> }
interface Rule { id?: string; name: string; description?: string; trigger: string; conditions: Condition[]; conditionLogic: 'AND' | 'OR'; actions: Action[]; isActive: boolean; runCount?: number; lastRunAt?: string }

const OPERATORS = ['eq','neq','gt','gte','lt','lte','contains','in','is_null'];
const defaultRule: Rule = { name: '', trigger: '', conditions: [], conditionLogic: 'AND', actions: [{ type: 'notify_employee', params: { message: '' } }], isActive: true };
const cls = { input: "w-full px-2.5 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none", select: "px-2.5 py-1.5 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none" };

function RuleCard({ rule, onToggle, onDelete, onEdit }: { rule: Rule & { id: string; runCount: number; lastRunAt?: string }; onToggle: () => void; onDelete: () => void; onEdit: () => void }) {
  return (
    <div className={`bg-retro-card border rounded-lg p-5 transition-all ${rule.isActive ? 'border-retro-border' : 'border-retro-border/40 opacity-60'}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <p className="font-mono text-sm text-primary-300 font-medium truncate">{rule.name}</p>
            {rule.isActive ? <span className="flex items-center gap-1 font-mono text-[8px] text-green-400"><span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />Active</span> : <span className="font-mono text-[8px] text-primary-700">Inactive</span>}
          </div>
          <div className="flex items-center gap-2 font-mono text-xs flex-wrap">
            <span className="px-2 py-1 bg-blue-950 border border-blue-900 rounded text-blue-400">IF {rule.trigger}</span>
            {rule.conditions.length > 0 && <><ArrowRight className="w-3 h-3 text-primary-700" /><span className="px-2 py-1 bg-purple-950 border border-purple-900 rounded text-purple-400">{rule.conditions.length} condition{rule.conditions.length > 1 ? 's' : ''} ({rule.conditionLogic})</span></>}
            <ArrowRight className="w-3 h-3 text-primary-700" />
            <span className="px-2 py-1 bg-green-950 border border-green-900 rounded text-green-400">{rule.actions.length} action{rule.actions.length > 1 ? 's' : ''}</span>
          </div>
          <div className="flex items-center gap-4 mt-2 font-mono text-[9px] text-primary-800">
            <span className="flex items-center gap-1"><Play className="w-2.5 h-2.5" />Ran {rule.runCount} times</span>
            {rule.lastRunAt && <span className="flex items-center gap-1"><Clock className="w-2.5 h-2.5" />Last: {new Date(rule.lastRunAt).toLocaleString('en-IN', { dateStyle: 'short', timeStyle: 'short' })}</span>}
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button onClick={onEdit} className="px-3 py-1.5 border border-retro-border rounded font-mono text-xs text-primary-600 hover:text-primary-400">Edit</button>
          <button onClick={onToggle}>{rule.isActive ? <ToggleRight className="w-6 h-6 text-primary-crt" /> : <ToggleLeft className="w-6 h-6 text-primary-700" />}</button>
          <button onClick={onDelete} className="p-1.5 text-primary-800 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
        </div>
      </div>
    </div>
  );
}

function RuleEditor({ rule, catalogue, onSave, onCancel }: { rule: Rule; catalogue: any; onSave: (r: Rule) => void; onCancel: () => void }) {
  const [form, setForm] = useState<Rule>(rule);
  const selTrig = catalogue?.triggers?.flatMap((g: any) => g.triggers)?.find((t: any) => t.value === form.trigger);

  return (
    <div className="bg-retro-card border border-primary-800 rounded-xl p-6 space-y-5">
      <div className="flex items-center justify-between">
        <h3 className="font-pixel text-[9px] text-primary-crt">{rule.id ? 'EDIT RULE' : 'NEW AUTOMATION RULE'}</h3>
        <button onClick={onCancel} className="font-mono text-xs text-primary-700 hover:text-primary-400">Cancel</button>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">RULE NAME *</label><input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="e.g. Long leave requires HR approval" className={cls.input} /></div>
        <div><label className="block font-pixel text-[7px] text-primary-600 mb-1.5">DESCRIPTION</label><input value={form.description ?? ''} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Optional description" className={cls.input} /></div>
      </div>
      {/* IF */}
      <div className="space-y-3">
        <div className="flex items-center gap-3"><div className="px-2.5 py-1 bg-blue-950 border border-blue-900 rounded font-pixel text-[8px] text-blue-400">IF</div><div className="h-px flex-1 bg-retro-border" /></div>
        <select value={form.trigger} onChange={e => setForm(f => ({ ...f, trigger: e.target.value, conditions: [] }))} className={`${cls.select} w-full`}>
          <option value="">— Select trigger —</option>
          {(catalogue?.triggers ?? []).map((g: any) => <optgroup key={g.category} label={g.category}>{g.triggers.map((t: any) => <option key={t.value} value={t.value}>{t.label}</option>)}</optgroup>)}
        </select>
        {form.trigger && <div className="space-y-2">
          <div className="flex items-center gap-2"><label className="font-pixel text-[7px] text-primary-600">CONDITIONS</label>
            <select value={form.conditionLogic} onChange={e => setForm(f => ({ ...f, conditionLogic: e.target.value as 'AND'|'OR' }))} className={`${cls.select} text-[9px]`}><option value="AND">ALL match (AND)</option><option value="OR">ANY match (OR)</option></select>
          </div>
          {form.conditions.map((cond, i) => (
            <div key={i} className="flex items-center gap-2 p-3 bg-retro-bg border border-retro-border rounded">
              <select value={cond.field} onChange={e => setForm(f => ({ ...f, conditions: f.conditions.map((c,j) => j===i ? {...c, field: e.target.value} : c) }))} className={cls.select}>
                {(selTrig?.fields ?? []).map((f: string) => <option key={f} value={f}>{f}</option>)}
              </select>
              <select value={cond.operator} onChange={e => setForm(f => ({ ...f, conditions: f.conditions.map((c,j) => j===i ? {...c, operator: e.target.value} : c) }))} className={cls.select}>
                {OPERATORS.map(op => <option key={op} value={op}>{op}</option>)}
              </select>
              {cond.operator !== 'is_null' && <input value={cond.value} onChange={e => setForm(f => ({ ...f, conditions: f.conditions.map((c,j) => j===i ? {...c, value: e.target.value} : c) }))} placeholder="value" className={`${cls.input} flex-1`} />}
              <button onClick={() => setForm(f => ({ ...f, conditions: f.conditions.filter((_,j) => j!==i) }))} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
            </div>
          ))}
          <button onClick={() => setForm(f => ({ ...f, conditions: [...f.conditions, { field: selTrig?.fields?.[0] ?? '', operator: 'eq', value: '' }] }))} className="flex items-center gap-1.5 font-mono text-xs text-primary-700 hover:text-primary-500"><Plus className="w-3 h-3" /> Add condition</button>
        </div>}
      </div>
      {/* THEN */}
      <div className="space-y-3">
        <div className="flex items-center gap-3"><div className="px-2.5 py-1 bg-green-950 border border-green-900 rounded font-pixel text-[8px] text-green-400">THEN</div><div className="h-px flex-1 bg-retro-border" /></div>
        {form.actions.map((action, i) => {
          const def = (catalogue?.actions ?? []).find((a: any) => a.value === action.type);
          return (
            <div key={i} className="p-3 bg-retro-bg border border-retro-border rounded space-y-2">
              <div className="flex items-center gap-2">
                <select value={action.type} onChange={e => setForm(f => ({ ...f, actions: f.actions.map((a,j) => j===i ? {...a, type: e.target.value, params: {}} : a) }))} className={`${cls.select} flex-1`}>
                  {(catalogue?.actions ?? []).map((a: any) => <option key={a.value} value={a.value}>{a.label}</option>)}
                </select>
                {form.actions.length > 1 && <button onClick={() => setForm(f => ({ ...f, actions: f.actions.filter((_,j) => j!==i) }))} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>}
              </div>
              {(def?.params ?? []).map((p: string) => <div key={p}><label className="block font-pixel text-[7px] text-primary-700 mb-1">{p.toUpperCase()}</label><input value={action.params[p] ?? ''} onChange={e => setForm(f => ({ ...f, actions: f.actions.map((a,j) => j===i ? {...a, params: {...a.params, [p]: e.target.value}} : a) }))} placeholder={p === 'message' ? 'Use {{employee.firstName}} etc.' : p} className={cls.input} /></div>)}
            </div>
          );
        })}
        <button onClick={() => setForm(f => ({ ...f, actions: [...f.actions, { type: 'notify_employee', params: { message: '' } }] }))} className="flex items-center gap-1.5 font-mono text-xs text-primary-700 hover:text-primary-500"><Plus className="w-3 h-3" /> Add action</button>
      </div>
      <div className="flex items-center gap-3 pt-2 border-t border-retro-border">
        <button onClick={() => onSave(form)} disabled={!form.name || !form.trigger} className="flex items-center gap-2 px-5 py-2.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500 disabled:opacity-30">
          <CheckCircle className="w-3.5 h-3.5" /> Save Rule
        </button>
      </div>
    </div>
  );
}

export function AutomationPage() {
  const [editing, setEditing] = useState<Rule | null>(null);
  const qc = useQueryClient();
  const { data: rules = [] } = useQuery({ queryKey: ['automation-rules'], queryFn: () => api('/automation/rules').then(r => r.data ?? []) });
  const { data: catalogue } = useQuery({ queryKey: ['automation-catalogue'], queryFn: () => api('/automation/catalogue').then(r => r.data) });
  const save = useMutation({ mutationFn: (r: Rule) => r.id ? api(`/automation/rules/${r.id}`, { method: 'PUT', body: JSON.stringify(r) }) : api('/automation/rules', { method: 'POST', body: JSON.stringify(r) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['automation-rules'] }); setEditing(null); } });
  const toggle = useMutation({ mutationFn: (id: string) => api(`/automation/rules/${id}/toggle`, { method: 'PATCH' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['automation-rules'] }) });
  const del = useMutation({ mutationFn: (id: string) => api(`/automation/rules/${id}`, { method: 'DELETE' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['automation-rules'] }) });
  const ruleList = rules as any[];

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div><h1 className="font-pixel text-[10px] text-primary-400">AUTOMATION RULES</h1><p className="font-mono text-xs text-primary-700 mt-1">Build IF/THEN automation rules — no code required</p></div>
        {!editing && <button onClick={() => setEditing(defaultRule)} className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500"><Plus className="w-3.5 h-3.5" /> New Rule</button>}
      </div>
      <div className="grid grid-cols-3 gap-3">
        {[['Total Rules', ruleList.length, <Zap className="w-3.5 h-3.5" />], ['Active', ruleList.filter((r: any) => r.isActive).length, <CheckCircle className="w-3.5 h-3.5 text-green-400" />], ['Total Runs', ruleList.reduce((s: number, r: any) => s + (r.runCount ?? 0), 0), <Play className="w-3.5 h-3.5 text-blue-400" />]].map(([l, v, icon]) => (
          <div key={l as string} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg"><div className="text-primary-600">{icon as React.ReactNode}</div><div><p className="font-pixel text-[14px] text-primary-crt">{v as string|number}</p><p className="font-mono text-[9px] text-primary-700">{l as string}</p></div></div>
        ))}
      </div>
      {editing && <RuleEditor rule={editing} catalogue={catalogue} onSave={r => save.mutate(r)} onCancel={() => setEditing(null)} />}
      {!editing && (
        <div className="space-y-3">
          {ruleList.length === 0 ? (
            <div className="text-center py-16 bg-retro-card border border-retro-border rounded-xl">
              <Zap className="w-12 h-12 text-primary-800 mx-auto mb-3" />
              <p className="font-pixel text-[9px] text-primary-600 mb-5">No automation rules yet</p>
              <button onClick={() => setEditing(defaultRule)} className="flex items-center gap-2 px-4 py-2.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500 mx-auto"><Plus className="w-3.5 h-3.5" /> Create First Rule</button>
            </div>
          ) : ruleList.map((rule: any) => <RuleCard key={rule.id} rule={rule} onToggle={() => toggle.mutate(rule.id)} onDelete={() => { if (confirm('Delete this rule?')) del.mutate(rule.id); }} onEdit={() => setEditing(rule)} />)}
        </div>
      )}
      {!editing && <div className="p-4 bg-retro-bg border border-retro-border rounded-lg"><p className="font-pixel text-[7px] text-primary-700 mb-2">EXAMPLE RULES</p><div className="grid grid-cols-2 gap-2 font-mono text-[10px] text-primary-700">{['IF leave.submitted AND leave.days > 3 THEN notify_manager','IF salary.changed AND salary.changePercent > 20 THEN escalate to CFO','IF attendance.absent AND consecutiveDays > 2 THEN create_ticket','IF onboarding.task.overdue THEN notify_hr'].map(e => <div key={e} className="flex items-start gap-2"><ChevronRight className="w-2.5 h-2.5 text-primary-800 mt-0.5 shrink-0" />{e}</div>)}</div></div>}
    </div>
  );
}
