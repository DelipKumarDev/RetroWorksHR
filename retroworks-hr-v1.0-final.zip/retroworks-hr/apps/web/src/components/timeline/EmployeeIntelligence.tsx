'use client';
// ══════════════════════════════════════════════════════════════
// Employee Lifecycle Timeline — "Employee Story View"
// Ethics & Bias Report — fairness monitor
// Employee Growth Path Visualizer — career progression
// ══════════════════════════════════════════════════════════════
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { User, TrendingUp, Calendar, Star, BookOpen, Shield, ChevronRight, AlertTriangle, CheckCircle } from 'lucide-react';

const api = (path: string) => fetch(`/api/v1${path}`, { headers: { Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}` } }).then(r => r.json());

// ─── EMPLOYEE TIMELINE ────────────────────────────────────────

const EVENT_ICONS: Record<string, React.ReactNode> = {
  joined: '🎉', confirmed: '✅', salary_change: '💰', performance: '⭐',
  role_change: '🚀', leave: '🌴', learning: '📚', policy: '📋',
};
const EVENT_COLORS: Record<string, string> = {
  green: 'border-green-700 bg-green-950/20', blue: 'border-blue-700 bg-blue-950/20',
  purple: 'border-purple-700 bg-purple-950/20', gold: 'border-yellow-600 bg-yellow-950/20',
  orange: 'border-orange-700 bg-orange-950/20', red: 'border-red-700 bg-red-950/20',
  teal: 'border-teal-700 bg-teal-950/20', primary: 'border-primary-700 bg-primary-950/20',
};

export function EmployeeTimeline({ employeeId }: { employeeId: string }) {
  const { data: events = [], isLoading } = useQuery({ queryKey: ['timeline', employeeId], queryFn: () => api(`/timeline/employees/${employeeId}`).then(r => r.data ?? []) });

  if (isLoading) return <div className="text-center py-10 font-mono text-xs text-primary-700 animate-pulse">Loading timeline…</div>;
  if ((events as any[]).length === 0) return <div className="text-center py-10 font-mono text-xs text-primary-700">No timeline events yet</div>;

  return (
    <div className="space-y-2">
      <p className="font-pixel text-[8px] text-primary-500 mb-4">EMPLOYEE STORY TIMELINE</p>
      <div className="relative">
        <div className="absolute left-5 top-0 bottom-0 w-px bg-retro-border" />
        {(events as any[]).map((evt: any, i: number) => (
          <div key={i} className="flex items-start gap-4 pb-4 relative">
            <div className="relative z-10 w-10 h-10 rounded-full border border-retro-border bg-retro-card flex items-center justify-center text-base shrink-0">
              {EVENT_ICONS[evt.type] ?? '•'}
            </div>
            <div className={`flex-1 p-3 border rounded-lg ${EVENT_COLORS[evt.color] ?? EVENT_COLORS.primary}`}>
              <div className="flex items-start justify-between gap-2">
                <p className="font-mono text-sm text-primary-300">{evt.title}</p>
                <p className="font-mono text-[9px] text-primary-800 shrink-0">{new Date(evt.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</p>
              </div>
              {evt.detail && <p className="font-mono text-[10px] text-primary-700 mt-0.5">{evt.detail}</p>}
              {evt.value && <p className="font-mono text-xs text-primary-crt mt-1">{evt.value}</p>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── ETHICS / BIAS REPORT ─────────────────────────────────────

function BiasCheckCard({ check }: { check: any }) {
  const [expanded, setExpanded] = useState(false);
  const severity = check.severity;
  const colors = { high: 'border-red-800 bg-red-950/10', medium: 'border-yellow-800 bg-yellow-950/10', low: 'border-green-800 bg-green-950/10' };
  const scoreColor = check.fairnessScore >= 85 ? 'text-green-400' : check.fairnessScore >= 70 ? 'text-yellow-400' : 'text-red-400';

  return (
    <div className={`border rounded-lg p-4 ${(colors as any)[severity] ?? colors.low}`}>
      <div className="flex items-center justify-between cursor-pointer" onClick={() => setExpanded(e => !e)}>
        <div className="flex items-center gap-3">
          {severity === 'high' ? <AlertTriangle className="w-4 h-4 text-red-400" /> : severity === 'medium' ? <AlertTriangle className="w-4 h-4 text-yellow-400" /> : <CheckCircle className="w-4 h-4 text-green-400" />}
          <div>
            <p className="font-mono text-sm text-primary-300">{check.name}</p>
            <p className="font-mono text-[9px] text-primary-700 mt-0.5 capitalize">{severity} concern</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right"><p className={`font-pixel text-[16px] ${scoreColor}`}>{check.fairnessScore}</p><p className="font-mono text-[8px] text-primary-700">fairness</p></div>
          <ChevronRight className={`w-4 h-4 text-primary-700 transition-transform ${expanded ? 'rotate-90' : ''}`} />
        </div>
      </div>
      {expanded && (
        <div className="mt-3 pt-3 border-t border-retro-border/30 space-y-2">
          <p className="font-mono text-xs text-primary-500">{check.detail}</p>
          {check.recommendation && <div className="flex items-start gap-2 p-2 bg-retro-bg rounded border border-retro-border"><ChevronRight className="w-3 h-3 text-primary-crt mt-0.5 shrink-0" /><p className="font-mono text-[10px] text-primary-400">{check.recommendation}</p></div>}
        </div>
      )}
    </div>
  );
}

export function EthicsBiasReport() {
  const { data, isLoading } = useQuery({ queryKey: ['ethics-bias'], queryFn: () => api('/ethics/bias-report').then(r => r.data) });

  if (isLoading) return <div className="text-center py-10 font-mono text-xs text-primary-700 animate-pulse">Analyzing fairness metrics…</div>;

  const fairness = data?.overallFairness ?? 0;
  const fairnessColor = fairness >= 85 ? 'text-green-400' : fairness >= 70 ? 'text-yellow-400' : 'text-red-400';

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center gap-4 p-5 bg-retro-card border border-retro-border rounded-xl">
        <Shield className="w-10 h-10 text-primary-600" />
        <div className="flex-1">
          <h2 className="font-pixel text-[9px] text-primary-400">ETHICS & FAIRNESS MONITOR</h2>
          <p className="font-mono text-xs text-primary-700 mt-1">Detects pay equity gaps, promotion bias, rating inconsistency, and hiring diversity</p>
        </div>
        <div className="text-right">
          <p className={`font-pixel text-[28px] ${fairnessColor}`}>{fairness}</p>
          <p className="font-mono text-[9px] text-primary-700">overall fairness</p>
        </div>
      </div>
      <div className="space-y-3">
        {(data?.checks ?? []).map((check: any) => <BiasCheckCard key={check.id} check={check} />)}
      </div>
    </div>
  );
}

// ─── EMPLOYEE GROWTH PATH ─────────────────────────────────────

export function GrowthPathVisualizer({ employeeId }: { employeeId: string }) {
  const { data: pathways } = useQuery({ queryKey: ['skill-pathways', employeeId], queryFn: () => api(`/skills/employees/${employeeId}/pathways`).then(r => r.data) });
  const { data: succession } = useQuery({ queryKey: ['succession', employeeId], queryFn: () => api('/skills/succession').then(r => r.data ?? []) });

  const empSuccession = (succession as any[])?.find((s: any) => s.employeeId === employeeId);
  const readinessColors = { ready_now: 'text-green-400 border-green-700', ready_1yr: 'text-blue-400 border-blue-700', ready_2yr: 'text-yellow-400 border-yellow-700', not_ready: 'text-red-400 border-red-700' };

  return (
    <div className="space-y-5">
      <p className="font-pixel text-[8px] text-primary-500">CAREER GROWTH PATH</p>

      {empSuccession && (
        <div className="p-4 bg-retro-card border border-retro-border rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <p className="font-mono text-sm text-primary-300">Succession Readiness</p>
            <span className={`font-pixel text-[8px] px-2 py-1 rounded border ${(readinessColors as any)[empSuccession.readinessLevel]}`}>
              {empSuccession.readinessLevel.replace('_', ' ').toUpperCase()}
            </span>
          </div>
          <div className="h-2 bg-retro-bg border border-retro-border rounded-full overflow-hidden">
            <div className="h-full bg-primary-crt rounded-full transition-all" style={{ width: `${empSuccession.readinessScore}%` }} />
          </div>
          <p className="font-mono text-[9px] text-primary-700 mt-1">{empSuccession.readinessScore}/100 readiness score</p>
          {empSuccession.skillGaps?.length > 0 && (
            <div className="mt-3 pt-3 border-t border-retro-border/30">
              <p className="font-mono text-[10px] text-primary-700 mb-2">Skills to develop:</p>
              <div className="flex flex-wrap gap-1.5">{empSuccession.skillGaps.map((g: string) => <span key={g} className="px-2 py-1 bg-red-950/20 border border-red-900 rounded font-mono text-[9px] text-red-400">{g}</span>)}</div>
            </div>
          )}
        </div>
      )}

      {pathways && (
        <div className="p-4 bg-retro-card border border-retro-border rounded-lg">
          <p className="font-mono text-sm text-primary-300 mb-3">Suggested Learning Path</p>
          {pathways.missingCriticalSkills?.length > 0 && (
            <div className="mb-3">
              <p className="font-mono text-[10px] text-primary-700 mb-2">Critical skill gaps:</p>
              <div className="flex flex-wrap gap-1.5">{pathways.missingCriticalSkills.map((s: string) => <span key={s} className="px-2 py-1 bg-yellow-950/20 border border-yellow-900 rounded font-mono text-[9px] text-yellow-400">{s}</span>)}</div>
            </div>
          )}
          {pathways.suggestedCourses?.length > 0 && (
            <div className="space-y-2">{pathways.suggestedCourses.map((c: any) => (
              <div key={c.courseId} className="flex items-center gap-3 p-2.5 bg-retro-bg border border-retro-border rounded">
                <BookOpen className="w-3.5 h-3.5 text-primary-600 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="font-mono text-xs text-primary-400 truncate">{c.title}</p>
                  <p className="font-mono text-[9px] text-primary-700">{c.duration}h · {c.skills?.join(', ')}</p>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-primary-800 shrink-0" />
              </div>
            ))}</div>
          )}
        </div>
      )}
    </div>
  );
}
