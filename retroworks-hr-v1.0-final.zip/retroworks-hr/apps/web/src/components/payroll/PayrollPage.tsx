'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { FileText, Download, Shield, Building } from 'lucide-react';

const api = (path: string) => fetch(`/api/v1${path}`, { headers: { Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}` } }).then(r => r.json());
const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const fmt = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

export function PayrollPage() {
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const { data: payslips = [] } = useQuery<any[]>({
    queryKey: ['my-payslips'],
    queryFn: () => api('/payroll/payslips/me').then(r => r.data ?? []),
  });

  const { data: detail } = useQuery<any>({
    queryKey: ['payslip-detail', selectedId],
    queryFn: () => api(`/payroll/payslips/me/${selectedId}`).then(r => r.data),
    enabled: !!selectedId,
  });

  if (!selectedId && payslips.length) setSelectedId(payslips[0].id);

  const p = detail;

  return (
    <div className="space-y-4 animate-fade-in">
      <div>
        <h1 className="font-pixel text-[10px] text-primary-400">MY PAYSLIPS</h1>
        <p className="font-mono text-xs text-primary-700 mt-1">{payslips.length} payslip{payslips.length !== 1 ? 's' : ''} available</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Sidebar */}
        <div className="col-span-1 space-y-2">
          {payslips.length === 0 ? (
            <div className="text-center py-10"><FileText className="w-8 h-8 text-primary-800 mx-auto mb-2" /><p className="font-pixel text-[7px] text-primary-700">No payslips yet</p></div>
          ) : payslips.map((ps: any) => (
            <button key={ps.id} onClick={() => setSelectedId(ps.id)} className={`w-full text-left px-4 py-3 rounded flex items-center justify-between transition-all ${selectedId === ps.id ? 'bg-primary-950 border border-primary-700 shadow-glow' : 'bg-retro-card border border-retro-border hover:border-primary-800'}`}>
              <div>
                <p className="font-mono text-sm text-primary-300">{MONTHS[ps.month - 1]} {ps.year}</p>
                <p className="font-mono text-xs text-primary-700">Gross {fmt(ps.grossPay)}</p>
              </div>
              <div className="text-right">
                <p className="font-pixel text-[9px] text-primary-crt">{fmt(ps.netPay)}</p>
                <p className="font-mono text-[10px] text-primary-700">net pay</p>
              </div>
            </button>
          ))}
        </div>

        {/* Detail */}
        <div className="col-span-2">
          {p ? (
            <div className="space-y-3">
              <div className="flex justify-end">
                <button onClick={() => window.print()} className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border font-pixel text-[7px] text-primary-600 hover:text-primary-400 rounded">
                  <Download className="w-3 h-3" /> Download PDF
                </button>
              </div>
              <div className="bg-retro-card border border-retro-border rounded-lg overflow-hidden">
                {/* Header */}
                <div className="bg-retro-bg border-b border-retro-border px-6 py-4 flex items-start justify-between">
                  <div>
                    <p className="font-pixel text-[8px] text-primary-700 mb-1">RETROWORKS HR</p>
                    <h2 className="font-pixel text-[10px] text-primary-crt">PAYSLIP — {MONTHS[p.month - 1]?.toUpperCase()} {p.year}</h2>
                  </div>
                  <div className="text-right">
                    <p className="font-mono text-sm text-primary-300 font-medium">{p.employee?.firstName} {p.employee?.lastName}</p>
                    <p className="font-mono text-xs text-primary-600">{p.employee?.employeeCode}</p>
                    <p className="font-mono text-xs text-primary-700">{p.employee?.designation?.name} · {p.employee?.department?.name}</p>
                  </div>
                </div>
                <div className="p-6 space-y-5">
                  {/* Net Pay hero */}
                  <div className="bg-primary-950/50 border border-primary-900 rounded-lg p-4 text-center">
                    <p className="font-pixel text-[8px] text-primary-700 mb-1">NET PAY</p>
                    <p className="font-pixel text-3xl text-primary-crt">{fmt(p.netPay)}</p>
                    <p className="font-mono text-xs text-primary-700 mt-1">Gross {fmt(p.grossPay)} — Deductions {fmt(p.totalDeductions)}</p>
                  </div>
                  {/* Earnings + Deductions */}
                  <div className="grid grid-cols-2 gap-6">
                    <div>
                      <p className="font-pixel text-[7px] text-primary-700 mb-2">EARNINGS</p>
                      <div className="space-y-1.5">
                        {[['Basic Pay', p.basicPay], ['HRA', p.hra], ['Special Allowance', p.specialAllowance], ...(p.lta > 0 ? [['LTA', p.lta]] : []), ...(p.medicalAllowance > 0 ? [['Medical', p.medicalAllowance]] : []), ...(p.bonus > 0 ? [['Bonus', p.bonus]] : [])].map(([l, a]) => (
                          <div key={l as string} className="flex justify-between font-mono text-xs">
                            <span className="text-primary-500">{l}</span>
                            <span className="text-primary-300">{fmt(a as number)}</span>
                          </div>
                        ))}
                        {p.lopDays > 0 && <div className="flex justify-between font-mono text-xs border-t border-retro-border/50 pt-1"><span className="text-red-400">LOP ({p.lopDays}d)</span><span className="text-red-400">-{fmt(p.lopDeduction)}</span></div>}
                        <div className="flex justify-between font-mono text-xs border-t border-retro-border pt-1.5 font-medium"><span className="text-primary-400">Gross</span><span className="text-primary-crt">{fmt(p.grossPay)}</span></div>
                      </div>
                    </div>
                    <div>
                      <p className="font-pixel text-[7px] text-primary-700 mb-2">DEDUCTIONS</p>
                      <div className="space-y-1.5">
                        {[[p.pfEmployee > 0, 'Provident Fund', p.pfEmployee], [p.esiEmployee > 0, 'ESI', p.esiEmployee], [p.professionalTax > 0, 'Professional Tax', p.professionalTax], [p.tdsDeducted > 0, `TDS (${(p.taxRegime ?? 'new').toUpperCase()})`, p.tdsDeducted]].filter(([show]) => show).map(([_, l, a]) => (
                          <div key={l as string} className="flex justify-between font-mono text-xs">
                            <span className="flex items-center gap-1 text-primary-500"><Shield className="w-2.5 h-2.5 text-primary-700" />{l}</span>
                            <span className="text-red-400">{fmt(a as number)}</span>
                          </div>
                        ))}
                        <div className="flex justify-between font-mono text-xs border-t border-retro-border pt-1.5 font-medium"><span className="text-primary-400">Total</span><span className="text-red-400">{fmt(p.totalDeductions)}</span></div>
                      </div>
                    </div>
                  </div>
                  {/* CTC + Tax */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-retro-bg border border-retro-border rounded p-3">
                      <p className="font-pixel text-[7px] text-primary-700 mb-2">EMPLOYER CONTRIBUTIONS</p>
                      <div className="space-y-1 font-mono text-xs">
                        {p.pfEmployer > 0 && <div className="flex justify-between"><span className="text-primary-600">EPF</span><span className="text-primary-500">{fmt(p.pfEmployer)}</span></div>}
                        {p.pfEps > 0 && <div className="flex justify-between"><span className="text-primary-600">EPS</span><span className="text-primary-500">{fmt(p.pfEps)}</span></div>}
                        {p.esiEmployer > 0 && <div className="flex justify-between"><span className="text-primary-600">ESI</span><span className="text-primary-500">{fmt(p.esiEmployer)}</span></div>}
                        <div className="flex justify-between border-t border-retro-border/50 pt-1 font-medium"><span className="text-primary-400">Monthly CTC</span><span className="text-primary-300">{fmt(p.ctcMonthly)}</span></div>
                      </div>
                    </div>
                    <div className="bg-retro-bg border border-retro-border rounded p-3">
                      <p className="font-pixel text-[7px] text-primary-700 mb-2">TAX SUMMARY</p>
                      <div className="space-y-1 font-mono text-xs">
                        <div className="flex justify-between"><span className="text-primary-600">Taxable Income</span><span className="text-primary-500">{fmt(p.taxableIncome)}</span></div>
                        <div className="flex justify-between"><span className="text-primary-600">Regime</span><span className="text-primary-400 uppercase">{p.taxRegime}</span></div>
                        <div className="flex justify-between border-t border-retro-border/50 pt-1"><span className="text-primary-500">Effective Rate</span><span className="text-primary-400">{p.effectiveTaxRate}%</span></div>
                      </div>
                    </div>
                  </div>
                  {p.employee?.bankAccountNumber && (
                    <div className="flex items-center gap-2 font-mono text-xs text-primary-700 border-t border-retro-border/50 pt-3">
                      <Building className="w-3 h-3" />
                      <span>Credited to ••••{p.employee.bankAccountNumber.slice(-4)}</span>
                      {p.employee.ifscCode && <span className="text-primary-800">· {p.employee.ifscCode}</span>}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 bg-retro-card border border-retro-border rounded">
              <p className="font-pixel text-[8px] text-primary-700">Select a payslip to view</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
