'use client';
import { useState, useCallback, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Code2, CheckCircle, AlertTriangle, AlertCircle, ChevronDown,
  ChevronRight, RotateCcw, Play, Save, History, Info,
  Zap, GitBranch, Shield,
} from 'lucide-react';

const token = () =>
  typeof localStorage !== 'undefined' ? (localStorage.getItem('token') ?? '') : '';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: {
      Authorization: `Bearer ${token()}`,
      'Content-Type': 'application/json',
      ...(opts?.headers ?? {}),
    },
  }).then(r => r.json());

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

// ── Syntax highlighter (lightweight, no external dep) ─────────────────────────

function highlightFormula(formula: string): string {
  return formula
    .replace(/\b(IF|MIN|MAX|ROUND|FLOOR|CEIL|ABS)\b/g, '<span class="text-amber-400 font-bold">$1</span>')
    .replace(/\b(AND|OR|NOT)\b/g, '<span class="text-purple-400 font-bold">$1</span>')
    .replace(/\b(BASIC|GROSS|CTC|WORKING_DAYS|LOP_DAYS|ATTENDANCE_DAYS|YEARS_OF_SERVICE)\b/g,
      '<span class="text-blue-400">$1</span>')
    .replace(/\b(workerCategory|legalEntity)\b/g, '<span class="text-cyan-400">$1</span>')
    .replace(/([0-9]+\.?[0-9]*)/g, '<span class="text-green-300">$1</span>')
    .replace(/(==|!=|>=|<=|>|<)/g, '<span class="text-primary-500">$1</span>');
}

// ── Validation issue row ──────────────────────────────────────────────────────

function IssueRow({ issue }: { issue: any }) {
  const isErr = issue.severity === 'ERROR';
  return (
    <div className={`flex items-start gap-2 px-3 py-2 rounded text-[10px] font-mono ${
      isErr ? 'bg-red-950/30 text-red-400' : 'bg-amber-950/20 text-amber-400'
    }`}>
      {isErr
        ? <AlertCircle className="w-3 h-3 flex-shrink-0 mt-0.5" />
        : <AlertTriangle className="w-3 h-3 flex-shrink-0 mt-0.5" />
      }
      <div>
        <span className="font-pixel text-[7px] mr-2">{issue.code}</span>
        {issue.message}
        {issue.pos !== undefined && (
          <span className="text-primary-700 ml-2">at pos {issue.pos}</span>
        )}
      </div>
    </div>
  );
}

// ── Version history item ──────────────────────────────────────────────────────

function VersionItem({
  v, onRollback, isLatest,
}: { v: any; onRollback: (version: number) => void; isLatest: boolean }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div className="border border-retro-border rounded mb-2">
      <button
        onClick={() => setExpanded(!expanded)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-primary-950/20"
      >
        <span className="font-pixel text-[7px] text-primary-700 w-8">v{v.version}</span>
        <span className="font-mono text-[10px] text-primary-500 flex-1 truncate">{v.formula}</span>
        <span className="font-mono text-[9px] text-primary-800">
          {new Date(v.createdAt).toLocaleDateString('en-IN')}
        </span>
        {isLatest
          ? <span className="font-pixel text-[6px] text-green-400 border border-green-800 px-1.5 py-0.5 rounded">CURRENT</span>
          : <button
              onClick={e => { e.stopPropagation(); onRollback(v.version); }}
              className="font-pixel text-[6px] text-amber-400 border border-amber-800 px-1.5 py-0.5 rounded hover:bg-amber-950/30 flex items-center gap-1"
            >
              <RotateCcw className="w-2 h-2" /> ROLLBACK
            </button>
        }
        {expanded ? <ChevronDown className="w-3 h-3 text-primary-800" /> : <ChevronRight className="w-3 h-3 text-primary-800" />}
      </button>
      {expanded && (
        <div className="px-4 pb-3 border-t border-retro-border/30 pt-2 space-y-1">
          <div className="font-mono text-[10px] text-primary-400 bg-retro-bg p-2 rounded">
            {v.formula}
          </div>
          {v.changedBy && (
            <div className="font-mono text-[9px] text-primary-700">
              Changed by: {v.changedBy} {v.changeNote ? `— ${v.changeNote}` : ''}
            </div>
          )}
          <div className="font-mono text-[9px] text-primary-800">Hash: {v.formulaHash}</div>
        </div>
      )}
    </div>
  );
}

// ── Sandbox test panel ────────────────────────────────────────────────────────

function SandboxPanel({ formula }: { formula: string }) {
  const [inputs, setInputs] = useState({
    BASIC: 25000, GROSS: 0, WORKING_DAYS: 26, LOP_DAYS: 0,
    YEARS_OF_SERVICE: 3, applyPF: true,
  });
  const [result, setResult] = useState<number | null>(null);
  const [sandboxErr, setSandboxErr] = useState('');

  const runSandbox = useCallback(() => {
    try {
      // Client-side evaluation using the same engine logic via API
      api('/payroll/components/validate', {
        method: 'POST',
        body: JSON.stringify({ formula, componentCode: '__SANDBOX__' }),
      }).then(r => {
        if (r.valid) {
          // Call a sandbox eval endpoint
          setSandboxErr('');
          setResult(null); // actual evaluation needs backend
        } else {
          setSandboxErr(r.issues?.[0]?.message ?? 'Invalid formula');
        }
      });
    } catch (e: any) {
      setSandboxErr(e.message);
    }
  }, [formula, inputs]);

  const DSL_SAMPLE_RESULTS: Record<string, (i: typeof inputs) => number> = {
    'BASIC * 0.4': i => i.BASIC * 0.4,
    'MIN(BASIC, 15000) * 0.12': i => Math.min(i.BASIC, 15000) * 0.12,
    'BASIC / WORKING_DAYS * LOP_DAYS': i => i.BASIC / i.WORKING_DAYS * i.LOP_DAYS,
  };

  // Quick local approximation for demo
  const approxResult = DSL_SAMPLE_RESULTS[formula]?.(inputs);

  return (
    <div className="space-y-3">
      <div className="font-pixel text-[7px] text-primary-700 mb-2">TEST SANDBOX — adjust inputs</div>
      <div className="grid grid-cols-3 gap-2">
        {Object.entries(inputs).map(([key, val]) => (
          typeof val === 'number' && (
            <div key={key}>
              <label className="font-pixel text-[6px] text-primary-800 block mb-0.5">{key}</label>
              <input
                type="number"
                value={val}
                onChange={e => setInputs(prev => ({ ...prev, [key]: parseFloat(e.target.value) || 0 }))}
                className="w-full bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none"
              />
            </div>
          )
        ))}
      </div>
      {approxResult !== undefined && (
        <div className="flex items-center gap-3">
          <Zap className="w-4 h-4 text-amber-500" />
          <div>
            <span className="font-pixel text-[7px] text-primary-700">ESTIMATED RESULT: </span>
            <span className="font-pixel text-[10px] text-primary-crt">{fmt(approxResult)}</span>
          </div>
        </div>
      )}
      {sandboxErr && <div className="font-mono text-[10px] text-red-400">{sandboxErr}</div>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN EXPRESSION EDITOR PAGE
// ─────────────────────────────────────────────────────────────────────────────

export function ExpressionEditorPage() {
  const qc = useQueryClient();
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [formula, setFormula] = useState('');
  const [changeNote, setChangeNote] = useState('');
  const [activeTab, setActiveTab] = useState<'editor' | 'sandbox' | 'history'>('editor');
  const [validation, setValidation] = useState<any>(null);
  const [isValidating, setIsValidating] = useState(false);
  const validateTimer = useRef<ReturnType<typeof setTimeout>>();

  // Load all components
  const { data: components = [], isLoading } = useQuery({
    queryKey: ['pay-components'],
    queryFn: () => api('/payroll/components').then(r => r.data ?? r),
  });

  // Load version history for selected component
  const { data: versions = [] } = useQuery({
    queryKey: ['component-versions', selectedId],
    queryFn: () => api(`/payroll/components/${selectedId}/versions`).then(r => r.data ?? r),
    enabled: !!selectedId && activeTab === 'history',
  });

  const selected = (components as any[]).find((c: any) => c.id === selectedId);

  // Auto-validate on formula change
  useEffect(() => {
    if (!formula || !selected) { setValidation(null); return; }
    clearTimeout(validateTimer.current);
    setIsValidating(true);
    validateTimer.current = setTimeout(() => {
      api('/payroll/components/validate', {
        method: 'POST',
        body: JSON.stringify({ formula, componentCode: selected.code }),
      }).then(r => {
        setValidation(r.data ?? r);
        setIsValidating(false);
      }).catch(() => setIsValidating(false));
    }, 400);
    return () => clearTimeout(validateTimer.current);
  }, [formula, selected?.code]);

  // Select component
  const selectComponent = (comp: any) => {
    setSelectedId(comp.id);
    setFormula(comp.formula ?? '');
    setValidation(null);
    setActiveTab('editor');
  };

  const saveFormula = useMutation({
    mutationFn: () => api(`/payroll/components/${selectedId}/formula`, {
      method: 'PUT',
      body: JSON.stringify({ formula, changeNote }),
    }).then(r => r.data ?? r),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['pay-components'] });
      qc.invalidateQueries({ queryKey: ['component-versions', selectedId] });
      setChangeNote('');
    },
  });

  const rollback = useMutation({
    mutationFn: (targetVersion: number) =>
      api(`/payroll/components/${selectedId}/rollback`, {
        method: 'POST',
        body: JSON.stringify({ targetVersion }),
      }).then(r => r.data ?? r),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['pay-components'] });
      qc.invalidateQueries({ queryKey: ['component-versions', selectedId] });
      // Refresh formula to rolled-back version
    },
  });

  const hasErrors = validation?.issues?.some((i: any) => i.severity === 'ERROR');
  const hasWarnings = validation?.issues?.some((i: any) => i.severity === 'WARNING');
  const isFormulaType = selected?.type === 'FORMULA';
  const formulaChanged = selected && formula !== (selected.formula ?? '');

  const COMPONENT_TYPE_BADGE: Record<string, string> = {
    FIXED:      'text-blue-400 border-blue-800',
    FORMULA:    'text-amber-400 border-amber-800',
    STATUTORY:  'text-purple-400 border-purple-800',
  };

  return (
    <div className="flex h-full gap-4 animate-fade-in" style={{ minHeight: '600px' }}>
      {/* Left: Component list */}
      <div className="w-72 flex-shrink-0 space-y-2">
        <div className="font-pixel text-[8px] text-primary-600 mb-3">PAY COMPONENTS</div>

        {isLoading ? (
          <div className="font-mono text-xs text-primary-700 animate-pulse">Loading...</div>
        ) : (components as any[]).length === 0 ? (
          <div className="font-mono text-xs text-primary-700">No components configured.</div>
        ) : (
          (components as any[]).map((comp: any) => (
            <button
              key={comp.id}
              onClick={() => selectComponent(comp)}
              className={`w-full text-left px-3 py-2.5 rounded border transition-all ${
                selectedId === comp.id
                  ? 'bg-primary-950 border-primary-700 shadow-glow'
                  : 'bg-retro-card border-retro-border hover:border-primary-800'
              }`}
            >
              <div className="flex items-center justify-between mb-0.5">
                <span className="font-mono text-xs text-primary-400">{comp.code}</span>
                <span className={`font-pixel text-[6px] border px-1 py-0.5 rounded ${COMPONENT_TYPE_BADGE[comp.type] ?? ''}`}>
                  {comp.type}
                </span>
              </div>
              <div className="font-mono text-[10px] text-primary-700">{comp.name}</div>
              {comp.formula && (
                <div className="font-mono text-[9px] text-primary-800 mt-0.5 truncate">{comp.formula}</div>
              )}
              <div className="flex items-center gap-2 mt-1">
                <span className="font-pixel text-[6px] text-primary-800">v{comp.version}</span>
                {comp.isTaxable && <span className="font-pixel text-[6px] text-green-800">TAXABLE</span>}
                {comp.isDeduction && <span className="font-pixel text-[6px] text-red-800">DEDUCTION</span>}
              </div>
            </button>
          ))
        )}
      </div>

      {/* Right: Editor panel */}
      {!selected ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-3">
            <Code2 className="w-12 h-12 text-primary-800 mx-auto" />
            <div className="font-pixel text-[8px] text-primary-700">SELECT A COMPONENT TO EDIT</div>
            <div className="font-mono text-xs text-primary-800">
              Choose a FORMULA component from the left to edit its expression.
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 space-y-3">
          {/* Component header */}
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3">
                <span className="font-pixel text-[10px] text-primary-400">{selected.code}</span>
                <span className={`font-pixel text-[7px] border px-2 py-0.5 rounded ${COMPONENT_TYPE_BADGE[selected.type] ?? ''}`}>
                  {selected.type}
                </span>
                <span className="font-pixel text-[7px] text-primary-700">v{selected.version}</span>
              </div>
              <div className="font-mono text-xs text-primary-700 mt-0.5">{selected.name}</div>
            </div>

            {isFormulaType && formulaChanged && (
              <div className="flex items-center gap-2">
                <input
                  value={changeNote}
                  onChange={e => setChangeNote(e.target.value)}
                  placeholder="Change note (optional)"
                  className="bg-retro-bg border border-retro-border rounded px-3 py-1.5 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none w-48"
                />
                <button
                  onClick={() => saveFormula.mutate()}
                  disabled={hasErrors || saveFormula.isPending || !validation?.valid}
                  className="flex items-center gap-1.5 px-4 py-1.5 bg-primary-900 border border-primary-700 font-pixel text-[7px] text-primary-crt rounded hover:bg-primary-800 disabled:opacity-40"
                >
                  <Save className="w-3 h-3" />
                  {saveFormula.isPending ? 'SAVING...' : 'SAVE FORMULA'}
                </button>
              </div>
            )}
          </div>

          {/* Tabs */}
          <div className="flex gap-1 border-b border-retro-border">
            {[
              { key: 'editor', label: 'FORMULA EDITOR', icon: Code2 },
              { key: 'sandbox', label: 'SANDBOX', icon: Play },
              { key: 'history', label: 'VERSION HISTORY', icon: History },
            ].map(({ key, label, icon: Icon }) => (
              <button
                key={key}
                onClick={() => setActiveTab(key as any)}
                className={`flex items-center gap-1.5 px-4 py-2 font-pixel text-[7px] border-b-2 transition-colors ${
                  activeTab === key
                    ? 'border-primary-crt text-primary-crt'
                    : 'border-transparent text-primary-700 hover:text-primary-500'
                }`}
              >
                <Icon className="w-3 h-3" />
                {label}
              </button>
            ))}
          </div>

          {/* ── EDITOR TAB ──────────────────────────────────────────────── */}
          {activeTab === 'editor' && (
            <div className="space-y-3">
              {/* Formula input area */}
              <div className="relative">
                <div className="font-pixel text-[7px] text-primary-700 mb-1.5">
                  FORMULA {isValidating && '(validating...)'}
                </div>

                {isFormulaType ? (
                  <div className="relative">
                    <textarea
                      value={formula}
                      onChange={e => setFormula(e.target.value)}
                      spellCheck={false}
                      className="w-full h-28 bg-retro-bg border border-retro-border rounded px-4 py-3 font-mono text-sm text-primary-300 focus:border-primary-crt outline-none resize-none"
                      placeholder="e.g. MIN(BASIC * 0.5, 10000)"
                    />
                    {/* Syntax preview */}
                    {formula && (
                      <div
                        className="mt-1 px-3 py-2 bg-retro-bg/50 border border-retro-border/30 rounded font-mono text-sm leading-relaxed pointer-events-none"
                        dangerouslySetInnerHTML={{ __html: highlightFormula(formula) }}
                      />
                    )}
                  </div>
                ) : (
                  <div className="bg-retro-bg border border-retro-border/30 rounded px-4 py-3 font-mono text-sm text-primary-700 italic">
                    {selected.type === 'FIXED'
                      ? 'Fixed component — value set per employee in salary structure'
                      : 'Statutory component — computed by statutory engine'
                    }
                  </div>
                )}
              </div>

              {/* Validation result */}
              {validation && isFormulaType && (
                <div className="space-y-2">
                  <div className={`flex items-center gap-2 px-3 py-2 rounded border ${
                    validation.valid
                      ? 'border-green-800 bg-green-950/20'
                      : 'border-red-800 bg-red-950/20'
                  }`}>
                    {validation.valid
                      ? <CheckCircle className="w-4 h-4 text-green-400" />
                      : <AlertCircle className="w-4 h-4 text-red-400" />
                    }
                    <span className={`font-pixel text-[8px] ${validation.valid ? 'text-green-400' : 'text-red-400'}`}>
                      {validation.valid ? 'FORMULA VALID' : 'FORMULA INVALID'}
                    </span>
                    {validation.valid && (
                      <span className="font-mono text-[10px] text-primary-700 ml-2">
                        depends on: {validation.dependencies?.join(', ') || 'none'}
                        {validation.systemVars?.length > 0 && ` · uses: ${validation.systemVars.join(', ')}`}
                      </span>
                    )}
                  </div>

                  {validation.issues?.map((issue: any, i: number) => (
                    <IssueRow key={i} issue={issue} />
                  ))}
                </div>
              )}

              {/* Reference guide */}
              <details className="group">
                <summary className="cursor-pointer flex items-center gap-2 font-pixel text-[7px] text-primary-800 hover:text-primary-600">
                  <Info className="w-3 h-3" /> DSL REFERENCE
                </summary>
                <div className="mt-2 grid grid-cols-2 gap-3 font-mono text-[9px] text-primary-700 bg-retro-bg border border-retro-border rounded p-3">
                  <div>
                    <div className="font-pixel text-[6px] text-primary-600 mb-1">SYSTEM VARIABLES</div>
                    {['BASIC', 'GROSS', 'CTC', 'WORKING_DAYS', 'LOP_DAYS', 'ATTENDANCE_DAYS', 'YEARS_OF_SERVICE'].map(v => (
                      <div key={v} className="text-blue-400">{v}</div>
                    ))}
                  </div>
                  <div>
                    <div className="font-pixel text-[6px] text-primary-600 mb-1">FUNCTIONS</div>
                    {[
                      'IF(cond, then, else)',
                      'MIN(a, b)',
                      'MAX(a, b)',
                      'ROUND(val, precision)',
                      'FLOOR(val)',
                      'CEIL(val)',
                      'ABS(val)',
                    ].map(f => (
                      <div key={f} className="text-amber-400">{f}</div>
                    ))}
                  </div>
                  <div>
                    <div className="font-pixel text-[6px] text-primary-600 mb-1">CONTEXT</div>
                    <div className="text-cyan-400">workerCategory.applyPF</div>
                    <div className="text-cyan-400">workerCategory.applyESI</div>
                    <div className="text-cyan-400">workerCategory.isPayrollEligible</div>
                    <div className="text-cyan-400">legalEntity.state</div>
                  </div>
                  <div>
                    <div className="font-pixel text-[6px] text-primary-600 mb-1">OPERATORS</div>
                    <div>+ - * / % (arithmetic)</div>
                    <div>{'> < >= <= == !='} (compare)</div>
                    <div>AND OR NOT (logical)</div>
                  </div>
                </div>
              </details>
            </div>
          )}

          {/* ── SANDBOX TAB ─────────────────────────────────────────────── */}
          {activeTab === 'sandbox' && (
            <div className="bg-retro-card border border-retro-border rounded p-4">
              {isFormulaType && formula ? (
                <SandboxPanel formula={formula} />
              ) : (
                <div className="font-mono text-xs text-primary-700 text-center py-8">
                  {isFormulaType ? 'Enter a formula in the Editor tab first' : 'Sandbox only available for FORMULA components'}
                </div>
              )}
            </div>
          )}

          {/* ── VERSION HISTORY TAB ─────────────────────────────────────── */}
          {activeTab === 'history' && (
            <div>
              {(versions as any[]).length === 0 ? (
                <div className="font-mono text-xs text-primary-700 text-center py-8">
                  No version history yet. Save a formula to create the first version.
                </div>
              ) : (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <GitBranch className="w-4 h-4 text-primary-700" />
                    <span className="font-pixel text-[7px] text-primary-600">
                      {(versions as any[]).length} version{(versions as any[]).length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  {(versions as any[]).map((v: any, i: number) => (
                    <VersionItem
                      key={v.id}
                      v={v}
                      isLatest={i === 0}
                      onRollback={(targetVersion) => rollback.mutate(targetVersion)}
                    />
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Save success feedback */}
          {saveFormula.isSuccess && (
            <div className="flex items-center gap-2 px-3 py-2 bg-green-950/20 border border-green-800 rounded">
              <CheckCircle className="w-4 h-4 text-green-400" />
              <span className="font-pixel text-[7px] text-green-400">
                FORMULA SAVED — v{saveFormula.data?.version} · hash {saveFormula.data?.hash}
              </span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
