'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Puzzle, Key, Globe, Plus, Trash2, Copy, ToggleLeft, ToggleRight,
  CheckCircle, Settings, AlertTriangle, Eye, EyeOff, Zap,
  Code, Shield, ChevronDown, ChevronRight,
} from 'lucide-react';

const api = async (path: string, opts?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, { ...opts, headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`, ...opts?.headers } });
  return res.json();
};

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  Payroll: <span className="text-green-400">₹</span>,
  Compliance: <Shield className="w-4 h-4 text-blue-400" />,
  Attendance: <span className="text-yellow-400">⏰</span>,
  Benefits: <span className="text-purple-400">✨</span>,
  Integration: <Zap className="w-4 h-4 text-orange-400" />,
};

const WEBHOOK_EVENTS = ['employee.created', 'employee.updated', 'leave.approved', 'leave.rejected', 'payroll.processed', 'review.completed', 'expense.approved', 'onboarding.completed'];

// ─── Plugin Card ──────────────────────────────────────────────────

function PluginCard({ plugin, onToggle, onConfigure }: { plugin: any; onToggle: () => void; onConfigure: () => void }) {
  return (
    <div className={`bg-retro-card border rounded-lg p-5 transition-all ${plugin.enabled ? 'border-primary-800' : 'border-retro-border'}`}>
      <div className="flex items-start justify-between gap-3 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-retro-bg border border-retro-border flex items-center justify-center">
            {CATEGORY_ICONS[plugin.category] ?? <Puzzle className="w-4 h-4 text-primary-600" />}
          </div>
          <div>
            <p className="font-mono text-sm text-primary-300 font-medium">{plugin.name}</p>
            <p className="font-mono text-[9px] text-primary-800">v{plugin.version} · {plugin.category}</p>
          </div>
        </div>
        <button onClick={onToggle}>
          {plugin.enabled ? <ToggleRight className="w-6 h-6 text-primary-crt" /> : <ToggleLeft className="w-6 h-6 text-primary-700" />}
        </button>
      </div>

      <p className="font-mono text-xs text-primary-600 mb-4">{plugin.description}</p>

      <div className="flex items-center justify-between">
        {plugin.enabled ? (
          <span className="flex items-center gap-1.5 font-mono text-[9px] text-green-400"><span className="w-1.5 h-1.5 rounded-full bg-green-400" />Active</span>
        ) : (
          <span className="font-mono text-[9px] text-primary-800">Inactive</span>
        )}
        {plugin.enabled && plugin.configSchema?.length > 0 && (
          <button onClick={onConfigure} className="flex items-center gap-1 font-mono text-[9px] text-primary-600 hover:text-primary-400">
            <Settings className="w-3 h-3" /> Configure
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Config Modal ──────────────────────────────────────────────────

function ConfigModal({ plugin, onSave, onClose }: { plugin: any; onSave: (config: Record<string, string>) => void; onClose: () => void }) {
  const [config, setConfig] = useState<Record<string, string>>(plugin.config ?? {});
  const [showSecrets, setShowSecrets] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative bg-retro-card border border-primary-800 rounded-xl p-6 w-full max-w-md space-y-4">
        <h3 className="font-pixel text-[9px] text-primary-crt">CONFIGURE: {plugin.name.toUpperCase()}</h3>
        {plugin.configSchema.map((field: any) => (
          <div key={field.key}>
            <label className="block font-pixel text-[7px] text-primary-600 mb-1.5">{field.label.toUpperCase()}</label>
            {field.type === 'select' ? (
              <select value={config[field.key] ?? field.defaultValue ?? ''} onChange={e => setConfig(c => ({ ...c, [field.key]: e.target.value }))} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none">
                {field.options.map((o: string) => <option key={o} value={o}>{o}</option>)}
              </select>
            ) : (
              <div className="relative">
                <input type={field.type === 'secret' && !showSecrets ? 'password' : 'text'} value={config[field.key] ?? field.defaultValue ?? ''} onChange={e => setConfig(c => ({ ...c, [field.key]: e.target.value }))} className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none" />
                {field.type === 'secret' && <button onClick={() => setShowSecrets(s => !s)} className="absolute right-2 top-1/2 -translate-y-1/2 text-primary-700">{showSecrets ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}</button>}
              </div>
            )}
          </div>
        ))}
        <div className="flex items-center gap-3 pt-2">
          <button onClick={() => onSave(config)} className="flex-1 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:border-primary-500">Save Config</button>
          <button onClick={onClose} className="flex-1 py-2 border border-retro-border rounded font-mono text-xs text-primary-600 hover:text-primary-400">Cancel</button>
        </div>
      </div>
    </div>
  );
}

// ─── API Keys Tab ──────────────────────────────────────────────────

function ApiKeysTab() {
  const [newKeyName, setNewKeyName] = useState('');
  const [newKeyScopes, setNewKeyScopes] = useState<string[]>(['read']);
  const [expiresInDays, setExpiresInDays] = useState('');
  const [newKey, setNewKey] = useState<string | null>(null);
  const qc = useQueryClient();

  const SCOPES = ['read', 'write', 'admin', 'payroll:read', 'payroll:write', 'employees:read', 'employees:write', 'reports:read'];

  const { data: keys = [] } = useQuery({ queryKey: ['api-keys'], queryFn: () => api('/plugins/api-keys').then(r => r.data ?? []) });
  const createMut = useMutation({ mutationFn: (dto: any) => api('/plugins/api-keys', { method: 'POST', body: JSON.stringify(dto) }), onSuccess: (res) => { qc.invalidateQueries({ queryKey: ['api-keys'] }); if (res.data?.key) setNewKey(res.data.key); setNewKeyName(''); } });
  const revokeMut = useMutation({ mutationFn: (id: string) => api(`/plugins/api-keys/${id}`, { method: 'DELETE' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['api-keys'] }) });

  return (
    <div className="space-y-5">
      {/* New key shown once */}
      {newKey && (
        <div className="p-4 bg-yellow-950/30 border border-yellow-800 rounded-lg space-y-2">
          <div className="flex items-center gap-2"><AlertTriangle className="w-4 h-4 text-yellow-400" /><p className="font-pixel text-[8px] text-yellow-400">COPY THIS KEY NOW — IT WON'T BE SHOWN AGAIN</p></div>
          <div className="flex items-center gap-2">
            <code className="flex-1 px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 break-all">{newKey}</code>
            <button onClick={() => navigator.clipboard.writeText(newKey)} className="p-2 text-primary-600 hover:text-primary-400"><Copy className="w-4 h-4" /></button>
          </div>
          <button onClick={() => setNewKey(null)} className="font-mono text-xs text-primary-700 hover:text-primary-500">I've saved it ✓</button>
        </div>
      )}

      {/* Create form */}
      <div className="p-4 bg-retro-card border border-retro-border rounded-lg space-y-3">
        <p className="font-pixel text-[8px] text-primary-600">CREATE NEW API KEY</p>
        <div className="grid grid-cols-3 gap-3">
          <div className="col-span-2"><label className="block font-pixel text-[7px] text-primary-700 mb-1">KEY NAME</label><input value={newKeyName} onChange={e => setNewKeyName(e.target.value)} placeholder="My Integration Key" className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none" /></div>
          <div><label className="block font-pixel text-[7px] text-primary-700 mb-1">EXPIRES IN (DAYS)</label><input type="number" value={expiresInDays} onChange={e => setExpiresInDays(e.target.value)} placeholder="90" className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none" /></div>
        </div>
        <div><label className="block font-pixel text-[7px] text-primary-700 mb-2">SCOPES</label>
          <div className="flex flex-wrap gap-2">{SCOPES.map(s => <button key={s} onClick={() => setNewKeyScopes(sc => sc.includes(s) ? sc.filter(x => x !== s) : [...sc, s])} className={`px-2 py-1 rounded border font-mono text-[9px] transition-all ${newKeyScopes.includes(s) ? 'bg-primary-950 border-primary-700 text-primary-300' : 'bg-retro-bg border-retro-border text-primary-700'}`}>{s}</button>)}</div>
        </div>
        <button onClick={() => createMut.mutate({ name: newKeyName, scopes: newKeyScopes, expiresInDays: expiresInDays ? +expiresInDays : undefined })} disabled={!newKeyName || createMut.isPending} className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 disabled:opacity-40">
          <Key className="w-3.5 h-3.5" /> {createMut.isPending ? 'Creating…' : 'Create Key'}
        </button>
      </div>

      {/* Key list */}
      <div className="space-y-2">
        {(keys as any[]).map((k: any) => (
          <div key={k.id} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg">
            <Key className="w-4 h-4 text-primary-600 shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2"><p className="font-mono text-sm text-primary-300">{k.name}</p><code className="font-mono text-[9px] text-primary-700 bg-retro-bg border border-retro-border rounded px-1.5">{k.prefix}…</code></div>
              <div className="flex items-center gap-3 mt-0.5 font-mono text-[9px] text-primary-700">
                <span>Scopes: {(k.scopes ?? []).join(', ')}</span>
                {k.expiresAt && <span>Expires: {new Date(k.expiresAt).toLocaleDateString('en-IN')}</span>}
                {k.lastUsedAt && <span>Last used: {new Date(k.lastUsedAt).toLocaleDateString('en-IN')}</span>}
              </div>
            </div>
            <button onClick={() => { if (confirm('Revoke this API key?')) revokeMut.mutate(k.id); }} className="text-primary-800 hover:text-red-400 transition-colors"><Trash2 className="w-3.5 h-3.5" /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Webhooks Tab ──────────────────────────────────────────────────

function WebhooksTab() {
  const [url, setUrl] = useState('');
  const [name, setName] = useState('');
  const [events, setEvents] = useState<string[]>([]);
  const qc = useQueryClient();

  const { data: webhooks = [] } = useQuery({ queryKey: ['webhooks'], queryFn: () => api('/plugins/webhooks').then(r => r.data ?? []) });
  const createMut = useMutation({ mutationFn: (dto: any) => api('/plugins/webhooks', { method: 'POST', body: JSON.stringify(dto) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['webhooks'] }); setUrl(''); setName(''); setEvents([]); } });
  const deleteMut = useMutation({ mutationFn: (id: string) => api(`/plugins/webhooks/${id}`, { method: 'DELETE' }), onSuccess: () => qc.invalidateQueries({ queryKey: ['webhooks'] }) });

  return (
    <div className="space-y-5">
      <div className="p-4 bg-retro-card border border-retro-border rounded-lg space-y-3">
        <p className="font-pixel text-[8px] text-primary-600">REGISTER WEBHOOK ENDPOINT</p>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="block font-pixel text-[7px] text-primary-700 mb-1">NAME</label><input value={name} onChange={e => setName(e.target.value)} placeholder="My Webhook" className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none" /></div>
          <div><label className="block font-pixel text-[7px] text-primary-700 mb-1">URL *</label><input value={url} onChange={e => setUrl(e.target.value)} placeholder="https://myapp.com/webhook" className="w-full px-2.5 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 focus:border-primary-600 focus:outline-none" /></div>
        </div>
        <div><label className="block font-pixel text-[7px] text-primary-700 mb-2">EVENTS TO SUBSCRIBE</label>
          <div className="flex flex-wrap gap-2">{WEBHOOK_EVENTS.map(e => <button key={e} onClick={() => setEvents(ev => ev.includes(e) ? ev.filter(x => x !== e) : [...ev, e])} className={`px-2 py-1 rounded border font-mono text-[9px] transition-all ${events.includes(e) ? 'bg-blue-950 border-blue-800 text-blue-300' : 'bg-retro-bg border-retro-border text-primary-700'}`}>{e}</button>)}</div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => createMut.mutate({ url, name, events })} disabled={!url || events.length === 0 || createMut.isPending} className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 disabled:opacity-40">
            <Globe className="w-3.5 h-3.5" /> {createMut.isPending ? 'Registering…' : 'Register Webhook'}
          </button>
          <p className="font-mono text-[9px] text-primary-800">Payload signed with HMAC-SHA256 — verify X-RetroWorks-Signature header</p>
        </div>
      </div>
      <div className="space-y-2">
        {(webhooks as any[]).map((wh: any) => (
          <div key={wh.id} className="flex items-center gap-3 p-4 bg-retro-card border border-retro-border rounded-lg">
            <Globe className="w-4 h-4 text-primary-600 shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2"><p className="font-mono text-sm text-primary-300">{wh.name}</p><div className={`w-1.5 h-1.5 rounded-full ${wh.isActive ? 'bg-green-400' : 'bg-primary-700'}`} /></div>
              <p className="font-mono text-[10px] text-primary-700 truncate">{wh.url}</p>
              <div className="flex items-center gap-1 mt-0.5 flex-wrap">{(wh.events ?? []).map((e: string) => <span key={e} className="font-mono text-[8px] text-blue-700 border border-blue-900 rounded px-1">{e}</span>)}</div>
            </div>
            <button onClick={() => { if (confirm('Delete this webhook?')) deleteMut.mutate(wh.id); }} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3.5 h-3.5" /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────

type Tab = 'plugins' | 'api-keys' | 'webhooks';

export function PluginsPage() {
  const [tab, setTab] = useState<Tab>('plugins');
  const [configPlugin, setConfigPlugin] = useState<any | null>(null);
  const qc = useQueryClient();

  const { data: plugins = [] } = useQuery({ queryKey: ['plugins'], queryFn: () => api('/plugins').then(r => r.data ?? []) });
  const toggleMut = useMutation({ mutationFn: ({ id, enabled }: any) => enabled ? api(`/plugins/${id}/disable`, { method: 'DELETE' }) : api(`/plugins/${id}/enable`, { method: 'POST', body: JSON.stringify({ config: {} }) }), onSuccess: () => qc.invalidateQueries({ queryKey: ['plugins'] }) });
  const configMut = useMutation({ mutationFn: ({ id, config }: any) => api(`/plugins/${id}/config`, { method: 'PATCH', body: JSON.stringify(config) }), onSuccess: () => { qc.invalidateQueries({ queryKey: ['plugins'] }); setConfigPlugin(null); } });

  const categories = [...new Set((plugins as any[]).map((p: any) => p.category))];
  const activeCount = (plugins as any[]).filter((p: any) => p.enabled).length;

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'plugins', label: 'Plugin Marketplace', icon: <Puzzle className="w-3.5 h-3.5" /> },
    { id: 'api-keys', label: 'API Keys', icon: <Key className="w-3.5 h-3.5" /> },
    { id: 'webhooks', label: 'Webhooks', icon: <Globe className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="space-y-5 animate-fade-in">
      <div><h1 className="font-pixel text-[10px] text-primary-400">PLUGINS & EXTENSIBILITY</h1><p className="font-mono text-xs text-primary-700 mt-1">{activeCount} of {(plugins as any[]).length} plugins active · API keys · Webhooks</p></div>

      <div className="flex items-center gap-1 p-1 bg-retro-bg border border-retro-border rounded-lg w-fit">
        {tabs.map(t => <button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-2 px-4 py-2 rounded font-mono text-xs transition-all ${tab === t.id ? 'bg-primary-900 border border-primary-700 text-primary-300' : 'text-primary-700 hover:text-primary-500'}`}>{t.icon}{t.label}</button>)}
      </div>

      {tab === 'plugins' && (
        <div className="space-y-5">
          {categories.map(cat => (
            <div key={cat as string}>
              <p className="font-pixel text-[7px] text-primary-700 mb-3">{cat as string}</p>
              <div className="grid grid-cols-3 gap-3">
                {(plugins as any[]).filter((p: any) => p.category === cat).map((plugin: any) => (
                  <PluginCard key={plugin.id} plugin={plugin} onToggle={() => toggleMut.mutate({ id: plugin.id, enabled: plugin.enabled })} onConfigure={() => setConfigPlugin(plugin)} />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
      {tab === 'api-keys' && <ApiKeysTab />}
      {tab === 'webhooks' && <WebhooksTab />}

      {configPlugin && <ConfigModal plugin={configPlugin} onSave={config => configMut.mutate({ id: configPlugin.id, config })} onClose={() => setConfigPlugin(null)} />}
    </div>
  );
}
