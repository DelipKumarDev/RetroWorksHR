'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Timer, LogIn, LogOut, CheckCircle2, Clock, BarChart2,
  Calendar, Users,
} from 'lucide-react';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
      ...opts?.headers,
    },
  }).then(r => r.json());

function formatMinutes(mins: number) {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}h ${m.toString().padStart(2, '0')}m`;
}

export function AttendancePage() {
  const [tab, setTab] = useState<'today' | 'my' | 'team'>('today');
  const qc = useQueryClient();

  const { data: today } = useQuery({
    queryKey: ['attendance-today'],
    queryFn: () => api('/attendance/today').then(r => r.data),
    refetchInterval: 60_000,
  });

  const { data: myRecords } = useQuery({
    queryKey: ['attendance-my'],
    queryFn: () => api('/attendance/my').then(r => r.data),
    enabled: tab === 'my',
  });

  const { data: teamData } = useQuery({
    queryKey: ['attendance-team'],
    queryFn: () => api('/attendance/team').then(r => r.data),
    enabled: tab === 'team',
    refetchInterval: 120_000,
  });

  const punchIn = useMutation({
    mutationFn: () => api('/attendance/punch-in', { method: 'POST', body: '{}' }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['attendance-today'] }),
  });

  const punchOut = useMutation({
    mutationFn: () => api('/attendance/punch-out', { method: 'POST', body: '{}' }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['attendance-today'] }),
  });

  const isPunchedIn = today?.status === 'punched-in';
  const isPunchedOut = today?.status === 'punched-out';
  const notStarted = today?.status === 'not-started';

  return (
    <div className="space-y-5 animate-fade-in">
      <div>
        <h1 className="font-pixel text-[10px] text-primary-400">ATTENDANCE</h1>
        <p className="font-mono text-xs text-primary-700 mt-1">
          {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
        </p>
      </div>

      {/* Punch Widget */}
      <div className="bg-retro-card border border-retro-border rounded-lg p-6 text-center space-y-4">
        {/* Status indicator */}
        <div className="flex items-center justify-center gap-2">
          <span className={`w-3 h-3 rounded-full ${
            isPunchedIn ? 'bg-primary-crt animate-pulse' :
            isPunchedOut ? 'bg-primary-700' : 'bg-retro-border'
          }`} />
          <span className="font-pixel text-[9px] text-primary-500">
            {isPunchedIn ? 'WORKING' : isPunchedOut ? 'COMPLETED' : 'NOT STARTED'}
          </span>
        </div>

        {/* Live timer */}
        <div className="font-pixel text-pixel-2xl text-primary-crt">
          {formatMinutes(today?.totalMinutes ?? 0)}
        </div>

        {/* Timestamps */}
        <div className="flex justify-center gap-8 font-mono text-xs text-primary-700">
          <div>
            <p className="text-[9px] mb-0.5">PUNCH IN</p>
            <p className="text-primary-400">
              {today?.punchIn
                ? new Date(today.punchIn).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
                : '—:——'}
            </p>
          </div>
          <div>
            <p className="text-[9px] mb-0.5">PUNCH OUT</p>
            <p className="text-primary-400">
              {today?.punchOut
                ? new Date(today.punchOut).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
                : '—:——'}
            </p>
          </div>
        </div>

        {/* Action button */}
        {notStarted && (
          <button
            onClick={() => punchIn.mutate()}
            disabled={punchIn.isPending}
            className="flex items-center gap-2 mx-auto px-8 py-3 bg-primary-900 border-2 border-primary-600 hover:border-primary-crt hover:shadow-glow-strong font-pixel text-[9px] text-primary-crt rounded-lg transition-all disabled:opacity-50 active:translate-y-px"
          >
            <LogIn className="w-4 h-4" />
            PUNCH IN
          </button>
        )}
        {isPunchedIn && (
          <button
            onClick={() => punchOut.mutate()}
            disabled={punchOut.isPending}
            className="flex items-center gap-2 mx-auto px-8 py-3 bg-amber-950 border-2 border-amber-700 hover:border-amber-500 font-pixel text-[9px] text-amber-400 rounded-lg transition-all disabled:opacity-50 active:translate-y-px"
          >
            <LogOut className="w-4 h-4" />
            PUNCH OUT
          </button>
        )}
        {isPunchedOut && (
          <div className="flex items-center justify-center gap-2 text-primary-600">
            <CheckCircle2 className="w-5 h-5" />
            <span className="font-pixel text-[8px]">DAY COMPLETE</span>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-0 border-b border-retro-border">
        {([
          { key: 'today', label: 'Today', icon: <Timer className="w-3 h-3" /> },
          { key: 'my', label: 'My History', icon: <Calendar className="w-3 h-3" /> },
          { key: 'team', label: 'Team', icon: <Users className="w-3 h-3" /> },
        ] as const).map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center gap-1.5 px-4 py-2 font-pixel text-[8px] border-b-2 transition-all ${
              tab === t.key ? 'border-primary-crt text-primary-crt' : 'border-transparent text-primary-700 hover:text-primary-500'
            }`}
          >
            {t.icon} {t.label}
          </button>
        ))}
      </div>

      {/* My History */}
      {tab === 'my' && myRecords && (
        <div className="space-y-3">
          {/* Summary */}
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: 'Present', value: myRecords.summary?.present ?? 0, color: 'text-green-400' },
              { label: 'Absent', value: myRecords.summary?.absent ?? 0, color: 'text-red-400' },
              { label: 'Half Day', value: myRecords.summary?.halfDay ?? 0, color: 'text-amber-400' },
              { label: 'Avg Hours', value: `${myRecords.summary?.avgHours ?? 0}h`, color: 'text-primary-400' },
            ].map(s => (
              <div key={s.label} className="bg-retro-card border border-retro-border rounded p-3 text-center">
                <p className={`font-pixel text-pixel-lg ${s.color}`}>{s.value}</p>
                <p className="font-pixel text-[7px] text-primary-700 mt-1">{s.label}</p>
              </div>
            ))}
          </div>

          {/* Records */}
          <div className="bg-retro-card border border-retro-border rounded overflow-hidden">
            <table className="w-full text-xs">
              <thead className="bg-retro-bg">
                <tr>
                  <th className="py-2 px-4 font-pixel text-[7px] text-primary-700 text-left">DATE</th>
                  <th className="py-2 px-4 font-pixel text-[7px] text-primary-700 text-left">IN</th>
                  <th className="py-2 px-4 font-pixel text-[7px] text-primary-700 text-left">OUT</th>
                  <th className="py-2 px-4 font-pixel text-[7px] text-primary-700 text-left">HOURS</th>
                  <th className="py-2 px-4 font-pixel text-[7px] text-primary-700 text-left">STATUS</th>
                </tr>
              </thead>
              <tbody>
                {(myRecords.records ?? []).slice(0, 30).map((r: {
                  id: string; date: string; punchIn?: string; punchOut?: string;
                  totalMinutes?: number; status: string;
                }) => (
                  <tr key={r.id} className="border-t border-retro-border/50 hover:bg-surface-raised">
                    <td className="py-2 px-4 font-mono text-primary-400">
                      {new Date(r.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                    </td>
                    <td className="py-2 px-4 font-mono text-primary-500">
                      {r.punchIn ? new Date(r.punchIn).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—'}
                    </td>
                    <td className="py-2 px-4 font-mono text-primary-500">
                      {r.punchOut ? new Date(r.punchOut).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—'}
                    </td>
                    <td className="py-2 px-4 font-mono text-primary-500">
                      {r.totalMinutes ? formatMinutes(r.totalMinutes) : '—'}
                    </td>
                    <td className="py-2 px-4">
                      <span className={`font-pixel text-[7px] ${
                        r.status === 'present' ? 'text-green-400' :
                        r.status === 'absent' ? 'text-red-400' :
                        r.status === 'half-day' ? 'text-amber-400' : 'text-primary-700'
                      }`}>{r.status.toUpperCase()}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Team */}
      {tab === 'team' && teamData && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {(teamData as Array<{
            employee: { firstName: string; lastName: string; avatarUrl?: string };
            status: string;
            record?: { punchIn?: string; punchOut?: string; totalMinutes?: number };
          }>).map((item, i) => (
            <div key={i} className="bg-retro-card border border-retro-border rounded p-3 flex items-center gap-3">
              <div className={`w-2 h-2 rounded-full shrink-0 ${
                item.status === 'punched-in' ? 'bg-primary-crt animate-pulse' :
                item.status === 'punched-out' ? 'bg-primary-700' : 'bg-red-800'
              }`} />
              <div className="min-w-0">
                <p className="font-mono text-sm text-primary-300 truncate">
                  {item.employee.firstName} {item.employee.lastName}
                </p>
                <p className="font-mono text-[10px] text-primary-700">
                  {item.status === 'punched-in' ? `In since ${new Date(item.record?.punchIn ?? '').toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}` :
                   item.status === 'punched-out' ? `${formatMinutes(item.record?.totalMinutes ?? 0)} worked` :
                   'Not checked in'}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
