'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Send, Bot, User, Loader2, Plus, Trash2, Search,
  BookOpen, Zap, FileText, Star,
} from 'lucide-react';

const api = async (path: string, options?: RequestInit) => {
  const res = await fetch(`/api/v1${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
      ...options?.headers,
    },
  });
  return res.json();
};

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  sources?: Array<{ title: string; url?: string }>;
  timestamp: Date;
  isStreaming?: boolean;
}

interface Session { id: string; title: string; updatedAt: string; messageCount: number }

const STARTER_PROMPTS = [
  { icon: <BookOpen className="w-3.5 h-3.5" />, label: 'Leave Policy', prompt: 'What is the leave encashment policy?' },
  { icon: <Zap className="w-3.5 h-3.5" />, label: 'PF Rules', prompt: 'How is Provident Fund calculated for me?' },
  { icon: <FileText className="w-3.5 h-3.5" />, label: 'My Payslip', prompt: 'What are the deductions in my payslip?' },
  { icon: <Star className="w-3.5 h-3.5" />, label: 'Goals', prompt: 'How do I update my OKR progress?' },
];

function genSessionId() {
  return `session_${Date.now()}_${Math.random().toString(36).slice(2)}`;
}

function MessageBubble({ msg }: { msg: ChatMessage }) {
  const isUser = msg.role === 'user';

  return (
    <div className={`flex gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* Avatar */}
      <div className={`shrink-0 w-7 h-7 rounded flex items-center justify-center text-xs ${
        isUser ? 'bg-primary-900 border border-primary-700' : 'bg-retro-bg border border-primary-800'
      }`}>
        {isUser ? <User className="w-3.5 h-3.5 text-primary-400" /> : <Bot className="w-3.5 h-3.5 text-primary-crt" />}
      </div>

      {/* Bubble */}
      <div className={`max-w-[80%] space-y-2`}>
        <div className={`px-4 py-3 rounded-lg font-mono text-sm leading-relaxed ${
          isUser
            ? 'bg-primary-900 border border-primary-700 text-primary-300 rounded-tr-none'
            : 'bg-retro-card border border-retro-border text-primary-400 rounded-tl-none'
        }`}>
          {msg.isStreaming ? (
            <span className="flex items-center gap-2">
              <Loader2 className="w-3 h-3 animate-spin text-primary-600" />
              <span className="text-primary-700 text-xs">RetroBot thinking...</span>
            </span>
          ) : (
            <p className="whitespace-pre-wrap">{msg.content}</p>
          )}
        </div>

        {/* Sources */}
        {msg.sources && msg.sources.length > 0 && (
          <div className="flex flex-wrap gap-1.5 px-1">
            {msg.sources.map((src, i) => (
              <span key={i} className="flex items-center gap-1 px-2 py-0.5 bg-primary-950/50 border border-primary-900 rounded font-mono text-[9px] text-primary-700">
                <BookOpen className="w-2.5 h-2.5" />
                {src.title}
              </span>
            ))}
          </div>
        )}

        <p className="font-mono text-[9px] text-primary-800 px-1">
          {msg.timestamp.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
        </p>
      </div>
    </div>
  );
}

export function AiChatPage() {
  const queryClient = useQueryClient();
  const [sessionId, setSessionId] = useState(() => genSessionId());
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const { data: sessions = [] } = useQuery<Session[]>({
    queryKey: ['ai-sessions'],
    queryFn: () => api('/ai/sessions').then(r => r.data ?? []),
  });

  const chatMutation = useMutation({
    mutationFn: (message: string) =>
      api('/ai/chat', {
        method: 'POST',
        body: JSON.stringify({ message, sessionId }),
      }).then(r => r.data),
    onMutate: (message) => {
      // Optimistically add user message
      const userMsg: ChatMessage = {
        id: `user-${Date.now()}`,
        role: 'user',
        content: message,
        timestamp: new Date(),
      };
      const loadingMsg: ChatMessage = {
        id: `assistant-loading`,
        role: 'assistant',
        content: '',
        timestamp: new Date(),
        isStreaming: true,
      };
      setMessages(prev => [...prev, userMsg, loadingMsg]);
      setIsTyping(true);
    },
    onSuccess: (data) => {
      setMessages(prev => [
        ...prev.filter(m => m.id !== 'assistant-loading'),
        {
          id: `assistant-${Date.now()}`,
          role: 'assistant',
          content: data?.reply ?? 'Sorry, I could not generate a response.',
          sources: data?.sources ?? [],
          timestamp: new Date(),
        },
      ]);
      queryClient.invalidateQueries({ queryKey: ['ai-sessions'] });
    },
    onError: () => {
      setMessages(prev => [
        ...prev.filter(m => m.id !== 'assistant-loading'),
        {
          id: `assistant-error-${Date.now()}`,
          role: 'assistant',
          content: '⚠️ Something went wrong. Please try again.',
          timestamp: new Date(),
        },
      ]);
    },
    onSettled: () => setIsTyping(false),
  });

  const handleSend = useCallback(() => {
    const msg = input.trim();
    if (!msg || chatMutation.isPending) return;
    setInput('');
    chatMutation.mutate(msg);
  }, [input, chatMutation]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleNewSession = () => {
    setSessionId(genSessionId());
    setMessages([]);
    setInput('');
  };

  const handleLoadSession = async (sid: string) => {
    setSessionId(sid);
    const data = await api(`/ai/sessions/${sid}`).then(r => r.data);
    const msgs: ChatMessage[] = (data?.messages ?? []).map((m: any) => ({
      id: m.id,
      role: m.role,
      content: m.content,
      timestamp: new Date(m.createdAt),
    }));
    setMessages(msgs);
  };

  const handleStarterPrompt = (prompt: string) => {
    setInput(prompt);
    inputRef.current?.focus();
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const hasMessages = messages.length > 0;

  return (
    <div className="flex gap-0 h-[calc(100vh-8rem)] animate-fade-in">
      {/* Sidebar — session history */}
      <div className="w-56 shrink-0 border-r border-retro-border flex flex-col bg-retro-bg/50">
        <div className="p-3 border-b border-retro-border">
          <button
            onClick={handleNewSession}
            className="w-full flex items-center gap-2 px-3 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-400 hover:text-primary-300 hover:border-primary-600 transition-all"
          >
            <Plus className="w-3 h-3" /> NEW CHAT
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {sessions.length === 0 ? (
            <p className="font-pixel text-[7px] text-primary-800 text-center py-4">No conversations yet</p>
          ) : sessions.map(s => (
            <button
              key={s.id}
              onClick={() => handleLoadSession(s.id)}
              className={`w-full text-left px-2.5 py-2 rounded font-mono text-[10px] truncate transition-all ${
                s.id === sessionId
                  ? 'bg-primary-950 border border-primary-800 text-primary-300'
                  : 'text-primary-600 hover:bg-surface-raised hover:text-primary-400'
              }`}
            >
              {s.title}
            </button>
          ))}
        </div>

        <div className="p-2 border-t border-retro-border">
          <p className="font-pixel text-[6px] text-primary-800 text-center">Powered by Claude</p>
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="px-5 py-3 border-b border-retro-border flex items-center gap-3">
          <div className="w-7 h-7 rounded bg-primary-950 border border-primary-800 flex items-center justify-center">
            <Bot className="w-4 h-4 text-primary-crt" />
          </div>
          <div>
            <h2 className="font-pixel text-[9px] text-primary-crt">RETROBOT</h2>
            <p className="font-mono text-[9px] text-primary-700">HR AI Assistant · RAG-powered · India Compliant</p>
          </div>
          <div className="ml-auto flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="font-mono text-[9px] text-primary-700">Online</span>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-5">
          {!hasMessages && (
            <div className="flex flex-col items-center justify-center h-full space-y-6">
              <div className="text-center space-y-2">
                <div className="w-14 h-14 mx-auto rounded-lg bg-primary-950 border border-primary-800 flex items-center justify-center mb-4">
                  <Bot className="w-7 h-7 text-primary-crt" />
                </div>
                <h3 className="font-pixel text-[10px] text-primary-400">How can I help you today?</h3>
                <p className="font-mono text-xs text-primary-700 max-w-xs">
                  Ask me about leave policies, payroll, performance reviews, or any HR topic.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 max-w-sm">
                {STARTER_PROMPTS.map(p => (
                  <button
                    key={p.label}
                    onClick={() => handleStarterPrompt(p.prompt)}
                    className="flex items-center gap-2 px-3 py-2.5 bg-retro-card border border-retro-border rounded-lg font-mono text-xs text-primary-500 hover:border-primary-700 hover:text-primary-400 transition-all text-left"
                  >
                    <span className="text-primary-700">{p.icon}</span>
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map(msg => (
            <MessageBubble key={msg.id} msg={msg} />
          ))}
          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <div className="px-5 py-4 border-t border-retro-border">
          <div className="flex gap-2 items-end">
            <div className="flex-1 relative">
              <textarea
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask RetroBot anything about HR policies, payroll, leave..."
                rows={1}
                className="w-full px-4 py-3 bg-retro-bg border border-retro-border rounded-lg font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none focus:shadow-glow resize-none leading-relaxed"
                style={{ maxHeight: '120px', overflowY: 'auto' }}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = 'auto';
                  target.style.height = Math.min(target.scrollHeight, 120) + 'px';
                }}
              />
            </div>
            <button
              onClick={handleSend}
              disabled={!input.trim() || chatMutation.isPending}
              className="px-4 py-3 bg-primary-900 border border-primary-700 rounded-lg text-primary-400 hover:text-primary-300 hover:border-primary-500 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-glow"
            >
              {chatMutation.isPending
                ? <Loader2 className="w-4 h-4 animate-spin" />
                : <Send className="w-4 h-4" />
              }
            </button>
          </div>
          <p className="font-mono text-[9px] text-primary-800 mt-2 text-center">
            RetroBot can make mistakes. Verify important HR details with your HR team.
          </p>
        </div>
      </div>
    </div>
  );
}
