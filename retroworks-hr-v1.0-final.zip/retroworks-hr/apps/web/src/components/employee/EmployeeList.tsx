'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  Search, UserPlus, Download, Upload, Filter,
  ChevronRight, ChevronLeft, Users, MoreVertical,
} from 'lucide-react';

interface Employee {
  id: string;
  employeeCode: string;
  firstName: string;
  lastName: string;
  workEmail: string;
  status: string;
  employmentType: string;
  dateOfJoining: string;
  department?: { name: string };
  designation?: { name: string };
  location?: { name: string; city?: string };
  manager?: { firstName: string; lastName: string };
  avatarUrl?: string;
}

interface EmployeeListResponse {
  data: Employee[];
  hasMore: boolean;
  nextCursor?: string;
  total?: number;
}

function PixelAvatar({ name, size = 'sm' }: { name: string; size?: 'sm' | 'md' }) {
  const initials = name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
  const colors = ['#1a3a1a', '#1a1a3a', '#3a1a1a', '#1a3a3a', '#3a1a3a'];
  const bg = colors[name.charCodeAt(0) % colors.length] ?? colors[0];
  const sizeClass = size === 'sm' ? 'w-7 h-7 text-[8px]' : 'w-9 h-9 text-[9px]';

  return (
    <div
      className={`${sizeClass} rounded border border-primary-800 flex items-center justify-center font-pixel text-primary-crt shrink-0`}
      style={{ backgroundColor: bg }}
      aria-hidden
    >
      {initials}
    </div>
  );
}

const STATUS_STYLES: Record<string, string> = {
  active: 'text-green-400 bg-green-950 border-green-800',
  'on-leave': 'text-purple-400 bg-purple-950 border-purple-800',
  'notice-period': 'text-amber-400 bg-amber-950 border-amber-800',
  terminated: 'text-red-400 bg-red-950 border-red-800',
  suspended: 'text-orange-400 bg-orange-950 border-orange-800',
};

export function EmployeeListClient() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [cursor, setCursor] = useState<string | undefined>(undefined);
  const [cursorHistory, setCursorHistory] = useState<string[]>([]);

  const queryKey = ['employees', { search, status, cursor }];

  const { data, isLoading, isFetching } = useQuery<EmployeeListResponse>({
    queryKey,
    queryFn: async () => {
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (status) params.set('status', status);
      if (cursor) params.set('cursor', cursor);
      params.set('limit', '25');

      const res = await fetch(`/api/v1/employees?${params.toString()}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token') ?? ''}` },
      });
      const json = await res.json() as { data: EmployeeListResponse };
      return json.data;
    },
  });

  const employees = data?.data ?? [];
  const hasMore = data?.hasMore ?? false;

  const handleNext = () => {
    if (data?.nextCursor) {
      setCursorHistory(h => [...h, cursor ?? '']);
      setCursor(data.nextCursor);
    }
  };

  const handlePrev = () => {
    const prev = [...cursorHistory];
    const last = prev.pop();
    setCursorHistory(prev);
    setCursor(last || undefined);
  };

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">EMPLOYEE DIRECTORY</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">
            {data?.total !== undefined ? `${data.total} total employees` : 'Loading...'}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border hover:border-primary-700 font-pixel text-[8px] text-primary-600 hover:text-primary-400 rounded transition-all">
            <Upload className="w-3.5 h-3.5" /> Import
          </button>
          <button className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border hover:border-primary-700 font-pixel text-[8px] text-primary-600 hover:text-primary-400 rounded transition-all">
            <Download className="w-3.5 h-3.5" /> Export
          </button>
          <button className="flex items-center gap-1.5 px-4 py-1.5 bg-primary-900 border border-primary-600 hover:border-primary-crt hover:shadow-glow font-pixel text-[8px] text-primary-crt rounded transition-all">
            <UserPlus className="w-3.5 h-3.5" /> Add Employee
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        {/* Search */}
        <div className="relative flex-1 min-w-48 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-primary-700" aria-hidden />
          <input
            type="search"
            value={search}
            onChange={e => { setSearch(e.target.value); setCursor(undefined); setCursorHistory([]); }}
            placeholder="Search name, code, email..."
            aria-label="Search employees"
            className="w-full pl-9 pr-4 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none focus:shadow-glow caret-primary-crt"
          />
        </div>

        {/* Status filter */}
        <select
          value={status}
          onChange={e => { setStatus(e.target.value); setCursor(undefined); setCursorHistory([]); }}
          aria-label="Filter by status"
          className="px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-xs text-primary-400 focus:border-primary-600 focus:outline-none"
        >
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="on-leave">On Leave</option>
          <option value="notice-period">Notice Period</option>
          <option value="terminated">Terminated</option>
        </select>

        <button className="flex items-center gap-1 px-3 py-2 border border-retro-border hover:border-primary-700 rounded font-pixel text-[8px] text-primary-600 transition-all">
          <Filter className="w-3 h-3" /> More Filters
        </button>
      </div>

      {/* Table */}
      <div className="bg-retro-card border border-retro-border rounded overflow-hidden">
        {/* Table header chrome */}
        <div className="flex items-center gap-2 px-4 py-2 border-b border-retro-border bg-retro-bg">
          <span className="w-2 h-2 bg-red-600 opacity-70" />
          <span className="w-2 h-2 bg-accent-dim opacity-70" />
          <span className="w-2 h-2 bg-primary-700 opacity-70" />
          <span className="ml-2 font-pixel text-[8px] text-primary-700">
            EMPLOYEE_DIRECTORY.DB
          </span>
          {isFetching && (
            <span className="ml-auto font-mono text-[10px] text-primary-700 animate-blink-cursor">
              LOADING▋
            </span>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full" aria-label="Employee list">
            <thead>
              <tr>
                <th className="w-10" scope="col"><span className="sr-only">Avatar</span></th>
                <th scope="col">Employee</th>
                <th scope="col">Department</th>
                <th scope="col">Location</th>
                <th scope="col">Type</th>
                <th scope="col">Joined</th>
                <th scope="col">Status</th>
                <th scope="col" className="w-10"><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                Array.from({ length: 8 }, (_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 8 }, (_, j) => (
                      <td key={j}><div className="h-5 skeleton rounded" /></td>
                    ))}
                  </tr>
                ))
              ) : employees.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center">
                    <Users className="w-8 h-8 text-primary-800 mx-auto mb-2" />
                    <p className="font-pixel text-[8px] text-primary-700">No employees found</p>
                    {search && (
                      <button
                        onClick={() => setSearch('')}
                        className="mt-2 font-mono text-xs text-primary-600 underline"
                      >
                        Clear search
                      </button>
                    )}
                  </td>
                </tr>
              ) : (
                employees.map(emp => (
                  <tr
                    key={emp.id}
                    className="cursor-pointer hover:bg-surface-raised transition-colors"
                    onClick={() => window.location.href = `/dashboard/employees/${emp.id}`}
                  >
                    <td>
                      <PixelAvatar name={`${emp.firstName} ${emp.lastName}`} />
                    </td>
                    <td>
                      <div>
                        <p className="font-mono text-sm text-primary-200">
                          {emp.firstName} {emp.lastName}
                        </p>
                        <p className="font-mono text-[10px] text-primary-700">
                          {emp.employeeCode} · {emp.workEmail}
                        </p>
                      </div>
                    </td>
                    <td>
                      <div>
                        <p className="font-mono text-xs text-primary-400">{emp.department?.name ?? '—'}</p>
                        <p className="font-mono text-[10px] text-primary-700">{emp.designation?.name ?? ''}</p>
                      </div>
                    </td>
                    <td>
                      <span className="font-mono text-xs text-primary-500">
                        {emp.location?.city ?? emp.location?.name ?? '—'}
                      </span>
                    </td>
                    <td>
                      <span className="font-mono text-xs text-primary-600 capitalize">
                        {emp.employmentType.replace('-', ' ')}
                      </span>
                    </td>
                    <td>
                      <span className="font-mono text-xs text-primary-600">
                        {new Date(emp.dateOfJoining).toLocaleDateString('en-IN', {
                          day: '2-digit', month: 'short', year: 'numeric',
                        })}
                      </span>
                    </td>
                    <td>
                      <span className={`px-2 py-0.5 border rounded font-pixel text-[7px] ${
                        STATUS_STYLES[emp.status] ?? 'text-primary-600 bg-retro-bg border-retro-border'
                      }`}>
                        {emp.status.replace('-', ' ').toUpperCase()}
                      </span>
                    </td>
                    <td onClick={e => e.stopPropagation()}>
                      <button
                        aria-label={`More actions for ${emp.firstName} ${emp.lastName}`}
                        className="p-1 text-primary-700 hover:text-primary-400 hover:bg-surface-raised rounded"
                      >
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {(cursorHistory.length > 0 || hasMore) && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-retro-border">
            <button
              onClick={handlePrev}
              disabled={cursorHistory.length === 0}
              className="flex items-center gap-1 px-3 py-1.5 border border-retro-border hover:border-primary-700 disabled:opacity-40 disabled:cursor-not-allowed font-pixel text-[8px] text-primary-600 rounded transition-all"
            >
              <ChevronLeft className="w-3 h-3" /> PREV
            </button>
            <span className="font-mono text-xs text-primary-700">
              Page {cursorHistory.length + 1}
            </span>
            <button
              onClick={handleNext}
              disabled={!hasMore}
              className="flex items-center gap-1 px-3 py-1.5 border border-retro-border hover:border-primary-700 disabled:opacity-40 disabled:cursor-not-allowed font-pixel text-[8px] text-primary-600 rounded transition-all"
            >
              NEXT <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
