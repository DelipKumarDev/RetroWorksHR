'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Calendar, Plus, Clock, CheckCircle2, XCircle, AlertCircle,
  ChevronLeft, ChevronRight, Filter,
} from 'lucide-react';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
      ...opts?.headers,
    },
  }).then(r => r.json());

interface LeaveBalance {
  leaveType: { id: string; name: string; code: string; paidLeave: boolean };
  balance: number;
  used: number;
  pending: number;
  entitled: number;
}

interface LeaveRequest {
  id: string;
  startDate: string;
  endDate: string;
  days: number;
  status: string;
  reason?: string;
  leaveType: { name: string; code: string };
  employee?: { firstName: string; lastName: string };
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  pending: { label: 'Pending', color: 'text-amber-400 bg-amber-950 border-amber-800', icon: <Clock className="w-3 h-3" /> },
  approved: { label: 'Approved', color: 'text-green-400 bg-green-950 border-green-800', icon: <CheckCircle2 className="w-3 h-3" /> },
  rejected: { label: 'Rejected', color: 'text-red-400 bg-red-950 border-red-800', icon: <XCircle className="w-3 h-3" /> },
  cancelled: { label: 'Cancelled', color: 'text-primary-700 bg-retro-bg border-retro-border', icon: null },
  'auto-approved': { label: 'Auto-Approved', color: 'text-green-400 bg-green-950 border-green-800', icon: <CheckCircle2 className="w-3 h-3" /> },
};

// Compact leave application form
function ApplyLeaveModal({ leaveTypes, onClose, onSubmit }: {
  leaveTypes: Array<{ id: string; name: string; code: string }>;
  onClose: () => void;
  onSubmit: (data: Record<string, string>) => void;
}) {
  const [form, setForm] = useState({
    leaveTypeId: leaveTypes[0]?.id ?? '',
    startDate: '',
    endDate: '',
    reason: '',
  });

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }));

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-retro-card border border-primary-800 rounded-lg w-full max-w-md shadow-glow-strong mx-4">
        {/* Chrome */}
        <div className="flex items-center gap-2 px-4 py-3 border-b border-retro-border">
          <span className="w-2 h-2 bg-red-600 rounded-full" />
          <span className="w-2 h-2 bg-amber-600 rounded-full" />
          <span className="w-2 h-2 bg-green-600 rounded-full" />
          <span className="font-pixel text-[8px] text-primary-600 ml-2">APPLY_LEAVE.EXE</span>
          <button onClick={onClose} className="ml-auto text-primary-700 hover:text-primary-400 font-mono text-sm">✕</button>
        </div>

        <div className="p-5 space-y-4">
          {/* Leave type */}
          <div>
            <label className="block font-pixel text-[7px] text-primary-700 mb-1">LEAVE TYPE *</label>
            <select
              value={form.leaveTypeId}
              onChange={set('leaveTypeId')}
              className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 focus:border-primary-600 focus:outline-none"
            >
              {leaveTypes.map(lt => (
                <option key={lt.id} value={lt.id}>{lt.name} ({lt.code})</option>
              ))}
            </select>
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-pixel text-[7px] text-primary-700 mb-1">FROM *</label>
              <input
                type="date"
                value={form.startDate}
                onChange={set('startDate')}
                className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 focus:border-primary-600 focus:outline-none"
              />
            </div>
            <div>
              <label className="block font-pixel text-[7px] text-primary-700 mb-1">TO *</label>
              <input
                type="date"
                value={form.endDate}
                onChange={set('endDate')}
                min={form.startDate}
                className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 focus:border-primary-600 focus:outline-none"
              />
            </div>
          </div>

          {/* Reason */}
          <div>
            <label className="block font-pixel text-[7px] text-primary-700 mb-1">REASON</label>
            <textarea
              value={form.reason}
              onChange={set('reason')}
              rows={3}
              placeholder="Optional — briefly describe the reason for leave"
              className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-1">
            <button
              onClick={() => onSubmit(form)}
              disabled={!form.leaveTypeId || !form.startDate || !form.endDate}
              className="flex-1 py-2 bg-primary-900 border border-primary-600 hover:border-primary-crt hover:shadow-glow font-pixel text-[8px] text-primary-crt rounded transition-all disabled:opacity-40"
            >
              SUBMIT REQUEST
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 border border-retro-border font-mono text-sm text-primary-700 hover:text-primary-500 rounded"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Main page component
export function LeavePage() {
  const [tab, setTab] = useState<'my' | 'team' | 'calendar'>('my');
  const [showApply, setShowApply] = useState(false);
  const [calendarDate, setCalendarDate] = useState(new Date());
  const qc = useQueryClient();

  const { data: balances = [] } = useQuery<LeaveBalance[]>({
    queryKey: ['leave-balances'],
    queryFn: () => api('/leave/balances/me').then(r => r.data),
  });

  const { data: leaveTypes = [] } = useQuery({
    queryKey: ['leave-types'],
    queryFn: () => api('/leave/types').then(r => r.data ?? []),
  });

  const { data: myRequests } = useQuery<{ data: LeaveRequest[] }>({
    queryKey: ['leave-requests-mine'],
    queryFn: () => api('/leave/requests?limit=20').then(r => r.data),
  });

  const { data: teamRequests } = useQuery<{ data: LeaveRequest[] }>({
    queryKey: ['leave-requests-team'],
    queryFn: () => api('/leave/requests?teamOnly=true&status=pending').then(r => r.data),
    enabled: tab === 'team',
  });

  const { data: calendar } = useQuery({
    queryKey: ['leave-calendar', calendarDate.getMonth(), calendarDate.getFullYear()],
    queryFn: () => api(`/leave/calendar?month=${calendarDate.getMonth() + 1}&year=${calendarDate.getFullYear()}`).then(r => r.data),
    enabled: tab === 'calendar',
  });

  const applyMutation = useMutation({
    mutationFn: (data: Record<string, string>) =>
      api('/leave/requests', { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['leave-requests-mine'] });
      void qc.invalidateQueries({ queryKey: ['leave-balances'] });
      setShowApply(false);
    },
  });

  const approveMutation = useMutation({
    mutationFn: (id: string) => api(`/leave/requests/${id}/approve`, { method: 'POST', body: '{}' }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['leave-requests-team'] }),
  });

  const rejectMutation = useMutation({
    mutationFn: ({ id, reason }: { id: string; reason: string }) =>
      api(`/leave/requests/${id}/reject`, { method: 'POST', body: JSON.stringify({ reason }) }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ['leave-requests-team'] }),
  });

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">LEAVE MANAGEMENT</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">Apply, track, and approve leaves</p>
        </div>
        <button
          onClick={() => setShowApply(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-primary-900 border border-primary-600 hover:border-primary-crt hover:shadow-glow font-pixel text-[8px] text-primary-crt rounded transition-all"
        >
          <Plus className="w-3.5 h-3.5" /> Apply Leave
        </button>
      </div>

      {/* Balance Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {balances.map(b => (
          <div key={b.leaveType.id} className="bg-retro-card border border-retro-border rounded p-3 text-center">
            <p className="font-pixel text-[7px] text-primary-700 truncate mb-2">{b.leaveType.name}</p>
            <p className="font-pixel text-pixel-xl text-primary-crt">{b.balance}</p>
            <p className="font-mono text-[9px] text-primary-700 mt-1">{b.used} used / {b.entitled} total</p>
            {/* Balance bar */}
            <div className="mt-2 h-1.5 bg-retro-bg rounded-full overflow-hidden">
              <div
                className="h-full bg-primary-crt rounded-full transition-all"
                style={{ width: `${b.entitled > 0 ? (b.balance / b.entitled) * 100 : 0}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-0 border-b border-retro-border">
        {([
          { key: 'my', label: 'My Requests' },
          { key: 'team', label: 'Team Approvals' },
          { key: 'calendar', label: 'Calendar' },
        ] as const).map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2 font-pixel text-[8px] border-b-2 transition-all ${
              tab === t.key
                ? 'border-primary-crt text-primary-crt'
                : 'border-transparent text-primary-700 hover:text-primary-500'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* My Requests */}
      {tab === 'my' && (
        <div className="space-y-2">
          {!myRequests?.data?.length ? (
            <div className="text-center py-10">
              <Calendar className="w-8 h-8 text-primary-800 mx-auto mb-2" />
              <p className="font-pixel text-[8px] text-primary-700">No leave requests yet</p>
            </div>
          ) : (
            myRequests.data.map(req => {
              const cfg = STATUS_CONFIG[req.status] ?? STATUS_CONFIG['pending']!;
              return (
                <div key={req.id} className="bg-retro-card border border-retro-border rounded px-4 py-3 flex items-center gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-sm text-primary-300">
                        {new Date(req.startDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                        {req.startDate !== req.endDate && ` – ${new Date(req.endDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}`}
                      </span>
                      <span className="font-pixel text-[7px] text-primary-700 bg-retro-bg border border-retro-border px-1.5 py-0.5 rounded">
                        {req.leaveType.code}
                      </span>
                      <span className="font-mono text-xs text-primary-700">{req.days} day{req.days !== 1 ? 's' : ''}</span>
                    </div>
                    {req.reason && <p className="font-mono text-xs text-primary-700 mt-0.5 truncate">{req.reason}</p>}
                  </div>
                  <span className={`flex items-center gap-1 px-2 py-1 border rounded font-pixel text-[7px] shrink-0 ${cfg.color}`}>
                    {cfg.icon} {cfg.label}
                  </span>
                </div>
              );
            })
          )}
        </div>
      )}

      {/* Team Approvals */}
      {tab === 'team' && (
        <div className="space-y-3">
          {!teamRequests?.data?.length ? (
            <div className="text-center py-10">
              <CheckCircle2 className="w-8 h-8 text-primary-800 mx-auto mb-2" />
              <p className="font-pixel text-[8px] text-primary-700">No pending approvals</p>
            </div>
          ) : (
            teamRequests.data.map(req => (
              <div key={req.id} className="bg-retro-card border border-amber-900/50 rounded p-4">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-mono text-sm text-primary-200">
                      {req.employee?.firstName} {req.employee?.lastName}
                    </p>
                    <p className="font-mono text-xs text-primary-600 mt-0.5">
                      {req.leaveType.name} · {req.days} day{req.days !== 1 ? 's' : ''} ·{' '}
                      {new Date(req.startDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                      {req.startDate !== req.endDate && ` – ${new Date(req.endDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}`}
                    </p>
                    {req.reason && <p className="font-mono text-xs text-primary-700 mt-1">{req.reason}</p>}
                  </div>
                  <div className="flex gap-2 shrink-0">
                    <button
                      onClick={() => approveMutation.mutate(req.id)}
                      className="px-3 py-1.5 bg-green-950 border border-green-700 hover:border-green-500 font-pixel text-[7px] text-green-400 rounded transition-all"
                    >
                      ✓ APPROVE
                    </button>
                    <button
                      onClick={() => rejectMutation.mutate({ id: req.id, reason: 'Not approved' })}
                      className="px-3 py-1.5 bg-red-950 border border-red-800 hover:border-red-600 font-pixel text-[7px] text-red-400 rounded transition-all"
                    >
                      ✗ REJECT
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Calendar */}
      {tab === 'calendar' && (
        <div className="bg-retro-card border border-retro-border rounded p-4">
          <div className="flex items-center justify-between mb-4">
            <button onClick={() => setCalendarDate(d => new Date(d.getFullYear(), d.getMonth() - 1))} className="p-1 text-primary-600 hover:text-primary-400">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="font-pixel text-[9px] text-primary-400">
              {calendarDate.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' }).toUpperCase()}
            </span>
            <button onClick={() => setCalendarDate(d => new Date(d.getFullYear(), d.getMonth() + 1))} className="p-1 text-primary-600 hover:text-primary-400">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Holidays */}
          {calendar?.holidays?.length > 0 && (
            <div className="mb-3 space-y-1">
              <p className="font-pixel text-[7px] text-primary-700">PUBLIC HOLIDAYS</p>
              {calendar.holidays.map((h: string) => (
                <div key={h} className="flex items-center gap-2 font-mono text-xs">
                  <span className="w-2 h-2 bg-accent rounded-full" />
                  <span className="text-primary-500">{new Date(h).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}</span>
                </div>
              ))}
            </div>
          )}

          {/* Approved leaves */}
          {calendar?.approvedLeaves?.length > 0 && (
            <div className="space-y-2">
              <p className="font-pixel text-[7px] text-primary-700">TEAM ON LEAVE</p>
              {calendar.approvedLeaves.map((req: LeaveRequest & { employee: { firstName: string; lastName: string } }) => (
                <div key={req.id} className="flex items-center gap-2 font-mono text-xs">
                  <span className="w-2 h-2 bg-primary-crt rounded-full" />
                  <span className="text-primary-400">{req.employee.firstName} {req.employee.lastName}</span>
                  <span className="text-primary-700">{req.leaveType.code}</span>
                  <span className="text-primary-700 ml-auto">
                    {new Date(req.startDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                    {req.startDate !== req.endDate && ` – ${new Date(req.endDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}`}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Apply modal */}
      {showApply && (
        <ApplyLeaveModal
          leaveTypes={leaveTypes}
          onClose={() => setShowApply(false)}
          onSubmit={data => applyMutation.mutate(data)}
        />
      )}
    </div>
  );
}
