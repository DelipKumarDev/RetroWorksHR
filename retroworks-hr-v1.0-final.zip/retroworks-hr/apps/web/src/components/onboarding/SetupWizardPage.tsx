'use client';
/**
 * Smart Onboarding Wizard + Config Validator UI
 * ─────────────────────────────────────────────────────────────────────────────
 * 8-step wizard · Industry presets · Live validation · Health score
 * Migration assistant with visual field mapper · Fix-Now dashboard panel
 */

import { useState, useCallback, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Check, ChevronRight, ChevronLeft, AlertTriangle, AlertCircle,
  CheckCircle, Info, Upload, RefreshCw, Play, Zap, Shield,
  Building2, Users, FileText, Settings, UserCheck, BarChart3,
  ArrowRight, Download, X, Plus, Trash2, Lock, Unlock,
  Activity, TrendingUp, TrendingDown,
} from 'lucide-react';

// ─── Types ────────────────────────────────────────────────────────────────────

type WizardStep =
  | 'company_profile' | 'legal_entities' | 'worker_categories'
  | 'payroll_components' | 'leave_policy' | 'statutory_config'
  | 'role_setup' | 'confirmation';

type IndustryPreset = 'it_services' | 'manufacturing' | 'school' | 'startup' | 'consulting';
type HealthStatus = 'HEALTHY' | 'ATTENTION' | 'ACTION_REQUIRED';

interface Issue { id: string; severity: string; title: string; description: string; recommendation: string; fixRoute?: string; category: string; }
interface HealthDim { label: string; score: number; status: HealthStatus; issues: string[]; }

// ─── API ──────────────────────────────────────────────────────────────────────

const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${tok()}`, 'Content-Type': 'application/json', ...((opts?.headers ?? {}) as any) },
  }).then(r => r.json()).then(r => r.data ?? r);

// ─── Constants ────────────────────────────────────────────────────────────────

const STEPS: { key: WizardStep; label: string; icon: any }[] = [
  { key: 'company_profile',    label: 'Company',    icon: Building2 },
  { key: 'legal_entities',     label: 'Entities',   icon: FileText },
  { key: 'worker_categories',  label: 'Workers',    icon: Users },
  { key: 'payroll_components', label: 'Payroll',    icon: BarChart3 },
  { key: 'leave_policy',       label: 'Leave',      icon: Activity },
  { key: 'statutory_config',   label: 'Statutory',  icon: Shield },
  { key: 'role_setup',         label: 'Roles',      icon: UserCheck },
  { key: 'confirmation',       label: 'Confirm',    icon: Check },
];

const PRESETS: { id: IndustryPreset; label: string; icon: string; desc: string }[] = [
  { id: 'it_services',   label: 'IT Services',   icon: '💻', desc: 'Software, SaaS, Product' },
  { id: 'manufacturing', label: 'Manufacturing', icon: '🏭', desc: 'Factory, Industrial' },
  { id: 'school',        label: 'Education',     icon: '🏫', desc: 'School, College, Coaching' },
  { id: 'startup',       label: 'Startup',       icon: '🚀', desc: 'Early-stage, fast-growing' },
  { id: 'consulting',    label: 'Consulting',    icon: '📊', desc: 'Professional services' },
];

const INDIAN_STATES = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
  'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
  'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
  'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
  'Delhi', 'Puducherry', 'Chandigarh',
];

// ─── Field component ──────────────────────────────────────────────────────────

function Field({ label, required, error, children }: {
  label: string; required?: boolean; error?: string; children: React.ReactNode;
}) {
  return (
    <div>
      <label className="font-pixel text-[7px] text-primary-700 block mb-1.5">
        {label}{required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      {children}
      {error && <p className="font-mono text-[9px] text-red-400 mt-0.5">{error}</p>}
    </div>
  );
}

const input = "w-full bg-retro-bg border border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none";
const select = "w-full bg-retro-bg border border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none";

// ─── Step panels ──────────────────────────────────────────────────────────────

function StepCompanyProfile({ data, onChange }: { data: any; onChange: (d: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...data, [k]: v });
  const setAddr = (k: string, v: any) => onChange({ ...data, address: { ...(data.address ?? {}), [k]: v } });
  const setContact = (k: string, v: any) => onChange({ ...data, primaryContact: { ...(data.primaryContact ?? {}), [k]: v } });

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <Field label="Company Name" required>
          <input className={input} value={data.companyName ?? ''} onChange={e => set('companyName', e.target.value)} placeholder="Acme Technologies Pvt Ltd" />
        </Field>
        <Field label="Company Size" required>
          <select className={select} value={data.companySize ?? ''} onChange={e => set('companySize', e.target.value)}>
            <option value="">Select...</option>
            {[['micro','Micro (1–10)'],['small','Small (11–50)'],['medium','Medium (51–250)'],['large','Large (251–1000)'],['enterprise','Enterprise (1000+)']].map(([v,l])=>(
              <option key={v} value={v}>{l}</option>
            ))}
          </select>
        </Field>
        <Field label="Website">
          <input className={input} value={data.website ?? ''} onChange={e => set('website', e.target.value)} placeholder="https://acme.in" />
        </Field>
        <Field label="Incorporation Year">
          <input className={input} type="number" value={data.incorporationYear ?? ''} onChange={e => set('incorporationYear', parseInt(e.target.value))} placeholder="2018" />
        </Field>
      </div>

      <div className="border-t border-retro-border pt-4">
        <div className="font-pixel text-[7px] text-primary-600 mb-3">PRIMARY CONTACT</div>
        <div className="grid grid-cols-2 gap-3">
          {[['name','Contact Name'],['email','Email'],['phone','Phone'],['designation','Designation']].map(([k,l])=>(
            <Field key={k} label={l} required={k==='name'||k==='email'}>
              <input className={input} value={data.primaryContact?.[k] ?? ''} onChange={e => setContact(k, e.target.value)} />
            </Field>
          ))}
        </div>
      </div>

      <div className="border-t border-retro-border pt-4">
        <div className="font-pixel text-[7px] text-primary-600 mb-3">REGISTERED ADDRESS</div>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2"><Field label="Address Line 1"><input className={input} value={data.address?.line1 ?? ''} onChange={e => setAddr('line1', e.target.value)} /></Field></div>
          <Field label="City"><input className={input} value={data.address?.city ?? ''} onChange={e => setAddr('city', e.target.value)} /></Field>
          <Field label="State">
            <select className={select} value={data.address?.state ?? ''} onChange={e => setAddr('state', e.target.value)}>
              <option value="">Select state...</option>
              {INDIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="PIN Code"><input className={input} value={data.address?.pincode ?? ''} onChange={e => setAddr('pincode', e.target.value)} placeholder="400001" /></Field>
        </div>
      </div>
    </div>
  );
}

function StepLegalEntities({ data, onChange }: { data: any[]; onChange: (d: any[]) => void }) {
  const add = () => onChange([...data, { name: '', pan: '', isHeadquarters: data.length === 0, stateCode: '' }]);
  const remove = (i: number) => onChange(data.filter((_, idx) => idx !== i));
  const update = (i: number, k: string, v: any) => onChange(data.map((e, idx) => idx === i ? { ...e, [k]: v } : e));

  return (
    <div className="space-y-4">
      {data.map((entity, i) => (
        <div key={i} className="border border-retro-border rounded p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-pixel text-[8px] text-primary-500">ENTITY {i + 1}{entity.isHeadquarters ? ' (HQ)' : ''}</span>
            {data.length > 1 && <button onClick={() => remove(i)} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Entity Name" required><input className={input} value={entity.name} onChange={e => update(i,'name',e.target.value)} placeholder="Acme Technologies Pvt Ltd" /></Field>
            <Field label="State" required>
              <select className={select} value={entity.stateCode} onChange={e => update(i,'stateCode',e.target.value)}>
                <option value="">Select...</option>
                {INDIAN_STATES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Company PAN" required><input className={input} value={entity.pan} onChange={e => update(i,'pan',e.target.value.toUpperCase())} placeholder="AABCA1234Z" maxLength={10} /></Field>
            <Field label="TAN Number"><input className={input} value={entity.tan??''} onChange={e => update(i,'tan',e.target.value.toUpperCase())} placeholder="MUMA12345B" /></Field>
            <Field label="PF Registration No."><input className={input} value={entity.pfRegistrationNumber??''} onChange={e => update(i,'pfRegistrationNumber',e.target.value)} placeholder="MH/BOM/123456" /></Field>
            <Field label="ESI Registration No."><input className={input} value={entity.esiRegistrationNumber??''} onChange={e => update(i,'esiRegistrationNumber',e.target.value)} /></Field>
            <Field label="GST Number"><input className={input} value={entity.gstNumber??''} onChange={e => update(i,'gstNumber',e.target.value.toUpperCase())} placeholder="27AABCA1234Z1Z5" /></Field>
            <Field label="CIN (optional)"><input className={input} value={entity.cin??''} onChange={e => update(i,'cin',e.target.value.toUpperCase())} placeholder="U72900MH2018PTC308000" /></Field>
          </div>
          <div className="border-t border-retro-border/30 pt-3">
            <div className="font-pixel text-[6px] text-primary-700 mb-2">SALARY CREDIT BANK ACCOUNT</div>
            <div className="grid grid-cols-3 gap-3">
              <Field label="Account Number"><input className={input} value={entity.bankAccountNumber??''} onChange={e => update(i,'bankAccountNumber',e.target.value)} /></Field>
              <Field label="IFSC"><input className={input} value={entity.bankIfsc??''} onChange={e => update(i,'bankIfsc',e.target.value.toUpperCase())} placeholder="HDFC0001234" /></Field>
              <Field label="Bank Name"><input className={input} value={entity.bankName??''} onChange={e => update(i,'bankName',e.target.value)} placeholder="HDFC Bank" /></Field>
            </div>
          </div>
        </div>
      ))}
      <button onClick={add} className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-retro-border rounded font-pixel text-[7px] text-primary-700 hover:border-primary-700 hover:text-primary-500">
        <Plus className="w-3 h-3" /> ADD LEGAL ENTITY
      </button>
    </div>
  );
}

function StepWorkerCategories({ data, onChange }: { data: any[]; onChange: (d: any[]) => void }) {
  const add = () => onChange([...data, { code: '', name: '', applyPF: true, applyESI: false, isContractWorker: false }]);
  const remove = (i: number) => onChange(data.filter((_, idx) => idx !== i));
  const update = (i: number, k: string, v: any) => onChange(data.map((c, idx) => idx === i ? { ...c, [k]: v } : c));

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 p-3 bg-blue-950/20 border border-blue-800/30 rounded">
        <Info className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
        <span className="font-mono text-[10px] text-blue-300">Worker categories control PF and ESI applicability for each employee type. At least one category is required.</span>
      </div>
      {data.map((cat, i) => (
        <div key={i} className="border border-retro-border rounded p-3">
          <div className="flex items-center justify-between mb-3">
            <span className="font-pixel text-[7px] text-primary-600">CATEGORY {i+1}</span>
            {data.length > 1 && <button onClick={() => remove(i)} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>}
          </div>
          <div className="grid grid-cols-3 gap-3 mb-3">
            <Field label="Code"><input className={input} value={cat.code} onChange={e => update(i,'code',e.target.value.toUpperCase())} placeholder="REGULAR" /></Field>
            <div className="col-span-2"><Field label="Name"><input className={input} value={cat.name} onChange={e => update(i,'name',e.target.value)} placeholder="Regular Employee" /></Field></div>
          </div>
          <div className="flex gap-6">
            {[['applyPF','Apply PF'],['applyESI','Apply ESI'],['isContractWorker','Contract Worker']].map(([k,l])=>(
              <label key={k} className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={!!(cat as any)[k]} onChange={e => update(i,k,e.target.checked)} className="accent-primary-crt" />
                <span className="font-pixel text-[7px] text-primary-600">{l}</span>
              </label>
            ))}
          </div>
        </div>
      ))}
      <button onClick={add} className="w-full flex items-center justify-center gap-2 py-2 border-2 border-dashed border-retro-border rounded font-pixel text-[7px] text-primary-700 hover:border-primary-700 hover:text-primary-500">
        <Plus className="w-3 h-3" /> ADD CATEGORY
      </button>
    </div>
  );
}

function StepPayrollComponents({ data, onChange }: { data: any[]; onChange: (d: any[]) => void }) {
  const add = () => onChange([...data, { code: '', name: '', type: 'FORMULA', formula: '', isTaxable: true, isDeduction: false }]);
  const remove = (i: number) => onChange(data.filter((_, idx) => idx !== i));
  const update = (i: number, k: string, v: any) => onChange(data.map((c, idx) => idx === i ? { ...c, [k]: v } : c));

  return (
    <div className="space-y-3">
      {data.map((comp, i) => (
        <div key={i} className="border border-retro-border rounded p-3">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className={`font-pixel text-[6px] px-2 py-0.5 rounded border ${comp.isDeduction ? 'text-red-400 border-red-800' : 'text-green-400 border-green-800'}`}>
                {comp.isDeduction ? 'DEDUCTION' : 'EARNING'}
              </span>
              <span className="font-pixel text-[6px] text-primary-700 border border-primary-800 px-2 py-0.5 rounded">{comp.type}</span>
            </div>
            <button onClick={() => remove(i)} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>
          </div>
          <div className="grid grid-cols-3 gap-3 mb-3">
            <Field label="Code"><input className={input} value={comp.code} onChange={e => update(i,'code',e.target.value.toUpperCase())} placeholder="BASIC" /></Field>
            <Field label="Name"><input className={input} value={comp.name} onChange={e => update(i,'name',e.target.value)} placeholder="Basic Salary" /></Field>
            <Field label="Type">
              <select className={select} value={comp.type} onChange={e => update(i,'type',e.target.value)}>
                <option value="FIXED">FIXED</option>
                <option value="FORMULA">FORMULA</option>
                <option value="STATUTORY">STATUTORY</option>
              </select>
            </Field>
          </div>
          {comp.type === 'FORMULA' && (
            <Field label="Formula">
              <input className={input} value={comp.formula??''} onChange={e => update(i,'formula',e.target.value)} placeholder="e.g. BASIC * 0.5" />
            </Field>
          )}
          <div className="flex gap-6 mt-2">
            {[['isTaxable','Taxable'],['isDeduction','Deduction']].map(([k,l])=>(
              <label key={k} className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={!!(comp as any)[k]} onChange={e => update(i,k,e.target.checked)} className="accent-primary-crt" />
                <span className="font-pixel text-[7px] text-primary-600">{l}</span>
              </label>
            ))}
          </div>
        </div>
      ))}
      <button onClick={add} className="w-full flex items-center justify-center gap-2 py-2 border-2 border-dashed border-retro-border rounded font-pixel text-[7px] text-primary-700 hover:border-primary-700 hover:text-primary-500">
        <Plus className="w-3 h-3" /> ADD COMPONENT
      </button>
    </div>
  );
}

function StepLeavePolicy({ data, onChange }: { data: any[]; onChange: (d: any[]) => void }) {
  const add = () => onChange([...data, { code: '', name: '', daysPerYear: 12, carryForward: false, maxCarryForward: 0, encashable: false, paidLeave: true }]);
  const remove = (i: number) => onChange(data.filter((_, idx) => idx !== i));
  const update = (i: number, k: string, v: any) => onChange(data.map((lt, idx) => idx === i ? { ...lt, [k]: v } : lt));

  return (
    <div className="space-y-3">
      {data.map((lt, i) => (
        <div key={i} className="border border-retro-border rounded p-3">
          <div className="flex items-center justify-between mb-3">
            <span className="font-pixel text-[7px] text-primary-500">LEAVE TYPE {i+1}</span>
            {data.length > 1 && <button onClick={() => remove(i)} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>}
          </div>
          <div className="grid grid-cols-3 gap-3 mb-2">
            <Field label="Code"><input className={input} value={lt.code} onChange={e => update(i,'code',e.target.value.toUpperCase())} placeholder="EL" /></Field>
            <div className="col-span-2"><Field label="Name"><input className={input} value={lt.name} onChange={e => update(i,'name',e.target.value)} placeholder="Earned Leave" /></Field></div>
            <Field label="Days / Year"><input className={input} type="number" min={0} value={lt.daysPerYear} onChange={e => update(i,'daysPerYear',parseInt(e.target.value)||0)} /></Field>
            <Field label="Max Carry Forward"><input className={input} type="number" min={0} value={lt.maxCarryForward} onChange={e => update(i,'maxCarryForward',parseInt(e.target.value)||0)} /></Field>
          </div>
          <div className="flex gap-6">
            {[['paidLeave','Paid Leave'],['carryForward','Carry Forward'],['encashable','Encashable']].map(([k,l])=>(
              <label key={k} className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox" checked={!!(lt as any)[k]} onChange={e => update(i,k,e.target.checked)} className="accent-primary-crt" />
                <span className="font-pixel text-[7px] text-primary-600">{l}</span>
              </label>
            ))}
          </div>
        </div>
      ))}
      <button onClick={add} className="w-full flex items-center justify-center gap-2 py-2 border-2 border-dashed border-retro-border rounded font-pixel text-[7px] text-primary-700 hover:border-primary-700 hover:text-primary-500">
        <Plus className="w-3 h-3" /> ADD LEAVE TYPE
      </button>
    </div>
  );
}

function StepStatutory({ data, onChange }: { data: any; onChange: (d: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...data, [k]: v });
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {/* PF */}
        <div className="border border-retro-border rounded p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-pixel text-[8px] text-primary-500">PROVIDENT FUND</span>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={data.pfApplicable??true} onChange={e => set('pfApplicable',e.target.checked)} className="accent-primary-crt" />
              <span className="font-pixel text-[7px] text-primary-600">Applicable</span>
            </label>
          </div>
          <Field label="PF Wage Ceiling (₹)">
            <input className={input} type="number" value={data.pfWageCeiling??15000} onChange={e => set('pfWageCeiling',parseInt(e.target.value))} />
          </Field>
        </div>
        {/* ESI */}
        <div className="border border-retro-border rounded p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-pixel text-[8px] text-primary-500">ESI</span>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={data.esiApplicable??false} onChange={e => set('esiApplicable',e.target.checked)} className="accent-primary-crt" />
              <span className="font-pixel text-[7px] text-primary-600">Applicable</span>
            </label>
          </div>
          <Field label="ESI Wage Ceiling (₹)">
            <input className={input} type="number" value={data.esiWageCeiling??21000} onChange={e => set('esiWageCeiling',parseInt(e.target.value))} />
          </Field>
        </div>
        {/* TDS */}
        <div className="border border-retro-border rounded p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-pixel text-[8px] text-primary-500">TDS</span>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={data.tdsApplicable??true} onChange={e => set('tdsApplicable',e.target.checked)} className="accent-primary-crt" />
              <span className="font-pixel text-[7px] text-primary-600">Applicable</span>
            </label>
          </div>
          <Field label="Default Tax Regime">
            <select className={select} value={data.defaultTaxRegime??'new'} onChange={e => set('defaultTaxRegime',e.target.value)}>
              <option value="new">New Regime (Default FY25+)</option>
              <option value="old">Old Regime</option>
            </select>
          </Field>
        </div>
        {/* PT */}
        <div className="border border-retro-border rounded p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-pixel text-[8px] text-primary-500">PROFESSIONAL TAX</span>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={data.professionalTaxApplicable??true} onChange={e => set('professionalTaxApplicable',e.target.checked)} className="accent-primary-crt" />
              <span className="font-pixel text-[7px] text-primary-600">Applicable</span>
            </label>
          </div>
        </div>
      </div>
      {/* Payroll calendar */}
      <div className="border border-retro-border rounded p-4">
        <div className="font-pixel text-[7px] text-primary-600 mb-3">PAYROLL CALENDAR</div>
        <div className="grid grid-cols-3 gap-3">
          <Field label="Payroll Cutoff Day"><input className={input} type="number" min={1} max={31} value={data.payrollCutoffDay??25} onChange={e => set('payrollCutoffDay',parseInt(e.target.value))} /></Field>
          <Field label="Salary Credit Day"><input className={input} type="number" min={1} max={10} value={data.salaryCredDay??1} onChange={e => set('salaryCredDay',parseInt(e.target.value))} /></Field>
          <Field label="Attendance Grace (mins)"><input className={input} type="number" min={0} value={data.lateMarkGraceMins??15} onChange={e => set('lateMarkGraceMins',parseInt(e.target.value))} /></Field>
        </div>
      </div>
    </div>
  );
}

function StepRoleSetup({ data, onChange }: { data: any[]; onChange: (d: any[]) => void }) {
  const ROLE_OPTIONS = [
    { value: 'super-admin', label: 'Super Admin — full system access' },
    { value: 'hr-admin', label: 'HR Admin — manage people, payroll, leave' },
    { value: 'cfo', label: 'CFO — payroll approval, financial reports' },
    { value: 'finance-controller', label: 'Finance Controller — TDS, PF, reports' },
    { value: 'manager', label: 'Manager — team leave approval, reports' },
  ];
  const add = () => onChange([...data, { roleName: '', assigneeEmail: '', permissions: [] }]);
  const remove = (i: number) => onChange(data.filter((_, idx) => idx !== i));
  const update = (i: number, k: string, v: any) => onChange(data.map((r, idx) => idx === i ? { ...r, [k]: v } : r));

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 p-3 bg-amber-950/20 border border-amber-800/30 rounded">
        <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
        <span className="font-mono text-[10px] text-amber-300">At minimum, assign an HR Admin and a CFO/Finance role. Payroll approval requires a finance role.</span>
      </div>
      {data.map((role, i) => (
        <div key={i} className="border border-retro-border rounded p-3">
          <div className="flex items-center justify-between mb-3">
            <span className="font-pixel text-[7px] text-primary-500">ROLE ASSIGNMENT {i+1}</span>
            {data.length > 1 && <button onClick={() => remove(i)} className="text-primary-800 hover:text-red-400"><Trash2 className="w-3 h-3" /></button>}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Role" required>
              <select className={select} value={role.roleName} onChange={e => update(i,'roleName',e.target.value)}>
                <option value="">Select role...</option>
                {ROLE_OPTIONS.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
              </select>
            </Field>
            <Field label="Assignee Email" required>
              <input className={input} type="email" value={role.assigneeEmail} onChange={e => update(i,'assigneeEmail',e.target.value)} placeholder="admin@company.com" />
            </Field>
          </div>
        </div>
      ))}
      <button onClick={add} className="w-full flex items-center justify-center gap-2 py-2 border-2 border-dashed border-retro-border rounded font-pixel text-[7px] text-primary-700 hover:border-primary-700 hover:text-primary-500">
        <Plus className="w-3 h-3" /> ADD ROLE ASSIGNMENT
      </button>
    </div>
  );
}

function StepConfirmation({ state }: { state: any }) {
  const checks = [
    { label: 'Company Profile', ok: !!state.companyProfile?.companyName },
    { label: 'Legal Entity with PAN', ok: state.legalEntities?.some((e: any) => e.pan) },
    { label: 'Worker Categories', ok: state.workerCategories?.length > 0 },
    { label: 'Payroll Components', ok: state.payrollComponents?.length > 0 },
    { label: 'Leave Types', ok: state.leaveTypes?.length > 0 },
    { label: 'HR Admin Role', ok: state.roles?.some((r: any) => ['hr-admin','super-admin'].includes(r.roleName)) },
  ];
  const allOk = checks.every(c => c.ok);
  return (
    <div className="space-y-4">
      <div className={`p-4 rounded border ${allOk ? 'bg-green-950/20 border-green-800' : 'bg-amber-950/20 border-amber-800'}`}>
        <div className="flex items-center gap-2 mb-3">
          {allOk ? <CheckCircle className="w-5 h-5 text-green-400" /> : <AlertTriangle className="w-5 h-5 text-amber-400" />}
          <span className="font-pixel text-[9px] text-primary-400">
            {allOk ? 'READY TO ACTIVATE' : 'REVIEW REQUIRED ITEMS'}
          </span>
        </div>
        <div className="space-y-2">
          {checks.map(c => (
            <div key={c.label} className="flex items-center gap-2">
              {c.ok ? <CheckCircle className="w-3 h-3 text-green-400" /> : <AlertCircle className="w-3 h-3 text-red-400" />}
              <span className="font-mono text-xs text-primary-500">{c.label}</span>
            </div>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3 text-center">
        {[
          ['Legal Entities', state.legalEntities?.length ?? 0],
          ['Leave Types', state.leaveTypes?.length ?? 0],
          ['Payroll Components', state.payrollComponents?.length ?? 0],
          ['Worker Categories', state.workerCategories?.length ?? 0],
          ['Role Assignments', state.roles?.length ?? 0],
        ].map(([l, v]) => (
          <div key={String(l)} className="border border-retro-border rounded p-3">
            <div className="font-pixel text-[11px] text-primary-crt">{v}</div>
            <div className="font-pixel text-[6px] text-primary-700 mt-0.5">{l}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Health Score Panel ───────────────────────────────────────────────────────

function HealthScorePanel() {
  const { data: score, refetch, isLoading } = useQuery({
    queryKey: ['health-score'],
    queryFn: () => api('/setup-wizard/health-score'),
  });
  const validate = useMutation({ mutationFn: () => api('/setup-wizard/validate', { method: 'POST' }), onSuccess: () => refetch() });

  const statusColor: Record<string, string> = {
    HEALTHY: 'text-green-400', ATTENTION: 'text-amber-400', ACTION_REQUIRED: 'text-red-400',
  };
  const statusBg: Record<string, string> = {
    HEALTHY: 'bg-green-950/20 border-green-800', ATTENTION: 'bg-amber-950/20 border-amber-800', ACTION_REQUIRED: 'bg-red-950/20 border-red-800',
  };
  const statusEmoji: Record<string, string> = { HEALTHY: '🟢', ATTENTION: '🟡', ACTION_REQUIRED: '🔴' };

  if (isLoading) return <div className="font-mono text-xs text-primary-700 animate-pulse">Computing health score...</div>;

  const dims: Record<string, HealthDim> = score?.dimensions ?? {};

  return (
    <div className="space-y-4">
      {/* Overall */}
      <div className={`p-4 rounded border ${statusBg[score?.status ?? 'ATTENTION'] ?? ''}`}>
        <div className="flex items-center justify-between">
          <div>
            <div className="font-pixel text-[7px] text-primary-700 mb-1">TENANT HEALTH SCORE</div>
            <div className={`font-pixel text-[18px] ${statusColor[score?.status ?? 'ATTENTION']}`}>
              {score?.overallScore ?? 0}/100
            </div>
            <div className={`font-pixel text-[8px] mt-0.5 ${statusColor[score?.status ?? 'ATTENTION']}`}>
              {statusEmoji[score?.status ?? 'ATTENTION']} {(score?.status ?? '').replace('_', ' ')}
            </div>
          </div>
          <button onClick={() => validate.mutate()} disabled={validate.isPending}
            className="flex items-center gap-1.5 px-3 py-2 border border-retro-border rounded font-pixel text-[6px] text-primary-600 hover:text-primary-400">
            <RefreshCw className={`w-3 h-3 ${validate.isPending ? 'animate-spin' : ''}`} /> RE-SCAN
          </button>
        </div>
        {/* Score bar */}
        <div className="mt-3 h-2 bg-retro-bg rounded overflow-hidden">
          <div className={`h-full transition-all ${
            (score?.overallScore ?? 0) >= 85 ? 'bg-green-500' :
            (score?.overallScore ?? 0) >= 60 ? 'bg-amber-500' : 'bg-red-500'
          }`} style={{ width: `${score?.overallScore ?? 0}%` }} />
        </div>
      </div>

      {/* Dimensions */}
      <div className="grid grid-cols-1 gap-2">
        {Object.values(dims).map((dim: HealthDim) => (
          <div key={dim.label} className="flex items-center gap-3 px-3 py-2 border border-retro-border rounded">
            <div className="w-28 font-pixel text-[6px] text-primary-700 flex-shrink-0">{dim.label.toUpperCase()}</div>
            <div className="flex-1 h-1.5 bg-retro-bg rounded overflow-hidden">
              <div className={`h-full ${dim.score >= 85 ? 'bg-green-500' : dim.score >= 60 ? 'bg-amber-500' : 'bg-red-500'}`}
                style={{ width: `${dim.score}%` }} />
            </div>
            <div className="w-10 font-pixel text-[7px] text-right text-primary-600">{dim.score}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Fix-Now Panel ─────────────────────────────────────────────────────────────

function FixNowPanel({ issues }: { issues: Issue[] }) {
  const critical = issues.filter(i => i.severity === 'CRITICAL');
  const high = issues.filter(i => i.severity === 'HIGH');
  const visible = [...critical, ...high].slice(0, 5);

  if (visible.length === 0) {
    return (
      <div className="flex items-center gap-2 p-3 bg-green-950/20 border border-green-800 rounded">
        <CheckCircle className="w-4 h-4 text-green-400" />
        <span className="font-pixel text-[7px] text-green-400">No critical issues detected</span>
      </div>
    );
  }

  const sevColor: Record<string, string> = { CRITICAL: 'text-red-400 border-red-800 bg-red-950/20', HIGH: 'text-amber-400 border-amber-800 bg-amber-950/20' };

  return (
    <div className="space-y-2">
      <div className="font-pixel text-[7px] text-primary-600 flex items-center gap-2">
        <AlertTriangle className="w-3 h-3 text-amber-500" /> FIX NOW — {critical.length} CRITICAL · {high.length} HIGH
      </div>
      {visible.map(issue => (
        <div key={issue.id} className={`px-3 py-2.5 rounded border ${sevColor[issue.severity] ?? ''}`}>
          <div className="flex items-start justify-between gap-2">
            <div>
              <div className="font-pixel text-[7px] mb-0.5">{issue.title}</div>
              <div className="font-mono text-[9px] text-primary-700">{issue.description}</div>
            </div>
            {issue.fixRoute && (
              <a href={issue.fixRoute} className="flex-shrink-0 flex items-center gap-1 font-pixel text-[6px] border border-current rounded px-2 py-0.5 hover:opacity-80">
                FIX <ArrowRight className="w-2.5 h-2.5" />
              </a>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Migration Assistant ───────────────────────────────────────────────────────

function MigrationAssistant() {
  const [entity, setEntity] = useState<string>('employees');
  const [csvContent, setCsvContent] = useState('');
  const [csvHeaders, setCsvHeaders] = useState<string[]>([]);
  const [mappings, setMappings] = useState<any[]>([]);
  const [preview, setPreview] = useState<any>(null);
  const [dryRun, setDryRun] = useState<any>(null);
  const [phase, setPhase] = useState<'upload' | 'map' | 'preview' | 'confirm'>('upload');
  const fileRef = useRef<HTMLInputElement>(null);

  const parse = useMutation({
    mutationFn: () => api('/setup-wizard/migration/parse', {
      method: 'POST', body: JSON.stringify({ csvContent, entity }),
    }),
    onSuccess: (data) => {
      setCsvHeaders(data.csvHeaders ?? []);
      setMappings(data.suggestedMappings ?? []);
      setPhase('map');
    },
  });

  const previewMut = useMutation({
    mutationFn: () => api('/setup-wizard/migration/preview', {
      method: 'POST', body: JSON.stringify({ csvContent, entity, mappings }),
    }),
    onSuccess: (data) => { setPreview(data); setPhase('preview'); },
  });

  const dryRunMut = useMutation({
    mutationFn: () => api('/setup-wizard/migration/dry-run', {
      method: 'POST', body: JSON.stringify({ csvContent, entity, mappings }),
    }),
    onSuccess: (data) => { setDryRun(data); setPhase('confirm'); },
  });

  const commitMut = useMutation({
    mutationFn: () => api('/setup-wizard/migration/commit', {
      method: 'POST', body: JSON.stringify({ csvContent, entity, mappings }),
    }),
  });

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setCsvContent(ev.target?.result as string ?? '');
    reader.readAsText(file);
  };

  const TARGET_FIELDS: Record<string, { field: string; label: string; required: boolean }[]> = {
    employees: [
      { field: 'employeeCode', label: 'Employee ID', required: true },
      { field: 'firstName', label: 'First Name', required: true },
      { field: 'lastName', label: 'Last Name', required: true },
      { field: 'email', label: 'Work Email', required: true },
      { field: 'dateOfJoining', label: 'Date of Joining', required: true },
      { field: 'department', label: 'Department', required: false },
      { field: 'designation', label: 'Designation', required: false },
      { field: 'ctc', label: 'Annual CTC', required: false },
      { field: 'panNumber', label: 'PAN', required: false },
      { field: 'bankAccountNumber', label: 'Bank Account', required: false },
      { field: 'bankIfsc', label: 'IFSC', required: false },
    ],
  };

  const targets = TARGET_FIELDS[entity] ?? [];

  return (
    <div className="space-y-4">
      {/* Phase: Upload */}
      {phase === 'upload' && (
        <div className="space-y-4">
          <div className="grid grid-cols-5 gap-2">
            {['employees','departments','designations','leaves','salary_structures'].map(e => (
              <button key={e} onClick={() => setEntity(e)}
                className={`py-2 rounded border font-pixel text-[6px] transition-all ${entity===e ? 'bg-primary-950 border-primary-700 text-primary-crt' : 'border-retro-border text-primary-700 hover:border-primary-700'}`}>
                {e.toUpperCase().replace('_','\n')}
              </button>
            ))}
          </div>
          <div
            onClick={() => fileRef.current?.click()}
            className="flex flex-col items-center justify-center p-12 border-2 border-dashed border-retro-border rounded cursor-pointer hover:border-primary-700 hover:bg-primary-950/10 transition-all"
          >
            <Upload className="w-8 h-8 text-primary-700 mb-3" />
            <div className="font-pixel text-[8px] text-primary-600">DROP CSV FILE OR CLICK TO BROWSE</div>
            <div className="font-mono text-[10px] text-primary-800 mt-1">Supports UTF-8 CSV with header row</div>
            {csvContent && <div className="mt-2 font-pixel text-[7px] text-green-400">✓ File loaded ({csvContent.split('\n').length} lines)</div>}
          </div>
          <input ref={fileRef} type="file" accept=".csv" onChange={handleFile} className="hidden" />
          {csvContent && (
            <button onClick={() => parse.mutate()} disabled={parse.isPending}
              className="w-full py-2.5 bg-primary-900 border border-primary-700 font-pixel text-[7px] text-primary-crt rounded hover:bg-primary-800 disabled:opacity-40">
              {parse.isPending ? 'PARSING...' : 'PARSE & MAP FIELDS →'}
            </button>
          )}
        </div>
      )}

      {/* Phase: Map */}
      {phase === 'map' && (
        <div className="space-y-3">
          <div className="font-pixel text-[8px] text-primary-600">MAP CSV COLUMNS → TARGET FIELDS</div>
          <div className="font-mono text-[10px] text-primary-700">Columns auto-matched. Review and adjust as needed.</div>
          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {targets.map(target => {
              const mapping = mappings.find(m => m.targetField === target.field);
              return (
                <div key={target.field} className="flex items-center gap-3 py-2 border-b border-retro-border/20">
                  <div className="w-36 flex-shrink-0">
                    <div className="font-pixel text-[6px] text-primary-600">{target.label}</div>
                    {target.required && <span className="font-pixel text-[5px] text-red-500">REQUIRED</span>}
                  </div>
                  <ArrowRight className="w-3 h-3 text-primary-800 flex-shrink-0" />
                  <select
                    value={mapping?.csvColumn ?? ''}
                    onChange={e => setMappings(prev => prev.map(m =>
                      m.targetField === target.field ? { ...m, csvColumn: e.target.value } : m
                    ))}
                    className="flex-1 bg-retro-bg border border-retro-border rounded px-2 py-1 font-mono text-xs text-primary-400 focus:border-primary-crt outline-none"
                  >
                    <option value="">— Skip this field —</option>
                    {csvHeaders.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                  {mapping?.csvColumn && <CheckCircle className="w-3 h-3 text-green-500 flex-shrink-0" />}
                  {!mapping?.csvColumn && target.required && <AlertCircle className="w-3 h-3 text-red-500 flex-shrink-0" />}
                </div>
              );
            })}
          </div>
          <div className="flex gap-2">
            <button onClick={() => setPhase('upload')} className="px-4 py-2 border border-retro-border rounded font-pixel text-[7px] text-primary-700 hover:text-primary-500">← BACK</button>
            <button onClick={() => previewMut.mutate()} disabled={previewMut.isPending}
              className="flex-1 py-2 bg-primary-900 border border-primary-700 font-pixel text-[7px] text-primary-crt rounded hover:bg-primary-800 disabled:opacity-40">
              {previewMut.isPending ? 'BUILDING PREVIEW...' : 'PREVIEW DATA →'}
            </button>
          </div>
        </div>
      )}

      {/* Phase: Preview */}
      {phase === 'preview' && preview && (
        <div className="space-y-3">
          <div className="grid grid-cols-4 gap-3 text-center">
            {[['Total Rows', preview.totalRows], ['Valid', preview.validRows, 'text-green-400'], ['Errors', preview.errorRows, 'text-red-400'], ['Duplicates', preview.duplicateRows, 'text-amber-400']].map(([l,v,c='text-primary-crt']) => (
              <div key={String(l)} className="border border-retro-border rounded p-3">
                <div className={`font-pixel text-[13px] ${c}`}>{v}</div>
                <div className="font-pixel text-[6px] text-primary-700 mt-0.5">{l}</div>
              </div>
            ))}
          </div>
          {preview.errors.length > 0 && (
            <div className="max-h-40 overflow-y-auto space-y-1">
              {preview.errors.slice(0,10).map((e: any, i: number) => (
                <div key={i} className="font-mono text-[9px] text-red-400 px-2 py-1 bg-red-950/10 rounded">
                  Row {e.row}: {e.column} — {e.error}
                </div>
              ))}
            </div>
          )}
          {preview.sampleData.length > 0 && (
            <div className="overflow-x-auto">
              <div className="font-pixel text-[6px] text-primary-700 mb-1">SAMPLE (first 5 valid rows)</div>
              <table className="w-full text-[9px] font-mono">
                <thead><tr>{Object.keys(preview.sampleData[0]).slice(0,6).map(k => <th key={k} className="text-left py-1 px-2 text-primary-700">{k}</th>)}</tr></thead>
                <tbody>{preview.sampleData.map((row: any, i: number) => (
                  <tr key={i} className="border-t border-retro-border/20">{Object.values(row).slice(0,6).map((v: any, j) => <td key={j} className="py-1 px-2 text-primary-500 truncate max-w-[100px]">{String(v ?? '')}</td>)}</tr>
                ))}</tbody>
              </table>
            </div>
          )}
          <div className="flex gap-2">
            <button onClick={() => setPhase('map')} className="px-4 py-2 border border-retro-border rounded font-pixel text-[7px] text-primary-700">← BACK</button>
            <button onClick={() => dryRunMut.mutate()} disabled={dryRunMut.isPending || preview.errorRows === preview.totalRows}
              className="flex-1 py-2 bg-primary-900 border border-primary-700 font-pixel text-[7px] text-primary-crt rounded hover:bg-primary-800 disabled:opacity-40">
              {dryRunMut.isPending ? 'RUNNING...' : 'DRY RUN →'}
            </button>
          </div>
        </div>
      )}

      {/* Phase: Confirm */}
      {phase === 'confirm' && dryRun && (
        <div className="space-y-4">
          <div className={`p-4 rounded border ${dryRun.readyToCommit ? 'bg-green-950/20 border-green-800' : 'bg-red-950/20 border-red-800'}`}>
            <div className="font-pixel text-[8px] text-primary-400 mb-2">DRY RUN COMPLETE</div>
            <div className="grid grid-cols-3 gap-3 text-center">
              {[['Will Create', dryRun.summary?.willCreate, 'text-green-400'], ['Will Skip', dryRun.summary?.willSkip, 'text-amber-400'], ['Will Fail', dryRun.summary?.willFail, 'text-red-400']].map(([l,v,c]) => (
                <div key={String(l)}><div className={`font-pixel text-[13px] ${c}`}>{v}</div><div className="font-pixel text-[6px] text-primary-700">{l}</div></div>
              ))}
            </div>
          </div>
          {commitMut.isSuccess && (
            <div className="flex items-center gap-2 p-3 bg-green-950/20 border border-green-800 rounded">
              <CheckCircle className="w-4 h-4 text-green-400" />
              <span className="font-pixel text-[7px] text-green-400">Migration complete — {commitMut.data?.successRows} records imported</span>
            </div>
          )}
          {!commitMut.isSuccess && (
            <div className="flex gap-2">
              <button onClick={() => { setPhase('upload'); setCsvContent(''); setPreview(null); setDryRun(null); }}
                className="px-4 py-2 border border-retro-border rounded font-pixel text-[7px] text-primary-700">CANCEL</button>
              <button onClick={() => commitMut.mutate()} disabled={!dryRun.readyToCommit || commitMut.isPending}
                className="flex-1 py-2 bg-green-900 border border-green-700 font-pixel text-[7px] text-green-300 rounded hover:bg-green-800 disabled:opacity-40">
                {commitMut.isPending ? 'IMPORTING...' : '⚡ COMMIT MIGRATION'}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN WIZARD PAGE
// ─────────────────────────────────────────────────────────────────────────────

export function SetupWizardPage() {
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState<'wizard' | 'health' | 'migration'>('wizard');
  const [selectedPreset, setSelectedPreset] = useState<IndustryPreset | null>(null);
  const [stepData, setStepData] = useState<Record<string, any>>({});

  const { data: wizardState, isLoading } = useQuery({
    queryKey: ['wizard-state'],
    queryFn: () => api('/setup-wizard/state'),
  });

  const { data: validationData } = useQuery({
    queryKey: ['wizard-validation'],
    queryFn: () => api('/setup-wizard/validate').catch(() => null),
    staleTime: 5 * 60 * 1000,
  });

  const currentStepIdx = STEPS.findIndex(s => s.key === (wizardState?.currentStep ?? 'company_profile'));
  const currentStep = STEPS[Math.max(0, currentStepIdx)]!;

  const applyPreset = useMutation({
    mutationFn: (preset: IndustryPreset) => api('/setup-wizard/preset', { method: 'POST', body: JSON.stringify({ preset }) }),
    onSuccess: (data) => {
      qc.invalidateQueries({ queryKey: ['wizard-state'] });
      setStepData(prev => ({
        ...prev,
        payroll_components: data.payrollComponents,
        leave_policy: data.leaveTypes,
        worker_categories: data.workerCategories,
      }));
    },
  });

  const saveStep = useMutation({
    mutationFn: ({ step, data }: { step: WizardStep; data: any }) =>
      api(`/setup-wizard/step/${step}`, { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['wizard-state'] }),
  });

  const handleNext = () => {
    const data = stepData[currentStep.key] ?? {};
    // For confirmation step, merge all state
    const payload = currentStep.key === 'confirmation'
      ? { confirmed: true }
      : data;
    saveStep.mutate({ step: currentStep.key as WizardStep, data: payload });
  };

  const mergedData = {
    ...(wizardState ?? {}),
    ...(stepData[currentStep.key] ? { [currentStep.key]: stepData[currentStep.key] } : {}),
  };

  const getStepData = (step: WizardStep) =>
    stepData[step] ?? (wizardState as any)?.[step.replace('_', '')] ?? (
      step === 'legal_entities' ? (wizardState?.legalEntities ?? []) :
      step === 'worker_categories' ? (wizardState?.workerCategories ?? []) :
      step === 'payroll_components' ? (wizardState?.payrollComponents ?? []) :
      step === 'leave_policy' ? (wizardState?.leaveTypes ?? []) :
      step === 'role_setup' ? (wizardState?.roles ?? []) :
      {}
    );

  const issues: Issue[] = validationData?.validation?.issues ?? [];
  const criticalCount = issues.filter(i => i.severity === 'CRITICAL').length;

  return (
    <div className="flex gap-4 h-full animate-fade-in" style={{ minHeight: '80vh' }}>
      {/* Left nav */}
      <div className="w-48 flex-shrink-0 space-y-1">
        {[
          { key: 'wizard' as const, label: 'SETUP WIZARD', icon: Zap },
          { key: 'health' as const, label: 'HEALTH SCORE', icon: Activity },
          { key: 'migration' as const, label: 'MIGRATE DATA', icon: Upload },
        ].map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setActiveTab(key)}
            className={`w-full flex items-center gap-2 px-3 py-2 rounded text-left transition-all ${activeTab === key ? 'bg-primary-950 border border-primary-700 text-primary-crt' : 'text-primary-700 hover:text-primary-500'}`}>
            <Icon className="w-3 h-3" />
            <span className="font-pixel text-[7px]">{label}</span>
          </button>
        ))}

        {/* Fix-now summary */}
        {criticalCount > 0 && activeTab !== 'health' && (
          <button onClick={() => setActiveTab('health')}
            className="w-full flex items-center gap-2 px-3 py-2 mt-3 rounded border border-red-800 bg-red-950/20 text-red-400">
            <AlertTriangle className="w-3 h-3" />
            <span className="font-pixel text-[6px]">{criticalCount} CRITICAL ISSUE{criticalCount>1?'S':''}</span>
          </button>
        )}
      </div>

      {/* Main content */}
      <div className="flex-1 min-w-0">

        {/* ── WIZARD TAB ──────────────────────────────────────────────── */}
        {activeTab === 'wizard' && (
          <div className="space-y-4">
            {/* Step progress */}
            <div className="flex items-center gap-1">
              {STEPS.map((step, i) => {
                const isComplete = (wizardState?.completedSteps ?? []).includes(step.key);
                const isCurrent = step.key === currentStep.key;
                const Icon = step.icon;
                return (
                  <div key={step.key} className="flex items-center">
                    <div className={`flex items-center gap-1.5 px-2 py-1.5 rounded transition-all ${
                      isCurrent ? 'bg-primary-950 border border-primary-700' :
                      isComplete ? 'opacity-60' : 'opacity-30'
                    }`}>
                      <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${
                        isComplete ? 'bg-green-700' : isCurrent ? 'bg-primary-700' : 'bg-retro-border'
                      }`}>
                        {isComplete ? <Check className="w-2.5 h-2.5 text-white" /> : <Icon className="w-2.5 h-2.5 text-white" />}
                      </div>
                      {isCurrent && <span className="font-pixel text-[6px] text-primary-crt whitespace-nowrap">{step.label}</span>}
                    </div>
                    {i < STEPS.length - 1 && <ChevronRight className="w-3 h-3 text-primary-800 mx-0.5" />}
                  </div>
                );
              })}
            </div>

            {/* Industry preset picker (shown on step 1) */}
            {currentStep.key === 'company_profile' && !selectedPreset && (
              <div className="border border-retro-border rounded p-4 space-y-3">
                <div className="font-pixel text-[8px] text-primary-600">QUICK START — SELECT INDUSTRY PRESET</div>
                <div className="font-mono text-[10px] text-primary-700">Choose your industry to pre-fill leave types, payroll components, and worker categories.</div>
                <div className="grid grid-cols-5 gap-2">
                  {PRESETS.map(p => (
                    <button key={p.id} onClick={() => { setSelectedPreset(p.id); applyPreset.mutate(p.id); }}
                      className="flex flex-col items-center gap-1.5 p-3 border border-retro-border rounded hover:border-primary-700 hover:bg-primary-950/20 transition-all">
                      <span className="text-2xl">{p.icon}</span>
                      <span className="font-pixel text-[6px] text-primary-500 text-center">{p.label}</span>
                      <span className="font-mono text-[8px] text-primary-800 text-center">{p.desc}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            {selectedPreset && (
              <div className="flex items-center gap-2 px-3 py-2 bg-green-950/20 border border-green-800 rounded">
                <CheckCircle className="w-3 h-3 text-green-400" />
                <span className="font-pixel text-[7px] text-green-400">
                  {PRESETS.find(p => p.id === selectedPreset)?.label} preset applied — leave types, payroll components, and worker categories pre-filled.
                </span>
                <button onClick={() => setSelectedPreset(null)} className="ml-auto text-primary-800 hover:text-primary-600"><X className="w-3 h-3" /></button>
              </div>
            )}

            {/* Current step content */}
            <div className="border border-retro-border rounded p-4">
              <div className="font-pixel text-[9px] text-primary-500 mb-4">
                STEP {currentStepIdx + 1} / {STEPS.length} — {currentStep.label.toUpperCase()}
              </div>

              {isLoading ? (
                <div className="font-mono text-xs text-primary-700 animate-pulse py-8 text-center">Loading...</div>
              ) : currentStep.key === 'company_profile' ? (
                <StepCompanyProfile
                  data={stepData.company_profile ?? wizardState?.companyProfile ?? {}}
                  onChange={d => setStepData(p => ({ ...p, company_profile: d }))}
                />
              ) : currentStep.key === 'legal_entities' ? (
                <StepLegalEntities
                  data={getStepData('legal_entities') as any[]}
                  onChange={d => setStepData(p => ({ ...p, legal_entities: d }))}
                />
              ) : currentStep.key === 'worker_categories' ? (
                <StepWorkerCategories
                  data={getStepData('worker_categories') as any[]}
                  onChange={d => setStepData(p => ({ ...p, worker_categories: d }))}
                />
              ) : currentStep.key === 'payroll_components' ? (
                <StepPayrollComponents
                  data={getStepData('payroll_components') as any[]}
                  onChange={d => setStepData(p => ({ ...p, payroll_components: d }))}
                />
              ) : currentStep.key === 'leave_policy' ? (
                <StepLeavePolicy
                  data={getStepData('leave_policy') as any[]}
                  onChange={d => setStepData(p => ({ ...p, leave_policy: d }))}
                />
              ) : currentStep.key === 'statutory_config' ? (
                <StepStatutory
                  data={stepData.statutory_config ?? wizardState?.statutoryConfig ?? { pfApplicable: true, pfWageCeiling: 15000, esiApplicable: false, esiWageCeiling: 21000, tdsApplicable: true, professionalTaxApplicable: true, defaultTaxRegime: 'new', payrollCutoffDay: 25, salaryCredDay: 1, lateMarkGraceMins: 15 }}
                  onChange={d => setStepData(p => ({ ...p, statutory_config: d }))}
                />
              ) : currentStep.key === 'role_setup' ? (
                <StepRoleSetup
                  data={getStepData('role_setup') as any[]}
                  onChange={d => setStepData(p => ({ ...p, role_setup: d }))}
                />
              ) : (
                <StepConfirmation state={{ ...wizardState, ...stepData }} />
              )}
            </div>

            {/* Nav buttons */}
            <div className="flex justify-between">
              <button disabled={currentStepIdx === 0}
                onClick={() => {
                  const prev = STEPS[currentStepIdx - 1];
                  if (prev) saveStep.mutate({ step: prev.key, data: {} });
                }}
                className="flex items-center gap-1.5 px-4 py-2 border border-retro-border rounded font-pixel text-[7px] text-primary-700 hover:text-primary-500 disabled:opacity-30">
                <ChevronLeft className="w-3 h-3" /> BACK
              </button>
              <button onClick={handleNext} disabled={saveStep.isPending}
                className="flex items-center gap-1.5 px-6 py-2 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
                {currentStep.key === 'confirmation' ? (
                  <><Zap className="w-3 h-3" /> {saveStep.isPending ? 'ACTIVATING...' : 'ACTIVATE TENANT'}</>
                ) : (
                  <>{saveStep.isPending ? 'SAVING...' : 'SAVE & CONTINUE'} <ChevronRight className="w-3 h-3" /></>
                )}
              </button>
            </div>

            {wizardState?.isComplete && (
              <div className="flex items-center gap-3 p-4 bg-green-950/20 border border-green-800 rounded">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <div>
                  <div className="font-pixel text-[8px] text-green-400">TENANT ACTIVATED SUCCESSFULLY</div>
                  <div className="font-mono text-xs text-primary-700 mt-0.5">All configuration applied. You can now run payroll.</div>
                </div>
                <a href="/dashboard" className="ml-auto flex items-center gap-1 font-pixel text-[7px] text-primary-crt border border-primary-700 px-3 py-1.5 rounded hover:bg-primary-900">
                  GO TO DASHBOARD <ArrowRight className="w-3 h-3" />
                </a>
              </div>
            )}
          </div>
        )}

        {/* ── HEALTH TAB ───────────────────────────────────────────────── */}
        {activeTab === 'health' && (
          <div className="space-y-4">
            <HealthScorePanel />
            {issues.length > 0 && (
              <div>
                <div className="font-pixel text-[7px] text-primary-600 mb-2">ALL DETECTED ISSUES ({issues.length})</div>
                <FixNowPanel issues={issues} />
              </div>
            )}
          </div>
        )}

        {/* ── MIGRATION TAB ─────────────────────────────────────────────── */}
        {activeTab === 'migration' && (
          <div className="space-y-3">
            <div className="font-pixel text-[8px] text-primary-600">MIGRATION ASSISTANT</div>
            <div className="font-mono text-[10px] text-primary-700">
              Upload CSV files to import employees, departments, leave history, or salary structures.
              All imports go through validation and dry-run before committing.
            </div>
            <MigrationAssistant />
          </div>
        )}
      </div>
    </div>
  );
}
