'use client';
/**
 * Billing Dashboard
 * ─────────────────────────────────────────────────────────────────────────────
 * Plan overview · Seat meters · Usage bars · Invoice history · Upgrade flow
 * GST-compliant invoice display · Razorpay checkout integration
 */

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  CreditCard, Users, Zap, Shield, BarChart3, Building2,
  CheckCircle, X, AlertTriangle, Download, ChevronRight,
  TrendingUp, Lock, Unlock, ArrowRight, RefreshCw, Star,
  FileText, Calendar, Clock, Activity,
} from 'lucide-react';

// ─── Types ────────────────────────────────────────────────────────────────────

type PlanId = 'starter' | 'growth' | 'pro' | 'enterprise';
type FeatureFlag = string;

interface Plan {
  id: PlanId; name: string; priceMonthly: number; priceAnnual: number;
  features: Record<string, boolean>;
  limits: { maxLegalEntities: number|null; maxSeats: number|null; supportSla: string };
}

interface SeatBreakdown {
  payrollEmployees: number; nonPayrollEmployees: number; contractorCount: number;
  totalHeadcount: number; billableSeats: number;
  byEntity: Array<{ entityName: string; count: number }>;
}

interface Invoice {
  id: string; invoiceNumber: string; status: string;
  totalAmount: number; amountDue: number; amountPaid: number;
  totalTax: number; cgstAmount: number; sgstAmount: number; igstAmount: number;
  subtotal: number; periodStart: string; periodEnd: string;
  dueDate: string; paidAt?: string; createdAt: string;
  lineItems: Array<{ description: string; quantity: number; unitPrice: number; amount: number }>;
  supplierGstin?: string; customerGstin?: string; placeOfSupply: string; isInterState: boolean;
}

// ─── API ──────────────────────────────────────────────────────────────────────

const tok = () => typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : '';
const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${tok()}`, 'Content-Type': 'application/json', ...((opts?.headers ?? {}) as any) },
  }).then(r => r.json()).then(r => r.data ?? r);

const fmt = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
const fmtDate = (d: string) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

// ─── Plan features map ────────────────────────────────────────────────────────

const FEATURE_LABELS: Record<string, { label: string; icon: any }> = {
  multi_entity:       { label: 'Multi-Entity',         icon: Building2 },
  expression_engine:  { label: 'Expression Engine',    icon: Zap },
  cfo_dashboard:      { label: 'CFO Dashboard',        icon: BarChart3 },
  audit_engine:       { label: 'Audit Engine',         icon: Shield },
  advanced_reports:   { label: 'Advanced Reports',     icon: FileText },
  api_access:         { label: 'API Access',           icon: Activity },
  ats_module:         { label: 'ATS Module',           icon: Users },
  performance_module: { label: 'Performance Reviews',  icon: TrendingUp },
  case_engine:        { label: 'HR Case Engine',       icon: Shield },
  backup_module:      { label: 'Automated Backups',    icon: Lock },
  custom_roles:       { label: 'Custom Roles',         icon: Users },
  sso:                { label: 'SSO',                  icon: Lock },
  ai_assistant:       { label: 'AI Assistant',         icon: Star },
  dedicated_support:  { label: 'Dedicated Support',    icon: CheckCircle },
  white_label:        { label: 'White-Label',          icon: Star },
};

const PLAN_COLORS: Record<PlanId, string> = {
  starter:    'border-slate-700 bg-slate-950/30',
  growth:     'border-blue-700 bg-blue-950/20',
  pro:        'border-violet-700 bg-violet-950/20',
  enterprise: 'border-amber-700 bg-amber-950/20',
};
const PLAN_BADGE: Record<PlanId, string> = {
  starter:    'text-slate-400 border-slate-700',
  growth:     'text-blue-400 border-blue-700',
  pro:        'text-violet-400 border-violet-700',
  enterprise: 'text-amber-400 border-amber-700',
};

// ─── Status badge ─────────────────────────────────────────────────────────────

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; cls: string }> = {
    paid:           { label: 'Paid',         cls: 'text-green-400 border-green-800 bg-green-950/20' },
    open:           { label: 'Open',         cls: 'text-amber-400 border-amber-800 bg-amber-950/20' },
    draft:          { label: 'Draft',        cls: 'text-primary-700 border-retro-border' },
    void:           { label: 'Void',         cls: 'text-primary-800 border-primary-800' },
    active:         { label: 'Active',       cls: 'text-green-400 border-green-800 bg-green-950/20' },
    trialing:       { label: 'Trial',        cls: 'text-blue-400 border-blue-800 bg-blue-950/20' },
    grace_period:   { label: 'Grace Period', cls: 'text-amber-400 border-amber-800 bg-amber-950/20' },
    suspended:      { label: 'Suspended',    cls: 'text-red-400 border-red-800 bg-red-950/20' },
    past_due:       { label: 'Past Due',     cls: 'text-red-400 border-red-800' },
  };
  const { label, cls } = config[status] ?? { label: status, cls: 'text-primary-700 border-retro-border' };
  return <span className={`font-pixel text-[6px] px-2 py-0.5 rounded border ${cls}`}>{label.toUpperCase()}</span>;
}

// ─── Usage meter ──────────────────────────────────────────────────────────────

function UsageMeter({ label, used, max, warn = 80 }: { label: string; used: number; max: number | null; warn?: number }) {
  const pct = max ? Math.min(100, Math.round(used / max * 100)) : 0;
  const color = !max ? 'bg-green-500' : pct >= 100 ? 'bg-red-500' : pct >= warn ? 'bg-amber-500' : 'bg-green-500';
  return (
    <div>
      <div className="flex justify-between mb-1">
        <span className="font-pixel text-[6px] text-primary-700">{label}</span>
        <span className="font-mono text-[9px] text-primary-500">
          {used.toLocaleString('en-IN')} {max ? `/ ${max.toLocaleString('en-IN')}` : '/ ∞'}
        </span>
      </div>
      <div className="h-1.5 bg-retro-bg rounded overflow-hidden">
        <div className={`h-full transition-all ${color}`} style={{ width: max ? `${pct}%` : '15%' }} />
      </div>
    </div>
  );
}

// ─── Plan card ────────────────────────────────────────────────────────────────

function PlanCard({
  plan, current, cycle, seats, onSelect, loading,
}: {
  plan: Plan; current: boolean; cycle: 'monthly' | 'annual';
  seats: number; onSelect: () => void; loading: boolean;
}) {
  const price = cycle === 'annual' ? plan.priceAnnual / 12 : plan.priceMonthly;
  const isEnterprise = plan.id === 'enterprise';
  const isUpgrade = !current;

  return (
    <div className={`relative border rounded p-4 flex flex-col gap-3 ${PLAN_COLORS[plan.id]} ${current ? 'ring-1 ring-primary-crt' : ''}`}>
      {current && (
        <div className="absolute -top-2 left-3 font-pixel text-[6px] px-2 py-0.5 bg-primary-950 border border-primary-700 text-primary-crt rounded">
          CURRENT PLAN
        </div>
      )}

      <div>
        <div className={`font-pixel text-[8px] mb-0.5 ${PLAN_BADGE[plan.id]}`}>{plan.name.toUpperCase()}</div>
        {!isEnterprise ? (
          <div className="mt-2">
            <span className="font-pixel text-[18px] text-primary-400">{fmt(price)}</span>
            <span className="font-mono text-[9px] text-primary-700">/employee/mo</span>
          </div>
        ) : (
          <div className="mt-2 font-pixel text-[11px] text-amber-400">Custom Pricing</div>
        )}
        {cycle === 'annual' && !isEnterprise && (
          <div className="font-mono text-[9px] text-green-400 mt-0.5">Save 20% with annual billing</div>
        )}
        {!isEnterprise && seats > 0 && (
          <div className="font-mono text-[9px] text-primary-700 mt-0.5">
            ≈ {fmt(price * seats)}/month for {seats} seats
          </div>
        )}
      </div>

      <div className="space-y-1.5 flex-1">
        {Object.entries(FEATURE_LABELS).slice(0, 8).map(([key, { label, icon: Icon }]) => {
          const enabled = plan.features[key];
          return (
            <div key={key} className={`flex items-center gap-2 ${enabled ? '' : 'opacity-30'}`}>
              {enabled
                ? <CheckCircle className="w-2.5 h-2.5 text-green-400 flex-shrink-0" />
                : <X className="w-2.5 h-2.5 text-primary-800 flex-shrink-0" />
              }
              <span className="font-mono text-[9px] text-primary-600">{label}</span>
            </div>
          );
        })}
      </div>

      <button
        onClick={onSelect}
        disabled={current || loading}
        className={`w-full py-2 rounded border font-pixel text-[7px] transition-all disabled:opacity-40 ${
          current
            ? 'border-retro-border text-primary-800 cursor-default'
            : isEnterprise
              ? 'border-amber-700 text-amber-400 hover:bg-amber-950/30'
              : 'bg-primary-900 border-primary-700 text-primary-crt hover:bg-primary-800'
        }`}
      >
        {current ? 'CURRENT' : loading ? 'SWITCHING...' : isEnterprise ? 'CONTACT SALES' : 'SELECT PLAN'}
      </button>
    </div>
  );
}

// ─── Invoice row ──────────────────────────────────────────────────────────────

function InvoiceRow({ inv, onView }: { inv: Invoice; onView: () => void }) {
  return (
    <div className="flex items-center gap-3 py-2.5 border-b border-retro-border/30 hover:bg-primary-950/10">
      <div className="w-32 font-mono text-[10px] text-primary-600">{inv.invoiceNumber}</div>
      <div className="flex-1 font-mono text-[10px] text-primary-500">{fmtDate(inv.createdAt)}</div>
      <div className="w-28 font-mono text-[10px] text-primary-500">
        {fmtDate(inv.periodStart)} – {fmtDate(inv.periodEnd)}
      </div>
      <div className="w-24 font-pixel text-[9px] text-primary-400 text-right">{fmt(inv.totalAmount)}</div>
      <div className="w-24"><StatusBadge status={inv.status} /></div>
      <button onClick={onView}
        className="flex items-center gap-1 font-pixel text-[6px] text-primary-700 hover:text-primary-400 border border-retro-border rounded px-2 py-1">
        <Download className="w-2.5 h-2.5" /> PDF
      </button>
    </div>
  );
}

// ─── Invoice detail modal ─────────────────────────────────────────────────────

function InvoiceModal({ inv, onClose }: { inv: Invoice; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-retro-bg border border-retro-border rounded max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="flex justify-between items-start mb-6">
          <div>
            <div className="font-pixel text-[11px] text-primary-crt">TAX INVOICE</div>
            <div className="font-mono text-xs text-primary-600 mt-0.5">{inv.invoiceNumber}</div>
          </div>
          <button onClick={onClose} className="text-primary-800 hover:text-primary-500"><X className="w-4 h-4" /></button>
        </div>

        {/* Supplier / Customer */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <div>
            <div className="font-pixel text-[6px] text-primary-700 mb-1">SUPPLIER</div>
            <div className="font-mono text-[10px] text-primary-500 space-y-0.5">
              <div className="font-semibold text-primary-400">Retroworks Technologies Pvt Ltd</div>
              <div>Mumbai, Maharashtra</div>
              {inv.supplierGstin && <div>GSTIN: {inv.supplierGstin}</div>}
              <div>SAC: 998313</div>
            </div>
          </div>
          <div>
            <div className="font-pixel text-[6px] text-primary-700 mb-1">BILLED TO</div>
            <div className="font-mono text-[10px] text-primary-500 space-y-0.5">
              {inv.customerGstin && <div>GSTIN: {inv.customerGstin}</div>}
              <div>Place of Supply: {inv.placeOfSupply}</div>
              <div>Period: {fmtDate(inv.periodStart)} – {fmtDate(inv.periodEnd)}</div>
            </div>
          </div>
        </div>

        {/* Line items */}
        <div className="border border-retro-border rounded overflow-hidden mb-4">
          <div className="grid grid-cols-4 gap-2 px-3 py-2 bg-primary-950/30 font-pixel text-[6px] text-primary-700">
            <div className="col-span-2">DESCRIPTION</div><div className="text-right">QTY</div><div className="text-right">AMOUNT</div>
          </div>
          {inv.lineItems?.map((item, i) => (
            <div key={i} className="grid grid-cols-4 gap-2 px-3 py-2 border-t border-retro-border/30">
              <div className="col-span-2 font-mono text-[9px] text-primary-500">{item.description}</div>
              <div className="font-mono text-[9px] text-primary-500 text-right">{item.quantity}</div>
              <div className="font-mono text-[9px] text-primary-400 text-right">{fmt(item.amount)}</div>
            </div>
          ))}
        </div>

        {/* Totals */}
        <div className="space-y-1.5 text-right">
          {[
            ['Subtotal', inv.subtotal],
            ...(inv.isInterState
              ? [['IGST (18%)', inv.igstAmount]]
              : [['CGST (9%)', inv.cgstAmount], ['SGST (9%)', inv.sgstAmount]]
            ),
          ].map(([label, amt]) => (
            <div key={String(label)} className="flex justify-between font-mono text-[10px] text-primary-600">
              <span>{label}</span><span>{fmt(amt as number)}</span>
            </div>
          ))}
          <div className="flex justify-between font-pixel text-[9px] text-primary-crt border-t border-retro-border pt-2 mt-2">
            <span>TOTAL AMOUNT</span><span>{fmt(inv.totalAmount)}</span>
          </div>
          {inv.status === 'paid' && (
            <div className="flex items-center justify-end gap-1 font-pixel text-[7px] text-green-400 mt-1">
              <CheckCircle className="w-3 h-3" /> PAID {inv.paidAt ? fmtDate(inv.paidAt) : ''}
            </div>
          )}
          {inv.status === 'open' && (
            <div className="font-pixel text-[7px] text-amber-400 mt-1">DUE BY {fmtDate(inv.dueDate)}</div>
          )}
        </div>

        <div className="mt-4 font-mono text-[9px] text-primary-800 text-center">
          This is a computer-generated invoice and does not require a signature.
        </div>
      </div>
    </div>
  );
}

// ─── Upgrade modal ────────────────────────────────────────────────────────────

function UpgradeModal({ plans, currentPlanId, seats, onClose, onUpgrade, loading }: {
  plans: Plan[]; currentPlanId: PlanId; seats: number;
  onClose: () => void; onUpgrade: (planId: PlanId, cycle: 'monthly'|'annual') => void;
  loading: boolean;
}) {
  const [cycle, setCycle] = useState<'monthly'|'annual'>('monthly');
  const [selected, setSelected] = useState<PlanId | null>(null);

  const { data: preview } = useQuery({
    queryKey: ['upgrade-preview', selected, cycle],
    queryFn: () => api(`/billing/upgrade-preview?plan=${selected}&cycle=${cycle}`),
    enabled: !!selected,
  });

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-retro-bg border border-retro-border rounded max-w-5xl w-full p-6 max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center mb-4">
          <div className="font-pixel text-[9px] text-primary-500">UPGRADE PLAN</div>
          <button onClick={onClose}><X className="w-4 h-4 text-primary-700" /></button>
        </div>

        {/* Billing cycle toggle */}
        <div className="flex items-center gap-3 mb-6">
          <span className="font-pixel text-[7px] text-primary-700">BILLING CYCLE:</span>
          <div className="flex border border-retro-border rounded overflow-hidden">
            {(['monthly','annual'] as const).map(c => (
              <button key={c} onClick={() => setCycle(c)}
                className={`px-4 py-1.5 font-pixel text-[7px] transition-all ${cycle===c ? 'bg-primary-900 text-primary-crt' : 'text-primary-700 hover:text-primary-500'}`}>
                {c.toUpperCase()}{c==='annual' && <span className="ml-1 text-green-400">−20%</span>}
              </button>
            ))}
          </div>
        </div>

        {/* Plan grid */}
        <div className="grid grid-cols-4 gap-3 mb-4">
          {plans.map(plan => (
            <PlanCard
              key={plan.id} plan={plan}
              current={plan.id === currentPlanId}
              cycle={cycle} seats={seats}
              onSelect={() => setSelected(plan.id as PlanId)}
              loading={loading && selected === plan.id}
            />
          ))}
        </div>

        {/* Preview panel */}
        {selected && preview && (
          <div className={`p-4 rounded border mb-4 ${preview.isUpgrade ? 'border-green-800 bg-green-950/10' : 'border-amber-800 bg-amber-950/10'}`}>
            <div className="font-pixel text-[7px] text-primary-500 mb-2">
              {preview.isUpgrade ? '⬆ UPGRADE' : '⬇ DOWNGRADE'} SUMMARY
            </div>
            <div className="grid grid-cols-3 gap-3 text-center mb-3">
              <div><div className="font-pixel text-[11px] text-primary-crt">{fmt(preview.newMonthlyCost)}</div><div className="font-pixel text-[6px] text-primary-700">New Monthly Cost</div></div>
              {preview.proratedCredit > 0 && <div><div className="font-pixel text-[11px] text-green-400">{fmt(preview.proratedCredit)}</div><div className="font-pixel text-[6px] text-primary-700">Prorated Credit</div></div>}
              <div><div className="font-pixel text-[11px] text-primary-400">{fmtDate(preview.effectiveDate)}</div><div className="font-pixel text-[6px] text-primary-700">Effective Date</div></div>
            </div>
            {preview.lostFeatures?.length > 0 && (
              <div>
                <div className="font-pixel text-[6px] text-amber-400 mb-1">FEATURES YOU WILL LOSE:</div>
                <div className="flex flex-wrap gap-1">
                  {preview.lostFeatures.map((f: string) => (
                    <span key={f} className="font-mono text-[8px] text-amber-300 border border-amber-800 px-2 py-0.5 rounded">{f.replace(/_/g,' ')}</span>
                  ))}
                </div>
              </div>
            )}
            {preview.requiredSeatAdjustment && (
              <div className="flex items-center gap-2 mt-2 text-red-400">
                <AlertTriangle className="w-3 h-3" />
                <span className="font-mono text-[10px]">Remove {preview.requiredSeatAdjustment} employees before downgrading</span>
              </div>
            )}
            {!preview.requiredSeatAdjustment && selected && (
              <button
                onClick={() => onUpgrade(selected, cycle)}
                disabled={loading}
                className="mt-3 w-full py-2.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[8px] text-primary-crt hover:bg-primary-800 disabled:opacity-40">
                {loading ? 'PROCESSING...' : preview.isUpgrade ? '⬆ UPGRADE NOW' : '⬇ SCHEDULE DOWNGRADE'}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN BILLING PAGE
// ─────────────────────────────────────────────────────────────────────────────

export function BillingPage() {
  const qc = useQueryClient();
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [viewInvoice, setViewInvoice] = useState<Invoice | null>(null);
  const [invoicePage, setInvoicePage] = useState(1);

  const { data: overview, isLoading } = useQuery({
    queryKey: ['billing-overview'],
    queryFn: () => api('/billing/overview'),
    refetchInterval: 60_000,
  });

  const { data: plans } = useQuery({
    queryKey: ['billing-plans'],
    queryFn: () => api('/billing/plans'),
  });

  const { data: invoiceData } = useQuery({
    queryKey: ['billing-invoices', invoicePage],
    queryFn: () => api(`/billing/invoices?page=${invoicePage}&limit=10`),
  });

  const upgradeMut = useMutation({
    mutationFn: ({ planId, cycle }: { planId: string; cycle: string }) =>
      api('/billing/upgrade', { method: 'POST', body: JSON.stringify({ planId, cycle }) }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['billing-overview'] });
      setShowUpgrade(false);
    },
  });

  const startTrialMut = useMutation({
    mutationFn: () => api('/billing/trial/start', { method: 'POST', body: JSON.stringify({ planId: 'growth' }) }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['billing-overview'] }),
  });

  if (isLoading) return (
    <div className="flex items-center justify-center h-64">
      <div className="font-pixel text-[8px] text-primary-700 animate-pulse">LOADING BILLING...</div>
    </div>
  );

  const sub = overview?.subscription;
  const plan = overview?.plan;
  const seats: SeatBreakdown = overview?.seats ?? { payrollEmployees: 0, nonPayrollEmployees: 0, contractorCount: 0, totalHeadcount: 0, billableSeats: 0, byEntity: [] };
  const billing = overview?.billing ?? {};

  return (
    <div className="space-y-4 animate-fade-in">
      {/* ── Trial / Grace / Suspended banners ──────────────────────────── */}
      {billing.isTrialing && (
        <div className="flex items-center gap-3 p-3 bg-blue-950/20 border border-blue-700 rounded">
          <Clock className="w-4 h-4 text-blue-400" />
          <div>
            <span className="font-pixel text-[8px] text-blue-400">FREE TRIAL ACTIVE</span>
            <span className="font-mono text-[10px] text-blue-300 ml-2">{billing.trialDaysRemaining} days remaining</span>
          </div>
          <button onClick={() => setShowUpgrade(true)}
            className="ml-auto flex items-center gap-1 font-pixel text-[7px] text-primary-crt border border-primary-700 px-3 py-1.5 rounded hover:bg-primary-900">
            UPGRADE NOW <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      )}
      {billing.inGracePeriod && (
        <div className="flex items-center gap-3 p-3 bg-amber-950/20 border border-amber-700 rounded">
          <AlertTriangle className="w-4 h-4 text-amber-400" />
          <div>
            <span className="font-pixel text-[8px] text-amber-400">PAYMENT REQUIRED</span>
            <span className="font-mono text-[10px] text-amber-300 ml-2">
              Grace period ends {fmtDate(billing.gracePeriodEnd)}. Features will be suspended.
            </span>
          </div>
          <button className="ml-auto font-pixel text-[7px] text-red-400 border border-red-800 px-3 py-1.5 rounded hover:bg-red-950/30">
            UPDATE PAYMENT
          </button>
        </div>
      )}
      {sub?.status === 'suspended' && (
        <div className="flex items-center gap-3 p-3 bg-red-950/20 border border-red-700 rounded">
          <Lock className="w-4 h-4 text-red-400" />
          <div>
            <span className="font-pixel text-[8px] text-red-400">ACCOUNT SUSPENDED</span>
            <span className="font-mono text-[10px] text-red-300 ml-2">All advanced features are locked. Please renew to restore access.</span>
          </div>
        </div>
      )}

      {/* ── Top row: Plan card + Seat meters ─────────────────────────────── */}
      <div className="grid grid-cols-3 gap-4">

        {/* Current plan */}
        <div className={`border rounded p-4 space-y-3 ${PLAN_COLORS[plan?.id as PlanId ?? 'starter']}`}>
          <div className="flex items-start justify-between">
            <div>
              <div className="font-pixel text-[6px] text-primary-700 mb-0.5">CURRENT PLAN</div>
              <div className={`font-pixel text-[13px] ${PLAN_BADGE[plan?.id as PlanId ?? 'starter']}`}>{plan?.name}</div>
            </div>
            <StatusBadge status={sub?.status ?? 'active'} />
          </div>
          {plan?.priceMonthly > 0 && (
            <div>
              <span className="font-pixel text-[16px] text-primary-400">{fmt(plan.priceMonthly)}</span>
              <span className="font-mono text-[9px] text-primary-700">/seat/month</span>
            </div>
          )}
          <div className="space-y-1 text-primary-600">
            <div className="flex items-center gap-1.5 font-mono text-[9px]">
              <Calendar className="w-3 h-3" />
              <span>Next billing: {billing.nextBillingDate ? fmtDate(billing.nextBillingDate) : '—'}</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-[9px]">
              <CreditCard className="w-3 h-3" />
              <span>Est. {fmt(billing.estimatedNextBill ?? 0)}</span>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => setShowUpgrade(true)}
              className="flex-1 py-1.5 bg-primary-900 border border-primary-700 rounded font-pixel text-[7px] text-primary-crt hover:bg-primary-800">
              CHANGE PLAN
            </button>
            {!sub && !billing.isTrialing && (
              <button onClick={() => startTrialMut.mutate()}
                className="flex-1 py-1.5 border border-blue-700 rounded font-pixel text-[7px] text-blue-400 hover:bg-blue-950/30">
                START TRIAL
              </button>
            )}
          </div>
        </div>

        {/* Seat breakdown */}
        <div className="border border-retro-border rounded p-4 space-y-3">
          <div className="font-pixel text-[7px] text-primary-600">SEAT USAGE</div>
          <div className="grid grid-cols-2 gap-2">
            {[
              ['Payroll Employees', seats.payrollEmployees, 'text-primary-crt', 'BILLED'],
              ['Non-Payroll', seats.nonPayrollEmployees, 'text-primary-600', ''],
              ['Contractors', seats.contractorCount, 'text-amber-400', ''],
              ['Total Headcount', seats.totalHeadcount, 'text-primary-500', ''],
            ].map(([label, val, cls, badge]) => (
              <div key={String(label)} className="border border-retro-border/50 rounded p-2 text-center">
                <div className={`font-pixel text-[13px] ${cls}`}>{val}</div>
                <div className="font-pixel text-[5px] text-primary-800 mt-0.5">{label}</div>
                {badge && <div className="font-pixel text-[5px] text-green-500 mt-0.5">{badge}</div>}
              </div>
            ))}
          </div>
          <UsageMeter label="Billable Seats" used={seats.billableSeats} max={plan?.limits?.maxSeats ?? null} />
        </div>

        {/* Feature gates */}
        <div className="border border-retro-border rounded p-4 space-y-2">
          <div className="font-pixel text-[7px] text-primary-600 mb-1">FEATURE ACCESS</div>
          {Object.entries(FEATURE_LABELS).slice(0, 9).map(([key, { label, icon: Icon }]) => {
            const enabled = plan?.features?.[key];
            return (
              <div key={key} className={`flex items-center gap-2 ${enabled ? '' : 'opacity-40'}`}>
                {enabled
                  ? <Unlock className="w-2.5 h-2.5 text-green-400 flex-shrink-0" />
                  : <Lock className="w-2.5 h-2.5 text-primary-800 flex-shrink-0" />
                }
                <span className="font-mono text-[8px] text-primary-600 flex-1">{label}</span>
                {!enabled && (
                  <button onClick={() => setShowUpgrade(true)}
                    className="font-pixel text-[5px] text-primary-800 hover:text-primary-crt">
                    UPGRADE
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Plan limits row ──────────────────────────────────────────────── */}
      <div className="border border-retro-border rounded p-4">
        <div className="font-pixel text-[7px] text-primary-600 mb-3">PLAN LIMITS</div>
        <div className="grid grid-cols-4 gap-4">
          <UsageMeter label="Legal Entities" used={seats.byEntity.length || 1} max={plan?.limits?.maxLegalEntities ?? null} />
          <div>
            <div className="font-pixel text-[6px] text-primary-700 mb-1">SUPPORT SLA</div>
            <div className="font-mono text-[10px] text-primary-400 uppercase">{plan?.limits?.supportSla ?? 'Community'}</div>
          </div>
          <div>
            <div className="font-pixel text-[6px] text-primary-700 mb-1">DATA RETENTION</div>
            <div className="font-mono text-[10px] text-primary-400">{plan?.limits?.dataRetentionMonths ?? 12} months</div>
          </div>
          <div>
            <div className="font-pixel text-[6px] text-primary-700 mb-1">API CALLS/MONTH</div>
            <div className="font-mono text-[10px] text-primary-400">
              {plan?.limits?.maxApiCalls ? plan.limits.maxApiCalls.toLocaleString('en-IN') : '∞'}
            </div>
          </div>
        </div>
      </div>

      {/* ── Multi-entity breakdown ────────────────────────────────────────── */}
      {seats.byEntity.length > 1 && (
        <div className="border border-retro-border rounded p-4">
          <div className="font-pixel text-[7px] text-primary-600 mb-3">HEADCOUNT BY ENTITY</div>
          <div className="grid grid-cols-3 gap-2">
            {seats.byEntity.map(e => (
              <div key={e.entityName} className="flex items-center justify-between px-3 py-2 border border-retro-border/50 rounded">
                <span className="font-mono text-[9px] text-primary-600">{e.entityName}</span>
                <span className="font-pixel text-[9px] text-primary-400">{e.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Invoice history ───────────────────────────────────────────────── */}
      <div className="border border-retro-border rounded p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="font-pixel text-[7px] text-primary-600">INVOICE HISTORY</div>
          <div className="flex items-center gap-1">
            <button
              disabled={invoicePage <= 1}
              onClick={() => setInvoicePage(p => p - 1)}
              className="px-2 py-1 font-pixel text-[6px] text-primary-700 border border-retro-border rounded disabled:opacity-30 hover:text-primary-400">
              ←
            </button>
            <span className="font-pixel text-[6px] text-primary-700 px-2">
              {invoicePage} / {Math.ceil((invoiceData?.total ?? 0) / 10)}
            </span>
            <button
              disabled={invoicePage >= Math.ceil((invoiceData?.total ?? 0) / 10)}
              onClick={() => setInvoicePage(p => p + 1)}
              className="px-2 py-1 font-pixel text-[6px] text-primary-700 border border-retro-border rounded disabled:opacity-30 hover:text-primary-400">
              →
            </button>
          </div>
        </div>

        {/* Table header */}
        <div className="flex items-center gap-3 py-1.5 border-b border-retro-border font-pixel text-[6px] text-primary-800">
          <div className="w-32">INVOICE #</div>
          <div className="flex-1">DATE</div>
          <div className="w-28">PERIOD</div>
          <div className="w-24 text-right">AMOUNT</div>
          <div className="w-24">STATUS</div>
          <div className="w-16"></div>
        </div>

        {invoiceData?.invoices?.length > 0 ? (
          invoiceData.invoices.map((inv: Invoice) => (
            <InvoiceRow key={inv.id} inv={inv} onView={() => setViewInvoice(inv)} />
          ))
        ) : (
          <div className="py-8 text-center font-mono text-xs text-primary-800">No invoices yet</div>
        )}
      </div>

      {/* ── Modals ────────────────────────────────────────────────────────── */}
      {showUpgrade && plans && (
        <UpgradeModal
          plans={plans}
          currentPlanId={plan?.id ?? 'starter'}
          seats={seats.billableSeats}
          onClose={() => setShowUpgrade(false)}
          onUpgrade={(planId, cycle) => upgradeMut.mutate({ planId, cycle })}
          loading={upgradeMut.isPending}
        />
      )}
      {viewInvoice && <InvoiceModal inv={viewInvoice} onClose={() => setViewInvoice(null)} />}
    </div>
  );
}
