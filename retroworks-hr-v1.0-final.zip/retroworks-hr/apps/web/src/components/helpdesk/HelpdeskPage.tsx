'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { HelpCircle, Plus, Clock, CheckCircle2, AlertCircle, MessageSquare } from 'lucide-react';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${typeof localStorage !== 'undefined' ? localStorage.getItem('token') ?? '' : ''}`,
      ...opts?.headers,
    },
  }).then(r => r.json());

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  open: { label: 'Open', color: 'text-amber-400 bg-amber-950 border-amber-800', icon: <Clock className="w-3 h-3" /> },
  'in-progress': { label: 'In Progress', color: 'text-blue-400 bg-blue-950 border-blue-800', icon: <AlertCircle className="w-3 h-3" /> },
  resolved: { label: 'Resolved', color: 'text-green-400 bg-green-950 border-green-800', icon: <CheckCircle2 className="w-3 h-3" /> },
  closed: { label: 'Closed', color: 'text-primary-700 bg-retro-bg border-retro-border', icon: null },
  'on-hold': { label: 'On Hold', color: 'text-purple-400 bg-purple-950 border-purple-800', icon: null },
};

const PRIORITY_DOT: Record<string, string> = {
  critical: 'bg-red-500',
  high: 'bg-orange-500',
  medium: 'bg-amber-500',
  low: 'bg-primary-700',
};

function NewTicketModal({ onClose, onSubmit }: {
  onClose: () => void;
  onSubmit: (data: Record<string, string>) => void;
}) {
  const [form, setForm] = useState({ subject: '', description: '', category: 'general', priority: 'medium' });
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }));

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-retro-card border border-primary-800 rounded-lg w-full max-w-lg mx-4 shadow-glow-strong">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-retro-border">
          <span className="w-2 h-2 bg-red-600 rounded-full" />
          <span className="w-2 h-2 bg-amber-600 rounded-full" />
          <span className="w-2 h-2 bg-green-600 rounded-full" />
          <span className="font-pixel text-[8px] text-primary-600 ml-2">NEW_TICKET.EXE</span>
          <button onClick={onClose} className="ml-auto text-primary-700 hover:text-primary-400 font-mono text-sm">✕</button>
        </div>

        <div className="p-5 space-y-4">
          <div>
            <label className="block font-pixel text-[7px] text-primary-700 mb-1">SUBJECT *</label>
            <input value={form.subject} onChange={set('subject')}
              placeholder="Briefly describe your issue"
              className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-pixel text-[7px] text-primary-700 mb-1">CATEGORY</label>
              <select value={form.category} onChange={set('category')}
                className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 focus:border-primary-600 focus:outline-none">
                <option value="payroll">Payroll</option>
                <option value="leave">Leave</option>
                <option value="it">IT Support</option>
                <option value="compliance">Compliance</option>
                <option value="general">General</option>
                <option value="grievance">Grievance</option>
              </select>
            </div>
            <div>
              <label className="block font-pixel text-[7px] text-primary-700 mb-1">PRIORITY</label>
              <select value={form.priority} onChange={set('priority')}
                className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 focus:border-primary-600 focus:outline-none">
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-pixel text-[7px] text-primary-700 mb-1">DESCRIPTION *</label>
            <textarea value={form.description} onChange={set('description')} rows={4}
              placeholder="Provide details about your issue..."
              className="w-full px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none resize-none" />
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => onSubmit(form)}
              disabled={!form.subject || !form.description}
              className="flex-1 py-2 bg-primary-900 border border-primary-600 hover:border-primary-crt hover:shadow-glow font-pixel text-[8px] text-primary-crt rounded transition-all disabled:opacity-40"
            >
              SUBMIT TICKET
            </button>
            <button onClick={onClose} className="px-4 py-2 border border-retro-border font-mono text-sm text-primary-700 hover:text-primary-500 rounded">
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function HelpdeskPage() {
  const [showNew, setShowNew] = useState(false);
  const [selectedTicket, setSelectedTicket] = useState<string | null>(null);
  const [comment, setComment] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const qc = useQueryClient();

  const { data: tickets = [] } = useQuery({
    queryKey: ['tickets', statusFilter],
    queryFn: () => api(`/helpdesk/tickets${statusFilter ? `?status=${statusFilter}` : ''}`).then(r => r.data ?? []),
  });

  const { data: ticketDetail } = useQuery({
    queryKey: ['ticket-detail', selectedTicket],
    queryFn: () => api(`/helpdesk/tickets/${selectedTicket}`).then(r => r.data),
    enabled: !!selectedTicket,
  });

  const createTicket = useMutation({
    mutationFn: (data: Record<string, string>) =>
      api('/helpdesk/tickets', { method: 'POST', body: JSON.stringify(data) }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['tickets'] });
      setShowNew(false);
    },
  });

  const addComment = useMutation({
    mutationFn: ({ id, message }: { id: string; message: string }) =>
      api(`/helpdesk/tickets/${id}/comments`, { method: 'POST', body: JSON.stringify({ message }) }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['ticket-detail'] });
      setComment('');
    },
  });

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">HELPDESK</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">HR support tickets & queries</p>
        </div>
        <button
          onClick={() => setShowNew(true)}
          className="flex items-center gap-1.5 px-4 py-2 bg-primary-900 border border-primary-600 hover:border-primary-crt hover:shadow-glow font-pixel text-[8px] text-primary-crt rounded transition-all"
        >
          <Plus className="w-3.5 h-3.5" /> Raise Ticket
        </button>
      </div>

      {/* Status filter */}
      <div className="flex gap-2">
        {['', 'open', 'in-progress', 'resolved', 'closed'].map(s => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={`px-3 py-1 font-mono text-xs rounded border transition-all ${
              statusFilter === s ? 'border-primary-crt text-primary-crt bg-primary-950' : 'border-retro-border text-primary-700 hover:border-primary-800'
            }`}
          >
            {s === '' ? 'All' : s.replace('-', ' ')}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Ticket List */}
        <div className="space-y-2">
          {(tickets as Array<{
            id: string; ticketNumber: string; subject: string;
            status: string; priority: string; category: string;
            createdAt: string; _count: { comments: number };
          }>).map(ticket => {
            const cfg = STATUS_CONFIG[ticket.status] ?? STATUS_CONFIG['open']!;
            return (
              <button
                key={ticket.id}
                onClick={() => setSelectedTicket(ticket.id)}
                className={`w-full text-left p-3 rounded border transition-all ${
                  selectedTicket === ticket.id ? 'border-primary-700 bg-primary-950' : 'border-retro-border bg-retro-card hover:border-primary-800'
                }`}
              >
                <div className="flex items-start gap-2">
                  <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${PRIORITY_DOT[ticket.priority] ?? PRIORITY_DOT['medium']!}`} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="font-mono text-[9px] text-primary-700">{ticket.ticketNumber}</span>
                      <span className="font-mono text-[9px] text-primary-800">· {ticket.category}</span>
                    </div>
                    <p className="font-mono text-xs text-primary-400 line-clamp-1">{ticket.subject}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`flex items-center gap-0.5 font-pixel text-[6px] px-1 py-0.5 border rounded ${cfg.color}`}>
                        {cfg.icon} {cfg.label}
                      </span>
                      {ticket._count.comments > 0 && (
                        <span className="flex items-center gap-0.5 font-mono text-[9px] text-primary-700">
                          <MessageSquare className="w-2.5 h-2.5" /> {ticket._count.comments}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Ticket Detail */}
        <div className="lg:col-span-2">
          {ticketDetail ? (
            <div className="bg-retro-card border border-retro-border rounded overflow-hidden">
              {/* Header */}
              <div className="px-5 py-4 border-b border-retro-border">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-mono text-[10px] text-primary-700">{(ticketDetail as Record<string, string>).ticketNumber}</p>
                    <h2 className="font-mono text-base text-primary-200 mt-1">{(ticketDetail as Record<string, string>).subject}</h2>
                  </div>
                  {(() => {
                    const cfg = STATUS_CONFIG[(ticketDetail as Record<string, string>).status] ?? STATUS_CONFIG['open']!;
                    return (
                      <span className={`flex items-center gap-1 px-2 py-1 border rounded font-pixel text-[7px] shrink-0 ${cfg.color}`}>
                        {cfg.icon} {cfg.label}
                      </span>
                    );
                  })()}
                </div>
                <p className="font-mono text-xs text-primary-600 mt-3 whitespace-pre-wrap">{(ticketDetail as Record<string, string>).description}</p>
              </div>

              {/* Comments */}
              <div className="p-5 space-y-3 max-h-60 overflow-y-auto">
                {((ticketDetail as Record<string, unknown>).comments as Array<{
                  id: string; message: string; createdAt: string;
                  author: { firstName: string; lastName: string };
                }>)?.map(c => (
                  <div key={c.id} className="bg-retro-bg border border-retro-border rounded p-3">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-mono text-xs text-primary-400">{c.author.firstName} {c.author.lastName}</span>
                      <span className="font-mono text-[9px] text-primary-700">
                        {new Date(c.createdAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="font-mono text-xs text-primary-600">{c.message}</p>
                  </div>
                ))}
              </div>

              {/* Reply */}
              {!['resolved', 'closed'].includes((ticketDetail as Record<string, string>).status) && (
                <div className="border-t border-retro-border p-4 flex gap-3">
                  <textarea
                    value={comment}
                    onChange={e => setComment(e.target.value)}
                    rows={2}
                    placeholder="Add a comment..."
                    className="flex-1 px-3 py-2 bg-retro-bg border border-retro-border rounded font-mono text-sm text-primary-300 placeholder:text-primary-800 focus:border-primary-600 focus:outline-none resize-none"
                  />
                  <button
                    onClick={() => selectedTicket && addComment.mutate({ id: selectedTicket, message: comment })}
                    disabled={!comment.trim()}
                    className="px-4 py-2 bg-primary-900 border border-primary-600 hover:border-primary-crt font-pixel text-[7px] text-primary-crt rounded disabled:opacity-40"
                  >
                    SEND
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-retro-card border border-retro-border rounded p-10 text-center">
              <HelpCircle className="w-10 h-10 text-primary-800 mx-auto mb-3" />
              <p className="font-pixel text-[8px] text-primary-700">Select a ticket to view details</p>
            </div>
          )}
        </div>
      </div>

      {showNew && <NewTicketModal onClose={() => setShowNew(false)} onSubmit={data => createTicket.mutate(data)} />}
    </div>
  );
}
