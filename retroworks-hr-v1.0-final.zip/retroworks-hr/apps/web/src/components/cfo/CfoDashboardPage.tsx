'use client';
import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import {
  TrendingUp, TrendingDown, Users, DollarSign,
  AlertTriangle, Calendar, Zap, Building2,
  ChevronDown, ChevronUp, Download, RefreshCw,
} from 'lucide-react';

// ── API client ─────────────────────────────────────────────────────────────────
const token = () =>
  typeof localStorage !== 'undefined' ? (localStorage.getItem('token') ?? '') : '';

const api = (path: string, opts?: RequestInit) =>
  fetch(`/api/v1${path}`, {
    ...opts,
    headers: { Authorization: `Bearer ${token()}`, 'Content-Type': 'application/json', ...(opts?.headers ?? {}) },
  }).then(r => r.json());

const fmt = (n: number) =>
  new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);

const fmtN = (n: number) =>
  new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(n);

// ── KPI Card ──────────────────────────────────────────────────────────────────
function KpiCard({
  label, value, subtitle, change, icon: Icon, color = 'primary',
}: {
  label: string; value: string; subtitle?: string;
  change?: number | null; icon: any; color?: string;
}) {
  const up = change !== null && change !== undefined && change > 0;
  const dn = change !== null && change !== undefined && change < 0;
  return (
    <div className="bg-retro-card border border-retro-border rounded p-4 space-y-2 hover:border-primary-700 transition-colors">
      <div className="flex items-center justify-between">
        <span className="font-pixel text-[7px] text-primary-700 uppercase tracking-widest">{label}</span>
        <Icon className="w-4 h-4 text-primary-800" />
      </div>
      <div className="font-pixel text-[11px] text-primary-crt">{value}</div>
      {subtitle && <div className="font-mono text-[10px] text-primary-700">{subtitle}</div>}
      {change !== null && change !== undefined && (
        <div className={`flex items-center gap-1 font-mono text-[10px] ${up ? 'text-green-500' : dn ? 'text-red-500' : 'text-primary-700'}`}>
          {up ? <TrendingUp className="w-3 h-3" /> : dn ? <TrendingDown className="w-3 h-3" /> : null}
          {up ? '+' : ''}{change.toFixed(1)}% vs prev month
        </div>
      )}
    </div>
  );
}

// ── Inline bar chart ──────────────────────────────────────────────────────────
function BarChart({ data, valueKey, labelKey }: { data: any[]; valueKey: string; labelKey: string }) {
  if (!data.length) return null;
  const max = Math.max(...data.map(d => d[valueKey]));
  return (
    <div className="space-y-2">
      {data.slice(0, 8).map((d, i) => (
        <div key={i} className="flex items-center gap-3">
          <div className="w-24 font-mono text-[9px] text-primary-600 truncate text-right">{d[labelKey]}</div>
          <div className="flex-1 bg-retro-bg rounded-none h-4 overflow-hidden border border-retro-border">
            <div
              className="h-full bg-primary-800 transition-all duration-500"
              style={{ width: max > 0 ? `${(d[valueKey] / max) * 100}%` : '0%' }}
            />
          </div>
          <div className="w-24 font-pixel text-[7px] text-primary-crt text-right">{fmt(d[valueKey])}</div>
        </div>
      ))}
    </div>
  );
}

// ── Trend sparkline ───────────────────────────────────────────────────────────
function Sparkline({ data, valueKey }: { data: any[]; valueKey: string }) {
  if (data.length < 2) return null;
  const vals = data.map(d => d[valueKey] ?? 0);
  const max = Math.max(...vals);
  const min = Math.min(...vals);
  const range = max - min || 1;
  const W = 300, H = 60;
  const pts = vals.map((v, i) => {
    const x = (i / (vals.length - 1)) * W;
    const y = H - ((v - min) / range) * (H - 8) - 4;
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} className="overflow-visible">
      <polyline points={pts} fill="none" stroke="rgb(34,197,94)" strokeWidth="1.5" />
      {vals.map((v, i) => {
        const x = (i / (vals.length - 1)) * W;
        const y = H - ((v - min) / range) * (H - 8) - 4;
        return (
          <g key={i}>
            <circle cx={x} cy={y} r="2.5" fill="rgb(34,197,94)" />
            <text x={x} y={H + 12} textAnchor="middle" fontSize="7" fill="rgb(96,112,96)">{data[i]?.label?.slice(0, 3)}</text>
          </g>
        );
      })}
    </svg>
  );
}

// ── Compliance event badge ────────────────────────────────────────────────────
function EventBadge({ event }: { event: any }) {
  const overdue = event.isOverdue;
  return (
    <div className={`flex items-center justify-between px-3 py-2 border rounded ${overdue ? 'border-red-800 bg-red-950/30' : 'border-retro-border bg-retro-card'}`}>
      <div>
        <div className="font-mono text-[10px] text-primary-400">{event.label}</div>
        <div className="font-pixel text-[7px] text-primary-700">Due: {event.dueDate}</div>
      </div>
      <span className={`font-pixel text-[7px] px-2 py-1 rounded ${overdue ? 'text-red-400 bg-red-900/40' : 'text-green-400 bg-green-900/20'}`}>
        {overdue ? 'OVERDUE' : 'UPCOMING'}
      </span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN CFO DASHBOARD PAGE
// ─────────────────────────────────────────────────────────────────────────────

export function CfoDashboardPage() {
  const now = new Date();
  const [month] = useState(now.getMonth() + 1);
  const [year]  = useState(now.getFullYear());
  const [simDept, setSimDept]     = useState('');
  const [simPct, setSimPct]       = useState(10);
  const [simResult, setSimResult] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'departments' | 'forecast' | 'leave' | 'simulator'>('overview');

  const { data: summary, isLoading: loadingSum } = useQuery({
    queryKey: ['cfo-summary', month, year],
    queryFn: () => api(`/analytics/cfo/cost-summary?month=${month}&year=${year}`).then(r => r.data ?? r),
  });

  const { data: depts = [], isLoading: loadingDepts } = useQuery({
    queryKey: ['cfo-depts', month, year],
    queryFn: () => api(`/analytics/cfo/department-breakdown?month=${month}&year=${year}`).then(r => r.data ?? r),
    enabled: activeTab === 'departments',
  });

  const { data: trend = [] } = useQuery({
    queryKey: ['cfo-trend'],
    queryFn: () => api('/analytics/cfo/cost-trend?months=12').then(r => r.data ?? r),
  });

  const { data: forecast } = useQuery({
    queryKey: ['cfo-forecast'],
    queryFn: () => api('/analytics/cfo/statutory-forecast').then(r => r.data ?? r),
    enabled: activeTab === 'forecast',
  });

  const { data: leaveRisk } = useQuery({
    queryKey: ['cfo-leave'],
    queryFn: () => api('/analytics/cfo/leave-liability').then(r => r.data ?? r),
    enabled: activeTab === 'leave',
  });

  const { data: departments = [] } = useQuery({
    queryKey: ['departments-list'],
    queryFn: () => api('/employees/departments').then(r => r.data ?? []),
    enabled: activeTab === 'simulator',
  });

  const simulate = useMutation({
    mutationFn: (dto: any) =>
      api('/analytics/cfo/simulate-revision', { method: 'POST', body: JSON.stringify(dto) }).then(r => r.data ?? r),
    onSuccess: (data) => setSimResult(data),
  });

  const TABS = [
    { key: 'overview',    label: 'OVERVIEW' },
    { key: 'departments', label: 'BY DEPT' },
    { key: 'forecast',    label: 'FORECAST' },
    { key: 'leave',       label: 'LEAVE RISK' },
    { key: 'simulator',   label: 'SIMULATOR' },
  ] as const;

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-pixel text-[10px] text-primary-400">CFO INTELLIGENCE DASHBOARD</h1>
          <p className="font-mono text-xs text-primary-700 mt-1">
            Financial overview · {new Date(year, month - 1).toLocaleString('en-IN', { month: 'long' })} {year}
          </p>
        </div>
        <div className="flex gap-2">
          <a
            href={`/api/v1/analytics/cfo/export/cost-report?month=${month}&year=${year}`}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-retro-border font-pixel text-[7px] text-primary-600 hover:text-primary-400 rounded"
          >
            <Download className="w-3 h-3" /> Export CSV
          </a>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-retro-border">
        {TABS.map(t => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`px-4 py-2 font-pixel text-[7px] border-b-2 transition-colors ${
              activeTab === t.key
                ? 'border-primary-crt text-primary-crt'
                : 'border-transparent text-primary-700 hover:text-primary-500'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* ── OVERVIEW TAB ──────────────────────────────────────────────────── */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          {loadingSum ? (
            <div className="font-mono text-xs text-primary-700 animate-pulse">Loading cost data...</div>
          ) : summary ? (
            <>
              {/* KPI Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <KpiCard
                  label="Total Gross" value={fmt(summary.totalGross)}
                  subtitle={`${summary.employeeCount} employees`}
                  change={summary.grossChangePercent}
                  icon={DollarSign}
                />
                <KpiCard
                  label="Total CTC" value={fmt(summary.totalCostToCompany)}
                  subtitle="Incl. employer PF+ESI"
                  change={summary.ctcChangePercent}
                  icon={TrendingUp}
                />
                <KpiCard
                  label="Employer PF" value={fmt(summary.employerPf)}
                  subtitle={`ESI: ${fmt(summary.employerEsi)}`}
                  icon={Building2}
                />
                <KpiCard
                  label="Headcount" value={fmtN(summary.employeeCount)}
                  subtitle="Active employees"
                  change={summary.headcountChangePercent}
                  icon={Users}
                />
              </div>

              {/* 12-month trend */}
              <div className="bg-retro-card border border-retro-border rounded p-4">
                <div className="font-pixel text-[8px] text-primary-600 mb-3">12-MONTH COST TREND</div>
                <Sparkline data={trend} valueKey="totalCostToCompany" />
              </div>
            </>
          ) : (
            <div className="font-mono text-xs text-primary-700">No payroll data for this period.</div>
          )}
        </div>
      )}

      {/* ── DEPARTMENTS TAB ───────────────────────────────────────────────── */}
      {activeTab === 'departments' && (
        <div className="bg-retro-card border border-retro-border rounded p-4">
          <div className="font-pixel text-[8px] text-primary-600 mb-4">DEPARTMENT COST BREAKDOWN</div>
          {loadingDepts ? (
            <div className="font-mono text-xs text-primary-700 animate-pulse">Loading...</div>
          ) : depts.length ? (
            <BarChart data={depts} valueKey="totalCostToCompany" labelKey="departmentName" />
          ) : (
            <div className="font-mono text-xs text-primary-700">No department data available.</div>
          )}
          {!!depts.length && (
            <table className="w-full mt-4 font-mono text-[10px]">
              <thead>
                <tr className="border-b border-retro-border text-primary-700">
                  <th className="text-left py-1">Department</th>
                  <th className="text-right py-1">HC</th>
                  <th className="text-right py-1">Gross</th>
                  <th className="text-right py-1">Avg CTC</th>
                  <th className="text-right py-1">Total CTC</th>
                </tr>
              </thead>
              <tbody>
                {(depts as any[]).map((d: any, i: number) => (
                  <tr key={i} className="border-b border-retro-border/30 hover:bg-primary-950/20">
                    <td className="py-1 text-primary-400">{d.departmentName}</td>
                    <td className="text-right text-primary-600">{d.headcount}</td>
                    <td className="text-right text-primary-500">{fmt(d.totalGross)}</td>
                    <td className="text-right text-primary-500">{fmt(d.avgCtc)}</td>
                    <td className="text-right text-primary-crt font-semibold">{fmt(d.totalCostToCompany)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {/* ── FORECAST TAB ──────────────────────────────────────────────────── */}
      {activeTab === 'forecast' && forecast && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-retro-card border border-retro-border rounded p-4">
              <div className="font-pixel text-[7px] text-primary-700 mb-2">TDS LIABILITY</div>
              <div className="font-pixel text-[10px] text-primary-crt">{fmt(forecast.tds.remainingLiability)}</div>
              <div className="font-mono text-[10px] text-primary-700 mt-1">remaining this FY</div>
              <div className="font-mono text-[10px] text-primary-600 mt-2">Monthly avg: {fmt(forecast.tds.monthlyAvg)}</div>
              <div className="font-mono text-[10px] text-primary-600">Paid YTD: {fmt(forecast.tds.paidYtd)}</div>
            </div>
            <div className="bg-retro-card border border-retro-border rounded p-4">
              <div className="font-pixel text-[7px] text-primary-700 mb-2">PF THIS MONTH</div>
              <div className="font-pixel text-[10px] text-primary-crt">{fmt(forecast.pf.currentMonthEmployer)}</div>
              <div className="font-mono text-[10px] text-primary-700 mt-1">employer contribution</div>
              <div className="font-mono text-[10px] text-primary-600 mt-2">Employee: {fmt(forecast.pf.currentMonthEmployee)}</div>
              <div className="font-mono text-[10px] text-primary-600">Due: {forecast.pf.nextDueDate}</div>
            </div>
            <div className="bg-retro-card border border-retro-border rounded p-4">
              <div className="font-pixel text-[7px] text-primary-700 mb-2">ESI THIS MONTH</div>
              <div className="font-pixel text-[10px] text-primary-crt">{fmt(forecast.esi.currentMonthEmployer)}</div>
              <div className="font-mono text-[10px] text-primary-700 mt-1">employer contribution</div>
              <div className="font-mono text-[10px] text-primary-600 mt-2">Employee: {fmt(forecast.esi.currentMonthEmployee)}</div>
              <div className="font-mono text-[10px] text-primary-600">Due: {forecast.esi.nextDueDate}</div>
            </div>
          </div>

          <div className="bg-retro-card border border-retro-border rounded p-4">
            <div className="font-pixel text-[8px] text-primary-600 mb-3">COMPLIANCE CALENDAR</div>
            <div className="space-y-2">
              {forecast.complianceCalendar?.map((e: any, i: number) => (
                <EventBadge key={i} event={e} />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── LEAVE RISK TAB ────────────────────────────────────────────────── */}
      {activeTab === 'leave' && leaveRisk && (
        <div className="space-y-4">
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-retro-card border border-amber-900/40 rounded p-4">
              <div className="font-pixel text-[7px] text-amber-600 mb-2">TOTAL UNUSED DAYS</div>
              <div className="font-pixel text-[11px] text-amber-400">{fmtN(leaveRisk.totalUnusedDays)}</div>
              <div className="font-mono text-[10px] text-primary-700 mt-1">across all employees</div>
            </div>
            <div className="bg-retro-card border border-amber-900/40 rounded p-4">
              <div className="font-pixel text-[7px] text-amber-600 mb-2">ENCASHABLE DAYS</div>
              <div className="font-pixel text-[11px] text-amber-400">{fmtN(leaveRisk.encashableUnusedDays)}</div>
              <div className="font-mono text-[10px] text-primary-700 mt-1">eligible for encashment</div>
            </div>
            <div className="bg-retro-card border border-red-900/40 rounded p-4">
              <div className="font-pixel text-[7px] text-red-500 mb-2">MONETARY RISK</div>
              <div className="font-pixel text-[11px] text-red-400">{fmt(leaveRisk.monetaryValueAtRisk)}</div>
              <div className="font-mono text-[10px] text-primary-700 mt-1">at risk of encashment</div>
            </div>
          </div>

          {leaveRisk.departmentBreakdown?.length > 0 && (
            <div className="bg-retro-card border border-retro-border rounded p-4">
              <div className="font-pixel text-[8px] text-primary-600 mb-3">DEPARTMENT LEAVE BURDEN</div>
              <BarChart data={leaveRisk.departmentBreakdown} valueKey="encashableValue" labelKey="departmentName" />
            </div>
          )}
        </div>
      )}

      {/* ── SIMULATOR TAB ─────────────────────────────────────────────────── */}
      {activeTab === 'simulator' && (
        <div className="space-y-4">
          <div className="bg-amber-950/20 border border-amber-800/40 rounded p-3">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-500" />
              <span className="font-pixel text-[7px] text-amber-500">SIMULATION MODE — NO PAYROLL DATA IS MODIFIED</span>
            </div>
          </div>

          <div className="bg-retro-card border border-retro-border rounded p-4 space-y-4">
            <div className="font-pixel text-[8px] text-primary-600">SALARY REVISION IMPACT SIMULATOR</div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="font-pixel text-[7px] text-primary-700 block mb-1">DEPARTMENT</label>
                <select
                  value={simDept}
                  onChange={e => setSimDept(e.target.value)}
                  className="w-full bg-retro-bg border border-retro-border rounded px-3 py-2 font-mono text-sm text-primary-400 focus:border-primary-crt outline-none"
                >
                  <option value="">Select department...</option>
                  {(departments as any[]).map((d: any) => (
                    <option key={d.id} value={d.id}>{d.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="font-pixel text-[7px] text-primary-700 block mb-1">INCREMENT % ({simPct}%)</label>
                <input
                  type="range" min="1" max="50" value={simPct}
                  onChange={e => setSimPct(parseInt(e.target.value))}
                  className="w-full accent-green-500"
                />
                <div className="flex justify-between font-mono text-[9px] text-primary-800 mt-1">
                  <span>1%</span><span>25%</span><span>50%</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => simDept && simulate.mutate({ departmentId: simDept, incrementPercent: simPct })}
              disabled={!simDept || simulate.isPending}
              className="flex items-center gap-2 px-4 py-2 bg-primary-900 border border-primary-700 font-pixel text-[7px] text-primary-crt rounded hover:bg-primary-800 disabled:opacity-40"
            >
              {simulate.isPending ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Zap className="w-3 h-3" />}
              RUN SIMULATION
            </button>

            {simResult && (
              <div className="border border-primary-800 rounded p-4 space-y-3">
                <div className="font-pixel text-[8px] text-primary-crt">SIMULATION RESULT — {simResult.departmentName?.toUpperCase()}</div>
                <div className="grid grid-cols-2 gap-4 font-mono text-[10px]">
                  <div className="space-y-2">
                    <div className="text-primary-700">Headcount: <span className="text-primary-400">{simResult.currentHeadcount}</span></div>
                    <div className="text-primary-700">Current Annual Gross: <span className="text-primary-400">{fmt(simResult.currentAnnualGross)}</span></div>
                    <div className="text-primary-700">Projected Annual Gross: <span className="text-green-400">{fmt(simResult.projectedAnnualGross)}</span></div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-primary-700">Annual Gross Increase: <span className="text-amber-400">{fmt(simResult.annualGrossIncrease)}</span></div>
                    <div className="text-primary-700">Monthly Gross Increase: <span className="text-amber-400">{fmt(simResult.monthlyGrossIncrease)}</span></div>
                    <div className="text-primary-700">Additional PF (annual): <span className="text-primary-400">{fmt(simResult.additionalEmployerPfAnnual)}</span></div>
                  </div>
                </div>
                <div className="border-t border-primary-800 pt-3">
                  <div className="flex justify-between items-center">
                    <span className="font-pixel text-[7px] text-primary-700">TOTAL ADDITIONAL CTC (ANNUAL)</span>
                    <span className="font-pixel text-[10px] text-primary-crt">{fmt(simResult.additionalTotalCtcAnnual)}</span>
                  </div>
                  <div className="flex justify-between items-center mt-1">
                    <span className="font-pixel text-[7px] text-primary-700">MONTHLY IMPACT</span>
                    <span className="font-pixel text-[10px] text-amber-400">{fmt(simResult.additionalTotalCtcMonthly)}</span>
                  </div>
                </div>
                <div className="font-mono text-[9px] text-primary-800 italic">{simResult.note}</div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
