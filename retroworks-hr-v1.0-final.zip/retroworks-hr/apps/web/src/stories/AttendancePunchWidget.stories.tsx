import type { Meta, StoryObj } from '@storybook/react';
import { within, userEvent } from '@storybook/testing-library';
import { expect } from '@storybook/jest';

// Simplified version for Storybook (no fetch calls)
function AttendancePunchWidget({ status = 'not-started', punchInTime, totalMinutes = 0 }: {
  status?: 'not-started' | 'punched-in' | 'punched-out';
  punchInTime?: string;
  totalMinutes?: number;
}) {
  const formatMinutes = (mins: number) => {
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h}h ${m.toString().padStart(2, '0')}m`;
  };

  return (
    <div className="bg-retro-card border border-retro-border rounded-lg p-6 text-center space-y-4 max-w-sm mx-auto">
      <div className="flex items-center justify-center gap-2">
        <span className={`w-3 h-3 rounded-full ${
          status === 'punched-in' ? 'bg-primary-crt animate-pulse' :
          status === 'punched-out' ? 'bg-primary-700' : 'bg-retro-border'
        }`} />
        <span className="font-pixel text-[9px] text-primary-500">
          {status === 'punched-in' ? 'WORKING' : status === 'punched-out' ? 'COMPLETED' : 'NOT STARTED'}
        </span>
      </div>

      <div className="font-pixel text-4xl text-primary-crt">{formatMinutes(totalMinutes)}</div>

      <div className="flex justify-center gap-8 font-mono text-xs text-primary-700">
        <div>
          <p className="text-[9px] mb-0.5">PUNCH IN</p>
          <p className="text-primary-400">{punchInTime ?? '—:——'}</p>
        </div>
        <div>
          <p className="text-[9px] mb-0.5">PUNCH OUT</p>
          <p className="text-primary-400">—:——</p>
        </div>
      </div>

      {status === 'not-started' && (
        <button
          data-testid="punch-in-btn"
          className="flex items-center gap-2 mx-auto px-8 py-3 bg-primary-900 border-2 border-primary-600 hover:border-primary-crt hover:shadow-glow-strong font-pixel text-[9px] text-primary-crt rounded-lg transition-all active:translate-y-px"
        >
          ▶ PUNCH IN
        </button>
      )}
      {status === 'punched-in' && (
        <button className="flex items-center gap-2 mx-auto px-8 py-3 bg-amber-950 border-2 border-amber-700 font-pixel text-[9px] text-amber-400 rounded-lg">
          ⏸ PUNCH OUT
        </button>
      )}
      {status === 'punched-out' && (
        <div className="flex items-center justify-center gap-2 text-primary-600">
          <span>✓</span>
          <span className="font-pixel text-[8px]">DAY COMPLETE</span>
        </div>
      )}
    </div>
  );
}

const meta = {
  title: 'Features/AttendancePunchWidget',
  component: AttendancePunchWidget,
  tags: ['autodocs'],
  argTypes: {
    status: {
      control: 'radio',
      options: ['not-started', 'punched-in', 'punched-out'],
    },
    totalMinutes: { control: { type: 'range', min: 0, max: 600, step: 15 } },
  },
} satisfies Meta<typeof AttendancePunchWidget>;

export default meta;
type Story = StoryObj<typeof meta>;

export const NotStarted: Story = {
  args: { status: 'not-started', totalMinutes: 0 },
};

export const PunchedIn: Story = {
  args: { status: 'punched-in', punchInTime: '09:30', totalMinutes: 165 },
};

export const PunchedOut: Story = {
  args: { status: 'punched-out', punchInTime: '09:30', totalMinutes: 480 },
};

export const WithInteraction: Story = {
  args: { status: 'not-started' },
  play: async ({ canvasElement }: { canvasElement: HTMLElement }) => {
    const canvas = within(canvasElement);
    const btn = canvas.getByTestId('punch-in-btn');
    await expect(btn).toBeInTheDocument();
    await userEvent.hover(btn);
  },
};
