import type { Meta, StoryObj } from '@storybook/react';
import { Button } from '../../packages/ui/src/components/Button';

const meta = {
  title: 'UI/Button',
  component: Button,
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['primary', 'accent', 'ghost', 'danger', 'terminal', 'link'],
      description: 'Visual style variant',
    },
    size: {
      control: 'select',
      options: ['xs', 'sm', 'md', 'lg'],
    },
    loading: { control: 'boolean' },
    disabled: { control: 'boolean' },
  },
} satisfies Meta<typeof Button>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: { children: 'PRIMARY ACTION', variant: 'primary' },
};

export const Accent: Story = {
  args: { children: 'ACCENT ACTION', variant: 'accent' },
};

export const Ghost: Story = {
  args: { children: 'GHOST BUTTON', variant: 'ghost' },
};

export const Danger: Story = {
  args: { children: 'DELETE RECORD', variant: 'danger' },
};

export const Terminal: Story = {
  args: { children: '[ EXECUTE ]', variant: 'terminal' },
};

export const Loading: Story = {
  args: { children: 'PROCESSING', variant: 'primary', loading: true },
};

export const Disabled: Story = {
  args: { children: 'DISABLED', variant: 'primary', disabled: true },
};

export const AllVariants: Story = {
  render: () => (
    <div className="flex flex-wrap gap-3">
      {(['primary', 'accent', 'ghost', 'danger', 'terminal'] as const).map(v => (
        <Button key={v} variant={v}>{v.toUpperCase()}</Button>
      ))}
    </div>
  ),
};

export const AllSizes: Story = {
  render: () => (
    <div className="flex items-center gap-3">
      {(['xs', 'sm', 'md', 'lg'] as const).map(s => (
        <Button key={s} size={s}>SIZE {s.toUpperCase()}</Button>
      ))}
    </div>
  ),
};
