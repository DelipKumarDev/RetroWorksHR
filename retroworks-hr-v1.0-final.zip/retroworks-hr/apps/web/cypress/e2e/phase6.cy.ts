/**
 * Phase 6 E2E Tests — Differentiation Layer
 * Simulation, Skills, Policy Engine, Compliance, Decision Assist,
 * Timeline, Ethics, People Analytics Lab
 *
 * Run: pnpm --filter @retroworks/web cypress run --spec phase6.cy.ts
 */

describe('Phase 6 — Category-Creating Differentiators', () => {
  const baseUrl = Cypress.env('API_URL') ?? 'http://localhost:3001/api/v1';
  let token: string;
  let employeeId: string;

  before(() => {
    cy.request({ method: 'POST', url: `${baseUrl}/auth/login`, body: { email: 'hr@demo.retroworks.hr', password: 'RetroWorks@123' } })
      .then(res => {
        token = res.body.data.accessToken;
        cy.request({ method: 'GET', url: `${baseUrl}/employees?limit=1`, headers: { Authorization: `Bearer ${token}` } })
          .then(r => { employeeId = r.body.data?.data?.[0]?.id; });
      });
  });

  const auth = () => ({ Authorization: `Bearer ${token}` });

  // ═══ ORG DIGITAL TWIN / SIMULATION ══════════════════════════

  describe('Organization Digital Twin', () => {
    it('GET /simulation/baseline — returns live org snapshot', () => {
      cy.request({ url: `${baseUrl}/simulation/baseline`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        const d = res.body.data;
        expect(d).to.have.all.keys('headcount', 'monthlyPayroll', 'annualPayroll', 'monthlyEmployerCost', 'pfContribution', 'esiContribution', 'averageCTC', 'departmentBreakdown');
        expect(d.headcount).to.be.a('number').and.be.gte(0);
        expect(d.annualPayroll).to.eq(d.monthlyPayroll * 12);
        expect(d.departmentBreakdown).to.be.an('array');
      });
    });

    it('POST /simulation/run — mass attrition scenario', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/simulation/run`, headers: auth(),
        body: { scenario: 'mass_attrition', name: 'Test attrition 5', attritionCount: 5 },
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        const d = res.body.data;
        expect(d).to.have.property('scenarioId');
        expect(d).to.have.property('baseline');
        expect(d).to.have.property('projected');
        expect(d).to.have.property('delta');
        expect(d).to.have.property('riskFlags');
        expect(d.delta.headcountChange).to.eq(-5);
        expect(d.delta.monthlyPayrollChange).to.be.lte(0);
        expect(d.riskFlags).to.be.an('array');
      });
    });

    it('POST /simulation/run — salary increment scenario', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/simulation/run`, headers: auth(),
        body: { scenario: 'salary_increment', name: '10% increment all', incrementPercent: 10 },
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        expect(res.body.data.delta.percentageChange).to.be.closeTo(10, 1);
      });
    });

    it('POST /simulation/run — hiring plan scenario', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/simulation/run`, headers: auth(),
        body: { scenario: 'hiring_plan', name: 'Q2 hiring plan', hireCount: 10, hireAverageCTC: 900000 },
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        expect(res.body.data.delta.headcountChange).to.eq(10);
        expect(res.body.data.timeline).to.be.an('array').with.length.gte(6);
      });
    });

    it('GET /simulation/scenarios — lists saved scenarios', () => {
      cy.request({ url: `${baseUrl}/simulation/scenarios`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
        if (res.body.data.length > 0) {
          expect(res.body.data[0]).to.have.all.keys('id', 'name', 'scenario', 'baselineHeadcount', 'projectedHeadcount', 'payrollDelta', 'headcountDelta', 'createdAt');
        }
      });
    });
  });

  // ═══ SKILL & CAPABILITY GRAPH ════════════════════════════════

  describe('Skill Intelligence Graph', () => {
    let skillId: string;

    it('POST /skills — creates a skill in the org library', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/skills`, headers: auth(),
        body: { name: 'TypeScript', category: 'Technical', isCritical: true },
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        skillId = res.body.data.id;
        expect(res.body.data.isCritical).to.be.true;
      });
    });

    it('GET /skills — lists skill library', () => {
      cy.request({ url: `${baseUrl}/skills`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
      });
    });

    it('GET /skills/heatmap — returns dept × skill coverage matrix', () => {
      cy.request({ url: `${baseUrl}/skills/heatmap`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
        if (res.body.data.length > 0) {
          const row = res.body.data[0];
          expect(row).to.have.property('departmentId');
          expect(row).to.have.property('departmentName');
          expect(row).to.have.property('skills');
          expect(row.skills).to.be.an('array');
        }
      });
    });

    it('GET /skills/gap-analysis — returns employee skill gap scores', () => {
      cy.request({ url: `${baseUrl}/skills/gap-analysis`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        const d = res.body.data;
        expect(d).to.have.all.keys('totalAnalyzed', 'withGaps', 'criticalGaps', 'employees');
      });
    });

    it('GET /skills/critical-roles — flags single-point-of-failure skills', () => {
      cy.request({ url: `${baseUrl}/skills/critical-roles`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
        res.body.data.forEach((r: any) => {
          expect(['critical', 'high', 'medium']).to.include(r.risk);
          expect(r).to.have.property('recommendation');
        });
      });
    });

    it('GET /skills/succession — returns ranked succession candidates', () => {
      cy.request({ url: `${baseUrl}/skills/succession`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
        if (res.body.data.length > 0) {
          expect(res.body.data[0]).to.have.all.keys('employeeId', 'name', 'readinessScore', 'readinessLevel', 'skillGaps');
          expect(['ready_now', 'ready_1yr', 'ready_2yr', 'not_ready']).to.include(res.body.data[0].readinessLevel);
        }
      });
    });

    it('GET /skills/summary — org skill health dashboard', () => {
      cy.request({ url: `${baseUrl}/skills/summary`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.all.keys('totalSkills', 'totalEmployeesWithSkills', 'criticalSkillCount', 'employeesWithGaps', 'criticalRoleRisks');
      });
    });
  });

  // ═══ POLICY ENGINE ════════════════════════════════════════════

  describe('Versioned Policy Engine', () => {
    let policyId: string;

    it('POST /policies — creates a versioned HR policy', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/policies`, headers: auth(),
        body: { name: 'Work From Home Policy', category: 'work_arrangement', content: 'Employees may work from home up to 3 days per week.', effectiveDate: '2025-01-01', requiresAcknowledgment: true, acknowledgmentDeadlineDays: 14 },
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        policyId = res.body.data.id;
        expect(res.body.data.currentVersion).to.eq(1);
        expect(res.body.data.requiresAcknowledgment).to.be.true;
      });
    });

    it('POST /policies/:id/versions — publishes new version', () => {
      if (!policyId) return;
      cy.request({
        method: 'POST', url: `${baseUrl}/policies/${policyId}/versions`, headers: auth(),
        body: { content: 'Updated: Employees may work from home up to 4 days per week effective Q2.', effectiveDate: '2025-04-01', changeLog: 'Increased WFH allowance', retroactive: false },
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        expect(res.body.data.newVersion).to.eq(2);
      });
    });

    it('GET /policies/:id/versions — returns version history', () => {
      if (!policyId) return;
      cy.request({ url: `${baseUrl}/policies/${policyId}/versions`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array').with.length.gte(2);
        expect(res.body.data[0].version).to.be.gte(res.body.data[1].version);
      });
    });

    it('GET /policies/:id/acknowledgments — shows who has/has not acknowledged', () => {
      if (!policyId) return;
      cy.request({ url: `${baseUrl}/policies/${policyId}/acknowledgments`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        const d = res.body.data;
        expect(d).to.have.all.keys('total', 'acknowledged', 'pending', 'pendingEmployees');
        expect(d.total).to.eq(d.acknowledged + d.pending);
      });
    });
  });

  // ═══ LIVE COMPLIANCE MONITOR ══════════════════════════════════

  describe('India Compliance Monitor', () => {
    it('GET /compliance/score — returns real-time compliance score', () => {
      cy.request({ url: `${baseUrl}/compliance/score`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        const d = res.body.data;
        expect(d).to.have.all.keys('overallScore', 'grade', 'checks', 'lastUpdated');
        expect(d.overallScore).to.be.gte(0).and.lte(100);
        expect(['A', 'B', 'C', 'D', 'F']).to.include(d.grade);
        expect(d.checks).to.be.an('array').with.length.gte(5);
        // Verify check structure
        d.checks.forEach((c: any) => {
          expect(c).to.have.all.keys('id', 'name', 'category', 'status', 'score', 'details', 'dueDate', 'filedDate');
          expect(['compliant', 'non_compliant', 'warning', 'pending', 'not_applicable']).to.include(c.status);
          expect(c.score).to.be.gte(0).and.lte(100);
        });
      });
    });

    it('GET /compliance/score — includes PF, ESI, and Leave checks', () => {
      cy.request({ url: `${baseUrl}/compliance/score`, headers: auth() }).then(res => {
        const checkIds = res.body.data.checks.map((c: any) => c.id);
        expect(checkIds).to.include('pf');
        expect(checkIds).to.include('esi');
        expect(checkIds).to.include('leave');
        expect(checkIds).to.include('min_wage');
      });
    });

    it('GET /compliance/state-wise — returns per-location compliance data', () => {
      cy.request({ url: `${baseUrl}/compliance/state-wise`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
        res.body.data.forEach((row: any) => {
          expect(row).to.have.all.keys('locationId', 'locationName', 'stateCode', 'minimumWage', 'ptApplicable', 'ptAnnual');
        });
      });
    });
  });

  // ═══ DECISION ASSIST ══════════════════════════════════════════

  describe('AI Decision Assist', () => {
    it('POST /decision-assist/analyze — leave approval analysis', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/decision-assist/analyze`, headers: auth(),
        body: { action: 'approve_leave', employeeId: employeeId ?? 'test-id', params: { days: 10, startDate: new Date(Date.now() + 7 * 86_400_000).toISOString().split('T')[0] } },
        failOnStatusCode: false,
      }).then(res => {
        expect([200, 201, 404]).to.include(res.status);
        if (res.status !== 404) {
          const d = res.body.data;
          expect(d).to.have.all.keys('proceed', 'insights', 'requiresConfirmation');
          expect(d.insights).to.be.an('array');
          d.insights.forEach((ins: any) => {
            expect(ins).to.have.all.keys('type', 'severity', 'title', 'detail');
            expect(['critical', 'warning', 'info']).to.include(ins.severity);
          });
        }
      });
    });

    it('POST /decision-assist/analyze — salary change triggers cost impact insight', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/decision-assist/analyze`, headers: auth(),
        body: { action: 'change_salary', employeeId: employeeId ?? 'test-id', params: { newCTC: 2500000, reason: 'Annual revision' } },
        failOnStatusCode: false,
      }).then(res => {
        if (res.status === 200) {
          const costInsight = res.body.data.insights.find((i: any) => i.type === 'cost_impact');
          expect(costInsight).to.exist;
          expect(costInsight.detail).to.include('₹');
        }
      });
    });

    it('POST /decision-assist/analyze — promotion check verifies performance threshold', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/decision-assist/analyze`, headers: auth(),
        body: { action: 'promote', employeeId: employeeId ?? 'test-id', params: { newDesignation: 'Senior Engineer' } },
        failOnStatusCode: false,
      }).then(res => {
        if (res.status === 200) {
          expect(res.body.data.insights).to.be.an('array');
        }
      });
    });
  });

  // ═══ EMPLOYEE TIMELINE ════════════════════════════════════════

  describe('Employee Lifecycle Timeline', () => {
    it('GET /timeline/employees/:id — returns chronological story', () => {
      if (!employeeId) return;
      cy.request({ url: `${baseUrl}/timeline/employees/${employeeId}`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
        res.body.data.forEach((evt: any) => {
          expect(evt).to.have.property('date');
          expect(evt).to.have.property('type');
          expect(evt).to.have.property('title');
        });
        // Events should be sorted newest first
        if (res.body.data.length > 1) {
          const first = new Date(res.body.data[0].date).getTime();
          const second = new Date(res.body.data[1].date).getTime();
          expect(first).to.be.gte(second);
        }
      });
    });
  });

  // ═══ ETHICS & BIAS DETECTION ══════════════════════════════════

  describe('Ethics & Bias Detection', () => {
    it('GET /ethics/bias-report — returns bias checks across 4 dimensions', () => {
      cy.request({ url: `${baseUrl}/ethics/bias-report`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        const d = res.body.data;
        expect(d).to.have.property('overallFairness');
        expect(d).to.have.property('checks');
        expect(d.overallFairness).to.be.gte(0).and.lte(100);
        expect(d.checks).to.be.an('array').with.lengthOf(4);

        const checkIds = d.checks.map((c: any) => c.id);
        expect(checkIds).to.include('gender_pay_gap');
        expect(checkIds).to.include('promotion_bias');
        expect(checkIds).to.include('rating_bias');
        expect(checkIds).to.include('hiring_bias');

        d.checks.forEach((c: any) => {
          expect(c).to.have.all.keys('id', 'name', 'severity', 'fairnessScore', 'detail', 'recommendation');
          expect(['high', 'medium', 'low']).to.include(c.severity);
          expect(c.fairnessScore).to.be.gte(0).and.lte(100);
        });
      });
    });
  });

  // ═══ PEOPLE ANALYTICS LAB ════════════════════════════════════

  describe('People Analytics Lab', () => {
    it('GET /analytics-lab/correlations — returns performance/leave correlation, burnout, manager scores', () => {
      cy.request({ url: `${baseUrl}/analytics-lab/correlations`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        const d = res.body.data;
        expect(d).to.have.property('performanceVsLeave');
        expect(d).to.have.property('burnout');
        expect(d).to.have.property('managerEffectiveness');

        const pvl = d.performanceVsLeave;
        expect(pvl).to.have.all.keys('lowPerformers', 'medPerformers', 'highPerformers', 'insight');
        expect(pvl.lowPerformers).to.have.all.keys('count', 'avgLeaveDays');

        expect(d.burnout).to.be.an('array');
        d.burnout.forEach((b: any) => {
          expect(b).to.have.all.keys('departmentId', 'departmentName', 'burnoutScore', 'risk', 'avgOvertimeHours');
          expect(['high', 'medium', 'low']).to.include(b.risk);
          expect(b.burnoutScore).to.be.gte(0).and.lte(100);
        });

        expect(d.managerEffectiveness).to.be.an('array');
      });
    });
  });

  // ═══ INTEGRATION HUB / API KEYS ═══════════════════════════════

  describe('Integration Hub', () => {
    it('GET /integrations — returns all integrations with connection status', () => {
      cy.request({ url: `${baseUrl}/integrations`, headers: auth() }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
        const types = res.body.data.map((i: any) => i.type);
        expect(types).to.include.members(['slack', 'zoom']);
      });
    });
  });

  // ═══ PAYROLL PREVIEW SIMULATOR ════════════════════════════════

  describe('Payroll Preview Simulator', () => {
    it('GET /payroll/preview — computes live payroll before running', () => {
      cy.request({
        url: `${baseUrl}/payroll/preview?month=${new Date().getMonth() + 1}&year=${new Date().getFullYear()}`,
        headers: auth(), failOnStatusCode: false,
      }).then(res => {
        expect([200, 201, 400, 404]).to.include(res.status);
        if (res.status === 200) {
          expect(res.body.data).to.have.property('employees');
          expect(res.body.data).to.have.property('summary');
        }
      });
    });
  });

  // ═══ FRONTEND PAGE SMOKE TESTS ════════════════════════════════

  describe('Frontend Page Smoke Tests', () => {
    beforeEach(() => {
      cy.window().then(win => { win.localStorage.setItem('token', token); });
    });

    it('/dashboard/simulation — renders simulation page', () => {
      cy.visit('/dashboard/simulation');
      cy.contains(/ORG DIGITAL TWIN|SIMULATION/i, { timeout: 10000 }).should('exist');
    });

    it('/dashboard/compliance — renders compliance dashboard', () => {
      cy.visit('/dashboard/compliance');
      cy.contains(/COMPLIANCE|PF|ESI/i, { timeout: 10000 }).should('exist');
    });

    it('/dashboard/skills — renders skills page', () => {
      cy.visit('/dashboard/skills');
      cy.contains(/SKILL/i, { timeout: 10000 }).should('exist');
    });

    it('/dashboard/ethics — renders ethics/bias report', () => {
      cy.visit('/dashboard/ethics');
      cy.contains(/ETHICS|BIAS|FAIRNESS/i, { timeout: 10000 }).should('exist');
    });
  });
});
