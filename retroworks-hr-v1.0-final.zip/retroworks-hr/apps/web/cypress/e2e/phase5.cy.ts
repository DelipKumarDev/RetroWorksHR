/**
 * Phase 5 E2E Tests — Setup, Automation, Documents, Insights, Command Bar
 * Run: pnpm --filter @retroworks/web cypress run --spec phase5.cy.ts
 */

describe('Phase 5 — UX + Automation + Insights', () => {
  const baseUrl = Cypress.env('API_URL') ?? 'http://localhost:3001/api/v1';
  let token: string;

  before(() => {
    cy.request({ method: 'POST', url: `${baseUrl}/auth/login`, body: { email: 'hr@demo.retroworks.hr', password: 'RetroWorks@123' } }).then(res => { token = res.body.data.accessToken; });
  });

  // ── Setup Wizard API ─────────────────────────────────────────────

  describe('Setup Wizard', () => {
    it('POST /setup/complete — completes guided company setup', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/setup/complete`,
        headers: { Authorization: `Bearer ${token}` },
        body: {
          company: { name: 'Cypress Test Co' },
          industry: 'tech',
          headcount: '1-50',
          policies: { cl: 12, sl: 12, el: 18, workingDays: 5, workingHours: 9, probationMonths: 6, noticePeriodDays: 90, includeIndiaHolidays: true },
          payroll: { taxRegime: 'new', pfOptIn: true, autoRun: false },
        },
        failOnStatusCode: false,
      }).then(res => {
        expect([200, 201, 400, 422]).to.include(res.status);
      });
    });
  });

  // ── Automation API ───────────────────────────────────────────────

  describe('Automation Rules', () => {
    it('GET /automation/catalogue — returns trigger and action catalogue', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/automation/catalogue`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.property('triggers');
        expect(res.body.data).to.have.property('actions');
        expect(res.body.data.triggers).to.be.an('array').with.length.greaterThan(0);
        expect(res.body.data.actions).to.be.an('array').with.length.greaterThan(0);
      });
    });

    it('POST /automation/rules — creates an IF/THEN automation rule', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/automation/rules`,
        headers: { Authorization: `Bearer ${token}` },
        body: {
          name: 'Long leave escalation test',
          description: 'Test rule for Cypress',
          trigger: 'leave.submitted',
          conditions: [{ field: 'leave.days', operator: 'gt', value: '3' }],
          conditionLogic: 'AND',
          actions: [{ type: 'notify_manager', params: { message: 'Leave > 3 days from {{employee.firstName}}' } }],
        },
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        expect(res.body.data).to.have.property('id');
        expect(res.body.data.name).to.eq('Long leave escalation test');
        expect(res.body.data.isActive).to.be.true;

        // Clean up
        const ruleId = res.body.data.id;
        cy.request({ method: 'DELETE', url: `${baseUrl}/automation/rules/${ruleId}`, headers: { Authorization: `Bearer ${token}` } });
      });
    });

    it('GET /automation/rules — lists tenant automation rules', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/automation/rules`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
      });
    });
  });

  // ── Document Templates API ───────────────────────────────────────

  describe('Document Engine', () => {
    it('GET /documents/templates — returns both builtin and custom templates', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/documents/templates`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.property('builtins');
        expect(res.body.data).to.have.property('custom');
        expect(res.body.data.builtins).to.be.an('array').with.length.greaterThan(0);
        // Built-ins should include offer letter
        const builtinTypes = res.body.data.builtins.map((t: any) => t.id);
        expect(builtinTypes).to.include('offer_letter');
      });
    });

    it('GET /documents/templates/offer_letter — fetches builtin offer letter template', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/documents/templates/offer_letter`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.property('body');
        expect(res.body.data.body).to.include('{{candidate.name}}');
      });
    });

    it('POST /documents/generate — generates document from template with variables', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/documents/generate`,
        headers: { Authorization: `Bearer ${token}` },
        body: {
          templateId: 'offer_letter',
          variables: {
            'candidate.name': 'Jane Doe', designation: 'Software Engineer', department: 'Engineering',
            ctc: '1200000', joiningDate: '2025-03-01', reportingManager: 'Ravi Kumar',
            probationMonths: 6, noticePeriodDays: 90, acceptanceDeadline: '2025-02-15',
          },
          saveToVault: false,
        },
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        expect(res.body.data).to.have.property('content');
        expect(res.body.data.content).to.include('Jane Doe');
        expect(res.body.data.content).to.include('Software Engineer');
      });
    });

    it('POST /documents/templates/:id/clone — clones builtin for customization', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/documents/templates/offer_letter/clone`,
        headers: { Authorization: `Bearer ${token}` },
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        expect(res.body.data.name).to.include('Offer Letter');
        expect(res.body.data.isBuiltin).to.be.false;
        // Clean up
        cy.request({ method: 'DELETE', url: `${baseUrl}/documents/templates/${res.body.data.id}`, headers: { Authorization: `Bearer ${token}` } });
      });
    });

    it('GET /documents/vault/me — returns my generated documents', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/documents/vault/me`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
      });
    });
  });

  // ── Insights API ─────────────────────────────────────────────────

  describe('HR Insights', () => {
    it('GET /insights/dashboard — returns insights summary', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/insights/dashboard`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.property('attritionRisk');
        expect(res.body.data).to.have.property('leaveInsights');
        expect(res.body.data).to.have.property('headcount');
        expect(res.body.data.attritionRisk).to.have.property('highRisk');
        expect(res.body.data.attritionRisk).to.have.property('mediumRisk');
      });
    });

    it('GET /insights/attrition-risk — returns scored employee risk list', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/insights/attrition-risk?limit=10`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
        if (res.body.data.length > 0) {
          const first = res.body.data[0];
          expect(first).to.have.property('riskScore');
          expect(first).to.have.property('riskLevel');
          expect(['low', 'medium', 'high']).to.include(first.riskLevel);
          expect(first).to.have.property('flags');
        }
      });
    });

    it('GET /insights/headcount-forecast — returns 12mo history + 3mo forecast', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/insights/headcount-forecast`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.property('history');
        expect(res.body.data).to.have.property('forecast');
        expect(res.body.data).to.have.property('trend');
        expect(res.body.data.history).to.be.an('array');
        expect(res.body.data.forecast).to.have.lengthOf(3);
        expect(['growing', 'declining', 'stable']).to.include(res.body.data.trend);
      });
    });

    it('GET /insights/payroll-projection — returns actuals + 3mo projection', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/insights/payroll-projection`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.property('actuals');
        expect(res.body.data).to.have.property('forecast');
        expect(res.body.data).to.have.property('annualProjection');
      });
    });

    it('GET /insights/leave — returns high utilizers and monthly trend', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/insights/leave`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.property('highUtilizers');
        expect(res.body.data).to.have.property('monthlyTrend');
        expect(res.body.data.monthlyTrend).to.be.an('array').with.lengthOf(6);
      });
    });
  });

  // ── Notifications API ────────────────────────────────────────────

  describe('Notifications', () => {
    it('GET /notifications — returns array of notifications', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/notifications`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
      });
    });

    it('GET /notifications/count — returns unread count', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/notifications/count`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.a('number');
      });
    });

    it('POST /notifications/read — marks all as read', () => {
      cy.request({ method: 'POST', url: `${baseUrl}/notifications/read`, headers: { Authorization: `Bearer ${token}` }, body: {} }).then(res => {
        expect([200, 204]).to.include(res.status);
      });
    });
  });

  // ── Settings API ─────────────────────────────────────────────────

  describe('Settings', () => {
    it('GET /settings/roles — returns system and custom roles', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/settings/roles`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.property('systemRoles');
        expect(res.body.data).to.have.property('customRoles');
        expect(res.body.data.systemRoles.map((r: any) => r.name)).to.include('hr-admin');
      });
    });

    it('GET /settings/features — returns feature flag map', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/settings/features`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.have.property('ai');
        expect(res.body.data).to.have.property('slackIntegration');
      });
    });

    it('GET /settings/audit-log — returns audit entries', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/settings/audit-log`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
      });
    });
  });

  // ── AI Module API ────────────────────────────────────────────────

  describe('AI Module', () => {
    it('GET /ai/sessions — returns conversation sessions', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/ai/sessions`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
      });
    });

    it('GET /ai/kb/documents — returns knowledge base documents list', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/ai/kb/documents`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('array');
      });
    });

    it('POST /ai/resume/parse — parses resume text into structured JSON', () => {
      cy.request({
        method: 'POST', url: `${baseUrl}/ai/resume/parse`,
        headers: { Authorization: `Bearer ${token}` },
        body: { resumeText: 'Priya Sharma\nEmail: priya@example.com\nPhone: +91 9876543210\n\nExperience: 5 years in software engineering\nSkills: React, Node.js, TypeScript, PostgreSQL\n\nWork History:\n- Senior Engineer at Infosys (2021-2024)\n- Engineer at Wipro (2019-2021)\n\nEducation: B.Tech Computer Science, IIT Delhi (2019)' },
        failOnStatusCode: false,
      }).then(res => {
        expect([200, 201]).to.include(res.status);
        if (res.status === 200 || res.status === 201) {
          expect(res.body.data).to.have.property('skills');
          expect(res.body.data).to.have.property('workHistory');
        }
      });
    });

    it('GET /ai/search?q=... — smart unified search returns employees and kb', () => {
      cy.request({ method: 'GET', url: `${baseUrl}/ai/search?q=engineer&types=employees`, headers: { Authorization: `Bearer ${token}` } }).then(res => {
        expect(res.status).to.eq(200);
        expect(res.body.data).to.be.an('object');
      });
    });
  });

  // ── Frontend Smoke Tests ──────────────────────────────────────────

  describe('Frontend Pages', () => {
    it('Dashboard loads employee home', () => {
      cy.visit('/dashboard');
      cy.get('[class*="font-pixel"]', { timeout: 10000 }).should('exist');
    });

    it('Automation page renders', () => {
      cy.visit('/dashboard/automation');
      cy.contains('AUTOMATION', { timeout: 10000 }).should('exist');
    });

    it('AI chat page renders RetroBot', () => {
      cy.visit('/dashboard/ai');
      cy.contains('RETROBOT', { timeout: 10000 }).should('exist');
    });

    it('Settings page renders tabs', () => {
      cy.visit('/dashboard/settings');
      cy.contains('SETTINGS', { timeout: 10000 }).should('exist');
    });

    it('Ctrl+K opens command bar', () => {
      cy.visit('/dashboard');
      cy.get('body').type('{ctrl}k');
      cy.get('input[placeholder*="Search"]', { timeout: 5000 }).should('be.visible');
      cy.get('body').type('{esc}');
      cy.get('input[placeholder*="Search"]').should('not.exist');
    });
  });
});
