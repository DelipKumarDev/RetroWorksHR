describe('Authentication', () => {
  beforeEach(() => {
    cy.visit('/login');
  });

  it('shows login form with vintage terminal UI', () => {
    cy.get('h1, [data-cy="login-title"]').should('be.visible');
    cy.get('input[name="email"], input[type="email"]').should('be.visible');
    cy.get('input[name="password"], input[type="password"]').should('be.visible');
  });

  it('shows error for invalid credentials', () => {
    cy.get('input[name="email"], input[type="email"]').type('wrong@email.com');
    cy.get('input[name="password"], input[type="password"]').type('wrongpassword');
    cy.get('button[type="submit"]').click();

    cy.contains(/invalid credentials|error/i, { timeout: 5000 }).should('be.visible');
  });

  it('logs in successfully with valid credentials', () => {
    cy.get('input[name="email"], input[type="email"]').type(Cypress.env('ADMIN_EMAIL') as string);
    cy.get('input[name="password"], input[type="password"]').type(Cypress.env('ADMIN_PASSWORD') as string);
    cy.get('button[type="submit"]').click();

    cy.url({ timeout: 10000 }).should('include', '/dashboard');
    cy.contains(/employee|dashboard|welcome/i, { timeout: 5000 }).should('be.visible');
  });

  it('sends magic link without revealing if email exists', () => {
    cy.contains(/magic link/i).click();
    cy.get('input[name="email"], input[type="email"]').type('nonexistent@email.com');
    cy.contains(/send|request|submit/i).click();

    // Should show success message regardless (no enumeration)
    cy.contains(/sent|check your email|magic/i, { timeout: 5000 }).should('be.visible');
  });

  it('redirects already-authenticated users away from login', () => {
    cy.login();
    cy.visit('/login');
    cy.url({ timeout: 5000 }).should('include', '/dashboard');
  });
});

describe('Logout', () => {
  beforeEach(() => {
    cy.login();
    cy.visit('/dashboard');
  });

  it('logs out and redirects to login', () => {
    // Find and click user menu / logout
    cy.get('[data-cy="user-menu"], [aria-label="User menu"]').click();
    cy.contains(/logout|sign out/i).click();

    cy.url({ timeout: 5000 }).should('include', '/login');
  });
});
