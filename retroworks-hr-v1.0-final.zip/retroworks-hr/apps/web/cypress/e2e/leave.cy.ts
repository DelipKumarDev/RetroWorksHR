describe('Leave Management', () => {
  beforeEach(() => {
    cy.login();
    cy.visit('/dashboard/leave');
  });

  it('shows leave balance cards', () => {
    cy.contains(/leave/i, { timeout: 5000 }).should('be.visible');
    // Should show balance cards (CL, SL, PL at minimum)
    cy.contains(/casual|sick|privilege/i, { timeout: 5000 }).should('be.visible');
  });

  it('shows apply leave button', () => {
    cy.contains(/apply leave/i).should('be.visible');
  });

  it('opens leave application modal on click', () => {
    cy.contains(/apply leave/i).click();
    cy.contains(/leave type/i, { timeout: 2000 }).should('be.visible');
  });

  it('validates leave form dates', () => {
    cy.contains(/apply leave/i).click();

    // Set end date before start date
    const today = new Date().toISOString().slice(0, 10);
    const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);

    cy.get('input[name="startDate"], input[type="date"]').first().type(today);
    cy.get('input[name="endDate"], input[type="date"]').last().type(yesterday);

    cy.contains(/submit|apply/i).click();
    cy.contains(/end date|invalid|error/i, { timeout: 3000 }).should('be.visible');
  });

  it('shows team tab for managers', () => {
    cy.contains(/team approvals/i).should('be.visible');
  });

  it('shows calendar tab with month navigation', () => {
    cy.contains(/calendar/i).click();
    cy.contains(/jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec/i, { timeout: 3000 }).should('be.visible');
  });
});

describe('Leave API', () => {
  beforeEach(() => {
    cy.login();
  });

  it('GET /leave/types returns leave types', () => {
    cy.apiRequest('GET', '/leave/types').then(res => {
      expect(res.status).to.eq(200);
      expect(res.body.data).to.be.an('array').with.length.greaterThan(0);
    });
  });

  it('GET /leave/balances/me returns my balances', () => {
    cy.apiRequest('GET', '/leave/balances/me').then(res => {
      expect(res.status).to.eq(200);
      expect(res.body.data).to.be.an('array');
    });
  });

  it('POST /leave/requests rejects overlapping dates', () => {
    // First get a leave type
    cy.apiRequest('GET', '/leave/types').then(typesRes => {
      const types = typesRes.body.data as Array<{ id: string }>;
      if (!types.length) return;

      const leaveTypeId = types[0]!.id;

      // Apply first leave
      const startDate = '2025-03-10';
      const endDate = '2025-03-12';

      cy.apiRequest('POST', '/leave/requests', {
        leaveTypeId, startDate, endDate,
      }).then(_firstRes => {
        // Try to apply overlapping leave
        cy.apiRequest('POST', '/leave/requests', {
          leaveTypeId,
          startDate: '2025-03-11', // Overlaps
          endDate: '2025-03-13',
        }).then(overlapRes => {
          expect(overlapRes.status).to.eq(409);
        });
      });
    });
  });
});
