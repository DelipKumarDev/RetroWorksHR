/**
 * Phase 5b E2E Tests — Report Builder, Plugins, Backup, Audit
 * Run: pnpm --filter @retroworks/web cypress run --spec phase5b.cy.ts
 */

describe('Phase 5b — Report Builder, Plugins, Backup, Audit', () => {
  const base = Cypress.env('API_URL') ?? 'http://localhost:3001/api/v1';
  let token: string;

  before(() => {
    cy.request({ method: 'POST', url: `${base}/auth/login`, body: { email: 'hr@demo.retroworks.hr', password: 'RetroWorks@123' } }).then(r => { token = r.body.data.accessToken; });
  });

  const req = (method: string, path: string, body?: any) => cy.request({ method, url: `${base}${path}`, headers: { Authorization: `Bearer ${token}` }, body, failOnStatusCode: false });

  // ── Report Builder ──────────────────────────────────────────────

  describe('Report Builder API', () => {
    it('GET /report-builder/catalogue/fields — returns field catalogue for all modules', () => {
      req('GET', '/report-builder/catalogue/fields').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('employees');
        expect(r.body.data).to.have.property('leave');
        expect(r.body.data).to.have.property('payroll');
        expect(r.body.data).to.have.property('attendance');
        expect(r.body.data).to.have.property('performance');
        expect(r.body.data.employees).to.be.an('array').with.length.greaterThan(0);
        const firstField = r.body.data.employees[0];
        expect(firstField).to.have.property('key');
        expect(firstField).to.have.property('label');
        expect(firstField).to.have.property('type');
      });
    });

    it('GET /report-builder/catalogue/prebuilt — returns 10+ prebuilt India reports', () => {
      req('GET', '/report-builder/catalogue/prebuilt').then(r => {
        expect(r.status).to.eq(200);
        const reports = r.body.data;
        expect(reports).to.be.an('array').with.length.greaterThan(9);
        const ids = reports.map((p: any) => p.id);
        expect(ids).to.include('headcount');
        expect(ids).to.include('pf_summary');
        expect(ids).to.include('tds_summary');
        expect(ids).to.include('payroll_variance');
      });
    });

    it('POST /report-builder/run — executes employee query and returns rows', () => {
      req('POST', '/report-builder/run', {
        module: 'employees',
        fields: ['employeeCode', 'firstName', 'lastName', 'designation.name', 'department.name', 'status'],
        filters: [{ field: 'status', operator: 'eq', value: 'active' }],
        limit: 10,
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('rows');
        expect(r.body.data).to.have.property('total');
        expect(r.body.data.rows).to.be.an('array');
      });
    });

    it('POST /report-builder/run — executes payroll query', () => {
      const now = new Date();
      req('POST', '/report-builder/run', {
        module: 'payroll',
        fields: ['employee.firstName', 'employee.lastName', 'month', 'year', 'grossPay', 'netPay', 'tdsDeducted'],
        filters: [{ field: 'year', operator: 'eq', value: now.getFullYear().toString() }],
        limit: 5,
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('rows');
      });
    });

    it('GET /report-builder/prebuilt/headcount — runs headcount prebuilt report', () => {
      req('GET', '/report-builder/prebuilt/headcount').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('rows');
        expect(r.body.data).to.have.property('summary');
      });
    });

    it('GET /report-builder/prebuilt/pf_summary — runs PF summary report', () => {
      const now = new Date();
      req('GET', `/report-builder/prebuilt/pf_summary?month=${now.getMonth() + 1}&year=${now.getFullYear()}`).then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('rows');
        expect(r.body.data).to.have.property('summary');
      });
    });

    it('POST /report-builder/reports — saves a custom report configuration', () => {
      req('POST', '/report-builder/reports', {
        name: 'Cypress Test Report', module: 'employees',
        fields: ['employeeCode', 'firstName', 'lastName', 'department.name'],
        filters: [], chartType: 'table', isShared: false,
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
        expect(r.body.data.name).to.eq('Cypress Test Report');
        cy.wrap(r.body.data.id).as('savedReportId');
        req('DELETE', `/report-builder/reports/${r.body.data.id}`);
      });
    });

    it('GET /report-builder/reports — lists saved reports', () => {
      req('GET', '/report-builder/reports').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });
  });

  // ── Plugins API ─────────────────────────────────────────────────

  describe('Plugins API', () => {
    it('GET /plugins — returns full plugin catalogue with enabled status', () => {
      req('GET', '/plugins').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array').with.length.greaterThan(5);
        const first = r.body.data[0];
        expect(first).to.have.property('id');
        expect(first).to.have.property('name');
        expect(first).to.have.property('category');
        expect(first).to.have.property('enabled');
        expect(first).to.have.property('configSchema');
      });
    });

    it('POST /plugins/:id/enable — enables a plugin', () => {
      req('POST', '/plugins/benefits_nps/enable', { config: {} }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data.pluginId).to.eq('benefits_nps');
        expect(r.body.data.enabled).to.be.true;
        // Clean up
        req('DELETE', '/plugins/benefits_nps/disable');
      });
    });

    it('GET /plugins/api-keys — returns API key list', () => {
      req('GET', '/plugins/api-keys').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });

    it('POST /plugins/api-keys — creates API key (shows secret once)', () => {
      req('POST', '/plugins/api-keys', { name: 'Cypress Test Key', scopes: ['read'], expiresInDays: 1 }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('key');
        expect(r.body.data.key).to.match(/^rw_/);
        expect(r.body.data).to.have.property('warning');
        // Revoke
        if (r.body.data.id) req('DELETE', `/plugins/api-keys/${r.body.data.id}`);
      });
    });

    it('GET /plugins/webhooks — returns webhook list', () => {
      req('GET', '/plugins/webhooks').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });

    it('POST /plugins/webhooks — registers a webhook endpoint', () => {
      req('POST', '/plugins/webhooks', { url: 'https://example.com/webhook', events: ['employee.created', 'leave.approved'], name: 'Cypress Test Webhook' }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
        expect(r.body.data).to.have.property('secret');
        // Clean up
        req('DELETE', `/plugins/webhooks/${r.body.data.id}`);
      });
    });
  });

  // ── Backup API ──────────────────────────────────────────────────

  describe('Backup API', () => {
    it('GET /backup/summary — returns backup health summary', () => {
      req('GET', '/backup/summary').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('total');
        expect(r.body.data).to.have.property('successful');
        expect(r.body.data).to.have.property('failed');
        expect(r.body.data).to.have.property('nextScheduled');
      });
    });

    it('GET /backup — lists backup records', () => {
      req('GET', '/backup').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });

    it('POST /backup/trigger — triggers manual backup (async)', () => {
      req('POST', '/backup/trigger').then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
        expect(r.body.data).to.have.property('status');
        expect(['running', 'queued']).to.include(r.body.data.status);
      });
    });

    it('GET /backup/restore/requests — lists restore requests', () => {
      req('GET', '/backup/restore/requests').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });
  });

  // ── Audit Log API ───────────────────────────────────────────────

  describe('Audit Log API', () => {
    it('GET /settings/audit-log — returns paginated audit entries', () => {
      req('GET', '/settings/audit-log?limit=10').then(r => {
        expect(r.status).to.eq(200);
        // Accepts either array or { entries, total }
        const data = r.body.data;
        const entries = Array.isArray(data) ? data : data?.entries ?? [];
        expect(entries).to.be.an('array');
      });
    });

    it('GET /settings/audit-log?resource=employee — filters by resource', () => {
      req('GET', '/settings/audit-log?resource=employee&limit=5').then(r => {
        expect(r.status).to.eq(200);
        const data = r.body.data;
        const entries = Array.isArray(data) ? data : data?.entries ?? [];
        entries.forEach((e: any) => expect(e.resource).to.eq('employee'));
      });
    });
  });

  // ── Insights API (continued) ────────────────────────────────────

  describe('Insights — Payroll Anomalies', () => {
    it('GET /insights/payroll-anomalies — returns anomaly detection results', () => {
      const now = new Date();
      req('GET', `/insights/payroll-anomalies?month=${now.getMonth() + 1}&year=${now.getFullYear()}`).then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('anomalies');
        expect(r.body.data).to.have.property('totalPayslips');
        expect(r.body.data).to.have.property('anomalyCount');
        expect(r.body.data.anomalies).to.be.an('array');
      });
    });
  });

  // ── Frontend Smoke Tests ────────────────────────────────────────

  describe('Frontend Pages (Phase 5b)', () => {
    it('Report Builder page renders', () => {
      cy.visit('/dashboard/report-builder');
      cy.contains('REPORT BUILDER', { timeout: 10000 }).should('exist');
    });

    it('Plugins page renders', () => {
      cy.visit('/dashboard/plugins');
      cy.contains('PLUGINS', { timeout: 10000 }).should('exist');
    });

    it('Backup page renders', () => {
      cy.visit('/dashboard/backup');
      cy.contains('BACKUP', { timeout: 10000 }).should('exist');
    });

    it('Audit page renders', () => {
      cy.visit('/dashboard/audit');
      cy.contains('AUDIT', { timeout: 10000 }).should('exist');
    });

    it('Report builder prebuilt tab loads India reports', () => {
      cy.visit('/dashboard/report-builder');
      cy.contains('Prebuilt Reports', { timeout: 10000 }).click();
      cy.contains('PF Summary', { timeout: 5000 }).should('exist');
      cy.contains('TDS Summary').should('exist');
      cy.contains('Payroll Variance').should('exist');
    });

    it('Plugins page shows marketplace grid', () => {
      cy.visit('/dashboard/plugins');
      cy.contains('Plugin Marketplace', { timeout: 10000 }).click();
      cy.contains('Bank File Generator', { timeout: 5000 }).should('exist');
    });
  });
});
