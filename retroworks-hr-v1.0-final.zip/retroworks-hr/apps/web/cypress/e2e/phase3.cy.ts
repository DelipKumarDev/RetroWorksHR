describe('Payroll API', () => {
  beforeEach(() => {
    cy.login();
  });

  it('GET /payroll/payslips/me returns my payslips', () => {
    cy.apiRequest('GET', '/payroll/payslips/me').then(res => {
      expect(res.status).to.eq(200);
      expect(res.body.data).to.be.an('array');
    });
  });

  it('GET /payroll/runs returns payroll run history for HR', () => {
    cy.apiRequest('GET', '/payroll/runs').then(res => {
      expect(res.status).to.be.oneOf([200, 403]); // 403 if not HR
    });
  });

  it('POST /payroll/runs validates month range', () => {
    cy.apiRequest('POST', '/payroll/runs', { month: 13, year: 2024 }).then(res => {
      expect(res.status).to.eq(400);
    });
  });

  it('GET /payroll/tax-statement/me returns annual tax data', () => {
    cy.apiRequest('GET', `/payroll/tax-statement/me?fy=${new Date().getFullYear() - 1}-${new Date().getFullYear()}`).then(res => {
      expect(res.status).to.eq(200);
      expect(res.body.data).to.have.property('financialYear');
    });
  });
});

describe('Reports API', () => {
  beforeEach(() => {
    cy.login();
  });

  it('GET /reports/headcount returns summary', () => {
    cy.apiRequest('GET', '/reports/headcount').then(res => {
      if (res.status === 200) {
        expect(res.body.data).to.have.property('summary');
        expect(res.body.data.summary).to.have.property('totalActive');
        expect(res.body.data).to.have.property('byDepartment');
        expect(res.body.data).to.have.property('byGender');
      }
    });
  });

  it('GET /reports/attrition-trend returns monthly data', () => {
    cy.apiRequest('GET', '/reports/attrition-trend?months=6').then(res => {
      if (res.status === 200) {
        expect(res.body.data).to.be.an('array');
        expect(res.body.data).to.have.length(6);
        res.body.data.forEach((month: any) => {
          expect(month).to.have.property('month');
          expect(month).to.have.property('joiners');
          expect(month).to.have.property('leavers');
        });
      }
    });
  });

  it('GET /reports/payroll returns payroll breakdown', () => {
    const now = new Date();
    cy.apiRequest('GET', `/reports/payroll?month=${now.getMonth() + 1}&year=${now.getFullYear()}`).then(res => {
      if (res.status === 200) {
        expect(res.body.data).to.have.property('totals');
        expect(res.body.data.totals).to.have.property('grossPay');
        expect(res.body.data.totals).to.have.property('tdsDeducted');
      }
    });
  });
});

describe('Helpdesk', () => {
  beforeEach(() => {
    cy.login();
  });

  it('can create and retrieve a helpdesk ticket', () => {
    cy.apiRequest('POST', '/helpdesk/tickets', {
      title: 'Test ticket from Cypress',
      description: 'This is an automated test ticket. Please ignore.',
      category: 'it',
      priority: 'p3',
    }).then(res => {
      expect(res.status).to.eq(201);
      const ticketId = res.body.data?.id;
      expect(ticketId).to.be.a('string');

      // Fetch the ticket
      cy.apiRequest('GET', `/helpdesk/tickets/${ticketId}`).then(detail => {
        expect(detail.status).to.eq(200);
        expect(detail.body.data.title).to.eq('Test ticket from Cypress');
      });
    });
  });

  it('SLA due is set based on priority', () => {
    cy.apiRequest('POST', '/helpdesk/tickets', {
      title: 'P1 critical issue',
      description: 'Critical production issue test',
      priority: 'p1',
    }).then(res => {
      if (res.status === 201) {
        const slaDue = new Date(res.body.data?.slaDue);
        const now = new Date();
        const hoursDiff = (slaDue.getTime() - now.getTime()) / 3_600_000;
        // P1 SLA = 4 hours
        expect(hoursDiff).to.be.closeTo(4, 0.5);
      }
    });
  });

  it('can add a comment to a ticket', () => {
    cy.apiRequest('POST', '/helpdesk/tickets', {
      title: 'Ticket for comment test',
      description: 'Testing comment functionality',
    }).then(res => {
      if (res.status === 201) {
        const ticketId = res.body.data?.id;
        cy.apiRequest('POST', `/helpdesk/tickets/${ticketId}/comments`, {
          message: 'This is a test comment',
        }).then(commentRes => {
          expect(commentRes.status).to.eq(201);
          expect(commentRes.body.data.message).to.eq('This is a test comment');
        });
      }
    });
  });
});

describe('Performance Module', () => {
  beforeEach(() => {
    cy.login();
  });

  it('GET /performance/cycles returns review cycles', () => {
    cy.apiRequest('GET', '/performance/cycles').then(res => {
      expect(res.status).to.eq(200);
      expect(res.body.data).to.be.an('array');
    });
  });

  it('GET /performance/reviews/me returns my reviews', () => {
    cy.apiRequest('GET', '/performance/reviews/me').then(res => {
      expect(res.status).to.eq(200);
      expect(res.body.data).to.be.an('array');
    });
  });

  it('GET /performance/goals/me returns my goals', () => {
    cy.apiRequest('GET', '/performance/goals/me').then(res => {
      expect(res.status).to.eq(200);
      expect(res.body.data).to.be.an('array');
    });
  });

  it('can create a goal', () => {
    cy.apiRequest('POST', '/performance/goals', {
      title: 'Improve code review turnaround',
      description: 'Reduce average code review time to under 24 hours',
      metric: 'hours',
      targetValue: 24,
      weightage: 20,
    }).then(res => {
      expect(res.status).to.eq(201);
      expect(res.body.data.title).to.include('code review');
    });
  });
});
