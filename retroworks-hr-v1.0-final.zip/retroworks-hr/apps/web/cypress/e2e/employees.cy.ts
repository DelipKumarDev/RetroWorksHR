describe('Employee Management', () => {
  beforeEach(() => {
    cy.login();
    cy.visit('/dashboard/employees');
  });

  it('shows employee list with search', () => {
    cy.contains(/employee/i, { timeout: 5000 }).should('be.visible');
    cy.get('input[type="search"], input[placeholder*="search" i]').should('be.visible');
  });

  it('can search employees by name', () => {
    cy.get('input[type="search"], input[placeholder*="search" i]').type('Arjun');

    // Results should filter
    cy.contains('Arjun', { timeout: 3000 }).should('be.visible');
  });

  it('can filter by status', () => {
    cy.get('select').first().select('active');
    // Should show only active employees
    cy.get('table tbody tr').should('have.length.greaterThan', 0);
  });

  it('navigates to employee detail on row click', () => {
    cy.get('table tbody tr').first().click();
    cy.url({ timeout: 5000 }).should('include', '/dashboard/employees/');
  });

  it('can create a new employee', () => {
    cy.contains(/add employee|new employee/i).click();

    // Fill in the form
    cy.get('input[name="employeeCode"]').type('TEST001');
    cy.get('input[name="firstName"]').type('Test');
    cy.get('input[name="lastName"]').type('Employee');
    cy.get('input[name="workEmail"]').type('test.employee@acme.com');
    cy.get('input[name="dateOfJoining"]').type('2024-01-15');

    cy.get('button[type="submit"]').click();

    cy.contains(/created|success/i, { timeout: 5000 }).should('be.visible');
  });
});

describe('Employee API', () => {
  beforeEach(() => {
    cy.login();
  });

  it('GET /employees returns paginated list', () => {
    cy.apiRequest('GET', '/employees').then(res => {
      expect(res.status).to.eq(200);
      expect(res.body.data).to.have.property('data');
      expect(res.body.data.data).to.be.an('array');
      expect(res.body.data).to.have.property('hasMore');
    });
  });

  it('GET /employees with search filter works', () => {
    cy.apiRequest('GET', '/employees?search=Arjun').then(res => {
      expect(res.status).to.eq(200);
      const employees = res.body.data.data as Array<{ firstName: string }>;
      employees.forEach(e => {
        expect(e.firstName.toLowerCase()).to.include('arjun');
      });
    });
  });

  it('POST /employees validates required fields', () => {
    cy.apiRequest('POST', '/employees', {
      // Missing required fields
      firstName: 'Test',
    }).then(res => {
      expect(res.status).to.eq(400);
    });
  });

  it('GET /employees/:id returns employee detail', () => {
    // First get the list to find an ID
    cy.apiRequest('GET', '/employees?limit=1').then(listRes => {
      const employees = listRes.body.data.data as Array<{ id: string }>;
      if (employees.length > 0) {
        const id = employees[0]!.id;
        cy.apiRequest('GET', `/employees/${id}`).then(detailRes => {
          expect(detailRes.status).to.eq(200);
          expect(detailRes.body.data.id).to.eq(id);
        });
      }
    });
  });
});
