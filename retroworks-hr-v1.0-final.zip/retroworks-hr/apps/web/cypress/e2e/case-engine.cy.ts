/**
 * Case Engine E2E Tests — Ticket, SLA, KB, CRM, Analytics, Cross-Domain, Email
 * Run: pnpm --filter @retroworks/web cypress run --spec case-engine.cy.ts
 */

describe('Case Engine — Full Test Suite', () => {
  const base = Cypress.env('API_URL') ?? 'http://localhost:3001/api/v1';
  let token: string;
  let createdTicketId: string;
  let createdAccountId: string;
  let createdKBId: string;

  before(() => {
    cy.request({ method: 'POST', url: `${base}/auth/login`, body: { email: 'hr@demo.retroworks.hr', password: 'RetroWorks@123' } }).then(r => { token = r.body.data.accessToken; });
  });

  const req = (method: string, path: string, body?: any) =>
    cy.request({ method, url: `${base}${path}`, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body, failOnStatusCode: false });

  // ── Ticket CRUD ──────────────────────────────────────────────────────

  describe('Ticket Core', () => {
    it('POST /case-engine/tickets — creates a ticket with auto-generated number', () => {
      req('POST', '/case-engine/tickets', {
        type: 'internal', title: 'Payroll discrepancy for March 2025',
        description: 'My net pay is ₹4,000 less than expected.', priority: 'p2',
        linkedEntityType: 'employee', source: 'web',
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
        expect(r.body.data).to.have.property('ticketNumber');
        expect(r.body.data.ticketNumber).to.match(/^RW-\d{4}-\d{5}$/);
        expect(r.body.data.status).to.eq('open');
        createdTicketId = r.body.data.id;
      });
    });

    it('GET /case-engine/tickets — returns paginated ticket list', () => {
      req('GET', '/case-engine/tickets?limit=10&offset=0').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('tickets');
        expect(r.body.data).to.have.property('total');
        expect(r.body.data.tickets).to.be.an('array');
      });
    });

    it('GET /case-engine/tickets/:id — returns ticket with full detail', () => {
      req('GET', `/case-engine/tickets/${createdTicketId}`).then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data.id).to.eq(createdTicketId);
        expect(r.body.data).to.have.property('messages');
        expect(r.body.data).to.have.property('activities');
      });
    });

    it('POST /case-engine/tickets/:id/messages — adds a reply message', () => {
      req('POST', `/case-engine/tickets/${createdTicketId}/messages`, {
        body: 'Hi, this is HR. Can you share your payslip for March?',
        isInternal: false,
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
        expect(r.body.data.ticketId).to.eq(createdTicketId);
      });
    });

    it('POST /case-engine/tickets/:id/messages — adds an internal note', () => {
      req('POST', `/case-engine/tickets/${createdTicketId}/messages`, {
        body: 'Internal: checking payroll run data. Do not share externally.',
        isInternal: true,
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data.isInternal).to.be.true;
      });
    });

    it('PATCH /case-engine/tickets/:id — updates ticket status to in-progress', () => {
      req('PATCH', `/case-engine/tickets/${createdTicketId}`, { status: 'in-progress', priority: 'p1' }).then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data.status).to.eq('in-progress');
      });
    });

    it('POST /case-engine/tickets/:id/resolve — resolves ticket', () => {
      req('POST', `/case-engine/tickets/${createdTicketId}/resolve`, { resolution: 'Payroll error corrected, supplementary payrun processed.' }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data.status).to.be.oneOf(['resolved', 'closed']);
      });
    });

    it('GET /case-engine/tickets — filters by type=internal', () => {
      req('GET', '/case-engine/tickets?type=internal&limit=5').then(r => {
        expect(r.status).to.eq(200);
        const tickets = r.body.data?.tickets ?? [];
        tickets.forEach((t: any) => expect(t.type).to.eq('internal'));
      });
    });
  });

  // ── SLA Engine ───────────────────────────────────────────────────────

  describe('SLA Engine', () => {
    it('POST /case-engine/sla — creates an SLA policy', () => {
      req('POST', '/case-engine/sla', {
        name: 'Finance P1 SLA',
        p1ResponseMinutes: 30, p1ResolutionMinutes: 120,
        p2ResponseMinutes: 120, p2ResolutionMinutes: 480,
        p3ResponseMinutes: 480, p3ResolutionMinutes: 1440,
        p4ResponseMinutes: 1440, p4ResolutionMinutes: 10080,
        isDefault: false, businessHoursOnly: true,
        workdayStart: '09:00', workdayEnd: '18:00', workdays: [1, 2, 3, 4, 5],
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
        expect(r.body.data.name).to.eq('Finance P1 SLA');
      });
    });

    it('GET /case-engine/sla — lists SLA policies', () => {
      req('GET', '/case-engine/sla').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });

    it('GET /case-engine/tickets?slaBreached=true — filters SLA-breached tickets', () => {
      req('GET', '/case-engine/tickets?slaBreached=true').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('tickets');
      });
    });
  });

  // ── Categories ───────────────────────────────────────────────────────

  describe('Ticket Categories', () => {
    it('POST /case-engine/categories — creates a category', () => {
      req('POST', '/case-engine/categories', {
        name: 'Payroll Query', type: 'payroll', defaultPriority: 'p2', color: '#f59e0b',
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
      });
    });

    it('GET /case-engine/categories — returns category tree', () => {
      req('GET', '/case-engine/categories').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });
  });

  // ── Assignment Rules ─────────────────────────────────────────────────

  describe('Assignment Rules', () => {
    it('GET /case-engine/assignment-rules/catalogue — returns field + action catalogue', () => {
      req('GET', '/case-engine/assignment-rules/catalogue').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('fields');
        expect(r.body.data).to.have.property('actions');
        expect(r.body.data.fields).to.be.an('array').with.length.greaterThan(0);
        expect(r.body.data.actions).to.be.an('array').with.length.greaterThan(0);
      });
    });

    it('POST /case-engine/assignment-rules — creates an assignment rule', () => {
      req('POST', '/case-engine/assignment-rules', {
        name: 'Auto-escalate P1 payroll tickets',
        priority: 10,
        conditions: [{ field: 'type', operator: 'eq', value: 'payroll' }, { field: 'priority', operator: 'eq', value: 'p1' }],
        conditionLogic: 'AND',
        actions: [{ type: 'set_priority', value: 'p1' }],
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
        expect(r.body.data.isActive).to.be.true;
      });
    });

    it('GET /case-engine/assignment-rules — lists rules ordered by priority', () => {
      req('GET', '/case-engine/assignment-rules').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });
  });

  // ── Knowledge Base ───────────────────────────────────────────────────

  describe('Knowledge Base', () => {
    it('POST /case-engine/kb/categories — creates a KB category', () => {
      req('POST', '/case-engine/kb/categories', {
        name: 'Payroll Policies', visibility: 'internal', icon: '₹',
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
      });
    });

    it('POST /case-engine/kb/articles — creates a KB article', () => {
      req('POST', '/case-engine/kb/articles', {
        title: 'How to dispute a payroll error',
        content: '# How to Dispute a Payroll Error\n\n1. Navigate to My Payslips\n2. Click the disputed month\n3. Click "Raise Dispute"\n4. Fill in the discrepancy details\n\nHR will review within 2 business days.',
        visibility: 'internal', status: 'published',
        tags: ['payroll', 'dispute', 'salary'],
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
        expect(r.body.data.status).to.eq('published');
        createdKBId = r.body.data.id;
      });
    });

    it('GET /case-engine/kb/articles — lists articles with pagination', () => {
      req('GET', '/case-engine/kb/articles?limit=10').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array').or.have.property('articles');
      });
    });

    it('PUT /case-engine/kb/articles/:id — updates article and bumps version', () => {
      req('PUT', `/case-engine/kb/articles/${createdKBId}`, {
        title: 'How to dispute a payroll error (Updated)',
        content: 'Updated content with more detail.',
        visibility: 'internal', status: 'published',
      }).then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data.version).to.be.greaterThan(1);
      });
    });

    it('GET /case-engine/kb/search?q=payroll — searches articles', () => {
      req('GET', '/case-engine/kb/search?q=payroll').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });
  });

  // ── CRM Lite ─────────────────────────────────────────────────────────

  describe('CRM Lite', () => {
    it('POST /case-engine/crm/accounts — creates an account', () => {
      req('POST', '/case-engine/crm/accounts', {
        name: 'Cypress Tech Pvt Ltd', industry: 'Technology',
        tier: 'smb', email: 'hr@cypresstech.com',
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data).to.have.property('id');
        createdAccountId = r.body.data.id;
      });
    });

    it('GET /case-engine/crm/accounts — lists accounts', () => {
      req('GET', '/case-engine/crm/accounts').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
        expect(r.body.data.some((a: any) => a.name === 'Cypress Tech Pvt Ltd')).to.be.true;
      });
    });

    it('POST /case-engine/crm/contacts — creates a contact linked to account', () => {
      req('POST', '/case-engine/crm/contacts', {
        accountId: createdAccountId, firstName: 'Arjun', lastName: 'Nair',
        email: 'arjun@cypresstech.com', designation: 'HR Manager',
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data.accountId).to.eq(createdAccountId);
      });
    });

    it('POST /case-engine/crm/opportunities — creates an opportunity', () => {
      req('POST', '/case-engine/crm/opportunities', {
        accountId: createdAccountId, title: 'Enterprise HRMS Contract',
        stage: 'proposal', value: 500000, currency: 'INR', probability: 50,
      }).then(r => {
        expect([200, 201]).to.include(r.status);
        expect(r.body.data.stage).to.eq('proposal');
      });
    });

    // Clean up
    after(() => { if (createdAccountId) req('DELETE', `/case-engine/crm/accounts/${createdAccountId}`); });
  });

  // ── Analytics ────────────────────────────────────────────────────────

  describe('Case Engine Analytics', () => {
    it('GET /case-engine/analytics/dashboard — returns dashboard KPIs', () => {
      req('GET', '/case-engine/analytics/dashboard').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('summary');
        expect(r.body.data.summary).to.have.property('open');
        expect(r.body.data.summary).to.have.property('slaBreached');
        expect(r.body.data).to.have.property('byType');
        expect(r.body.data).to.have.property('byPriority');
      });
    });

    it('GET /case-engine/analytics/volume-trend — returns 12-month trend', () => {
      req('GET', '/case-engine/analytics/volume-trend').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array').with.length(12);
        expect(r.body.data[0]).to.have.property('created');
        expect(r.body.data[0]).to.have.property('resolved');
        expect(r.body.data[0]).to.have.property('breached');
      });
    });

    it('GET /case-engine/analytics/sla-report — returns SLA breach report', () => {
      req('GET', '/case-engine/analytics/sla-report').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('breachRate');
        expect(r.body.data).to.have.property('byCategory');
      });
    });

    it('GET /case-engine/analytics/agent-performance — returns agent leaderboard', () => {
      req('GET', '/case-engine/analytics/agent-performance').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array');
      });
    });

    it('GET /case-engine/analytics/headcount-correlation — returns cross-domain ticket/headcount data', () => {
      req('GET', '/case-engine/analytics/headcount-correlation').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array').with.length(6);
        expect(r.body.data[0]).to.have.property('ticketCount');
        expect(r.body.data[0]).to.have.property('headcount');
        expect(r.body.data[0]).to.have.property('ticketsPerEmployee');
      });
    });

    it('GET /case-engine/analytics/leave-query-trend — returns leave/payroll/IT query breakdown', () => {
      req('GET', '/case-engine/analytics/leave-query-trend').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.be.an('array').with.length(6);
        expect(r.body.data[0]).to.have.property('leaveTickets');
        expect(r.body.data[0]).to.have.property('payrollTickets');
        expect(r.body.data[0]).to.have.property('itTickets');
      });
    });
  });

  // ── Email Ingest ─────────────────────────────────────────────────────

  describe('Email Ingest', () => {
    it('GET /case-engine/email/stats — returns email ingest statistics', () => {
      req('GET', '/case-engine/email/stats').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('total');
        expect(r.body.data).to.have.property('parsed');
        expect(r.body.data).to.have.property('successRate');
      });
    });

    it('GET /case-engine/email/log — returns inbound email log', () => {
      req('GET', '/case-engine/email/log?limit=10').then(r => {
        expect(r.status).to.eq(200);
        expect(r.body.data).to.have.property('items');
        expect(r.body.data).to.have.property('total');
      });
    });
  });

  // ── Frontend Smoke Tests ──────────────────────────────────────────────

  describe('Frontend — Case Engine Pages', () => {
    it('Ticket list page loads', () => {
      cy.visit('/dashboard/case-engine/tickets');
      cy.contains('TICKET', { timeout: 10000 }).should('exist');
    });

    it('Kanban board loads', () => {
      cy.visit('/dashboard/case-engine/kanban');
      cy.contains('KANBAN', { timeout: 10000 }).should('exist');
    });

    it('Analytics page loads with dashboard', () => {
      cy.visit('/dashboard/case-engine/analytics');
      cy.contains('ANALYTICS', { timeout: 10000 }).should('exist');
    });

    it('Knowledge Base page loads', () => {
      cy.visit('/dashboard/case-engine/kb');
      cy.contains('KNOWLEDGE', { timeout: 10000 }).should('exist');
    });

    it('CRM page loads', () => {
      cy.visit('/dashboard/case-engine/crm');
      cy.contains('CRM', { timeout: 10000 }).should('exist');
    });

    it('Assignment Rules page loads', () => {
      cy.visit('/dashboard/case-engine/assignment-rules');
      cy.contains('ASSIGNMENT', { timeout: 10000 }).should('exist');
    });

    it('Ticket list allows filtering by status', () => {
      cy.visit('/dashboard/case-engine/tickets');
      cy.get('select').first().select('open', { timeout: 5000 });
      cy.wait(500);
    });

    it('KB article creation and save', () => {
      cy.visit('/dashboard/case-engine/kb');
      cy.contains('New', { timeout: 8000 }).first().click();
      cy.get('input').first().type('Test article from Cypress');
      cy.get('textarea').first().type('# Test\n\nThis is test content for E2E.');
      cy.contains('Save Draft', { timeout: 5000 }).click();
    });
  });
});
