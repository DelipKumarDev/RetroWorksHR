// Custom Cypress commands for RetroWorks HR

Cypress.Commands.add('login', (email?: string, password?: string) => {
  const e = email ?? Cypress.env('ADMIN_EMAIL') as string;
  const p = password ?? Cypress.env('ADMIN_PASSWORD') as string;

  cy.request({
    method: 'POST',
    url: `${Cypress.env('API_URL') as string}/auth/login`,
    body: { email: e, password: p },
  }).then(res => {
    const { accessToken, user } = res.body.data as { accessToken: string; user: { id: string } };
    localStorage.setItem('token', accessToken);
    localStorage.setItem('user', JSON.stringify(user));
  });
});

Cypress.Commands.add('apiRequest', (method, path, body?) => {
  const token = localStorage.getItem('token') ?? '';
  return cy.request({
    method,
    url: `${Cypress.env('API_URL') as string}${path}`,
    body,
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    failOnStatusCode: false,
  });
});

// Type augmentation
declare global {
  namespace Cypress {
    interface Chainable {
      login(email?: string, password?: string): Chainable<void>;
      apiRequest(method: string, path: string, body?: unknown): Chainable<Cypress.Response<unknown>>;
    }
  }
}
