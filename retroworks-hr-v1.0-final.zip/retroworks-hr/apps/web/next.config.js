/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,

  // Transpile workspace packages
  transpilePackages: ['@retroworks/ui', '@retroworks/types', '@retroworks/config'],

  // Image optimization
  images: {
    domains: [
      'localhost',
      process.env['NEXT_PUBLIC_CLOUDFRONT_DOMAIN'] ?? '',
      's3.ap-south-1.amazonaws.com',
    ].filter(Boolean),
    formats: ['image/avif', 'image/webp'],
  },

  // Headers
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(self)' },
        ],
      },
    ];
  },

  // Redirects
  async redirects() {
    return [
      { source: '/', destination: '/dashboard', permanent: false },
    ];
  },

  webpack: (config) => {
    // Optimize bundle for t2.micro deployment
    config.optimization = {
      ...config.optimization,
      moduleIds: 'deterministic',
    };
    return config;
  },
};

module.exports = nextConfig;
