// ─────────────────────────────────────────────
// BASE ENTITIES
// ─────────────────────────────────────────────

export interface BaseEntity {
  id: string;
  tenantId: string;
  createdAt: Date;
  updatedAt: Date;
  createdBy: string;
  updatedBy: string;
  deletedAt?: Date | null;
  deletedBy?: string | null;
}

export interface AuditMeta {
  ip?: string;
  userAgent?: string;
  sessionId?: string;
  reason?: string;
}

// ─────────────────────────────────────────────
// PAGINATION
// ─────────────────────────────────────────────

export interface CursorPaginationInput {
  cursor?: string;
  limit?: number;
  direction?: 'forward' | 'backward';
}

export interface CursorPaginationResult<T> {
  data: T[];
  nextCursor?: string;
  prevCursor?: string;
  hasMore: boolean;
  total?: number;
}

export interface FilterInput {
  field: string;
  operator: 'eq' | 'neq' | 'gt' | 'gte' | 'lt' | 'lte' | 'in' | 'like' | 'between';
  value: unknown;
}

export interface SortInput {
  field: string;
  direction: 'asc' | 'desc';
}

export interface QueryInput {
  filters?: FilterInput[];
  sorts?: SortInput[];
  pagination?: CursorPaginationInput;
  fields?: string[];
}

// ─────────────────────────────────────────────
// API RESPONSES
// ─────────────────────────────────────────────

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: ApiError;
  meta?: ResponseMeta;
}

export interface ApiError {
  code: string;
  message: string;
  details?: Record<string, string[]>;
  traceId?: string;
}

export interface ResponseMeta {
  requestId: string;
  timestamp: string;
  version: string;
}

// ─────────────────────────────────────────────
// AUTH & IDENTITY
// ─────────────────────────────────────────────

export type AuthProvider = 'local' | 'google' | 'microsoft' | 'keycloak' | 'magic-link';
export type MfaMethod = 'totp' | 'sms' | 'email';

export interface JwtPayload {
  sub: string;        // userId
  tid: string;        // tenantId
  email: string;
  roles: string[];
  permissions?: string[];
  sessionId: string;
  iat: number;
  exp: number;
}

export interface AuthUser {
  id: string;
  tenantId: string;
  email: string;
  name: string;
  roles: string[];
  permissions: string[];
  employeeId?: string;
  avatarUrl?: string;
}

// ─────────────────────────────────────────────
// RBAC / ABAC
// ─────────────────────────────────────────────

export type ResourceType =
  | 'employee' | 'candidate' | 'leave' | 'attendance' | 'payroll'
  | 'performance' | 'helpdesk' | 'asset' | 'expense' | 'survey'
  | 'course' | 'announcement' | 'document' | 'report' | 'admin';

export type ActionType =
  | 'create' | 'read' | 'update' | 'delete' | 'approve'
  | 'reject' | 'export' | 'import' | 'configure';

export interface Permission {
  resource: ResourceType;
  action: ActionType;
  conditions?: PolicyCondition[];
}

export interface PolicyCondition {
  field: string;
  operator: string;
  value: unknown;
}

export interface Role {
  id: string;
  name: string;
  tenantId: string;
  permissions: Permission[];
  isSystem: boolean;
}

// ─────────────────────────────────────────────
// TENANT
// ─────────────────────────────────────────────

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  domain?: string;
  logoUrl?: string;
  region: 'IN' | 'US' | 'UK' | 'EU' | 'SG';
  currency: string;
  timezone: string;
  locale: string;
  enabledModules: HrModule[];
  subscriptionTier: 'free' | 'starter' | 'growth' | 'enterprise';
  settings: TenantSettings;
  createdAt: Date;
}

export type HrModule =
  | 'ats' | 'onboarding' | 'core-hr' | 'attendance' | 'leave'
  | 'payroll' | 'benefits' | 'performance' | 'lnd' | 'expenses'
  | 'assets' | 'helpdesk' | 'surveys' | 'integrations' | 'offboarding';

export interface TenantSettings {
  theme: ThemeConfig;
  payroll?: PayrollSettings;
  attendance?: AttendanceSettings;
  leave?: LeaveSettings;
  notifications?: NotificationSettings;
  security?: SecuritySettings;
}

export interface ThemeConfig {
  mode: 'dark' | 'light' | 'system';
  primaryColor?: string;
  accentColor?: string;
  enableCrtEffect: boolean;
  enableScanlines: boolean;
  reducedMotion?: boolean;
  pixelFont: boolean;
}

// ─────────────────────────────────────────────
// EMPLOYEE
// ─────────────────────────────────────────────

export type EmploymentType = 'full-time' | 'part-time' | 'contract' | 'intern' | 'consultant';
export type EmploymentStatus = 'active' | 'on-leave' | 'suspended' | 'terminated' | 'notice-period';
export type Gender = 'male' | 'female' | 'non-binary' | 'prefer-not-to-say';

export interface Employee extends BaseEntity {
  employeeCode: string;
  firstName: string;
  lastName: string;
  middleName?: string;
  preferredName?: string;
  email: string;
  workEmail: string;
  phone?: string;
  gender: Gender;
  dateOfBirth?: Date;
  dateOfJoining: Date;
  dateOfLeaving?: Date;
  employmentType: EmploymentType;
  status: EmploymentStatus;
  departmentId: string;
  designationId: string;
  locationId: string;
  managerId?: string;
  gradeId?: string;
  costCenterId?: string;
  probationEndDate?: Date;
  noticePeriodDays: number;
  avatarUrl?: string;
  // PII - encrypted at rest
  panNumber?: string;     // masked
  aadhaarNumber?: string; // masked
  uanNumber?: string;
  pfAccountNumber?: string;
}

// ─────────────────────────────────────────────
// WORKFLOW
// ─────────────────────────────────────────────

export type WorkflowStatus = 'draft' | 'active' | 'archived';
export type NodeType = 'start' | 'state' | 'decision' | 'parallel' | 'end';
export type TransitionTrigger = 'manual' | 'automatic' | 'scheduled' | 'webhook';

export interface WorkflowDefinition extends BaseEntity {
  name: string;
  description?: string;
  module: HrModule;
  entityType: string;
  version: number;
  status: WorkflowStatus;
  nodes: WorkflowNode[];
  transitions: WorkflowTransition[];
  slaConfig?: SlAConfig;
}

export interface WorkflowNode {
  id: string;
  type: NodeType;
  label: string;
  x: number;
  y: number;
  config: NodeConfig;
}

export interface NodeConfig {
  assigneeRoles?: string[];
  assigneeUsers?: string[];
  parallelBranches?: string[];
  autoActions?: AutoAction[];
  slaHours?: number;
  escalationConfig?: EscalationConfig;
}

export interface WorkflowTransition {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  label: string;
  trigger: TransitionTrigger;
  conditions?: PolicyCondition[];
  actions?: AutoAction[];
}

export interface AutoAction {
  type: 'notify' | 'webhook' | 'update-field' | 'create-task' | 'email';
  config: Record<string, unknown>;
}

export interface SlAConfig {
  warningHours: number;
  breachHours: number;
  escalateTo: string[];
}

export interface EscalationConfig {
  afterHours: number;
  escalateTo: string[];
  notifyChannels: ('email' | 'sms' | 'push')[];
}

// ─────────────────────────────────────────────
// FORM BUILDER
// ─────────────────────────────────────────────

export type FieldType =
  | 'text' | 'textarea' | 'number' | 'email' | 'phone'
  | 'date' | 'datetime' | 'select' | 'multi-select'
  | 'checkbox' | 'radio' | 'file' | 'currency'
  | 'computed' | 'richtext' | 'address' | 'signature';

export interface FormDefinition extends BaseEntity {
  name: string;
  entityType: string;
  version: number;
  sections: FormSection[];
  visibleForRoles?: string[];
  workflowStates?: string[];
}

export interface FormSection {
  id: string;
  label: string;
  order: number;
  collapsible: boolean;
  fields: FormField[];
  visibleWhen?: ConditionalRule[];
}

export interface FormField {
  id: string;
  name: string;
  label: string;
  type: FieldType;
  required: boolean;
  order: number;
  placeholder?: string;
  helpText?: string;
  defaultValue?: unknown;
  options?: FieldOption[];
  validation?: FieldValidation;
  conditional?: ConditionalRule[];
  maskedForRoles?: string[];
  readonlyForRoles?: string[];
  hiddenForRoles?: string[];
  computedFormula?: string;
}

export interface FieldOption {
  label: string;
  value: string;
  disabled?: boolean;
  metadata?: Record<string, unknown>;
}

export interface FieldValidation {
  min?: number;
  max?: number;
  minLength?: number;
  maxLength?: number;
  pattern?: string;
  patternMessage?: string;
  allowedFileTypes?: string[];
  maxFileSizeMb?: number;
}

export interface ConditionalRule {
  field: string;
  operator: 'eq' | 'neq' | 'in' | 'not-in' | 'gt' | 'lt' | 'empty' | 'not-empty';
  value?: unknown;
}

// ─────────────────────────────────────────────
// LEAVE
// ─────────────────────────────────────────────

export type LeaveStatus = 'pending' | 'approved' | 'rejected' | 'cancelled' | 'withdrawn';
export type LeaveUnit = 'days' | 'hours';

export interface LeaveType extends BaseEntity {
  name: string;
  code: string;
  unit: LeaveUnit;
  maxDaysPerYear: number;
  maxConsecutiveDays?: number;
  carryForwardDays?: number;
  encashable: boolean;
  requiresDocument: boolean;
  paidLeave: boolean;
  applicableGenders?: Gender[];
  noticeDaysRequired?: number;
}

export interface LeaveRequest extends BaseEntity {
  employeeId: string;
  leaveTypeId: string;
  startDate: Date;
  endDate: Date;
  totalDays: number;
  unit: LeaveUnit;
  reason: string;
  status: LeaveStatus;
  workflowInstanceId?: string;
  attachments?: string[];
  approverIds: string[];
}

// ─────────────────────────────────────────────
// PAYROLL (India)
// ─────────────────────────────────────────────

export type PayrollStatus = 'draft' | 'processing' | 'review' | 'approved' | 'paid' | 'reversed';

export interface PayrollGroup extends BaseEntity {
  name: string;
  payPeriod: 'monthly' | 'bimonthly' | 'weekly';
  payDay: number;
  currency: string;
  components: SalaryComponent[];
  statutoryConfig: IndiaStatutoryConfig;
}

export interface SalaryComponent {
  id: string;
  name: string;
  code: string;
  type: 'earning' | 'deduction' | 'benefit' | 'reimbursement';
  taxable: boolean;
  formula?: string;
  fixedAmount?: number;
  percentOf?: string;
  percentValue?: number;
  order: number;
}

export interface IndiaStatutoryConfig {
  pf: {
    enabled: boolean;
    employeeRate: number;   // default 12%
    employerRate: number;   // default 12%
    ceilingAmount: number;  // default 15000
    voluntaryPF: boolean;
  };
  esi: {
    enabled: boolean;
    employeeRate: number;   // default 0.75%
    employerRate: number;   // default 3.25%
    wageLimit: number;      // default 21000
  };
  pt: {
    enabled: boolean;
    state: string;
    slabs: PtSlab[];
  };
  tds: {
    enabled: boolean;
    regime: 'old' | 'new';
  };
  lwf: {
    enabled: boolean;
    state: string;
  };
  gratuity: {
    enabled: boolean;
    eligibilityYears: number; // default 5
  };
}

export interface PtSlab {
  from: number;
  to?: number;
  monthlyPt: number;
  exemptMonths?: number[];
}

// ─────────────────────────────────────────────
// NOTIFICATIONS
// ─────────────────────────────────────────────

export type NotificationChannel = 'email' | 'sms' | 'push' | 'in-app';

export interface NotificationTemplate extends BaseEntity {
  name: string;
  eventKey: string;
  channels: NotificationChannel[];
  subject?: string; // email only
  bodyHtml?: string;
  bodySms?: string;
  bodyPush?: string;
  tokens: string[]; // e.g. ['{{employee.name}}', '{{leave.days}}']
  quietHours?: QuietHoursConfig;
}

export interface QuietHoursConfig {
  enabled: boolean;
  startHour: number;
  endHour: number;
  timezone: string;
  excludeUrgent: boolean;
}

// ─────────────────────────────────────────────
// SETTINGS — Payroll, Attendance, Leave, Security, Notifications
// ─────────────────────────────────────────────

export interface PayrollSettings {
  pfEnabled: boolean;
  esiEnabled: boolean;
  ptEnabled: boolean;
  ptState?: string;
  tdsRegime: 'old' | 'new';
  lwfEnabled: boolean;
  gratuityEnabled: boolean;
}

export interface AttendanceSettings {
  mode: 'manual' | 'biometric' | 'geo' | 'wifi' | 'qr';
  gracePeriodMinutes: number;
  halfDayHours: number;
  fullDayHours: number;
  overTimeEnabled: boolean;
  compOffEnabled: boolean;
}

export interface LeaveSettings {
  approvalRequired: boolean;
  maxApprovers: number;
  allowBackdatedLeave: boolean;
  backdatedDays?: number;
  leaveCalendar: 'calendar' | 'working-days';
}

export interface NotificationSettings {
  emailEnabled: boolean;
  smsEnabled: boolean;
  pushEnabled: boolean;
  digestEnabled: boolean;
  digestFrequency: 'daily' | 'weekly';
}

export interface SecuritySettings {
  mfaRequired: boolean;
  sessionTimeoutMinutes: number;
  passwordPolicy: PasswordPolicy;
  allowedIpRanges?: string[];
  ssoEnabled: boolean;
  biometricEnabled: boolean; // OFF by default
}

export interface PasswordPolicy {
  minLength: number;
  requireUppercase: boolean;
  requireNumbers: boolean;
  requireSymbols: boolean;
  expiryDays?: number;
  historyCount?: number;
}

// ─────────────────────────────────────────────
// AI / RAG
// ─────────────────────────────────────────────

export interface RagDocument extends BaseEntity {
  title: string;
  sourceType: 'policy' | 'handbook' | 'faq' | 'sop' | 'template' | 'custom';
  content: string;
  metadata: Record<string, unknown>;
  chunkCount: number;
  vectorized: boolean;
  vectorizedAt?: Date;
  tags: string[];
  visibleForRoles: string[];
  confidential: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  citations?: Citation[];
  confidence?: number;
  escalated?: boolean;
  timestamp: Date;
}

export interface Citation {
  documentId: string;
  documentTitle: string;
  chunkId: string;
  relevanceScore: number;
  excerpt: string;
  pageRef?: string;
}

// ─────────────────────────────────────────────
// FEATURE FLAGS
// ─────────────────────────────────────────────

export interface FeatureFlag {
  key: string;
  enabled: boolean;
  tenantOverrides?: Record<string, boolean>;
  description: string;
  rolloutPercent?: number;
}

export const DEFAULT_FEATURE_FLAGS: Record<string, boolean> = {
  'biometric-attendance': false,
  'ai-copilot': true,
  'advanced-analytics': false,
  'mobile-app': true,
  'payroll-india': true,
  'sso-oidc': true,
  'mfa-totp': true,
  'data-export': true,
  'webhooks': true,
  'api-access': false,
} as const;
