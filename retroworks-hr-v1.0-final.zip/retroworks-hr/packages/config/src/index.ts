// ─────────────────────────────────────────────
// RETROWORKS HR — DESIGN TOKENS
// Vintage Gaming Theme
// ─────────────────────────────────────────────

export const DESIGN_TOKENS = {
  // Palette — CRT Phosphor Inspired
  colors: {
    // Primary — Phosphor Green
    primary: {
      50:  '#f0fdf0',
      100: '#dcfce7',
      200: '#bbf7d0',
      300: '#86efac',
      400: '#4ade80',
      500: '#22c55e',
      600: '#16a34a',
      700: '#15803d',
      800: '#166534',
      900: '#14532d',
      950: '#052e16',
      DEFAULT: '#22c55e',
      crt: '#00ff41',   // Classic CRT green
    },
    // Accent — Amber/CRT Orange
    accent: {
      DEFAULT: '#f59e0b',
      crt: '#ff9900',
      dim: '#92400e',
    },
    // Retro Blues
    retro: {
      cyan: '#00ffff',
      magenta: '#ff00ff',
      blue: '#0000ff',
      cobalt: '#004b97',
    },
    // Dark Backgrounds — Deep Space
    bg: {
      primary: '#080c08',     // near-black green tint
      secondary: '#0d160d',
      tertiary: '#111a11',
      card: '#0f1a0f',
      hover: '#162416',
      border: '#1a2e1a',
      borderHover: '#2a4a2a',
    },
    // Text
    text: {
      primary: '#e2ffe2',
      secondary: '#a0c0a0',
      muted: '#607060',
      disabled: '#3a4a3a',
      inverse: '#080c08',
    },
    // Status
    status: {
      success: '#22c55e',
      warning: '#f59e0b',
      error: '#ef4444',
      info: '#3b82f6',
      pending: '#a855f7',
    },
    // Pixel Art Avatars
    avatar: [
      '#22c55e', '#3b82f6', '#f59e0b', '#ef4444',
      '#a855f7', '#06b6d4', '#f97316', '#ec4899',
    ],
  },

  // Typography
  fonts: {
    pixel: '"Press Start 2P", monospace',    // headings, badges, stats
    mono:  '"JetBrains Mono", "Fira Code", monospace',  // code, IDs
    body:  '"Space Mono", monospace',        // body text — slightly warmer mono
    sans:  'system-ui, -apple-system, sans-serif', // fallback only
  },

  // Spacing (4px base grid)
  spacing: {
    px: '1px',
    0.5: '2px',
    1: '4px',
    2: '8px',
    3: '12px',
    4: '16px',
    5: '20px',
    6: '24px',
    8: '32px',
    10: '40px',
    12: '48px',
    16: '64px',
  },

  // Border radius — pixel-art prefers sharp corners
  radius: {
    none: '0px',
    sm: '2px',
    DEFAULT: '4px',
    md: '4px',
    lg: '8px',
    full: '9999px',
  },

  // Shadows — glow effects
  shadows: {
    glow: '0 0 10px rgba(34, 197, 94, 0.5)',
    glowStrong: '0 0 20px rgba(34, 197, 94, 0.8)',
    glowAccent: '0 0 10px rgba(245, 158, 11, 0.5)',
    glowError: '0 0 10px rgba(239, 68, 68, 0.5)',
    card: '0 2px 8px rgba(0, 0, 0, 0.8)',
    inset: 'inset 0 2px 4px rgba(0, 0, 0, 0.5)',
  },

  // Animation
  animation: {
    scanline: 'scanline 8s linear infinite',
    blink: 'blink 1s step-end infinite',
    glitch: 'glitch 0.3s ease-in-out',
    fadeIn: 'fadeIn 0.3s ease-out',
    slideUp: 'slideUp 0.2s ease-out',
  },

  // Z-index scale
  zIndex: {
    base: 0,
    raised: 10,
    dropdown: 100,
    sticky: 200,
    overlay: 300,
    modal: 400,
    toast: 500,
    tooltip: 600,
  },
} as const;

// ─────────────────────────────────────────────
// APP CONSTANTS
// ─────────────────────────────────────────────

export const APP_CONFIG = {
  name: 'RetroWorks HR',
  version: '0.1.0',
  region: 'IN',
  defaultCurrency: 'INR',
  defaultLocale: 'en-IN',
  defaultTimezone: 'Asia/Kolkata',
  domain: process.env['NEXT_PUBLIC_DOMAIN'] || 'localhost',
  apiUrl: process.env['NEXT_PUBLIC_API_URL'] || 'http://localhost:3001',
  wsUrl: process.env['NEXT_PUBLIC_WS_URL'] || 'ws://localhost:3001',
} as const;

export const PAGINATION = {
  defaultLimit: 25,
  maxLimit: 100,
  cursorField: 'id',
} as const;

export const FILE_UPLOAD = {
  maxSizeMb: 10,
  allowedTypes: ['image/jpeg', 'image/png', 'image/webp', 'application/pdf',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/csv'],
} as const;

export const INDIA_STATUTORY = {
  PF_EMPLOYEE_RATE: 0.12,
  PF_EMPLOYER_RATE: 0.12,
  PF_WAGE_CEILING: 15000,
  ESI_EMPLOYEE_RATE: 0.0075,
  ESI_EMPLOYER_RATE: 0.0325,
  ESI_WAGE_LIMIT: 21000,
  GRATUITY_ELIGIBILITY_YEARS: 5,
  GRATUITY_FORMULA_DIVISOR: 26,
} as const;

export const MODULE_NAMES: Record<string, string> = {
  ats: 'Applicant Tracking',
  onboarding: 'Onboarding',
  'core-hr': 'Core HR',
  attendance: 'Attendance',
  leave: 'Leave Management',
  payroll: 'Payroll',
  benefits: 'Benefits',
  performance: 'Performance & OKRs',
  lnd: 'Learning & Development',
  expenses: 'Expenses',
  assets: 'Asset Management',
  helpdesk: 'HR Helpdesk',
  surveys: 'Surveys & Feedback',
  integrations: 'Integrations',
  offboarding: 'Offboarding',
};

// ─────────────────────────────────────────────
// INDIA STATE PT SLABS (Profession Tax)
// ─────────────────────────────────────────────

export const INDIA_PT_SLABS: Record<string, { from: number; to?: number; monthly: number }[]> = {
  KA: [ // Karnataka
    { from: 0, to: 14999, monthly: 0 },
    { from: 15000, monthly: 200 },
  ],
  MH: [ // Maharashtra
    { from: 0, to: 7500, monthly: 0 },
    { from: 7501, to: 10000, monthly: 175 },
    { from: 10001, monthly: 200 },
  ],
  WB: [ // West Bengal
    { from: 0, to: 10000, monthly: 0 },
    { from: 10001, to: 15000, monthly: 110 },
    { from: 15001, to: 25000, monthly: 130 },
    { from: 25001, to: 40000, monthly: 150 },
    { from: 40001, monthly: 200 },
  ],
  AP: [ // Andhra Pradesh
    { from: 0, to: 15000, monthly: 0 },
    { from: 15001, to: 20000, monthly: 150 },
    { from: 20001, monthly: 200 },
  ],
  TN: [ // Tamil Nadu
    { from: 0, to: 21000, monthly: 0 },
    { from: 21001, monthly: 208 }, // special case — annual 2500
  ],
};
