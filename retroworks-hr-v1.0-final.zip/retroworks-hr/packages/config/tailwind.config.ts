import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    '../../packages/ui/src/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // CRT Phosphor Greens — Primary
        primary: {
          50: '#f0fdf0',
          100: '#dcfce7',
          200: '#bbf7d0',
          300: '#86efac',
          400: '#4ade80',
          500: '#22c55e',
          600: '#16a34a',
          700: '#15803d',
          800: '#166534',
          900: '#14532d',
          950: '#052e16',
          crt: '#00ff41',
          DEFAULT: '#22c55e',
        },
        // Retro Amber Accent
        accent: {
          DEFAULT: '#f59e0b',
          crt: '#ff9900',
          dim: '#92400e',
        },
        // Dark backgrounds
        retro: {
          bg: '#080c08',
          'bg-secondary': '#0d160d',
          'bg-tertiary': '#111a11',
          card: '#0f1a0f',
          border: '#1a2e1a',
          'border-hover': '#2a4a2a',
          cyan: '#00ffff',
          magenta: '#ff00ff',
        },
        // Surface colors
        surface: {
          DEFAULT: '#0f1a0f',
          raised: '#162416',
          overlay: '#1a2e1a',
        },
      },
      fontFamily: {
        pixel: ['"Press Start 2P"', 'monospace'],
        mono: ['"Space Mono"', '"JetBrains Mono"', 'monospace'],
        body: ['"Space Mono"', 'monospace'],
        sans: ['system-ui', '-apple-system', 'sans-serif'],
      },
      fontSize: {
        'pixel-xs': ['8px', { lineHeight: '16px', letterSpacing: '0.05em' }],
        'pixel-sm': ['10px', { lineHeight: '18px', letterSpacing: '0.05em' }],
        'pixel-base': ['12px', { lineHeight: '20px', letterSpacing: '0.05em' }],
        'pixel-lg': ['14px', { lineHeight: '24px', letterSpacing: '0.05em' }],
        'pixel-xl': ['16px', { lineHeight: '28px', letterSpacing: '0.05em' }],
        'pixel-2xl': ['20px', { lineHeight: '32px', letterSpacing: '0.05em' }],
      },
      boxShadow: {
        'glow': '0 0 10px rgba(34, 197, 94, 0.5)',
        'glow-strong': '0 0 20px rgba(34, 197, 94, 0.8)',
        'glow-accent': '0 0 10px rgba(245, 158, 11, 0.5)',
        'glow-error': '0 0 10px rgba(239, 68, 68, 0.5)',
        'glow-info': '0 0 10px rgba(59, 130, 246, 0.5)',
        'pixel': '2px 2px 0px rgba(34, 197, 94, 0.3)',
        'pixel-lg': '4px 4px 0px rgba(34, 197, 94, 0.3)',
        'card': '0 2px 8px rgba(0, 0, 0, 0.8)',
        'inset': 'inset 0 2px 4px rgba(0, 0, 0, 0.5)',
      },
      borderRadius: {
        none: '0px',
        sm: '2px',
        DEFAULT: '4px',
        md: '4px',
        lg: '8px',
      },
      animation: {
        'scanline': 'scanline 8s linear infinite',
        'blink-cursor': 'blink 1s step-end infinite',
        'glitch': 'glitch 0.3s ease-in-out',
        'fade-in': 'fadeIn 0.3s ease-out',
        'slide-up': 'slideUp 0.2s ease-out',
        'slide-down': 'slideDown 0.2s ease-out',
        'glow-pulse': 'glowPulse 2s ease-in-out infinite',
        'pixel-boot': 'pixelBoot 0.5s steps(10) forwards',
        'scroll-down': 'scrollDown 20s linear infinite',
        'typing': 'typing 2s steps(40) forwards',
      },
      keyframes: {
        scanline: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100vh)' },
        },
        blink: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0' },
        },
        glitch: {
          '0%': { transform: 'translate(0)' },
          '20%': { transform: 'translate(-2px, 2px)' },
          '40%': { transform: 'translate(-2px, -2px)' },
          '60%': { transform: 'translate(2px, 2px)' },
          '80%': { transform: 'translate(2px, -2px)' },
          '100%': { transform: 'translate(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(8px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        slideDown: {
          '0%': { transform: 'translateY(-8px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
        glowPulse: {
          '0%, 100%': { boxShadow: '0 0 5px rgba(34, 197, 94, 0.3)' },
          '50%': { boxShadow: '0 0 20px rgba(34, 197, 94, 0.8)' },
        },
        pixelBoot: {
          '0%': { opacity: '0', transform: 'scale(0.95)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
        typing: {
          '0%': { width: '0' },
          '100%': { width: '100%' },
        },
      },
      backgroundImage: {
        'crt-lines': 'repeating-linear-gradient(0deg, rgba(0,0,0,0.1) 0px, rgba(0,0,0,0.1) 1px, transparent 1px, transparent 2px)',
        'pixel-grid': 'repeating-linear-gradient(#1a2e1a 0 1px, transparent 1px 100%), repeating-linear-gradient(90deg, #1a2e1a 0 1px, transparent 1px 100%)',
        'terminal-glow': 'radial-gradient(ellipse at center, rgba(34,197,94,0.05) 0%, transparent 70%)',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/typography'),
  ],
};

export default config;
