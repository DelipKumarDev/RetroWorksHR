'use client';

import * as React from 'react';
import { cn } from '../utils/cn';

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  glow?: boolean;
  glowColor?: 'green' | 'amber' | 'red' | 'blue';
  scanlines?: boolean;
  header?: React.ReactNode;
  footer?: React.ReactNode;
  noPadding?: boolean;
}

export const Card = React.forwardRef<HTMLDivElement, CardProps>(
  ({ className, glow, glowColor = 'green', scanlines, header, footer, noPadding, children, ...props }, ref) => {
    const glowClasses = {
      green: 'shadow-glow border-primary-800 hover:border-primary-600',
      amber: 'shadow-glow-accent border-accent/50 hover:border-accent',
      red: 'shadow-glow-error border-red-800 hover:border-red-600',
      blue: 'shadow-glow-info border-blue-800 hover:border-blue-600',
    };

    return (
      <div
        ref={ref}
        className={cn(
          'relative bg-retro-card border border-retro-border rounded',
          'transition-all duration-200',
          glow && glowClasses[glowColor],
          !glow && 'hover:border-retro-border-hover',
          'overflow-hidden',
          className
        )}
        {...props}
      >
        {/* CRT scanlines overlay */}
        {scanlines && (
          <div
            className="absolute inset-0 bg-crt-lines pointer-events-none z-10 opacity-20"
            aria-hidden="true"
          />
        )}

        {/* Terminal window chrome */}
        {header && (
          <div className="flex items-center gap-2 px-4 py-2 border-b border-retro-border bg-retro-bg-secondary">
            {/* Pixel "traffic lights" */}
            <span className="w-2 h-2 rounded-none bg-red-600 opacity-70" />
            <span className="w-2 h-2 rounded-none bg-accent-dim opacity-70" />
            <span className="w-2 h-2 rounded-none bg-primary-700 opacity-70" />
            <div className="ml-2 flex-1 font-pixel text-pixel-xs text-primary-600">
              {header}
            </div>
          </div>
        )}

        {/* Content */}
        <div className={cn(!noPadding && 'p-4')}>{children}</div>

        {/* Footer */}
        {footer && (
          <div className="px-4 py-3 border-t border-retro-border bg-retro-bg-secondary">
            {footer}
          </div>
        )}
      </div>
    );
  }
);
Card.displayName = 'Card';

// Stat card variant for dashboards
interface StatCardProps {
  label: string;
  value: string | number;
  delta?: string;
  deltaType?: 'positive' | 'negative' | 'neutral';
  icon?: React.ReactNode;
  className?: string;
}

export function StatCard({ label, value, delta, deltaType = 'neutral', icon, className }: StatCardProps) {
  const deltaColors = {
    positive: 'text-primary-400',
    negative: 'text-red-400',
    neutral: 'text-primary-600',
  };

  return (
    <Card className={cn('min-w-0', className)} glow>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0 flex-1">
          <p className="font-pixel text-[9px] text-primary-600 uppercase tracking-widest mb-2 truncate">
            {label}
          </p>
          <p className="font-pixel text-pixel-lg text-primary-crt leading-none">
            {value}
          </p>
          {delta && (
            <p className={cn('font-mono text-xs mt-1', deltaColors[deltaType])}>
              {delta}
            </p>
          )}
        </div>
        {icon && (
          <div className="text-primary-700 shrink-0 mt-1">
            {icon}
          </div>
        )}
      </div>
    </Card>
  );
}
