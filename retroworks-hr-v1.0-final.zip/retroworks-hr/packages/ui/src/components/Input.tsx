'use client';

import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../utils/cn';

const inputVariants = cva(
  [
    'w-full bg-retro-bg border-2 font-mono text-sm text-primary-300',
    'placeholder:text-primary-700 placeholder:font-mono',
    'transition-all duration-150 outline-none',
    'disabled:opacity-40 disabled:cursor-not-allowed',
    // Caret style
    'caret-primary-crt',
  ],
  {
    variants: {
      variant: {
        default: [
          'border-retro-border rounded',
          'focus:border-primary-600 focus:shadow-glow focus:bg-retro-bg-secondary',
          'hover:border-primary-800',
        ],
        error: [
          'border-red-700 rounded',
          'focus:border-red-500 focus:shadow-glow-error',
        ],
        terminal: [
          'border-0 border-b-2 border-primary-800 rounded-none bg-transparent',
          'focus:border-primary-crt',
          'pl-0',
        ],
      },
      size: {
        sm: 'px-3 py-1.5 text-xs h-7',
        md: 'px-3 py-2 text-sm h-9',
        lg: 'px-4 py-2.5 text-base h-11',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'md',
    },
  }
);

export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'>,
    VariantProps<typeof inputVariants> {
  label?: string;
  error?: string;
  hint?: string;
  leftAddon?: React.ReactNode;
  rightAddon?: React.ReactNode;
  prefix?: string;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, variant, size, label, error, hint, leftAddon, rightAddon, prefix, id, ...props }, ref) => {
    const inputId = id || `input-${Math.random().toString(36).slice(2, 9)}`;
    const hasError = Boolean(error);

    return (
      <div className="w-full space-y-1">
        {label && (
          <label
            htmlFor={inputId}
            className="block font-pixel text-[9px] text-primary-500 uppercase tracking-widest"
          >
            {label}
            {props.required && <span className="text-accent-crt ml-1">*</span>}
          </label>
        )}

        <div className="relative flex items-center">
          {leftAddon && (
            <div className="absolute left-3 text-primary-600">
              {leftAddon}
            </div>
          )}
          {prefix && (
            <span className="absolute left-3 font-mono text-sm text-primary-600">
              {prefix}
            </span>
          )}

          <input
            ref={ref}
            id={inputId}
            className={cn(
              inputVariants({ variant: hasError ? 'error' : variant, size }),
              leftAddon || prefix ? 'pl-8' : '',
              rightAddon ? 'pr-8' : '',
              className
            )}
            aria-invalid={hasError}
            aria-describedby={hasError ? `${inputId}-error` : hint ? `${inputId}-hint` : undefined}
            {...props}
          />

          {rightAddon && (
            <div className="absolute right-3 text-primary-600">
              {rightAddon}
            </div>
          )}
        </div>

        {error && (
          <p id={`${inputId}-error`} className="font-mono text-xs text-red-400 flex items-center gap-1">
            <span aria-hidden>✗</span> {error}
          </p>
        )}
        {hint && !error && (
          <p id={`${inputId}-hint`} className="font-mono text-xs text-primary-700">
            {hint}
          </p>
        )}
      </div>
    );
  }
);
Input.displayName = 'Input';

// Textarea variant
export const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: string; error?: string; hint?: string }
>(({ className, label, error, hint, id, ...props }, ref) => {
  const inputId = id || `textarea-${Math.random().toString(36).slice(2, 9)}`;

  return (
    <div className="w-full space-y-1">
      {label && (
        <label htmlFor={inputId} className="block font-pixel text-[9px] text-primary-500 uppercase tracking-widest">
          {label}
          {props.required && <span className="text-accent-crt ml-1">*</span>}
        </label>
      )}
      <textarea
        ref={ref}
        id={inputId}
        className={cn(
          'w-full bg-retro-bg border-2 border-retro-border rounded font-mono text-sm text-primary-300',
          'placeholder:text-primary-700 caret-primary-crt',
          'focus:border-primary-600 focus:shadow-glow focus:bg-retro-bg-secondary focus:outline-none',
          'hover:border-primary-800 transition-all duration-150',
          'px-3 py-2 min-h-[80px] resize-y',
          'disabled:opacity-40',
          error && 'border-red-700 focus:border-red-500',
          className
        )}
        aria-invalid={Boolean(error)}
        {...props}
      />
      {error && (
        <p className="font-mono text-xs text-red-400">✗ {error}</p>
      )}
      {hint && !error && (
        <p className="font-mono text-xs text-primary-700">{hint}</p>
      )}
    </div>
  );
});
Textarea.displayName = 'Textarea';
