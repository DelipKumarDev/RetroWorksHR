'use client';

import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../utils/cn';

const badgeVariants = cva(
  'inline-flex items-center gap-1 font-pixel uppercase tracking-widest border',
  {
    variants: {
      variant: {
        default: 'bg-primary-950 border-primary-700 text-primary-400',
        success: 'bg-green-950 border-green-700 text-green-400',
        warning: 'bg-amber-950 border-amber-700 text-amber-400',
        error: 'bg-red-950 border-red-700 text-red-400',
        info: 'bg-blue-950 border-blue-700 text-blue-400',
        purple: 'bg-purple-950 border-purple-700 text-purple-400',
        ghost: 'bg-transparent border-retro-border text-primary-600',
        // Status-specific
        active: 'bg-green-950 border-green-700 text-green-400',
        pending: 'bg-amber-950 border-amber-700 text-amber-400',
        rejected: 'bg-red-950 border-red-700 text-red-400',
        approved: 'bg-green-950 border-green-700 text-green-400',
        draft: 'bg-retro-bg-secondary border-retro-border text-primary-600',
      },
      size: {
        xs: 'px-1.5 py-0.5 text-[7px]',
        sm: 'px-2 py-0.5 text-[8px]',
        md: 'px-2.5 py-1 text-[9px]',
      },
      dot: {
        true: '',
        false: '',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'sm',
      dot: false,
    },
  }
);

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {}

export function Badge({ className, variant, size, dot, children, ...props }: BadgeProps) {
  return (
    <span className={cn(badgeVariants({ variant, size, dot }), className)} {...props}>
      {dot && (
        <span className={cn(
          'w-1.5 h-1.5 rounded-full inline-block',
          variant === 'success' || variant === 'active' || variant === 'approved' ? 'bg-green-400' :
          variant === 'warning' || variant === 'pending' ? 'bg-amber-400' :
          variant === 'error' || variant === 'rejected' ? 'bg-red-400' :
          variant === 'info' ? 'bg-blue-400' :
          variant === 'purple' ? 'bg-purple-400' : 'bg-primary-600'
        )} />
      )}
      {children}
    </span>
  );
}

// Convenience status badge
export function StatusBadge({ status }: { status: string }) {
  const statusMap: Record<string, VariantProps<typeof badgeVariants>['variant']> = {
    active: 'active',
    approved: 'approved',
    pending: 'pending',
    rejected: 'rejected',
    draft: 'draft',
    cancelled: 'error',
    terminated: 'error',
    completed: 'success',
    processing: 'info',
    'on-leave': 'purple',
    'notice-period': 'warning',
  };

  return (
    <Badge variant={statusMap[status.toLowerCase()] ?? 'default'} dot>
      {status.replace(/-/g, ' ')}
    </Badge>
  );
}
