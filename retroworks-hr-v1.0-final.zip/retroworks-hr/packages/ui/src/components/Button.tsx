'use client';

import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '../utils/cn';

const buttonVariants = cva(
  // Base styles — pixel art feel
  [
    'inline-flex items-center justify-center gap-2',
    'font-pixel text-pixel-xs uppercase tracking-wider',
    'border-2 transition-all duration-100',
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-crt focus-visible:ring-offset-2 focus-visible:ring-offset-retro-bg',
    'disabled:pointer-events-none disabled:opacity-40',
    'active:translate-y-px',
    // Keyboard focus always visible — accessibility
    'focus:outline-2 focus:outline-primary-500',
  ],
  {
    variants: {
      variant: {
        // Primary — CRT green
        primary: [
          'bg-primary-900 border-primary-500 text-primary-crt',
          'hover:bg-primary-800 hover:border-primary-crt hover:shadow-glow',
          'active:bg-primary-950',
        ],
        // Accent — Amber
        accent: [
          'bg-amber-950 border-accent text-accent-crt',
          'hover:bg-amber-900 hover:border-accent-crt hover:shadow-glow-accent',
        ],
        // Ghost — transparent
        ghost: [
          'bg-transparent border-retro-border text-primary-400',
          'hover:bg-surface-raised hover:border-primary-700 hover:text-primary-300',
        ],
        // Danger
        danger: [
          'bg-red-950 border-red-700 text-red-400',
          'hover:bg-red-900 hover:border-red-500 hover:shadow-glow-error',
        ],
        // Terminal — monospace raw style
        terminal: [
          'bg-retro-bg border-primary-800 text-primary-500 font-mono',
          'hover:border-primary-600 hover:text-primary-400',
          'before:content-[">_"] before:text-primary-crt before:mr-1',
        ],
        // Link
        link: [
          'bg-transparent border-transparent text-primary-400',
          'hover:text-primary-crt hover:underline hover:underline-offset-4',
          'p-0',
        ],
      },
      size: {
        xs: 'h-6 px-2 py-0.5 text-[8px]',
        sm: 'h-7 px-3 py-1 text-[9px]',
        md: 'h-9 px-4 py-2 text-pixel-xs',
        lg: 'h-11 px-6 py-2 text-pixel-sm',
        xl: 'h-13 px-8 py-3 text-pixel-sm',
        icon: 'h-9 w-9 p-2',
        'icon-sm': 'h-7 w-7 p-1.5',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  loading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, leftIcon, rightIcon, children, disabled, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={cn(buttonVariants({ variant, size }), className)}
        disabled={disabled || loading}
        aria-busy={loading}
        {...props}
      >
        {loading ? (
          <span className="animate-blink-cursor">▋</span>
        ) : (
          leftIcon
        )}
        {children}
        {!loading && rightIcon}
      </button>
    );
  }
);
Button.displayName = 'Button';

export { buttonVariants };
